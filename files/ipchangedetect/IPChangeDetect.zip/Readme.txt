IPChangeDetect - by Mark Cocquio (strepto@fromorbit.com)

(c) 2001

Legal blah:

Free for personal use, provided users promise to limit their use of plastic bags in the future. I mean, come on, do you REALLY need one for a single fucking carton of milk?!

Commercial use forbidden without obtaining permission from the author. Large bastardly multinationals must pay $US100,000, half of which will go to the charity of my choice.

If this program destroys all your data, I take no responsibility (I always wanted to write that! Hell, if this program manages to do any damage, please let me know! I'll be very impressed!)

So there.



Some brief ramblings on it... yep, this is what passes as 'documentation'.


Background:

So you got your wonderful fast ADSL (or whatever) fast connection hooked up. Super. Installed a few funky programs, like Webcam32, which incorporates a nifty little http server to let you grab images from the web, and maybe VNC, for remote control of your PC while at work, etc.

Only problem is... how does you know the IP address of your machine, as they're allocated dynamically using DCHP.

Ok, so by now you've probably discovered the wonders of a Dynamic DNS system (like http://www.ddns.nu), so you can have a domain name assigned to your IP address.

Only problem is, what happens if you're at work, and the power goes out on your home machine, or the cable connection drops out. Sure, you've set up things so the machine will re-connect automatically. But you're not around to update your DDNS entry. Grr.

Now, if Microsoft had put in some way of running a command just after hooking up with a server, you could set up your favourite DDNS updating program to run as soon as your machine reconnected.

But they didn't... at least, not that I've discovered. Who knows, there may actually be a way, and I might have just wasted a few hours writing this thing. At any rate it was a programming exercise. ;)

(if you do know of a way, let me know...)


About IPChangeDetect:

It's pretty straightforward. My imaginatively-named program will scan your machine's IP address (or addresses if you have a LAN happening), and if something changes, it'll fire off an update to the DDNS server.

Special thanks go to James Salter for sending me the code for AutoDDNS - originally this was just going to be a program to fire off an arbitrary command, now it'll actually do the DDNS update itself.


Setting it up:

Just install it, and run it.

If more than one IP address is listed, tick the ones that are static (ie the lan ones).  At the end of this process you should only have one IP address UNTICKED.

I'm using RASPPPOE to connect to ADSL, and I have a LAN running, so I have two static IPs (one for each network card) and one dynamic one when I'm hooked up (which is pretty much all the time).

As of the latest version, the program will automatically tick any new addresses which are in a private IP range - 10.0.0.x, 192.168.x.x etc.

Next enter the login details for your DDNS, and the handle you want to update.

Enter an interval in minutes for the program to use when polling your machine's IP addresses. This doesn't have to be too small, something like 15 minutes should be fine. I'm using 5 as it doesn't actually use any significant processor power, and I want my machine to be available quicker if it's address changes.

The interval before your machine's DNS name will work again will be somewhere around this value, plus the life of your DDNS entry (which you set up online).

Now tick the various configuration boxes as required. "Start minimised" is pretty damn obvious. Once everything's set up to your liking, tick this and whack the program in your startup folder if you like.

"Verbose action log" will make the program spit out info about its polls every time. If it's not ticked, info will only appear if your IP changes and the update gets triggered, or if new IPs are detected.

"Clean registry on exit" requires a little bit more info. The program works by storing the IP addresses in the registry. If a new one appears it gets added (and an update is triggered) - and if one is already there (in the case of you getting re-allocated the same IP) it is checked for a 'this is static' flag (this is why you need to tick off the static IPs). If it's not flagged as static the updater will also be fired... blah blah.

The practical upshot of this is that each time you get allocated a new IP, it gets stored in the registry. Ticking this box will delete these values when the program exits; it's that simple. If you want a record of the addresses you've been allocated you can leave it unticked. It's no biggie, but in 10000 years or something you might fill your registry. How exciting.

That's it! Just click "save setup" and away you go...


Known Issues:

* The program will only handle one dynamic IP - if you have some bizarre need for numerous DDNS entries from the same machine you won't be using this.

* If the popup window warning about multiple IP updates is active and you try to pop up the program without clicking OK, you'll get a VB runtime error. This is no biggie, and in fact the latest version shouldn't pop up the window very often, if ever, as it flags private IPs as static automatically. In fact, it'll only really pop up if you haven't configured things properly (ie if you leave more than one IP address unticked).


If you have any comments or suggestions feel free to email me... strepto@fromorbit.com.

That's it. Thanks everyone for reading this exciting documentation. I hope you had as much fun reading it as I did writing it. Thanks also to those wonderful people who've got the DDNS thing working - there's real code involved in that sort of thing (as opposed to VB :))


Todo:

Maybe one day I'll learn Java well enough to write this in a real language. Till then it's windows only I'm afraid.


Version History:

1.1.21	- Added 127.0.0.1 to the 'private' ip list so it will be flagged as static by default.

1.1.20	- New IPs will be automatically flagged as 'static' if they are in the private ranges 10.0.0.x,
	  192.168.x.x and 169.254.x.x.

1.1.19	- Fixed bug where if update was called twice in one go (eg if two IPs were not flagged
	  as static) it would crash with an error. Now it'll pop up a box and warn you, so you
	  can go in and make sure only one IP is not ticked as static
	- Redid the display code for the DDNS updater, it's a bit cleaner now and doesn't show
	  the password.
	- tested the timeout code - it does work properly (of course ;))

1.1.17	- Fixed a bug whereby only one update would work per time run
	- Added a manual 'update now' button
	- Tried to add code to handle server timeouts, kinda hard to test but I think it'll work

1.1.15	- Incorporated James Salter's AutoDDNS code

1.0.10	- First Release, boring and buggy
