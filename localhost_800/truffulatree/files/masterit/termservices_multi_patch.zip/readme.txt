concurrent connections patch by BigT (2005)
-------------------------------------------

(*) steps requiring Safe Mode

unpacking	|	unzip all the files in the same directory.
----------------------------------------------------------
enabling*	|	run "mulTermInst.bat"
----------------------------------------------------------
disabling*	|	run "mulTermUninst.bat"


note : 	"Fast User Switching" and "Welcome Screen" must be be enabled
	from the "start menu" >> "control panel" >> "user accounts" >>
	"change the way users log on or off" >> check both options >> "apply"

contact : bigtiti@hotmail.com