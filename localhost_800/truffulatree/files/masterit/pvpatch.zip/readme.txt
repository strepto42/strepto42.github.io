To disable the Microsoft picture previewer, just double click the ImagePreview_disable.reg file.

If you'd like to re-enable at any stage, use the other file.