<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - 26/8/2005 - Kakadu and Litchfield</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="Kakadu and Litchfield">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="Greetings from a Bum" href='greetingsfromabum.php'>29/4/2005</a></li>
<li><a title="Onward" href='onward.php'>2/5/2005</a></li>
<li><a title="It's a tough life (pt 1: Bundaberg, Agnes Water and 1770)" href='itsatoughlife1.php'>17/5/2005</a></li>
<li><a title="It's a tough life (pt 2: Rockhampton, Emu Park and Great Keppel Island)" href='itsatoughlife2.php'>23/5/2005</a></li>
<li><a title="There and Back Again - a Yo-yo's Tale" href='thereandbackagain.php'>18/6/2005</a></li>
<li><a title="Platypi and Grey Nomads" href='platypiandgreynomads.php'>24/6/2005</a></li>
<li><a title="Blowing Bubbles in a Watery Tomb" href='blowingbubbles.php'>1/7/2005</a></li>
<li><a title="Pieces of History" href='piecesofhistory.php'>8/7/2005</a></li>
<li><a title="Walks and Waterfalls" href='walksandwaterfalls.php'>15/7/2005</a></li>
<li><a title="Mission to Tribulation" href='missiontotribulation.php'>22/7/2005</a></li>
<li><a title="Levity, Limestone and Lava" href='levitylimestoneandlava.php'>29/7/2005</a></li>
<li><a title="Into the Never Never" href='intothenevernever.php'>5/8/2005</a></li>
<li><a title="Slowing the pace in Darwin" href='slowingthepaceindarwin.php'>12/8/2005</a></li>
<li><a title="Blistering Barnacles and Leaping Lizards" href='leapinglizards.php'>19/8/2005</a></li>
<li><div class='activemenu'>26/8/2005</div></li>
<li><a title="Legacies of War" href='legaciesofwar.php'>2/9/2005</a></li>
<li><a title="Go West" href='gowest.php'>10/9/2005</a></li>
<li><a title="Things from Above" href='thingsfromabove.php'>16/9/2005</a></li>
<li><a title="The West Coast" href='thewestcoast.php'>23/9/2005</a></li>
<li><a title="Reefs and Red Dust" href='reefsandreddust.php'>30/9/2005</a></li>
<li><a title="The Pilbara" href='pilbara.php'>7/10/2005</a></li>
<li><a title="Paradise with a Headwind" href='paradisewithaheadwind.php'>14/10/2005</a></li>
<li><a title="Down the Coral Coast" href='downthecoralcoast.php'>21/10/2005</a></li>
<li><a title="Pinnacles and Pinnipeds" href='pinnaclesandpinnipeds.php'>28/10/2005</a></li>
<li><a title="A week in Perth" href='perth.php'>4/11/2005</a></li>
<li><a title="The Southwest (from Above and Below)" href='thesouthwest.php'>11/11/2005</a></li>
<li><a title="More Heights and Depths" href='moreheightsanddepths.php'>18/11/2005</a></li>
<li><a title="Across the Nullarbor (and a bit beyond)" href='nullarbor.php'>25/11/2005</a></li>
<li><a title="Double Whammy" href='doublewhammy.php'>9/12/2005</a></li>
<li><a title="Two Cities" href='twocities.php'>19/12/2005</a></li>
<li><a title="Tassie - Part 1" href='tassie1.php'>1/1/2006</a></li>
<li><a title="Tassie - Part 2" href='tassie2.php'>7/1/2006</a></li>
<li><a title="Full Circle" href='fullcircle.php'>26/1/2006</a></li>
<li><a title="The Wrap Up" href='thewrapup.php'>23/3/2006</a></li>
<li> </li><br><li>Or go back to:</li><li><a title='Travelouges and blogs from my trip around Australia' href="nerdseyeview.php">Nerd's Eye View</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>26/8/2005</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Travel stories and pictures' href="travel.php">Travelogues</a> > <a title='Travelouges and blogs from my trip around Australia' href="nerdseyeview.php">Nerd's Eye View</a> > <a title='Kakadu and Litchfield' href="kakadu.php">26/8/2005</a>
<br><br>		


<h1>Kakadu and Litchfield</h1>

<a href="images/maps/Map050826.gif"><img src="images/maps/Map050826_sm.gif" align="right"></a>

<p>Here I am again, another Friday email. Often, I write most of the text for these on Thursday night, just because it takes a while, and I'm generally not doing much else.</p>

<p>So it's Thursday my time, and evening, and I'm sitting in Litchfield National Park, after spending a week in Kakadu. Right now, there are about 50 flying ants on my screen, and their numbers are rising steadily. Such are the perils of outdoor laptop work in the tropics; I shall soldier on anyway.</p>

<p>Well, where to begin. It's been one of the fuller weeks of my trip, and there's a fair bit to relate. This is going to be a rather long one I'm afraid. :)</p>

<p>First stop after my last exploits was the Mamukala wetlands, just up the road from where I was staying. This spot has an excellent bird observation building, so I took the whole kit down, tripod and all, to spend a few hours being a serious bird nerd. I got some great shots of various birds, including lots of Magpie Geese, and great pic of a Rainbow Bee-eater, which turned out to actually have a bee in it's beak (I didn't notice when I took the shot, and subsequently got very excited when I looked at it on the computer).</p>

<p>After that I drove to Jabiru, in the Park's north, near the Ranger Uranium mine, and spent the day in the lovely air conditioned library there, sending out the last weekly update. Whilst doing this, I looked out the window and noticed enormous numbers of fruit bats flying around, so I had to grab a few snaps.</p>

<p>Apparently they're Little Red Flying Foxes, and aren't residents; they're just passing through. They've sensibly chosen the police and courthouse area to roost (and crap on extensively). And there are a hell of a lot of them. Tree after tree is black with the buggers. All quite cute I reckon, just don't park your car underneath...</p>

<p>After that diversion, a visit to the park HQ (to pick up a ton of info) revealed that the following day (ie last Saturday) was the annual open day/festival thing for the town/community of Oenpelli, just over the border in Arnhem land. Normally, one needs a permit to visit, and it sounded interesting, so I headed out for the day.</p>

<p>All up, it was an interesting day. For starters, all the local community and school AFL teams were having a comp, so I have actually attended my first AFL match now (which will make some people reading this laugh). Of course, it also afforded the chance to try another new type of photography - sports. It's much like bird photography actually, only easier, as people don't move as quickly, or fly (unless the tackle is particularly brutal, and even then, the flight is short-lived).</p>

<p>I spent most of the day riding around and absorbing the atmosphere, and I got some great photos of the local billabong, which borders the town. The colours there were amazing, greens and blues with a backdrop of outback orange. The country there is simply stunning; even in Kakadu I didn't see anything that quite matched it.</p>

<p>At the end of the day, there was an army demo of sorts scheduled. I had visions of vehicles, smoke grenades and howitzers, as my folks used to take me to the occasional "invasion" at Birkenhead point in Sydney when I was a kid. So I sat through interminable AFL matches (what I thought was the final was only the quarter final), and in the end all that happened was some guys in camo shot blanks at each other for 2 minutes, then pretended to be dead. That'll teach me!</p>

<p>The silver lining was that by the time I headed back to Jabiru, it was dusk, and the Arnhem land escarpment was particularly gorgeous. I have prepared a couple of panoramic pics; they're quite large though so you'll have to email me and ask for them if you want a copy.</p>

<p>That night, I hooked up with a Kiwi guy for some guitar and beer action back at the caravan park. Sunday I therefore spent quite hung over. Nuff said.</p>

<p>Monday was a day of contrasts. In the morning, I went on a tour of the Ranger mine, just to see it first hand. Rather than provide any particular commentary, I'll let the pictures do the talking, and people can interpret them in their own way. It was interesting to see the scale of such an operation; perhaps in 20 years I'll come back (with camera and Geiger counter) and see how much of a sign is left. </p>

<p>By the way, the yellow stuff in the pictures isn't uranium - leaving piles of yellowcake blowing around like that would certainly not be very sensible - it's sulphur, used to make sulphuric acid, which is used (among other processes) to extract the U from it's parent rock.</p>

<p>After the industrial, it was back to natural. I drove south to a spot called Nourlangie rock, and went on a nice long walk around the billabong there, followed by a climb up a small hill to a lovely lookout, followed in turn by an amble through some aboriginal art sites, some more ancient than others (some very old indeed).</p>

<p>They certainly make a point of all the culture in the place, and the literature has various quotes from elders throughout. This is fine, except sometimes a little editing is probably preferable to a direct quote. One in particular starts: "We tell you stories that have been told to us by our old people. They go on and on...". Just like Grandpa Simpson, no doubt.</p>

<p>The next day called for yet another billabong circuit (the amusingly named "Bubba Wetlands", although it's not pronounced that way), and whilst I'm just about billabonged out now, this one was particularly nice (although not as picturesque as the one in Oenpelli).</p>

<p>I spent the night at another caravan park near a spot called Yellow Water, where they do river cruises, but I elected not to go on one; having already seen my share of birds and wetlands. I also didn't bother visiting Jim Jim and Twin Falls, as they required a proper 4WD to get in (although talking to people, I would have been able to go most of the way, then walk or cycle the rest). Not to worry, gotta save something for next time after all, and those places are ultra-touristy.</p>

<p>I wasn't going to ignore all the waterfalls in the park though - when I had visited the info centre, I discussed the possibilities re my vehicle with the ranger. An alternative to Jim Jim was suggested - Maguk (say it again! say it louder!). This spot is marked as 4WD only, but the road there is much shorter, so the theory was that if I had to stop and turn back, it'd be after a much shorter trip (Jim Jim is 60kms of dirt in before you hit the 4WD bit).</p>

<p>So, after my Bubba walk I headed off down the road to Magluk and eventually got to the so-called 4WD bit. It was a bit sandy for a while, and whilst it looked ok, it was narrow, and I didn't know what was around the corner. So I parked and headed in on the bike to investigate. Bikes, especially ones with thin road tyres, don't react terribly well to sand either of course, but they're sooo much easier to pull out.</p>

<p>I rode in about 300m when someone came the other way. I flagged them down and their look of complete confusion faded when I explained my mission and motives. They assured me that the bit I had already passed was the worst (and in fact the only bad) bit. So in I went with the mighty Subie, without even a hiccup.</p>

<p>I had been a bit cynical earlier about the worth of all this bother just to visit yet another waterfall, but once I got to the plunge pool and falls it was justified. Once again, the photos speak for themselves...</p>

<p>I wandered around for a while, at the bottom of the cliff, then walked to the top. Not having my swimmers on, and noting the large crocodile warning signs I decided not to swim there, even though many people were.</p>

<p>I had another spot up my sleeve anyway; another plunge pool just further south, with campsites, called Gunlom, which was where I planned to spend the night. I headed there, and indeed it was just as lovely. I even went for a snorkel there to check out the fish, and to see how deep it went (it goes DEEP, but I didn't have the nerve to dive all the way to the bottom under the falls, as the water was really murky and spooky and I'm afraid of Bunyips).</p>

<p>I spent the night there, and it was quite quiet until at one point a convoy of no less than 10 rented camper trucks arrived full of Italians. Turned out that they were the kiddie-owning, early-to-bed type though, so all was well.</p>

<p>I found it highly amusing though. Imagine queuing up for fuel in a convoy like that. How annoying! Plus, those things are expensive to rent - someone must have made them an offer they couldn't refuse (sorry, I couldn't resist).</p>

<p>Anyway I got up at the crack of dawn and climbed up to the top of the falls, and managed to have an awesome swim in an amazingly lovely spot before the crowds got there. It's moments like that, that make it all worthwhile.</p>

<p>"It", by the way, is the annoying stuff, like the heat (it's damn hot up here during the day now), the lack of decent food in the whole of Kakadu (would it kill them to put a stir fry on their overpriced $25 steak and chip menus?), and of course the flies and mozzies. Those last two play tag team - at sunset, the flies that have been driving you insane all day swap with the mozzies. The flies, incidentally, don't seem interested in your food, like the flies I grew up with. Instead, they just want to buzz in your ears and eyes, and generally make you exasperated. I suppose that's fly humour.</p>

<p>So you can all nod sagely and say "well it's not all roses". Then I invite you to look at the pics ;). At the end of the day, it's all worth it.</p>

<p>Anyway, I haven't quite finished my rambling monologue yet. After the morning's lovely billabong swim (one not involving a leaping crocodile, although the pool was quite reminiscent of the one in Croc Dundee), I finally left Kakadu, and drove straight to another NP, Litchfield.</p>

<p>This place too is lovely, albeit a lot smaller. I did most of the main attractions yesterday (it's Friday now, ok, I'm editing! Keep up!); mostly waterfalls, and the cool magnetic termite mounds.</p>

<p>These differ from the other varieties (like the enormous cathedral termite mounds), by being long and thin, and facing along a particular axis, basically N-S. The reason being, the termites like to keep the temperature of the mound fairly constant, so early in the morning the flat face gets all the sun, and during the middle of the day, when the sun is overhead (more or less), a smaller profile is presented, so they get less heat.</p>

<p>I had to be naughty and sneak off the boardwalk to get a good picture of them (the light was in the wrong position!), but I promise I was walking like an elf and bent not a blade of grass.</p>

<p>Today, I visited the last of the gorge waterfalls there, Wangi falls. It was quite lovely, and starting the day with a good swim and snorkel (the water here was less murky too) was sweet. Sitting under a waterfall is actually quite pleasant too, although in the wet season it may well be another story.</p>

<p>That's it from me for now. I've driven back to Darwin, and I'm sitting in my car outside Justine and Harley's place, as they're at work. From here I'll make my way back down to Katherine, then over to the big daddy state of them all - WA. The Kimberley beckons. It's time to get RIGHT off the map.</p>

<p>Oh, once again I've had email woes. In fact, major home computer woes, but we won't discuss those here. So, if you sent me something that bounced this week, please send it again. Also, make sure you use the truffulatree.com.au address, and not the strepto.mine.nu one (in fact, if you have this address in your address book, please delete it). There shouldn't be any more hassles in future.</p>

<p>Pics from this week's extensive crop are:</p>
<!-- 
<ul>
<li><a href="?fileId=IMG_7566.JPG">It's kickin' time!</a></li>
<li><a href="?fileId=IMG_7631.JPG">Humans are ok at this age. It takes a few more years for the rot to set in.</a></li>
<li><a href="?fileId=IMG_7693.JPG">Arnhem land at sunset</a></li>
<li><a href="?fileId=IMG_7752.JPG">Source of relatively clean energy to some, trouble and heartache to others</a></li>
<li><a href="?fileId=IMG_7936.JPG">It's a tough life for some. Just watch the crocs.</a></li>
</ul>
 -->
<table width="800">
	<tr>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=IMG_7566.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7566.JPG' ALT="It's kickin' time!"><BR>It's kickin' time!</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=IMG_7631.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7631.JPG' ALT='Humans are ok at this age. It takes a few more years for the rot to set in.'><BR>Humans are ok at this age. It takes a few more years for the rot to set in.</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=IMG_7693.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7693.JPG' ALT='Arnhem land at sunset'><BR>Arnhem land at sunset</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=IMG_7752.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7752.JPG' ALT='Source of relatively clean energy to some, trouble and heartache to others'><BR>Source of relatively clean energy to some, trouble and heartache to others</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=IMG_7936.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7936.JPG' ALT="It's a tough life for some. Just watch the crocs."><BR>It's a tough life for some. Just watch the crocs.</a>
	</td>
	</tr>
</table>

<br><br>
All images in this gallery:<br>
<table width='800'>
<tr>
</tr>
<tr><td><A ID='IMG_7436.JPG' href='kakadu.php?fileId=IMG_7436.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7436.JPG' ALT='IMG_7436.JPG'><BR>IMG_7436.JPG<br>62.55 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7436.JPG' ALT='IMG_7436.JPG'>IMG_7436.JPG</a></div></td>
<td><A ID='IMG_7437.JPG' href='kakadu.php?fileId=IMG_7437.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7437.JPG' ALT='IMG_7437.JPG'><BR>IMG_7437.JPG<br>85.8 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7437.JPG' ALT='IMG_7437.JPG'>IMG_7437.JPG</a></div></td>
<td><A ID='IMG_7443.JPG' href='kakadu.php?fileId=IMG_7443.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7443.JPG' ALT='IMG_7443.JPG'><BR>IMG_7443.JPG<br>70.08 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7443.JPG' ALT='IMG_7443.JPG'>IMG_7443.JPG</a></div></td>
<td><A ID='IMG_7445.JPG' href='kakadu.php?fileId=IMG_7445.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7445.JPG' ALT='IMG_7445.JPG'><BR>IMG_7445.JPG<br>61.5 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7445.JPG' ALT='IMG_7445.JPG'>IMG_7445.JPG</a></div></td>
<td><A ID='IMG_7455.JPG' href='kakadu.php?fileId=IMG_7455.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7455.JPG' ALT='IMG_7455.JPG'><BR>IMG_7455.JPG<br>122.76 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7455.JPG' ALT='IMG_7455.JPG'>IMG_7455.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_7459.JPG' href='kakadu.php?fileId=IMG_7459.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7459.JPG' ALT='IMG_7459.JPG'><BR>IMG_7459.JPG<br>115.19 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7459.JPG' ALT='IMG_7459.JPG'>IMG_7459.JPG</a></div></td>
<td><A ID='IMG_7460.JPG' href='kakadu.php?fileId=IMG_7460.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7460.JPG' ALT='IMG_7460.JPG'><BR>IMG_7460.JPG<br>82.18 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7460.JPG' ALT='IMG_7460.JPG'>IMG_7460.JPG</a></div></td>
<td><A ID='IMG_7465.JPG' href='kakadu.php?fileId=IMG_7465.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7465.JPG' ALT='IMG_7465.JPG'><BR>IMG_7465.JPG<br>76.95 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7465.JPG' ALT='IMG_7465.JPG'>IMG_7465.JPG</a></div></td>
<td><A ID='IMG_7470.JPG' href='kakadu.php?fileId=IMG_7470.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7470.JPG' ALT='IMG_7470.JPG'><BR>IMG_7470.JPG<br>23.59 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7470.JPG' ALT='IMG_7470.JPG'>IMG_7470.JPG</a></div></td>
<td><A ID='IMG_7473.JPG' href='kakadu.php?fileId=IMG_7473.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7473.JPG' ALT='IMG_7473.JPG'><BR>IMG_7473.JPG<br>58.65 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7473.JPG' ALT='IMG_7473.JPG'>IMG_7473.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_7475.JPG' href='kakadu.php?fileId=IMG_7475.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7475.JPG' ALT='IMG_7475.JPG'><BR>IMG_7475.JPG<br>114.2 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7475.JPG' ALT='IMG_7475.JPG'>IMG_7475.JPG</a></div></td>
<td><A ID='IMG_7477.JPG' href='kakadu.php?fileId=IMG_7477.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7477.JPG' ALT='IMG_7477.JPG'><BR>IMG_7477.JPG<br>77.21 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7477.JPG' ALT='IMG_7477.JPG'>IMG_7477.JPG</a></div></td>
<td><A ID='IMG_7481.JPG' href='kakadu.php?fileId=IMG_7481.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7481.JPG' ALT='IMG_7481.JPG'><BR>IMG_7481.JPG<br>48.29 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7481.JPG' ALT='IMG_7481.JPG'>IMG_7481.JPG</a></div></td>
<td><A ID='IMG_7485.JPG' href='kakadu.php?fileId=IMG_7485.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7485.JPG' ALT='IMG_7485.JPG'><BR>IMG_7485.JPG<br>23.78 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7485.JPG' ALT='IMG_7485.JPG'>IMG_7485.JPG</a></div></td>
<td><A ID='IMG_7498.JPG' href='kakadu.php?fileId=IMG_7498.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7498.JPG' ALT='IMG_7498.JPG'><BR>IMG_7498.JPG<br>94.97 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7498.JPG' ALT='IMG_7498.JPG'>IMG_7498.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_7499.JPG' href='kakadu.php?fileId=IMG_7499.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7499.JPG' ALT='IMG_7499.JPG'><BR>IMG_7499.JPG<br>117.13 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7499.JPG' ALT='IMG_7499.JPG'>IMG_7499.JPG</a></div></td>
<td><A ID='IMG_7500.JPG' href='kakadu.php?fileId=IMG_7500.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7500.JPG' ALT='IMG_7500.JPG'><BR>IMG_7500.JPG<br>146.96 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7500.JPG' ALT='IMG_7500.JPG'>IMG_7500.JPG</a></div></td>
<td><A ID='IMG_7501.JPG' href='kakadu.php?fileId=IMG_7501.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7501.JPG' ALT='IMG_7501.JPG'><BR>IMG_7501.JPG<br>140.54 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7501.JPG' ALT='IMG_7501.JPG'>IMG_7501.JPG</a></div></td>
<td><A ID='IMG_7509.JPG' href='kakadu.php?fileId=IMG_7509.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7509.JPG' ALT='IMG_7509.JPG'><BR>IMG_7509.JPG<br>25.05 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7509.JPG' ALT='IMG_7509.JPG'>IMG_7509.JPG</a></div></td>
<td><A ID='IMG_7521.JPG' href='kakadu.php?fileId=IMG_7521.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7521.JPG' ALT='IMG_7521.JPG'><BR>IMG_7521.JPG<br>21.82 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7521.JPG' ALT='IMG_7521.JPG'>IMG_7521.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_7526.JPG' href='kakadu.php?fileId=IMG_7526.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7526.JPG' ALT='IMG_7526.JPG'><BR>IMG_7526.JPG<br>45.88 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7526.JPG' ALT='IMG_7526.JPG'>IMG_7526.JPG</a></div></td>
<td><A ID='IMG_7537.JPG' href='kakadu.php?fileId=IMG_7537.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7537.JPG' ALT='IMG_7537.JPG'><BR>IMG_7537.JPG<br>77.31 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7537.JPG' ALT='IMG_7537.JPG'>IMG_7537.JPG</a></div></td>
<td><A ID='IMG_7538.JPG' href='kakadu.php?fileId=IMG_7538.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7538.JPG' ALT='IMG_7538.JPG'><BR>IMG_7538.JPG<br>83.54 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7538.JPG' ALT='IMG_7538.JPG'>IMG_7538.JPG</a></div></td>
<td><A ID='IMG_7545.JPG' href='kakadu.php?fileId=IMG_7545.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7545.JPG' ALT='IMG_7545.JPG'><BR>IMG_7545.JPG<br>71.05 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7545.JPG' ALT='IMG_7545.JPG'>IMG_7545.JPG</a></div></td>
<td><A ID='IMG_7549.JPG' href='kakadu.php?fileId=IMG_7549.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7549.JPG' ALT='IMG_7549.JPG'><BR>IMG_7549.JPG<br>63.18 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7549.JPG' ALT='IMG_7549.JPG'>IMG_7549.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_7553.JPG' href='kakadu.php?fileId=IMG_7553.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7553.JPG' ALT='IMG_7553.JPG'><BR>IMG_7553.JPG<br>124.28 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7553.JPG' ALT='IMG_7553.JPG'>IMG_7553.JPG</a></div></td>
<td><A ID='IMG_7554.JPG' href='kakadu.php?fileId=IMG_7554.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7554.JPG' ALT='IMG_7554.JPG'><BR>IMG_7554.JPG<br>68.09 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7554.JPG' ALT='IMG_7554.JPG'>IMG_7554.JPG</a></div></td>
<td><A ID='IMG_7559.JPG' href='kakadu.php?fileId=IMG_7559.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7559.JPG' ALT='IMG_7559.JPG'><BR>IMG_7559.JPG<br>88.24 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7559.JPG' ALT='IMG_7559.JPG'>IMG_7559.JPG</a></div></td>
<td><A ID='IMG_7566.JPG' href='kakadu.php?fileId=IMG_7566.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7566.JPG' ALT='IMG_7566.JPG'><BR>IMG_7566.JPG<br>69.67 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7566.JPG' ALT='IMG_7566.JPG'>IMG_7566.JPG</a></div></td>
<td><A ID='IMG_7569.JPG' href='kakadu.php?fileId=IMG_7569.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7569.JPG' ALT='IMG_7569.JPG'><BR>IMG_7569.JPG<br>108 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7569.JPG' ALT='IMG_7569.JPG'>IMG_7569.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_7571.JPG' href='kakadu.php?fileId=IMG_7571.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7571.JPG' ALT='IMG_7571.JPG'><BR>IMG_7571.JPG<br>82.48 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7571.JPG' ALT='IMG_7571.JPG'>IMG_7571.JPG</a></div></td>
<td><A ID='IMG_7573.JPG' href='kakadu.php?fileId=IMG_7573.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7573.JPG' ALT='IMG_7573.JPG'><BR>IMG_7573.JPG<br>66.64 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7573.JPG' ALT='IMG_7573.JPG'>IMG_7573.JPG</a></div></td>
<td><A ID='IMG_7574.JPG' href='kakadu.php?fileId=IMG_7574.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7574.JPG' ALT='IMG_7574.JPG'><BR>IMG_7574.JPG<br>78.79 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7574.JPG' ALT='IMG_7574.JPG'>IMG_7574.JPG</a></div></td>
<td><A ID='IMG_7575.JPG' href='kakadu.php?fileId=IMG_7575.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7575.JPG' ALT='IMG_7575.JPG'><BR>IMG_7575.JPG<br>67.46 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7575.JPG' ALT='IMG_7575.JPG'>IMG_7575.JPG</a></div></td>
<td><A ID='IMG_7576.JPG' href='kakadu.php?fileId=IMG_7576.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7576.JPG' ALT='IMG_7576.JPG'><BR>IMG_7576.JPG<br>67.38 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7576.JPG' ALT='IMG_7576.JPG'>IMG_7576.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_7577.JPG' href='kakadu.php?fileId=IMG_7577.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7577.JPG' ALT='IMG_7577.JPG'><BR>IMG_7577.JPG<br>80.6 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7577.JPG' ALT='IMG_7577.JPG'>IMG_7577.JPG</a></div></td>
<td><A ID='IMG_7578.JPG' href='kakadu.php?fileId=IMG_7578.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7578.JPG' ALT='IMG_7578.JPG'><BR>IMG_7578.JPG<br>63.58 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7578.JPG' ALT='IMG_7578.JPG'>IMG_7578.JPG</a></div></td>
<td><A ID='IMG_7580.JPG' href='kakadu.php?fileId=IMG_7580.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7580.JPG' ALT='IMG_7580.JPG'><BR>IMG_7580.JPG<br>70.06 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7580.JPG' ALT='IMG_7580.JPG'>IMG_7580.JPG</a></div></td>
<td><A ID='IMG_7582.JPG' href='kakadu.php?fileId=IMG_7582.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7582.JPG' ALT='IMG_7582.JPG'><BR>IMG_7582.JPG<br>87.47 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7582.JPG' ALT='IMG_7582.JPG'>IMG_7582.JPG</a></div></td>
<td><A ID='IMG_7584.JPG' href='kakadu.php?fileId=IMG_7584.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7584.JPG' ALT='IMG_7584.JPG'><BR>IMG_7584.JPG<br>86.57 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7584.JPG' ALT='IMG_7584.JPG'>IMG_7584.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_7585.JPG' href='kakadu.php?fileId=IMG_7585.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7585.JPG' ALT='IMG_7585.JPG'><BR>IMG_7585.JPG<br>50.39 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7585.JPG' ALT='IMG_7585.JPG'>IMG_7585.JPG</a></div></td>
<td><A ID='IMG_7586.JPG' href='kakadu.php?fileId=IMG_7586.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7586.JPG' ALT='IMG_7586.JPG'><BR>IMG_7586.JPG<br>59.14 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7586.JPG' ALT='IMG_7586.JPG'>IMG_7586.JPG</a></div></td>
<td><A ID='IMG_7588.JPG' href='kakadu.php?fileId=IMG_7588.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7588.JPG' ALT='IMG_7588.JPG'><BR>IMG_7588.JPG<br>83.8 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7588.JPG' ALT='IMG_7588.JPG'>IMG_7588.JPG</a></div></td>
<td><A ID='IMG_7597.JPG' href='kakadu.php?fileId=IMG_7597.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7597.JPG' ALT='IMG_7597.JPG'><BR>IMG_7597.JPG<br>118.72 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7597.JPG' ALT='IMG_7597.JPG'>IMG_7597.JPG</a></div></td>
<td><A ID='IMG_7601.JPG' href='kakadu.php?fileId=IMG_7601.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7601.JPG' ALT='IMG_7601.JPG'><BR>IMG_7601.JPG<br>100.75 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7601.JPG' ALT='IMG_7601.JPG'>IMG_7601.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_7608.JPG' href='kakadu.php?fileId=IMG_7608.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7608.JPG' ALT='IMG_7608.JPG'><BR>IMG_7608.JPG<br>68.78 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7608.JPG' ALT='IMG_7608.JPG'>IMG_7608.JPG</a></div></td>
<td><A ID='IMG_7610.JPG' href='kakadu.php?fileId=IMG_7610.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7610.JPG' ALT='IMG_7610.JPG'><BR>IMG_7610.JPG<br>78.48 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7610.JPG' ALT='IMG_7610.JPG'>IMG_7610.JPG</a></div></td>
<td><A ID='IMG_7615.JPG' href='kakadu.php?fileId=IMG_7615.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7615.JPG' ALT='IMG_7615.JPG'><BR>IMG_7615.JPG<br>66.8 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7615.JPG' ALT='IMG_7615.JPG'>IMG_7615.JPG</a></div></td>
<td><A ID='IMG_7616.JPG' href='kakadu.php?fileId=IMG_7616.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7616.JPG' ALT='IMG_7616.JPG'><BR>IMG_7616.JPG<br>74.44 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7616.JPG' ALT='IMG_7616.JPG'>IMG_7616.JPG</a></div></td>
<td><A ID='IMG_7622.JPG' href='kakadu.php?fileId=IMG_7622.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7622.JPG' ALT='IMG_7622.JPG'><BR>IMG_7622.JPG<br>61.93 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7622.JPG' ALT='IMG_7622.JPG'>IMG_7622.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_7624.JPG' href='kakadu.php?fileId=IMG_7624.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7624.JPG' ALT='IMG_7624.JPG'><BR>IMG_7624.JPG<br>95.02 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7624.JPG' ALT='IMG_7624.JPG'>IMG_7624.JPG</a></div></td>
<td><A ID='IMG_7626.JPG' href='kakadu.php?fileId=IMG_7626.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7626.JPG' ALT='IMG_7626.JPG'><BR>IMG_7626.JPG<br>129.31 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7626.JPG' ALT='IMG_7626.JPG'>IMG_7626.JPG</a></div></td>
<td><A ID='IMG_7627.JPG' href='kakadu.php?fileId=IMG_7627.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7627.JPG' ALT='IMG_7627.JPG'><BR>IMG_7627.JPG<br>86.01 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7627.JPG' ALT='IMG_7627.JPG'>IMG_7627.JPG</a></div></td>
<td><A ID='IMG_7628.JPG' href='kakadu.php?fileId=IMG_7628.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7628.JPG' ALT='IMG_7628.JPG'><BR>IMG_7628.JPG<br>93.45 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7628.JPG' ALT='IMG_7628.JPG'>IMG_7628.JPG</a></div></td>
<td><A ID='IMG_7631.JPG' href='kakadu.php?fileId=IMG_7631.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7631.JPG' ALT='IMG_7631.JPG'><BR>IMG_7631.JPG<br>92.88 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7631.JPG' ALT='IMG_7631.JPG'>IMG_7631.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_7632.JPG' href='kakadu.php?fileId=IMG_7632.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7632.JPG' ALT='IMG_7632.JPG'><BR>IMG_7632.JPG<br>68.98 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7632.JPG' ALT='IMG_7632.JPG'>IMG_7632.JPG</a></div></td>
<td><A ID='IMG_7634.JPG' href='kakadu.php?fileId=IMG_7634.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7634.JPG' ALT='IMG_7634.JPG'><BR>IMG_7634.JPG<br>125.01 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7634.JPG' ALT='IMG_7634.JPG'>IMG_7634.JPG</a></div></td>
<td><A ID='IMG_7635.JPG' href='kakadu.php?fileId=IMG_7635.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7635.JPG' ALT='IMG_7635.JPG'><BR>IMG_7635.JPG<br>136.44 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7635.JPG' ALT='IMG_7635.JPG'>IMG_7635.JPG</a></div></td>
<td><A ID='IMG_7639.JPG' href='kakadu.php?fileId=IMG_7639.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7639.JPG' ALT='IMG_7639.JPG'><BR>IMG_7639.JPG<br>78.76 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7639.JPG' ALT='IMG_7639.JPG'>IMG_7639.JPG</a></div></td>
<td><A ID='IMG_7640.JPG' href='kakadu.php?fileId=IMG_7640.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7640.JPG' ALT='IMG_7640.JPG'><BR>IMG_7640.JPG<br>90.19 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7640.JPG' ALT='IMG_7640.JPG'>IMG_7640.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_7641.JPG' href='kakadu.php?fileId=IMG_7641.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7641.JPG' ALT='IMG_7641.JPG'><BR>IMG_7641.JPG<br>111.2 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7641.JPG' ALT='IMG_7641.JPG'>IMG_7641.JPG</a></div></td>
<td><A ID='IMG_7642.JPG' href='kakadu.php?fileId=IMG_7642.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7642.JPG' ALT='IMG_7642.JPG'><BR>IMG_7642.JPG<br>78.71 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7642.JPG' ALT='IMG_7642.JPG'>IMG_7642.JPG</a></div></td>
<td><A ID='IMG_7643.JPG' href='kakadu.php?fileId=IMG_7643.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7643.JPG' ALT='IMG_7643.JPG'><BR>IMG_7643.JPG<br>86.87 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7643.JPG' ALT='IMG_7643.JPG'>IMG_7643.JPG</a></div></td>
<td><A ID='IMG_7645.JPG' href='kakadu.php?fileId=IMG_7645.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7645.JPG' ALT='IMG_7645.JPG'><BR>IMG_7645.JPG<br>98.55 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7645.JPG' ALT='IMG_7645.JPG'>IMG_7645.JPG</a></div></td>
<td><A ID='IMG_7653.JPG' href='kakadu.php?fileId=IMG_7653.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7653.JPG' ALT='IMG_7653.JPG'><BR>IMG_7653.JPG<br>102.75 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7653.JPG' ALT='IMG_7653.JPG'>IMG_7653.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_7654.JPG' href='kakadu.php?fileId=IMG_7654.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7654.JPG' ALT='IMG_7654.JPG'><BR>IMG_7654.JPG<br>100.73 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7654.JPG' ALT='IMG_7654.JPG'>IMG_7654.JPG</a></div></td>
<td><A ID='IMG_7655.JPG' href='kakadu.php?fileId=IMG_7655.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7655.JPG' ALT='IMG_7655.JPG'><BR>IMG_7655.JPG<br>100.37 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7655.JPG' ALT='IMG_7655.JPG'>IMG_7655.JPG</a></div></td>
<td><A ID='IMG_7657.JPG' href='kakadu.php?fileId=IMG_7657.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7657.JPG' ALT='IMG_7657.JPG'><BR>IMG_7657.JPG<br>103.47 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7657.JPG' ALT='IMG_7657.JPG'>IMG_7657.JPG</a></div></td>
<td><A ID='IMG_7660.JPG' href='kakadu.php?fileId=IMG_7660.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7660.JPG' ALT='IMG_7660.JPG'><BR>IMG_7660.JPG<br>120.25 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7660.JPG' ALT='IMG_7660.JPG'>IMG_7660.JPG</a></div></td>
<td><A ID='IMG_7664.JPG' href='kakadu.php?fileId=IMG_7664.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7664.JPG' ALT='IMG_7664.JPG'><BR>IMG_7664.JPG<br>106.41 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7664.JPG' ALT='IMG_7664.JPG'>IMG_7664.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_7665.JPG' href='kakadu.php?fileId=IMG_7665.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7665.JPG' ALT='IMG_7665.JPG'><BR>IMG_7665.JPG<br>69.54 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7665.JPG' ALT='IMG_7665.JPG'>IMG_7665.JPG</a></div></td>
<td><A ID='IMG_7669.JPG' href='kakadu.php?fileId=IMG_7669.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7669.JPG' ALT='IMG_7669.JPG'><BR>IMG_7669.JPG<br>110.82 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7669.JPG' ALT='IMG_7669.JPG'>IMG_7669.JPG</a></div></td>
<td><A ID='IMG_7679.JPG' href='kakadu.php?fileId=IMG_7679.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7679.JPG' ALT='IMG_7679.JPG'><BR>IMG_7679.JPG<br>69.22 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7679.JPG' ALT='IMG_7679.JPG'>IMG_7679.JPG</a></div></td>
<td><A ID='IMG_7683.JPG' href='kakadu.php?fileId=IMG_7683.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7683.JPG' ALT='IMG_7683.JPG'><BR>IMG_7683.JPG<br>83.01 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7683.JPG' ALT='IMG_7683.JPG'>IMG_7683.JPG</a></div></td>
<td><A ID='IMG_7685.JPG' href='kakadu.php?fileId=IMG_7685.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7685.JPG' ALT='IMG_7685.JPG'><BR>IMG_7685.JPG<br>107.84 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7685.JPG' ALT='IMG_7685.JPG'>IMG_7685.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_7687.JPG' href='kakadu.php?fileId=IMG_7687.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7687.JPG' ALT='IMG_7687.JPG'><BR>IMG_7687.JPG<br>62.81 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7687.JPG' ALT='IMG_7687.JPG'>IMG_7687.JPG</a></div></td>
<td><A ID='IMG_7689.JPG' href='kakadu.php?fileId=IMG_7689.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7689.JPG' ALT='IMG_7689.JPG'><BR>IMG_7689.JPG<br>52.61 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7689.JPG' ALT='IMG_7689.JPG'>IMG_7689.JPG</a></div></td>
<td><A ID='IMG_7692.JPG' href='kakadu.php?fileId=IMG_7692.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7692.JPG' ALT='IMG_7692.JPG'><BR>IMG_7692.JPG<br>51.91 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7692.JPG' ALT='IMG_7692.JPG'>IMG_7692.JPG</a></div></td>
<td><A ID='IMG_7693.JPG' href='kakadu.php?fileId=IMG_7693.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7693.JPG' ALT='IMG_7693.JPG'><BR>IMG_7693.JPG<br>57.71 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7693.JPG' ALT='IMG_7693.JPG'>IMG_7693.JPG</a></div></td>
<td><A ID='IMG_7715.JPG' href='kakadu.php?fileId=IMG_7715.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7715.JPG' ALT='IMG_7715.JPG'><BR>IMG_7715.JPG<br>96.32 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7715.JPG' ALT='IMG_7715.JPG'>IMG_7715.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_7734.JPG' href='kakadu.php?fileId=IMG_7734.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7734.JPG' ALT='IMG_7734.JPG'><BR>IMG_7734.JPG<br>63.39 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7734.JPG' ALT='IMG_7734.JPG'>IMG_7734.JPG</a></div></td>
<td><A ID='IMG_7740.JPG' href='kakadu.php?fileId=IMG_7740.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7740.JPG' ALT='IMG_7740.JPG'><BR>IMG_7740.JPG<br>70.6 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7740.JPG' ALT='IMG_7740.JPG'>IMG_7740.JPG</a></div></td>
<td><A ID='IMG_7747.JPG' href='kakadu.php?fileId=IMG_7747.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7747.JPG' ALT='IMG_7747.JPG'><BR>IMG_7747.JPG<br>76.15 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7747.JPG' ALT='IMG_7747.JPG'>IMG_7747.JPG</a></div></td>
<td><A ID='IMG_7749.JPG' href='kakadu.php?fileId=IMG_7749.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7749.JPG' ALT='IMG_7749.JPG'><BR>IMG_7749.JPG<br>83.67 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7749.JPG' ALT='IMG_7749.JPG'>IMG_7749.JPG</a></div></td>
<td><A ID='IMG_7751.JPG' href='kakadu.php?fileId=IMG_7751.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7751.JPG' ALT='IMG_7751.JPG'><BR>IMG_7751.JPG<br>106.61 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7751.JPG' ALT='IMG_7751.JPG'>IMG_7751.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_7752.JPG' href='kakadu.php?fileId=IMG_7752.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7752.JPG' ALT='IMG_7752.JPG'><BR>IMG_7752.JPG<br>67.29 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7752.JPG' ALT='IMG_7752.JPG'>IMG_7752.JPG</a></div></td>
<td><A ID='IMG_7756.JPG' href='kakadu.php?fileId=IMG_7756.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7756.JPG' ALT='IMG_7756.JPG'><BR>IMG_7756.JPG<br>86.88 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7756.JPG' ALT='IMG_7756.JPG'>IMG_7756.JPG</a></div></td>
<td><A ID='IMG_7757.JPG' href='kakadu.php?fileId=IMG_7757.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7757.JPG' ALT='IMG_7757.JPG'><BR>IMG_7757.JPG<br>69.53 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7757.JPG' ALT='IMG_7757.JPG'>IMG_7757.JPG</a></div></td>
<td><A ID='IMG_7759.JPG' href='kakadu.php?fileId=IMG_7759.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7759.JPG' ALT='IMG_7759.JPG'><BR>IMG_7759.JPG<br>65.74 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7759.JPG' ALT='IMG_7759.JPG'>IMG_7759.JPG</a></div></td>
<td><A ID='IMG_7760.JPG' href='kakadu.php?fileId=IMG_7760.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7760.JPG' ALT='IMG_7760.JPG'><BR>IMG_7760.JPG<br>62.77 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7760.JPG' ALT='IMG_7760.JPG'>IMG_7760.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_7761.JPG' href='kakadu.php?fileId=IMG_7761.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7761.JPG' ALT='IMG_7761.JPG'><BR>IMG_7761.JPG<br>55.71 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7761.JPG' ALT='IMG_7761.JPG'>IMG_7761.JPG</a></div></td>
<td><A ID='IMG_7763.JPG' href='kakadu.php?fileId=IMG_7763.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7763.JPG' ALT='IMG_7763.JPG'><BR>IMG_7763.JPG<br>54.02 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7763.JPG' ALT='IMG_7763.JPG'>IMG_7763.JPG</a></div></td>
<td><A ID='IMG_7764.JPG' href='kakadu.php?fileId=IMG_7764.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7764.JPG' ALT='IMG_7764.JPG'><BR>IMG_7764.JPG<br>49.51 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7764.JPG' ALT='IMG_7764.JPG'>IMG_7764.JPG</a></div></td>
<td><A ID='IMG_7765.JPG' href='kakadu.php?fileId=IMG_7765.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7765.JPG' ALT='IMG_7765.JPG'><BR>IMG_7765.JPG<br>29.68 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7765.JPG' ALT='IMG_7765.JPG'>IMG_7765.JPG</a></div></td>
<td><A ID='IMG_7766.JPG' href='kakadu.php?fileId=IMG_7766.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7766.JPG' ALT='IMG_7766.JPG'><BR>IMG_7766.JPG<br>50.34 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7766.JPG' ALT='IMG_7766.JPG'>IMG_7766.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_7767.JPG' href='kakadu.php?fileId=IMG_7767.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7767.JPG' ALT='IMG_7767.JPG'><BR>IMG_7767.JPG<br>48.35 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7767.JPG' ALT='IMG_7767.JPG'>IMG_7767.JPG</a></div></td>
<td><A ID='IMG_7770.JPG' href='kakadu.php?fileId=IMG_7770.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7770.JPG' ALT='IMG_7770.JPG'><BR>IMG_7770.JPG<br>68.87 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7770.JPG' ALT='IMG_7770.JPG'>IMG_7770.JPG</a></div></td>
<td><A ID='IMG_7771.JPG' href='kakadu.php?fileId=IMG_7771.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7771.JPG' ALT='IMG_7771.JPG'><BR>IMG_7771.JPG<br>96.96 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7771.JPG' ALT='IMG_7771.JPG'>IMG_7771.JPG</a></div></td>
<td><A ID='IMG_7773.JPG' href='kakadu.php?fileId=IMG_7773.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7773.JPG' ALT='IMG_7773.JPG'><BR>IMG_7773.JPG<br>102.66 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7773.JPG' ALT='IMG_7773.JPG'>IMG_7773.JPG</a></div></td>
<td><A ID='IMG_7774.JPG' href='kakadu.php?fileId=IMG_7774.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7774.JPG' ALT='IMG_7774.JPG'><BR>IMG_7774.JPG<br>96.76 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7774.JPG' ALT='IMG_7774.JPG'>IMG_7774.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_7776.JPG' href='kakadu.php?fileId=IMG_7776.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7776.JPG' ALT='IMG_7776.JPG'><BR>IMG_7776.JPG<br>81.15 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7776.JPG' ALT='IMG_7776.JPG'>IMG_7776.JPG</a></div></td>
<td><A ID='IMG_7777.JPG' href='kakadu.php?fileId=IMG_7777.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7777.JPG' ALT='IMG_7777.JPG'><BR>IMG_7777.JPG<br>70.42 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7777.JPG' ALT='IMG_7777.JPG'>IMG_7777.JPG</a></div></td>
<td><A ID='IMG_7780.JPG' href='kakadu.php?fileId=IMG_7780.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7780.JPG' ALT='IMG_7780.JPG'><BR>IMG_7780.JPG<br>107.87 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7780.JPG' ALT='IMG_7780.JPG'>IMG_7780.JPG</a></div></td>
<td><A ID='IMG_7781.JPG' href='kakadu.php?fileId=IMG_7781.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7781.JPG' ALT='IMG_7781.JPG'><BR>IMG_7781.JPG<br>70.38 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7781.JPG' ALT='IMG_7781.JPG'>IMG_7781.JPG</a></div></td>
<td><A ID='IMG_7787.JPG' href='kakadu.php?fileId=IMG_7787.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7787.JPG' ALT='IMG_7787.JPG'><BR>IMG_7787.JPG<br>85.56 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7787.JPG' ALT='IMG_7787.JPG'>IMG_7787.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_7789.JPG' href='kakadu.php?fileId=IMG_7789.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7789.JPG' ALT='IMG_7789.JPG'><BR>IMG_7789.JPG<br>98.2 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7789.JPG' ALT='IMG_7789.JPG'>IMG_7789.JPG</a></div></td>
<td><A ID='IMG_7793.JPG' href='kakadu.php?fileId=IMG_7793.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7793.JPG' ALT='IMG_7793.JPG'><BR>IMG_7793.JPG<br>70.39 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7793.JPG' ALT='IMG_7793.JPG'>IMG_7793.JPG</a></div></td>
<td><A ID='IMG_7794.JPG' href='kakadu.php?fileId=IMG_7794.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7794.JPG' ALT='IMG_7794.JPG'><BR>IMG_7794.JPG<br>74.88 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7794.JPG' ALT='IMG_7794.JPG'>IMG_7794.JPG</a></div></td>
<td><A ID='IMG_7795.JPG' href='kakadu.php?fileId=IMG_7795.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7795.JPG' ALT='IMG_7795.JPG'><BR>IMG_7795.JPG<br>94.27 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7795.JPG' ALT='IMG_7795.JPG'>IMG_7795.JPG</a></div></td>
<td><A ID='IMG_7797.JPG' href='kakadu.php?fileId=IMG_7797.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7797.JPG' ALT='IMG_7797.JPG'><BR>IMG_7797.JPG<br>70.35 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7797.JPG' ALT='IMG_7797.JPG'>IMG_7797.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_7798.JPG' href='kakadu.php?fileId=IMG_7798.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7798.JPG' ALT='IMG_7798.JPG'><BR>IMG_7798.JPG<br>70.68 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7798.JPG' ALT='IMG_7798.JPG'>IMG_7798.JPG</a></div></td>
<td><A ID='IMG_7802.JPG' href='kakadu.php?fileId=IMG_7802.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7802.JPG' ALT='IMG_7802.JPG'><BR>IMG_7802.JPG<br>65.1 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7802.JPG' ALT='IMG_7802.JPG'>IMG_7802.JPG</a></div></td>
<td><A ID='IMG_7806.JPG' href='kakadu.php?fileId=IMG_7806.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7806.JPG' ALT='IMG_7806.JPG'><BR>IMG_7806.JPG<br>95.86 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7806.JPG' ALT='IMG_7806.JPG'>IMG_7806.JPG</a></div></td>
<td><A ID='IMG_7807.JPG' href='kakadu.php?fileId=IMG_7807.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7807.JPG' ALT='IMG_7807.JPG'><BR>IMG_7807.JPG<br>62.27 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7807.JPG' ALT='IMG_7807.JPG'>IMG_7807.JPG</a></div></td>
<td><A ID='IMG_7816.JPG' href='kakadu.php?fileId=IMG_7816.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7816.JPG' ALT='IMG_7816.JPG'><BR>IMG_7816.JPG<br>103.89 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7816.JPG' ALT='IMG_7816.JPG'>IMG_7816.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_7817.JPG' href='kakadu.php?fileId=IMG_7817.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7817.JPG' ALT='IMG_7817.JPG'><BR>IMG_7817.JPG<br>112.19 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7817.JPG' ALT='IMG_7817.JPG'>IMG_7817.JPG</a></div></td>
<td><A ID='IMG_7819.JPG' href='kakadu.php?fileId=IMG_7819.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7819.JPG' ALT='IMG_7819.JPG'><BR>IMG_7819.JPG<br>69.59 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7819.JPG' ALT='IMG_7819.JPG'>IMG_7819.JPG</a></div></td>
<td><A ID='IMG_7821.JPG' href='kakadu.php?fileId=IMG_7821.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7821.JPG' ALT='IMG_7821.JPG'><BR>IMG_7821.JPG<br>111.19 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7821.JPG' ALT='IMG_7821.JPG'>IMG_7821.JPG</a></div></td>
<td><A ID='IMG_7822.JPG' href='kakadu.php?fileId=IMG_7822.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7822.JPG' ALT='IMG_7822.JPG'><BR>IMG_7822.JPG<br>90.35 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7822.JPG' ALT='IMG_7822.JPG'>IMG_7822.JPG</a></div></td>
<td><A ID='IMG_7823.JPG' href='kakadu.php?fileId=IMG_7823.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7823.JPG' ALT='IMG_7823.JPG'><BR>IMG_7823.JPG<br>108.21 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7823.JPG' ALT='IMG_7823.JPG'>IMG_7823.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_7827.JPG' href='kakadu.php?fileId=IMG_7827.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7827.JPG' ALT='IMG_7827.JPG'><BR>IMG_7827.JPG<br>97.95 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7827.JPG' ALT='IMG_7827.JPG'>IMG_7827.JPG</a></div></td>
<td><A ID='IMG_7828.JPG' href='kakadu.php?fileId=IMG_7828.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7828.JPG' ALT='IMG_7828.JPG'><BR>IMG_7828.JPG<br>101.63 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7828.JPG' ALT='IMG_7828.JPG'>IMG_7828.JPG</a></div></td>
<td><A ID='IMG_7829.JPG' href='kakadu.php?fileId=IMG_7829.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7829.JPG' ALT='IMG_7829.JPG'><BR>IMG_7829.JPG<br>84.15 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7829.JPG' ALT='IMG_7829.JPG'>IMG_7829.JPG</a></div></td>
<td><A ID='IMG_7832.JPG' href='kakadu.php?fileId=IMG_7832.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7832.JPG' ALT='IMG_7832.JPG'><BR>IMG_7832.JPG<br>97.26 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7832.JPG' ALT='IMG_7832.JPG'>IMG_7832.JPG</a></div></td>
<td><A ID='IMG_7833.JPG' href='kakadu.php?fileId=IMG_7833.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7833.JPG' ALT='IMG_7833.JPG'><BR>IMG_7833.JPG<br>94.92 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7833.JPG' ALT='IMG_7833.JPG'>IMG_7833.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_7834.JPG' href='kakadu.php?fileId=IMG_7834.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7834.JPG' ALT='IMG_7834.JPG'><BR>IMG_7834.JPG<br>102.83 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7834.JPG' ALT='IMG_7834.JPG'>IMG_7834.JPG</a></div></td>
<td><A ID='IMG_7835.JPG' href='kakadu.php?fileId=IMG_7835.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7835.JPG' ALT='IMG_7835.JPG'><BR>IMG_7835.JPG<br>118.88 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7835.JPG' ALT='IMG_7835.JPG'>IMG_7835.JPG</a></div></td>
<td><A ID='IMG_7862.JPG' href='kakadu.php?fileId=IMG_7862.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7862.JPG' ALT='IMG_7862.JPG'><BR>IMG_7862.JPG<br>44.39 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7862.JPG' ALT='IMG_7862.JPG'>IMG_7862.JPG</a></div></td>
<td><A ID='IMG_7863.JPG' href='kakadu.php?fileId=IMG_7863.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7863.JPG' ALT='IMG_7863.JPG'><BR>IMG_7863.JPG<br>99.26 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7863.JPG' ALT='IMG_7863.JPG'>IMG_7863.JPG</a></div></td>
<td><A ID='IMG_7886.JPG' href='kakadu.php?fileId=IMG_7886.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7886.JPG' ALT='IMG_7886.JPG'><BR>IMG_7886.JPG<br>82.55 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7886.JPG' ALT='IMG_7886.JPG'>IMG_7886.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_7903.JPG' href='kakadu.php?fileId=IMG_7903.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7903.JPG' ALT='IMG_7903.JPG'><BR>IMG_7903.JPG<br>63.62 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7903.JPG' ALT='IMG_7903.JPG'>IMG_7903.JPG</a></div></td>
<td><A ID='IMG_7904.JPG' href='kakadu.php?fileId=IMG_7904.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7904.JPG' ALT='IMG_7904.JPG'><BR>IMG_7904.JPG<br>44.13 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7904.JPG' ALT='IMG_7904.JPG'>IMG_7904.JPG</a></div></td>
<td><A ID='IMG_7909.JPG' href='kakadu.php?fileId=IMG_7909.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7909.JPG' ALT='IMG_7909.JPG'><BR>IMG_7909.JPG<br>68.82 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7909.JPG' ALT='IMG_7909.JPG'>IMG_7909.JPG</a></div></td>
<td><A ID='IMG_7916.JPG' href='kakadu.php?fileId=IMG_7916.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7916.JPG' ALT='IMG_7916.JPG'><BR>IMG_7916.JPG<br>71.12 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7916.JPG' ALT='IMG_7916.JPG'>IMG_7916.JPG</a></div></td>
<td><A ID='IMG_7918.JPG' href='kakadu.php?fileId=IMG_7918.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7918.JPG' ALT='IMG_7918.JPG'><BR>IMG_7918.JPG<br>158.23 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7918.JPG' ALT='IMG_7918.JPG'>IMG_7918.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_7920.JPG' href='kakadu.php?fileId=IMG_7920.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7920.JPG' ALT='IMG_7920.JPG'><BR>IMG_7920.JPG<br>128.57 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7920.JPG' ALT='IMG_7920.JPG'>IMG_7920.JPG</a></div></td>
<td><A ID='IMG_7932.JPG' href='kakadu.php?fileId=IMG_7932.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7932.JPG' ALT='IMG_7932.JPG'><BR>IMG_7932.JPG<br>87.51 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7932.JPG' ALT='IMG_7932.JPG'>IMG_7932.JPG</a></div></td>
<td><A ID='IMG_7934.JPG' href='kakadu.php?fileId=IMG_7934.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7934.JPG' ALT='IMG_7934.JPG'><BR>IMG_7934.JPG<br>114.22 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7934.JPG' ALT='IMG_7934.JPG'>IMG_7934.JPG</a></div></td>
<td><A ID='IMG_7936.JPG' href='kakadu.php?fileId=IMG_7936.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7936.JPG' ALT='IMG_7936.JPG'><BR>IMG_7936.JPG<br>76.81 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7936.JPG' ALT='IMG_7936.JPG'>IMG_7936.JPG</a></div></td>
<td><A ID='IMG_7938.JPG' href='kakadu.php?fileId=IMG_7938.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7938.JPG' ALT='IMG_7938.JPG'><BR>IMG_7938.JPG<br>80.19 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7938.JPG' ALT='IMG_7938.JPG'>IMG_7938.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_7939.JPG' href='kakadu.php?fileId=IMG_7939.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7939.JPG' ALT='IMG_7939.JPG'><BR>IMG_7939.JPG<br>94.6 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7939.JPG' ALT='IMG_7939.JPG'>IMG_7939.JPG</a></div></td>
<td><A ID='IMG_7944.JPG' href='kakadu.php?fileId=IMG_7944.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7944.JPG' ALT='IMG_7944.JPG'><BR>IMG_7944.JPG<br>86.86 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7944.JPG' ALT='IMG_7944.JPG'>IMG_7944.JPG</a></div></td>
<td><A ID='IMG_7946.JPG' href='kakadu.php?fileId=IMG_7946.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7946.JPG' ALT='IMG_7946.JPG'><BR>IMG_7946.JPG<br>93.72 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7946.JPG' ALT='IMG_7946.JPG'>IMG_7946.JPG</a></div></td>
<td><A ID='IMG_7955.JPG' href='kakadu.php?fileId=IMG_7955.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7955.JPG' ALT='IMG_7955.JPG'><BR>IMG_7955.JPG<br>107.23 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7955.JPG' ALT='IMG_7955.JPG'>IMG_7955.JPG</a></div></td>
<td><A ID='IMG_7956.JPG' href='kakadu.php?fileId=IMG_7956.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7956.JPG' ALT='IMG_7956.JPG'><BR>IMG_7956.JPG<br>101.36 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7956.JPG' ALT='IMG_7956.JPG'>IMG_7956.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_7961.JPG' href='kakadu.php?fileId=IMG_7961.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7961.JPG' ALT='IMG_7961.JPG'><BR>IMG_7961.JPG<br>111.2 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7961.JPG' ALT='IMG_7961.JPG'>IMG_7961.JPG</a></div></td>
<td><A ID='IMG_7962.JPG' href='kakadu.php?fileId=IMG_7962.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7962.JPG' ALT='IMG_7962.JPG'><BR>IMG_7962.JPG<br>81.66 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7962.JPG' ALT='IMG_7962.JPG'>IMG_7962.JPG</a></div></td>
<td><A ID='IMG_7966.JPG' href='kakadu.php?fileId=IMG_7966.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7966.JPG' ALT='IMG_7966.JPG'><BR>IMG_7966.JPG<br>92.7 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7966.JPG' ALT='IMG_7966.JPG'>IMG_7966.JPG</a></div></td>
<td><A ID='IMG_7971.JPG' href='kakadu.php?fileId=IMG_7971.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7971.JPG' ALT='IMG_7971.JPG'><BR>IMG_7971.JPG<br>117.69 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7971.JPG' ALT='IMG_7971.JPG'>IMG_7971.JPG</a></div></td>
<td><A ID='IMG_7974.JPG' href='kakadu.php?fileId=IMG_7974.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7974.JPG' ALT='IMG_7974.JPG'><BR>IMG_7974.JPG<br>108.22 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7974.JPG' ALT='IMG_7974.JPG'>IMG_7974.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_7975.JPG' href='kakadu.php?fileId=IMG_7975.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7975.JPG' ALT='IMG_7975.JPG'><BR>IMG_7975.JPG<br>101.44 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7975.JPG' ALT='IMG_7975.JPG'>IMG_7975.JPG</a></div></td>
<td><A ID='IMG_7976.JPG' href='kakadu.php?fileId=IMG_7976.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7976.JPG' ALT='IMG_7976.JPG'><BR>IMG_7976.JPG<br>83.01 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7976.JPG' ALT='IMG_7976.JPG'>IMG_7976.JPG</a></div></td>
<td><A ID='IMG_7979.JPG' href='kakadu.php?fileId=IMG_7979.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7979.JPG' ALT='IMG_7979.JPG'><BR>IMG_7979.JPG<br>127.39 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7979.JPG' ALT='IMG_7979.JPG'>IMG_7979.JPG</a></div></td>
<td><A ID='IMG_7984.JPG' href='kakadu.php?fileId=IMG_7984.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7984.JPG' ALT='IMG_7984.JPG'><BR>IMG_7984.JPG<br>82.18 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7984.JPG' ALT='IMG_7984.JPG'>IMG_7984.JPG</a></div></td>
<td><A ID='IMG_7987.JPG' href='kakadu.php?fileId=IMG_7987.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7987.JPG' ALT='IMG_7987.JPG'><BR>IMG_7987.JPG<br>109.66 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7987.JPG' ALT='IMG_7987.JPG'>IMG_7987.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_7990.JPG' href='kakadu.php?fileId=IMG_7990.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7990.JPG' ALT='IMG_7990.JPG'><BR>IMG_7990.JPG<br>105.12 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7990.JPG' ALT='IMG_7990.JPG'>IMG_7990.JPG</a></div></td>
<td><A ID='IMG_7991.JPG' href='kakadu.php?fileId=IMG_7991.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7991.JPG' ALT='IMG_7991.JPG'><BR>IMG_7991.JPG<br>69 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7991.JPG' ALT='IMG_7991.JPG'>IMG_7991.JPG</a></div></td>
<td><A ID='IMG_7992.JPG' href='kakadu.php?fileId=IMG_7992.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7992.JPG' ALT='IMG_7992.JPG'><BR>IMG_7992.JPG<br>100.43 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7992.JPG' ALT='IMG_7992.JPG'>IMG_7992.JPG</a></div></td>
<td><A ID='IMG_7994.JPG' href='kakadu.php?fileId=IMG_7994.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7994.JPG' ALT='IMG_7994.JPG'><BR>IMG_7994.JPG<br>85.66 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7994.JPG' ALT='IMG_7994.JPG'>IMG_7994.JPG</a></div></td>
<td><A ID='IMG_7995.JPG' href='kakadu.php?fileId=IMG_7995.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7995.JPG' ALT='IMG_7995.JPG'><BR>IMG_7995.JPG<br>87.2 KB</a><div class='inv'><br><a href='./images/20050826/IMG_7995.JPG' ALT='IMG_7995.JPG'>IMG_7995.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_8001.JPG' href='kakadu.php?fileId=IMG_8001.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_8001.JPG' ALT='IMG_8001.JPG'><BR>IMG_8001.JPG<br>57.14 KB</a><div class='inv'><br><a href='./images/20050826/IMG_8001.JPG' ALT='IMG_8001.JPG'>IMG_8001.JPG</a></div></td>
<td><A ID='IMG_8003.JPG' href='kakadu.php?fileId=IMG_8003.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_8003.JPG' ALT='IMG_8003.JPG'><BR>IMG_8003.JPG<br>100.85 KB</a><div class='inv'><br><a href='./images/20050826/IMG_8003.JPG' ALT='IMG_8003.JPG'>IMG_8003.JPG</a></div></td>
<td><A ID='IMG_8007.JPG' href='kakadu.php?fileId=IMG_8007.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_8007.JPG' ALT='IMG_8007.JPG'><BR>IMG_8007.JPG<br>110.34 KB</a><div class='inv'><br><a href='./images/20050826/IMG_8007.JPG' ALT='IMG_8007.JPG'>IMG_8007.JPG</a></div></td>
<td><A ID='IMG_8008.JPG' href='kakadu.php?fileId=IMG_8008.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_8008.JPG' ALT='IMG_8008.JPG'><BR>IMG_8008.JPG<br>117.86 KB</a><div class='inv'><br><a href='./images/20050826/IMG_8008.JPG' ALT='IMG_8008.JPG'>IMG_8008.JPG</a></div></td>
<td><A ID='IMG_8009.JPG' href='kakadu.php?fileId=IMG_8009.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_8009.JPG' ALT='IMG_8009.JPG'><BR>IMG_8009.JPG<br>120.1 KB</a><div class='inv'><br><a href='./images/20050826/IMG_8009.JPG' ALT='IMG_8009.JPG'>IMG_8009.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_8013.JPG' href='kakadu.php?fileId=IMG_8013.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_8013.JPG' ALT='IMG_8013.JPG'><BR>IMG_8013.JPG<br>102.72 KB</a><div class='inv'><br><a href='./images/20050826/IMG_8013.JPG' ALT='IMG_8013.JPG'>IMG_8013.JPG</a></div></td>
<td><A ID='IMG_8016.JPG' href='kakadu.php?fileId=IMG_8016.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_8016.JPG' ALT='IMG_8016.JPG'><BR>IMG_8016.JPG<br>101.97 KB</a><div class='inv'><br><a href='./images/20050826/IMG_8016.JPG' ALT='IMG_8016.JPG'>IMG_8016.JPG</a></div></td>
<td><A ID='IMG_8019.JPG' href='kakadu.php?fileId=IMG_8019.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_8019.JPG' ALT='IMG_8019.JPG'><BR>IMG_8019.JPG<br>66 KB</a><div class='inv'><br><a href='./images/20050826/IMG_8019.JPG' ALT='IMG_8019.JPG'>IMG_8019.JPG</a></div></td>
<td><A ID='IMG_8021.JPG' href='kakadu.php?fileId=IMG_8021.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_8021.JPG' ALT='IMG_8021.JPG'><BR>IMG_8021.JPG<br>80.09 KB</a><div class='inv'><br><a href='./images/20050826/IMG_8021.JPG' ALT='IMG_8021.JPG'>IMG_8021.JPG</a></div></td>
<td><A ID='IMG_8023.JPG' href='kakadu.php?fileId=IMG_8023.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_8023.JPG' ALT='IMG_8023.JPG'><BR>IMG_8023.JPG<br>67.53 KB</a><div class='inv'><br><a href='./images/20050826/IMG_8023.JPG' ALT='IMG_8023.JPG'>IMG_8023.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_8024.JPG' href='kakadu.php?fileId=IMG_8024.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_8024.JPG' ALT='IMG_8024.JPG'><BR>IMG_8024.JPG<br>123.13 KB</a><div class='inv'><br><a href='./images/20050826/IMG_8024.JPG' ALT='IMG_8024.JPG'>IMG_8024.JPG</a></div></td>
<td><A ID='IMG_8028.JPG' href='kakadu.php?fileId=IMG_8028.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_8028.JPG' ALT='IMG_8028.JPG'><BR>IMG_8028.JPG<br>65.34 KB</a><div class='inv'><br><a href='./images/20050826/IMG_8028.JPG' ALT='IMG_8028.JPG'>IMG_8028.JPG</a></div></td>
<td><A ID='IMG_8031.JPG' href='kakadu.php?fileId=IMG_8031.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_8031.JPG' ALT='IMG_8031.JPG'><BR>IMG_8031.JPG<br>71.58 KB</a><div class='inv'><br><a href='./images/20050826/IMG_8031.JPG' ALT='IMG_8031.JPG'>IMG_8031.JPG</a></div></td>
<td><A ID='IMG_8032.JPG' href='kakadu.php?fileId=IMG_8032.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_8032.JPG' ALT='IMG_8032.JPG'><BR>IMG_8032.JPG<br>65.38 KB</a><div class='inv'><br><a href='./images/20050826/IMG_8032.JPG' ALT='IMG_8032.JPG'>IMG_8032.JPG</a></div></td>
<td><A ID='IMG_8033.JPG' href='kakadu.php?fileId=IMG_8033.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_8033.JPG' ALT='IMG_8033.JPG'><BR>IMG_8033.JPG<br>89.83 KB</a><div class='inv'><br><a href='./images/20050826/IMG_8033.JPG' ALT='IMG_8033.JPG'>IMG_8033.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_8034.JPG' href='kakadu.php?fileId=IMG_8034.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_8034.JPG' ALT='IMG_8034.JPG'><BR>IMG_8034.JPG<br>94.96 KB</a><div class='inv'><br><a href='./images/20050826/IMG_8034.JPG' ALT='IMG_8034.JPG'>IMG_8034.JPG</a></div></td>
<td><A ID='IMG_8035.JPG' href='kakadu.php?fileId=IMG_8035.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_8035.JPG' ALT='IMG_8035.JPG'><BR>IMG_8035.JPG<br>81.49 KB</a><div class='inv'><br><a href='./images/20050826/IMG_8035.JPG' ALT='IMG_8035.JPG'>IMG_8035.JPG</a></div></td>
<td><A ID='IMG_8038.JPG' href='kakadu.php?fileId=IMG_8038.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_8038.JPG' ALT='IMG_8038.JPG'><BR>IMG_8038.JPG<br>72.29 KB</a><div class='inv'><br><a href='./images/20050826/IMG_8038.JPG' ALT='IMG_8038.JPG'>IMG_8038.JPG</a></div></td>
<td><A ID='IMG_8039.JPG' href='kakadu.php?fileId=IMG_8039.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_8039.JPG' ALT='IMG_8039.JPG'><BR>IMG_8039.JPG<br>73.1 KB</a><div class='inv'><br><a href='./images/20050826/IMG_8039.JPG' ALT='IMG_8039.JPG'>IMG_8039.JPG</a></div></td>
<td><A ID='IMG_8040.JPG' href='kakadu.php?fileId=IMG_8040.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_8040.JPG' ALT='IMG_8040.JPG'><BR>IMG_8040.JPG<br>97.05 KB</a><div class='inv'><br><a href='./images/20050826/IMG_8040.JPG' ALT='IMG_8040.JPG'>IMG_8040.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_8041.JPG' href='kakadu.php?fileId=IMG_8041.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_8041.JPG' ALT='IMG_8041.JPG'><BR>IMG_8041.JPG<br>92.27 KB</a><div class='inv'><br><a href='./images/20050826/IMG_8041.JPG' ALT='IMG_8041.JPG'>IMG_8041.JPG</a></div></td>
<td><A ID='IMG_8042.JPG' href='kakadu.php?fileId=IMG_8042.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_8042.JPG' ALT='IMG_8042.JPG'><BR>IMG_8042.JPG<br>101.77 KB</a><div class='inv'><br><a href='./images/20050826/IMG_8042.JPG' ALT='IMG_8042.JPG'>IMG_8042.JPG</a></div></td>
<td><A ID='IMG_8044.JPG' href='kakadu.php?fileId=IMG_8044.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_8044.JPG' ALT='IMG_8044.JPG'><BR>IMG_8044.JPG<br>98.83 KB</a><div class='inv'><br><a href='./images/20050826/IMG_8044.JPG' ALT='IMG_8044.JPG'>IMG_8044.JPG</a></div></td>
<td><A ID='IMG_8045.JPG' href='kakadu.php?fileId=IMG_8045.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_8045.JPG' ALT='IMG_8045.JPG'><BR>IMG_8045.JPG<br>104.27 KB</a><div class='inv'><br><a href='./images/20050826/IMG_8045.JPG' ALT='IMG_8045.JPG'>IMG_8045.JPG</a></div></td>
<td><A ID='IMG_8048.JPG' href='kakadu.php?fileId=IMG_8048.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_8048.JPG' ALT='IMG_8048.JPG'><BR>IMG_8048.JPG<br>97.91 KB</a><div class='inv'><br><a href='./images/20050826/IMG_8048.JPG' ALT='IMG_8048.JPG'>IMG_8048.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_8057.JPG' href='kakadu.php?fileId=IMG_8057.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_8057.JPG' ALT='IMG_8057.JPG'><BR>IMG_8057.JPG<br>158.18 KB</a><div class='inv'><br><a href='./images/20050826/IMG_8057.JPG' ALT='IMG_8057.JPG'>IMG_8057.JPG</a></div></td>
<td><A ID='IMG_8058.JPG' href='kakadu.php?fileId=IMG_8058.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_8058.JPG' ALT='IMG_8058.JPG'><BR>IMG_8058.JPG<br>95.7 KB</a><div class='inv'><br><a href='./images/20050826/IMG_8058.JPG' ALT='IMG_8058.JPG'>IMG_8058.JPG</a></div></td>
<td><A ID='IMG_8061.JPG' href='kakadu.php?fileId=IMG_8061.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_8061.JPG' ALT='IMG_8061.JPG'><BR>IMG_8061.JPG<br>49.72 KB</a><div class='inv'><br><a href='./images/20050826/IMG_8061.JPG' ALT='IMG_8061.JPG'>IMG_8061.JPG</a></div></td>
<td><A ID='IMG_8063.JPG' href='kakadu.php?fileId=IMG_8063.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_8063.JPG' ALT='IMG_8063.JPG'><BR>IMG_8063.JPG<br>84.68 KB</a><div class='inv'><br><a href='./images/20050826/IMG_8063.JPG' ALT='IMG_8063.JPG'>IMG_8063.JPG</a></div></td>
</tr>
</table>	</div>
</div>
</body>
</html>