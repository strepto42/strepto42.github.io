<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - March 2005 - Q&A letters</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="Q&A letters">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="Q&A letters" href='masterit200501.php'>January 2005</a></li>
<li><a title="Q&A letters" href='masterit200502.php'>February 2005</a></li>
<li><div class='activemenu'>March 2005</div></li>
<li><a title="Q&A letters" href='masterit200504.php'>April 2005</a></li>
<li><a title="Q&A letters" href='masterit200505.php'>May 2005</a></li>
<li><a title="Q&A letters" href='masterit200506.php'>June 2005</a></li>
<li><a title="Q&A letters" href='masterit200507.php'>July 2005</a></li>
<li><a title="Q&A letters" href='masterit200508.php'>August 2005</a></li>
<li><a title="Q&A letters" href='masterit200509.php'>September 2005</a></li>
<li><a title="Q&A letters" href='masterit200510.php'>October 2005</a></li>
<li><a title="Q&A letters" href='masterit200511.php'>November 2005</a></li>
<li><a title="Q&A letters" href='masterit200512.php'>December 2005</a></li>
<li> </li><br><li>Or go back to:</li><li><a title='Q&A/MasterIT letters from 2005' href="masterit2005.php">2005 archive</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>March 2005</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Mark's writing' href="written.php">Professional Writing</a> > <a title='My weekly Q&A column in The Australian' href="masterIT.php">MasterIT</a> > <a title='Q&A/MasterIT letters from 2005' href="masterit2005.php">2005 archive</a> > <a title='Q&A letters' href="masterit200503.php">March 2005</a>
<br><br>		<br>
<h2>1/3/05</h2><br>
<b>I work directly from a USB key from a variety of computers. I have just been told that when I exceed RAM it can cache to the hard drive. Since these are work files is there anyway I can ensure this does not happen, or if it does how do I permanently delete them from the computer I am working on? Also, I'm just about to sell a computer. How do I permanently delete the files I had on it? I believe with even a format the files can be read by a capable hacker. Which program do you recommend which would write over the existing files 8 times (which I believe is the US security standard)?</b><br>
<br>
Regarding the question of caching - what you're talking about is the Windows swapfile. When Windows runs out of physical RAM it uses so-called virtual memory (which is just a big file on the hard drive).<br>
<br>
The bad news is that there's pretty much nothing you can do about this, if you want Windows to work properly. The good news is that all Windows is doing is swapping chunks of data out to disc and back. Getting any meaningful data out of the swapfile would certainly be a non-trivial exercise, as it's constantly changing you'd have to be pretty lucky to get more than just random garbage.<br>
<br>
If it really concerns you, after each session, you can go into the system properties, select the advanced tab, click the "settings" button in "performance", then select advanced again, click "change", set the paging file for 'no paging file', then hit ok a few times, reboot, then re-enable the swapfile with a reverse of the procedure above. This is of course a pain in the proverbial, but it will force Windows to delete and recreate it's swapfile.<br>
<br>
Regarding your second query, as long as you do a long format, J Random Hacker isn't going to be able to read your erased hard drive. Conceivably someone with the right tools could, but these tools are very expensive and specialised though - think men in grey suits with earpieces.<br>
<br>
The more times data is written over the less possible it becomes to recover anything of course, so just doing a long format a couple of times in a row will pretty much eliminate any possibility of any data retrieval.<br>
<br>
<br>
<h2>8/3/05</h2><br>
<b>I am running Windows 95 with IE5.5. From late December 2004, I have been unable to access my Hotmail account, even though I can access all other websites, including those requiring a sign-in. E-mails are similarly not affected. When I click on the sign-in box, the screen changes to blank white and the blue bar at the bottom of the screen showing download moves slowly along about one third of its box and then stops.</b><br>
<br>
It might be due to the fact that you're running a slightly older version of IE (the latest version is 6), but that seems unlikely (although not impossible as 5.5 is known to have a number of bugs).<br>
<br>
It's possible that a security setting in IE is wrong. Try going into the IE options, and select the security tab, then click "default level". Also, go to the advanced tab and click "restore defaults". This will override any custom security settings that might have been made.<br>
<br>
Yet another alternative is to use Outlook Express to check your Hotmail, as the later versions of it support Hotmail, but it depends which version you have. Windows 95 is pretty long in the tooth these days (and not supported by MS any more) - you might be out of luck.<br>
<br>
Failing the above, you might like to try Mozilla Firefox as an alternative browser - it's free and available from mozilla.org.<br>
<br>
<br>
<b>Last year I added a DVD burner to my PC. The guy who fitted it said that he couldn't get the drive (E:) to display in "My Computer" even the though the original CD burner displayed OK. He didn't see this as much of a problem and set up a shortcut on my desktop. Lately I added a second hard drive; again the same problem. I now have 3 shortcuts on my desktop. Hitting Windows+E doesn't show the drive, but they are shown in Device Manager.</b><br>
<br>
The first thing that comes to mind is that perhaps the drive letters are hidden or disabled from displaying in Explorer - it's possible to do this by tweaking the registry (either manually or with a third party tool).<br>
<br>
You can check this by downloading a tool called TweakUI from http://tinyurl.com/h8zs<br>
<br>
The settings you want are under the My Computer tab, in "drives". Once you find the list of drive letters, go tick-happy and see if the drives reappear.<br>
<br>
<br>
<h2>15/3/05</h2><br>
<b>I have two problems. 1, I'm happily online, and the whole screen goes black and the computer shuts down. I have searched for solution online as it seems to be something to do with the video card, but I simply can't figure it out. There are 7,686 entries for "black screen of death". 2, I have Microsoft Outlook for my email. Lately, it will not open - it just freezes. I can try later, and it may feel inclined to work, but often not.</b><br>
<br>
These are both nasty problems because they're a bit non-specific.<br>
<br>
For the first - it could very well be a power supply problem. Bad power supplies can cause all manner of odd problems, including (and often especially) random shutdowns. They can also cause data corruption, mysterious crashes, and associated hair loss. Swapping the power supply isn't quite trivial, but it's also not rocket science. Your local friendly geek or computer shop should be able to help.<br>
<br>
As for the second problem, I always hate saying it, but reinstalling Office is the go. If you don't need Outlook's calendar though, I'd recommend getting rid of  it and using Mozilla or Thunderbird, as they're much better mail clients.<br>
<br>
<br>
<b>I apparently copied pictures from My Documents to CD for backup purposes, but I now cannot open the pics in either My Docs or from the CD. The individual pics are there according to Windows, each showing its name, size and jpeg format, but I cannot open them. I have tried "Open with..." using all the obvious programs but with no result. What have I done? I think I hate computers!</b><br>
<br>
Don't worry, you're not alone. Anyone sane who works with computers will tell you the same thing.<br>
<br>
I'm not sure what happened to your pictures. The fact that a number of programs all refuse to open them suggests to me that the problem is more likely with the files themselves than your PC.<br>
<br>
The first thing to do is to ascertain whether you can read the pictures from the CD on another PC. That way you can be sure it's your PC that's the problem, and not the files themselves.<br>
<br>
Unfortunately though, if you open other images on your PC then I would say that the files are probably corrupted.<br>
<br>
<br>
<h2>22/3/05</h2><br>
<b>In your column on the 8th of March you commented "Another alternative is to use Outlook Express to check your Hotmail". As a geriatric computer dimwit I would like to know how you go about doing this. At the moment I have Hotmail listed as a favourite and access it this way via IE but would like you to advise how to do it via OE.</b><br>
<br>
In belated honour of Senior's Week I should address this one (as well as point out that there are far more dim-witted questions out there).<br>
<br>
It isn't be hard to set up Hotmail on OE, assuming you're running a relatively recent version, but there is one caveat - it's not free any longer. Microsoft now charge extra for the privilege. If you have an old Hotmail account, you might be lucky, otherwise you'll have to pay to upgrade your account first.<br>
<br>
Anyway, to try, fire up OE, then go to the Tools menu, select accounts, click the mail tab, then click Add and then Mail.<br>
<br>
Now enter your name and email address (clicking next in between). Then you should be at the "email server names" screen - with a dropdown for incoming mail server. Select "http".<br>
<br>
Now you should see another dropdown, with Hotmail as an option. Select that and hit next, then enter your Hotmail email address and password. Last, hit next and then finish.<br>
<br>
Also, bear in mind that using hotmail with OE is a bit different - you might not have access to your address book, and most of the Hotmail settings aren't there. It's also a little bit slow at times.<br>
<br>
<br>
<b>My problem is trying to open Email attachments called "winmail.dat". All sorts of windows open when I try these, telling me to find a correct program and to warn that .dat files are sensitive if fiddled with! These attachments also have pics within but for some reason they don't show as .jpeg. I am running Eudora as my mail client - is the problem there?</b><br>
<br>
Winmail.dat is one of those useless files that Microsoft programs attach to messages. MS mail readers hide them, but because you're using a real mail client they show up. ms.tnef is another common attachment that you can ignore.<br>
<br>
I'm not sure why there are pictures are there - the person may be sending rich text with embedded images.<br>
<br>
Unfortunately the only solutions here are either to switch to Outlook or OE (not pleasant choices!) or ask the people sending you such attachments to send only plain text emails.<br>
<br>
<br>
<h2>29/3/05</h2><br>
<b>I bought a computer over the internet without an OS and intend installing my copy of Win2000. It came with a Test version of XP, and a request to remove the OS before installing my own. How do I do this? I tried to format the hard drive to start from scratch, but got the message "Format cannot run because the volume is in use by another process. Format may run if this volume is dismounted first. Would you like to force a dismount on this volume? <Y/N>". I typed Y but nothing seemed to happen.</b><br>
<br>
This is a sort of a chicken and egg thing, in that you can't destroy Windows from within Windows itself (well, you CAN, but not by formatting the disc. We'll cover how to completely bollocks up your Windows installation another day).<br>
<br>
Luckily, Windows 2000 (and XP) let you format the hard disc as part of the installation procedure.<br>
<br>
Simply start the install process by booting from the Windows CD, rather than from within Windows itself. This can be a little complicated if your PC isn't set up to boot from the CD drive, but thankfully many (if not most) PCs these days will boot from CD without a problem.<br>
<br>
To try, reboot with the Windows CD in, and if a little message saying "press any key to boot from CD" pops up, do just that, and follow the prompts.<br>
<br>
<br>
<b>I read your column religiously every week and I tried racking my brain for months to figure out how to stop an error in Win XP... the event log has an error stating that the clock can not been synchronised for x seconds etc. The computer that this error shows up on is not and will not be connected to the internet... maybe that is why i have this error?</b><br>
<br>
You're absolutely right - what's happening is that Windows is trying to set the clock every so often by connecting to an online server that is (supposedly) reflecting an atomic clock somewhere.<br>
<br>
Open up the clock properties (double clicking on the time is the simplest way), then select the "Internet time" tab, and untick the checkbox to disable synchronisation.<br>
<br>
If that doesn't solve the problem, you'll have to live with the errors in your system log. Windows loves polluting it's logs with all sorts of meaningless stuff, and the more programs you install, typically the worse it gets. You can safely ignore it though, unless you have a specific problem to track down.<br>
<br>
Send queries, chickens and golden eggs to <a href="contact.php?subject=MasterIT">(the masterit contact email address)</a><br>
<br>
<i><p>Did the information on this page help you? Entertain you? Bore you? <a href="contact.php?subject=MasterIT">Drop me a line</a>.</p>

<p>If you're feeling particularly generous, you can even <a href="buypics.php">click here to send me some dot-com riches</a>. Think of it as online busking.</i></p>
	</div>
</div>
</body>
</html>