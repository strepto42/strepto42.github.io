<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - June 2003 - Q&A letters</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="Q&A letters">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="Q&A letters" href='masterit200301.php'>January 2003</a></li>
<li><a title="Q&A letters" href='masterit200302.php'>February 2003</a></li>
<li><a title="Q&A letters" href='masterit200303.php'>March 2003</a></li>
<li><a title="Q&A letters" href='masterit200304.php'>April 2003</a></li>
<li><a title="Q&A letters" href='masterit200305.php'>May 2003</a></li>
<li><div class='activemenu'>June 2003</div></li>
<li><a title="Q&A letters" href='masterit200307.php'>July 2003</a></li>
<li><a title="Q&A letters" href='masterit200308.php'>August 2003</a></li>
<li><a title="Q&A letters" href='masterit200309.php'>September 2003</a></li>
<li><a title="Q&A letters" href='masterit200310.php'>October 2003</a></li>
<li><a title="Q&A letters" href='masterit200311.php'>November 2003</a></li>
<li><a title="Q&A letters" href='masterit200312.php'>December 2003</a></li>
<li> </li><br><li>Or go back to:</li><li><a title='Q&A/MasterIT letters from 2003' href="masterit2003.php">2003 archive</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>June 2003</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Mark's writing' href="written.php">Professional Writing</a> > <a title='My weekly Q&A column in The Australian' href="masterIT.php">MasterIT</a> > <a title='Q&A/MasterIT letters from 2003' href="masterit2003.php">2003 archive</a> > <a title='Q&A letters' href="masterit200306.php">June 2003</a>
<br><br>		<br>
<h2>3/6/03</h2><br>
<b>Is it possible to change the font of my outgoing messages so that it doesn't look like something out of a 1930 Underwood typewriter? I use Mozilla, and the address and subject come out in nice Arial. Thanks for the advice.</b><br>
<br>
It's possible to change the outgoing font for your messages, however you'll need to send them as HTML to do so.<br>
<br>
Unfortunately this sparks an ethical dilemma for MasterIT, as we firmly believe that HTML emails are the tool of the Devil.<br>
<br>
Whilst it may sound extreme to classify people who send rich text emails as Pointy Minions of Satan (especially users of Incredimail, you know who you are), consider the following sermon�<br>
<br>
Rich text emails are larger. They tend not to format well for inline comments when you reply to them, and text that relies on equally spaced characters (like tables) won't line up properly. Some mail programs can't read rich text emails, and spam filters can incorrectly pick them up as spam. And they can be pink.<br>
<br>
Ok, so we're scraping the bottom a little with the pink thing. But the point is that they rob the reader of the choice to view all incoming mail in a 1930s Underwood Typewriter font.<br>
<br>
Anyway, if you want to ignore our sagely advice and change to html emails, go to the Edit menu and select Mail & Newsgroup Account Settings. Click on the name of your email account, then check the box marked "Compose message in HTML format", and your journey to the Dark Side will be complete.<br>
<br>
As an alternative though, bear in mind that you can change the font for displaying and editing plain text emails. This won't change how others see your messages, but it'll let you choose a nicer font than Courier (a.k.a. 1930s Underwood).<br>
<br>
Hop into the general preferences (Edit -> Preferences), open up the Appearance sub-menu, and select Fonts.<br>
<br>
Have a play around with the setting for Monospace. Lucida Console may be more palatable than Courier.<br>
<br>
Please send all flames and pink emails to /dev/null. Chants of "Hallelujah" and technical questions go to <a href="contact.php">(the masterit contact email address)</a><br>
<br>
<br>
<h2>10/6/03</h2><br>
<b>I'm a third year uni student and as such tend to spend a lot of time in Word writing assignments and so on. Often the course of such joyous activities will involve cutting and pasting text from various articles and journals, sometimes from web pages, sometimes from other documents.<br>
<br>
Problem is, Windows is too smart about such things, and often it preserves all the font and formatting information. Is there a way of just pasting plain text into Word? This is driving me up the wall.</b><br>
<br>
Here at MasterIT, we feel your pain. Sometimes it's great that Windows preserves the formatting of text, but mostly it's irritating, especially when trying to write a document with a consistent look and feel.<br>
<br>
There are two solutions that come to mind. If one is specifically dealing with Word, you can select "Paste Special" from the Edit menu, and select the "unformatted text" option. Unfortunately though, there's no handy keyboard shortcut for this.<br>
<br>
More generically, you can strip formatting out of some text by running it through Notepad.<br>
<br>
Once you've copied what you want, start Notepad (the quickest way is to just press Windows-R, then type "notepad" and press enter), paste your text with control-V, select it all again with control-A, cut or copy it again with control X or C, and then paste it into its final destination.<br>
<br>
Sighing and muttering under your breath about Microsoft and Bill Gates's parentage whilst doing this are optional.<br>
<br>
<br>
<b>Thank you for your response to my question re the use of Works on the notebook. I have tried Openoffice and 602Pro PC Suite and much prefer 602Pro as the easier to use. Any comments?</b><br>
<br>
To be honest, we've not actually used either package extensively. They both seem pretty solid; although they have different heritages.<br>
<br>
Openoffice is based on Staroffice, and is completely open source (and therefore non-profit). 602Pro is a free version of more extensive commercial software that the company produces.<br>
<br>
Ultimately though, the best software for you is that which gets the job done best for you. This goes for operating systems and hardware platforms too.<br>
<br>
<br>
<h2>17/6/03</h2><br>
<b>HELP!!! Past 50, considered by some to be "Technically Challenged", I was previously running Outlook Express with no problems. Along came a new computer loaded with XP and I was instructed by my "advisor" to import all of my Outlook Express data back into Outlook. With Express, my email address book and contacts files seemed to operate independently whereas in Outlook they seem interconnected (if I delete an entry in the Contacts section it seems to automatically delete the email address and sometimes obviously you require an email address without having to have a listing in Contacts).<br>
<br>
Which system would you consider to be the better one and what am I doing wrong?<br>
<br>
Thanks for any help provided!</b><br>
<br>
You're right about the contacts being tied to the email address book in Outlook. As you no doubt realise now, Outlook and Outlook Express (OE) are very different beasties; the resemblance doesn't extend much further than the ability to send email and word "outlook".<br>
<br>
Deciding which one is better as such isn't a simple question; they're simply different. <br>
<br>
The short version is that OE is basically a mail and news reader, whereas Outlook is all that, plus an appointment book/calendar, contact manager, journal, post-it note thingy, and so on.<br>
<br>
Outlook also has about forty thousand customisable bits, and features that make it a favourite of corporate environments, such as the ability to coordinate your appointments with other people's, and set other people tasks (and fire them by email automatically when they don't deliver on time). None of these things will probably be of much use to you though.<br>
<br>
Outlook does have a nice calendar though (with oh-so-handy reminders), and once you get used to the contact-manager-as-address-book thing it can be quite usable. But it boils down to personal preference.<br>
<br>
On a side note, should you (for some esoteric reason) wish to turn off html email in Outlook, it's simply a matter of going to Tools->Options, then select the "mail format" tab and select "plain text".<br>
<br>
Outlook Express users can bless themselves in a similar manner by selecting Tools->Options, clicking on the "send" tab and selecting plain text.<br>
<br>
<br>
<h2>24/6/03</h2><br>
<b>Having read your column on 3/6/03 and as a layman user of Incredimail I would be interested in being educated on the main problems (apart from what you've already identified) with this system and will get rid of it if it causes problems for recipients etc. I look forward to your response.</b><br>
<br>
Wow - such a reasonable question from a reader we essentially called a Pointy Minion of Satan!<br>
<br>
The basic problems with Incredimail are indeed the same as the ones that we mentioned a couple of weeks ago, however Incredimail is specifically designed to send extra-lively-technicolour-dancing-bear-with-circus-music-style emails by default.<br>
<br>
This is sort of the email equivalent to "low rider" cars with suspension that can bounce them off the ground - funny to watch (especially when they accidentally tip over and crush their owners - sorry got carried away there) - but largely useless for commuting.<br>
<br>
To be fair though, Incredimail is also designed as a very user friendly email program. If having little animated dogs walking onscreen with your new mail is your thing, or you just prefer the ease of use factor, then go for it.<br>
<br>
Of course, it's possible to use Incredimail to send plain text, and it wouldn't be a true MasterIT without us telling you how to switch it off. <br>
<br>
<a href="http://www.incredimail.com" target="_blank">www.incredimail.com</a> has the low down.<br>
<br>
<br>
<b>More on cutting and pasting rich text into Word</b><br>
<br>
Thanks also to the many readers who wrote in pointing out that newer versions of Word and Works (for example, the version in Office XP) actually deal with this issue much more gracefully, by having a little widget that appears when you paste which  can be clicked to select various formatting options, including plain text.<br>
<br>
Another reader has also pointed out that you can make an easy keyboard shortcut to paste as plain text in Word 2000 by creating a keyboard macro (like ALT-V) and binding it to the "paste special" function.<br>
<br>
This is as simple as pressing control, alt and the numeric pad "+" key together, selecting "paste special" from the edit menu, pressing alt-V, and clicking assign.<br>
<br>
<i><p>Did the information on this page help you? Entertain you? Bore you? <a href="contact.php?subject=MasterIT">Drop me a line</a>.</p>

<p>If you're feeling particularly generous, you can even <a href="buypics.php">click here to send me some dot-com riches</a>. Think of it as online busking.</i></p>
	</div>
</div>
</body>
</html>