<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - Tye's Birthday - Image Gallery</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="Image Gallery">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="Pictures of my 28th Birthday party complete with Sparkler Bomb" href='28th.php'>28th Birthday</a></li>
<li><a title="Pictures of my 30th Birthday party" href='30th.php'>30th Birthday</a></li>
<li><a title="Michael Shamgar and Lindsay Halamek's 30th birthday bash photos" href='sl30th.php'>Shams & Linds' 30th</a></li>
<li><a title="Pictures of Andy Marinos's new flat, cat Toby, and Mum Pam Swain" href='andycatandflat.php'>Andy's Cat & Flat</a></li>
<li><a title="Pictures of a visit to Stephen Jackson's Farm" href='jackovisit.php'>Jacko's Farm</a></li>
<li><a title="Pictures taken at the Peace Convergence action in Rockhampton and Yeppoon in June 2005 to protest the joint US Australia military exercises (Operation Talisman Sabre)" href='peaceconvergence.php'>Peace Convergence</a></li>
<li><a title="Sydney trip - April '06" href='bridges.php'>Sydney, April 06</a></li>
<li><a title="Pics of Naima's 28th birthday dinner" href='mim28th.php'>Naima's 28th</a></li>
<li><a title="Brisbane CBD and the Story Bridge" href='brisbanepics1.php'>Brissie by Night 1</a></li>
<li><a title="Lamington National Park" href='lamington.php'>Lamington NP</a></li>
<li><a title="Various creatures and views from our Brisbane back yard" href='backyard.php'>Backyard Creatures</a></li>
<li><a title="Opening day of the Eleanor Schonell (Green) Bridge" href='greenbridge.php'>Green Bridge</a></li>
<li><a title="Pictutres from the 2006 Woodford Folk Festival" href='woodford0607.php'>Woodford 2006-2007</a></li>
<li><a title="One Cute Puppy" href='jezebel.php'>Jezebel</a></li>
<li><a title="Climbing at Kangaroo Point Cliffs" href='kangaroopt1.php'>Heather's Visit</a></li>
<li><a title="0x0021st (33rd) birthday celebrations" href='0x0021st.php'>0x0021st Birthday</a></li>
<li><a title="Nuptial photography" href='guyandalison.php'>Guy and Alison's Wedding</a></li>
<li><a title="Pictures from the 2007 Woodford Folk Festival" href='woodford0708.php'>Woodford 2007-2008</a></li>
<li><a title="Image gallery" href='sydneytrip0802.php'>Sydney & Yacaaba Head</a></li>
<li><a title="An impressive show by nature" href='lightning.php'>Thunderstorm Moonrise</a></li>
<li><a title="Frightening pictures of a shrinking beard" href='debearding.php'>De-bearding</a></li>
<li><a title="More Nuptial Photography" href='michaelandkaren.php'>Michael and Karen's Wedding</a></li>
<li><a title="A night of celebration" href='andrews21st.php'>Andrew's 21st</a></li>
<li><a title="Image Gallery" href='bloodyknee.php'>Bloody Knee</a></li>
<li><div class='activemenu'>Tye's Birthday</div></li>
<li><a title="Image Gallery" href='lasersocialising.php'>Laser Socialising</a></li>
<li><a title="Image Gallery" href='heatherandevan.php'>Heather and Evan's Wedding</a></li>
<li><a title="Image Gallery" href='woodford0809.php'>Woodford 2008-2009</a></li>
<li><a title="Image Gallery" href='allyandben.php'>Ally and Ben's Wedding</a></li>
<li><a title="Image Gallery" href='annes30th.php'>Anne's 30th</a></li>
<li><a title="Image Gallery" href='possumcreek.php'>Possum Creek</a></li>
<li><a title="Image Gallery" href='jamnight.php'>Jam Night</a></li>
<li><a title="Image Gallery" href='cunninghamsgap.php'>Cunningham's Gap</a></li>
<li><a title="Image Gallery" href='bigcat.php'>Diving on Big Cat</a></li>
<li><a title="Images from my birthday jam" href='birthdayjam.php'>Music, mayhem and merriment</a></li>
<li><a title="Image Gallery" href='fuzzypolaroidpics.php'>Fuzzy Polaroid</a></li>
<li><a title="Image Gallery" href='zombiewalk2009.php'>2009 Zombie Walk</a></li>
<li> </li><br><li>Or go back to:</li><li><a title='Picture galleries' href="pictures.php">Photography</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>Tye's Birthday</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Picture galleries' href="pictures.php">Photography</a> > <a title='Image Gallery' href="tyesbirthday.php">Tye's Birthday</a>
<br><br>		

<p>My mate Tye went and had himself a birthday. I popped along and had a grand old evening, playing with my new toy (a <a href="http://www.dpreview.com/reviews/canoneos50d/" target="_blank">Canon 50D</a>). I also met some lovely new people (hi guys, you know who you are!)</p>
<br><br>
All images in this gallery:<br>
<table width='800'>
<tr>
</tr>
<tr><td><A ID='IMG_0114.JPG' href='tyesbirthday.php?fileId=IMG_0114.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20081107/IMG_0114.JPG' ALT='IMG_0114.JPG'><BR>IMG_0114.JPG<br>64.29 KB</a><div class='inv'><br><a href='./images/20081107/IMG_0114.JPG' ALT='IMG_0114.JPG'>IMG_0114.JPG</a></div></td>
<td><A ID='IMG_0116.JPG' href='tyesbirthday.php?fileId=IMG_0116.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20081107/IMG_0116.JPG' ALT='IMG_0116.JPG'><BR>IMG_0116.JPG<br>80.78 KB</a><div class='inv'><br><a href='./images/20081107/IMG_0116.JPG' ALT='IMG_0116.JPG'>IMG_0116.JPG</a></div></td>
<td><A ID='IMG_0117.JPG' href='tyesbirthday.php?fileId=IMG_0117.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20081107/IMG_0117.JPG' ALT='IMG_0117.JPG'><BR>IMG_0117.JPG<br>77.31 KB</a><div class='inv'><br><a href='./images/20081107/IMG_0117.JPG' ALT='IMG_0117.JPG'>IMG_0117.JPG</a></div></td>
<td><A ID='IMG_0122.JPG' href='tyesbirthday.php?fileId=IMG_0122.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20081107/IMG_0122.JPG' ALT='IMG_0122.JPG'><BR>IMG_0122.JPG<br>69.97 KB</a><div class='inv'><br><a href='./images/20081107/IMG_0122.JPG' ALT='IMG_0122.JPG'>IMG_0122.JPG</a></div></td>
<td><A ID='IMG_0125.JPG' href='tyesbirthday.php?fileId=IMG_0125.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20081107/IMG_0125.JPG' ALT='IMG_0125.JPG'><BR>IMG_0125.JPG<br>55.1 KB</a><div class='inv'><br><a href='./images/20081107/IMG_0125.JPG' ALT='IMG_0125.JPG'>IMG_0125.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_0127.JPG' href='tyesbirthday.php?fileId=IMG_0127.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20081107/IMG_0127.JPG' ALT='IMG_0127.JPG'><BR>IMG_0127.JPG<br>59.82 KB</a><div class='inv'><br><a href='./images/20081107/IMG_0127.JPG' ALT='IMG_0127.JPG'>IMG_0127.JPG</a></div></td>
<td><A ID='IMG_0128.JPG' href='tyesbirthday.php?fileId=IMG_0128.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20081107/IMG_0128.JPG' ALT='IMG_0128.JPG'><BR>IMG_0128.JPG<br>53.76 KB</a><div class='inv'><br><a href='./images/20081107/IMG_0128.JPG' ALT='IMG_0128.JPG'>IMG_0128.JPG</a></div></td>
<td><A ID='IMG_0132.JPG' href='tyesbirthday.php?fileId=IMG_0132.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20081107/IMG_0132.JPG' ALT='IMG_0132.JPG'><BR>IMG_0132.JPG<br>59.59 KB</a><div class='inv'><br><a href='./images/20081107/IMG_0132.JPG' ALT='IMG_0132.JPG'>IMG_0132.JPG</a></div></td>
<td><A ID='IMG_0135.JPG' href='tyesbirthday.php?fileId=IMG_0135.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20081107/IMG_0135.JPG' ALT='IMG_0135.JPG'><BR>IMG_0135.JPG<br>43.69 KB</a><div class='inv'><br><a href='./images/20081107/IMG_0135.JPG' ALT='IMG_0135.JPG'>IMG_0135.JPG</a></div></td>
<td><A ID='IMG_0137.JPG' href='tyesbirthday.php?fileId=IMG_0137.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20081107/IMG_0137.JPG' ALT='IMG_0137.JPG'><BR>IMG_0137.JPG<br>48.16 KB</a><div class='inv'><br><a href='./images/20081107/IMG_0137.JPG' ALT='IMG_0137.JPG'>IMG_0137.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_0139.JPG' href='tyesbirthday.php?fileId=IMG_0139.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20081107/IMG_0139.JPG' ALT='IMG_0139.JPG'><BR>IMG_0139.JPG<br>44.08 KB</a><div class='inv'><br><a href='./images/20081107/IMG_0139.JPG' ALT='IMG_0139.JPG'>IMG_0139.JPG</a></div></td>
<td><A ID='IMG_0143.JPG' href='tyesbirthday.php?fileId=IMG_0143.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20081107/IMG_0143.JPG' ALT='IMG_0143.JPG'><BR>IMG_0143.JPG<br>47.41 KB</a><div class='inv'><br><a href='./images/20081107/IMG_0143.JPG' ALT='IMG_0143.JPG'>IMG_0143.JPG</a></div></td>
<td><A ID='IMG_0146.JPG' href='tyesbirthday.php?fileId=IMG_0146.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20081107/IMG_0146.JPG' ALT='IMG_0146.JPG'><BR>IMG_0146.JPG<br>41.5 KB</a><div class='inv'><br><a href='./images/20081107/IMG_0146.JPG' ALT='IMG_0146.JPG'>IMG_0146.JPG</a></div></td>
<td><A ID='IMG_0148.JPG' href='tyesbirthday.php?fileId=IMG_0148.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20081107/IMG_0148.JPG' ALT='IMG_0148.JPG'><BR>IMG_0148.JPG<br>42.05 KB</a><div class='inv'><br><a href='./images/20081107/IMG_0148.JPG' ALT='IMG_0148.JPG'>IMG_0148.JPG</a></div></td>
<td><A ID='IMG_0149.JPG' href='tyesbirthday.php?fileId=IMG_0149.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20081107/IMG_0149.JPG' ALT='IMG_0149.JPG'><BR>IMG_0149.JPG<br>49.61 KB</a><div class='inv'><br><a href='./images/20081107/IMG_0149.JPG' ALT='IMG_0149.JPG'>IMG_0149.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_0153.JPG' href='tyesbirthday.php?fileId=IMG_0153.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20081107/IMG_0153.JPG' ALT='IMG_0153.JPG'><BR>IMG_0153.JPG<br>45.16 KB</a><div class='inv'><br><a href='./images/20081107/IMG_0153.JPG' ALT='IMG_0153.JPG'>IMG_0153.JPG</a></div></td>
<td><A ID='IMG_0157.JPG' href='tyesbirthday.php?fileId=IMG_0157.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20081107/IMG_0157.JPG' ALT='IMG_0157.JPG'><BR>IMG_0157.JPG<br>56.92 KB</a><div class='inv'><br><a href='./images/20081107/IMG_0157.JPG' ALT='IMG_0157.JPG'>IMG_0157.JPG</a></div></td>
<td><A ID='IMG_0168.JPG' href='tyesbirthday.php?fileId=IMG_0168.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20081107/IMG_0168.JPG' ALT='IMG_0168.JPG'><BR>IMG_0168.JPG<br>54.2 KB</a><div class='inv'><br><a href='./images/20081107/IMG_0168.JPG' ALT='IMG_0168.JPG'>IMG_0168.JPG</a></div></td>
<td><A ID='IMG_0170.JPG' href='tyesbirthday.php?fileId=IMG_0170.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20081107/IMG_0170.JPG' ALT='IMG_0170.JPG'><BR>IMG_0170.JPG<br>74.59 KB</a><div class='inv'><br><a href='./images/20081107/IMG_0170.JPG' ALT='IMG_0170.JPG'>IMG_0170.JPG</a></div></td>
<td><A ID='IMG_0171.JPG' href='tyesbirthday.php?fileId=IMG_0171.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20081107/IMG_0171.JPG' ALT='IMG_0171.JPG'><BR>IMG_0171.JPG<br>44.95 KB</a><div class='inv'><br><a href='./images/20081107/IMG_0171.JPG' ALT='IMG_0171.JPG'>IMG_0171.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_0174.JPG' href='tyesbirthday.php?fileId=IMG_0174.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20081107/IMG_0174.JPG' ALT='IMG_0174.JPG'><BR>IMG_0174.JPG<br>53.74 KB</a><div class='inv'><br><a href='./images/20081107/IMG_0174.JPG' ALT='IMG_0174.JPG'>IMG_0174.JPG</a></div></td>
<td><A ID='IMG_0176.JPG' href='tyesbirthday.php?fileId=IMG_0176.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20081107/IMG_0176.JPG' ALT='IMG_0176.JPG'><BR>IMG_0176.JPG<br>45.28 KB</a><div class='inv'><br><a href='./images/20081107/IMG_0176.JPG' ALT='IMG_0176.JPG'>IMG_0176.JPG</a></div></td>
<td><A ID='IMG_0187.JPG' href='tyesbirthday.php?fileId=IMG_0187.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20081107/IMG_0187.JPG' ALT='IMG_0187.JPG'><BR>IMG_0187.JPG<br>47.73 KB</a><div class='inv'><br><a href='./images/20081107/IMG_0187.JPG' ALT='IMG_0187.JPG'>IMG_0187.JPG</a></div></td>
<td><A ID='IMG_0188.JPG' href='tyesbirthday.php?fileId=IMG_0188.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20081107/IMG_0188.JPG' ALT='IMG_0188.JPG'><BR>IMG_0188.JPG<br>47.07 KB</a><div class='inv'><br><a href='./images/20081107/IMG_0188.JPG' ALT='IMG_0188.JPG'>IMG_0188.JPG</a></div></td>
<td><A ID='IMG_0190.JPG' href='tyesbirthday.php?fileId=IMG_0190.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20081107/IMG_0190.JPG' ALT='IMG_0190.JPG'><BR>IMG_0190.JPG<br>55.94 KB</a><div class='inv'><br><a href='./images/20081107/IMG_0190.JPG' ALT='IMG_0190.JPG'>IMG_0190.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_0205.JPG' href='tyesbirthday.php?fileId=IMG_0205.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20081107/IMG_0205.JPG' ALT='IMG_0205.JPG'><BR>IMG_0205.JPG<br>52.38 KB</a><div class='inv'><br><a href='./images/20081107/IMG_0205.JPG' ALT='IMG_0205.JPG'>IMG_0205.JPG</a></div></td>
<td><A ID='IMG_0208.JPG' href='tyesbirthday.php?fileId=IMG_0208.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20081107/IMG_0208.JPG' ALT='IMG_0208.JPG'><BR>IMG_0208.JPG<br>65.26 KB</a><div class='inv'><br><a href='./images/20081107/IMG_0208.JPG' ALT='IMG_0208.JPG'>IMG_0208.JPG</a></div></td>
<td><A ID='IMG_0209.JPG' href='tyesbirthday.php?fileId=IMG_0209.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20081107/IMG_0209.JPG' ALT='IMG_0209.JPG'><BR>IMG_0209.JPG<br>59.15 KB</a><div class='inv'><br><a href='./images/20081107/IMG_0209.JPG' ALT='IMG_0209.JPG'>IMG_0209.JPG</a></div></td>
<td><A ID='IMG_0211.JPG' href='tyesbirthday.php?fileId=IMG_0211.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20081107/IMG_0211.JPG' ALT='IMG_0211.JPG'><BR>IMG_0211.JPG<br>57.78 KB</a><div class='inv'><br><a href='./images/20081107/IMG_0211.JPG' ALT='IMG_0211.JPG'>IMG_0211.JPG</a></div></td>
<td><A ID='IMG_0215.JPG' href='tyesbirthday.php?fileId=IMG_0215.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20081107/IMG_0215.JPG' ALT='IMG_0215.JPG'><BR>IMG_0215.JPG<br>49.9 KB</a><div class='inv'><br><a href='./images/20081107/IMG_0215.JPG' ALT='IMG_0215.JPG'>IMG_0215.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_0218.JPG' href='tyesbirthday.php?fileId=IMG_0218.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20081107/IMG_0218.JPG' ALT='IMG_0218.JPG'><BR>IMG_0218.JPG<br>59.2 KB</a><div class='inv'><br><a href='./images/20081107/IMG_0218.JPG' ALT='IMG_0218.JPG'>IMG_0218.JPG</a></div></td>
<td><A ID='IMG_0221.JPG' href='tyesbirthday.php?fileId=IMG_0221.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20081107/IMG_0221.JPG' ALT='IMG_0221.JPG'><BR>IMG_0221.JPG<br>52.85 KB</a><div class='inv'><br><a href='./images/20081107/IMG_0221.JPG' ALT='IMG_0221.JPG'>IMG_0221.JPG</a></div></td>
<td><A ID='IMG_0225.JPG' href='tyesbirthday.php?fileId=IMG_0225.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20081107/IMG_0225.JPG' ALT='IMG_0225.JPG'><BR>IMG_0225.JPG<br>68.56 KB</a><div class='inv'><br><a href='./images/20081107/IMG_0225.JPG' ALT='IMG_0225.JPG'>IMG_0225.JPG</a></div></td>
<td><A ID='IMG_0232.JPG' href='tyesbirthday.php?fileId=IMG_0232.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20081107/IMG_0232.JPG' ALT='IMG_0232.JPG'><BR>IMG_0232.JPG<br>63.28 KB</a><div class='inv'><br><a href='./images/20081107/IMG_0232.JPG' ALT='IMG_0232.JPG'>IMG_0232.JPG</a></div></td>
<td><A ID='IMG_0233.JPG' href='tyesbirthday.php?fileId=IMG_0233.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20081107/IMG_0233.JPG' ALT='IMG_0233.JPG'><BR>IMG_0233.JPG<br>51.28 KB</a><div class='inv'><br><a href='./images/20081107/IMG_0233.JPG' ALT='IMG_0233.JPG'>IMG_0233.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_0235.JPG' href='tyesbirthday.php?fileId=IMG_0235.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20081107/IMG_0235.JPG' ALT='IMG_0235.JPG'><BR>IMG_0235.JPG<br>59.26 KB</a><div class='inv'><br><a href='./images/20081107/IMG_0235.JPG' ALT='IMG_0235.JPG'>IMG_0235.JPG</a></div></td>
<td><A ID='IMG_0236.JPG' href='tyesbirthday.php?fileId=IMG_0236.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20081107/IMG_0236.JPG' ALT='IMG_0236.JPG'><BR>IMG_0236.JPG<br>57.5 KB</a><div class='inv'><br><a href='./images/20081107/IMG_0236.JPG' ALT='IMG_0236.JPG'>IMG_0236.JPG</a></div></td>
<td><A ID='IMG_0238.JPG' href='tyesbirthday.php?fileId=IMG_0238.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20081107/IMG_0238.JPG' ALT='IMG_0238.JPG'><BR>IMG_0238.JPG<br>60.73 KB</a><div class='inv'><br><a href='./images/20081107/IMG_0238.JPG' ALT='IMG_0238.JPG'>IMG_0238.JPG</a></div></td>
<td><A ID='IMG_0239.JPG' href='tyesbirthday.php?fileId=IMG_0239.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20081107/IMG_0239.JPG' ALT='IMG_0239.JPG'><BR>IMG_0239.JPG<br>71.88 KB</a><div class='inv'><br><a href='./images/20081107/IMG_0239.JPG' ALT='IMG_0239.JPG'>IMG_0239.JPG</a></div></td>
<td><A ID='IMG_0243.JPG' href='tyesbirthday.php?fileId=IMG_0243.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20081107/IMG_0243.JPG' ALT='IMG_0243.JPG'><BR>IMG_0243.JPG<br>49.43 KB</a><div class='inv'><br><a href='./images/20081107/IMG_0243.JPG' ALT='IMG_0243.JPG'>IMG_0243.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_0244.JPG' href='tyesbirthday.php?fileId=IMG_0244.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20081107/IMG_0244.JPG' ALT='IMG_0244.JPG'><BR>IMG_0244.JPG<br>56.09 KB</a><div class='inv'><br><a href='./images/20081107/IMG_0244.JPG' ALT='IMG_0244.JPG'>IMG_0244.JPG</a></div></td>
<td><A ID='IMG_0246.JPG' href='tyesbirthday.php?fileId=IMG_0246.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20081107/IMG_0246.JPG' ALT='IMG_0246.JPG'><BR>IMG_0246.JPG<br>51.85 KB</a><div class='inv'><br><a href='./images/20081107/IMG_0246.JPG' ALT='IMG_0246.JPG'>IMG_0246.JPG</a></div></td>
<td><A ID='IMG_0248.JPG' href='tyesbirthday.php?fileId=IMG_0248.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20081107/IMG_0248.JPG' ALT='IMG_0248.JPG'><BR>IMG_0248.JPG<br>53.58 KB</a><div class='inv'><br><a href='./images/20081107/IMG_0248.JPG' ALT='IMG_0248.JPG'>IMG_0248.JPG</a></div></td>
<td><A ID='IMG_0249.JPG' href='tyesbirthday.php?fileId=IMG_0249.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20081107/IMG_0249.JPG' ALT='IMG_0249.JPG'><BR>IMG_0249.JPG<br>50.33 KB</a><div class='inv'><br><a href='./images/20081107/IMG_0249.JPG' ALT='IMG_0249.JPG'>IMG_0249.JPG</a></div></td>
<td><A ID='IMG_0253.JPG' href='tyesbirthday.php?fileId=IMG_0253.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20081107/IMG_0253.JPG' ALT='IMG_0253.JPG'><BR>IMG_0253.JPG<br>41.84 KB</a><div class='inv'><br><a href='./images/20081107/IMG_0253.JPG' ALT='IMG_0253.JPG'>IMG_0253.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_0254.JPG' href='tyesbirthday.php?fileId=IMG_0254.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20081107/IMG_0254.JPG' ALT='IMG_0254.JPG'><BR>IMG_0254.JPG<br>48.62 KB</a><div class='inv'><br><a href='./images/20081107/IMG_0254.JPG' ALT='IMG_0254.JPG'>IMG_0254.JPG</a></div></td>
<td><A ID='IMG_0257.JPG' href='tyesbirthday.php?fileId=IMG_0257.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20081107/IMG_0257.JPG' ALT='IMG_0257.JPG'><BR>IMG_0257.JPG<br>54.23 KB</a><div class='inv'><br><a href='./images/20081107/IMG_0257.JPG' ALT='IMG_0257.JPG'>IMG_0257.JPG</a></div></td>
<td><A ID='IMG_0261.JPG' href='tyesbirthday.php?fileId=IMG_0261.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20081107/IMG_0261.JPG' ALT='IMG_0261.JPG'><BR>IMG_0261.JPG<br>63.2 KB</a><div class='inv'><br><a href='./images/20081107/IMG_0261.JPG' ALT='IMG_0261.JPG'>IMG_0261.JPG</a></div></td>
<td><A ID='IMG_0262.JPG' href='tyesbirthday.php?fileId=IMG_0262.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20081107/IMG_0262.JPG' ALT='IMG_0262.JPG'><BR>IMG_0262.JPG<br>49.39 KB</a><div class='inv'><br><a href='./images/20081107/IMG_0262.JPG' ALT='IMG_0262.JPG'>IMG_0262.JPG</a></div></td>
<td><A ID='IMG_0272.JPG' href='tyesbirthday.php?fileId=IMG_0272.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20081107/IMG_0272.JPG' ALT='IMG_0272.JPG'><BR>IMG_0272.JPG<br>57.9 KB</a><div class='inv'><br><a href='./images/20081107/IMG_0272.JPG' ALT='IMG_0272.JPG'>IMG_0272.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_0276.JPG' href='tyesbirthday.php?fileId=IMG_0276.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20081107/IMG_0276.JPG' ALT='IMG_0276.JPG'><BR>IMG_0276.JPG<br>40.48 KB</a><div class='inv'><br><a href='./images/20081107/IMG_0276.JPG' ALT='IMG_0276.JPG'>IMG_0276.JPG</a></div></td>
<td><A ID='IMG_0277.JPG' href='tyesbirthday.php?fileId=IMG_0277.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20081107/IMG_0277.JPG' ALT='IMG_0277.JPG'><BR>IMG_0277.JPG<br>54.66 KB</a><div class='inv'><br><a href='./images/20081107/IMG_0277.JPG' ALT='IMG_0277.JPG'>IMG_0277.JPG</a></div></td>
<td><A ID='IMG_0289.JPG' href='tyesbirthday.php?fileId=IMG_0289.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20081107/IMG_0289.JPG' ALT='IMG_0289.JPG'><BR>IMG_0289.JPG<br>52.58 KB</a><div class='inv'><br><a href='./images/20081107/IMG_0289.JPG' ALT='IMG_0289.JPG'>IMG_0289.JPG</a></div></td>
<td><A ID='IMG_0292.JPG' href='tyesbirthday.php?fileId=IMG_0292.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20081107/IMG_0292.JPG' ALT='IMG_0292.JPG'><BR>IMG_0292.JPG<br>39.98 KB</a><div class='inv'><br><a href='./images/20081107/IMG_0292.JPG' ALT='IMG_0292.JPG'>IMG_0292.JPG</a></div></td>
<td><A ID='IMG_0294.JPG' href='tyesbirthday.php?fileId=IMG_0294.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20081107/IMG_0294.JPG' ALT='IMG_0294.JPG'><BR>IMG_0294.JPG<br>60.15 KB</a><div class='inv'><br><a href='./images/20081107/IMG_0294.JPG' ALT='IMG_0294.JPG'>IMG_0294.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_0295.JPG' href='tyesbirthday.php?fileId=IMG_0295.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20081107/IMG_0295.JPG' ALT='IMG_0295.JPG'><BR>IMG_0295.JPG<br>68.48 KB</a><div class='inv'><br><a href='./images/20081107/IMG_0295.JPG' ALT='IMG_0295.JPG'>IMG_0295.JPG</a></div></td>
<td><A ID='IMG_0303.JPG' href='tyesbirthday.php?fileId=IMG_0303.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20081107/IMG_0303.JPG' ALT='IMG_0303.JPG'><BR>IMG_0303.JPG<br>51.75 KB</a><div class='inv'><br><a href='./images/20081107/IMG_0303.JPG' ALT='IMG_0303.JPG'>IMG_0303.JPG</a></div></td>
<td><A ID='IMG_0305.JPG' href='tyesbirthday.php?fileId=IMG_0305.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20081107/IMG_0305.JPG' ALT='IMG_0305.JPG'><BR>IMG_0305.JPG<br>53.42 KB</a><div class='inv'><br><a href='./images/20081107/IMG_0305.JPG' ALT='IMG_0305.JPG'>IMG_0305.JPG</a></div></td>
<td><A ID='IMG_0311.JPG' href='tyesbirthday.php?fileId=IMG_0311.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20081107/IMG_0311.JPG' ALT='IMG_0311.JPG'><BR>IMG_0311.JPG<br>56.7 KB</a><div class='inv'><br><a href='./images/20081107/IMG_0311.JPG' ALT='IMG_0311.JPG'>IMG_0311.JPG</a></div></td>
<td><A ID='IMG_0318.JPG' href='tyesbirthday.php?fileId=IMG_0318.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20081107/IMG_0318.JPG' ALT='IMG_0318.JPG'><BR>IMG_0318.JPG<br>61.17 KB</a><div class='inv'><br><a href='./images/20081107/IMG_0318.JPG' ALT='IMG_0318.JPG'>IMG_0318.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_0320.JPG' href='tyesbirthday.php?fileId=IMG_0320.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20081107/IMG_0320.JPG' ALT='IMG_0320.JPG'><BR>IMG_0320.JPG<br>55.73 KB</a><div class='inv'><br><a href='./images/20081107/IMG_0320.JPG' ALT='IMG_0320.JPG'>IMG_0320.JPG</a></div></td>
</tr>
</table>	</div>
</div>
</body>
</html>