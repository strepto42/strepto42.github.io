<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - December 2004 - Q&A letters</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="Q&A letters">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="Q&A letters" href='masterit200401.php'>January 2004</a></li>
<li><a title="Q&A letters" href='masterit200402.php'>February 2004</a></li>
<li><a title="Q&A letters" href='masterit200403.php'>March 2004</a></li>
<li><a title="Q&A letters" href='masterit200404.php'>April 2004</a></li>
<li><a title="Q&A letters" href='masterit200405.php'>May 2004</a></li>
<li><a title="Q&A letters" href='masterit200406.php'>June 2004</a></li>
<li><a title="Q&A letters" href='masterit200407.php'>July 2004</a></li>
<li><a title="Q&A letters" href='masterit200408.php'>August 2004</a></li>
<li><a title="Q&A letters" href='masterit200409.php'>September 2004</a></li>
<li><a title="Q&A letters" href='masterit200410.php'>October 2004</a></li>
<li><a title="Q&A letters" href='masterit200411.php'>November 2004</a></li>
<li><div class='activemenu'>December 2004</div></li>
<li> </li><br><li>Or go back to:</li><li><a title='Q&A/MasterIT letters from 2004' href="masterit2004.php">2004 archive</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>December 2004</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Mark's writing' href="written.php">Professional Writing</a> > <a title='My weekly Q&A column in The Australian' href="masterIT.php">MasterIT</a> > <a title='Q&A/MasterIT letters from 2004' href="masterit2004.php">2004 archive</a> > <a title='Q&A letters' href="masterit200412.php">December 2004</a>
<br><br>		<br>
<h2>7/12/04</h2><br>
<b>We use Outlook Express as our e-mail program. Frequently it will tell me we have more messages than actually end up in our inbox. It'll say "downloading 2 new messages", yet only one appears in the inbox. Is this a concern? Where is the other message coming from, and where does it go? Repeated virus scans show no problem.</b><br>
<br>
It's possible that the mystery messages are just viruses, and that your virus scanner is deleting them before you even have a chance to view them. In this case a manual scan won't show anything as the offending message is already in that big bit-bucket in the sky.<br>
<br>
Virus scanners will generally keep a log of their activities, and if you can track this log down and have a look at it, you can see if there is any activity around the time you checked your mail.<br>
<br>
Overall, I wouldn't be overly worried unless you know for certain that you're losing mail (in which case people will hound you eventually).<br>
<br>
<br>
<b>We have four old computers running windows 2000. They have a C and D drive, the D is partitioned from the C drive. The C drive is almost out of space, despite being cleaned regularly. The D seems to have nothing on it. Can the partition be removed? Would this cause any problems?</b><br>
<br>
You can indeed merge the partitions, but not without third party software. The granddaddy of them all is a thing called Partition Magic, which works very well. It will let you merge, change and add partitions. Unfortunately, it's not free. You can find it online at www.powerquest.com.<br>
<br>
Googling "free partition manager" returns quite a few hits - of which many aren't actually free. I don't actually know of any free software offhand, and when dealing with an exercise like this it's probably not a bad idea to be cautious of potentially buggy, non-commercial products. It's not like you can hit undo if things go wrong. (The worst case scenario is that you'll lose BOTH partitions).<br>
<br>
As always, back everything important up before you begin. As the mantra goes: Data that is not backed up is not data you want to keep.<br>
<br>
As far as de-partitioning causing problems, you will definitely have dramas if you have installed applications to D. In such cases, "uninstall and reinstall" is the go. On the other hand, if you only have data files on D, you'll be fine.<br>
<br>
<i><p>Did the information on this page help you? Entertain you? Bore you? <a href="contact.php?subject=MasterIT">Drop me a line</a>.</p>

<p>If you're feeling particularly generous, you can even <a href="buypics.php">click here to send me some dot-com riches</a>. Think of it as online busking.</i></p>
	</div>
</div>
</body>
</html>