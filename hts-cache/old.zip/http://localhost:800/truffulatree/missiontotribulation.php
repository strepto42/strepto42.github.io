<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - 22/7/2005 - Mission to Tribulation</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="Mission to Tribulation">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="Greetings from a Bum" href='greetingsfromabum.php'>29/4/2005</a></li>
<li><a title="Onward" href='onward.php'>2/5/2005</a></li>
<li><a title="It's a tough life (pt 1: Bundaberg, Agnes Water and 1770)" href='itsatoughlife1.php'>17/5/2005</a></li>
<li><a title="It's a tough life (pt 2: Rockhampton, Emu Park and Great Keppel Island)" href='itsatoughlife2.php'>23/5/2005</a></li>
<li><a title="There and Back Again - a Yo-yo's Tale" href='thereandbackagain.php'>18/6/2005</a></li>
<li><a title="Platypi and Grey Nomads" href='platypiandgreynomads.php'>24/6/2005</a></li>
<li><a title="Blowing Bubbles in a Watery Tomb" href='blowingbubbles.php'>1/7/2005</a></li>
<li><a title="Pieces of History" href='piecesofhistory.php'>8/7/2005</a></li>
<li><a title="Walks and Waterfalls" href='walksandwaterfalls.php'>15/7/2005</a></li>
<li><div class='activemenu'>22/7/2005</div></li>
<li><a title="Levity, Limestone and Lava" href='levitylimestoneandlava.php'>29/7/2005</a></li>
<li><a title="Into the Never Never" href='intothenevernever.php'>5/8/2005</a></li>
<li><a title="Slowing the pace in Darwin" href='slowingthepaceindarwin.php'>12/8/2005</a></li>
<li><a title="Blistering Barnacles and Leaping Lizards" href='leapinglizards.php'>19/8/2005</a></li>
<li><a title="Kakadu and Litchfield" href='kakadu.php'>26/8/2005</a></li>
<li><a title="Legacies of War" href='legaciesofwar.php'>2/9/2005</a></li>
<li><a title="Go West" href='gowest.php'>10/9/2005</a></li>
<li><a title="Things from Above" href='thingsfromabove.php'>16/9/2005</a></li>
<li><a title="The West Coast" href='thewestcoast.php'>23/9/2005</a></li>
<li><a title="Reefs and Red Dust" href='reefsandreddust.php'>30/9/2005</a></li>
<li><a title="The Pilbara" href='pilbara.php'>7/10/2005</a></li>
<li><a title="Paradise with a Headwind" href='paradisewithaheadwind.php'>14/10/2005</a></li>
<li><a title="Down the Coral Coast" href='downthecoralcoast.php'>21/10/2005</a></li>
<li><a title="Pinnacles and Pinnipeds" href='pinnaclesandpinnipeds.php'>28/10/2005</a></li>
<li><a title="A week in Perth" href='perth.php'>4/11/2005</a></li>
<li><a title="The Southwest (from Above and Below)" href='thesouthwest.php'>11/11/2005</a></li>
<li><a title="More Heights and Depths" href='moreheightsanddepths.php'>18/11/2005</a></li>
<li><a title="Across the Nullarbor (and a bit beyond)" href='nullarbor.php'>25/11/2005</a></li>
<li><a title="Double Whammy" href='doublewhammy.php'>9/12/2005</a></li>
<li><a title="Two Cities" href='twocities.php'>19/12/2005</a></li>
<li><a title="Tassie - Part 1" href='tassie1.php'>1/1/2006</a></li>
<li><a title="Tassie - Part 2" href='tassie2.php'>7/1/2006</a></li>
<li><a title="Full Circle" href='fullcircle.php'>26/1/2006</a></li>
<li><a title="The Wrap Up" href='thewrapup.php'>23/3/2006</a></li>
<li> </li><br><li>Or go back to:</li><li><a title='Travelouges and blogs from my trip around Australia' href="nerdseyeview.php">Nerd's Eye View</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>22/7/2005</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Travel stories and pictures' href="travel.php">Travelogues</a> > <a title='Travelouges and blogs from my trip around Australia' href="nerdseyeview.php">Nerd's Eye View</a> > <a title='Mission to Tribulation' href="missiontotribulation.php">22/7/2005</a>
<br><br>		


<h1>Mission to Tribulation</h1>

<a href="images/maps/Map050722.gif"><img src="images/maps/Map050722_sm.gif" align="right"></a>
<p>Hello again!</p>

<p>As usual, it's been a pretty full week, so I have lots to ramble about.</p>

<p>Taking up the story, I was at Mission beach, where I ended up staying for a few days. It was a nice, chilled hostel, and there was a good group of people to hang out with. When you're travelling, this sort of thing is relatively rare, so I figured I may as well take advantage of it, especially since the weather was awesome too.</p>

<p>I spent the few days lazing about, or riding my bike up and down the 15km beach (the tragedy of it all!). The nights were generally spent drinking. One evening I played an appalling game of chess, and was chased around the board from the word go by a German girl, who admittedly had had a fair bit of practice, having busked playing speed chess (a novel concept!) quite a bit in the past.</p>

<p>On the last night I spent there, her Aussie beau showed up from Townsville. His primary source of entertainment seemed to be buying large amounts of beer for the backpackers and watching them drink it. To refuse would no doubt have caused great offence, so what could I do. I think everyone needs a beer daddy.</p>

<p>So we sat around most of the afternoon drinking. As you can see in <a href="images/20050722/IMG_4543.JPG">one of the photos</a>, I've been working hard on my tan and physique. It's been hard, but I've been able to maintain my nerd monitor tan and bulging muscles.</p>

<p>Later in the evening one of the Italian boys staying there got out the fire twirling gear and a photo shoot ensued. I'm not normally one to encourage fire twirlers. They're like hippy drummers - mostly really bad and you just want to slap them. But the good ones are quite impressive, and the photos speak for themselves.</p>

<p>Anyway it was time to push on, so the next day I headed up to Babinda for a night, which was nice, but somewhat touristy. There were signs up everwhere warning of the EXTREME DANGER and DEATH if you dared to walk on the rocks. Sheesh.</p>

After that I headed up into the Atherton Tableland (high country to the west of Cairns which is really lovely).</p>

<p>I spent a couple of days being a big tourist and driving from attraction to attraction. Day one was waterfall day. I think I visited no less than 6. Ho hum, what can I say, they're lovely, but one does get cynical. :)</p>

<p>However, I also visited the Windy Hill wind farm, Australia's largest wind power station apparently, and that was damn cool. The noise and sheer scale of these things has to be seen to be believed. It was nice to be able to get so close too.</p>

<p>As you can see from the photos, the weather went from lovely in Mission beach, to miserable, which it has been ever since. It kinda suited the high country though, and those huge turbines spinning in the mist were very atmospheric, and o so much more lovely than a great big coal burner (discussions about the practicalities of renewable vs non-renewable energy on a postcard please).</p>

<p>I ended the day at a volcanic crater, where I also finally saw a Cassowary. That's a Damn Big Bird with a big dagger-like claw. You have to be a wee bit careful around them.</p>

<p>I ended up sleeping in the car there that night, as it was still rainy and miserable, and the nearest official campsite was far away. A French Canadian guy called Jacques also risked the wrath of a ranger by staying, and as he had a nice van and we were comparing notes regarding cameras and laptops, I offered to watch a movie on monster in his van.</p>

<p>Unfortunately, my laptop blew up his inverter after about two minutes. I felt terribly guilty; it was both of our faults though, as we should have checked the various ratings before plugging in. In my defence though, inverters normally have protective circuitry in them to prevent this sort of thing. I thought it was just bad luck, until he produced the box - with the word "Digitor" on the side. Ahhh (for the confused - Digitor is the Dick Smith budget brand. When I worked there we had running jokes about how crap anything with that branding was, and what a nightmare it would be if you had an accident, and then woke up in hospital next to a machine with said branding).</p>

<p>Oh well, live and learn. I left him with half the price of a new one; not much else one could do really in the situation. Replacing power transistors in the middle of rainforest can be tricky, even if you can get the parts.</p>

<p>Anyway, if day one of the Atherton Tableland was waterfall day, day two was tree day. I visited an enormous Red Cedar, and two Strangler Figs. All three trees are easily several hundred years old, and are damn impressive.</p>

<p>After that I did a long drive around Lake Tinaroo. Parts of the lake have dead trees poking out of the water, as apparently when they were clearing the land prior to completing the dam, the rain came down a bit suddenly and they didn't quite finish the job. I wasn't complaining, they make for nice photos.</p>

<p>The dam itself also presented some neat photographic opportunities, as someone had left a tap running, and a huge jet of water was fountaining into the spillway.</p>

<p>I spent the night in Atherton itself, in possibly the nicest hostel I've ever seen, facilities-wise. Free pool, huge TV with videos, enormous kitchen etc. Turned out to be a working hostel though; stocked with tired looking fruit pickers. They all went to bed early and got up before I even woke up the next morning. There was all something very gingerbread house about it.</p>

<p>From there I drove North, to Cape Tribulation, which is where I am now. This is as far up as I'll go in Queensland; from here one starts to need a proper 4WD to go much further.</p>

<p>This is a really lovely spot though - tropical rainforest right up to the ocean. There is also an amazing amount of wildlife, if you stop and look. Unfortunately the weather is still terrible - rainy and windy - so no snorkelling or diving for me. Not to worry; I've been for a few walks, and frequented the bar a little.</p>

<p>There was a full moon party last night; half the local population showed up (this is the only real bar in town). It was a nice night all up; despite getting to witness my first Qld pub brawl at the end of the night. Mmmm. Classy lads full of alcohol. It pays to smile lots at these people.</p>

<p>I don't want to end on a sour note though; it really wasn't that bad. I quite like it up here, but it is somewhat off the map. I'll head to Cairns now, the big smoke of the backpacker train. If anyone wants to fly up and visit me suddenly, feel free. Come on, the weather's great! ;)</p>

<p>Till next time, look after yourselves, and keep those emails coming!</p>

<p>This week's selected pics:</p>
<!-- 
<ul>
<li><a href="?fileId=IMG_4638.JPG">Sergio, a flaming Italian</a></li>
<li><a href="?fileId=IMG_4643.JPG">possibly a new Doom3 monster</a></li>
<li><a href="?fileId=IMG_4812.JPG">big f'koff windmills</a></li>
<li><a href="?fileId=IMG_4887.JPG">the Red Cedar, with bouncer</a></li>
<li><a href="?fileId=IMG_4941.JPG">someone left the tap running at lake Tinaroo</a></li>
</ul>
 -->
<table width="800">
	<tr>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=IMG_4638.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20050722/IMG_4638.JPG' ALT='Sergio, a flaming Italian'><BR>Sergio, a flaming Italian</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=IMG_4643.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20050722/IMG_4643.JPG' ALT='possibly a new Doom3 monster'><BR>possibly a new Doom3 monster</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=IMG_4812.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20050722/IMG_4812.JPG' ALT="big f'koff windmills"><BR>big f'koff windmills</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=IMG_4887.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20050722/IMG_4887.JPG' ALT='the Red Cedar, with bouncer'><BR>the Red Cedar, with bouncer</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=IMG_4941.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20050722/IMG_4941.JPG' ALT='someone left the tap running at lake Tinaroo'><BR>someone left the tap running at lake Tinaroo</a>
	</td>
	</tr>
</table>

<br><br>
All images in this gallery:<br>
<table width='800'>
<tr>
</tr>
<tr><td><A ID='IMG_4536.JPG' href='missiontotribulation.php?fileId=IMG_4536.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050722/IMG_4536.JPG' ALT='IMG_4536.JPG'><BR>IMG_4536.JPG<br>60.95 KB</a><div class='inv'><br><a href='./images/20050722/IMG_4536.JPG' ALT='IMG_4536.JPG'>IMG_4536.JPG</a></div></td>
<td><A ID='IMG_4541.JPG' href='missiontotribulation.php?fileId=IMG_4541.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050722/IMG_4541.JPG' ALT='IMG_4541.JPG'><BR>IMG_4541.JPG<br>44.92 KB</a><div class='inv'><br><a href='./images/20050722/IMG_4541.JPG' ALT='IMG_4541.JPG'>IMG_4541.JPG</a></div></td>
<td><A ID='IMG_4542.JPG' href='missiontotribulation.php?fileId=IMG_4542.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050722/IMG_4542.JPG' ALT='IMG_4542.JPG'><BR>IMG_4542.JPG<br>124.99 KB</a><div class='inv'><br><a href='./images/20050722/IMG_4542.JPG' ALT='IMG_4542.JPG'>IMG_4542.JPG</a></div></td>
<td><A ID='IMG_4543.JPG' href='missiontotribulation.php?fileId=IMG_4543.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050722/IMG_4543.JPG' ALT='IMG_4543.JPG'><BR>IMG_4543.JPG<br>77.75 KB</a><div class='inv'><br><a href='./images/20050722/IMG_4543.JPG' ALT='IMG_4543.JPG'>IMG_4543.JPG</a></div></td>
<td><A ID='IMG_4544.JPG' href='missiontotribulation.php?fileId=IMG_4544.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050722/IMG_4544.JPG' ALT='IMG_4544.JPG'><BR>IMG_4544.JPG<br>74.46 KB</a><div class='inv'><br><a href='./images/20050722/IMG_4544.JPG' ALT='IMG_4544.JPG'>IMG_4544.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_4546.JPG' href='missiontotribulation.php?fileId=IMG_4546.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050722/IMG_4546.JPG' ALT='IMG_4546.JPG'><BR>IMG_4546.JPG<br>55.68 KB</a><div class='inv'><br><a href='./images/20050722/IMG_4546.JPG' ALT='IMG_4546.JPG'>IMG_4546.JPG</a></div></td>
<td><A ID='IMG_4547.JPG' href='missiontotribulation.php?fileId=IMG_4547.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050722/IMG_4547.JPG' ALT='IMG_4547.JPG'><BR>IMG_4547.JPG<br>99.03 KB</a><div class='inv'><br><a href='./images/20050722/IMG_4547.JPG' ALT='IMG_4547.JPG'>IMG_4547.JPG</a></div></td>
<td><A ID='IMG_4555.JPG' href='missiontotribulation.php?fileId=IMG_4555.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050722/IMG_4555.JPG' ALT='IMG_4555.JPG'><BR>IMG_4555.JPG<br>51.42 KB</a><div class='inv'><br><a href='./images/20050722/IMG_4555.JPG' ALT='IMG_4555.JPG'>IMG_4555.JPG</a></div></td>
<td><A ID='IMG_4557.JPG' href='missiontotribulation.php?fileId=IMG_4557.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050722/IMG_4557.JPG' ALT='IMG_4557.JPG'><BR>IMG_4557.JPG<br>59.75 KB</a><div class='inv'><br><a href='./images/20050722/IMG_4557.JPG' ALT='IMG_4557.JPG'>IMG_4557.JPG</a></div></td>
<td><A ID='IMG_4558.JPG' href='missiontotribulation.php?fileId=IMG_4558.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050722/IMG_4558.JPG' ALT='IMG_4558.JPG'><BR>IMG_4558.JPG<br>53.35 KB</a><div class='inv'><br><a href='./images/20050722/IMG_4558.JPG' ALT='IMG_4558.JPG'>IMG_4558.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_4571.JPG' href='missiontotribulation.php?fileId=IMG_4571.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050722/IMG_4571.JPG' ALT='IMG_4571.JPG'><BR>IMG_4571.JPG<br>43.18 KB</a><div class='inv'><br><a href='./images/20050722/IMG_4571.JPG' ALT='IMG_4571.JPG'>IMG_4571.JPG</a></div></td>
<td><A ID='IMG_4577.JPG' href='missiontotribulation.php?fileId=IMG_4577.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050722/IMG_4577.JPG' ALT='IMG_4577.JPG'><BR>IMG_4577.JPG<br>91.08 KB</a><div class='inv'><br><a href='./images/20050722/IMG_4577.JPG' ALT='IMG_4577.JPG'>IMG_4577.JPG</a></div></td>
<td><A ID='IMG_4581.JPG' href='missiontotribulation.php?fileId=IMG_4581.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050722/IMG_4581.JPG' ALT='IMG_4581.JPG'><BR>IMG_4581.JPG<br>102.8 KB</a><div class='inv'><br><a href='./images/20050722/IMG_4581.JPG' ALT='IMG_4581.JPG'>IMG_4581.JPG</a></div></td>
<td><A ID='IMG_4583.JPG' href='missiontotribulation.php?fileId=IMG_4583.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050722/IMG_4583.JPG' ALT='IMG_4583.JPG'><BR>IMG_4583.JPG<br>138.51 KB</a><div class='inv'><br><a href='./images/20050722/IMG_4583.JPG' ALT='IMG_4583.JPG'>IMG_4583.JPG</a></div></td>
<td><A ID='IMG_4587.JPG' href='missiontotribulation.php?fileId=IMG_4587.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050722/IMG_4587.JPG' ALT='IMG_4587.JPG'><BR>IMG_4587.JPG<br>113.51 KB</a><div class='inv'><br><a href='./images/20050722/IMG_4587.JPG' ALT='IMG_4587.JPG'>IMG_4587.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_4596.JPG' href='missiontotribulation.php?fileId=IMG_4596.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050722/IMG_4596.JPG' ALT='IMG_4596.JPG'><BR>IMG_4596.JPG<br>109.21 KB</a><div class='inv'><br><a href='./images/20050722/IMG_4596.JPG' ALT='IMG_4596.JPG'>IMG_4596.JPG</a></div></td>
<td><A ID='IMG_4599.JPG' href='missiontotribulation.php?fileId=IMG_4599.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050722/IMG_4599.JPG' ALT='IMG_4599.JPG'><BR>IMG_4599.JPG<br>119.23 KB</a><div class='inv'><br><a href='./images/20050722/IMG_4599.JPG' ALT='IMG_4599.JPG'>IMG_4599.JPG</a></div></td>
<td><A ID='IMG_4617.JPG' href='missiontotribulation.php?fileId=IMG_4617.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050722/IMG_4617.JPG' ALT='IMG_4617.JPG'><BR>IMG_4617.JPG<br>62.84 KB</a><div class='inv'><br><a href='./images/20050722/IMG_4617.JPG' ALT='IMG_4617.JPG'>IMG_4617.JPG</a></div></td>
<td><A ID='IMG_4619.JPG' href='missiontotribulation.php?fileId=IMG_4619.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050722/IMG_4619.JPG' ALT='IMG_4619.JPG'><BR>IMG_4619.JPG<br>105.71 KB</a><div class='inv'><br><a href='./images/20050722/IMG_4619.JPG' ALT='IMG_4619.JPG'>IMG_4619.JPG</a></div></td>
<td><A ID='IMG_4634.JPG' href='missiontotribulation.php?fileId=IMG_4634.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050722/IMG_4634.JPG' ALT='IMG_4634.JPG'><BR>IMG_4634.JPG<br>64.91 KB</a><div class='inv'><br><a href='./images/20050722/IMG_4634.JPG' ALT='IMG_4634.JPG'>IMG_4634.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_4638.JPG' href='missiontotribulation.php?fileId=IMG_4638.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050722/IMG_4638.JPG' ALT='IMG_4638.JPG'><BR>IMG_4638.JPG<br>72.43 KB</a><div class='inv'><br><a href='./images/20050722/IMG_4638.JPG' ALT='IMG_4638.JPG'>IMG_4638.JPG</a></div></td>
<td><A ID='IMG_4640.JPG' href='missiontotribulation.php?fileId=IMG_4640.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050722/IMG_4640.JPG' ALT='IMG_4640.JPG'><BR>IMG_4640.JPG<br>81.32 KB</a><div class='inv'><br><a href='./images/20050722/IMG_4640.JPG' ALT='IMG_4640.JPG'>IMG_4640.JPG</a></div></td>
<td><A ID='IMG_4641.JPG' href='missiontotribulation.php?fileId=IMG_4641.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050722/IMG_4641.JPG' ALT='IMG_4641.JPG'><BR>IMG_4641.JPG<br>62.79 KB</a><div class='inv'><br><a href='./images/20050722/IMG_4641.JPG' ALT='IMG_4641.JPG'>IMG_4641.JPG</a></div></td>
<td><A ID='IMG_4643.JPG' href='missiontotribulation.php?fileId=IMG_4643.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050722/IMG_4643.JPG' ALT='IMG_4643.JPG'><BR>IMG_4643.JPG<br>90.68 KB</a><div class='inv'><br><a href='./images/20050722/IMG_4643.JPG' ALT='IMG_4643.JPG'>IMG_4643.JPG</a></div></td>
<td><A ID='IMG_4651.JPG' href='missiontotribulation.php?fileId=IMG_4651.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050722/IMG_4651.JPG' ALT='IMG_4651.JPG'><BR>IMG_4651.JPG<br>50.77 KB</a><div class='inv'><br><a href='./images/20050722/IMG_4651.JPG' ALT='IMG_4651.JPG'>IMG_4651.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_4652.JPG' href='missiontotribulation.php?fileId=IMG_4652.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050722/IMG_4652.JPG' ALT='IMG_4652.JPG'><BR>IMG_4652.JPG<br>47.58 KB</a><div class='inv'><br><a href='./images/20050722/IMG_4652.JPG' ALT='IMG_4652.JPG'>IMG_4652.JPG</a></div></td>
<td><A ID='IMG_4658.JPG' href='missiontotribulation.php?fileId=IMG_4658.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050722/IMG_4658.JPG' ALT='IMG_4658.JPG'><BR>IMG_4658.JPG<br>30.77 KB</a><div class='inv'><br><a href='./images/20050722/IMG_4658.JPG' ALT='IMG_4658.JPG'>IMG_4658.JPG</a></div></td>
<td><A ID='IMG_4660.JPG' href='missiontotribulation.php?fileId=IMG_4660.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050722/IMG_4660.JPG' ALT='IMG_4660.JPG'><BR>IMG_4660.JPG<br>60.66 KB</a><div class='inv'><br><a href='./images/20050722/IMG_4660.JPG' ALT='IMG_4660.JPG'>IMG_4660.JPG</a></div></td>
<td><A ID='IMG_4662.JPG' href='missiontotribulation.php?fileId=IMG_4662.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050722/IMG_4662.JPG' ALT='IMG_4662.JPG'><BR>IMG_4662.JPG<br>37.54 KB</a><div class='inv'><br><a href='./images/20050722/IMG_4662.JPG' ALT='IMG_4662.JPG'>IMG_4662.JPG</a></div></td>
<td><A ID='IMG_4669.JPG' href='missiontotribulation.php?fileId=IMG_4669.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050722/IMG_4669.JPG' ALT='IMG_4669.JPG'><BR>IMG_4669.JPG<br>22.65 KB</a><div class='inv'><br><a href='./images/20050722/IMG_4669.JPG' ALT='IMG_4669.JPG'>IMG_4669.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_4676.JPG' href='missiontotribulation.php?fileId=IMG_4676.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050722/IMG_4676.JPG' ALT='IMG_4676.JPG'><BR>IMG_4676.JPG<br>35.38 KB</a><div class='inv'><br><a href='./images/20050722/IMG_4676.JPG' ALT='IMG_4676.JPG'>IMG_4676.JPG</a></div></td>
<td><A ID='IMG_4682.JPG' href='missiontotribulation.php?fileId=IMG_4682.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050722/IMG_4682.JPG' ALT='IMG_4682.JPG'><BR>IMG_4682.JPG<br>49.28 KB</a><div class='inv'><br><a href='./images/20050722/IMG_4682.JPG' ALT='IMG_4682.JPG'>IMG_4682.JPG</a></div></td>
<td><A ID='IMG_4689.JPG' href='missiontotribulation.php?fileId=IMG_4689.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050722/IMG_4689.JPG' ALT='IMG_4689.JPG'><BR>IMG_4689.JPG<br>60.28 KB</a><div class='inv'><br><a href='./images/20050722/IMG_4689.JPG' ALT='IMG_4689.JPG'>IMG_4689.JPG</a></div></td>
<td><A ID='IMG_4695.JPG' href='missiontotribulation.php?fileId=IMG_4695.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050722/IMG_4695.JPG' ALT='IMG_4695.JPG'><BR>IMG_4695.JPG<br>63.95 KB</a><div class='inv'><br><a href='./images/20050722/IMG_4695.JPG' ALT='IMG_4695.JPG'>IMG_4695.JPG</a></div></td>
<td><A ID='IMG_4700.JPG' href='missiontotribulation.php?fileId=IMG_4700.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050722/IMG_4700.JPG' ALT='IMG_4700.JPG'><BR>IMG_4700.JPG<br>50.36 KB</a><div class='inv'><br><a href='./images/20050722/IMG_4700.JPG' ALT='IMG_4700.JPG'>IMG_4700.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_4704.JPG' href='missiontotribulation.php?fileId=IMG_4704.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050722/IMG_4704.JPG' ALT='IMG_4704.JPG'><BR>IMG_4704.JPG<br>60.46 KB</a><div class='inv'><br><a href='./images/20050722/IMG_4704.JPG' ALT='IMG_4704.JPG'>IMG_4704.JPG</a></div></td>
<td><A ID='IMG_4707.JPG' href='missiontotribulation.php?fileId=IMG_4707.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050722/IMG_4707.JPG' ALT='IMG_4707.JPG'><BR>IMG_4707.JPG<br>70.21 KB</a><div class='inv'><br><a href='./images/20050722/IMG_4707.JPG' ALT='IMG_4707.JPG'>IMG_4707.JPG</a></div></td>
<td><A ID='IMG_4712.JPG' href='missiontotribulation.php?fileId=IMG_4712.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050722/IMG_4712.JPG' ALT='IMG_4712.JPG'><BR>IMG_4712.JPG<br>36.86 KB</a><div class='inv'><br><a href='./images/20050722/IMG_4712.JPG' ALT='IMG_4712.JPG'>IMG_4712.JPG</a></div></td>
<td><A ID='IMG_4714.JPG' href='missiontotribulation.php?fileId=IMG_4714.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050722/IMG_4714.JPG' ALT='IMG_4714.JPG'><BR>IMG_4714.JPG<br>31.3 KB</a><div class='inv'><br><a href='./images/20050722/IMG_4714.JPG' ALT='IMG_4714.JPG'>IMG_4714.JPG</a></div></td>
<td><A ID='IMG_4716.JPG' href='missiontotribulation.php?fileId=IMG_4716.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050722/IMG_4716.JPG' ALT='IMG_4716.JPG'><BR>IMG_4716.JPG<br>35.5 KB</a><div class='inv'><br><a href='./images/20050722/IMG_4716.JPG' ALT='IMG_4716.JPG'>IMG_4716.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_4718.JPG' href='missiontotribulation.php?fileId=IMG_4718.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050722/IMG_4718.JPG' ALT='IMG_4718.JPG'><BR>IMG_4718.JPG<br>52.43 KB</a><div class='inv'><br><a href='./images/20050722/IMG_4718.JPG' ALT='IMG_4718.JPG'>IMG_4718.JPG</a></div></td>
<td><A ID='IMG_4721.JPG' href='missiontotribulation.php?fileId=IMG_4721.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050722/IMG_4721.JPG' ALT='IMG_4721.JPG'><BR>IMG_4721.JPG<br>53.08 KB</a><div class='inv'><br><a href='./images/20050722/IMG_4721.JPG' ALT='IMG_4721.JPG'>IMG_4721.JPG</a></div></td>
<td><A ID='IMG_4722.JPG' href='missiontotribulation.php?fileId=IMG_4722.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050722/IMG_4722.JPG' ALT='IMG_4722.JPG'><BR>IMG_4722.JPG<br>58.82 KB</a><div class='inv'><br><a href='./images/20050722/IMG_4722.JPG' ALT='IMG_4722.JPG'>IMG_4722.JPG</a></div></td>
<td><A ID='IMG_4745.JPG' href='missiontotribulation.php?fileId=IMG_4745.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050722/IMG_4745.JPG' ALT='IMG_4745.JPG'><BR>IMG_4745.JPG<br>56.14 KB</a><div class='inv'><br><a href='./images/20050722/IMG_4745.JPG' ALT='IMG_4745.JPG'>IMG_4745.JPG</a></div></td>
<td><A ID='IMG_4748.JPG' href='missiontotribulation.php?fileId=IMG_4748.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050722/IMG_4748.JPG' ALT='IMG_4748.JPG'><BR>IMG_4748.JPG<br>44.46 KB</a><div class='inv'><br><a href='./images/20050722/IMG_4748.JPG' ALT='IMG_4748.JPG'>IMG_4748.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_4749.JPG' href='missiontotribulation.php?fileId=IMG_4749.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050722/IMG_4749.JPG' ALT='IMG_4749.JPG'><BR>IMG_4749.JPG<br>107.91 KB</a><div class='inv'><br><a href='./images/20050722/IMG_4749.JPG' ALT='IMG_4749.JPG'>IMG_4749.JPG</a></div></td>
<td><A ID='IMG_4752.JPG' href='missiontotribulation.php?fileId=IMG_4752.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050722/IMG_4752.JPG' ALT='IMG_4752.JPG'><BR>IMG_4752.JPG<br>104.45 KB</a><div class='inv'><br><a href='./images/20050722/IMG_4752.JPG' ALT='IMG_4752.JPG'>IMG_4752.JPG</a></div></td>
<td><A ID='IMG_4764.JPG' href='missiontotribulation.php?fileId=IMG_4764.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050722/IMG_4764.JPG' ALT='IMG_4764.JPG'><BR>IMG_4764.JPG<br>120.04 KB</a><div class='inv'><br><a href='./images/20050722/IMG_4764.JPG' ALT='IMG_4764.JPG'>IMG_4764.JPG</a></div></td>
<td><A ID='IMG_4782.JPG' href='missiontotribulation.php?fileId=IMG_4782.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050722/IMG_4782.JPG' ALT='IMG_4782.JPG'><BR>IMG_4782.JPG<br>89.96 KB</a><div class='inv'><br><a href='./images/20050722/IMG_4782.JPG' ALT='IMG_4782.JPG'>IMG_4782.JPG</a></div></td>
<td><A ID='IMG_4786.JPG' href='missiontotribulation.php?fileId=IMG_4786.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050722/IMG_4786.JPG' ALT='IMG_4786.JPG'><BR>IMG_4786.JPG<br>102.1 KB</a><div class='inv'><br><a href='./images/20050722/IMG_4786.JPG' ALT='IMG_4786.JPG'>IMG_4786.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_4787.JPG' href='missiontotribulation.php?fileId=IMG_4787.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050722/IMG_4787.JPG' ALT='IMG_4787.JPG'><BR>IMG_4787.JPG<br>87.53 KB</a><div class='inv'><br><a href='./images/20050722/IMG_4787.JPG' ALT='IMG_4787.JPG'>IMG_4787.JPG</a></div></td>
<td><A ID='IMG_4804.JPG' href='missiontotribulation.php?fileId=IMG_4804.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050722/IMG_4804.JPG' ALT='IMG_4804.JPG'><BR>IMG_4804.JPG<br>30.25 KB</a><div class='inv'><br><a href='./images/20050722/IMG_4804.JPG' ALT='IMG_4804.JPG'>IMG_4804.JPG</a></div></td>
<td><A ID='IMG_4805.JPG' href='missiontotribulation.php?fileId=IMG_4805.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050722/IMG_4805.JPG' ALT='IMG_4805.JPG'><BR>IMG_4805.JPG<br>40.85 KB</a><div class='inv'><br><a href='./images/20050722/IMG_4805.JPG' ALT='IMG_4805.JPG'>IMG_4805.JPG</a></div></td>
<td><A ID='IMG_4812.JPG' href='missiontotribulation.php?fileId=IMG_4812.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050722/IMG_4812.JPG' ALT='IMG_4812.JPG'><BR>IMG_4812.JPG<br>25.61 KB</a><div class='inv'><br><a href='./images/20050722/IMG_4812.JPG' ALT='IMG_4812.JPG'>IMG_4812.JPG</a></div></td>
<td><A ID='IMG_4814.JPG' href='missiontotribulation.php?fileId=IMG_4814.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050722/IMG_4814.JPG' ALT='IMG_4814.JPG'><BR>IMG_4814.JPG<br>34.81 KB</a><div class='inv'><br><a href='./images/20050722/IMG_4814.JPG' ALT='IMG_4814.JPG'>IMG_4814.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_4819.JPG' href='missiontotribulation.php?fileId=IMG_4819.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050722/IMG_4819.JPG' ALT='IMG_4819.JPG'><BR>IMG_4819.JPG<br>28.13 KB</a><div class='inv'><br><a href='./images/20050722/IMG_4819.JPG' ALT='IMG_4819.JPG'>IMG_4819.JPG</a></div></td>
<td><A ID='IMG_4822.JPG' href='missiontotribulation.php?fileId=IMG_4822.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050722/IMG_4822.JPG' ALT='IMG_4822.JPG'><BR>IMG_4822.JPG<br>33 KB</a><div class='inv'><br><a href='./images/20050722/IMG_4822.JPG' ALT='IMG_4822.JPG'>IMG_4822.JPG</a></div></td>
<td><A ID='IMG_4825.JPG' href='missiontotribulation.php?fileId=IMG_4825.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050722/IMG_4825.JPG' ALT='IMG_4825.JPG'><BR>IMG_4825.JPG<br>28.23 KB</a><div class='inv'><br><a href='./images/20050722/IMG_4825.JPG' ALT='IMG_4825.JPG'>IMG_4825.JPG</a></div></td>
<td><A ID='IMG_4829.JPG' href='missiontotribulation.php?fileId=IMG_4829.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050722/IMG_4829.JPG' ALT='IMG_4829.JPG'><BR>IMG_4829.JPG<br>25.01 KB</a><div class='inv'><br><a href='./images/20050722/IMG_4829.JPG' ALT='IMG_4829.JPG'>IMG_4829.JPG</a></div></td>
<td><A ID='IMG_4834.JPG' href='missiontotribulation.php?fileId=IMG_4834.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050722/IMG_4834.JPG' ALT='IMG_4834.JPG'><BR>IMG_4834.JPG<br>26.39 KB</a><div class='inv'><br><a href='./images/20050722/IMG_4834.JPG' ALT='IMG_4834.JPG'>IMG_4834.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_4838.JPG' href='missiontotribulation.php?fileId=IMG_4838.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050722/IMG_4838.JPG' ALT='IMG_4838.JPG'><BR>IMG_4838.JPG<br>42.2 KB</a><div class='inv'><br><a href='./images/20050722/IMG_4838.JPG' ALT='IMG_4838.JPG'>IMG_4838.JPG</a></div></td>
<td><A ID='IMG_4853.JPG' href='missiontotribulation.php?fileId=IMG_4853.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050722/IMG_4853.JPG' ALT='IMG_4853.JPG'><BR>IMG_4853.JPG<br>71.95 KB</a><div class='inv'><br><a href='./images/20050722/IMG_4853.JPG' ALT='IMG_4853.JPG'>IMG_4853.JPG</a></div></td>
<td><A ID='IMG_4854.JPG' href='missiontotribulation.php?fileId=IMG_4854.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050722/IMG_4854.JPG' ALT='IMG_4854.JPG'><BR>IMG_4854.JPG<br>91.38 KB</a><div class='inv'><br><a href='./images/20050722/IMG_4854.JPG' ALT='IMG_4854.JPG'>IMG_4854.JPG</a></div></td>
<td><A ID='IMG_4860.JPG' href='missiontotribulation.php?fileId=IMG_4860.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050722/IMG_4860.JPG' ALT='IMG_4860.JPG'><BR>IMG_4860.JPG<br>84.76 KB</a><div class='inv'><br><a href='./images/20050722/IMG_4860.JPG' ALT='IMG_4860.JPG'>IMG_4860.JPG</a></div></td>
<td><A ID='IMG_4868.JPG' href='missiontotribulation.php?fileId=IMG_4868.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050722/IMG_4868.JPG' ALT='IMG_4868.JPG'><BR>IMG_4868.JPG<br>97.89 KB</a><div class='inv'><br><a href='./images/20050722/IMG_4868.JPG' ALT='IMG_4868.JPG'>IMG_4868.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_4873.JPG' href='missiontotribulation.php?fileId=IMG_4873.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050722/IMG_4873.JPG' ALT='IMG_4873.JPG'><BR>IMG_4873.JPG<br>102.47 KB</a><div class='inv'><br><a href='./images/20050722/IMG_4873.JPG' ALT='IMG_4873.JPG'>IMG_4873.JPG</a></div></td>
<td><A ID='IMG_4887.JPG' href='missiontotribulation.php?fileId=IMG_4887.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050722/IMG_4887.JPG' ALT='IMG_4887.JPG'><BR>IMG_4887.JPG<br>135.81 KB</a><div class='inv'><br><a href='./images/20050722/IMG_4887.JPG' ALT='IMG_4887.JPG'>IMG_4887.JPG</a></div></td>
<td><A ID='IMG_4891.JPG' href='missiontotribulation.php?fileId=IMG_4891.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050722/IMG_4891.JPG' ALT='IMG_4891.JPG'><BR>IMG_4891.JPG<br>115.35 KB</a><div class='inv'><br><a href='./images/20050722/IMG_4891.JPG' ALT='IMG_4891.JPG'>IMG_4891.JPG</a></div></td>
<td><A ID='IMG_4900.JPG' href='missiontotribulation.php?fileId=IMG_4900.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050722/IMG_4900.JPG' ALT='IMG_4900.JPG'><BR>IMG_4900.JPG<br>111.89 KB</a><div class='inv'><br><a href='./images/20050722/IMG_4900.JPG' ALT='IMG_4900.JPG'>IMG_4900.JPG</a></div></td>
<td><A ID='IMG_4901.JPG' href='missiontotribulation.php?fileId=IMG_4901.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050722/IMG_4901.JPG' ALT='IMG_4901.JPG'><BR>IMG_4901.JPG<br>115.43 KB</a><div class='inv'><br><a href='./images/20050722/IMG_4901.JPG' ALT='IMG_4901.JPG'>IMG_4901.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_4902.JPG' href='missiontotribulation.php?fileId=IMG_4902.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050722/IMG_4902.JPG' ALT='IMG_4902.JPG'><BR>IMG_4902.JPG<br>65.7 KB</a><div class='inv'><br><a href='./images/20050722/IMG_4902.JPG' ALT='IMG_4902.JPG'>IMG_4902.JPG</a></div></td>
<td><A ID='IMG_4905.JPG' href='missiontotribulation.php?fileId=IMG_4905.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050722/IMG_4905.JPG' ALT='IMG_4905.JPG'><BR>IMG_4905.JPG<br>111.58 KB</a><div class='inv'><br><a href='./images/20050722/IMG_4905.JPG' ALT='IMG_4905.JPG'>IMG_4905.JPG</a></div></td>
<td><A ID='IMG_4907.JPG' href='missiontotribulation.php?fileId=IMG_4907.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050722/IMG_4907.JPG' ALT='IMG_4907.JPG'><BR>IMG_4907.JPG<br>66.11 KB</a><div class='inv'><br><a href='./images/20050722/IMG_4907.JPG' ALT='IMG_4907.JPG'>IMG_4907.JPG</a></div></td>
<td><A ID='IMG_4908.JPG' href='missiontotribulation.php?fileId=IMG_4908.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050722/IMG_4908.JPG' ALT='IMG_4908.JPG'><BR>IMG_4908.JPG<br>138.49 KB</a><div class='inv'><br><a href='./images/20050722/IMG_4908.JPG' ALT='IMG_4908.JPG'>IMG_4908.JPG</a></div></td>
<td><A ID='IMG_4910.JPG' href='missiontotribulation.php?fileId=IMG_4910.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050722/IMG_4910.JPG' ALT='IMG_4910.JPG'><BR>IMG_4910.JPG<br>111.89 KB</a><div class='inv'><br><a href='./images/20050722/IMG_4910.JPG' ALT='IMG_4910.JPG'>IMG_4910.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_4911.JPG' href='missiontotribulation.php?fileId=IMG_4911.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050722/IMG_4911.JPG' ALT='IMG_4911.JPG'><BR>IMG_4911.JPG<br>118.38 KB</a><div class='inv'><br><a href='./images/20050722/IMG_4911.JPG' ALT='IMG_4911.JPG'>IMG_4911.JPG</a></div></td>
<td><A ID='IMG_4917.JPG' href='missiontotribulation.php?fileId=IMG_4917.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050722/IMG_4917.JPG' ALT='IMG_4917.JPG'><BR>IMG_4917.JPG<br>106.38 KB</a><div class='inv'><br><a href='./images/20050722/IMG_4917.JPG' ALT='IMG_4917.JPG'>IMG_4917.JPG</a></div></td>
<td><A ID='IMG_4919.JPG' href='missiontotribulation.php?fileId=IMG_4919.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050722/IMG_4919.JPG' ALT='IMG_4919.JPG'><BR>IMG_4919.JPG<br>102.58 KB</a><div class='inv'><br><a href='./images/20050722/IMG_4919.JPG' ALT='IMG_4919.JPG'>IMG_4919.JPG</a></div></td>
<td><A ID='IMG_4920.JPG' href='missiontotribulation.php?fileId=IMG_4920.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050722/IMG_4920.JPG' ALT='IMG_4920.JPG'><BR>IMG_4920.JPG<br>106.11 KB</a><div class='inv'><br><a href='./images/20050722/IMG_4920.JPG' ALT='IMG_4920.JPG'>IMG_4920.JPG</a></div></td>
<td><A ID='IMG_4933.JPG' href='missiontotribulation.php?fileId=IMG_4933.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050722/IMG_4933.JPG' ALT='IMG_4933.JPG'><BR>IMG_4933.JPG<br>55.32 KB</a><div class='inv'><br><a href='./images/20050722/IMG_4933.JPG' ALT='IMG_4933.JPG'>IMG_4933.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_4940.JPG' href='missiontotribulation.php?fileId=IMG_4940.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050722/IMG_4940.JPG' ALT='IMG_4940.JPG'><BR>IMG_4940.JPG<br>57.98 KB</a><div class='inv'><br><a href='./images/20050722/IMG_4940.JPG' ALT='IMG_4940.JPG'>IMG_4940.JPG</a></div></td>
<td><A ID='IMG_4941.JPG' href='missiontotribulation.php?fileId=IMG_4941.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050722/IMG_4941.JPG' ALT='IMG_4941.JPG'><BR>IMG_4941.JPG<br>37.33 KB</a><div class='inv'><br><a href='./images/20050722/IMG_4941.JPG' ALT='IMG_4941.JPG'>IMG_4941.JPG</a></div></td>
<td><A ID='IMG_4953.JPG' href='missiontotribulation.php?fileId=IMG_4953.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050722/IMG_4953.JPG' ALT='IMG_4953.JPG'><BR>IMG_4953.JPG<br>46.24 KB</a><div class='inv'><br><a href='./images/20050722/IMG_4953.JPG' ALT='IMG_4953.JPG'>IMG_4953.JPG</a></div></td>
<td><A ID='IMG_4956.JPG' href='missiontotribulation.php?fileId=IMG_4956.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050722/IMG_4956.JPG' ALT='IMG_4956.JPG'><BR>IMG_4956.JPG<br>39.42 KB</a><div class='inv'><br><a href='./images/20050722/IMG_4956.JPG' ALT='IMG_4956.JPG'>IMG_4956.JPG</a></div></td>
<td><A ID='IMG_4960.JPG' href='missiontotribulation.php?fileId=IMG_4960.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050722/IMG_4960.JPG' ALT='IMG_4960.JPG'><BR>IMG_4960.JPG<br>59.33 KB</a><div class='inv'><br><a href='./images/20050722/IMG_4960.JPG' ALT='IMG_4960.JPG'>IMG_4960.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_4968.JPG' href='missiontotribulation.php?fileId=IMG_4968.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050722/IMG_4968.JPG' ALT='IMG_4968.JPG'><BR>IMG_4968.JPG<br>48 KB</a><div class='inv'><br><a href='./images/20050722/IMG_4968.JPG' ALT='IMG_4968.JPG'>IMG_4968.JPG</a></div></td>
<td><A ID='IMG_4972.JPG' href='missiontotribulation.php?fileId=IMG_4972.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050722/IMG_4972.JPG' ALT='IMG_4972.JPG'><BR>IMG_4972.JPG<br>44.06 KB</a><div class='inv'><br><a href='./images/20050722/IMG_4972.JPG' ALT='IMG_4972.JPG'>IMG_4972.JPG</a></div></td>
<td><A ID='IMG_4974.JPG' href='missiontotribulation.php?fileId=IMG_4974.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050722/IMG_4974.JPG' ALT='IMG_4974.JPG'><BR>IMG_4974.JPG<br>73.38 KB</a><div class='inv'><br><a href='./images/20050722/IMG_4974.JPG' ALT='IMG_4974.JPG'>IMG_4974.JPG</a></div></td>
<td><A ID='IMG_4979.JPG' href='missiontotribulation.php?fileId=IMG_4979.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050722/IMG_4979.JPG' ALT='IMG_4979.JPG'><BR>IMG_4979.JPG<br>38.72 KB</a><div class='inv'><br><a href='./images/20050722/IMG_4979.JPG' ALT='IMG_4979.JPG'>IMG_4979.JPG</a></div></td>
<td><A ID='IMG_4980.JPG' href='missiontotribulation.php?fileId=IMG_4980.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050722/IMG_4980.JPG' ALT='IMG_4980.JPG'><BR>IMG_4980.JPG<br>42.89 KB</a><div class='inv'><br><a href='./images/20050722/IMG_4980.JPG' ALT='IMG_4980.JPG'>IMG_4980.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_4981.JPG' href='missiontotribulation.php?fileId=IMG_4981.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050722/IMG_4981.JPG' ALT='IMG_4981.JPG'><BR>IMG_4981.JPG<br>80.18 KB</a><div class='inv'><br><a href='./images/20050722/IMG_4981.JPG' ALT='IMG_4981.JPG'>IMG_4981.JPG</a></div></td>
<td><A ID='IMG_4982.JPG' href='missiontotribulation.php?fileId=IMG_4982.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050722/IMG_4982.JPG' ALT='IMG_4982.JPG'><BR>IMG_4982.JPG<br>128.38 KB</a><div class='inv'><br><a href='./images/20050722/IMG_4982.JPG' ALT='IMG_4982.JPG'>IMG_4982.JPG</a></div></td>
<td><A ID='IMG_4985.JPG' href='missiontotribulation.php?fileId=IMG_4985.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050722/IMG_4985.JPG' ALT='IMG_4985.JPG'><BR>IMG_4985.JPG<br>64.68 KB</a><div class='inv'><br><a href='./images/20050722/IMG_4985.JPG' ALT='IMG_4985.JPG'>IMG_4985.JPG</a></div></td>
<td><A ID='IMG_4993.JPG' href='missiontotribulation.php?fileId=IMG_4993.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050722/IMG_4993.JPG' ALT='IMG_4993.JPG'><BR>IMG_4993.JPG<br>95.62 KB</a><div class='inv'><br><a href='./images/20050722/IMG_4993.JPG' ALT='IMG_4993.JPG'>IMG_4993.JPG</a></div></td>
<td><A ID='IMG_4996.JPG' href='missiontotribulation.php?fileId=IMG_4996.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050722/IMG_4996.JPG' ALT='IMG_4996.JPG'><BR>IMG_4996.JPG<br>47.03 KB</a><div class='inv'><br><a href='./images/20050722/IMG_4996.JPG' ALT='IMG_4996.JPG'>IMG_4996.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5004.JPG' href='missiontotribulation.php?fileId=IMG_5004.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050722/IMG_5004.JPG' ALT='IMG_5004.JPG'><BR>IMG_5004.JPG<br>53.08 KB</a><div class='inv'><br><a href='./images/20050722/IMG_5004.JPG' ALT='IMG_5004.JPG'>IMG_5004.JPG</a></div></td>
<td><A ID='IMG_5013.JPG' href='missiontotribulation.php?fileId=IMG_5013.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050722/IMG_5013.JPG' ALT='IMG_5013.JPG'><BR>IMG_5013.JPG<br>54.02 KB</a><div class='inv'><br><a href='./images/20050722/IMG_5013.JPG' ALT='IMG_5013.JPG'>IMG_5013.JPG</a></div></td>
<td><A ID='IMG_5022.JPG' href='missiontotribulation.php?fileId=IMG_5022.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050722/IMG_5022.JPG' ALT='IMG_5022.JPG'><BR>IMG_5022.JPG<br>67.48 KB</a><div class='inv'><br><a href='./images/20050722/IMG_5022.JPG' ALT='IMG_5022.JPG'>IMG_5022.JPG</a></div></td>
<td><A ID='IMG_5027.JPG' href='missiontotribulation.php?fileId=IMG_5027.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050722/IMG_5027.JPG' ALT='IMG_5027.JPG'><BR>IMG_5027.JPG<br>55.85 KB</a><div class='inv'><br><a href='./images/20050722/IMG_5027.JPG' ALT='IMG_5027.JPG'>IMG_5027.JPG</a></div></td>
</tr>
</table>	</div>
</div>
</body>
</html>