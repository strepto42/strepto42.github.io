<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - 4/11/2000 - Indian Update</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="Indian Update">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="Greetings from the Other Side" href='greetingsfromtheotherside.php'>16/10/2000</a></li>
<li><a title="Another quick update from the land of rupees..." href='anotherquickupdate.php'>19/10/2000</a></li>
<li><a title="More Miscellaneous Ramblings from the Teeming Subcontinent" href='subcontinentramblings.php'>25/10/2000</a></li>
<li><div class='activemenu'>4/11/2000</div></li>
<li><a title="From the Ganges to the Taj... and beyond" href='gangestotaj.php'>18/11/2000</a></li>
<li><a title="Camels, Tigers, Elephants and Octopussies" href='camelstigersoctopussies.php'>9/12/2000</a></li>
<li><a title="Back to bloody reality" href='backtobloodyreality.php'>14/12/2000</a></li>
<li> </li><br><li>Or go back to:</li><li><a title='Travelouges from my trip through India in 2000' href="india2000.php">India 2000</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>4/11/2000</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Travel stories and pictures' href="travel.php">Travelogues</a> > <a title='Travelouges from my trip through India in 2000' href="india2000.php">India 2000</a> > <a title='Indian Update' href="indianupdate.php">4/11/2000</a>
<br><br>		


<h1>Indian Update</h1>

<p>Well here's yet another exciting update of our adventures. Perhaps not so 
exciting.</p>

<p>Hmm let's see...</p>

<p>We last left our two adventurers in the lovely mountainside town of 
Dharamsala... The next day saw the start of Diwali, which is a pretty big 
festival over here, sort of equivalent to christmas or new year's. It 
actually marks the official start of winter, and involves people prettying 
up their houses with flowers, lights and other decorations. And of course, 
fireworks.</p>

<p>Yes, you remember fireworks, those things that got banned for causing too 
much fun (and too many new yachts for eye doctors). But they're alive and 
well over here, especially the variety that go 'bang'. Actually some go 
bang, some go BANG and some are probably just dynamite with a label. Ok, I 
exaggerate. But lots of loud noises ensued in the evening, it was quite fun.</p>

<p>I managed to set fire to my shoe, not from playing with fireworks (sing-song 
voice: "Jana doesn't like fireworks" - at least when I suggest getting some 
of our own), but from not noticing that our hotel manager had placed small 
candles at the bottom of the balcony railings. Ergo I trod in one for some 
time, until I noticed the burning smell. Oh well, Volleys are cheap. And 
mine have character now.</p>

<p>After that, we commenced our exiting journey to Varanasi. This can be 
summarised thus:</p>

<p>11 hours bus ride. Arrive Delhi 4:30am or something horrid like that.<br>
3 hours waiting for train ticket office to open<br>
1 hour getting ticket<br>
4 hours waiting for train<br>
19 hours on train.</p>

<p>The train wasn't so bad actually, they have that marvel of modern invention 
over here known as the sleeper carridge. Seems Australia could do with some 
pointers.</p>

<p>So anyway, we arrived in Varanasi. Got taken to a place that sounded like 
where we wanted to stay, but turned out to be an imitator with a similar 
name. Decided once and for all never to trust and Indian taxi driver again.</p>

<p>But we were too tired to care. Decided to stay a day or so and then move, 
and see the sights etc. Varanasi is much nicer than Delhi. You can actually 
breathe here for starters. And not nearly as many people hassling you to buy 
something.</p>

<p>In fact my only complaint would be that there seems to be a whole heap of 
rotten luck floating around in the air - sunday night we inhaled a prize 
dose and Jana got sick again, quite sick in fact, and as she was getting 
very dehydrated we had to go off to hospital and get her on an IV drip. Fun 
fun fun. This of course at 4 in the morning.</p>

<p>They pumped her full of fluids and antibiotics and other such goodness, and 
she's fine now. The IV was rather painful though. But the fun and games 
didn't end there; the last night we stayed there, *I* got sick with the same 
thing, and so got the same treatment. At least we were already there.</p>

<p>So all up it's been a week of much excitement. Least the hospital had a TV. 
We spent most of the time watching "Animal Planet". I love animals, but if I 
see one more dog or horse documentary soon I'll most likely do something 
best described as 'colourful'. Suppose it could have been worse, could have 
been Indian MTV. There's some odd pop songs here. But still better than 
bOyZ2MeN or some other hideous chart crap.</p>

<p>So all is well now. Of course you can all feel free to take pity on us and 
charge our bank accounts with much booty, if you are that way inclined. Hmm, 
thought not. Ok fine, no presents for anyone. :)</p>

<p>Anyway time to sign off. With luck we'll actually get to see some of the 
city tomorrow! And then it's off to Agra and the Taj.</p>

<p>One final note to those that care - write to me you bastards!!</p>
<br><br>
All images in this gallery:<br>
<table width='800'>
<tr>
</tr>
<tr><td><A ID='F1000022.JPG' href='indianupdate.php?fileId=F1000022.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001104/F1000022.JPG' ALT='F1000022.JPG'><BR>F1000022.JPG<br>51.4 KB</a><div class='inv'><br><a href='./images/20001104/F1000022.JPG' ALT='F1000022.JPG'>F1000022.JPG</a></div></td>
<td><A ID='F1000025.JPG' href='indianupdate.php?fileId=F1000025.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001104/F1000025.JPG' ALT='F1000025.JPG'><BR>F1000025.JPG<br>74.63 KB</a><div class='inv'><br><a href='./images/20001104/F1000025.JPG' ALT='F1000025.JPG'>F1000025.JPG</a></div></td>
</tr>
</table>	</div>
</div>
</body>
</html>