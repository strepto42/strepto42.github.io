<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - About - About me</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="About me">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="truffulatree.com.au homepage" href="home.php">Home</a></li>
<li> </li><br>
<li><div class='activemenu'>About</div></li>
<li><a title="Picture galleries" href='pictures.php'>Photography</a></li>
<li><a title="Travel stories and pictures" href='travel.php'>Travelogues</a></li>
<li><a title="Mark's writing" href='written.php'>Professional Writing</a></li>
<li><a title="Programming work I've done" href='programming.php'>Programming</a></li>
<li><a title="Sounds and music" href='music.php'>Music</a></li>
<li><a title="Silly things for your amusement" href='silliness.php'>Silliness</a></li>
<li><a title="Old stuff from my site" href='archive.php'>Archive</a></li>
<li><a title="Contact me" href='contact.php'>Contact</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>About</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='About me' href="about.php">About</a>
<br><br>		<br>
Boo!<br>
<br>
<img src="images/disturbing_mark.jpg" alt="You've got nice veins!" align="right"> Well, what to say...<br>
<br>
I'm a cynical old gen Xer. Part nerd (geek and dag too, but not dork), part muso, part hippy, part grumpy old man. Thanks to my mate Nathan, I'm also a character in a <a href="http://www.digi-comic.com" target="_blank">web comic</a>. I live in <a href="images/Back_View_Small.jpg">Brisbane</a>, a big country town with delusions of grandeur.<br>
<br>
In my spare time I <a href="http://www.pacificinternationaltaekwondo.com.au/photos?id=6" target="_blank">teach</a> <a href="http://www.pacificinternationaltaekwondo.com.au" target="_blank">Taekwondo</a>, ride my bike and <a href="images/photochops/pauline_jam.png">play guitar</a>, bass and drums for a <a href="music.php">lark</a>. I've also become quite a keen <a href="pictures.php">photographer</a> since taking year off to travel around Australia. <a href="http://www.flickr.com/people/strepto42/" title="My profile on flickr" target="_blank">I shoot all sorts of things</a>, from landscapes and birds to music and martial arts.<br>
<br>
I've been in the IT caper for many years, and while I have a ton of Internet programming experience, I am also a true generalist (and their ain't that many of us left in IT). I also seem to dress a lot like Mr Sharp (my old computer teacher), but I feel this is more an example of convergent evolution than imitation.<br>
<br>
For a crust I currently program super-sekrit stuff for the QLD Government. I also used to write for <a href="http://www.australianit.news.com.au" target="_blank">The Australian</a> newspaper and <a href="http://www.dansdata.com" target="_blank">Dan's Data</a> (a hardware review site of some infamy). I'm also available for freelance copywriting work and other specialised tech writing jobs.<br>
<br>
I've debated making this website more 'employer friendly' and straight down the line, but that wouldn't be any fun at all, would it? If you would like to employ me, I promise that I can be professional from time to time. I'll even wear a shirt to work (shoes are negotiable).<br>


	</div>
</div>
</body>
</html>