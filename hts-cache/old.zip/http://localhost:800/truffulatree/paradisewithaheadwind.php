<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - 14/10/2005 - Paradise with a Headwind</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="Paradise with a Headwind">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="Greetings from a Bum" href='greetingsfromabum.php'>29/4/2005</a></li>
<li><a title="Onward" href='onward.php'>2/5/2005</a></li>
<li><a title="It's a tough life (pt 1: Bundaberg, Agnes Water and 1770)" href='itsatoughlife1.php'>17/5/2005</a></li>
<li><a title="It's a tough life (pt 2: Rockhampton, Emu Park and Great Keppel Island)" href='itsatoughlife2.php'>23/5/2005</a></li>
<li><a title="There and Back Again - a Yo-yo's Tale" href='thereandbackagain.php'>18/6/2005</a></li>
<li><a title="Platypi and Grey Nomads" href='platypiandgreynomads.php'>24/6/2005</a></li>
<li><a title="Blowing Bubbles in a Watery Tomb" href='blowingbubbles.php'>1/7/2005</a></li>
<li><a title="Pieces of History" href='piecesofhistory.php'>8/7/2005</a></li>
<li><a title="Walks and Waterfalls" href='walksandwaterfalls.php'>15/7/2005</a></li>
<li><a title="Mission to Tribulation" href='missiontotribulation.php'>22/7/2005</a></li>
<li><a title="Levity, Limestone and Lava" href='levitylimestoneandlava.php'>29/7/2005</a></li>
<li><a title="Into the Never Never" href='intothenevernever.php'>5/8/2005</a></li>
<li><a title="Slowing the pace in Darwin" href='slowingthepaceindarwin.php'>12/8/2005</a></li>
<li><a title="Blistering Barnacles and Leaping Lizards" href='leapinglizards.php'>19/8/2005</a></li>
<li><a title="Kakadu and Litchfield" href='kakadu.php'>26/8/2005</a></li>
<li><a title="Legacies of War" href='legaciesofwar.php'>2/9/2005</a></li>
<li><a title="Go West" href='gowest.php'>10/9/2005</a></li>
<li><a title="Things from Above" href='thingsfromabove.php'>16/9/2005</a></li>
<li><a title="The West Coast" href='thewestcoast.php'>23/9/2005</a></li>
<li><a title="Reefs and Red Dust" href='reefsandreddust.php'>30/9/2005</a></li>
<li><a title="The Pilbara" href='pilbara.php'>7/10/2005</a></li>
<li><div class='activemenu'>14/10/2005</div></li>
<li><a title="Down the Coral Coast" href='downthecoralcoast.php'>21/10/2005</a></li>
<li><a title="Pinnacles and Pinnipeds" href='pinnaclesandpinnipeds.php'>28/10/2005</a></li>
<li><a title="A week in Perth" href='perth.php'>4/11/2005</a></li>
<li><a title="The Southwest (from Above and Below)" href='thesouthwest.php'>11/11/2005</a></li>
<li><a title="More Heights and Depths" href='moreheightsanddepths.php'>18/11/2005</a></li>
<li><a title="Across the Nullarbor (and a bit beyond)" href='nullarbor.php'>25/11/2005</a></li>
<li><a title="Double Whammy" href='doublewhammy.php'>9/12/2005</a></li>
<li><a title="Two Cities" href='twocities.php'>19/12/2005</a></li>
<li><a title="Tassie - Part 1" href='tassie1.php'>1/1/2006</a></li>
<li><a title="Tassie - Part 2" href='tassie2.php'>7/1/2006</a></li>
<li><a title="Full Circle" href='fullcircle.php'>26/1/2006</a></li>
<li><a title="The Wrap Up" href='thewrapup.php'>23/3/2006</a></li>
<li> </li><br><li>Or go back to:</li><li><a title='Travelouges and blogs from my trip around Australia' href="nerdseyeview.php">Nerd's Eye View</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>14/10/2005</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Travel stories and pictures' href="travel.php">Travelogues</a> > <a title='Travelouges and blogs from my trip around Australia' href="nerdseyeview.php">Nerd's Eye View</a> > <a title='Paradise with a Headwind' href="paradisewithaheadwind.php">14/10/2005</a>
<br><br>		


<h1>Paradise with a Headwind</h1>

<a href="images/maps/Map051014.gif"><img src="images/maps/Map051014_sm.gif" align="right"></a>

<p>Here we are again, another week on, and as usual it's been fairly well packed with new places and sights.</p>

<p>We're back on the coast now, so most of this week has been spent lazing it up in the sun, and experiencing that horrible stress known as working on one's tan.</p>

<p>As was the plan, from Exmouth we headed over to the other side of the peninsula, to Cape Range national park, and Ningaloo Reef.</p>

<p>All up, we camped there for three days and two nights, and went for quite a few snorkels, including the slightly famous "drift snorkel" in Turquoise Bay, which is like a drift dive in that you... drift.</p>

<p>It was pretty nice there, with reasonable visibility, and a fair bit of aquatic life around. All up, I'd have to say that my snorkelling experiences on Great Keppel Island were better, but these things depend on conditions and luck, as well as location.</p>

<p>Great Keppel was calm, whereas we seem to have hit the land of wind over here. I think it's just the time of year, but we've had southerlies pretty much constantly since leaving the Broome area.</p>

<p>This makes for a nice increase in fuel consumption when driving, and if you're hapless enough to be riding your bike down the coast at this time of year, as one fellow we've met a few times is, your experience may not be all you hoped for (read: bloody annoying. Ride north at this time of year :)).</p>

<p>But getting back to the snorkelling, it was still good, even if the winds made it a tad chilly and created a few currents, thus stirring up the water a bit. We still managed to see some pretty awesome fish, and Jana has spotted two Octopi so far which I completely missed. We've also seen a turtle which was nice, and some random rays (including one massive one), but unfortunately the Mantas are hiding elsewhere at the moment. Not to worry, I'll see 'em eventually.</p>

<p>So yes, snorkelling good. Sunshine good (no burning, just tanning). Camping good. Lack of fresh water showers not so good - salt gets irritating after a few days (especially in long hair), but hey, I can hardly complain.</p>

<p>The water seems to pretty much always be a magnificent turquoise colour here, and the land is also quite picturesque, with a rugged, desolate beauty to it.</p>

<p>Whilst in the area, we explored a couple of gorges (we're pretty much over gorges these days, but they were there :)); one we did on foot and the other by boat as it's, well, flooded. On this boat trip we spotted plenty of wildlife, including an endangered Black-footed Rock Wallaby cutely poking it's head out from behind a rock.</p>

<p>There are all sorts of interesting plants and (non-aquatic) animals in the park, including, of course, lots of interesting birds. There's a bird hide in mangroves at the park's northern end, which we visited on our way out.</p>

<p>The third night there, we spent in a caravan park, near the lighthouse that's situated on the northern(ish) tip of the peninsula. We spotted whales and watched the sun go down yet again, accompanied by the usual gaggle of camera-eyed tourists. Not that I can talk of course, but it was funny when one young girl ran back to her car just as this sun was setting, declaring dejectedly that "the battery (on her video camera) went flat just as the sun started setting!!". Oh my god, and there'll never be another one either!</p>

<p>Our next destination was Coral Bay, a few hundred kilometres to the south. Supposedly a gorgeous, untouched, hidden away spot, we had high hopes for a relaxing few days, in a nice hostel perhaps, with some quality snorkelling nearby.</p>

<p>It turned out to be a little fouler than that; not actually a terrible place, but overrated. The hostel was ridiculously foul, a big square brick monstrosity looming up out of the landscape, with no character at all. Their overpriced rooms were pretty flamin' Spartan too, and the cinder-block walls made it feel rather like sleeping in a fire escape. Ho well.</p>

<p>We spent a couple of nights in the Bay (the second one in a caravan park which was much nicer), and went for a couple of chilly snorkels. The unabating southerly winds picked up, and the visibility in the water suffered as a result. The coral was also fairly badly damaged in places, thanks to an abundance of boats crunching around the area on a regular basis.</p>

<p>I can see how the place could be quite nice, especially in calm conditions, and certainly the vibe there was very relaxed, and quite pleasant, but there's not much to be had in the way of budget accommodation if you're not camping, and the backpackers there sucks. You can snorkel right off the beach though, and of course you have the same lovely turquoise water, so you can do a lot worse.</p>

<p>Nonetheless, we'd had a gutful after a few days, so we pushed on down south again.</p>

<p>We stopped off at the blowholes, near Quobba station, which was an odd place, campsite-wise. It had a very ghost-town vibe to it, and the wind was very high, so the idea of snorkelling in the bay there (which would be lovely if calm) wasn't looking so good.</p>

<p>Hence, we pushed on, and camped for free at a lovely spot called Rocky Pool, a bit further south, and inland 50kms. </p>

<p>Unfortunately, being inland didn't made a difference to the wind, but it was still a really nice spot, and it was totally worth what we paid.</p>

<p>Next day, we got an early start, and headed to Carnarvon, which is a pretty nice little town, although there's not a great deal to do there - our main motive was shopping. We did also head out to nearby Babbage Island (connected by road) and checked out the historic area, where there is a one-mile-long jetty, which is over a hundred years old, and has a cute little train that runs up and down it's length at a breakneck speed of roughly walking pace.</p>

<p>We elected to use our own legs, and explored the area, which we both agreed was quite nice. Travelling, one becomes quite a connoisseur of Interpretive Signs, and the quality and frequency of Carnarvon's deserve a "highly commended".</p>

<p>Anyway, it's made for another batch of jetty pictures, for those jetty fetishists out there.</p>

<p>We headed off, as it wasn't too late in the day, and the rest of Carnarvon held limited appeal. On the way out, we stopped at the OTC dish there for some happy snaps. The wind around the dish is magnified, and our favourite little headwind became quite intense in places.</p>

<p>Next overnight stop was planned to be Denham, but we stopped early at Hamelin Bay (in southern Shark Bay), as it was on the way, was quite nice, and is also one of the only places in the world where you can see Stromatolites (which we were going to visit anyway).</p>

<p>Stromatolites are ancient colonies of cyanobacteria (blue-green algae), which have gotten large due to a lack of predators in the area. Normally, marine life happily eats the algae, but the water in the bay there is extremely salty, so there isn't much of a marine population to do the munching.</p>

<p>Once upon a time this form of life was the dominant - and in fact the only - form of life on the planet. It is thanks to these bacteria becoming so numerous, and producing so much oxygen as a waste product, that it was possible for oxygen-breathing life as we know it to evolve.</p>

<p>This oxygen-breathing life of course promptly and happily ate the bacteria, and so large colonies like the ones in Hamelin bay are very rare.</p>

<p>After all that, you're probably excited, so go look at the pictures. They'll calm you down, because the Stromatolites are not exactly amazing to look at. But really, it depends on your attitude. I reckon they look pretty cool for a bunch of rocks made out of bacteria poo.</p>

<p>Anyway, we enjoyed our little tour of the area. The interpretive signage was also quite entertaining, with Stumpy the Stromatolite guiding the way.</p>

<p>Hamelin Bay is also noted for it's buildings made out of shell-brick. It's basically millions of cockle shells all cemented together over time, and in the past they quarried it by sawing blocks as needed. It's (perhaps amusingly) known as Coquina.</p>

<p>That pretty much brings us up to date. We carried on this morning to Denham, near Monkey Mia, and more turquoise water of course. From here we'll continue to work hard on our tans and snorkelling skills. I hope yours are coming along nicely too. :)</p>

<p>Incidentally, Jana has just about equalled my tan of 6 months within 3 weeks. It's hard work being a nerd at large.</p>

<p>Gallery selections this week are:</p>
<!-- 
<ul>
<li><a href="?fileId=IMG_0642.JPG">Cape Range NP coastline</a></li>
<li><a href="?fileId=IMG_0869.JPG">One Mile Jetty</a></li>
<li><a href="?fileId=IMG_0871.JPG">Waiting for the Yanks to come into range</a></li>
<li><a href="?fileId=IMG_0909.JPG">My hat also repels flies</a></li>
<li><a href="?fileId=IMG_0952.JPG">Stumpy Stromatolite and friends</a></li>
</ul>
 -->
<table width="800">
	<tr>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=IMG_0642.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20051014/IMG_0642.JPG' ALT='Cape Range NP coastline'><BR>Cape Range NP coastline</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=IMG_0869.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20051014/IMG_0869.JPG' ALT='One Mile Jetty'><BR>One Mile Jetty</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=IMG_0871.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20051014/IMG_0871.JPG' ALT='Waiting for the Yanks to come into range'><BR>Waiting for the Yanks to come into range</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=IMG_0909.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20051014/IMG_0909.JPG' ALT='My hat also repels flies'><BR>My hat also repels flies</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=IMG_0952.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20051014/IMG_0952.JPG' ALT='Stumpy Stromatolite and friends'><BR>Stumpy Stromatolite and friends</a>
	</td>
	</tr>
</table>

<br><br>
All images in this gallery:<br>
<table width='800'>
<tr>
</tr>
<tr><td><A ID='IMG_0613.JPG' href='paradisewithaheadwind.php?fileId=IMG_0613.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051014/IMG_0613.JPG' ALT='IMG_0613.JPG'><BR>IMG_0613.JPG<br>90.43 KB</a><div class='inv'><br><a href='./images/20051014/IMG_0613.JPG' ALT='IMG_0613.JPG'>IMG_0613.JPG</a></div></td>
<td><A ID='IMG_0616.JPG' href='paradisewithaheadwind.php?fileId=IMG_0616.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051014/IMG_0616.JPG' ALT='IMG_0616.JPG'><BR>IMG_0616.JPG<br>63.99 KB</a><div class='inv'><br><a href='./images/20051014/IMG_0616.JPG' ALT='IMG_0616.JPG'>IMG_0616.JPG</a></div></td>
<td><A ID='IMG_0617.JPG' href='paradisewithaheadwind.php?fileId=IMG_0617.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051014/IMG_0617.JPG' ALT='IMG_0617.JPG'><BR>IMG_0617.JPG<br>56.47 KB</a><div class='inv'><br><a href='./images/20051014/IMG_0617.JPG' ALT='IMG_0617.JPG'>IMG_0617.JPG</a></div></td>
<td><A ID='IMG_0621.JPG' href='paradisewithaheadwind.php?fileId=IMG_0621.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051014/IMG_0621.JPG' ALT='IMG_0621.JPG'><BR>IMG_0621.JPG<br>76.76 KB</a><div class='inv'><br><a href='./images/20051014/IMG_0621.JPG' ALT='IMG_0621.JPG'>IMG_0621.JPG</a></div></td>
<td><A ID='IMG_0627.JPG' href='paradisewithaheadwind.php?fileId=IMG_0627.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051014/IMG_0627.JPG' ALT='IMG_0627.JPG'><BR>IMG_0627.JPG<br>51.9 KB</a><div class='inv'><br><a href='./images/20051014/IMG_0627.JPG' ALT='IMG_0627.JPG'>IMG_0627.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_0633.JPG' href='paradisewithaheadwind.php?fileId=IMG_0633.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051014/IMG_0633.JPG' ALT='IMG_0633.JPG'><BR>IMG_0633.JPG<br>111.58 KB</a><div class='inv'><br><a href='./images/20051014/IMG_0633.JPG' ALT='IMG_0633.JPG'>IMG_0633.JPG</a></div></td>
<td><A ID='IMG_0634.JPG' href='paradisewithaheadwind.php?fileId=IMG_0634.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051014/IMG_0634.JPG' ALT='IMG_0634.JPG'><BR>IMG_0634.JPG<br>99.71 KB</a><div class='inv'><br><a href='./images/20051014/IMG_0634.JPG' ALT='IMG_0634.JPG'>IMG_0634.JPG</a></div></td>
<td><A ID='IMG_0637.JPG' href='paradisewithaheadwind.php?fileId=IMG_0637.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051014/IMG_0637.JPG' ALT='IMG_0637.JPG'><BR>IMG_0637.JPG<br>96.35 KB</a><div class='inv'><br><a href='./images/20051014/IMG_0637.JPG' ALT='IMG_0637.JPG'>IMG_0637.JPG</a></div></td>
<td><A ID='IMG_0641.JPG' href='paradisewithaheadwind.php?fileId=IMG_0641.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051014/IMG_0641.JPG' ALT='IMG_0641.JPG'><BR>IMG_0641.JPG<br>78.62 KB</a><div class='inv'><br><a href='./images/20051014/IMG_0641.JPG' ALT='IMG_0641.JPG'>IMG_0641.JPG</a></div></td>
<td><A ID='IMG_0642.JPG' href='paradisewithaheadwind.php?fileId=IMG_0642.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051014/IMG_0642.JPG' ALT='IMG_0642.JPG'><BR>IMG_0642.JPG<br>72.68 KB</a><div class='inv'><br><a href='./images/20051014/IMG_0642.JPG' ALT='IMG_0642.JPG'>IMG_0642.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_0643.JPG' href='paradisewithaheadwind.php?fileId=IMG_0643.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051014/IMG_0643.JPG' ALT='IMG_0643.JPG'><BR>IMG_0643.JPG<br>91.63 KB</a><div class='inv'><br><a href='./images/20051014/IMG_0643.JPG' ALT='IMG_0643.JPG'>IMG_0643.JPG</a></div></td>
<td><A ID='IMG_0644.JPG' href='paradisewithaheadwind.php?fileId=IMG_0644.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051014/IMG_0644.JPG' ALT='IMG_0644.JPG'><BR>IMG_0644.JPG<br>132.95 KB</a><div class='inv'><br><a href='./images/20051014/IMG_0644.JPG' ALT='IMG_0644.JPG'>IMG_0644.JPG</a></div></td>
<td><A ID='IMG_0645.JPG' href='paradisewithaheadwind.php?fileId=IMG_0645.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051014/IMG_0645.JPG' ALT='IMG_0645.JPG'><BR>IMG_0645.JPG<br>100.12 KB</a><div class='inv'><br><a href='./images/20051014/IMG_0645.JPG' ALT='IMG_0645.JPG'>IMG_0645.JPG</a></div></td>
<td><A ID='IMG_0648_crop.JPG' href='paradisewithaheadwind.php?fileId=IMG_0648_crop.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051014/IMG_0648_crop.JPG' ALT='IMG_0648_crop.JPG'><BR>IMG_0648_crop.JPG<br>148.94 KB</a><div class='inv'><br><a href='./images/20051014/IMG_0648_crop.JPG' ALT='IMG_0648_crop.JPG'>IMG_0648_crop.JPG</a></div></td>
<td><A ID='IMG_0657.JPG' href='paradisewithaheadwind.php?fileId=IMG_0657.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051014/IMG_0657.JPG' ALT='IMG_0657.JPG'><BR>IMG_0657.JPG<br>87.97 KB</a><div class='inv'><br><a href='./images/20051014/IMG_0657.JPG' ALT='IMG_0657.JPG'>IMG_0657.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_0659.JPG' href='paradisewithaheadwind.php?fileId=IMG_0659.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051014/IMG_0659.JPG' ALT='IMG_0659.JPG'><BR>IMG_0659.JPG<br>70.52 KB</a><div class='inv'><br><a href='./images/20051014/IMG_0659.JPG' ALT='IMG_0659.JPG'>IMG_0659.JPG</a></div></td>
<td><A ID='IMG_0662.JPG' href='paradisewithaheadwind.php?fileId=IMG_0662.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051014/IMG_0662.JPG' ALT='IMG_0662.JPG'><BR>IMG_0662.JPG<br>37.05 KB</a><div class='inv'><br><a href='./images/20051014/IMG_0662.JPG' ALT='IMG_0662.JPG'>IMG_0662.JPG</a></div></td>
<td><A ID='IMG_0666.JPG' href='paradisewithaheadwind.php?fileId=IMG_0666.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051014/IMG_0666.JPG' ALT='IMG_0666.JPG'><BR>IMG_0666.JPG<br>33.76 KB</a><div class='inv'><br><a href='./images/20051014/IMG_0666.JPG' ALT='IMG_0666.JPG'>IMG_0666.JPG</a></div></td>
<td><A ID='IMG_0673.JPG' href='paradisewithaheadwind.php?fileId=IMG_0673.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051014/IMG_0673.JPG' ALT='IMG_0673.JPG'><BR>IMG_0673.JPG<br>73.15 KB</a><div class='inv'><br><a href='./images/20051014/IMG_0673.JPG' ALT='IMG_0673.JPG'>IMG_0673.JPG</a></div></td>
<td><A ID='IMG_0675.JPG' href='paradisewithaheadwind.php?fileId=IMG_0675.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051014/IMG_0675.JPG' ALT='IMG_0675.JPG'><BR>IMG_0675.JPG<br>63.74 KB</a><div class='inv'><br><a href='./images/20051014/IMG_0675.JPG' ALT='IMG_0675.JPG'>IMG_0675.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_0677.JPG' href='paradisewithaheadwind.php?fileId=IMG_0677.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051014/IMG_0677.JPG' ALT='IMG_0677.JPG'><BR>IMG_0677.JPG<br>92.14 KB</a><div class='inv'><br><a href='./images/20051014/IMG_0677.JPG' ALT='IMG_0677.JPG'>IMG_0677.JPG</a></div></td>
<td><A ID='IMG_0678.JPG' href='paradisewithaheadwind.php?fileId=IMG_0678.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051014/IMG_0678.JPG' ALT='IMG_0678.JPG'><BR>IMG_0678.JPG<br>84.12 KB</a><div class='inv'><br><a href='./images/20051014/IMG_0678.JPG' ALT='IMG_0678.JPG'>IMG_0678.JPG</a></div></td>
<td><A ID='IMG_0680.JPG' href='paradisewithaheadwind.php?fileId=IMG_0680.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051014/IMG_0680.JPG' ALT='IMG_0680.JPG'><BR>IMG_0680.JPG<br>56.71 KB</a><div class='inv'><br><a href='./images/20051014/IMG_0680.JPG' ALT='IMG_0680.JPG'>IMG_0680.JPG</a></div></td>
<td><A ID='IMG_0684.JPG' href='paradisewithaheadwind.php?fileId=IMG_0684.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051014/IMG_0684.JPG' ALT='IMG_0684.JPG'><BR>IMG_0684.JPG<br>105.37 KB</a><div class='inv'><br><a href='./images/20051014/IMG_0684.JPG' ALT='IMG_0684.JPG'>IMG_0684.JPG</a></div></td>
<td><A ID='IMG_0693.JPG' href='paradisewithaheadwind.php?fileId=IMG_0693.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051014/IMG_0693.JPG' ALT='IMG_0693.JPG'><BR>IMG_0693.JPG<br>129.49 KB</a><div class='inv'><br><a href='./images/20051014/IMG_0693.JPG' ALT='IMG_0693.JPG'>IMG_0693.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_0696.JPG' href='paradisewithaheadwind.php?fileId=IMG_0696.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051014/IMG_0696.JPG' ALT='IMG_0696.JPG'><BR>IMG_0696.JPG<br>75.79 KB</a><div class='inv'><br><a href='./images/20051014/IMG_0696.JPG' ALT='IMG_0696.JPG'>IMG_0696.JPG</a></div></td>
<td><A ID='IMG_0707.JPG' href='paradisewithaheadwind.php?fileId=IMG_0707.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051014/IMG_0707.JPG' ALT='IMG_0707.JPG'><BR>IMG_0707.JPG<br>101.14 KB</a><div class='inv'><br><a href='./images/20051014/IMG_0707.JPG' ALT='IMG_0707.JPG'>IMG_0707.JPG</a></div></td>
<td><A ID='IMG_0712.JPG' href='paradisewithaheadwind.php?fileId=IMG_0712.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051014/IMG_0712.JPG' ALT='IMG_0712.JPG'><BR>IMG_0712.JPG<br>82.08 KB</a><div class='inv'><br><a href='./images/20051014/IMG_0712.JPG' ALT='IMG_0712.JPG'>IMG_0712.JPG</a></div></td>
<td><A ID='IMG_0716.JPG' href='paradisewithaheadwind.php?fileId=IMG_0716.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051014/IMG_0716.JPG' ALT='IMG_0716.JPG'><BR>IMG_0716.JPG<br>67.66 KB</a><div class='inv'><br><a href='./images/20051014/IMG_0716.JPG' ALT='IMG_0716.JPG'>IMG_0716.JPG</a></div></td>
<td><A ID='IMG_0718.JPG' href='paradisewithaheadwind.php?fileId=IMG_0718.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051014/IMG_0718.JPG' ALT='IMG_0718.JPG'><BR>IMG_0718.JPG<br>73.12 KB</a><div class='inv'><br><a href='./images/20051014/IMG_0718.JPG' ALT='IMG_0718.JPG'>IMG_0718.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_0730.JPG' href='paradisewithaheadwind.php?fileId=IMG_0730.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051014/IMG_0730.JPG' ALT='IMG_0730.JPG'><BR>IMG_0730.JPG<br>38.55 KB</a><div class='inv'><br><a href='./images/20051014/IMG_0730.JPG' ALT='IMG_0730.JPG'>IMG_0730.JPG</a></div></td>
<td><A ID='IMG_0731.JPG' href='paradisewithaheadwind.php?fileId=IMG_0731.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051014/IMG_0731.JPG' ALT='IMG_0731.JPG'><BR>IMG_0731.JPG<br>35 KB</a><div class='inv'><br><a href='./images/20051014/IMG_0731.JPG' ALT='IMG_0731.JPG'>IMG_0731.JPG</a></div></td>
<td><A ID='IMG_0736.JPG' href='paradisewithaheadwind.php?fileId=IMG_0736.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051014/IMG_0736.JPG' ALT='IMG_0736.JPG'><BR>IMG_0736.JPG<br>76.52 KB</a><div class='inv'><br><a href='./images/20051014/IMG_0736.JPG' ALT='IMG_0736.JPG'>IMG_0736.JPG</a></div></td>
<td><A ID='IMG_0737.JPG' href='paradisewithaheadwind.php?fileId=IMG_0737.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051014/IMG_0737.JPG' ALT='IMG_0737.JPG'><BR>IMG_0737.JPG<br>113.93 KB</a><div class='inv'><br><a href='./images/20051014/IMG_0737.JPG' ALT='IMG_0737.JPG'>IMG_0737.JPG</a></div></td>
<td><A ID='IMG_0749.JPG' href='paradisewithaheadwind.php?fileId=IMG_0749.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051014/IMG_0749.JPG' ALT='IMG_0749.JPG'><BR>IMG_0749.JPG<br>45.49 KB</a><div class='inv'><br><a href='./images/20051014/IMG_0749.JPG' ALT='IMG_0749.JPG'>IMG_0749.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_0751.JPG' href='paradisewithaheadwind.php?fileId=IMG_0751.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051014/IMG_0751.JPG' ALT='IMG_0751.JPG'><BR>IMG_0751.JPG<br>45.42 KB</a><div class='inv'><br><a href='./images/20051014/IMG_0751.JPG' ALT='IMG_0751.JPG'>IMG_0751.JPG</a></div></td>
<td><A ID='IMG_0754.JPG' href='paradisewithaheadwind.php?fileId=IMG_0754.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051014/IMG_0754.JPG' ALT='IMG_0754.JPG'><BR>IMG_0754.JPG<br>62.64 KB</a><div class='inv'><br><a href='./images/20051014/IMG_0754.JPG' ALT='IMG_0754.JPG'>IMG_0754.JPG</a></div></td>
<td><A ID='IMG_0765.JPG' href='paradisewithaheadwind.php?fileId=IMG_0765.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051014/IMG_0765.JPG' ALT='IMG_0765.JPG'><BR>IMG_0765.JPG<br>54.93 KB</a><div class='inv'><br><a href='./images/20051014/IMG_0765.JPG' ALT='IMG_0765.JPG'>IMG_0765.JPG</a></div></td>
<td><A ID='IMG_0772.JPG' href='paradisewithaheadwind.php?fileId=IMG_0772.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051014/IMG_0772.JPG' ALT='IMG_0772.JPG'><BR>IMG_0772.JPG<br>48.94 KB</a><div class='inv'><br><a href='./images/20051014/IMG_0772.JPG' ALT='IMG_0772.JPG'>IMG_0772.JPG</a></div></td>
<td><A ID='IMG_0773.JPG' href='paradisewithaheadwind.php?fileId=IMG_0773.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051014/IMG_0773.JPG' ALT='IMG_0773.JPG'><BR>IMG_0773.JPG<br>33.2 KB</a><div class='inv'><br><a href='./images/20051014/IMG_0773.JPG' ALT='IMG_0773.JPG'>IMG_0773.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_0774.JPG' href='paradisewithaheadwind.php?fileId=IMG_0774.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051014/IMG_0774.JPG' ALT='IMG_0774.JPG'><BR>IMG_0774.JPG<br>41.29 KB</a><div class='inv'><br><a href='./images/20051014/IMG_0774.JPG' ALT='IMG_0774.JPG'>IMG_0774.JPG</a></div></td>
<td><A ID='IMG_0775.JPG' href='paradisewithaheadwind.php?fileId=IMG_0775.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051014/IMG_0775.JPG' ALT='IMG_0775.JPG'><BR>IMG_0775.JPG<br>42.86 KB</a><div class='inv'><br><a href='./images/20051014/IMG_0775.JPG' ALT='IMG_0775.JPG'>IMG_0775.JPG</a></div></td>
<td><A ID='IMG_0778.JPG' href='paradisewithaheadwind.php?fileId=IMG_0778.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051014/IMG_0778.JPG' ALT='IMG_0778.JPG'><BR>IMG_0778.JPG<br>50.28 KB</a><div class='inv'><br><a href='./images/20051014/IMG_0778.JPG' ALT='IMG_0778.JPG'>IMG_0778.JPG</a></div></td>
<td><A ID='IMG_0782.JPG' href='paradisewithaheadwind.php?fileId=IMG_0782.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051014/IMG_0782.JPG' ALT='IMG_0782.JPG'><BR>IMG_0782.JPG<br>42.64 KB</a><div class='inv'><br><a href='./images/20051014/IMG_0782.JPG' ALT='IMG_0782.JPG'>IMG_0782.JPG</a></div></td>
<td><A ID='IMG_0785.JPG' href='paradisewithaheadwind.php?fileId=IMG_0785.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051014/IMG_0785.JPG' ALT='IMG_0785.JPG'><BR>IMG_0785.JPG<br>35.27 KB</a><div class='inv'><br><a href='./images/20051014/IMG_0785.JPG' ALT='IMG_0785.JPG'>IMG_0785.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_0787.JPG' href='paradisewithaheadwind.php?fileId=IMG_0787.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051014/IMG_0787.JPG' ALT='IMG_0787.JPG'><BR>IMG_0787.JPG<br>39.45 KB</a><div class='inv'><br><a href='./images/20051014/IMG_0787.JPG' ALT='IMG_0787.JPG'>IMG_0787.JPG</a></div></td>
<td><A ID='IMG_0788.JPG' href='paradisewithaheadwind.php?fileId=IMG_0788.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051014/IMG_0788.JPG' ALT='IMG_0788.JPG'><BR>IMG_0788.JPG<br>51.15 KB</a><div class='inv'><br><a href='./images/20051014/IMG_0788.JPG' ALT='IMG_0788.JPG'>IMG_0788.JPG</a></div></td>
<td><A ID='IMG_0789.JPG' href='paradisewithaheadwind.php?fileId=IMG_0789.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051014/IMG_0789.JPG' ALT='IMG_0789.JPG'><BR>IMG_0789.JPG<br>117.48 KB</a><div class='inv'><br><a href='./images/20051014/IMG_0789.JPG' ALT='IMG_0789.JPG'>IMG_0789.JPG</a></div></td>
<td><A ID='IMG_0802.JPG' href='paradisewithaheadwind.php?fileId=IMG_0802.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051014/IMG_0802.JPG' ALT='IMG_0802.JPG'><BR>IMG_0802.JPG<br>73.36 KB</a><div class='inv'><br><a href='./images/20051014/IMG_0802.JPG' ALT='IMG_0802.JPG'>IMG_0802.JPG</a></div></td>
<td><A ID='IMG_0803.JPG' href='paradisewithaheadwind.php?fileId=IMG_0803.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051014/IMG_0803.JPG' ALT='IMG_0803.JPG'><BR>IMG_0803.JPG<br>91.13 KB</a><div class='inv'><br><a href='./images/20051014/IMG_0803.JPG' ALT='IMG_0803.JPG'>IMG_0803.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_0807.JPG' href='paradisewithaheadwind.php?fileId=IMG_0807.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051014/IMG_0807.JPG' ALT='IMG_0807.JPG'><BR>IMG_0807.JPG<br>94.09 KB</a><div class='inv'><br><a href='./images/20051014/IMG_0807.JPG' ALT='IMG_0807.JPG'>IMG_0807.JPG</a></div></td>
<td><A ID='IMG_0808.JPG' href='paradisewithaheadwind.php?fileId=IMG_0808.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051014/IMG_0808.JPG' ALT='IMG_0808.JPG'><BR>IMG_0808.JPG<br>99.71 KB</a><div class='inv'><br><a href='./images/20051014/IMG_0808.JPG' ALT='IMG_0808.JPG'>IMG_0808.JPG</a></div></td>
<td><A ID='IMG_0810.JPG' href='paradisewithaheadwind.php?fileId=IMG_0810.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051014/IMG_0810.JPG' ALT='IMG_0810.JPG'><BR>IMG_0810.JPG<br>109.76 KB</a><div class='inv'><br><a href='./images/20051014/IMG_0810.JPG' ALT='IMG_0810.JPG'>IMG_0810.JPG</a></div></td>
<td><A ID='IMG_0816.JPG' href='paradisewithaheadwind.php?fileId=IMG_0816.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051014/IMG_0816.JPG' ALT='IMG_0816.JPG'><BR>IMG_0816.JPG<br>99.91 KB</a><div class='inv'><br><a href='./images/20051014/IMG_0816.JPG' ALT='IMG_0816.JPG'>IMG_0816.JPG</a></div></td>
<td><A ID='IMG_0821.JPG' href='paradisewithaheadwind.php?fileId=IMG_0821.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051014/IMG_0821.JPG' ALT='IMG_0821.JPG'><BR>IMG_0821.JPG<br>48.48 KB</a><div class='inv'><br><a href='./images/20051014/IMG_0821.JPG' ALT='IMG_0821.JPG'>IMG_0821.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_0822.JPG' href='paradisewithaheadwind.php?fileId=IMG_0822.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051014/IMG_0822.JPG' ALT='IMG_0822.JPG'><BR>IMG_0822.JPG<br>57.44 KB</a><div class='inv'><br><a href='./images/20051014/IMG_0822.JPG' ALT='IMG_0822.JPG'>IMG_0822.JPG</a></div></td>
<td><A ID='IMG_0825.JPG' href='paradisewithaheadwind.php?fileId=IMG_0825.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051014/IMG_0825.JPG' ALT='IMG_0825.JPG'><BR>IMG_0825.JPG<br>38.25 KB</a><div class='inv'><br><a href='./images/20051014/IMG_0825.JPG' ALT='IMG_0825.JPG'>IMG_0825.JPG</a></div></td>
<td><A ID='IMG_0828.JPG' href='paradisewithaheadwind.php?fileId=IMG_0828.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051014/IMG_0828.JPG' ALT='IMG_0828.JPG'><BR>IMG_0828.JPG<br>42.21 KB</a><div class='inv'><br><a href='./images/20051014/IMG_0828.JPG' ALT='IMG_0828.JPG'>IMG_0828.JPG</a></div></td>
<td><A ID='IMG_0830.JPG' href='paradisewithaheadwind.php?fileId=IMG_0830.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051014/IMG_0830.JPG' ALT='IMG_0830.JPG'><BR>IMG_0830.JPG<br>86.37 KB</a><div class='inv'><br><a href='./images/20051014/IMG_0830.JPG' ALT='IMG_0830.JPG'>IMG_0830.JPG</a></div></td>
<td><A ID='IMG_0831.JPG' href='paradisewithaheadwind.php?fileId=IMG_0831.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051014/IMG_0831.JPG' ALT='IMG_0831.JPG'><BR>IMG_0831.JPG<br>62.8 KB</a><div class='inv'><br><a href='./images/20051014/IMG_0831.JPG' ALT='IMG_0831.JPG'>IMG_0831.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_0834.JPG' href='paradisewithaheadwind.php?fileId=IMG_0834.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051014/IMG_0834.JPG' ALT='IMG_0834.JPG'><BR>IMG_0834.JPG<br>64.33 KB</a><div class='inv'><br><a href='./images/20051014/IMG_0834.JPG' ALT='IMG_0834.JPG'>IMG_0834.JPG</a></div></td>
<td><A ID='IMG_0840.JPG' href='paradisewithaheadwind.php?fileId=IMG_0840.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051014/IMG_0840.JPG' ALT='IMG_0840.JPG'><BR>IMG_0840.JPG<br>47.08 KB</a><div class='inv'><br><a href='./images/20051014/IMG_0840.JPG' ALT='IMG_0840.JPG'>IMG_0840.JPG</a></div></td>
<td><A ID='IMG_0845.JPG' href='paradisewithaheadwind.php?fileId=IMG_0845.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051014/IMG_0845.JPG' ALT='IMG_0845.JPG'><BR>IMG_0845.JPG<br>72.9 KB</a><div class='inv'><br><a href='./images/20051014/IMG_0845.JPG' ALT='IMG_0845.JPG'>IMG_0845.JPG</a></div></td>
<td><A ID='IMG_0853.JPG' href='paradisewithaheadwind.php?fileId=IMG_0853.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051014/IMG_0853.JPG' ALT='IMG_0853.JPG'><BR>IMG_0853.JPG<br>102.7 KB</a><div class='inv'><br><a href='./images/20051014/IMG_0853.JPG' ALT='IMG_0853.JPG'>IMG_0853.JPG</a></div></td>
<td><A ID='IMG_0857.JPG' href='paradisewithaheadwind.php?fileId=IMG_0857.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051014/IMG_0857.JPG' ALT='IMG_0857.JPG'><BR>IMG_0857.JPG<br>95 KB</a><div class='inv'><br><a href='./images/20051014/IMG_0857.JPG' ALT='IMG_0857.JPG'>IMG_0857.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_0859.JPG' href='paradisewithaheadwind.php?fileId=IMG_0859.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051014/IMG_0859.JPG' ALT='IMG_0859.JPG'><BR>IMG_0859.JPG<br>49.86 KB</a><div class='inv'><br><a href='./images/20051014/IMG_0859.JPG' ALT='IMG_0859.JPG'>IMG_0859.JPG</a></div></td>
<td><A ID='IMG_0860.JPG' href='paradisewithaheadwind.php?fileId=IMG_0860.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051014/IMG_0860.JPG' ALT='IMG_0860.JPG'><BR>IMG_0860.JPG<br>83.21 KB</a><div class='inv'><br><a href='./images/20051014/IMG_0860.JPG' ALT='IMG_0860.JPG'>IMG_0860.JPG</a></div></td>
<td><A ID='IMG_0864.JPG' href='paradisewithaheadwind.php?fileId=IMG_0864.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051014/IMG_0864.JPG' ALT='IMG_0864.JPG'><BR>IMG_0864.JPG<br>68.67 KB</a><div class='inv'><br><a href='./images/20051014/IMG_0864.JPG' ALT='IMG_0864.JPG'>IMG_0864.JPG</a></div></td>
<td><A ID='IMG_0865.JPG' href='paradisewithaheadwind.php?fileId=IMG_0865.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051014/IMG_0865.JPG' ALT='IMG_0865.JPG'><BR>IMG_0865.JPG<br>76.54 KB</a><div class='inv'><br><a href='./images/20051014/IMG_0865.JPG' ALT='IMG_0865.JPG'>IMG_0865.JPG</a></div></td>
<td><A ID='IMG_0867.JPG' href='paradisewithaheadwind.php?fileId=IMG_0867.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051014/IMG_0867.JPG' ALT='IMG_0867.JPG'><BR>IMG_0867.JPG<br>60.79 KB</a><div class='inv'><br><a href='./images/20051014/IMG_0867.JPG' ALT='IMG_0867.JPG'>IMG_0867.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_0868.JPG' href='paradisewithaheadwind.php?fileId=IMG_0868.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051014/IMG_0868.JPG' ALT='IMG_0868.JPG'><BR>IMG_0868.JPG<br>57.91 KB</a><div class='inv'><br><a href='./images/20051014/IMG_0868.JPG' ALT='IMG_0868.JPG'>IMG_0868.JPG</a></div></td>
<td><A ID='IMG_0869.JPG' href='paradisewithaheadwind.php?fileId=IMG_0869.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051014/IMG_0869.JPG' ALT='IMG_0869.JPG'><BR>IMG_0869.JPG<br>56.06 KB</a><div class='inv'><br><a href='./images/20051014/IMG_0869.JPG' ALT='IMG_0869.JPG'>IMG_0869.JPG</a></div></td>
<td><A ID='IMG_0871.JPG' href='paradisewithaheadwind.php?fileId=IMG_0871.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051014/IMG_0871.JPG' ALT='IMG_0871.JPG'><BR>IMG_0871.JPG<br>89.16 KB</a><div class='inv'><br><a href='./images/20051014/IMG_0871.JPG' ALT='IMG_0871.JPG'>IMG_0871.JPG</a></div></td>
<td><A ID='IMG_0875.JPG' href='paradisewithaheadwind.php?fileId=IMG_0875.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051014/IMG_0875.JPG' ALT='IMG_0875.JPG'><BR>IMG_0875.JPG<br>98.59 KB</a><div class='inv'><br><a href='./images/20051014/IMG_0875.JPG' ALT='IMG_0875.JPG'>IMG_0875.JPG</a></div></td>
<td><A ID='IMG_0878.JPG' href='paradisewithaheadwind.php?fileId=IMG_0878.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051014/IMG_0878.JPG' ALT='IMG_0878.JPG'><BR>IMG_0878.JPG<br>108.34 KB</a><div class='inv'><br><a href='./images/20051014/IMG_0878.JPG' ALT='IMG_0878.JPG'>IMG_0878.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_0879.JPG' href='paradisewithaheadwind.php?fileId=IMG_0879.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051014/IMG_0879.JPG' ALT='IMG_0879.JPG'><BR>IMG_0879.JPG<br>62.87 KB</a><div class='inv'><br><a href='./images/20051014/IMG_0879.JPG' ALT='IMG_0879.JPG'>IMG_0879.JPG</a></div></td>
<td><A ID='IMG_0880.JPG' href='paradisewithaheadwind.php?fileId=IMG_0880.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051014/IMG_0880.JPG' ALT='IMG_0880.JPG'><BR>IMG_0880.JPG<br>92.74 KB</a><div class='inv'><br><a href='./images/20051014/IMG_0880.JPG' ALT='IMG_0880.JPG'>IMG_0880.JPG</a></div></td>
<td><A ID='IMG_0882.JPG' href='paradisewithaheadwind.php?fileId=IMG_0882.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051014/IMG_0882.JPG' ALT='IMG_0882.JPG'><BR>IMG_0882.JPG<br>60.26 KB</a><div class='inv'><br><a href='./images/20051014/IMG_0882.JPG' ALT='IMG_0882.JPG'>IMG_0882.JPG</a></div></td>
<td><A ID='IMG_0887.JPG' href='paradisewithaheadwind.php?fileId=IMG_0887.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051014/IMG_0887.JPG' ALT='IMG_0887.JPG'><BR>IMG_0887.JPG<br>55.9 KB</a><div class='inv'><br><a href='./images/20051014/IMG_0887.JPG' ALT='IMG_0887.JPG'>IMG_0887.JPG</a></div></td>
<td><A ID='IMG_0891.JPG' href='paradisewithaheadwind.php?fileId=IMG_0891.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051014/IMG_0891.JPG' ALT='IMG_0891.JPG'><BR>IMG_0891.JPG<br>49.27 KB</a><div class='inv'><br><a href='./images/20051014/IMG_0891.JPG' ALT='IMG_0891.JPG'>IMG_0891.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_0892.JPG' href='paradisewithaheadwind.php?fileId=IMG_0892.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051014/IMG_0892.JPG' ALT='IMG_0892.JPG'><BR>IMG_0892.JPG<br>56.36 KB</a><div class='inv'><br><a href='./images/20051014/IMG_0892.JPG' ALT='IMG_0892.JPG'>IMG_0892.JPG</a></div></td>
<td><A ID='IMG_0893.JPG' href='paradisewithaheadwind.php?fileId=IMG_0893.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051014/IMG_0893.JPG' ALT='IMG_0893.JPG'><BR>IMG_0893.JPG<br>85.3 KB</a><div class='inv'><br><a href='./images/20051014/IMG_0893.JPG' ALT='IMG_0893.JPG'>IMG_0893.JPG</a></div></td>
<td><A ID='IMG_0897.JPG' href='paradisewithaheadwind.php?fileId=IMG_0897.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051014/IMG_0897.JPG' ALT='IMG_0897.JPG'><BR>IMG_0897.JPG<br>84.71 KB</a><div class='inv'><br><a href='./images/20051014/IMG_0897.JPG' ALT='IMG_0897.JPG'>IMG_0897.JPG</a></div></td>
<td><A ID='IMG_0900.JPG' href='paradisewithaheadwind.php?fileId=IMG_0900.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051014/IMG_0900.JPG' ALT='IMG_0900.JPG'><BR>IMG_0900.JPG<br>51.17 KB</a><div class='inv'><br><a href='./images/20051014/IMG_0900.JPG' ALT='IMG_0900.JPG'>IMG_0900.JPG</a></div></td>
<td><A ID='IMG_0901.JPG' href='paradisewithaheadwind.php?fileId=IMG_0901.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051014/IMG_0901.JPG' ALT='IMG_0901.JPG'><BR>IMG_0901.JPG<br>72.69 KB</a><div class='inv'><br><a href='./images/20051014/IMG_0901.JPG' ALT='IMG_0901.JPG'>IMG_0901.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_0903.JPG' href='paradisewithaheadwind.php?fileId=IMG_0903.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051014/IMG_0903.JPG' ALT='IMG_0903.JPG'><BR>IMG_0903.JPG<br>56.4 KB</a><div class='inv'><br><a href='./images/20051014/IMG_0903.JPG' ALT='IMG_0903.JPG'>IMG_0903.JPG</a></div></td>
<td><A ID='IMG_0904.JPG' href='paradisewithaheadwind.php?fileId=IMG_0904.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051014/IMG_0904.JPG' ALT='IMG_0904.JPG'><BR>IMG_0904.JPG<br>134.37 KB</a><div class='inv'><br><a href='./images/20051014/IMG_0904.JPG' ALT='IMG_0904.JPG'>IMG_0904.JPG</a></div></td>
<td><A ID='IMG_0906.JPG' href='paradisewithaheadwind.php?fileId=IMG_0906.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051014/IMG_0906.JPG' ALT='IMG_0906.JPG'><BR>IMG_0906.JPG<br>64.91 KB</a><div class='inv'><br><a href='./images/20051014/IMG_0906.JPG' ALT='IMG_0906.JPG'>IMG_0906.JPG</a></div></td>
<td><A ID='IMG_0909.JPG' href='paradisewithaheadwind.php?fileId=IMG_0909.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051014/IMG_0909.JPG' ALT='IMG_0909.JPG'><BR>IMG_0909.JPG<br>65.42 KB</a><div class='inv'><br><a href='./images/20051014/IMG_0909.JPG' ALT='IMG_0909.JPG'>IMG_0909.JPG</a></div></td>
<td><A ID='IMG_0910.JPG' href='paradisewithaheadwind.php?fileId=IMG_0910.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051014/IMG_0910.JPG' ALT='IMG_0910.JPG'><BR>IMG_0910.JPG<br>75.88 KB</a><div class='inv'><br><a href='./images/20051014/IMG_0910.JPG' ALT='IMG_0910.JPG'>IMG_0910.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_0911.JPG' href='paradisewithaheadwind.php?fileId=IMG_0911.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051014/IMG_0911.JPG' ALT='IMG_0911.JPG'><BR>IMG_0911.JPG<br>61.01 KB</a><div class='inv'><br><a href='./images/20051014/IMG_0911.JPG' ALT='IMG_0911.JPG'>IMG_0911.JPG</a></div></td>
<td><A ID='IMG_0913.JPG' href='paradisewithaheadwind.php?fileId=IMG_0913.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051014/IMG_0913.JPG' ALT='IMG_0913.JPG'><BR>IMG_0913.JPG<br>128.77 KB</a><div class='inv'><br><a href='./images/20051014/IMG_0913.JPG' ALT='IMG_0913.JPG'>IMG_0913.JPG</a></div></td>
<td><A ID='IMG_0914.JPG' href='paradisewithaheadwind.php?fileId=IMG_0914.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051014/IMG_0914.JPG' ALT='IMG_0914.JPG'><BR>IMG_0914.JPG<br>90.66 KB</a><div class='inv'><br><a href='./images/20051014/IMG_0914.JPG' ALT='IMG_0914.JPG'>IMG_0914.JPG</a></div></td>
<td><A ID='IMG_0929.JPG' href='paradisewithaheadwind.php?fileId=IMG_0929.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051014/IMG_0929.JPG' ALT='IMG_0929.JPG'><BR>IMG_0929.JPG<br>91.45 KB</a><div class='inv'><br><a href='./images/20051014/IMG_0929.JPG' ALT='IMG_0929.JPG'>IMG_0929.JPG</a></div></td>
<td><A ID='IMG_0947.JPG' href='paradisewithaheadwind.php?fileId=IMG_0947.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051014/IMG_0947.JPG' ALT='IMG_0947.JPG'><BR>IMG_0947.JPG<br>87.72 KB</a><div class='inv'><br><a href='./images/20051014/IMG_0947.JPG' ALT='IMG_0947.JPG'>IMG_0947.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_0948.JPG' href='paradisewithaheadwind.php?fileId=IMG_0948.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051014/IMG_0948.JPG' ALT='IMG_0948.JPG'><BR>IMG_0948.JPG<br>73.61 KB</a><div class='inv'><br><a href='./images/20051014/IMG_0948.JPG' ALT='IMG_0948.JPG'>IMG_0948.JPG</a></div></td>
<td><A ID='IMG_0950.JPG' href='paradisewithaheadwind.php?fileId=IMG_0950.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051014/IMG_0950.JPG' ALT='IMG_0950.JPG'><BR>IMG_0950.JPG<br>114.34 KB</a><div class='inv'><br><a href='./images/20051014/IMG_0950.JPG' ALT='IMG_0950.JPG'>IMG_0950.JPG</a></div></td>
<td><A ID='IMG_0951.JPG' href='paradisewithaheadwind.php?fileId=IMG_0951.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051014/IMG_0951.JPG' ALT='IMG_0951.JPG'><BR>IMG_0951.JPG<br>114.61 KB</a><div class='inv'><br><a href='./images/20051014/IMG_0951.JPG' ALT='IMG_0951.JPG'>IMG_0951.JPG</a></div></td>
<td><A ID='IMG_0952.JPG' href='paradisewithaheadwind.php?fileId=IMG_0952.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051014/IMG_0952.JPG' ALT='IMG_0952.JPG'><BR>IMG_0952.JPG<br>110.5 KB</a><div class='inv'><br><a href='./images/20051014/IMG_0952.JPG' ALT='IMG_0952.JPG'>IMG_0952.JPG</a></div></td>
<td><A ID='IMG_0955.JPG' href='paradisewithaheadwind.php?fileId=IMG_0955.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051014/IMG_0955.JPG' ALT='IMG_0955.JPG'><BR>IMG_0955.JPG<br>117.88 KB</a><div class='inv'><br><a href='./images/20051014/IMG_0955.JPG' ALT='IMG_0955.JPG'>IMG_0955.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_0959.JPG' href='paradisewithaheadwind.php?fileId=IMG_0959.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051014/IMG_0959.JPG' ALT='IMG_0959.JPG'><BR>IMG_0959.JPG<br>103.64 KB</a><div class='inv'><br><a href='./images/20051014/IMG_0959.JPG' ALT='IMG_0959.JPG'>IMG_0959.JPG</a></div></td>
<td><A ID='IMG_0961.JPG' href='paradisewithaheadwind.php?fileId=IMG_0961.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051014/IMG_0961.JPG' ALT='IMG_0961.JPG'><BR>IMG_0961.JPG<br>87.01 KB</a><div class='inv'><br><a href='./images/20051014/IMG_0961.JPG' ALT='IMG_0961.JPG'>IMG_0961.JPG</a></div></td>
<td><A ID='IMG_0967.JPG' href='paradisewithaheadwind.php?fileId=IMG_0967.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051014/IMG_0967.JPG' ALT='IMG_0967.JPG'><BR>IMG_0967.JPG<br>75.6 KB</a><div class='inv'><br><a href='./images/20051014/IMG_0967.JPG' ALT='IMG_0967.JPG'>IMG_0967.JPG</a></div></td>
<td><A ID='IMG_0973.JPG' href='paradisewithaheadwind.php?fileId=IMG_0973.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051014/IMG_0973.JPG' ALT='IMG_0973.JPG'><BR>IMG_0973.JPG<br>72 KB</a><div class='inv'><br><a href='./images/20051014/IMG_0973.JPG' ALT='IMG_0973.JPG'>IMG_0973.JPG</a></div></td>
<td><A ID='IMG_0974.JPG' href='paradisewithaheadwind.php?fileId=IMG_0974.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051014/IMG_0974.JPG' ALT='IMG_0974.JPG'><BR>IMG_0974.JPG<br>129.21 KB</a><div class='inv'><br><a href='./images/20051014/IMG_0974.JPG' ALT='IMG_0974.JPG'>IMG_0974.JPG</a></div></td>
</tr>
</table>	</div>
</div>
</body>
</html>