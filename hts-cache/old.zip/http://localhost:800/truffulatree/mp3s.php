<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - MP3s - Random mp3s</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="Random mp3s">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><div class='activemenu'>MP3s</div></li>
<li><a title="Mark Cocquio's webcam" href='webcam.php'>Webcam</a></li>
<li><a title="James Ruse Agricultural High School Class of 1992 10 year reunion" href='reunion.php'>Reunion</a></li>
<li> </li><br><li>Or go back to:</li><li><a title='Old stuff from my site' href="archive.php">Archive</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>MP3s</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Old stuff from my site' href="archive.php">Archive</a> > <a title='Random mp3s' href="mp3s.php">MP3s</a>
<br><br>		<br>
The Arnie Interview is mine and aired on <a href="http://www.2rrr.org.au" target="_blank">2rrr 88.5FM</a>, on <a href="http://streamerthebeagle.cjb.net" target="_blank">Streamer Never Sleeps</a>.<br>
<br>
Unfortunately, I've decided to remove the downloads for Bulbous Bouffant and for Hasselhoff's mighty Hot Shot City. No lawyers have come threatening yet; it's just more a bandwidth consideration thing, and given that I'm getting free hosting from Shams, plus the fact that traffic is mounting for my pictures and travel stories, I decided these two had to go.<br>
<br>
If you really really want a copy and can't find it anywhere else, please do <a href="contact.php">contact me</a>. I'm some something perfectly legal can be arranged.<br>
<br>
Lastly, please note that there is no frigging apostrophe in "MP3s". Nor should there be one in "CDs", "DVDs" or (for Christ's sake) "Photos".<br>
<br>
Sorry, had to get that off my chest...<br>
<br>
<br><br>
Files available for download:<br>
<ul class="dirlist"><li><a href="./files/mp3/ArnieInterview.mp3">ArnieInterview.mp3</a></li><li><a href="./files/mp3/Bulbous Bouffant.mp3">Bulbous Bouffant.mp3</a></li><li><a href="./files/mp3/David Hasselhoff - Hot Shot City.mp3">David Hasselhoff - Hot Shot City.mp3</a></li></ul><!-- old method
getTheFiles($file);

function getTheFiles($folder) {
	if ($handle = opendir($folder)) {
		while (false !== ($file = readdir($handle))) {
			If ($file!= "." && $file!= ".." and !is_dir($folder."/".$file)) {
				$filesize = round(filesize ($folder."/".$file)/1024,2);
				echo "<tr><td><div align='left'><A href='$corelise$folder/$file'>$file</a></div></td><td><div align='left'>$filesize KB</div></td><tr>\n";
			} else {
			If ($file!= "." && $file!= ".." and is_dir($folder."/".$file)) {
				getTheFiles($file);
			}
		}
		closedir($handle);
	}
} -->
	</div>
</div>
</body>
</html>