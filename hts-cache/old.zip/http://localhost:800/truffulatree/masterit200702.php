<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - February 2007 - Q&A letters</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="Q&A letters">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="Q&A letters" href='masterit200701.php'>January 2007</a></li>
<li><div class='activemenu'>February 2007</div></li>
<li><a title="Q&A letters" href='masterit200703.php'>March 2007</a></li>
<li><a title="Q&A letters" href='masterit200704.php'>April 2007</a></li>
<li><a title="Q&A letters" href='masterit200705.php'>May 2007</a></li>
<li><a title="Q&A letters" href='masterit200706.php'>June 2007</a></li>
<li><a title="Q&A letters" href='masterit200707.php'>July 2007</a></li>
<li> </li><br><li>Or go back to:</li><li><a title='Q&A letters from 2007' href="masterit2007.php">2007 archive</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>February 2007</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Mark's writing' href="written.php">Professional Writing</a> > <a title='My weekly Q&A column in The Australian' href="masterIT.php">MasterIT</a> > <a title='Q&A letters from 2007' href="masterit2007.php">2007 archive</a> > <a title='Q&A letters' href="masterit200702.php">February 2007</a>
<br><br>		<br>
<h2>6/2/07</h2><br>
<b>When I run Disk Cleanup In XP I am offered the option of compressing old files which I am not game to do. Is it a good idea?</b><br>
<br>
In short, probably not.<br>
<br>
The compression that we're talking about here is a feature of XP's filesystem. You can set a flag on each file which tells the operating system to squish up the file (using clever maths), making it take up less disk space, but at the expense of access speed.<br>
<br>
The files are uncompressed on the fly automatically by the operating system, so it's all transparent from the user's point of view, apart from the slower performance.<br>
<br>
I do use XP's compression, but I do so selectively, by right clicking on files or folders, then selecting properties, then clicking "advanced" and ticking the appropriate box.<br>
<br>
I only use it on files which contain lots of redundant "compressible" data (eg text files), as there's nothing to be gained by compressing files like movies or pictures, because they are already saved in a compressed format.<br>
<br>
When you run the Disk Cleanup, XP does a scan of every file's last access date, and tags any files you haven't opened for a while to be compressed. This is obviously a bit of a hit and miss approach, and it doesn't factor in binary files versus more compressible data.<br>
<br>
Hence, given the above, and the cheapness of hard drive space these days, I'd say don't tick that particular box in Disk Cleanup.<br>
<br>
Feel free to keep doing cleanups though, they're fine.<br>
<br>
<br>
<b>I have been backing up to a Maxtor external Hard drive, but have recently been having trouble with the backup software. Is there any reason why I shouldn't use the backup function in XP pro?</b><br>
<br>
There's a fairly good reason - it's abysmal.<br>
<br>
For starters, it doesn't support file compression, or optical media. It's also pretty slow. We can only hope that Vista has a better offering.<br>
<br>
As I mentioned last week, I now use a thing called Acronis Trueimage, which hits all my favourite criteria for backup software (it's fast, flexible and, most importantly, it works).<br>
<br>
You can download a trial at <a href="http://www.acronis.com" target="_blank">www.acronis.com</a>.<br>
<br>
<br>
<h2>13/2/07</h2><br>
<b>I used an external drive (Maxtor) as a back up. Without a cooling fan, it overheated - at least I guess so - and all files disappeared. I removed the hard disc and installed into my PC. Scavenger V3-1 recovered the files. Some photos appear as little images in the thumbnails, others just a sign with name of the photo. I tried to open the pictures but with out any luck. I would appreciate your advice as to how to open the photos as some are of significant sentimental value.</b><br>
<br>
It sounds a little bit grim to be honest - like some of the recovered files are corrupted.<br>
<br>
I'm not familiar with the software you used, but there are many packages out there that do the same sort of thing. I don't have a recommendation in this department, but I would try out a few others - you may have more success.<br>
<br>
It's very important to make sure that you recover the files to a different disk, and avoid writing to the damaged disks at all costs.<br>
<br>
Ultimately, if all else fails, your best bet may be to get in touch with a dedicated data recovery business. They do tend to charge a fair bit, but they will have professional tools and may be able to recover more data for you.<br>
<br>
<br>
<b>On each start up, a window appears, headed RUNDLL., with the message: Error loading cmicnfg.cpl, The specified module could not be found. Whilst it does not appear to affect the operation of my computer, running Windows XP Home edition, it is a nuisance necessitating its removal each time. Could you please advise how to remove it permanently?</b><br>
<br>
The error in question is coming up because Windows is configured to run that particular program on startup, but it can't find it (for your information, it's a file associated with your sound card drivers).<br>
<br>
Luckily, there's an easy fix. All you need to do is remove the command which tries to start that program from your registry.<br>
<br>
This may sound scary, but it's quite straightforward, and there are quite a few tools out there for managing the Windows startup list without having to edit your registry at all (as they do it for you).<br>
<br>
One such program is even built in to Windows. You can fire it up by by selecting "run program" from the start menu (or pressing Windows-R), and then typing in "msconfig".<br>
<br>
Once it fires up, select the "startup" tab and un-tick the box next to cmicnfg.cpl.<br>
<br>
There's also a lengthy discussion of the exact problem you're experiencing at http://tinyurl.com/8ctcw<br>
<br>
<br>
<h2>20/2/07</h2><br>
<b>On each start up, a window appears, headed RUNDLL., with the message: Error loading cmicnfg.cpl, The specified module could not be found. Whilst it does not appear to affect the operation of my computer, running Windows XP Home edition, it is a nuisance necessitating its removal each time. Could you please advise how to remove it permanently?</b><br>
<br>
The error in question is coming up because Windows is configured to run that particular program on startup, but it can't find it (for your information, it's a file associated with your sound card drivers).<br>
<br>
Luckily, there's an easy fix. All you need to do is remove the command which tries to start that program from your registry.<br>
<br>
This may sound scary, but it's quite straightforward, and there are quite a few tools out there for managing the Windows startup list without having to edit your registry at all (as they do it for you).<br>
<br>
One such program is even built in to Windows. You can fire it up by by selecting "run program" from the start menu (or pressing Windows-R), and then typing in "msconfig".<br>
<br>
Once it fires up, select the "startup" tab and un-tick the box next to cmicnfg.cpl.<br>
<br>
There's also a lengthy discussion of the exact problem you're experiencing at http://tinyurl.com/8ctcw<br>
<br>
<br>
<b>After several crashes this year I ended up with 2 seperate Outlook .pst files - one that predates my last crash, and one since the crash. I can view the old one by copying it into the right directory, but is there any way I can merge the 2 so I have my last 7 years of emails all in one place?</b><br>
<br>
Yep, it's quite easy. Have a look in the file menu - there should be an option to open a new PST file. Once you do that, you'll see two separate sets of personal folders in Outlook.<br>
<br>
From there it's simply a case of manually dragging the folders across. It's a bit time consuming, but afterwards you'll have everything in the right place.<br>
<br>
<br>
<h2>27/2/07</h2><br>
<b>I've just read your reply to a reader who's in a similar predicament so I wondered if you could give me some advice. The hard drive in my Toshiba laptop packed up a few weeks ago. I swapped it out with a new one, but I'd like to recover my photos from the old drive, and have few ideas how to go about it. I read somewhere that you can buy a kind of 'caddy' device that will accept an internal drive from a laptop and connect it via a USB port, and that it may then be possible to use proprietary software to retrieve files from it. I don't have the cash to employ the services of a recovery specialist, so am wondering where to go, and what to ask for to get a device for connecting the removed drive etc. Also, which data recovery software would you suggest for the task?</b><br>
<br>
There are two problems to solve here; one is getting the old drive connected to the computer, and the other is recovering the data.<br>
<br>
I can really only help with the first problem, as I've never actually tried to use any data recovery software (having smugly restored from backup instead whenever a crisis occurred).<br>
<br>
Start with Google, and don't be afraid to try a few different programs. There are certainly many of them out there, of varying qualities, so you will probably have to play with more than one.<br>
<br>
The main thing to watch is that you don't write to the damaged disk, or you'll just make the problem worse.<br>
<br>
In regards to getting the hard disk hooked up, there are two ways you can go.<br>
<br>
First, you can use a simple USB adaptor (like this one: http://tinyurl.com/2dv5mv) to connect the bare drive to a USB port.<br>
<br>
The only problem you may encounter with this approach is that some recovery software packages may try to access the hardware directly, and so won't work properly over a USB connection.<br>
<br>
Your other option is to gain access to a desktop computer, and use an adaptor (like this one: http://tinyurl.com/2xmggg) to plug in the laptop hard drive directly.<br>
<br>
(By the way, both of those links go to Auspcmarket.com.au, a local supplier, but such items are also quite common on eBay for a few dollars less, if you don't care about after sales support and so on).<br>
<br>
Unfortunately though, at the end of the day, there are no really easy solutions here. Once a hard drive dies, there's only so much that a non-professional can do. Good luck!<br>
<br>
<i><p>Did the information on this page help you? Entertain you? Bore you? <a href="contact.php?subject=MasterIT">Drop me a line</a>.</p>

<p>If you're feeling particularly generous, you can even <a href="buypics.php">click here to send me some dot-com riches</a>. Think of it as online busking.</i></p>
	</div>
</div>
</body>
</html>