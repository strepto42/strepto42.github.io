<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - April 2005 - Q&A letters</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="Q&A letters">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="Q&A letters" href='masterit200501.php'>January 2005</a></li>
<li><a title="Q&A letters" href='masterit200502.php'>February 2005</a></li>
<li><a title="Q&A letters" href='masterit200503.php'>March 2005</a></li>
<li><div class='activemenu'>April 2005</div></li>
<li><a title="Q&A letters" href='masterit200505.php'>May 2005</a></li>
<li><a title="Q&A letters" href='masterit200506.php'>June 2005</a></li>
<li><a title="Q&A letters" href='masterit200507.php'>July 2005</a></li>
<li><a title="Q&A letters" href='masterit200508.php'>August 2005</a></li>
<li><a title="Q&A letters" href='masterit200509.php'>September 2005</a></li>
<li><a title="Q&A letters" href='masterit200510.php'>October 2005</a></li>
<li><a title="Q&A letters" href='masterit200511.php'>November 2005</a></li>
<li><a title="Q&A letters" href='masterit200512.php'>December 2005</a></li>
<li> </li><br><li>Or go back to:</li><li><a title='Q&A/MasterIT letters from 2005' href="masterit2005.php">2005 archive</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>April 2005</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Mark's writing' href="written.php">Professional Writing</a> > <a title='My weekly Q&A column in The Australian' href="masterIT.php">MasterIT</a> > <a title='Q&A/MasterIT letters from 2005' href="masterit2005.php">2005 archive</a> > <a title='Q&A letters' href="masterit200504.php">April 2005</a>
<br><br>		<br>
<h2>5/4/05</h2><br>
<b>Under Windows 2000 I used to be able to write my project files to a CD, as a precaution against virus troubles. When I wanted to revise a file, I would recall it, modify it and return the modified file to the CD. Now, under Windows XP, if I write to a CD, the file is automatically marked Write Protect. When I modify the file, I can't rewrite to the CD; instead, I have to change the file's name to get it onto the CD, and I can't delete the old file, or change its Write Protect status.  Is there any way I can change this?</b><br>
<br>
There certainly is. Technically, CD-Rs can only ever be written to once (hence the write protect status), but you can install special software, known as packet writing software, which lets the computer do the writing in little dribs and drabs. All the old versions of your files are still on the disc, but only the latest versions are visible.<br>
<br>
Windows doesn't actually come with any packet writing software, so I suspect you had installed some third party software on top of Windows 2000. Often, such software comes bundled with the burner.<br>
<br>
You have a couple of options. To make things like they were, you can reinstall the original packet writing software, or source a new version (Google will help here). If you're reinstalling, make sure the program is compatible with XP first.<br>
<br>
The second option is to use a standard CD burning program (like Nero) to write what's called a multisession disc, which allows you to write to a disc multiple times until it's full, using a similar (but different) technique to the packet writing software.<br>
<br>
This can be a bit unwieldy though, and it all comes down to how often you update the files. If you want to write smaller files quite frequently, you'll be better off with packet writing software. If, however, you just want to back up a whole bunch of things at once, and only do it once a day or so, just using a multisession disc will be fine.<br>
<br>
Assuming your writer supports them (and almost all do), it's also probably a good idea to invest in some CD-RW (rewritable) discs. These can be erased and reused quite a few times (hundreds if you keep them clean and scratch-free), and don't cost much more than regular blanks.<br>
<br>
<br>
<h2>12/4/05</h2><br>
<b>My dilemma is to do with leaving AOL. I finally gave up on it and when a friend told me about Gmail (I'm sure you know it, but just in case I'm sending you an invitation - clever marketing ploy making it invitation only). I also downloaded and began using Firefox to access the internet. That's the preamble... here's the question: Often when I click on a link I get the message "could not perform this operation because they default mail client is not properly installed". The only way I can access the link is to type it in and then hit "Go". Obviously this is a pain. I'm clueless... is this an AOL retaliation, Microsoft getting nervous that Google is going to take over the world? Anti Mozilla warfare, or what?</b><br>
<br>
Thanks for the Gmail invite. Of course, being the professional nerd that I am, I already have an account (not that I use it much, but it's a useful spam filter).<br>
<br>
It is indeed clever marketing - but it also makes sense from a technical standpoint. By only allowing so many invites per month, per user, they can control the growth of the system, and make sure it performs under load in controlled circumstances, before they let every man and his 12 year old sign up. They're clever people, those Google chaps.<br>
<br>
Incidentally, if any readers would like an invite, write me an interesting question and I'll throw one in with the reply.<br>
<br>
As far as the link clicking issue goes, I'd say it's just bad luck, rather than a conspiracy. But, of course, I might be part of the conspiracy.<br>
<br>
You can try changing the default program for hyperlinks - go to control panel, and open add/remove programs, then click the "set program access and defaults" button. Open up "custom", and make sure Mozilla is selected.<br>
<br>
Failing the above, try uninstalling and reinstalling Firefox.<br>
<br>
<br>
<b>I have received a "Windows installer error 1635" when trying to install a program. I tried unsuccessfully to navigate my way into Microsoft Help so was hoping you might be able to suggest what I need to do to fix this.</b><br>
<br>
The error is actually coming from an installer program, rather than from Windows itself. Unfortunately this makes it a bit harder to track down.<br>
<br>
Have a look at http://tinyurl.com/5k8kz - it has a link to a program that might help.<br>
<br>
<br>
<h2>19/4/05</h2><br>
<b>I recently installed Windows XP Home. When I enter My Computer and access a particular list of files from a data CD they always show as Icons. By clicking on View I can change to List, which I prefer, but I have not found a way to make that the default view. Any suggestions?</b><br>
<br>
This shouldn't be too hard to fix. Open My Computer, and pick a random folder, then set the view to the way you like it. Next, select the Tools menu, then folder options, and then click the 'view' tab. Now click the "Apply to all folders" button up the top.<br>
<br>
Note that this will overwrite any specific views for folders you already have defined, but it will also set the default view for the future.<br>
<br>
You might also want to tick the checkbox next to "remember each folder's view settings" (down a bit in the advanced settings list). This will let you customise folder views independently of each other in the future.<br>
<br>
Note that not all CDs will let you specify a default view, as Windows uses a hidden file in each folder to store this information, and if a CD has this file already present, it may override your settings. In reality this is fairly unlikely to be the case though, as few CDs will have this file.<br>
<br>
<br>
<b>I have run a scan with Ad-aware and it has come up with 1. One Object "DSS Agent" of type "Registry key", 2. 13 "Tracking cookies" of category "Data Miners". One of them has the comment www.searchtraffic.com. Unfortunately RTFMing doesn't explain whether they are good, bad, or indifferent, and I would like to be sure that Ad-aware is not being over-zealous before killing them. Can you enlighten me? Should I quarantine them or get rid of them altogether?</b><br>
<br>
You can safely kill anything that Ad-aware flags - I've never had it remove anything important (caveat emptor of course!).<br>
<br>
At any rate, Ad-aware's default action is to quarantine rather than delete, so in the unlikely event that you do nuke something important you can always get it back.<br>
<br>
While you're at it, you might also want to make sure you have the latest version of Ad-aware, as they regularly update the main program as well as the data files. Older versions of the program don't support the newer data files, so if you're updating the data files and there never seems to be a new set, this is probably what's happening. Check out http://tinyurl.com/yu6cm for the latest version.<br>
<br>
<br>
<h2>26/4/05</h2><br>
<b>Dear Master, I've just purchased a new laptop, which supposedly came supplied with a 60Gb hard drive. Windows tells me otherwise though, stating that the total capacity of C is only 55.9Gb. Have I been ripped off?</b><br>
<br>
In a sense, yes you have, in exactly the same way thousands of people have been by hard drive manufacturers' marketing people over the years.<br>
<br>
The difference comes from how you define a gigabyte. Hard disc manufacturers define 60Gb as 60 000 megabytes, or 60 000 000 bytes. Windows calculates the figure differently, as technically a megabyte is 1024 kilobytes, not 1000. Likewise, a gigabyte is 1024 megabytes (or, 1 073 741 824 bytes - 1024 times 1024 times 1024).<br>
<br>
(if you think that's hard to follow, try typing it)<br>
<br>
There is a school of thought that says that the kilo, mega and giga prefixes are strictly for multiples of 1000, and subscribers to that school suggest new terms - kibibyte, mebibyte and gibibyte - for the 1024 multiples, apparently in aid of simplifying life. I am not making this up.<br>
<br>
Meanwhile, despite Google helpfully siding with the consumer and defining gigabytes and gibibytes as equal (just type in "gibibytes in a gigabyte"), hard drive manufacturers continue to milk the buyer with their difference of definition.<br>
<br>
If you think being ripped off 4Gb on a 60Gb drive isn't fun, the difference gets worse as you go up in size. A system with a pair of so-called 250Gb drives in it only has 465.67 real gigabytes of storage.<br>
<br>
<br>
<b>On some web sites one finds links such as "e-mail this" or whatever, and when one clicks on the link a circle with a slash through it appears and the link will not respond. The symbol is a bit like the "no entry" road signs. Does the symbol mean that the link cannot be accessed for some obscure technical reasons or is there something in my computer (Windows XP Home) preventing the link being accessed by me.</b><br>
<br>
Generally speaking, the little "no" symbol (circle with a slash) only tends to appear when you drag something to somewhere it shouldn't/can't be. Could it be that you're clicking and dragging very slightly at the same time?<br>
<br>
Short of that, I'm not sure why you're seeing it on links - it generally doesn't appear on web pages that much, and doesn't tend to have any normal usage apart the above.<br>
<br>
Send queries and dead marketing people who work for hard drive manufacturers to <a href="contact.php?subject=MasterIT">(the masterit contact email address)</a><br>
<br>
<i><p>Did the information on this page help you? Entertain you? Bore you? <a href="contact.php?subject=MasterIT">Drop me a line</a>.</p>

<p>If you're feeling particularly generous, you can even <a href="buypics.php">click here to send me some dot-com riches</a>. Think of it as online busking.</i></p>
	</div>
</div>
</body>
</html>