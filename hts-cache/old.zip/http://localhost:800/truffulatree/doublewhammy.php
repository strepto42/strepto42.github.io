<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - 9/12/2005 - Double Whammy</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="Double Whammy">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="Greetings from a Bum" href='greetingsfromabum.php'>29/4/2005</a></li>
<li><a title="Onward" href='onward.php'>2/5/2005</a></li>
<li><a title="It's a tough life (pt 1: Bundaberg, Agnes Water and 1770)" href='itsatoughlife1.php'>17/5/2005</a></li>
<li><a title="It's a tough life (pt 2: Rockhampton, Emu Park and Great Keppel Island)" href='itsatoughlife2.php'>23/5/2005</a></li>
<li><a title="There and Back Again - a Yo-yo's Tale" href='thereandbackagain.php'>18/6/2005</a></li>
<li><a title="Platypi and Grey Nomads" href='platypiandgreynomads.php'>24/6/2005</a></li>
<li><a title="Blowing Bubbles in a Watery Tomb" href='blowingbubbles.php'>1/7/2005</a></li>
<li><a title="Pieces of History" href='piecesofhistory.php'>8/7/2005</a></li>
<li><a title="Walks and Waterfalls" href='walksandwaterfalls.php'>15/7/2005</a></li>
<li><a title="Mission to Tribulation" href='missiontotribulation.php'>22/7/2005</a></li>
<li><a title="Levity, Limestone and Lava" href='levitylimestoneandlava.php'>29/7/2005</a></li>
<li><a title="Into the Never Never" href='intothenevernever.php'>5/8/2005</a></li>
<li><a title="Slowing the pace in Darwin" href='slowingthepaceindarwin.php'>12/8/2005</a></li>
<li><a title="Blistering Barnacles and Leaping Lizards" href='leapinglizards.php'>19/8/2005</a></li>
<li><a title="Kakadu and Litchfield" href='kakadu.php'>26/8/2005</a></li>
<li><a title="Legacies of War" href='legaciesofwar.php'>2/9/2005</a></li>
<li><a title="Go West" href='gowest.php'>10/9/2005</a></li>
<li><a title="Things from Above" href='thingsfromabove.php'>16/9/2005</a></li>
<li><a title="The West Coast" href='thewestcoast.php'>23/9/2005</a></li>
<li><a title="Reefs and Red Dust" href='reefsandreddust.php'>30/9/2005</a></li>
<li><a title="The Pilbara" href='pilbara.php'>7/10/2005</a></li>
<li><a title="Paradise with a Headwind" href='paradisewithaheadwind.php'>14/10/2005</a></li>
<li><a title="Down the Coral Coast" href='downthecoralcoast.php'>21/10/2005</a></li>
<li><a title="Pinnacles and Pinnipeds" href='pinnaclesandpinnipeds.php'>28/10/2005</a></li>
<li><a title="A week in Perth" href='perth.php'>4/11/2005</a></li>
<li><a title="The Southwest (from Above and Below)" href='thesouthwest.php'>11/11/2005</a></li>
<li><a title="More Heights and Depths" href='moreheightsanddepths.php'>18/11/2005</a></li>
<li><a title="Across the Nullarbor (and a bit beyond)" href='nullarbor.php'>25/11/2005</a></li>
<li><div class='activemenu'>9/12/2005</div></li>
<li><a title="Two Cities" href='twocities.php'>19/12/2005</a></li>
<li><a title="Tassie - Part 1" href='tassie1.php'>1/1/2006</a></li>
<li><a title="Tassie - Part 2" href='tassie2.php'>7/1/2006</a></li>
<li><a title="Full Circle" href='fullcircle.php'>26/1/2006</a></li>
<li><a title="The Wrap Up" href='thewrapup.php'>23/3/2006</a></li>
<li> </li><br><li>Or go back to:</li><li><a title='Travelouges and blogs from my trip around Australia' href="nerdseyeview.php">Nerd's Eye View</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>9/12/2005</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Travel stories and pictures' href="travel.php">Travelogues</a> > <a title='Travelouges and blogs from my trip around Australia' href="nerdseyeview.php">Nerd's Eye View</a> > <a title='Double Whammy' href="doublewhammy.php">9/12/2005</a>
<br><br>		


<h1>Double Whammy</h1>

<a href="images/maps/Map051209.gif"><img src="images/maps/Map051209_sm.gif" align="right"></a>

<p>Well, as you may have noticed, I skipped a week. There is therefore quite a bit to relate!</p>

<p>Last time I signed off we hadn't even reached Adelaide. Now I'm sitting in Melbourne - how geography flies! :)</p>

<p>Winding back the clock, two weeks ago we were in Hawker, just having left the Flinders Ranges. The next day we drove on towards Adelaide, stopping off a couple of times.</p>

<p>The first stop was at a random toy museum that we happened upon as we drove through a small town called Wilmington. It was full of lovely things, from the old to the relatively new - pictures abound.</p>

<p>The second stop off was for a gorge walk in the Mount Remarkable National Park. Whilst very pleasant, it was quite an up and down drive to get in and out, and shortly afterwards the car started making it's bad noise again. Some oil silenced it, but I resolved to get it looked at properly in Adelaide.</p>

<p>So, after an overnight stay in Melrose, we pushed on to Adelaide. We were nearly at the caravan park when the car started to make the alarming noise again.</p>

<p>The next day I toured a few local mechanics, and they all looked grim. One actually did the "sucking air in through his teeth" thing. The consensus - Bad Noise. Need new engine.</p>

<p>Previous to this, I'd thought it was a problem with a valve lifter not working properly. This can happen in old Subaru engines, but alas it wasn't quite the case. In the end, it turned out that a valve guide had come loose (the sleeve around the valve stem itself). This was moving around, hence the noise coming and going with temperature and oil level. In it's last incarnation the problem had gotten to the stage where the valve became completely stuck, and the piston was hitting it.</p>

<p>So... an alarming noise - but perhaps not new engine time yet. Unfortunately when they opened up the engine to fix the above problem (well, to discover it actually), it turned out that another cylinder had issues - to the point of being full of oil. This revealed where my oil had been going all this time (the car had been quite oil-thirty for ages), but unfortunately it made fixing the valve problem a bit uneconomical.</p>

<p>The conclusion of all this technical engine nonsense is that my car now has a "new" second hand engine in it. The upshot is that it's only done 45,000kms, the downside is that I'm $3700 poorer. So bloody well check out some ads, people!</p>

<p>Anyway, the mechanics were actually pretty good to me, and got the new engine in really quickly. All up, we spent 5 nights in Adelaide; it's a very pretty city. The whole CBD is surrounded by parkland, and the Torrens River runs through the northern bit. There are bike paths all along it too, so it's easy to get about.</p>

<p>We explored a little bit, and visited the museum on the fifth day. The displays there are really quite good - they have a slightly elderly yet awesome bird section.</p>

<p>On the sixth day, I picked up the car, which thankfully ran nicely, and we headed into town to check out the art Gallery before leaving. Despite having just spent a crapload of money, I was in a fairly good mood, as the problem was sorted, and NRMA had just agreed to pay our accommodation for the week too.</p>

<p>The art gallery was really nice; it's also well worth a visit if you're in town. Unfortunately, I wouldn't recommend you ride your bike in to visit it, as when we left the gallery our two bikes, chained to a pole, had become one. Mine was stolen, Jana's being left behind due to it being somewhat less valuable.</p>

<p>So, all up, Adelaide wasn't terribly kind to me. I wish broken bones, intestinal cancer and a foul pox upon the oxygen thief who pinched my bike just in time for xmas and my departure from Adelaide. With luck, the insurance company won't ream me too much when it comes to organising a replacement (a process which is in progress), although I'll be down $300 due to the excess at the very least. Fan-tastic.</p>

<p>Anyway, enough with the double whammies. We moved on to Glenelg that night (Adelaide's palindrome suburb), had dinner, and then headed out of town to the Adelaide Hills, where we spent the night before leaving the next day. </p>

<p>It was a lovely drive through the hills and small towns, and we crossed the miserable remnants of the Murray River at Murray Bend. Eventually we ended up on the shores of Lake Albert for the night, in the town of Meningie. We had a pleasant night until a bunch of local kids having a party parked next to the caravan park and proceeded to drink and carry on until the wee small hours. Such is life.</p>

<p>From there we moved on to the coast, or at least near to the coast, and we dove along beside the Coorong, which is the long body of water separated from the sea by a big sand bar that runs from the Murray Mouth to Salt Creek. It's an interesting place, and the wind and greyness of the day seemed appropriate.</p>

<p>Then we turned inland, and zigzagged our way to Naracoorte, near the Victorian border. We checked out a local wetland, but it wasn't terribly wet, and the wind was up, so we moved on, into Victoria, and another time zone.</p>

<p>After driving along various Victorian country roads, evoking memories of Mad Max, we ended up at Halls Gap in the Grampians, where we spent a night. The following day we went on a few walks, and visited a couple of lookouts and Mackenzie Falls.</p>

<p>The area is full of spectacular scenery, and the weather was most pleasant - cool yet sunny, and, relatively speaking, no flies to speak of at all. This was a nice change, given the infestations of the little buggers present in some of the places we've been.</p>

<p>Jana then chauffeured me out of the park, and we headed south to the Great Ocean Road. We spent the first night in Warrnambool, and then drove along the coast, stopping off to take in the spectacular scenery, which includes various lookouts, and of course the famous 12 Apostles, only 11 of which still stand after one collapsed earlier this year.</p>

<p>We got there with perfect timing, as there was a storm front moving in, and half way back to the car the wind picked up, the temperature dropped, and it pelted with rain. The Melbourne weather had begun!</p>

<p>We drove on through the rain to The Otway National Park, and stayed in the caravan park at Cape Otway. After an interesting tour of the local lighthouse the next morning, we pushed on, taking in the rest of the Great Ocean Road.</p>

<p>One or two stops later, after taking in some fantastic views, some fantastic corners, and a couple of photographically obliging koalas, we arrived at long last in Melbourne.</p>

<p>My old friend Michael put us up last night, and Jana has headed off to her sister Hildy's place today, whilst I'm off to Brisvegas tomorrow for a quick visit.</p>
 
<p>Till next time enjoy the latest pics:</p>

<table width="800">
	<tr>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=IMG_3792.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3792.JPG' ALT='Vicki lords it over Central Adelaide'><BR>Vicki lords it over Central Adelaide</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=IMG_3827.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3827.JPG' ALT='Not Melbourne, but Glenelg (of an evening)'><BR>Not Melbourne, but Glenelg (of an evening)</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=IMG_3836.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3836.JPG' ALT='City of Churches indeed'><BR>City of Churches indeed</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=IMG_3905.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3905.JPG' ALT='The Grampians'><BR>The Grampians</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=IMG_4078.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_4078.JPG' ALT='The 12 Apostles, now 11'><BR>The 12 Apostles, now 11</a>
	</td>
	</tr>
</table>

<br><br>
All images in this gallery:<br>
<table width='800'>
<tr>
</tr>
<tr><td><A ID='IMG_3638.JPG' href='doublewhammy.php?fileId=IMG_3638.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3638.JPG' ALT='IMG_3638.JPG'><BR>IMG_3638.JPG<br>115.94 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3638.JPG' ALT='IMG_3638.JPG'>IMG_3638.JPG</a></div></td>
<td><A ID='IMG_3640.JPG' href='doublewhammy.php?fileId=IMG_3640.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3640.JPG' ALT='IMG_3640.JPG'><BR>IMG_3640.JPG<br>114.85 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3640.JPG' ALT='IMG_3640.JPG'>IMG_3640.JPG</a></div></td>
<td><A ID='IMG_3642.JPG' href='doublewhammy.php?fileId=IMG_3642.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3642.JPG' ALT='IMG_3642.JPG'><BR>IMG_3642.JPG<br>90.75 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3642.JPG' ALT='IMG_3642.JPG'>IMG_3642.JPG</a></div></td>
<td><A ID='IMG_3643.JPG' href='doublewhammy.php?fileId=IMG_3643.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3643.JPG' ALT='IMG_3643.JPG'><BR>IMG_3643.JPG<br>95.41 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3643.JPG' ALT='IMG_3643.JPG'>IMG_3643.JPG</a></div></td>
<td><A ID='IMG_3645.JPG' href='doublewhammy.php?fileId=IMG_3645.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3645.JPG' ALT='IMG_3645.JPG'><BR>IMG_3645.JPG<br>104.1 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3645.JPG' ALT='IMG_3645.JPG'>IMG_3645.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_3649.JPG' href='doublewhammy.php?fileId=IMG_3649.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3649.JPG' ALT='IMG_3649.JPG'><BR>IMG_3649.JPG<br>62.36 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3649.JPG' ALT='IMG_3649.JPG'>IMG_3649.JPG</a></div></td>
<td><A ID='IMG_3652.JPG' href='doublewhammy.php?fileId=IMG_3652.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3652.JPG' ALT='IMG_3652.JPG'><BR>IMG_3652.JPG<br>40.22 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3652.JPG' ALT='IMG_3652.JPG'>IMG_3652.JPG</a></div></td>
<td><A ID='IMG_3653.JPG' href='doublewhammy.php?fileId=IMG_3653.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3653.JPG' ALT='IMG_3653.JPG'><BR>IMG_3653.JPG<br>42.72 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3653.JPG' ALT='IMG_3653.JPG'>IMG_3653.JPG</a></div></td>
<td><A ID='IMG_3654.JPG' href='doublewhammy.php?fileId=IMG_3654.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3654.JPG' ALT='IMG_3654.JPG'><BR>IMG_3654.JPG<br>68.33 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3654.JPG' ALT='IMG_3654.JPG'>IMG_3654.JPG</a></div></td>
<td><A ID='IMG_3655.JPG' href='doublewhammy.php?fileId=IMG_3655.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3655.JPG' ALT='IMG_3655.JPG'><BR>IMG_3655.JPG<br>36.44 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3655.JPG' ALT='IMG_3655.JPG'>IMG_3655.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_3656.JPG' href='doublewhammy.php?fileId=IMG_3656.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3656.JPG' ALT='IMG_3656.JPG'><BR>IMG_3656.JPG<br>77.53 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3656.JPG' ALT='IMG_3656.JPG'>IMG_3656.JPG</a></div></td>
<td><A ID='IMG_3657.JPG' href='doublewhammy.php?fileId=IMG_3657.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3657.JPG' ALT='IMG_3657.JPG'><BR>IMG_3657.JPG<br>79.47 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3657.JPG' ALT='IMG_3657.JPG'>IMG_3657.JPG</a></div></td>
<td><A ID='IMG_3658.JPG' href='doublewhammy.php?fileId=IMG_3658.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3658.JPG' ALT='IMG_3658.JPG'><BR>IMG_3658.JPG<br>57.68 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3658.JPG' ALT='IMG_3658.JPG'>IMG_3658.JPG</a></div></td>
<td><A ID='IMG_3659.JPG' href='doublewhammy.php?fileId=IMG_3659.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3659.JPG' ALT='IMG_3659.JPG'><BR>IMG_3659.JPG<br>69.79 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3659.JPG' ALT='IMG_3659.JPG'>IMG_3659.JPG</a></div></td>
<td><A ID='IMG_3660.JPG' href='doublewhammy.php?fileId=IMG_3660.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3660.JPG' ALT='IMG_3660.JPG'><BR>IMG_3660.JPG<br>65.64 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3660.JPG' ALT='IMG_3660.JPG'>IMG_3660.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_3662.JPG' href='doublewhammy.php?fileId=IMG_3662.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3662.JPG' ALT='IMG_3662.JPG'><BR>IMG_3662.JPG<br>64.07 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3662.JPG' ALT='IMG_3662.JPG'>IMG_3662.JPG</a></div></td>
<td><A ID='IMG_3663.JPG' href='doublewhammy.php?fileId=IMG_3663.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3663.JPG' ALT='IMG_3663.JPG'><BR>IMG_3663.JPG<br>68.64 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3663.JPG' ALT='IMG_3663.JPG'>IMG_3663.JPG</a></div></td>
<td><A ID='IMG_3664.JPG' href='doublewhammy.php?fileId=IMG_3664.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3664.JPG' ALT='IMG_3664.JPG'><BR>IMG_3664.JPG<br>68.62 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3664.JPG' ALT='IMG_3664.JPG'>IMG_3664.JPG</a></div></td>
<td><A ID='IMG_3665.JPG' href='doublewhammy.php?fileId=IMG_3665.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3665.JPG' ALT='IMG_3665.JPG'><BR>IMG_3665.JPG<br>58.28 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3665.JPG' ALT='IMG_3665.JPG'>IMG_3665.JPG</a></div></td>
<td><A ID='IMG_3666.JPG' href='doublewhammy.php?fileId=IMG_3666.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3666.JPG' ALT='IMG_3666.JPG'><BR>IMG_3666.JPG<br>60.82 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3666.JPG' ALT='IMG_3666.JPG'>IMG_3666.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_3667.JPG' href='doublewhammy.php?fileId=IMG_3667.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3667.JPG' ALT='IMG_3667.JPG'><BR>IMG_3667.JPG<br>35.47 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3667.JPG' ALT='IMG_3667.JPG'>IMG_3667.JPG</a></div></td>
<td><A ID='IMG_3668.JPG' href='doublewhammy.php?fileId=IMG_3668.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3668.JPG' ALT='IMG_3668.JPG'><BR>IMG_3668.JPG<br>42.28 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3668.JPG' ALT='IMG_3668.JPG'>IMG_3668.JPG</a></div></td>
<td><A ID='IMG_3669.JPG' href='doublewhammy.php?fileId=IMG_3669.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3669.JPG' ALT='IMG_3669.JPG'><BR>IMG_3669.JPG<br>61.98 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3669.JPG' ALT='IMG_3669.JPG'>IMG_3669.JPG</a></div></td>
<td><A ID='IMG_3670.JPG' href='doublewhammy.php?fileId=IMG_3670.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3670.JPG' ALT='IMG_3670.JPG'><BR>IMG_3670.JPG<br>95.82 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3670.JPG' ALT='IMG_3670.JPG'>IMG_3670.JPG</a></div></td>
<td><A ID='IMG_3672.JPG' href='doublewhammy.php?fileId=IMG_3672.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3672.JPG' ALT='IMG_3672.JPG'><BR>IMG_3672.JPG<br>92.13 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3672.JPG' ALT='IMG_3672.JPG'>IMG_3672.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_3673.JPG' href='doublewhammy.php?fileId=IMG_3673.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3673.JPG' ALT='IMG_3673.JPG'><BR>IMG_3673.JPG<br>65.42 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3673.JPG' ALT='IMG_3673.JPG'>IMG_3673.JPG</a></div></td>
<td><A ID='IMG_3674.JPG' href='doublewhammy.php?fileId=IMG_3674.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3674.JPG' ALT='IMG_3674.JPG'><BR>IMG_3674.JPG<br>79.27 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3674.JPG' ALT='IMG_3674.JPG'>IMG_3674.JPG</a></div></td>
<td><A ID='IMG_3683.JPG' href='doublewhammy.php?fileId=IMG_3683.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3683.JPG' ALT='IMG_3683.JPG'><BR>IMG_3683.JPG<br>101.01 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3683.JPG' ALT='IMG_3683.JPG'>IMG_3683.JPG</a></div></td>
<td><A ID='IMG_3685.JPG' href='doublewhammy.php?fileId=IMG_3685.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3685.JPG' ALT='IMG_3685.JPG'><BR>IMG_3685.JPG<br>101.4 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3685.JPG' ALT='IMG_3685.JPG'>IMG_3685.JPG</a></div></td>
<td><A ID='IMG_3692.JPG' href='doublewhammy.php?fileId=IMG_3692.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3692.JPG' ALT='IMG_3692.JPG'><BR>IMG_3692.JPG<br>95.93 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3692.JPG' ALT='IMG_3692.JPG'>IMG_3692.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_3694.JPG' href='doublewhammy.php?fileId=IMG_3694.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3694.JPG' ALT='IMG_3694.JPG'><BR>IMG_3694.JPG<br>77.94 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3694.JPG' ALT='IMG_3694.JPG'>IMG_3694.JPG</a></div></td>
<td><A ID='IMG_3698.JPG' href='doublewhammy.php?fileId=IMG_3698.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3698.JPG' ALT='IMG_3698.JPG'><BR>IMG_3698.JPG<br>109.03 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3698.JPG' ALT='IMG_3698.JPG'>IMG_3698.JPG</a></div></td>
<td><A ID='IMG_3701.JPG' href='doublewhammy.php?fileId=IMG_3701.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3701.JPG' ALT='IMG_3701.JPG'><BR>IMG_3701.JPG<br>94.1 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3701.JPG' ALT='IMG_3701.JPG'>IMG_3701.JPG</a></div></td>
<td><A ID='IMG_3703.JPG' href='doublewhammy.php?fileId=IMG_3703.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3703.JPG' ALT='IMG_3703.JPG'><BR>IMG_3703.JPG<br>89.45 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3703.JPG' ALT='IMG_3703.JPG'>IMG_3703.JPG</a></div></td>
<td><A ID='IMG_3704.JPG' href='doublewhammy.php?fileId=IMG_3704.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3704.JPG' ALT='IMG_3704.JPG'><BR>IMG_3704.JPG<br>73.39 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3704.JPG' ALT='IMG_3704.JPG'>IMG_3704.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_3707.JPG' href='doublewhammy.php?fileId=IMG_3707.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3707.JPG' ALT='IMG_3707.JPG'><BR>IMG_3707.JPG<br>99.77 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3707.JPG' ALT='IMG_3707.JPG'>IMG_3707.JPG</a></div></td>
<td><A ID='IMG_3709.JPG' href='doublewhammy.php?fileId=IMG_3709.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3709.JPG' ALT='IMG_3709.JPG'><BR>IMG_3709.JPG<br>110.58 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3709.JPG' ALT='IMG_3709.JPG'>IMG_3709.JPG</a></div></td>
<td><A ID='IMG_3711.JPG' href='doublewhammy.php?fileId=IMG_3711.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3711.JPG' ALT='IMG_3711.JPG'><BR>IMG_3711.JPG<br>106.38 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3711.JPG' ALT='IMG_3711.JPG'>IMG_3711.JPG</a></div></td>
<td><A ID='IMG_3715.JPG' href='doublewhammy.php?fileId=IMG_3715.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3715.JPG' ALT='IMG_3715.JPG'><BR>IMG_3715.JPG<br>90.63 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3715.JPG' ALT='IMG_3715.JPG'>IMG_3715.JPG</a></div></td>
<td><A ID='IMG_3716.JPG' href='doublewhammy.php?fileId=IMG_3716.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3716.JPG' ALT='IMG_3716.JPG'><BR>IMG_3716.JPG<br>115.06 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3716.JPG' ALT='IMG_3716.JPG'>IMG_3716.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_3719.JPG' href='doublewhammy.php?fileId=IMG_3719.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3719.JPG' ALT='IMG_3719.JPG'><BR>IMG_3719.JPG<br>71.42 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3719.JPG' ALT='IMG_3719.JPG'>IMG_3719.JPG</a></div></td>
<td><A ID='IMG_3721.JPG' href='doublewhammy.php?fileId=IMG_3721.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3721.JPG' ALT='IMG_3721.JPG'><BR>IMG_3721.JPG<br>96.25 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3721.JPG' ALT='IMG_3721.JPG'>IMG_3721.JPG</a></div></td>
<td><A ID='IMG_3723.JPG' href='doublewhammy.php?fileId=IMG_3723.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3723.JPG' ALT='IMG_3723.JPG'><BR>IMG_3723.JPG<br>99 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3723.JPG' ALT='IMG_3723.JPG'>IMG_3723.JPG</a></div></td>
<td><A ID='IMG_3728.JPG' href='doublewhammy.php?fileId=IMG_3728.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3728.JPG' ALT='IMG_3728.JPG'><BR>IMG_3728.JPG<br>43.97 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3728.JPG' ALT='IMG_3728.JPG'>IMG_3728.JPG</a></div></td>
<td><A ID='IMG_3732.JPG' href='doublewhammy.php?fileId=IMG_3732.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3732.JPG' ALT='IMG_3732.JPG'><BR>IMG_3732.JPG<br>85.48 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3732.JPG' ALT='IMG_3732.JPG'>IMG_3732.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_3734.JPG' href='doublewhammy.php?fileId=IMG_3734.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3734.JPG' ALT='IMG_3734.JPG'><BR>IMG_3734.JPG<br>90.67 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3734.JPG' ALT='IMG_3734.JPG'>IMG_3734.JPG</a></div></td>
<td><A ID='IMG_3743.JPG' href='doublewhammy.php?fileId=IMG_3743.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3743.JPG' ALT='IMG_3743.JPG'><BR>IMG_3743.JPG<br>115.46 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3743.JPG' ALT='IMG_3743.JPG'>IMG_3743.JPG</a></div></td>
<td><A ID='IMG_3747.JPG' href='doublewhammy.php?fileId=IMG_3747.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3747.JPG' ALT='IMG_3747.JPG'><BR>IMG_3747.JPG<br>112.55 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3747.JPG' ALT='IMG_3747.JPG'>IMG_3747.JPG</a></div></td>
<td><A ID='IMG_3748.JPG' href='doublewhammy.php?fileId=IMG_3748.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3748.JPG' ALT='IMG_3748.JPG'><BR>IMG_3748.JPG<br>95.82 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3748.JPG' ALT='IMG_3748.JPG'>IMG_3748.JPG</a></div></td>
<td><A ID='IMG_3750.JPG' href='doublewhammy.php?fileId=IMG_3750.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3750.JPG' ALT='IMG_3750.JPG'><BR>IMG_3750.JPG<br>105.63 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3750.JPG' ALT='IMG_3750.JPG'>IMG_3750.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_3751.JPG' href='doublewhammy.php?fileId=IMG_3751.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3751.JPG' ALT='IMG_3751.JPG'><BR>IMG_3751.JPG<br>104.57 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3751.JPG' ALT='IMG_3751.JPG'>IMG_3751.JPG</a></div></td>
<td><A ID='IMG_3752.JPG' href='doublewhammy.php?fileId=IMG_3752.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3752.JPG' ALT='IMG_3752.JPG'><BR>IMG_3752.JPG<br>45.66 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3752.JPG' ALT='IMG_3752.JPG'>IMG_3752.JPG</a></div></td>
<td><A ID='IMG_3753.JPG' href='doublewhammy.php?fileId=IMG_3753.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3753.JPG' ALT='IMG_3753.JPG'><BR>IMG_3753.JPG<br>41.52 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3753.JPG' ALT='IMG_3753.JPG'>IMG_3753.JPG</a></div></td>
<td><A ID='IMG_3756.JPG' href='doublewhammy.php?fileId=IMG_3756.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3756.JPG' ALT='IMG_3756.JPG'><BR>IMG_3756.JPG<br>81.41 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3756.JPG' ALT='IMG_3756.JPG'>IMG_3756.JPG</a></div></td>
<td><A ID='IMG_3765.JPG' href='doublewhammy.php?fileId=IMG_3765.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3765.JPG' ALT='IMG_3765.JPG'><BR>IMG_3765.JPG<br>66.28 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3765.JPG' ALT='IMG_3765.JPG'>IMG_3765.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_3769.JPG' href='doublewhammy.php?fileId=IMG_3769.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3769.JPG' ALT='IMG_3769.JPG'><BR>IMG_3769.JPG<br>104.7 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3769.JPG' ALT='IMG_3769.JPG'>IMG_3769.JPG</a></div></td>
<td><A ID='IMG_3770.JPG' href='doublewhammy.php?fileId=IMG_3770.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3770.JPG' ALT='IMG_3770.JPG'><BR>IMG_3770.JPG<br>95.81 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3770.JPG' ALT='IMG_3770.JPG'>IMG_3770.JPG</a></div></td>
<td><A ID='IMG_3774.JPG' href='doublewhammy.php?fileId=IMG_3774.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3774.JPG' ALT='IMG_3774.JPG'><BR>IMG_3774.JPG<br>80.97 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3774.JPG' ALT='IMG_3774.JPG'>IMG_3774.JPG</a></div></td>
<td><A ID='IMG_3775.JPG' href='doublewhammy.php?fileId=IMG_3775.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3775.JPG' ALT='IMG_3775.JPG'><BR>IMG_3775.JPG<br>92.16 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3775.JPG' ALT='IMG_3775.JPG'>IMG_3775.JPG</a></div></td>
<td><A ID='IMG_3777.JPG' href='doublewhammy.php?fileId=IMG_3777.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3777.JPG' ALT='IMG_3777.JPG'><BR>IMG_3777.JPG<br>48.5 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3777.JPG' ALT='IMG_3777.JPG'>IMG_3777.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_3778.JPG' href='doublewhammy.php?fileId=IMG_3778.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3778.JPG' ALT='IMG_3778.JPG'><BR>IMG_3778.JPG<br>69.45 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3778.JPG' ALT='IMG_3778.JPG'>IMG_3778.JPG</a></div></td>
<td><A ID='IMG_3783.JPG' href='doublewhammy.php?fileId=IMG_3783.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3783.JPG' ALT='IMG_3783.JPG'><BR>IMG_3783.JPG<br>83.04 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3783.JPG' ALT='IMG_3783.JPG'>IMG_3783.JPG</a></div></td>
<td><A ID='IMG_3785.JPG' href='doublewhammy.php?fileId=IMG_3785.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3785.JPG' ALT='IMG_3785.JPG'><BR>IMG_3785.JPG<br>82.56 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3785.JPG' ALT='IMG_3785.JPG'>IMG_3785.JPG</a></div></td>
<td><A ID='IMG_3791.JPG' href='doublewhammy.php?fileId=IMG_3791.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3791.JPG' ALT='IMG_3791.JPG'><BR>IMG_3791.JPG<br>93.12 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3791.JPG' ALT='IMG_3791.JPG'>IMG_3791.JPG</a></div></td>
<td><A ID='IMG_3792.JPG' href='doublewhammy.php?fileId=IMG_3792.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3792.JPG' ALT='IMG_3792.JPG'><BR>IMG_3792.JPG<br>74.65 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3792.JPG' ALT='IMG_3792.JPG'>IMG_3792.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_3794.JPG' href='doublewhammy.php?fileId=IMG_3794.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3794.JPG' ALT='IMG_3794.JPG'><BR>IMG_3794.JPG<br>65.49 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3794.JPG' ALT='IMG_3794.JPG'>IMG_3794.JPG</a></div></td>
<td><A ID='IMG_3796.JPG' href='doublewhammy.php?fileId=IMG_3796.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3796.JPG' ALT='IMG_3796.JPG'><BR>IMG_3796.JPG<br>80.64 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3796.JPG' ALT='IMG_3796.JPG'>IMG_3796.JPG</a></div></td>
<td><A ID='IMG_3797.JPG' href='doublewhammy.php?fileId=IMG_3797.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3797.JPG' ALT='IMG_3797.JPG'><BR>IMG_3797.JPG<br>79.46 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3797.JPG' ALT='IMG_3797.JPG'>IMG_3797.JPG</a></div></td>
<td><A ID='IMG_3798.JPG' href='doublewhammy.php?fileId=IMG_3798.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3798.JPG' ALT='IMG_3798.JPG'><BR>IMG_3798.JPG<br>76.9 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3798.JPG' ALT='IMG_3798.JPG'>IMG_3798.JPG</a></div></td>
<td><A ID='IMG_3801.JPG' href='doublewhammy.php?fileId=IMG_3801.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3801.JPG' ALT='IMG_3801.JPG'><BR>IMG_3801.JPG<br>81.55 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3801.JPG' ALT='IMG_3801.JPG'>IMG_3801.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_3802.JPG' href='doublewhammy.php?fileId=IMG_3802.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3802.JPG' ALT='IMG_3802.JPG'><BR>IMG_3802.JPG<br>60.8 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3802.JPG' ALT='IMG_3802.JPG'>IMG_3802.JPG</a></div></td>
<td><A ID='IMG_3804.JPG' href='doublewhammy.php?fileId=IMG_3804.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3804.JPG' ALT='IMG_3804.JPG'><BR>IMG_3804.JPG<br>65.94 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3804.JPG' ALT='IMG_3804.JPG'>IMG_3804.JPG</a></div></td>
<td><A ID='IMG_3805.JPG' href='doublewhammy.php?fileId=IMG_3805.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3805.JPG' ALT='IMG_3805.JPG'><BR>IMG_3805.JPG<br>42.79 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3805.JPG' ALT='IMG_3805.JPG'>IMG_3805.JPG</a></div></td>
<td><A ID='IMG_3806.JPG' href='doublewhammy.php?fileId=IMG_3806.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3806.JPG' ALT='IMG_3806.JPG'><BR>IMG_3806.JPG<br>56.91 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3806.JPG' ALT='IMG_3806.JPG'>IMG_3806.JPG</a></div></td>
<td><A ID='IMG_3807.JPG' href='doublewhammy.php?fileId=IMG_3807.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3807.JPG' ALT='IMG_3807.JPG'><BR>IMG_3807.JPG<br>56.82 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3807.JPG' ALT='IMG_3807.JPG'>IMG_3807.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_3808.JPG' href='doublewhammy.php?fileId=IMG_3808.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3808.JPG' ALT='IMG_3808.JPG'><BR>IMG_3808.JPG<br>53.82 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3808.JPG' ALT='IMG_3808.JPG'>IMG_3808.JPG</a></div></td>
<td><A ID='IMG_3809.JPG' href='doublewhammy.php?fileId=IMG_3809.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3809.JPG' ALT='IMG_3809.JPG'><BR>IMG_3809.JPG<br>53.31 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3809.JPG' ALT='IMG_3809.JPG'>IMG_3809.JPG</a></div></td>
<td><A ID='IMG_3810.JPG' href='doublewhammy.php?fileId=IMG_3810.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3810.JPG' ALT='IMG_3810.JPG'><BR>IMG_3810.JPG<br>58.9 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3810.JPG' ALT='IMG_3810.JPG'>IMG_3810.JPG</a></div></td>
<td><A ID='IMG_3811.JPG' href='doublewhammy.php?fileId=IMG_3811.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3811.JPG' ALT='IMG_3811.JPG'><BR>IMG_3811.JPG<br>56.85 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3811.JPG' ALT='IMG_3811.JPG'>IMG_3811.JPG</a></div></td>
<td><A ID='IMG_3812.JPG' href='doublewhammy.php?fileId=IMG_3812.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3812.JPG' ALT='IMG_3812.JPG'><BR>IMG_3812.JPG<br>56.11 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3812.JPG' ALT='IMG_3812.JPG'>IMG_3812.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_3814.JPG' href='doublewhammy.php?fileId=IMG_3814.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3814.JPG' ALT='IMG_3814.JPG'><BR>IMG_3814.JPG<br>64.14 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3814.JPG' ALT='IMG_3814.JPG'>IMG_3814.JPG</a></div></td>
<td><A ID='IMG_3816.JPG' href='doublewhammy.php?fileId=IMG_3816.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3816.JPG' ALT='IMG_3816.JPG'><BR>IMG_3816.JPG<br>52.93 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3816.JPG' ALT='IMG_3816.JPG'>IMG_3816.JPG</a></div></td>
<td><A ID='IMG_3818.JPG' href='doublewhammy.php?fileId=IMG_3818.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3818.JPG' ALT='IMG_3818.JPG'><BR>IMG_3818.JPG<br>43.63 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3818.JPG' ALT='IMG_3818.JPG'>IMG_3818.JPG</a></div></td>
<td><A ID='IMG_3819.JPG' href='doublewhammy.php?fileId=IMG_3819.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3819.JPG' ALT='IMG_3819.JPG'><BR>IMG_3819.JPG<br>39.05 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3819.JPG' ALT='IMG_3819.JPG'>IMG_3819.JPG</a></div></td>
<td><A ID='IMG_3823.JPG' href='doublewhammy.php?fileId=IMG_3823.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3823.JPG' ALT='IMG_3823.JPG'><BR>IMG_3823.JPG<br>72.18 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3823.JPG' ALT='IMG_3823.JPG'>IMG_3823.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_3824.JPG' href='doublewhammy.php?fileId=IMG_3824.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3824.JPG' ALT='IMG_3824.JPG'><BR>IMG_3824.JPG<br>62.42 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3824.JPG' ALT='IMG_3824.JPG'>IMG_3824.JPG</a></div></td>
<td><A ID='IMG_3825.JPG' href='doublewhammy.php?fileId=IMG_3825.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3825.JPG' ALT='IMG_3825.JPG'><BR>IMG_3825.JPG<br>51.23 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3825.JPG' ALT='IMG_3825.JPG'>IMG_3825.JPG</a></div></td>
<td><A ID='IMG_3827.JPG' href='doublewhammy.php?fileId=IMG_3827.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3827.JPG' ALT='IMG_3827.JPG'><BR>IMG_3827.JPG<br>56.67 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3827.JPG' ALT='IMG_3827.JPG'>IMG_3827.JPG</a></div></td>
<td><A ID='IMG_3830.JPG' href='doublewhammy.php?fileId=IMG_3830.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3830.JPG' ALT='IMG_3830.JPG'><BR>IMG_3830.JPG<br>50.63 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3830.JPG' ALT='IMG_3830.JPG'>IMG_3830.JPG</a></div></td>
<td><A ID='IMG_3831.JPG' href='doublewhammy.php?fileId=IMG_3831.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3831.JPG' ALT='IMG_3831.JPG'><BR>IMG_3831.JPG<br>87.91 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3831.JPG' ALT='IMG_3831.JPG'>IMG_3831.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_3833.JPG' href='doublewhammy.php?fileId=IMG_3833.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3833.JPG' ALT='IMG_3833.JPG'><BR>IMG_3833.JPG<br>58.86 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3833.JPG' ALT='IMG_3833.JPG'>IMG_3833.JPG</a></div></td>
<td><A ID='IMG_3834.JPG' href='doublewhammy.php?fileId=IMG_3834.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3834.JPG' ALT='IMG_3834.JPG'><BR>IMG_3834.JPG<br>55.22 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3834.JPG' ALT='IMG_3834.JPG'>IMG_3834.JPG</a></div></td>
<td><A ID='IMG_3836.JPG' href='doublewhammy.php?fileId=IMG_3836.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3836.JPG' ALT='IMG_3836.JPG'><BR>IMG_3836.JPG<br>67 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3836.JPG' ALT='IMG_3836.JPG'>IMG_3836.JPG</a></div></td>
<td><A ID='IMG_3839.JPG' href='doublewhammy.php?fileId=IMG_3839.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3839.JPG' ALT='IMG_3839.JPG'><BR>IMG_3839.JPG<br>44.71 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3839.JPG' ALT='IMG_3839.JPG'>IMG_3839.JPG</a></div></td>
<td><A ID='IMG_3840.JPG' href='doublewhammy.php?fileId=IMG_3840.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3840.JPG' ALT='IMG_3840.JPG'><BR>IMG_3840.JPG<br>55.47 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3840.JPG' ALT='IMG_3840.JPG'>IMG_3840.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_3842.JPG' href='doublewhammy.php?fileId=IMG_3842.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3842.JPG' ALT='IMG_3842.JPG'><BR>IMG_3842.JPG<br>73.64 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3842.JPG' ALT='IMG_3842.JPG'>IMG_3842.JPG</a></div></td>
<td><A ID='IMG_3843.JPG' href='doublewhammy.php?fileId=IMG_3843.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3843.JPG' ALT='IMG_3843.JPG'><BR>IMG_3843.JPG<br>61.48 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3843.JPG' ALT='IMG_3843.JPG'>IMG_3843.JPG</a></div></td>
<td><A ID='IMG_3874.JPG' href='doublewhammy.php?fileId=IMG_3874.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3874.JPG' ALT='IMG_3874.JPG'><BR>IMG_3874.JPG<br>51.54 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3874.JPG' ALT='IMG_3874.JPG'>IMG_3874.JPG</a></div></td>
<td><A ID='IMG_3875.JPG' href='doublewhammy.php?fileId=IMG_3875.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3875.JPG' ALT='IMG_3875.JPG'><BR>IMG_3875.JPG<br>40.09 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3875.JPG' ALT='IMG_3875.JPG'>IMG_3875.JPG</a></div></td>
<td><A ID='IMG_3880.JPG' href='doublewhammy.php?fileId=IMG_3880.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3880.JPG' ALT='IMG_3880.JPG'><BR>IMG_3880.JPG<br>51.2 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3880.JPG' ALT='IMG_3880.JPG'>IMG_3880.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_3882.JPG' href='doublewhammy.php?fileId=IMG_3882.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3882.JPG' ALT='IMG_3882.JPG'><BR>IMG_3882.JPG<br>57.31 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3882.JPG' ALT='IMG_3882.JPG'>IMG_3882.JPG</a></div></td>
<td><A ID='IMG_3883.JPG' href='doublewhammy.php?fileId=IMG_3883.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3883.JPG' ALT='IMG_3883.JPG'><BR>IMG_3883.JPG<br>44.77 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3883.JPG' ALT='IMG_3883.JPG'>IMG_3883.JPG</a></div></td>
<td><A ID='IMG_3886.JPG' href='doublewhammy.php?fileId=IMG_3886.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3886.JPG' ALT='IMG_3886.JPG'><BR>IMG_3886.JPG<br>31.07 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3886.JPG' ALT='IMG_3886.JPG'>IMG_3886.JPG</a></div></td>
<td><A ID='IMG_3887.JPG' href='doublewhammy.php?fileId=IMG_3887.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3887.JPG' ALT='IMG_3887.JPG'><BR>IMG_3887.JPG<br>62.62 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3887.JPG' ALT='IMG_3887.JPG'>IMG_3887.JPG</a></div></td>
<td><A ID='IMG_3888.JPG' href='doublewhammy.php?fileId=IMG_3888.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3888.JPG' ALT='IMG_3888.JPG'><BR>IMG_3888.JPG<br>30.39 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3888.JPG' ALT='IMG_3888.JPG'>IMG_3888.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_3889.JPG' href='doublewhammy.php?fileId=IMG_3889.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3889.JPG' ALT='IMG_3889.JPG'><BR>IMG_3889.JPG<br>66.13 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3889.JPG' ALT='IMG_3889.JPG'>IMG_3889.JPG</a></div></td>
<td><A ID='IMG_3891.JPG' href='doublewhammy.php?fileId=IMG_3891.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3891.JPG' ALT='IMG_3891.JPG'><BR>IMG_3891.JPG<br>60.31 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3891.JPG' ALT='IMG_3891.JPG'>IMG_3891.JPG</a></div></td>
<td><A ID='IMG_3892.JPG' href='doublewhammy.php?fileId=IMG_3892.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3892.JPG' ALT='IMG_3892.JPG'><BR>IMG_3892.JPG<br>67.61 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3892.JPG' ALT='IMG_3892.JPG'>IMG_3892.JPG</a></div></td>
<td><A ID='IMG_3894.JPG' href='doublewhammy.php?fileId=IMG_3894.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3894.JPG' ALT='IMG_3894.JPG'><BR>IMG_3894.JPG<br>47.63 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3894.JPG' ALT='IMG_3894.JPG'>IMG_3894.JPG</a></div></td>
<td><A ID='IMG_3897.JPG' href='doublewhammy.php?fileId=IMG_3897.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3897.JPG' ALT='IMG_3897.JPG'><BR>IMG_3897.JPG<br>49.18 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3897.JPG' ALT='IMG_3897.JPG'>IMG_3897.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_3898.JPG' href='doublewhammy.php?fileId=IMG_3898.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3898.JPG' ALT='IMG_3898.JPG'><BR>IMG_3898.JPG<br>41.41 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3898.JPG' ALT='IMG_3898.JPG'>IMG_3898.JPG</a></div></td>
<td><A ID='IMG_3899.JPG' href='doublewhammy.php?fileId=IMG_3899.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3899.JPG' ALT='IMG_3899.JPG'><BR>IMG_3899.JPG<br>61.36 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3899.JPG' ALT='IMG_3899.JPG'>IMG_3899.JPG</a></div></td>
<td><A ID='IMG_3905.JPG' href='doublewhammy.php?fileId=IMG_3905.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3905.JPG' ALT='IMG_3905.JPG'><BR>IMG_3905.JPG<br>61.4 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3905.JPG' ALT='IMG_3905.JPG'>IMG_3905.JPG</a></div></td>
<td><A ID='IMG_3906.JPG' href='doublewhammy.php?fileId=IMG_3906.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3906.JPG' ALT='IMG_3906.JPG'><BR>IMG_3906.JPG<br>61.88 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3906.JPG' ALT='IMG_3906.JPG'>IMG_3906.JPG</a></div></td>
<td><A ID='IMG_3909.JPG' href='doublewhammy.php?fileId=IMG_3909.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3909.JPG' ALT='IMG_3909.JPG'><BR>IMG_3909.JPG<br>105.91 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3909.JPG' ALT='IMG_3909.JPG'>IMG_3909.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_3910.JPG' href='doublewhammy.php?fileId=IMG_3910.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3910.JPG' ALT='IMG_3910.JPG'><BR>IMG_3910.JPG<br>94.7 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3910.JPG' ALT='IMG_3910.JPG'>IMG_3910.JPG</a></div></td>
<td><A ID='IMG_3911.JPG' href='doublewhammy.php?fileId=IMG_3911.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3911.JPG' ALT='IMG_3911.JPG'><BR>IMG_3911.JPG<br>116.33 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3911.JPG' ALT='IMG_3911.JPG'>IMG_3911.JPG</a></div></td>
<td><A ID='IMG_3912.JPG' href='doublewhammy.php?fileId=IMG_3912.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3912.JPG' ALT='IMG_3912.JPG'><BR>IMG_3912.JPG<br>91.68 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3912.JPG' ALT='IMG_3912.JPG'>IMG_3912.JPG</a></div></td>
<td><A ID='IMG_3913.JPG' href='doublewhammy.php?fileId=IMG_3913.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3913.JPG' ALT='IMG_3913.JPG'><BR>IMG_3913.JPG<br>106.62 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3913.JPG' ALT='IMG_3913.JPG'>IMG_3913.JPG</a></div></td>
<td><A ID='IMG_3917.JPG' href='doublewhammy.php?fileId=IMG_3917.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3917.JPG' ALT='IMG_3917.JPG'><BR>IMG_3917.JPG<br>110.79 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3917.JPG' ALT='IMG_3917.JPG'>IMG_3917.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_3920.JPG' href='doublewhammy.php?fileId=IMG_3920.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3920.JPG' ALT='IMG_3920.JPG'><BR>IMG_3920.JPG<br>132.8 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3920.JPG' ALT='IMG_3920.JPG'>IMG_3920.JPG</a></div></td>
<td><A ID='IMG_3925.JPG' href='doublewhammy.php?fileId=IMG_3925.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3925.JPG' ALT='IMG_3925.JPG'><BR>IMG_3925.JPG<br>84.09 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3925.JPG' ALT='IMG_3925.JPG'>IMG_3925.JPG</a></div></td>
<td><A ID='IMG_3926.JPG' href='doublewhammy.php?fileId=IMG_3926.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3926.JPG' ALT='IMG_3926.JPG'><BR>IMG_3926.JPG<br>96.33 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3926.JPG' ALT='IMG_3926.JPG'>IMG_3926.JPG</a></div></td>
<td><A ID='IMG_3927.JPG' href='doublewhammy.php?fileId=IMG_3927.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3927.JPG' ALT='IMG_3927.JPG'><BR>IMG_3927.JPG<br>99.26 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3927.JPG' ALT='IMG_3927.JPG'>IMG_3927.JPG</a></div></td>
<td><A ID='IMG_3928.JPG' href='doublewhammy.php?fileId=IMG_3928.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3928.JPG' ALT='IMG_3928.JPG'><BR>IMG_3928.JPG<br>85.04 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3928.JPG' ALT='IMG_3928.JPG'>IMG_3928.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_3929.JPG' href='doublewhammy.php?fileId=IMG_3929.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3929.JPG' ALT='IMG_3929.JPG'><BR>IMG_3929.JPG<br>75.64 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3929.JPG' ALT='IMG_3929.JPG'>IMG_3929.JPG</a></div></td>
<td><A ID='IMG_3930.JPG' href='doublewhammy.php?fileId=IMG_3930.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3930.JPG' ALT='IMG_3930.JPG'><BR>IMG_3930.JPG<br>62.26 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3930.JPG' ALT='IMG_3930.JPG'>IMG_3930.JPG</a></div></td>
<td><A ID='IMG_3932.JPG' href='doublewhammy.php?fileId=IMG_3932.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3932.JPG' ALT='IMG_3932.JPG'><BR>IMG_3932.JPG<br>92.47 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3932.JPG' ALT='IMG_3932.JPG'>IMG_3932.JPG</a></div></td>
<td><A ID='IMG_3934.JPG' href='doublewhammy.php?fileId=IMG_3934.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3934.JPG' ALT='IMG_3934.JPG'><BR>IMG_3934.JPG<br>96.64 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3934.JPG' ALT='IMG_3934.JPG'>IMG_3934.JPG</a></div></td>
<td><A ID='IMG_3935.JPG' href='doublewhammy.php?fileId=IMG_3935.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3935.JPG' ALT='IMG_3935.JPG'><BR>IMG_3935.JPG<br>75.42 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3935.JPG' ALT='IMG_3935.JPG'>IMG_3935.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_3937.JPG' href='doublewhammy.php?fileId=IMG_3937.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3937.JPG' ALT='IMG_3937.JPG'><BR>IMG_3937.JPG<br>96.91 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3937.JPG' ALT='IMG_3937.JPG'>IMG_3937.JPG</a></div></td>
<td><A ID='IMG_3938.JPG' href='doublewhammy.php?fileId=IMG_3938.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3938.JPG' ALT='IMG_3938.JPG'><BR>IMG_3938.JPG<br>84.77 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3938.JPG' ALT='IMG_3938.JPG'>IMG_3938.JPG</a></div></td>
<td><A ID='IMG_3941.JPG' href='doublewhammy.php?fileId=IMG_3941.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3941.JPG' ALT='IMG_3941.JPG'><BR>IMG_3941.JPG<br>86.81 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3941.JPG' ALT='IMG_3941.JPG'>IMG_3941.JPG</a></div></td>
<td><A ID='IMG_3943.JPG' href='doublewhammy.php?fileId=IMG_3943.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3943.JPG' ALT='IMG_3943.JPG'><BR>IMG_3943.JPG<br>85.61 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3943.JPG' ALT='IMG_3943.JPG'>IMG_3943.JPG</a></div></td>
<td><A ID='IMG_3945.JPG' href='doublewhammy.php?fileId=IMG_3945.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3945.JPG' ALT='IMG_3945.JPG'><BR>IMG_3945.JPG<br>56.75 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3945.JPG' ALT='IMG_3945.JPG'>IMG_3945.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_3946.JPG' href='doublewhammy.php?fileId=IMG_3946.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3946.JPG' ALT='IMG_3946.JPG'><BR>IMG_3946.JPG<br>95.69 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3946.JPG' ALT='IMG_3946.JPG'>IMG_3946.JPG</a></div></td>
<td><A ID='IMG_3948.JPG' href='doublewhammy.php?fileId=IMG_3948.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3948.JPG' ALT='IMG_3948.JPG'><BR>IMG_3948.JPG<br>99.66 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3948.JPG' ALT='IMG_3948.JPG'>IMG_3948.JPG</a></div></td>
<td><A ID='IMG_3951.JPG' href='doublewhammy.php?fileId=IMG_3951.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3951.JPG' ALT='IMG_3951.JPG'><BR>IMG_3951.JPG<br>97.52 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3951.JPG' ALT='IMG_3951.JPG'>IMG_3951.JPG</a></div></td>
<td><A ID='IMG_3952.JPG' href='doublewhammy.php?fileId=IMG_3952.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3952.JPG' ALT='IMG_3952.JPG'><BR>IMG_3952.JPG<br>84.39 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3952.JPG' ALT='IMG_3952.JPG'>IMG_3952.JPG</a></div></td>
<td><A ID='IMG_3959.JPG' href='doublewhammy.php?fileId=IMG_3959.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3959.JPG' ALT='IMG_3959.JPG'><BR>IMG_3959.JPG<br>85.53 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3959.JPG' ALT='IMG_3959.JPG'>IMG_3959.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_3963.JPG' href='doublewhammy.php?fileId=IMG_3963.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3963.JPG' ALT='IMG_3963.JPG'><BR>IMG_3963.JPG<br>120.3 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3963.JPG' ALT='IMG_3963.JPG'>IMG_3963.JPG</a></div></td>
<td><A ID='IMG_3970.JPG' href='doublewhammy.php?fileId=IMG_3970.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3970.JPG' ALT='IMG_3970.JPG'><BR>IMG_3970.JPG<br>115.16 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3970.JPG' ALT='IMG_3970.JPG'>IMG_3970.JPG</a></div></td>
<td><A ID='IMG_3974.JPG' href='doublewhammy.php?fileId=IMG_3974.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3974.JPG' ALT='IMG_3974.JPG'><BR>IMG_3974.JPG<br>79.24 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3974.JPG' ALT='IMG_3974.JPG'>IMG_3974.JPG</a></div></td>
<td><A ID='IMG_3975.JPG' href='doublewhammy.php?fileId=IMG_3975.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3975.JPG' ALT='IMG_3975.JPG'><BR>IMG_3975.JPG<br>75.19 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3975.JPG' ALT='IMG_3975.JPG'>IMG_3975.JPG</a></div></td>
<td><A ID='IMG_3976.JPG' href='doublewhammy.php?fileId=IMG_3976.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3976.JPG' ALT='IMG_3976.JPG'><BR>IMG_3976.JPG<br>71.79 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3976.JPG' ALT='IMG_3976.JPG'>IMG_3976.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_3977.JPG' href='doublewhammy.php?fileId=IMG_3977.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3977.JPG' ALT='IMG_3977.JPG'><BR>IMG_3977.JPG<br>77.92 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3977.JPG' ALT='IMG_3977.JPG'>IMG_3977.JPG</a></div></td>
<td><A ID='IMG_3982.JPG' href='doublewhammy.php?fileId=IMG_3982.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3982.JPG' ALT='IMG_3982.JPG'><BR>IMG_3982.JPG<br>134.45 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3982.JPG' ALT='IMG_3982.JPG'>IMG_3982.JPG</a></div></td>
<td><A ID='IMG_3985.JPG' href='doublewhammy.php?fileId=IMG_3985.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3985.JPG' ALT='IMG_3985.JPG'><BR>IMG_3985.JPG<br>106.13 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3985.JPG' ALT='IMG_3985.JPG'>IMG_3985.JPG</a></div></td>
<td><A ID='IMG_3988.JPG' href='doublewhammy.php?fileId=IMG_3988.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3988.JPG' ALT='IMG_3988.JPG'><BR>IMG_3988.JPG<br>113.02 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3988.JPG' ALT='IMG_3988.JPG'>IMG_3988.JPG</a></div></td>
<td><A ID='IMG_3990.JPG' href='doublewhammy.php?fileId=IMG_3990.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3990.JPG' ALT='IMG_3990.JPG'><BR>IMG_3990.JPG<br>100.84 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3990.JPG' ALT='IMG_3990.JPG'>IMG_3990.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_3995.JPG' href='doublewhammy.php?fileId=IMG_3995.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3995.JPG' ALT='IMG_3995.JPG'><BR>IMG_3995.JPG<br>106.54 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3995.JPG' ALT='IMG_3995.JPG'>IMG_3995.JPG</a></div></td>
<td><A ID='IMG_3997.JPG' href='doublewhammy.php?fileId=IMG_3997.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3997.JPG' ALT='IMG_3997.JPG'><BR>IMG_3997.JPG<br>83.23 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3997.JPG' ALT='IMG_3997.JPG'>IMG_3997.JPG</a></div></td>
<td><A ID='IMG_3998.JPG' href='doublewhammy.php?fileId=IMG_3998.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3998.JPG' ALT='IMG_3998.JPG'><BR>IMG_3998.JPG<br>124.21 KB</a><div class='inv'><br><a href='./images/20051209/IMG_3998.JPG' ALT='IMG_3998.JPG'>IMG_3998.JPG</a></div></td>
<td><A ID='IMG_4002.JPG' href='doublewhammy.php?fileId=IMG_4002.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_4002.JPG' ALT='IMG_4002.JPG'><BR>IMG_4002.JPG<br>78.33 KB</a><div class='inv'><br><a href='./images/20051209/IMG_4002.JPG' ALT='IMG_4002.JPG'>IMG_4002.JPG</a></div></td>
<td><A ID='IMG_4007.JPG' href='doublewhammy.php?fileId=IMG_4007.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_4007.JPG' ALT='IMG_4007.JPG'><BR>IMG_4007.JPG<br>78.02 KB</a><div class='inv'><br><a href='./images/20051209/IMG_4007.JPG' ALT='IMG_4007.JPG'>IMG_4007.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_4010.JPG' href='doublewhammy.php?fileId=IMG_4010.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_4010.JPG' ALT='IMG_4010.JPG'><BR>IMG_4010.JPG<br>77.32 KB</a><div class='inv'><br><a href='./images/20051209/IMG_4010.JPG' ALT='IMG_4010.JPG'>IMG_4010.JPG</a></div></td>
<td><A ID='IMG_4012.JPG' href='doublewhammy.php?fileId=IMG_4012.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_4012.JPG' ALT='IMG_4012.JPG'><BR>IMG_4012.JPG<br>94.2 KB</a><div class='inv'><br><a href='./images/20051209/IMG_4012.JPG' ALT='IMG_4012.JPG'>IMG_4012.JPG</a></div></td>
<td><A ID='IMG_4021.JPG' href='doublewhammy.php?fileId=IMG_4021.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_4021.JPG' ALT='IMG_4021.JPG'><BR>IMG_4021.JPG<br>50.7 KB</a><div class='inv'><br><a href='./images/20051209/IMG_4021.JPG' ALT='IMG_4021.JPG'>IMG_4021.JPG</a></div></td>
<td><A ID='IMG_4022.JPG' href='doublewhammy.php?fileId=IMG_4022.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_4022.JPG' ALT='IMG_4022.JPG'><BR>IMG_4022.JPG<br>50.51 KB</a><div class='inv'><br><a href='./images/20051209/IMG_4022.JPG' ALT='IMG_4022.JPG'>IMG_4022.JPG</a></div></td>
<td><A ID='IMG_4030.JPG' href='doublewhammy.php?fileId=IMG_4030.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_4030.JPG' ALT='IMG_4030.JPG'><BR>IMG_4030.JPG<br>46.97 KB</a><div class='inv'><br><a href='./images/20051209/IMG_4030.JPG' ALT='IMG_4030.JPG'>IMG_4030.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_4031.JPG' href='doublewhammy.php?fileId=IMG_4031.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_4031.JPG' ALT='IMG_4031.JPG'><BR>IMG_4031.JPG<br>43.35 KB</a><div class='inv'><br><a href='./images/20051209/IMG_4031.JPG' ALT='IMG_4031.JPG'>IMG_4031.JPG</a></div></td>
<td><A ID='IMG_4032.JPG' href='doublewhammy.php?fileId=IMG_4032.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_4032.JPG' ALT='IMG_4032.JPG'><BR>IMG_4032.JPG<br>68.18 KB</a><div class='inv'><br><a href='./images/20051209/IMG_4032.JPG' ALT='IMG_4032.JPG'>IMG_4032.JPG</a></div></td>
<td><A ID='IMG_4035.JPG' href='doublewhammy.php?fileId=IMG_4035.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_4035.JPG' ALT='IMG_4035.JPG'><BR>IMG_4035.JPG<br>51.62 KB</a><div class='inv'><br><a href='./images/20051209/IMG_4035.JPG' ALT='IMG_4035.JPG'>IMG_4035.JPG</a></div></td>
<td><A ID='IMG_4036.JPG' href='doublewhammy.php?fileId=IMG_4036.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_4036.JPG' ALT='IMG_4036.JPG'><BR>IMG_4036.JPG<br>40.35 KB</a><div class='inv'><br><a href='./images/20051209/IMG_4036.JPG' ALT='IMG_4036.JPG'>IMG_4036.JPG</a></div></td>
<td><A ID='IMG_4037.JPG' href='doublewhammy.php?fileId=IMG_4037.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_4037.JPG' ALT='IMG_4037.JPG'><BR>IMG_4037.JPG<br>85.86 KB</a><div class='inv'><br><a href='./images/20051209/IMG_4037.JPG' ALT='IMG_4037.JPG'>IMG_4037.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_4039.JPG' href='doublewhammy.php?fileId=IMG_4039.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_4039.JPG' ALT='IMG_4039.JPG'><BR>IMG_4039.JPG<br>67.28 KB</a><div class='inv'><br><a href='./images/20051209/IMG_4039.JPG' ALT='IMG_4039.JPG'>IMG_4039.JPG</a></div></td>
<td><A ID='IMG_4040.JPG' href='doublewhammy.php?fileId=IMG_4040.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_4040.JPG' ALT='IMG_4040.JPG'><BR>IMG_4040.JPG<br>75.09 KB</a><div class='inv'><br><a href='./images/20051209/IMG_4040.JPG' ALT='IMG_4040.JPG'>IMG_4040.JPG</a></div></td>
<td><A ID='IMG_4041.JPG' href='doublewhammy.php?fileId=IMG_4041.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_4041.JPG' ALT='IMG_4041.JPG'><BR>IMG_4041.JPG<br>64.38 KB</a><div class='inv'><br><a href='./images/20051209/IMG_4041.JPG' ALT='IMG_4041.JPG'>IMG_4041.JPG</a></div></td>
<td><A ID='IMG_4042.JPG' href='doublewhammy.php?fileId=IMG_4042.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_4042.JPG' ALT='IMG_4042.JPG'><BR>IMG_4042.JPG<br>80.04 KB</a><div class='inv'><br><a href='./images/20051209/IMG_4042.JPG' ALT='IMG_4042.JPG'>IMG_4042.JPG</a></div></td>
<td><A ID='IMG_4043.JPG' href='doublewhammy.php?fileId=IMG_4043.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_4043.JPG' ALT='IMG_4043.JPG'><BR>IMG_4043.JPG<br>76.7 KB</a><div class='inv'><br><a href='./images/20051209/IMG_4043.JPG' ALT='IMG_4043.JPG'>IMG_4043.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_4045.JPG' href='doublewhammy.php?fileId=IMG_4045.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_4045.JPG' ALT='IMG_4045.JPG'><BR>IMG_4045.JPG<br>105.98 KB</a><div class='inv'><br><a href='./images/20051209/IMG_4045.JPG' ALT='IMG_4045.JPG'>IMG_4045.JPG</a></div></td>
<td><A ID='IMG_4046.JPG' href='doublewhammy.php?fileId=IMG_4046.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_4046.JPG' ALT='IMG_4046.JPG'><BR>IMG_4046.JPG<br>72.5 KB</a><div class='inv'><br><a href='./images/20051209/IMG_4046.JPG' ALT='IMG_4046.JPG'>IMG_4046.JPG</a></div></td>
<td><A ID='IMG_4047.JPG' href='doublewhammy.php?fileId=IMG_4047.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_4047.JPG' ALT='IMG_4047.JPG'><BR>IMG_4047.JPG<br>61.22 KB</a><div class='inv'><br><a href='./images/20051209/IMG_4047.JPG' ALT='IMG_4047.JPG'>IMG_4047.JPG</a></div></td>
<td><A ID='IMG_4049.JPG' href='doublewhammy.php?fileId=IMG_4049.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_4049.JPG' ALT='IMG_4049.JPG'><BR>IMG_4049.JPG<br>57.67 KB</a><div class='inv'><br><a href='./images/20051209/IMG_4049.JPG' ALT='IMG_4049.JPG'>IMG_4049.JPG</a></div></td>
<td><A ID='IMG_4050.JPG' href='doublewhammy.php?fileId=IMG_4050.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_4050.JPG' ALT='IMG_4050.JPG'><BR>IMG_4050.JPG<br>86.26 KB</a><div class='inv'><br><a href='./images/20051209/IMG_4050.JPG' ALT='IMG_4050.JPG'>IMG_4050.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_4053.JPG' href='doublewhammy.php?fileId=IMG_4053.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_4053.JPG' ALT='IMG_4053.JPG'><BR>IMG_4053.JPG<br>59.6 KB</a><div class='inv'><br><a href='./images/20051209/IMG_4053.JPG' ALT='IMG_4053.JPG'>IMG_4053.JPG</a></div></td>
<td><A ID='IMG_4054.JPG' href='doublewhammy.php?fileId=IMG_4054.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_4054.JPG' ALT='IMG_4054.JPG'><BR>IMG_4054.JPG<br>101.6 KB</a><div class='inv'><br><a href='./images/20051209/IMG_4054.JPG' ALT='IMG_4054.JPG'>IMG_4054.JPG</a></div></td>
<td><A ID='IMG_4058.JPG' href='doublewhammy.php?fileId=IMG_4058.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_4058.JPG' ALT='IMG_4058.JPG'><BR>IMG_4058.JPG<br>81.43 KB</a><div class='inv'><br><a href='./images/20051209/IMG_4058.JPG' ALT='IMG_4058.JPG'>IMG_4058.JPG</a></div></td>
<td><A ID='IMG_4061.JPG' href='doublewhammy.php?fileId=IMG_4061.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_4061.JPG' ALT='IMG_4061.JPG'><BR>IMG_4061.JPG<br>71.95 KB</a><div class='inv'><br><a href='./images/20051209/IMG_4061.JPG' ALT='IMG_4061.JPG'>IMG_4061.JPG</a></div></td>
<td><A ID='IMG_4063.JPG' href='doublewhammy.php?fileId=IMG_4063.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_4063.JPG' ALT='IMG_4063.JPG'><BR>IMG_4063.JPG<br>46.27 KB</a><div class='inv'><br><a href='./images/20051209/IMG_4063.JPG' ALT='IMG_4063.JPG'>IMG_4063.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_4064.JPG' href='doublewhammy.php?fileId=IMG_4064.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_4064.JPG' ALT='IMG_4064.JPG'><BR>IMG_4064.JPG<br>73.61 KB</a><div class='inv'><br><a href='./images/20051209/IMG_4064.JPG' ALT='IMG_4064.JPG'>IMG_4064.JPG</a></div></td>
<td><A ID='IMG_4065.JPG' href='doublewhammy.php?fileId=IMG_4065.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_4065.JPG' ALT='IMG_4065.JPG'><BR>IMG_4065.JPG<br>57.5 KB</a><div class='inv'><br><a href='./images/20051209/IMG_4065.JPG' ALT='IMG_4065.JPG'>IMG_4065.JPG</a></div></td>
<td><A ID='IMG_4068.JPG' href='doublewhammy.php?fileId=IMG_4068.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_4068.JPG' ALT='IMG_4068.JPG'><BR>IMG_4068.JPG<br>71.23 KB</a><div class='inv'><br><a href='./images/20051209/IMG_4068.JPG' ALT='IMG_4068.JPG'>IMG_4068.JPG</a></div></td>
<td><A ID='IMG_4071.JPG' href='doublewhammy.php?fileId=IMG_4071.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_4071.JPG' ALT='IMG_4071.JPG'><BR>IMG_4071.JPG<br>48.44 KB</a><div class='inv'><br><a href='./images/20051209/IMG_4071.JPG' ALT='IMG_4071.JPG'>IMG_4071.JPG</a></div></td>
<td><A ID='IMG_4072.JPG' href='doublewhammy.php?fileId=IMG_4072.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_4072.JPG' ALT='IMG_4072.JPG'><BR>IMG_4072.JPG<br>52.6 KB</a><div class='inv'><br><a href='./images/20051209/IMG_4072.JPG' ALT='IMG_4072.JPG'>IMG_4072.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_4075.JPG' href='doublewhammy.php?fileId=IMG_4075.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_4075.JPG' ALT='IMG_4075.JPG'><BR>IMG_4075.JPG<br>56.01 KB</a><div class='inv'><br><a href='./images/20051209/IMG_4075.JPG' ALT='IMG_4075.JPG'>IMG_4075.JPG</a></div></td>
<td><A ID='IMG_4078.JPG' href='doublewhammy.php?fileId=IMG_4078.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_4078.JPG' ALT='IMG_4078.JPG'><BR>IMG_4078.JPG<br>60.93 KB</a><div class='inv'><br><a href='./images/20051209/IMG_4078.JPG' ALT='IMG_4078.JPG'>IMG_4078.JPG</a></div></td>
<td><A ID='IMG_4081.JPG' href='doublewhammy.php?fileId=IMG_4081.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_4081.JPG' ALT='IMG_4081.JPG'><BR>IMG_4081.JPG<br>56.59 KB</a><div class='inv'><br><a href='./images/20051209/IMG_4081.JPG' ALT='IMG_4081.JPG'>IMG_4081.JPG</a></div></td>
<td><A ID='IMG_4083.JPG' href='doublewhammy.php?fileId=IMG_4083.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_4083.JPG' ALT='IMG_4083.JPG'><BR>IMG_4083.JPG<br>57.43 KB</a><div class='inv'><br><a href='./images/20051209/IMG_4083.JPG' ALT='IMG_4083.JPG'>IMG_4083.JPG</a></div></td>
<td><A ID='IMG_4084.JPG' href='doublewhammy.php?fileId=IMG_4084.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_4084.JPG' ALT='IMG_4084.JPG'><BR>IMG_4084.JPG<br>71.34 KB</a><div class='inv'><br><a href='./images/20051209/IMG_4084.JPG' ALT='IMG_4084.JPG'>IMG_4084.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_4085.JPG' href='doublewhammy.php?fileId=IMG_4085.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_4085.JPG' ALT='IMG_4085.JPG'><BR>IMG_4085.JPG<br>47.22 KB</a><div class='inv'><br><a href='./images/20051209/IMG_4085.JPG' ALT='IMG_4085.JPG'>IMG_4085.JPG</a></div></td>
<td><A ID='IMG_4086.JPG' href='doublewhammy.php?fileId=IMG_4086.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_4086.JPG' ALT='IMG_4086.JPG'><BR>IMG_4086.JPG<br>62.18 KB</a><div class='inv'><br><a href='./images/20051209/IMG_4086.JPG' ALT='IMG_4086.JPG'>IMG_4086.JPG</a></div></td>
<td><A ID='IMG_4087.JPG' href='doublewhammy.php?fileId=IMG_4087.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_4087.JPG' ALT='IMG_4087.JPG'><BR>IMG_4087.JPG<br>61.43 KB</a><div class='inv'><br><a href='./images/20051209/IMG_4087.JPG' ALT='IMG_4087.JPG'>IMG_4087.JPG</a></div></td>
<td><A ID='IMG_4091.JPG' href='doublewhammy.php?fileId=IMG_4091.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_4091.JPG' ALT='IMG_4091.JPG'><BR>IMG_4091.JPG<br>50.05 KB</a><div class='inv'><br><a href='./images/20051209/IMG_4091.JPG' ALT='IMG_4091.JPG'>IMG_4091.JPG</a></div></td>
<td><A ID='IMG_4092.JPG' href='doublewhammy.php?fileId=IMG_4092.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_4092.JPG' ALT='IMG_4092.JPG'><BR>IMG_4092.JPG<br>72.66 KB</a><div class='inv'><br><a href='./images/20051209/IMG_4092.JPG' ALT='IMG_4092.JPG'>IMG_4092.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_4095.JPG' href='doublewhammy.php?fileId=IMG_4095.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_4095.JPG' ALT='IMG_4095.JPG'><BR>IMG_4095.JPG<br>78.64 KB</a><div class='inv'><br><a href='./images/20051209/IMG_4095.JPG' ALT='IMG_4095.JPG'>IMG_4095.JPG</a></div></td>
<td><A ID='IMG_4097.JPG' href='doublewhammy.php?fileId=IMG_4097.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_4097.JPG' ALT='IMG_4097.JPG'><BR>IMG_4097.JPG<br>55.09 KB</a><div class='inv'><br><a href='./images/20051209/IMG_4097.JPG' ALT='IMG_4097.JPG'>IMG_4097.JPG</a></div></td>
<td><A ID='IMG_4100.JPG' href='doublewhammy.php?fileId=IMG_4100.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_4100.JPG' ALT='IMG_4100.JPG'><BR>IMG_4100.JPG<br>57.37 KB</a><div class='inv'><br><a href='./images/20051209/IMG_4100.JPG' ALT='IMG_4100.JPG'>IMG_4100.JPG</a></div></td>
<td><A ID='IMG_4102.JPG' href='doublewhammy.php?fileId=IMG_4102.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_4102.JPG' ALT='IMG_4102.JPG'><BR>IMG_4102.JPG<br>44.49 KB</a><div class='inv'><br><a href='./images/20051209/IMG_4102.JPG' ALT='IMG_4102.JPG'>IMG_4102.JPG</a></div></td>
<td><A ID='IMG_4105.JPG' href='doublewhammy.php?fileId=IMG_4105.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_4105.JPG' ALT='IMG_4105.JPG'><BR>IMG_4105.JPG<br>81.31 KB</a><div class='inv'><br><a href='./images/20051209/IMG_4105.JPG' ALT='IMG_4105.JPG'>IMG_4105.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_4107.JPG' href='doublewhammy.php?fileId=IMG_4107.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_4107.JPG' ALT='IMG_4107.JPG'><BR>IMG_4107.JPG<br>117.79 KB</a><div class='inv'><br><a href='./images/20051209/IMG_4107.JPG' ALT='IMG_4107.JPG'>IMG_4107.JPG</a></div></td>
<td><A ID='IMG_4110.JPG' href='doublewhammy.php?fileId=IMG_4110.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_4110.JPG' ALT='IMG_4110.JPG'><BR>IMG_4110.JPG<br>80.7 KB</a><div class='inv'><br><a href='./images/20051209/IMG_4110.JPG' ALT='IMG_4110.JPG'>IMG_4110.JPG</a></div></td>
<td><A ID='IMG_4112.JPG' href='doublewhammy.php?fileId=IMG_4112.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_4112.JPG' ALT='IMG_4112.JPG'><BR>IMG_4112.JPG<br>145.07 KB</a><div class='inv'><br><a href='./images/20051209/IMG_4112.JPG' ALT='IMG_4112.JPG'>IMG_4112.JPG</a></div></td>
<td><A ID='IMG_4114.JPG' href='doublewhammy.php?fileId=IMG_4114.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_4114.JPG' ALT='IMG_4114.JPG'><BR>IMG_4114.JPG<br>96.15 KB</a><div class='inv'><br><a href='./images/20051209/IMG_4114.JPG' ALT='IMG_4114.JPG'>IMG_4114.JPG</a></div></td>
<td><A ID='IMG_4115.JPG' href='doublewhammy.php?fileId=IMG_4115.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_4115.JPG' ALT='IMG_4115.JPG'><BR>IMG_4115.JPG<br>77.65 KB</a><div class='inv'><br><a href='./images/20051209/IMG_4115.JPG' ALT='IMG_4115.JPG'>IMG_4115.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_4120.JPG' href='doublewhammy.php?fileId=IMG_4120.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_4120.JPG' ALT='IMG_4120.JPG'><BR>IMG_4120.JPG<br>102.48 KB</a><div class='inv'><br><a href='./images/20051209/IMG_4120.JPG' ALT='IMG_4120.JPG'>IMG_4120.JPG</a></div></td>
<td><A ID='IMG_4125.JPG' href='doublewhammy.php?fileId=IMG_4125.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_4125.JPG' ALT='IMG_4125.JPG'><BR>IMG_4125.JPG<br>75.13 KB</a><div class='inv'><br><a href='./images/20051209/IMG_4125.JPG' ALT='IMG_4125.JPG'>IMG_4125.JPG</a></div></td>
<td><A ID='IMG_4126.JPG' href='doublewhammy.php?fileId=IMG_4126.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_4126.JPG' ALT='IMG_4126.JPG'><BR>IMG_4126.JPG<br>64.81 KB</a><div class='inv'><br><a href='./images/20051209/IMG_4126.JPG' ALT='IMG_4126.JPG'>IMG_4126.JPG</a></div></td>
<td><A ID='IMG_4127.JPG' href='doublewhammy.php?fileId=IMG_4127.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_4127.JPG' ALT='IMG_4127.JPG'><BR>IMG_4127.JPG<br>58.88 KB</a><div class='inv'><br><a href='./images/20051209/IMG_4127.JPG' ALT='IMG_4127.JPG'>IMG_4127.JPG</a></div></td>
<td><A ID='IMG_4131.JPG' href='doublewhammy.php?fileId=IMG_4131.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_4131.JPG' ALT='IMG_4131.JPG'><BR>IMG_4131.JPG<br>99.14 KB</a><div class='inv'><br><a href='./images/20051209/IMG_4131.JPG' ALT='IMG_4131.JPG'>IMG_4131.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_4134.JPG' href='doublewhammy.php?fileId=IMG_4134.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_4134.JPG' ALT='IMG_4134.JPG'><BR>IMG_4134.JPG<br>80.81 KB</a><div class='inv'><br><a href='./images/20051209/IMG_4134.JPG' ALT='IMG_4134.JPG'>IMG_4134.JPG</a></div></td>
<td><A ID='IMG_4135.JPG' href='doublewhammy.php?fileId=IMG_4135.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_4135.JPG' ALT='IMG_4135.JPG'><BR>IMG_4135.JPG<br>62.8 KB</a><div class='inv'><br><a href='./images/20051209/IMG_4135.JPG' ALT='IMG_4135.JPG'>IMG_4135.JPG</a></div></td>
<td><A ID='IMG_4140.JPG' href='doublewhammy.php?fileId=IMG_4140.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_4140.JPG' ALT='IMG_4140.JPG'><BR>IMG_4140.JPG<br>92.68 KB</a><div class='inv'><br><a href='./images/20051209/IMG_4140.JPG' ALT='IMG_4140.JPG'>IMG_4140.JPG</a></div></td>
<td><A ID='IMG_4143.JPG' href='doublewhammy.php?fileId=IMG_4143.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_4143.JPG' ALT='IMG_4143.JPG'><BR>IMG_4143.JPG<br>55.7 KB</a><div class='inv'><br><a href='./images/20051209/IMG_4143.JPG' ALT='IMG_4143.JPG'>IMG_4143.JPG</a></div></td>
<td><A ID='IMG_4144.JPG' href='doublewhammy.php?fileId=IMG_4144.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_4144.JPG' ALT='IMG_4144.JPG'><BR>IMG_4144.JPG<br>79.52 KB</a><div class='inv'><br><a href='./images/20051209/IMG_4144.JPG' ALT='IMG_4144.JPG'>IMG_4144.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_4146.JPG' href='doublewhammy.php?fileId=IMG_4146.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_4146.JPG' ALT='IMG_4146.JPG'><BR>IMG_4146.JPG<br>82.91 KB</a><div class='inv'><br><a href='./images/20051209/IMG_4146.JPG' ALT='IMG_4146.JPG'>IMG_4146.JPG</a></div></td>
<td><A ID='IMG_4148.JPG' href='doublewhammy.php?fileId=IMG_4148.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_4148.JPG' ALT='IMG_4148.JPG'><BR>IMG_4148.JPG<br>49.46 KB</a><div class='inv'><br><a href='./images/20051209/IMG_4148.JPG' ALT='IMG_4148.JPG'>IMG_4148.JPG</a></div></td>
<td><A ID='IMG_4149.JPG' href='doublewhammy.php?fileId=IMG_4149.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_4149.JPG' ALT='IMG_4149.JPG'><BR>IMG_4149.JPG<br>35.03 KB</a><div class='inv'><br><a href='./images/20051209/IMG_4149.JPG' ALT='IMG_4149.JPG'>IMG_4149.JPG</a></div></td>
</tr>
</table>	</div>
</div>
</body>
</html>