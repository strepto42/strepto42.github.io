<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - 29/7/2005 - Levity, Limestone and Lava</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="Levity, Limestone and Lava">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="Greetings from a Bum" href='greetingsfromabum.php'>29/4/2005</a></li>
<li><a title="Onward" href='onward.php'>2/5/2005</a></li>
<li><a title="It's a tough life (pt 1: Bundaberg, Agnes Water and 1770)" href='itsatoughlife1.php'>17/5/2005</a></li>
<li><a title="It's a tough life (pt 2: Rockhampton, Emu Park and Great Keppel Island)" href='itsatoughlife2.php'>23/5/2005</a></li>
<li><a title="There and Back Again - a Yo-yo's Tale" href='thereandbackagain.php'>18/6/2005</a></li>
<li><a title="Platypi and Grey Nomads" href='platypiandgreynomads.php'>24/6/2005</a></li>
<li><a title="Blowing Bubbles in a Watery Tomb" href='blowingbubbles.php'>1/7/2005</a></li>
<li><a title="Pieces of History" href='piecesofhistory.php'>8/7/2005</a></li>
<li><a title="Walks and Waterfalls" href='walksandwaterfalls.php'>15/7/2005</a></li>
<li><a title="Mission to Tribulation" href='missiontotribulation.php'>22/7/2005</a></li>
<li><div class='activemenu'>29/7/2005</div></li>
<li><a title="Into the Never Never" href='intothenevernever.php'>5/8/2005</a></li>
<li><a title="Slowing the pace in Darwin" href='slowingthepaceindarwin.php'>12/8/2005</a></li>
<li><a title="Blistering Barnacles and Leaping Lizards" href='leapinglizards.php'>19/8/2005</a></li>
<li><a title="Kakadu and Litchfield" href='kakadu.php'>26/8/2005</a></li>
<li><a title="Legacies of War" href='legaciesofwar.php'>2/9/2005</a></li>
<li><a title="Go West" href='gowest.php'>10/9/2005</a></li>
<li><a title="Things from Above" href='thingsfromabove.php'>16/9/2005</a></li>
<li><a title="The West Coast" href='thewestcoast.php'>23/9/2005</a></li>
<li><a title="Reefs and Red Dust" href='reefsandreddust.php'>30/9/2005</a></li>
<li><a title="The Pilbara" href='pilbara.php'>7/10/2005</a></li>
<li><a title="Paradise with a Headwind" href='paradisewithaheadwind.php'>14/10/2005</a></li>
<li><a title="Down the Coral Coast" href='downthecoralcoast.php'>21/10/2005</a></li>
<li><a title="Pinnacles and Pinnipeds" href='pinnaclesandpinnipeds.php'>28/10/2005</a></li>
<li><a title="A week in Perth" href='perth.php'>4/11/2005</a></li>
<li><a title="The Southwest (from Above and Below)" href='thesouthwest.php'>11/11/2005</a></li>
<li><a title="More Heights and Depths" href='moreheightsanddepths.php'>18/11/2005</a></li>
<li><a title="Across the Nullarbor (and a bit beyond)" href='nullarbor.php'>25/11/2005</a></li>
<li><a title="Double Whammy" href='doublewhammy.php'>9/12/2005</a></li>
<li><a title="Two Cities" href='twocities.php'>19/12/2005</a></li>
<li><a title="Tassie - Part 1" href='tassie1.php'>1/1/2006</a></li>
<li><a title="Tassie - Part 2" href='tassie2.php'>7/1/2006</a></li>
<li><a title="Full Circle" href='fullcircle.php'>26/1/2006</a></li>
<li><a title="The Wrap Up" href='thewrapup.php'>23/3/2006</a></li>
<li> </li><br><li>Or go back to:</li><li><a title='Travelouges and blogs from my trip around Australia' href="nerdseyeview.php">Nerd's Eye View</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>29/7/2005</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Travel stories and pictures' href="travel.php">Travelogues</a> > <a title='Travelouges and blogs from my trip around Australia' href="nerdseyeview.php">Nerd's Eye View</a> > <a title='Levity, Limestone and Lava' href="levitylimestoneandlava.php">29/7/2005</a>
<br><br>		


<h1>Levity, Limestone and Lava</h1>

<a href="images/maps/Map050729.gif"><img src="images/maps/Map050729_sm.gif" align="right"></a>
<p>Oh well, another week has rolled by again with great speed! I hope you are all well and happy.</p>

<p>Half my week this time has been spent in Cairns, at Jen D's place (an old school friend, for those scratching their heads). I have to thank her extensively and most publicly for putting me up (putting up with me?) for 5 nights, and letting me completely redefine her normal sleeping hours.</p>

<p>I arrived in Cairns on the Friday night, having given a Swiss guy a lift. He had spent the trip revelling in my early Metallica collection, in between identifying just about every bird we passed, even the ones that I could barely even make out as birds.</p>

<p>Anyway I arrived late, thanks partially to my own lack of getting-arse-into-gearedness, and partially to some strangers who didn't get the whole "wet roads are slippery" thing, and crashed their cars into each other, thus closing the highway for a time.</p>

<p>Once I arrived we headed to the pub, as you do, and had a few beverages with Jen's workmates. This set a sort of precedent in terms of drinking whilst in Cairns; Saturday we were both quite lazy (and the weather was still crapulous), and we ended up spending the evening watching Triple X the movie (people get confused looks if you write it XXX), and playing some sort of card game (amazing for me, as I normally detest cards, but what can I say; I was drunk...). Anyway I started off losing but ended up winning, so yay.</p>

<p>Sunday was hangover nursing day. Jen needed some small bits of metal to hold up her bookshelves, so we went to Bunnings, and proceeded to take hours to buy one packet of nails, one brush (for cleaning my bike), and one pot plant for her place, which we named Bernie. I think. I wasn't terribly functional that day.</p>

<p>Monday Jen had to work, but she very kindly twisted my arm into staying for a bit longer, and so I had a constructive day in front of the computer using her internet connection for free. Sheer bloody luxury.</p>

<p>I did actually get out on the bike and take some snaps come late afternoon though; as the sky was (amazingly) blue, a fantastic new colour for the area.</p>

<p>Tuesday, I rode out to the botanic gardens and practiced plant photography. Unfortunately the weather had turned lousy again, and I hadn't lugged my tripod along, so many of the snaps I took suffer from low light jitters. Not to worry. I also went and saw Sin City (the movie), which is excellent, if you're a fan of the genre (violence by the bucketload, but god damn it's stylish violence!).</p>

<p>Jen has also turned into quite the geek these days (tongue firmly in cheek), with her own laptop and mp3 setup and so on, so we did some perfectly legal music and movie exchanging, after much wrestling with the network (I'd forgotten how much fun networks can be; ugh).</p>

<p>Anyway that was about it for my stay in Cairns. I didn't go diving, or do anything even remotely touristy. I stayed well away from the hostel where Tim and I had stayed for one night last year, as I found out they host Big Brother evictions there. At the end of the day it was just too much nicer spending time with a mate and having a normal house type existence for a few days.</p>

<p>But one must move on, and so I did, to Chillagoe, which wasn't somewhere I had planned on visiting, but Jen had been there, and it has caves, and I dig caves. Figuratively.</p>

<p>I got there on Wednesday arvo, and explored one of the bigger caves, with about 25 other people and a guide. There wasn't actually any lighting in it, so it was headlamps (well, necklamps). I took in my camera, with tripod, so it made for some interesting photography under pretty difficult lighting conditions.</p>

<p>After that, I visited the site of the old smelter there; it has been closed for more than 50 years so it's a ruin now, but it's still full of amazing stuff to photograph. Rusting, decaying stuff and so on. There is also a slag heap there, with 40 years or so of congealed black goo. You realise at some stage that you're driving/walking on it. It's a BIG pile.</p>

<p>After risking life and limb at the smelter (by crossing a barrier to take a photo - hey, media access all areas! Even those with asbestos!), I headed to the pub where I was staying, via a balancing rock of relatively dubious interest.</p>

<p>At the pub I had a few beers and chatted with the locals, who were mostly all working in the geology field, as there are still quite a few things to discover around and about (just not obvious things any more; alas no more kicking gold nuggets whilst relieving oneself in dry creek beds). The atmosphere was nice, and the steak was average, but massive.</p>

<p>Thursday morning I headed to the other two guided caves in the area, again with camera. This time though there was permanent lighting, so I took a much nicer photos; including a nice bat portrait. Following that, I headed to Undara, to visit the lava tubes, which are big tunnels in the ground left behind from ancient lava flows.</p>

<p>To get there, one has to travel along a dirt road, or backtrack quite a long way. I'd picked out a route, but a couple that I met in Chillagoe said that the locals warned against that track, and to take a longer one. This sounded sensible, and I was set to turn off at the appropriate point, but there was a sign warning that my road of choice was only suitable for vehicles with high clearance.</p>

<p>Remembering my little beach beaching, I thought it prudent to drive down the road 3kms after the turnoff and ask a local. The one I found in the pub (I think he was the ONLY person in town that day) confirmed that my first choice of road was indeed lousy, and that this one was finem despite the sign.</p>

<p>"Nah, that's a good road" he said. No worries in a sedan.</p>

<p>It seems that in the outback, the term "good road" is relative. If one takes good to mean "passable in a normal car with no trouble", then yes, it was good. If one takes good to mean "smooth and comfortable ride", then this was a shite road. But I made it, after 70kms or so of filling-loosening corrugations, half of which were spent behind a very considerate road train that pulled out in front of me. Dussst. Anyone? No? Dussst.</p>

<p>Nothing fell off the car though, so all's well that ends well, as they say. Although I think a piece of my brain fell out.</p>

<p>Anyway, Undara turned out to be another nice spot, and as it was late in the day I decided to stay a night and explore the tubes in the morning. In the evening I did a brief walk and took some nice shots from a lookout. Oh, the weather turned amazing the day I left Cairns of course; it's been clear and blue ever since. Yay. :)</p>

<p>That night the stars came out in force, so I did a couple of star shots, but in the end I couldn't be bothered staying up for more.</p>

<p>Friday morning (this morning as I write this) I did a 3 hour tour of one of the Lava Tubes. It was actually pretty cool. We had an interesting guide too; he was an older fellow full of facts and figures, as well as general scientific information, much of which was quite gloomy, and he pulled no punches in frightening people on subjects ranging from possible volcanic eruptions to global warming and dimming.</p>

<p>He was also quite describable physically. Take Willam H. Macy (the actor), stick a moustache and Acubra on him, and give him a once-scottish-now-aussieish accent, and you have it nailed.</p>

<p>The lava tubes are pretty interesting in themselves; they form when lava flows down natural contours in the land (like creek beds), and eventually get a skin on top. Once the volcanic activity subsides a hollow tube is left. These ones set all sorts of world records - they are pretty damn big too. There is also a really fine dust on the floors (that's what the footprint pic is of).</p>

<p>Anyway I'll let the pics speak for themselves (it's easier than writing). :)</p>

<p>The rest of the day I spent driving to Karumba, which is on the west coast of Cape York, but I'll take up that part of the story next week. :)</p>

<p>Till then, take care and so on...</p>

<p>This week's selected pics:</p>
<!-- 
<ul>
<li><a href="?fileId=IMG_5071.JPG">A ferny thing</a></li>
<li><a href="?fileId=IMG_5256.JPG">Rusty old smelter gear</a></li>
<li><a href="?fileId=IMG_5387.JPG">A face only a mother, or a bat specialist, could love</a></li>
<li><a href="?fileId=IMG_5456.JPG">Picture this full of lava</a></li>
<li><a href="?fileId=IMG_5467.JPG">Ghosts in the lava tube</a></li>
</ul>
 -->
<table width="800">
	<tr>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=IMG_5071.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5071.JPG' ALT='A ferny thing'><BR>A ferny thing</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=IMG_5256.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5256.JPG' ALT='Rusty old smelter gear'><BR>Rusty old smelter gear</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=IMG_5387.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5387.JPG' ALT='A face only a mother, or a bat specialist, could love'><BR>A face only a mother, or a bat specialist, could love</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=IMG_5456.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5456.JPG' ALT='Picture this full of lava'><BR>Picture this full of lava</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=IMG_5467.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5467.JPG' ALT='Ghosts in the lava tube'><BR>Ghosts in the lava tube</a>
	</td>
	</tr>
</table>

<br><br>
All images in this gallery:<br>
<table width='800'>
<tr>
</tr>
<tr><td><A ID='IMG_5044.JPG' href='levitylimestoneandlava.php?fileId=IMG_5044.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5044.JPG' ALT='IMG_5044.JPG'><BR>IMG_5044.JPG<br>76.27 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5044.JPG' ALT='IMG_5044.JPG'>IMG_5044.JPG</a></div></td>
<td><A ID='IMG_5045.JPG' href='levitylimestoneandlava.php?fileId=IMG_5045.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5045.JPG' ALT='IMG_5045.JPG'><BR>IMG_5045.JPG<br>83.72 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5045.JPG' ALT='IMG_5045.JPG'>IMG_5045.JPG</a></div></td>
<td><A ID='IMG_5050.JPG' href='levitylimestoneandlava.php?fileId=IMG_5050.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5050.JPG' ALT='IMG_5050.JPG'><BR>IMG_5050.JPG<br>81.53 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5050.JPG' ALT='IMG_5050.JPG'>IMG_5050.JPG</a></div></td>
<td><A ID='IMG_5053.JPG' href='levitylimestoneandlava.php?fileId=IMG_5053.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5053.JPG' ALT='IMG_5053.JPG'><BR>IMG_5053.JPG<br>47.5 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5053.JPG' ALT='IMG_5053.JPG'>IMG_5053.JPG</a></div></td>
<td><A ID='IMG_5054.JPG' href='levitylimestoneandlava.php?fileId=IMG_5054.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5054.JPG' ALT='IMG_5054.JPG'><BR>IMG_5054.JPG<br>63.8 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5054.JPG' ALT='IMG_5054.JPG'>IMG_5054.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5056.JPG' href='levitylimestoneandlava.php?fileId=IMG_5056.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5056.JPG' ALT='IMG_5056.JPG'><BR>IMG_5056.JPG<br>60.63 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5056.JPG' ALT='IMG_5056.JPG'>IMG_5056.JPG</a></div></td>
<td><A ID='IMG_5059.JPG' href='levitylimestoneandlava.php?fileId=IMG_5059.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5059.JPG' ALT='IMG_5059.JPG'><BR>IMG_5059.JPG<br>68.32 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5059.JPG' ALT='IMG_5059.JPG'>IMG_5059.JPG</a></div></td>
<td><A ID='IMG_5060.JPG' href='levitylimestoneandlava.php?fileId=IMG_5060.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5060.JPG' ALT='IMG_5060.JPG'><BR>IMG_5060.JPG<br>83.27 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5060.JPG' ALT='IMG_5060.JPG'>IMG_5060.JPG</a></div></td>
<td><A ID='IMG_5066.JPG' href='levitylimestoneandlava.php?fileId=IMG_5066.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5066.JPG' ALT='IMG_5066.JPG'><BR>IMG_5066.JPG<br>50.92 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5066.JPG' ALT='IMG_5066.JPG'>IMG_5066.JPG</a></div></td>
<td><A ID='IMG_5068.JPG' href='levitylimestoneandlava.php?fileId=IMG_5068.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5068.JPG' ALT='IMG_5068.JPG'><BR>IMG_5068.JPG<br>48.52 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5068.JPG' ALT='IMG_5068.JPG'>IMG_5068.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5071.JPG' href='levitylimestoneandlava.php?fileId=IMG_5071.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5071.JPG' ALT='IMG_5071.JPG'><BR>IMG_5071.JPG<br>62.23 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5071.JPG' ALT='IMG_5071.JPG'>IMG_5071.JPG</a></div></td>
<td><A ID='IMG_5072.JPG' href='levitylimestoneandlava.php?fileId=IMG_5072.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5072.JPG' ALT='IMG_5072.JPG'><BR>IMG_5072.JPG<br>49.64 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5072.JPG' ALT='IMG_5072.JPG'>IMG_5072.JPG</a></div></td>
<td><A ID='IMG_5076.JPG' href='levitylimestoneandlava.php?fileId=IMG_5076.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5076.JPG' ALT='IMG_5076.JPG'><BR>IMG_5076.JPG<br>50.86 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5076.JPG' ALT='IMG_5076.JPG'>IMG_5076.JPG</a></div></td>
<td><A ID='IMG_5077.JPG' href='levitylimestoneandlava.php?fileId=IMG_5077.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5077.JPG' ALT='IMG_5077.JPG'><BR>IMG_5077.JPG<br>56.24 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5077.JPG' ALT='IMG_5077.JPG'>IMG_5077.JPG</a></div></td>
<td><A ID='IMG_5079.JPG' href='levitylimestoneandlava.php?fileId=IMG_5079.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5079.JPG' ALT='IMG_5079.JPG'><BR>IMG_5079.JPG<br>38.39 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5079.JPG' ALT='IMG_5079.JPG'>IMG_5079.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5081.JPG' href='levitylimestoneandlava.php?fileId=IMG_5081.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5081.JPG' ALT='IMG_5081.JPG'><BR>IMG_5081.JPG<br>67.54 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5081.JPG' ALT='IMG_5081.JPG'>IMG_5081.JPG</a></div></td>
<td><A ID='IMG_5088.JPG' href='levitylimestoneandlava.php?fileId=IMG_5088.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5088.JPG' ALT='IMG_5088.JPG'><BR>IMG_5088.JPG<br>85.42 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5088.JPG' ALT='IMG_5088.JPG'>IMG_5088.JPG</a></div></td>
<td><A ID='IMG_5091.JPG' href='levitylimestoneandlava.php?fileId=IMG_5091.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5091.JPG' ALT='IMG_5091.JPG'><BR>IMG_5091.JPG<br>52.7 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5091.JPG' ALT='IMG_5091.JPG'>IMG_5091.JPG</a></div></td>
<td><A ID='IMG_5092.JPG' href='levitylimestoneandlava.php?fileId=IMG_5092.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5092.JPG' ALT='IMG_5092.JPG'><BR>IMG_5092.JPG<br>79.12 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5092.JPG' ALT='IMG_5092.JPG'>IMG_5092.JPG</a></div></td>
<td><A ID='IMG_5093.JPG' href='levitylimestoneandlava.php?fileId=IMG_5093.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5093.JPG' ALT='IMG_5093.JPG'><BR>IMG_5093.JPG<br>56.74 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5093.JPG' ALT='IMG_5093.JPG'>IMG_5093.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5094.JPG' href='levitylimestoneandlava.php?fileId=IMG_5094.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5094.JPG' ALT='IMG_5094.JPG'><BR>IMG_5094.JPG<br>131.18 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5094.JPG' ALT='IMG_5094.JPG'>IMG_5094.JPG</a></div></td>
<td><A ID='IMG_5096.JPG' href='levitylimestoneandlava.php?fileId=IMG_5096.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5096.JPG' ALT='IMG_5096.JPG'><BR>IMG_5096.JPG<br>82.83 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5096.JPG' ALT='IMG_5096.JPG'>IMG_5096.JPG</a></div></td>
<td><A ID='IMG_5100.JPG' href='levitylimestoneandlava.php?fileId=IMG_5100.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5100.JPG' ALT='IMG_5100.JPG'><BR>IMG_5100.JPG<br>49.97 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5100.JPG' ALT='IMG_5100.JPG'>IMG_5100.JPG</a></div></td>
<td><A ID='IMG_5104.JPG' href='levitylimestoneandlava.php?fileId=IMG_5104.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5104.JPG' ALT='IMG_5104.JPG'><BR>IMG_5104.JPG<br>84.26 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5104.JPG' ALT='IMG_5104.JPG'>IMG_5104.JPG</a></div></td>
<td><A ID='IMG_5106.JPG' href='levitylimestoneandlava.php?fileId=IMG_5106.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5106.JPG' ALT='IMG_5106.JPG'><BR>IMG_5106.JPG<br>118.38 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5106.JPG' ALT='IMG_5106.JPG'>IMG_5106.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5108.JPG' href='levitylimestoneandlava.php?fileId=IMG_5108.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5108.JPG' ALT='IMG_5108.JPG'><BR>IMG_5108.JPG<br>105.72 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5108.JPG' ALT='IMG_5108.JPG'>IMG_5108.JPG</a></div></td>
<td><A ID='IMG_5109.JPG' href='levitylimestoneandlava.php?fileId=IMG_5109.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5109.JPG' ALT='IMG_5109.JPG'><BR>IMG_5109.JPG<br>112.47 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5109.JPG' ALT='IMG_5109.JPG'>IMG_5109.JPG</a></div></td>
<td><A ID='IMG_5110.JPG' href='levitylimestoneandlava.php?fileId=IMG_5110.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5110.JPG' ALT='IMG_5110.JPG'><BR>IMG_5110.JPG<br>112.66 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5110.JPG' ALT='IMG_5110.JPG'>IMG_5110.JPG</a></div></td>
<td><A ID='IMG_5112.JPG' href='levitylimestoneandlava.php?fileId=IMG_5112.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5112.JPG' ALT='IMG_5112.JPG'><BR>IMG_5112.JPG<br>84.42 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5112.JPG' ALT='IMG_5112.JPG'>IMG_5112.JPG</a></div></td>
<td><A ID='IMG_5114.JPG' href='levitylimestoneandlava.php?fileId=IMG_5114.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5114.JPG' ALT='IMG_5114.JPG'><BR>IMG_5114.JPG<br>109.41 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5114.JPG' ALT='IMG_5114.JPG'>IMG_5114.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5115.JPG' href='levitylimestoneandlava.php?fileId=IMG_5115.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5115.JPG' ALT='IMG_5115.JPG'><BR>IMG_5115.JPG<br>98.17 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5115.JPG' ALT='IMG_5115.JPG'>IMG_5115.JPG</a></div></td>
<td><A ID='IMG_5117.JPG' href='levitylimestoneandlava.php?fileId=IMG_5117.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5117.JPG' ALT='IMG_5117.JPG'><BR>IMG_5117.JPG<br>140.49 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5117.JPG' ALT='IMG_5117.JPG'>IMG_5117.JPG</a></div></td>
<td><A ID='IMG_5118.JPG' href='levitylimestoneandlava.php?fileId=IMG_5118.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5118.JPG' ALT='IMG_5118.JPG'><BR>IMG_5118.JPG<br>123.46 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5118.JPG' ALT='IMG_5118.JPG'>IMG_5118.JPG</a></div></td>
<td><A ID='IMG_5122.JPG' href='levitylimestoneandlava.php?fileId=IMG_5122.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5122.JPG' ALT='IMG_5122.JPG'><BR>IMG_5122.JPG<br>53.53 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5122.JPG' ALT='IMG_5122.JPG'>IMG_5122.JPG</a></div></td>
<td><A ID='IMG_5123.JPG' href='levitylimestoneandlava.php?fileId=IMG_5123.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5123.JPG' ALT='IMG_5123.JPG'><BR>IMG_5123.JPG<br>72.16 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5123.JPG' ALT='IMG_5123.JPG'>IMG_5123.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5124.JPG' href='levitylimestoneandlava.php?fileId=IMG_5124.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5124.JPG' ALT='IMG_5124.JPG'><BR>IMG_5124.JPG<br>95.25 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5124.JPG' ALT='IMG_5124.JPG'>IMG_5124.JPG</a></div></td>
<td><A ID='IMG_5126.JPG' href='levitylimestoneandlava.php?fileId=IMG_5126.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5126.JPG' ALT='IMG_5126.JPG'><BR>IMG_5126.JPG<br>76.97 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5126.JPG' ALT='IMG_5126.JPG'>IMG_5126.JPG</a></div></td>
<td><A ID='IMG_5128.JPG' href='levitylimestoneandlava.php?fileId=IMG_5128.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5128.JPG' ALT='IMG_5128.JPG'><BR>IMG_5128.JPG<br>64.08 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5128.JPG' ALT='IMG_5128.JPG'>IMG_5128.JPG</a></div></td>
<td><A ID='IMG_5129.JPG' href='levitylimestoneandlava.php?fileId=IMG_5129.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5129.JPG' ALT='IMG_5129.JPG'><BR>IMG_5129.JPG<br>61.9 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5129.JPG' ALT='IMG_5129.JPG'>IMG_5129.JPG</a></div></td>
<td><A ID='IMG_5131.JPG' href='levitylimestoneandlava.php?fileId=IMG_5131.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5131.JPG' ALT='IMG_5131.JPG'><BR>IMG_5131.JPG<br>71.11 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5131.JPG' ALT='IMG_5131.JPG'>IMG_5131.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5133.JPG' href='levitylimestoneandlava.php?fileId=IMG_5133.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5133.JPG' ALT='IMG_5133.JPG'><BR>IMG_5133.JPG<br>64.5 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5133.JPG' ALT='IMG_5133.JPG'>IMG_5133.JPG</a></div></td>
<td><A ID='IMG_5134.JPG' href='levitylimestoneandlava.php?fileId=IMG_5134.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5134.JPG' ALT='IMG_5134.JPG'><BR>IMG_5134.JPG<br>108.79 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5134.JPG' ALT='IMG_5134.JPG'>IMG_5134.JPG</a></div></td>
<td><A ID='IMG_5135.JPG' href='levitylimestoneandlava.php?fileId=IMG_5135.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5135.JPG' ALT='IMG_5135.JPG'><BR>IMG_5135.JPG<br>52.16 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5135.JPG' ALT='IMG_5135.JPG'>IMG_5135.JPG</a></div></td>
<td><A ID='IMG_5136.JPG' href='levitylimestoneandlava.php?fileId=IMG_5136.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5136.JPG' ALT='IMG_5136.JPG'><BR>IMG_5136.JPG<br>43.85 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5136.JPG' ALT='IMG_5136.JPG'>IMG_5136.JPG</a></div></td>
<td><A ID='IMG_5137.JPG' href='levitylimestoneandlava.php?fileId=IMG_5137.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5137.JPG' ALT='IMG_5137.JPG'><BR>IMG_5137.JPG<br>50.17 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5137.JPG' ALT='IMG_5137.JPG'>IMG_5137.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5141.JPG' href='levitylimestoneandlava.php?fileId=IMG_5141.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5141.JPG' ALT='IMG_5141.JPG'><BR>IMG_5141.JPG<br>58.32 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5141.JPG' ALT='IMG_5141.JPG'>IMG_5141.JPG</a></div></td>
<td><A ID='IMG_5144.JPG' href='levitylimestoneandlava.php?fileId=IMG_5144.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5144.JPG' ALT='IMG_5144.JPG'><BR>IMG_5144.JPG<br>48.37 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5144.JPG' ALT='IMG_5144.JPG'>IMG_5144.JPG</a></div></td>
<td><A ID='IMG_5145.JPG' href='levitylimestoneandlava.php?fileId=IMG_5145.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5145.JPG' ALT='IMG_5145.JPG'><BR>IMG_5145.JPG<br>86.75 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5145.JPG' ALT='IMG_5145.JPG'>IMG_5145.JPG</a></div></td>
<td><A ID='IMG_5147.JPG' href='levitylimestoneandlava.php?fileId=IMG_5147.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5147.JPG' ALT='IMG_5147.JPG'><BR>IMG_5147.JPG<br>53.26 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5147.JPG' ALT='IMG_5147.JPG'>IMG_5147.JPG</a></div></td>
<td><A ID='IMG_5148.JPG' href='levitylimestoneandlava.php?fileId=IMG_5148.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5148.JPG' ALT='IMG_5148.JPG'><BR>IMG_5148.JPG<br>65.4 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5148.JPG' ALT='IMG_5148.JPG'>IMG_5148.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5155.JPG' href='levitylimestoneandlava.php?fileId=IMG_5155.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5155.JPG' ALT='IMG_5155.JPG'><BR>IMG_5155.JPG<br>67 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5155.JPG' ALT='IMG_5155.JPG'>IMG_5155.JPG</a></div></td>
<td><A ID='IMG_5160.JPG' href='levitylimestoneandlava.php?fileId=IMG_5160.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5160.JPG' ALT='IMG_5160.JPG'><BR>IMG_5160.JPG<br>79.33 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5160.JPG' ALT='IMG_5160.JPG'>IMG_5160.JPG</a></div></td>
<td><A ID='IMG_5164.JPG' href='levitylimestoneandlava.php?fileId=IMG_5164.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5164.JPG' ALT='IMG_5164.JPG'><BR>IMG_5164.JPG<br>63.74 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5164.JPG' ALT='IMG_5164.JPG'>IMG_5164.JPG</a></div></td>
<td><A ID='IMG_5165.JPG' href='levitylimestoneandlava.php?fileId=IMG_5165.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5165.JPG' ALT='IMG_5165.JPG'><BR>IMG_5165.JPG<br>53.94 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5165.JPG' ALT='IMG_5165.JPG'>IMG_5165.JPG</a></div></td>
<td><A ID='IMG_5168.JPG' href='levitylimestoneandlava.php?fileId=IMG_5168.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5168.JPG' ALT='IMG_5168.JPG'><BR>IMG_5168.JPG<br>90.6 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5168.JPG' ALT='IMG_5168.JPG'>IMG_5168.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5171.JPG' href='levitylimestoneandlava.php?fileId=IMG_5171.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5171.JPG' ALT='IMG_5171.JPG'><BR>IMG_5171.JPG<br>68.79 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5171.JPG' ALT='IMG_5171.JPG'>IMG_5171.JPG</a></div></td>
<td><A ID='IMG_5177.JPG' href='levitylimestoneandlava.php?fileId=IMG_5177.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5177.JPG' ALT='IMG_5177.JPG'><BR>IMG_5177.JPG<br>63.25 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5177.JPG' ALT='IMG_5177.JPG'>IMG_5177.JPG</a></div></td>
<td><A ID='IMG_5178.JPG' href='levitylimestoneandlava.php?fileId=IMG_5178.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5178.JPG' ALT='IMG_5178.JPG'><BR>IMG_5178.JPG<br>65.75 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5178.JPG' ALT='IMG_5178.JPG'>IMG_5178.JPG</a></div></td>
<td><A ID='IMG_5180.JPG' href='levitylimestoneandlava.php?fileId=IMG_5180.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5180.JPG' ALT='IMG_5180.JPG'><BR>IMG_5180.JPG<br>56.96 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5180.JPG' ALT='IMG_5180.JPG'>IMG_5180.JPG</a></div></td>
<td><A ID='IMG_5182.JPG' href='levitylimestoneandlava.php?fileId=IMG_5182.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5182.JPG' ALT='IMG_5182.JPG'><BR>IMG_5182.JPG<br>75.56 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5182.JPG' ALT='IMG_5182.JPG'>IMG_5182.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5183.JPG' href='levitylimestoneandlava.php?fileId=IMG_5183.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5183.JPG' ALT='IMG_5183.JPG'><BR>IMG_5183.JPG<br>72.69 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5183.JPG' ALT='IMG_5183.JPG'>IMG_5183.JPG</a></div></td>
<td><A ID='IMG_5190.JPG' href='levitylimestoneandlava.php?fileId=IMG_5190.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5190.JPG' ALT='IMG_5190.JPG'><BR>IMG_5190.JPG<br>80.55 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5190.JPG' ALT='IMG_5190.JPG'>IMG_5190.JPG</a></div></td>
<td><A ID='IMG_5196.JPG' href='levitylimestoneandlava.php?fileId=IMG_5196.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5196.JPG' ALT='IMG_5196.JPG'><BR>IMG_5196.JPG<br>73.15 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5196.JPG' ALT='IMG_5196.JPG'>IMG_5196.JPG</a></div></td>
<td><A ID='IMG_5207.JPG' href='levitylimestoneandlava.php?fileId=IMG_5207.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5207.JPG' ALT='IMG_5207.JPG'><BR>IMG_5207.JPG<br>42.12 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5207.JPG' ALT='IMG_5207.JPG'>IMG_5207.JPG</a></div></td>
<td><A ID='IMG_5224.JPG' href='levitylimestoneandlava.php?fileId=IMG_5224.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5224.JPG' ALT='IMG_5224.JPG'><BR>IMG_5224.JPG<br>65.76 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5224.JPG' ALT='IMG_5224.JPG'>IMG_5224.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5225.JPG' href='levitylimestoneandlava.php?fileId=IMG_5225.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5225.JPG' ALT='IMG_5225.JPG'><BR>IMG_5225.JPG<br>57.95 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5225.JPG' ALT='IMG_5225.JPG'>IMG_5225.JPG</a></div></td>
<td><A ID='IMG_5226.JPG' href='levitylimestoneandlava.php?fileId=IMG_5226.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5226.JPG' ALT='IMG_5226.JPG'><BR>IMG_5226.JPG<br>75.4 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5226.JPG' ALT='IMG_5226.JPG'>IMG_5226.JPG</a></div></td>
<td><A ID='IMG_5238.JPG' href='levitylimestoneandlava.php?fileId=IMG_5238.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5238.JPG' ALT='IMG_5238.JPG'><BR>IMG_5238.JPG<br>81.17 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5238.JPG' ALT='IMG_5238.JPG'>IMG_5238.JPG</a></div></td>
<td><A ID='IMG_5242.JPG' href='levitylimestoneandlava.php?fileId=IMG_5242.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5242.JPG' ALT='IMG_5242.JPG'><BR>IMG_5242.JPG<br>71.55 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5242.JPG' ALT='IMG_5242.JPG'>IMG_5242.JPG</a></div></td>
<td><A ID='IMG_5245.JPG' href='levitylimestoneandlava.php?fileId=IMG_5245.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5245.JPG' ALT='IMG_5245.JPG'><BR>IMG_5245.JPG<br>52.03 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5245.JPG' ALT='IMG_5245.JPG'>IMG_5245.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5253.JPG' href='levitylimestoneandlava.php?fileId=IMG_5253.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5253.JPG' ALT='IMG_5253.JPG'><BR>IMG_5253.JPG<br>142.06 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5253.JPG' ALT='IMG_5253.JPG'>IMG_5253.JPG</a></div></td>
<td><A ID='IMG_5254.JPG' href='levitylimestoneandlava.php?fileId=IMG_5254.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5254.JPG' ALT='IMG_5254.JPG'><BR>IMG_5254.JPG<br>64.01 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5254.JPG' ALT='IMG_5254.JPG'>IMG_5254.JPG</a></div></td>
<td><A ID='IMG_5255.JPG' href='levitylimestoneandlava.php?fileId=IMG_5255.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5255.JPG' ALT='IMG_5255.JPG'><BR>IMG_5255.JPG<br>112.93 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5255.JPG' ALT='IMG_5255.JPG'>IMG_5255.JPG</a></div></td>
<td><A ID='IMG_5256.JPG' href='levitylimestoneandlava.php?fileId=IMG_5256.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5256.JPG' ALT='IMG_5256.JPG'><BR>IMG_5256.JPG<br>96.39 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5256.JPG' ALT='IMG_5256.JPG'>IMG_5256.JPG</a></div></td>
<td><A ID='IMG_5257.JPG' href='levitylimestoneandlava.php?fileId=IMG_5257.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5257.JPG' ALT='IMG_5257.JPG'><BR>IMG_5257.JPG<br>66.79 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5257.JPG' ALT='IMG_5257.JPG'>IMG_5257.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5260.JPG' href='levitylimestoneandlava.php?fileId=IMG_5260.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5260.JPG' ALT='IMG_5260.JPG'><BR>IMG_5260.JPG<br>68.99 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5260.JPG' ALT='IMG_5260.JPG'>IMG_5260.JPG</a></div></td>
<td><A ID='IMG_5261.JPG' href='levitylimestoneandlava.php?fileId=IMG_5261.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5261.JPG' ALT='IMG_5261.JPG'><BR>IMG_5261.JPG<br>78.27 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5261.JPG' ALT='IMG_5261.JPG'>IMG_5261.JPG</a></div></td>
<td><A ID='IMG_5264.JPG' href='levitylimestoneandlava.php?fileId=IMG_5264.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5264.JPG' ALT='IMG_5264.JPG'><BR>IMG_5264.JPG<br>90.4 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5264.JPG' ALT='IMG_5264.JPG'>IMG_5264.JPG</a></div></td>
<td><A ID='IMG_5266.JPG' href='levitylimestoneandlava.php?fileId=IMG_5266.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5266.JPG' ALT='IMG_5266.JPG'><BR>IMG_5266.JPG<br>94.05 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5266.JPG' ALT='IMG_5266.JPG'>IMG_5266.JPG</a></div></td>
<td><A ID='IMG_5270.JPG' href='levitylimestoneandlava.php?fileId=IMG_5270.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5270.JPG' ALT='IMG_5270.JPG'><BR>IMG_5270.JPG<br>67.72 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5270.JPG' ALT='IMG_5270.JPG'>IMG_5270.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5271.JPG' href='levitylimestoneandlava.php?fileId=IMG_5271.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5271.JPG' ALT='IMG_5271.JPG'><BR>IMG_5271.JPG<br>83.99 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5271.JPG' ALT='IMG_5271.JPG'>IMG_5271.JPG</a></div></td>
<td><A ID='IMG_5273.JPG' href='levitylimestoneandlava.php?fileId=IMG_5273.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5273.JPG' ALT='IMG_5273.JPG'><BR>IMG_5273.JPG<br>92.25 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5273.JPG' ALT='IMG_5273.JPG'>IMG_5273.JPG</a></div></td>
<td><A ID='IMG_5274.JPG' href='levitylimestoneandlava.php?fileId=IMG_5274.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5274.JPG' ALT='IMG_5274.JPG'><BR>IMG_5274.JPG<br>107.05 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5274.JPG' ALT='IMG_5274.JPG'>IMG_5274.JPG</a></div></td>
<td><A ID='IMG_5275.JPG' href='levitylimestoneandlava.php?fileId=IMG_5275.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5275.JPG' ALT='IMG_5275.JPG'><BR>IMG_5275.JPG<br>62.41 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5275.JPG' ALT='IMG_5275.JPG'>IMG_5275.JPG</a></div></td>
<td><A ID='IMG_5277.JPG' href='levitylimestoneandlava.php?fileId=IMG_5277.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5277.JPG' ALT='IMG_5277.JPG'><BR>IMG_5277.JPG<br>111.81 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5277.JPG' ALT='IMG_5277.JPG'>IMG_5277.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5279.JPG' href='levitylimestoneandlava.php?fileId=IMG_5279.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5279.JPG' ALT='IMG_5279.JPG'><BR>IMG_5279.JPG<br>26.88 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5279.JPG' ALT='IMG_5279.JPG'>IMG_5279.JPG</a></div></td>
<td><A ID='IMG_5281.JPG' href='levitylimestoneandlava.php?fileId=IMG_5281.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5281.JPG' ALT='IMG_5281.JPG'><BR>IMG_5281.JPG<br>76.86 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5281.JPG' ALT='IMG_5281.JPG'>IMG_5281.JPG</a></div></td>
<td><A ID='IMG_5282.JPG' href='levitylimestoneandlava.php?fileId=IMG_5282.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5282.JPG' ALT='IMG_5282.JPG'><BR>IMG_5282.JPG<br>50.61 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5282.JPG' ALT='IMG_5282.JPG'>IMG_5282.JPG</a></div></td>
<td><A ID='IMG_5288.JPG' href='levitylimestoneandlava.php?fileId=IMG_5288.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5288.JPG' ALT='IMG_5288.JPG'><BR>IMG_5288.JPG<br>119.19 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5288.JPG' ALT='IMG_5288.JPG'>IMG_5288.JPG</a></div></td>
<td><A ID='IMG_5289.JPG' href='levitylimestoneandlava.php?fileId=IMG_5289.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5289.JPG' ALT='IMG_5289.JPG'><BR>IMG_5289.JPG<br>122.03 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5289.JPG' ALT='IMG_5289.JPG'>IMG_5289.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5293.JPG' href='levitylimestoneandlava.php?fileId=IMG_5293.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5293.JPG' ALT='IMG_5293.JPG'><BR>IMG_5293.JPG<br>77.25 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5293.JPG' ALT='IMG_5293.JPG'>IMG_5293.JPG</a></div></td>
<td><A ID='IMG_5295.JPG' href='levitylimestoneandlava.php?fileId=IMG_5295.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5295.JPG' ALT='IMG_5295.JPG'><BR>IMG_5295.JPG<br>137.89 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5295.JPG' ALT='IMG_5295.JPG'>IMG_5295.JPG</a></div></td>
<td><A ID='IMG_5296.JPG' href='levitylimestoneandlava.php?fileId=IMG_5296.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5296.JPG' ALT='IMG_5296.JPG'><BR>IMG_5296.JPG<br>94.35 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5296.JPG' ALT='IMG_5296.JPG'>IMG_5296.JPG</a></div></td>
<td><A ID='IMG_5301.JPG' href='levitylimestoneandlava.php?fileId=IMG_5301.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5301.JPG' ALT='IMG_5301.JPG'><BR>IMG_5301.JPG<br>90.53 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5301.JPG' ALT='IMG_5301.JPG'>IMG_5301.JPG</a></div></td>
<td><A ID='IMG_5304.JPG' href='levitylimestoneandlava.php?fileId=IMG_5304.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5304.JPG' ALT='IMG_5304.JPG'><BR>IMG_5304.JPG<br>80.76 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5304.JPG' ALT='IMG_5304.JPG'>IMG_5304.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5309.JPG' href='levitylimestoneandlava.php?fileId=IMG_5309.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5309.JPG' ALT='IMG_5309.JPG'><BR>IMG_5309.JPG<br>73.53 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5309.JPG' ALT='IMG_5309.JPG'>IMG_5309.JPG</a></div></td>
<td><A ID='IMG_5310.JPG' href='levitylimestoneandlava.php?fileId=IMG_5310.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5310.JPG' ALT='IMG_5310.JPG'><BR>IMG_5310.JPG<br>94.41 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5310.JPG' ALT='IMG_5310.JPG'>IMG_5310.JPG</a></div></td>
<td><A ID='IMG_5318.JPG' href='levitylimestoneandlava.php?fileId=IMG_5318.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5318.JPG' ALT='IMG_5318.JPG'><BR>IMG_5318.JPG<br>73.65 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5318.JPG' ALT='IMG_5318.JPG'>IMG_5318.JPG</a></div></td>
<td><A ID='IMG_5320.JPG' href='levitylimestoneandlava.php?fileId=IMG_5320.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5320.JPG' ALT='IMG_5320.JPG'><BR>IMG_5320.JPG<br>74.46 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5320.JPG' ALT='IMG_5320.JPG'>IMG_5320.JPG</a></div></td>
<td><A ID='IMG_5321.JPG' href='levitylimestoneandlava.php?fileId=IMG_5321.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5321.JPG' ALT='IMG_5321.JPG'><BR>IMG_5321.JPG<br>66.58 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5321.JPG' ALT='IMG_5321.JPG'>IMG_5321.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5323.JPG' href='levitylimestoneandlava.php?fileId=IMG_5323.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5323.JPG' ALT='IMG_5323.JPG'><BR>IMG_5323.JPG<br>84.54 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5323.JPG' ALT='IMG_5323.JPG'>IMG_5323.JPG</a></div></td>
<td><A ID='IMG_5328.JPG' href='levitylimestoneandlava.php?fileId=IMG_5328.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5328.JPG' ALT='IMG_5328.JPG'><BR>IMG_5328.JPG<br>77.12 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5328.JPG' ALT='IMG_5328.JPG'>IMG_5328.JPG</a></div></td>
<td><A ID='IMG_5329.JPG' href='levitylimestoneandlava.php?fileId=IMG_5329.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5329.JPG' ALT='IMG_5329.JPG'><BR>IMG_5329.JPG<br>71.05 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5329.JPG' ALT='IMG_5329.JPG'>IMG_5329.JPG</a></div></td>
<td><A ID='IMG_5332.JPG' href='levitylimestoneandlava.php?fileId=IMG_5332.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5332.JPG' ALT='IMG_5332.JPG'><BR>IMG_5332.JPG<br>90.11 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5332.JPG' ALT='IMG_5332.JPG'>IMG_5332.JPG</a></div></td>
<td><A ID='IMG_5335.JPG' href='levitylimestoneandlava.php?fileId=IMG_5335.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5335.JPG' ALT='IMG_5335.JPG'><BR>IMG_5335.JPG<br>76.42 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5335.JPG' ALT='IMG_5335.JPG'>IMG_5335.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5338.JPG' href='levitylimestoneandlava.php?fileId=IMG_5338.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5338.JPG' ALT='IMG_5338.JPG'><BR>IMG_5338.JPG<br>104.25 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5338.JPG' ALT='IMG_5338.JPG'>IMG_5338.JPG</a></div></td>
<td><A ID='IMG_5342.JPG' href='levitylimestoneandlava.php?fileId=IMG_5342.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5342.JPG' ALT='IMG_5342.JPG'><BR>IMG_5342.JPG<br>58.97 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5342.JPG' ALT='IMG_5342.JPG'>IMG_5342.JPG</a></div></td>
<td><A ID='IMG_5346.JPG' href='levitylimestoneandlava.php?fileId=IMG_5346.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5346.JPG' ALT='IMG_5346.JPG'><BR>IMG_5346.JPG<br>85.34 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5346.JPG' ALT='IMG_5346.JPG'>IMG_5346.JPG</a></div></td>
<td><A ID='IMG_5349.JPG' href='levitylimestoneandlava.php?fileId=IMG_5349.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5349.JPG' ALT='IMG_5349.JPG'><BR>IMG_5349.JPG<br>105.48 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5349.JPG' ALT='IMG_5349.JPG'>IMG_5349.JPG</a></div></td>
<td><A ID='IMG_5350.JPG' href='levitylimestoneandlava.php?fileId=IMG_5350.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5350.JPG' ALT='IMG_5350.JPG'><BR>IMG_5350.JPG<br>54.83 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5350.JPG' ALT='IMG_5350.JPG'>IMG_5350.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5353.JPG' href='levitylimestoneandlava.php?fileId=IMG_5353.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5353.JPG' ALT='IMG_5353.JPG'><BR>IMG_5353.JPG<br>54.52 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5353.JPG' ALT='IMG_5353.JPG'>IMG_5353.JPG</a></div></td>
<td><A ID='IMG_5362.JPG' href='levitylimestoneandlava.php?fileId=IMG_5362.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5362.JPG' ALT='IMG_5362.JPG'><BR>IMG_5362.JPG<br>64.95 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5362.JPG' ALT='IMG_5362.JPG'>IMG_5362.JPG</a></div></td>
<td><A ID='IMG_5372.JPG' href='levitylimestoneandlava.php?fileId=IMG_5372.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5372.JPG' ALT='IMG_5372.JPG'><BR>IMG_5372.JPG<br>63.52 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5372.JPG' ALT='IMG_5372.JPG'>IMG_5372.JPG</a></div></td>
<td><A ID='IMG_5374.JPG' href='levitylimestoneandlava.php?fileId=IMG_5374.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5374.JPG' ALT='IMG_5374.JPG'><BR>IMG_5374.JPG<br>96.02 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5374.JPG' ALT='IMG_5374.JPG'>IMG_5374.JPG</a></div></td>
<td><A ID='IMG_5378.JPG' href='levitylimestoneandlava.php?fileId=IMG_5378.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5378.JPG' ALT='IMG_5378.JPG'><BR>IMG_5378.JPG<br>75.13 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5378.JPG' ALT='IMG_5378.JPG'>IMG_5378.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5381.JPG' href='levitylimestoneandlava.php?fileId=IMG_5381.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5381.JPG' ALT='IMG_5381.JPG'><BR>IMG_5381.JPG<br>74.71 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5381.JPG' ALT='IMG_5381.JPG'>IMG_5381.JPG</a></div></td>
<td><A ID='IMG_5384.JPG' href='levitylimestoneandlava.php?fileId=IMG_5384.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5384.JPG' ALT='IMG_5384.JPG'><BR>IMG_5384.JPG<br>92.87 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5384.JPG' ALT='IMG_5384.JPG'>IMG_5384.JPG</a></div></td>
<td><A ID='IMG_5387.JPG' href='levitylimestoneandlava.php?fileId=IMG_5387.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5387.JPG' ALT='IMG_5387.JPG'><BR>IMG_5387.JPG<br>57.1 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5387.JPG' ALT='IMG_5387.JPG'>IMG_5387.JPG</a></div></td>
<td><A ID='IMG_5388.JPG' href='levitylimestoneandlava.php?fileId=IMG_5388.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5388.JPG' ALT='IMG_5388.JPG'><BR>IMG_5388.JPG<br>79.76 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5388.JPG' ALT='IMG_5388.JPG'>IMG_5388.JPG</a></div></td>
<td><A ID='IMG_5392.JPG' href='levitylimestoneandlava.php?fileId=IMG_5392.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5392.JPG' ALT='IMG_5392.JPG'><BR>IMG_5392.JPG<br>77.27 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5392.JPG' ALT='IMG_5392.JPG'>IMG_5392.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5394.JPG' href='levitylimestoneandlava.php?fileId=IMG_5394.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5394.JPG' ALT='IMG_5394.JPG'><BR>IMG_5394.JPG<br>80.8 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5394.JPG' ALT='IMG_5394.JPG'>IMG_5394.JPG</a></div></td>
<td><A ID='IMG_5405.JPG' href='levitylimestoneandlava.php?fileId=IMG_5405.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5405.JPG' ALT='IMG_5405.JPG'><BR>IMG_5405.JPG<br>110.7 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5405.JPG' ALT='IMG_5405.JPG'>IMG_5405.JPG</a></div></td>
<td><A ID='IMG_5406.JPG' href='levitylimestoneandlava.php?fileId=IMG_5406.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5406.JPG' ALT='IMG_5406.JPG'><BR>IMG_5406.JPG<br>91.79 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5406.JPG' ALT='IMG_5406.JPG'>IMG_5406.JPG</a></div></td>
<td><A ID='IMG_5433.JPG' href='levitylimestoneandlava.php?fileId=IMG_5433.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5433.JPG' ALT='IMG_5433.JPG'><BR>IMG_5433.JPG<br>88.56 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5433.JPG' ALT='IMG_5433.JPG'>IMG_5433.JPG</a></div></td>
<td><A ID='IMG_5442.JPG' href='levitylimestoneandlava.php?fileId=IMG_5442.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5442.JPG' ALT='IMG_5442.JPG'><BR>IMG_5442.JPG<br>52.76 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5442.JPG' ALT='IMG_5442.JPG'>IMG_5442.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5452.JPG' href='levitylimestoneandlava.php?fileId=IMG_5452.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5452.JPG' ALT='IMG_5452.JPG'><BR>IMG_5452.JPG<br>75.82 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5452.JPG' ALT='IMG_5452.JPG'>IMG_5452.JPG</a></div></td>
<td><A ID='IMG_5453.JPG' href='levitylimestoneandlava.php?fileId=IMG_5453.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5453.JPG' ALT='IMG_5453.JPG'><BR>IMG_5453.JPG<br>130.08 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5453.JPG' ALT='IMG_5453.JPG'>IMG_5453.JPG</a></div></td>
<td><A ID='IMG_5454.JPG' href='levitylimestoneandlava.php?fileId=IMG_5454.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5454.JPG' ALT='IMG_5454.JPG'><BR>IMG_5454.JPG<br>80.14 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5454.JPG' ALT='IMG_5454.JPG'>IMG_5454.JPG</a></div></td>
<td><A ID='IMG_5455.JPG' href='levitylimestoneandlava.php?fileId=IMG_5455.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5455.JPG' ALT='IMG_5455.JPG'><BR>IMG_5455.JPG<br>94.35 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5455.JPG' ALT='IMG_5455.JPG'>IMG_5455.JPG</a></div></td>
<td><A ID='IMG_5456.JPG' href='levitylimestoneandlava.php?fileId=IMG_5456.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5456.JPG' ALT='IMG_5456.JPG'><BR>IMG_5456.JPG<br>90.74 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5456.JPG' ALT='IMG_5456.JPG'>IMG_5456.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5458.JPG' href='levitylimestoneandlava.php?fileId=IMG_5458.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5458.JPG' ALT='IMG_5458.JPG'><BR>IMG_5458.JPG<br>98.95 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5458.JPG' ALT='IMG_5458.JPG'>IMG_5458.JPG</a></div></td>
<td><A ID='IMG_5459.JPG' href='levitylimestoneandlava.php?fileId=IMG_5459.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5459.JPG' ALT='IMG_5459.JPG'><BR>IMG_5459.JPG<br>89.42 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5459.JPG' ALT='IMG_5459.JPG'>IMG_5459.JPG</a></div></td>
<td><A ID='IMG_5465.JPG' href='levitylimestoneandlava.php?fileId=IMG_5465.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5465.JPG' ALT='IMG_5465.JPG'><BR>IMG_5465.JPG<br>88.29 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5465.JPG' ALT='IMG_5465.JPG'>IMG_5465.JPG</a></div></td>
<td><A ID='IMG_5467.JPG' href='levitylimestoneandlava.php?fileId=IMG_5467.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5467.JPG' ALT='IMG_5467.JPG'><BR>IMG_5467.JPG<br>63.38 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5467.JPG' ALT='IMG_5467.JPG'>IMG_5467.JPG</a></div></td>
<td><A ID='IMG_5477.JPG' href='levitylimestoneandlava.php?fileId=IMG_5477.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5477.JPG' ALT='IMG_5477.JPG'><BR>IMG_5477.JPG<br>80.16 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5477.JPG' ALT='IMG_5477.JPG'>IMG_5477.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5479.JPG' href='levitylimestoneandlava.php?fileId=IMG_5479.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5479.JPG' ALT='IMG_5479.JPG'><BR>IMG_5479.JPG<br>96.77 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5479.JPG' ALT='IMG_5479.JPG'>IMG_5479.JPG</a></div></td>
<td><A ID='IMG_5484.JPG' href='levitylimestoneandlava.php?fileId=IMG_5484.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5484.JPG' ALT='IMG_5484.JPG'><BR>IMG_5484.JPG<br>80.19 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5484.JPG' ALT='IMG_5484.JPG'>IMG_5484.JPG</a></div></td>
<td><A ID='IMG_5487.JPG' href='levitylimestoneandlava.php?fileId=IMG_5487.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5487.JPG' ALT='IMG_5487.JPG'><BR>IMG_5487.JPG<br>52.02 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5487.JPG' ALT='IMG_5487.JPG'>IMG_5487.JPG</a></div></td>
<td><A ID='IMG_5488.JPG' href='levitylimestoneandlava.php?fileId=IMG_5488.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5488.JPG' ALT='IMG_5488.JPG'><BR>IMG_5488.JPG<br>78.4 KB</a><div class='inv'><br><a href='./images/20050729/IMG_5488.JPG' ALT='IMG_5488.JPG'>IMG_5488.JPG</a></div></td>
</tr>
</table>	</div>
</div>
</body>
</html>