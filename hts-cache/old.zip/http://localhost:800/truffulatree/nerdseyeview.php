<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - Nerd's Eye View - Travelouges and blogs from my trip around Australia</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="Travelouges and blogs from my trip around Australia">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="Travelouges from my trip through India in 2000" href='india2000.php'>India 2000</a></li>
<li><div class='activemenu'>Nerd's Eye View</div></li>
<ul>
<li><a title="Greetings from a Bum" href='greetingsfromabum.php'>29/4/2005</a></li>
<li><a title="Onward" href='onward.php'>2/5/2005</a></li>
<li><a title="It's a tough life (pt 1: Bundaberg, Agnes Water and 1770)" href='itsatoughlife1.php'>17/5/2005</a></li>
<li><a title="It's a tough life (pt 2: Rockhampton, Emu Park and Great Keppel Island)" href='itsatoughlife2.php'>23/5/2005</a></li>
<li><a title="There and Back Again - a Yo-yo's Tale" href='thereandbackagain.php'>18/6/2005</a></li>
<li><a title="Platypi and Grey Nomads" href='platypiandgreynomads.php'>24/6/2005</a></li>
<li><a title="Blowing Bubbles in a Watery Tomb" href='blowingbubbles.php'>1/7/2005</a></li>
<li><a title="Pieces of History" href='piecesofhistory.php'>8/7/2005</a></li>
<li><a title="Walks and Waterfalls" href='walksandwaterfalls.php'>15/7/2005</a></li>
<li><a title="Mission to Tribulation" href='missiontotribulation.php'>22/7/2005</a></li>
<li><a title="Levity, Limestone and Lava" href='levitylimestoneandlava.php'>29/7/2005</a></li>
<li><a title="Into the Never Never" href='intothenevernever.php'>5/8/2005</a></li>
<li><a title="Slowing the pace in Darwin" href='slowingthepaceindarwin.php'>12/8/2005</a></li>
<li><a title="Blistering Barnacles and Leaping Lizards" href='leapinglizards.php'>19/8/2005</a></li>
<li><a title="Kakadu and Litchfield" href='kakadu.php'>26/8/2005</a></li>
<li><a title="Legacies of War" href='legaciesofwar.php'>2/9/2005</a></li>
<li><a title="Go West" href='gowest.php'>10/9/2005</a></li>
<li><a title="Things from Above" href='thingsfromabove.php'>16/9/2005</a></li>
<li><a title="The West Coast" href='thewestcoast.php'>23/9/2005</a></li>
<li><a title="Reefs and Red Dust" href='reefsandreddust.php'>30/9/2005</a></li>
<li><a title="The Pilbara" href='pilbara.php'>7/10/2005</a></li>
<li><a title="Paradise with a Headwind" href='paradisewithaheadwind.php'>14/10/2005</a></li>
<li><a title="Down the Coral Coast" href='downthecoralcoast.php'>21/10/2005</a></li>
<li><a title="Pinnacles and Pinnipeds" href='pinnaclesandpinnipeds.php'>28/10/2005</a></li>
<li><a title="A week in Perth" href='perth.php'>4/11/2005</a></li>
<li><a title="The Southwest (from Above and Below)" href='thesouthwest.php'>11/11/2005</a></li>
<li><a title="More Heights and Depths" href='moreheightsanddepths.php'>18/11/2005</a></li>
<li><a title="Across the Nullarbor (and a bit beyond)" href='nullarbor.php'>25/11/2005</a></li>
<li><a title="Double Whammy" href='doublewhammy.php'>9/12/2005</a></li>
<li><a title="Two Cities" href='twocities.php'>19/12/2005</a></li>
<li><a title="Tassie - Part 1" href='tassie1.php'>1/1/2006</a></li>
<li><a title="Tassie - Part 2" href='tassie2.php'>7/1/2006</a></li>
<li><a title="Full Circle" href='fullcircle.php'>26/1/2006</a></li>
<li><a title="The Wrap Up" href='thewrapup.php'>23/3/2006</a></li>
</ul>
<li><a title="Warrumbungle, Kings Plains and Bald Rock National Parks" href='outbackNSW.php'>Outback NSW</a></li>
<li><a title="Alice Springs and surrounds" href='redcentre.php'>The Red Centre</a></li>
<li> </li><br><li>Or go back to:</li><li><a title='Travel stories and pictures' href="travel.php">Travelogues</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>Nerd's Eye View</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Travel stories and pictures' href="travel.php">Travelogues</a> > <a title='Travelouges and blogs from my trip around Australia' href="nerdseyeview.php">Nerd's Eye View</a>
<br>Select a link on the left to continue navigating.<br><br>		<br>
Between April '05 and January '06 I went on a massive driving trip around Australia. Basically, I lived out of my car and took my sweet time with it all. The sub-pages here<br>
contain the updates I sent around, plus a horde of photos that I took. If you're wondering where to start, <a href="thewrapup.php">the final installment</a> has a nice collection of pics and stats from the trip. Then you can either work backwards or head to the first installment and go from there. Isn't time travel wonderful?<br>
<br>
No nerd travel trip would be complete without a complement of technology and toys, so, for the interested, here's a partial list of what I took:<br>
<br>
- Laptop<br>
ITC monster, same as a Sager 9860. It's a fantastic laptop, but totally inappropriate for travel due to crappy battery life and general enormousness. Oh well, life is a learning experience. ;)<br>
<br>
- Camera<br>
Canon EOS 20D (my baby) with<br>
EF-S 17-85mm F4.0-5.6 IS USM (anyone wanna swap me for the new EF-S 17-55 F2.8 IS? *grin*)<br>
EF 50mm F1.8<br>
EF 90-300mm F4.5-5.6 USM<br>
Circular polarising filter<br>
Remote shutter release<br>
Manfrotto Tripod of some sort that I can't remember the model of right now, and who cares really :)<br>
<br>
- GPS<br>
Garmin eTrex Legend<br>
Mapsource Metroguide software and maps<br>
<br>
- Music (gotta have it!)<br>
Creative Nomad Zen NX 60gb<br>
Beyerdynamic headphones compliments of Dan from <a href="http://www.dansdata.com" target="_blank">Dan's Data</a> :)<br>
Acoustic guitar (Epiphone, left handed)<br>
Acoustic bass (Crafter, left handed)<br>
<br>
- Bag<br>
Lowepro Computrekker Plus AW - holds the laptop and most of the gear above (barring the guitars!).<br>
<br>
- Power<br>
Modified Sola 300VA UPS, hooked up to the car battery (works a treat, who needs a proper inverter!)<br>
<br>
Anyway, I've also posted my travel blogs on my friend Carl's site, <a href="http://www.swagtravel.com" target="_blank">www.swagtravel.com</a>. Check it out - it's pretty cool.<br>
<br>
I've also created a new section on this site for my other writing. Under that I've posted the <a href="india2000.php">old travel emails from my India trip in 2000</a>. If you're enjoying the Nerds Eye View stories, and just can't get enough of my ramblings, check it out!<br>
<br>
And at the desktop there's crying sounds<br>
For all the projects due and no-one else is round<br>
And the sprinklers that come on at 3 A.M.<br>
Sound like crowds of people asking<br>
Are you happy what you're doing?<br>
<br>
- The Group Who Couldn't Say by Grandaddy<br>


	</div>
</div>
</body>
</html>