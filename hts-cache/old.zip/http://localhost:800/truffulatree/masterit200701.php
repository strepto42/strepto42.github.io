<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - January 2007 - Q&A letters</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="Q&A letters">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><div class='activemenu'>January 2007</div></li>
<li><a title="Q&A letters" href='masterit200702.php'>February 2007</a></li>
<li><a title="Q&A letters" href='masterit200703.php'>March 2007</a></li>
<li><a title="Q&A letters" href='masterit200704.php'>April 2007</a></li>
<li><a title="Q&A letters" href='masterit200705.php'>May 2007</a></li>
<li><a title="Q&A letters" href='masterit200706.php'>June 2007</a></li>
<li><a title="Q&A letters" href='masterit200707.php'>July 2007</a></li>
<li> </li><br><li>Or go back to:</li><li><a title='Q&A letters from 2007' href="masterit2007.php">2007 archive</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>January 2007</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Mark's writing' href="written.php">Professional Writing</a> > <a title='My weekly Q&A column in The Australian' href="masterIT.php">MasterIT</a> > <a title='Q&A letters from 2007' href="masterit2007.php">2007 archive</a> > <a title='Q&A letters' href="masterit200701.php">January 2007</a>
<br><br>		<br>
<h2>23/1/07</h2><br>
<b>I am planning an upgrade, but as I already have a screen I would like to know how hard would it be to use two screens at the same time. I know that my wife would find it handy to have one program running on one screen and Excel running on the other. I will have XP Professional on my upgraded system.</b><br>
<br>
Running multiple displays should be pretty easy. XP Pro supports them; all you need is a dual head video card (i.e., one that supports two displays).<br>
<br>
The good news is that many newer video cards are dual head. You can tell by looking at the back of the computer - if you have two monitor sockets, you're in business.<br>
<br>
Note that sometimes one or both connectors may be DVI plugs. In this case you'll need a VGA->DVI adaptor to plug in an older screen.<br>
<br>
Assuming you have the hardware to hook both displays up, it should simply be a case of going into the Windows display properties (the easiest way is to right click on the desktop and select "properties"), clicking on the Settings tab, and ticking the various boxes to extend your desktop.<br>
<br>
<br>
<b>I was recently sent an e-card by a (good) friend. I received the link by email, but when I went to the site a window popped up telling me that my computer had porn on it, and that if I downloaded their product I would be protected. There was a 'girlie' picture on the page, but apparently no scope to see what the compromising material might be (in other words, no evidence). I am absolutely certain there would be no such material on my PC. Is this a scam?</b><br>
<br>
Yep, it is.<br>
<br>
I had a look at the e-card site in question, and the site itself is fairly innocent. The problem is that it has pop-up ads, and I guess you drew a short straw with the ad it found for you.<br>
<br>
Unfortunately, it's a common scam to pop up a frightening window containing a "click here to spend money and save yourself from unspeakable horrors" message. The idea is to sucker the user into buying something they don't need.<br>
<br>
At best, many of these so-called protection and cleaning programs do very little. At worst, they can even install their own spyware onto your PC. Lovely, isn't it!<br>
<br>
It's a shame, but the Internet is full of rubbish like this these days. Just keep exercising common sense (like you did), use your antivirus and anti-spyware programs regularly, and keep up the sceptical approach.<br>
<br>
<br>
<h2>30/1/07</h2><br>
<b>I currently back up my whole hard drive to a couple of DVDs using Norton Ghost 2003, but together with the subsequent integrity check, it take hours to do. Is there a better and quicker way (eg via an external HD). My HD holds about 10 gigs and I run XP Pro.</b><br>
<br>
An external hard drive is an excellent way to go. I do something similar myself; the only difference being that the backup drive isn't external (which is bad, but it is better than no backup at all).<br>
<br>
I back up to another hard drive simply because I have way too much data to put on optical media, but there are other advantages to this approach, namely speed and convenience (because you don't have to actually be there to change the discs!).<br>
<br>
Obviously, it's a bit more expensive to go this way, but ultimately it is more flexible. If your external hard drive is large, you'll be able to store quite a few incremental backups along with the master, which might let you rescue a long-gone file if you ever need to down the track.<br>
<br>
Tape drives are another option of course, but given the amount of data you have, and the current cost of enormous hard drives (not much!), it would be more expensive and less flexible as a solution.<br>
<br>
As far as software goes, I played with Ghost for a while, but I was always frustrated by it (regular readers will know my opinion of Symantec's rebadged "products").<br>
<br>
Nowadays, I use a thing called Acronis True Image (http://www.acronis.com). It's pretty much flawless and lacks the bugs that plague Ghost.<br>
<br>
<br>
<b>I installed Adaware, but I also have Avast antivirus, and when I triggered the antivirus scan, all sorts of Alarms sounded, advising that Adaware was a virus and I should either quarantine or delete! Which programme should I believe?</b><br>
<br>
Neither. Or both. Sometimes, well-meaning programs can conflict with each other, and in your case this is exactly what has happened.<br>
<br>
Adaware has been known to have issues with certain versions of Mcaffe, as well as with Avast. Nonetheless, I've been using the Adaware/Mcaffe combo for years without an issue, probably because I never hit the magic combination of versions that interfere with each other.<br>
<br>
Updating to the latest versions/databases of both programs will probably fix the problem, but if that fails you may have to change one of the packages entirely.<br>
<br>
One good option in the anti-spyware department that I've discovered recently is Prevx (http://www.prevx.com).<br>
<br>
<i><p>Did the information on this page help you? Entertain you? Bore you? <a href="contact.php?subject=MasterIT">Drop me a line</a>.</p>

<p>If you're feeling particularly generous, you can even <a href="buypics.php">click here to send me some dot-com riches</a>. Think of it as online busking.</i></p>
	</div>
</div>
</body>
</html>