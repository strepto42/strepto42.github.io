<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - 25/10/2000 - More Miscellaneous Ramblings from the Teeming Subcontinent</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="More Miscellaneous Ramblings from the Teeming Subcontinent">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="Greetings from the Other Side" href='greetingsfromtheotherside.php'>16/10/2000</a></li>
<li><a title="Another quick update from the land of rupees..." href='anotherquickupdate.php'>19/10/2000</a></li>
<li><div class='activemenu'>25/10/2000</div></li>
<li><a title="Indian Update" href='indianupdate.php'>4/11/2000</a></li>
<li><a title="From the Ganges to the Taj... and beyond" href='gangestotaj.php'>18/11/2000</a></li>
<li><a title="Camels, Tigers, Elephants and Octopussies" href='camelstigersoctopussies.php'>9/12/2000</a></li>
<li><a title="Back to bloody reality" href='backtobloodyreality.php'>14/12/2000</a></li>
<li> </li><br><li>Or go back to:</li><li><a title='Travelouges from my trip through India in 2000' href="india2000.php">India 2000</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>25/10/2000</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Travel stories and pictures' href="travel.php">Travelogues</a> > <a title='Travelouges from my trip through India in 2000' href="india2000.php">India 2000</a> > <a title='More Miscellaneous Ramblings from the Teeming Subcontinent' href="subcontinentramblings.php">25/10/2000</a>
<br><br>		


<h1>More Miscellaneous Ramblings from the Teeming Subcontinent</h1>

<p>Just another quick update. For those that didn't get Jana's email, we're in 
a place called Dharamsala now, which is where the Dalai Lama lives, along 
with the Tibetan Govt in Exile. It's really lovely, nice big mountains (well 
almost mountains, hills really, but we'd call them mountains in Australia). 
Clean air too, which is nice after Delhi (which can be compared to Sydney at 
the height of the big bushfires a few years ago, only it ain't wood smoke).</p>

<p>Haven't been doing all that much, the place is just a lovely spot to relax 
and read a bit in the sun and so on. The place where we're staying is really 
nice, only slight drawback are the 228 stairs to get into town. But it's 
good exercise...</p>

<p>There was a children's festival on today at the Tibetan school, which we 
went along to have a look at, as the Dalai Lama as speaking, which he did, 
unfortunately for us we don't speak Tibetan so we have no idea what he 
actually said. I'm sure it was nice though. :) I've actually just finished 
reading his autobiography - he's quite a remarkable and wise man (not that 
this came as a surprise).</p>

<p>Apart from that not much news. We'll probably leave here tomorrow, and head 
back to Delhi (yay) for a day, then on to Varanasi (which is the place with 
all the steps on the river, known as 'Ghats'). After that Agra and the Taj 
Mahal.</p>

<p>So yah, another 13 hour bus trip out of here. You'll be able to use the 
words 'bus plunge' again safely soon. :)</p>

<p>Some other random memories:</p>

<p>- Some traffic lights in Delhi have 'relax' painted on the red light</p>

<p>- A sign on the side of the twisty mountain road on the way up here - "Risk 
takers are accident makers" (this isn't aimed at anyone in partiular of 
course, you're all bloody dangerous drivers!)</p>

<p>- The cows are often amusing. We were watching the little alley behind our 
place in Delhi, where there are numerous stalls selling various vegies and 
so on... the cows wander around, totally unfazed by the chaos around them. 
One went up to a pile of cauliflowers and had a good lick and nuzzle, 
causing one to fall off... The owner of the stall waited a few minutes 
(after giving the cow the 'movealong') and then dusted off the veg and 
popped it back on the pile. Good as new. I'd say it's reasonably unlikely to 
get sick here, provided one is a little careful, but incidents like are 
pretty random, and you never know. Still once cooked it doesn't really 
matter about cow slobber I guess. :)</p>

<p>Anyway enough ramble for now... enjoy your disinfected sponges, air conditioned offices and antibacterial ways of life... ;)</p>
<br><br>
All images in this gallery:<br>
<table width='800'>
<tr>
</tr>
<tr><td><A ID='F1000010.JPG' href='subcontinentramblings.php?fileId=F1000010.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001025/F1000010.JPG' ALT='F1000010.JPG'><BR>F1000010.JPG<br>106.04 KB</a><div class='inv'><br><a href='./images/20001025/F1000010.JPG' ALT='F1000010.JPG'>F1000010.JPG</a></div></td>
<td><A ID='F1000011.JPG' href='subcontinentramblings.php?fileId=F1000011.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001025/F1000011.JPG' ALT='F1000011.JPG'><BR>F1000011.JPG<br>107.14 KB</a><div class='inv'><br><a href='./images/20001025/F1000011.JPG' ALT='F1000011.JPG'>F1000011.JPG</a></div></td>
<td><A ID='F1000013.JPG' href='subcontinentramblings.php?fileId=F1000013.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001025/F1000013.JPG' ALT='F1000013.JPG'><BR>F1000013.JPG<br>130.04 KB</a><div class='inv'><br><a href='./images/20001025/F1000013.JPG' ALT='F1000013.JPG'>F1000013.JPG</a></div></td>
<td><A ID='F1000014.JPG' href='subcontinentramblings.php?fileId=F1000014.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001025/F1000014.JPG' ALT='F1000014.JPG'><BR>F1000014.JPG<br>125.17 KB</a><div class='inv'><br><a href='./images/20001025/F1000014.JPG' ALT='F1000014.JPG'>F1000014.JPG</a></div></td>
<td><A ID='F1000015.JPG' href='subcontinentramblings.php?fileId=F1000015.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001025/F1000015.JPG' ALT='F1000015.JPG'><BR>F1000015.JPG<br>49.17 KB</a><div class='inv'><br><a href='./images/20001025/F1000015.JPG' ALT='F1000015.JPG'>F1000015.JPG</a></div></td>
</tr>
<tr><td><A ID='F1000016.JPG' href='subcontinentramblings.php?fileId=F1000016.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001025/F1000016.JPG' ALT='F1000016.JPG'><BR>F1000016.JPG<br>55.27 KB</a><div class='inv'><br><a href='./images/20001025/F1000016.JPG' ALT='F1000016.JPG'>F1000016.JPG</a></div></td>
<td><A ID='F1000017.JPG' href='subcontinentramblings.php?fileId=F1000017.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001025/F1000017.JPG' ALT='F1000017.JPG'><BR>F1000017.JPG<br>78.71 KB</a><div class='inv'><br><a href='./images/20001025/F1000017.JPG' ALT='F1000017.JPG'>F1000017.JPG</a></div></td>
<td><A ID='F1000018.JPG' href='subcontinentramblings.php?fileId=F1000018.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001025/F1000018.JPG' ALT='F1000018.JPG'><BR>F1000018.JPG<br>70.35 KB</a><div class='inv'><br><a href='./images/20001025/F1000018.JPG' ALT='F1000018.JPG'>F1000018.JPG</a></div></td>
<td><A ID='F1000020.JPG' href='subcontinentramblings.php?fileId=F1000020.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001025/F1000020.JPG' ALT='F1000020.JPG'><BR>F1000020.JPG<br>111.94 KB</a><div class='inv'><br><a href='./images/20001025/F1000020.JPG' ALT='F1000020.JPG'>F1000020.JPG</a></div></td>
</tr>
</table>	</div>
</div>
</body>
</html>