<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - 23/3/2006 - The Wrap Up</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="The Wrap Up">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="Greetings from a Bum" href='greetingsfromabum.php'>29/4/2005</a></li>
<li><a title="Onward" href='onward.php'>2/5/2005</a></li>
<li><a title="It's a tough life (pt 1: Bundaberg, Agnes Water and 1770)" href='itsatoughlife1.php'>17/5/2005</a></li>
<li><a title="It's a tough life (pt 2: Rockhampton, Emu Park and Great Keppel Island)" href='itsatoughlife2.php'>23/5/2005</a></li>
<li><a title="There and Back Again - a Yo-yo's Tale" href='thereandbackagain.php'>18/6/2005</a></li>
<li><a title="Platypi and Grey Nomads" href='platypiandgreynomads.php'>24/6/2005</a></li>
<li><a title="Blowing Bubbles in a Watery Tomb" href='blowingbubbles.php'>1/7/2005</a></li>
<li><a title="Pieces of History" href='piecesofhistory.php'>8/7/2005</a></li>
<li><a title="Walks and Waterfalls" href='walksandwaterfalls.php'>15/7/2005</a></li>
<li><a title="Mission to Tribulation" href='missiontotribulation.php'>22/7/2005</a></li>
<li><a title="Levity, Limestone and Lava" href='levitylimestoneandlava.php'>29/7/2005</a></li>
<li><a title="Into the Never Never" href='intothenevernever.php'>5/8/2005</a></li>
<li><a title="Slowing the pace in Darwin" href='slowingthepaceindarwin.php'>12/8/2005</a></li>
<li><a title="Blistering Barnacles and Leaping Lizards" href='leapinglizards.php'>19/8/2005</a></li>
<li><a title="Kakadu and Litchfield" href='kakadu.php'>26/8/2005</a></li>
<li><a title="Legacies of War" href='legaciesofwar.php'>2/9/2005</a></li>
<li><a title="Go West" href='gowest.php'>10/9/2005</a></li>
<li><a title="Things from Above" href='thingsfromabove.php'>16/9/2005</a></li>
<li><a title="The West Coast" href='thewestcoast.php'>23/9/2005</a></li>
<li><a title="Reefs and Red Dust" href='reefsandreddust.php'>30/9/2005</a></li>
<li><a title="The Pilbara" href='pilbara.php'>7/10/2005</a></li>
<li><a title="Paradise with a Headwind" href='paradisewithaheadwind.php'>14/10/2005</a></li>
<li><a title="Down the Coral Coast" href='downthecoralcoast.php'>21/10/2005</a></li>
<li><a title="Pinnacles and Pinnipeds" href='pinnaclesandpinnipeds.php'>28/10/2005</a></li>
<li><a title="A week in Perth" href='perth.php'>4/11/2005</a></li>
<li><a title="The Southwest (from Above and Below)" href='thesouthwest.php'>11/11/2005</a></li>
<li><a title="More Heights and Depths" href='moreheightsanddepths.php'>18/11/2005</a></li>
<li><a title="Across the Nullarbor (and a bit beyond)" href='nullarbor.php'>25/11/2005</a></li>
<li><a title="Double Whammy" href='doublewhammy.php'>9/12/2005</a></li>
<li><a title="Two Cities" href='twocities.php'>19/12/2005</a></li>
<li><a title="Tassie - Part 1" href='tassie1.php'>1/1/2006</a></li>
<li><a title="Tassie - Part 2" href='tassie2.php'>7/1/2006</a></li>
<li><a title="Full Circle" href='fullcircle.php'>26/1/2006</a></li>
<li><div class='activemenu'>23/3/2006</div></li>
<li> </li><br><li>Or go back to:</li><li><a title='Travelouges and blogs from my trip around Australia' href="nerdseyeview.php">Nerd's Eye View</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>23/3/2006</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Travel stories and pictures' href="travel.php">Travelogues</a> > <a title='Travelouges and blogs from my trip around Australia' href="nerdseyeview.php">Nerd's Eye View</a> > <a title='The Wrap Up' href="thewrapup.php">23/3/2006</a>
<br><br>		


<h1>The Wrap Up</h1>

<a href="images/maps/Map_combined.gif"><img src="images/maps/Map_combined_sm.gif" align="right"></a>

<p>Hi everyone. Remember me? It's been a while...</p>

<p>I've been putting off writing this last update, in the hope that I would be able to do it from a (rented) house of my very own, but it's turned out to be a little more difficult to find a good place than we first thought.</p>

<p>This will be the last instalment of Nerd's Eye View. It'll be a bit long (ok, it's turned out to be way long), but if you've been saving yourself up to finally read one in full (as I know many of you haven't before), this is your chance :).</p>

<p>So, time has marched on.... and it's been nearly two months since the last post; talk about slack!</p>

<p>Compared to the prior 9 months, these last two have been relatively unexciting, and the pace of life (in terms of how full the days are) has definitely backed off a notch or 10.</p>

<p>So, the executive summary: We're staying at Jana's cousin's place while we look for a place to rent. Sylvie has a 3-and-a-lot year old called Ashra, who is good entertainment (most of the time :)).</p>

<p>Apart from hanging around here with a small child climbing all over me, and looking at rental houses, we've been pretty relaxed. I've gone back to training, and my fitness is slowly being clawed back.</p>

<p>Other highlights from the past month:</p>

<ul>
	<li>Going to the One-day Cricket Final (a relatively unexciting game, but I did get a chance to take a few snaps before nice man told me that my camera was too expensive to be used there (it makes the corporate copyright holders nervous, you see).</li>
	<li>Heading to QLD Raceway for a day, to watch Rhys (friend and fellow photo-nerd) do some quick laps, and take pictures of his shiny new MX-5. It was a good excuse to practice pan shots on rapidly moving objects, as well as to get more sunburnt than I did on my entire trip.</li>
	<li>Various other random photo-taking events, some just for fun with Rhys (one with a cool 10-22mm lens on loan - now of course I want one!), some more Taekwondo events, a night out seeing a friend's friend's band debut, and various snaps of a certain 3-year-old showing off.</li>
	<li>Rebuilding my big computer that had a conniption last August. This involves lots of data shuffling and is as exciting as it sounds.</li>
	<li>Fighting with Australia Post, who have lost the parcel my Dad sent up from Sydney, containing the archive discs with my trip's camera RAW files (sort of like digital negatives). They managed to lose a registered parcel, and took a month before even properly looking. Then they only started to do stuff because I got seriously shirty with them. Needless to say, Australia Post are not my favourite people right at the moment, and I would urge anyone thinking of sending anything valuable not to use them.</li>
</ul>

<p>And that's it. Adjusting back into so-called normal life has been a pretty gradual process, and given the difficulty we've had in finding a decent place to live it's made for a terrific anticlimax. But that's ok, post travelling blues are to be expected, and I'm fairly malleable when it comes to life at the moment.</p>

<p>In the meantime, Nerd's Eye View is long overdue for a wrap-up. So, in no particular order, some random thoughts and statistics on the trip:</p>

<p><h3>Time on the road:</h3> 9 months.</p>

<p><h3>Kilometres driven:</h3> About 35000. This is quite an achievement considering that doing a straight lap of the country on the main highway is around about 10000kms, give or take a couple of thousand. Just goes to show that all the little detours add up! This figure also means that I burned about 3500 litres of petrol (and tens of litres of oil, before my engine change). When I met up with Jana, we started keeping track of expenses, and since then we averaged $10 each and every day on petrol.</p>

<p><h3>Kilometres ridden:</h3> Not sure, due to the whole bike-stealing incident messing up my statistics. I think the figure is around 900-1100kms. This sounds impressive, but is actually really rather pathetic given it's over 9 months. :) Mind you - it's still a couple of tanks of fuel saved!</p>

<p><h3>Photos taken:</h3> Nearly 17000. The figures leapt when I bought the zoom lens and started using continuous shooting mode a lot more. :)</p>

<p><h3>Photos actually kept:</h3> About 8300. Many of these are decidedly average, or too stupid for publication. Only about 3800 actually made it onto the website, but of course I kept the rest anyway. We all have to horde something in life, and I choose data.</p>

<p><h3>Emails sent:</h3> 34, including this one.</p>

<p><h3>Words written:</h3> 44000. If you've actually read them all, award yourself an Iced Vo-vo (and an appointment with the optometrist). :) There's also another 20000 words in my diary, but thankfully that claptrap that will never see the light of day. So it's little wonder that the most used keys on my laptop have developed little shiny patches.</p>

<p><h3>Animals killed:</h3> No doubt tens of thousands, if you include insects. Invertebrates aside though, I hit about 6 birds and 2 bobtail lizards. Almost all of these were pretty much unavoidable, barring one or two when I really should have been paying more attention.</p>

<p>Thankfully, I never hit anything larger, mostly due to the simple strategy of avoiding driving at dusk/dawn/night whenever possible, and doing sensible speeds in higher risk areas. It just goes to show that killing animals on the road is almost completely avoidable (unless you are driving a road train, which is why I could never do that for a job), so there's really very little excuse for the disgustingly high amount of roadkill in this country.</p>

<p>It really pisses me off, especially in national parks, to see dead animals that someone hasn't even bothered to move off the road. Apart from the complete lack of respect that it entails, it endangers other animals that might come onto the road to scavenge.</p>

<p>Anyway, on to more cheerful topics. :)</p>

<p><h3>Longest time without a shower:</h3> About three days, when we were out in the Pilbara, however, we did swim in gorgeous gorges almost every day, so it doesn't really count. Similarly, when we were exploring Ningaloo Reef, we didn't shower (there weren't any in the park), but we were snorkelling almost every day. This was in fact worse though, as you end up covered in itchy salt and your hair gets quite foul.</p>

<p><h3>Most amusing road sign:</h3> Probably <a href="levitylimestoneandlava.php?fileId=IMG_5183.JPG">this one</a>. I love the fact that there is no petrol available for a greater distance than the span of many, if not most, European countries.</p>

<p>
<h3>Items "used up", lost, broken, stolen or generally kaput:</h3>

<ul>
	<li>1 engine. The less said about that the better.</li>
	<li>3 tyres. Two died a horrible delamination death, and the third had the tread completely worn off. </li>
	<li>1 bike (grrr). Several inner tubes.</li>
	<li>1 t-shirt, several socks.</li>
	<li>2 pairs of thongs (flip-flops for all you chuckling geezers).</li>
	<li>1 hat (<a href="http://www.digi-comic.com/index.php?comicId=102" target="_blank">upgraded</a>).</li>
	<li>1 entire tin of lip balm</li>
	<li>1 capo (forgot to get it back at the end of the night, curse that alcohol!).</li>
	<li>...and a couple of sets of guitar strings.</li>
</ul>
</p>

<p><h3>Favourite place:</h3> This is probably the most common question I get asked, before people lose interest and start talking about the weather, sport, themselves and so on (a phenomenon that most travellers will be familiar with - it's not just that I'm a boring speaker :)). To be honest, I don't have any one place in mind, although I did love the Wolfe Creek crater somewhat disproportionately (and I still haven't seen the movie).</p>

<p>Overall, I'd have to say that anywhere more remote was nice; the top end, NT and WA. In particular the Kimberley and the Pilbara are pretty damn awesome. They're also the furthest places to get to from the east coast. Anyway, it's a totally different country when you get up north, and away from the east coast. It makes you appreciate the ridiculous size of this country too.</p>

<p>And whilst on the subject, some random thoughts on the various Australian states and territories, in the order that I visited them, plus some of my favourite pictures. In case you wonder at my bizarre selections, these pics are not necessarily anything to do with the places; they're just some of my personal favs.</p>

<br>

<h2>Queensland.</h2>

<p>Redneck capital of Australia (frighteningly so in places. Half this state still thinks it lives in the 60s. This is not a good thing). Gorgeous rainforest, beaches to die for. Sunshine, amazing snorkelling and diving. Serious indigenous drinking problems. Really lousy mobile coverage away from the east coast. Pleasant grey nomads. Backpackers galore, some cool travellers, but also many useless partying 18 year olds travelling on mummy and daddy's money. Shoddy roads.</p>

<table width="800">
	<tr>
	<td ALIGN=CENTER VALIGN=top>
		<A ID='qld' href='itsatoughlife2.php?fileId=IMG_2515.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20050523/IMG_2515.JPG' ALT='An amazing sunset on Great Keppel Island'><BR>An amazing sunset on Great Keppel Island</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='peaceconvergence.php?fileId=IMG_3321.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/peaceconvergence/IMG_3321.JPG' ALT='Mists in the caravan park, Rockhampton, at 3am'><BR>Mists in the caravan park, Rockhampton, at 3am</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='piecesofhistory.php?fileId=IMG_3878.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20050708/IMG_3878.JPG' ALT='Charters Towers was a bit of a hole, but the old Stock Exchange building is pretty'><BR>Charters Towers was a bit of a hole, but the old Stock Exchange building is pretty</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='missiontotribulation.php?fileId=IMG_4638.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20050722/IMG_4638.JPG' ALT='Fire twirling at Mission Beach backpackers. Hopefully the place is still there (a cyclone just hit the area)'><BR>Fire twirling at Mission Beach backpackers. Hopefully the place is still there (a cyclone just hit the area)</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='levitylimestoneandlava.php?fileId=IMG_5256.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20050729/IMG_5256.JPG' ALT='Just too damn tired to get up - part of the old smelter at Chillagoe'><BR>Just too damn tired to get up - part of the old smelter at Chillagoe</a>
	</td>
	</tr>
</table>

<br>

<h2>The Northern Territory.</h2>

<p>Empty. Flat. Amazing. Empty (ok, not really, just devoid of people). Far less serious alcohol issues, however plenty of issues remain nonetheless. Laid back, down to earth. Better roads, but less of them.</p>

<table width="800">
	<tr>
	<td ALIGN=CENTER VALIGN=top>
		<A id="nt" href='intothenevernever.php?fileId=IMG_5842.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20050805/IMG_5842.JPG' ALT="The Devil's Marbles at dawn"><BR>The Devil's Marbles at dawn</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='slowingthepaceindarwin.php?fileId=IMG_6107.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20050812/IMG_6107.JPG' ALT='Mindil Beach in Darwin turns on a great sunset'><BR>Mindil Beach in Darwin turns on a great sunset</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='leapinglizards.php?fileId=IMG_7332.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20050819/IMG_7332.JPG' ALT='As does Kakadu :)'><BR>As does Kakadu :)</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='kakadu.php?fileId=IMG_7459.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20050826/IMG_7459.JPG' ALT='Magpie Geese. 400,000 of them once destroyed a rice crop in the Kimberley'><BR>Magpie Geese. 400,000 of them once destroyed a rice crop in the Kimberley</a>
	</td>
	</tr>
</table>

<br>

<h2>Western Australia.</h2>

<p>Enormous. Ancient. Remote. Old fashioned at times, but not redneckingly so (with the possible exception of certain southern areas). The indigenous people living outside the cities seem to have their shit together much more so than in other states. Northern WA is another world altogether. It's a serious must-see if you haven't already been. Amazing coastline all the way from the top to the bottom. The bluest water I've ever seen - great diving too although a little chilly at times! There is far, far more I could say about WA, it's such an enormous and diverse place. The best idea I think is to re-read the appropriate emails. :)</p>

<table width="800">
	<tr>
	<td ALIGN=CENTER VALIGN=top>
		<A id="wa" href='thingsfromabove.php?fileId=IMG_8708.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_8708.JPG' ALT='An ancient Boab in the Kimblerley'><BR>An ancient Boab in the Kimblerley</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='thingsfromabove.php?fileId=IMG_8853.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_8853.JPG' ALT='My favourite shiny road train at dawn in the Kimberley'><BR>My favourite shiny road train at dawn in the Kimberley</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='thingsfromabove.php?fileId=IMG_9051.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_9051.JPG' ALT='Wolfe Creek meteorite crater'><BR>Wolfe Creek meteorite crater</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='pilbara.php?fileId=IMG_0328.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20051007/IMG_0328.JPG' ALT='A Spinifex Pigeon in the Pilbara'><BR>A Spinifex Pigeon in the Pilbara</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='downthecoralcoast.php?fileId=IMG_1132.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1132.JPG' ALT='Feeding time for baby swallows'><BR>Feeding time for baby swallows</a>
	</td>
	</tr>
	<tr>
	<td ALIGN=CENTER VALIGN=top>
		<A href='pinnaclesandpinnipeds.php?fileId=IMG_1568.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1568.JPG' ALT='Making tracks at the Pinnacles'><BR>Making tracks at the Pinnacles</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='pinnaclesandpinnipeds.php?fileId=IMG_1754.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1754.JPG' ALT='An imposing building in the monastery town of New Norcia'><BR>An imposing building in the monastery town of New Norcia</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='perth.php?fileId=IMG_1932.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20051104/IMG_1932.JPG' ALT='Two Dugites getting very friendly with each other on Rottnest Island'><BR>Two Dugites getting very friendly with each other on Rottnest Island</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='thesouthwest.php?fileId=IMG_2025.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2025.JPG' ALT='Amazing silver bark'><BR>Amazing silver bark</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='thesouthwest.php?fileId=IMG_2494.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2494.JPG' ALT='A male Splendid Wren, possibly the bluest creature on earth'><BR>A male Splendid Wren, possibly the bluest creature on earth</a>
	</td>
	</tr>
</table>

<h2>South Australia.</h2>

<p>Disappointing. Large and largely empty. Environmental disaster area in places. Somewhat overrated (barring the Flinders ranges, and a few other spots which were fantastic). Adelaide is pretty, but for some reason I didn't take much of a shine to it. There is also a lot of amazing coastline, more of which warrants exploration one day. </p>

<table width="800">
	<tr>
	<td ALIGN=CENTER VALIGN=top>
		<A id='sa' href='nullarbor.php?fileId=IMG_3442.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20051125/IMG_3442.JPG' ALT='I love the variety of perils depicted on this warning sign'><BR>I love the variety of perils depicted on this warning sign</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='doublewhammy.php?fileId=IMG_3694.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_3694.JPG' ALT='Sap oozes from a trimmed fallen tree in Mount Remarkable National Park'><BR>Sap oozes from a trimmed fallen tree in Mount Remarkable National Park</a>
	</td>
	</tr>
</table>

<h2>Victoria.</h2>

<p>Mad Max country roads. Greenery. More fantastic coastline. Culture. I didn't really get to see a lot of Vic - I'm sure I'll return one day and cover it properly. Melbourne is great of course; and the Dandenong Ranges and Grampians were also quite lovely.</p>

<table width="800">
	<tr>
	<td ALIGN=CENTER VALIGN=top>
		<A id='vic' href='doublewhammy.php?fileId=IMG_4135.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20051209/IMG_4135.JPG' ALT='Koala Claws'><BR>Koala Claws</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='twocities.php?fileId=IMG_4480.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4480.JPG' ALT='Lovely mounted butterflies in the Melbourne Museum'><BR>Lovely mounted butterflies in the Melbourne Museum</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='twocities.php?fileId=IMG_4524.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4524.JPG' ALT="Penelope's back yard in The Dandenongs"><BR>Penelope's back yard in The Dandenongs</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='twocities.php?fileId=IMG_4569.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4569.JPG' ALT='Visual confusion in Melbourne'><BR>Visual confusion in Melbourne</a>
	</td>
	</tr>
</table>

<h2>Tasmania.</h2>

<p>Beautiful and tragic. Total environmental disaster area in many places, particularly the west. Second most redneck state, bowing only to Queensland. Cold. Mossy and damp, in a pleasing way. Quite European in some way, although still definitely Australian. Lovely waterfalls and rainforest.</p>

<table width="800">
	<tr>
	<td ALIGN=CENTER VALIGN=top>
		<A id='tas' href='tassie1.php?fileId=IMG_5006.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5006.JPG' ALT='Climbing Henty Dunes'><BR>Climbing Henty Dunes</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='tassie1.php?fileId=IMG_5041.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5041.JPG' ALT='Hogarth Falls'><BR>Hogarth Falls</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='tassie1.php?fileId=IMG_5386.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5386.JPG' ALT='Tasmania abounds in lovely fungi'><BR>Tasmania abounds in lovely fungi</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='tassie2.php?fileId=IMG_5832.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5832.JPG' ALT='Waters mixing in a tidal outflow, Launceston'><BR>Waters mixing in a tidal outflow, Launceston</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='tassie2.php?fileId=IMG_6064.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_6064.JPG' ALT='Bass Strait on an amazingly calm day'><BR>Bass Strait on an amazingly calm day</a>
	</td>
	</tr>
</table>

<h2>Australian Capital Territory (Canberra).</h2>

<p>Boring as batshit, but kinda pretty from the air. Smells like liar when parliament is sitting. And my fantabulous sister lives there of course, so it's gotta have something going for it.</p>

<table width="800">
	<tr>
	<td ALIGN=CENTER VALIGN=top>
		<A id='act' href='fullcircle.php?fileId=IMG_6316.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6316.JPG' ALT='Parliament House, Canberra. Nice building, pity about the occupants'><BR>Parliament House, Canberra. Nice building, pity about the occupants</a>
	</td>
	</tr>
</table>

<h2>New South Wales.</h2>

<p>Having gown up in Sydney, and done a lot of traipsing up and down the coast, I've still yet to explore the western part of NSW. Sydney itself is a gorgeous city, let down only by it's ridiculous cost of living and even more ridiculous traffic situation. Of course it's a must-see on any visit to Oz, but it's totally not the be-all and end-all it makes itself out to be.</p>

<table width="800">
	<tr>
	<td ALIGN=CENTER VALIGN=top>
		<A id='nsw' href='fullcircle.php?fileId=IMG_6102.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6102.JPG' ALT='Fire and regeneration in the Snowy Mountains'><BR>Fire and regeneration in the Snowy Mountains</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='fullcircle.php?fileId=IMG_6666.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6666.JPG' ALT='Wentworth Falls through a fisheye. I gotta get me one sometime'><BR>Wentworth Falls through a fisheye. I gotta get me one sometime</a>
	</td>
	</tr>
</table>

<p>So that's that. Before I go, a few final words and comments in general.</p>

<p>First of all, if you have any sort of interest in the photos I've taken, and you've never actually been to my website, I really think you should go and waste some time there. The links above all take you to this email's corresponding page on my site, as attaching that many pictures wouldn't have been kind to Alan (whom I have to thank once again for letting me load test his mail server every week).</p>

<p>There are also maps of every step of the journey on the site, like the one attached. For anyone who's interested, you can download a saved set of these track points from here: <a href="files/nerdseyeview/NerdsEyeView.redirector.html">http://www.truffulatree.com.au/files/nerdseyeview/NerdsEyeView.redirector.html</a>, and load this file into Google Earth. For those of you who've never tried playing with Google Earth, it's very, very cool, and by downloading my track you can follow a bird's eye view of the nerd's eye view. You will waste hours zooming and tilting!</p>

<p>Over the next month or so I'll also be redoing a fair bit of my site - so do check back from time to time (assuming you give a hoot or two). Also, when you're there, please check out the ads. If they're relevant and you click, this gives me free money. I'm facing the prospect of having to find some sort of real job again at some stage, and every little bit of avoidance helps.</p>

<p>On this subject (grovelling and avoiding real work in general), I'm looking into expanding my tech writing, and trying to flog some of my photos (to departments of tourism, and image archives in general)... so, if anyone of you knows someone who might be interested, or has any suggestions, or just plain wants to give me money for nothing (we can all dream, can't we?), please feel free to get in touch with me, or pass on my details to whoever might care. I'm also available to do IT consulting of pretty much any kind (websites in particular). So share the love. It would mean a lot to me.</p>

<p>Apart from that, there's not much else to say. It's been nice to have everyone looking over my shoulder while I travel. Hopefully it's been nice for you too. If you're interested in staying in touch, all you have to do it <a href="contact.php">click "reply"</a>. ;)</p>

<p>Until next time, adios!</p>
<br><br>
All images in this gallery:<br>
<table width='800'>
<tr>
</tr>
<tr><td><A ID='IMG_6887.JPG' href='thewrapup.php?fileId=IMG_6887.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060323/IMG_6887.JPG' ALT='IMG_6887.JPG'><BR>IMG_6887.JPG<br>66.12 KB</a><div class='inv'><br><a href='./images/20060323/IMG_6887.JPG' ALT='IMG_6887.JPG'>IMG_6887.JPG</a></div></td>
<td><A ID='IMG_6904.JPG' href='thewrapup.php?fileId=IMG_6904.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060323/IMG_6904.JPG' ALT='IMG_6904.JPG'><BR>IMG_6904.JPG<br>51.26 KB</a><div class='inv'><br><a href='./images/20060323/IMG_6904.JPG' ALT='IMG_6904.JPG'>IMG_6904.JPG</a></div></td>
<td><A ID='IMG_6935.JPG' href='thewrapup.php?fileId=IMG_6935.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060323/IMG_6935.JPG' ALT='IMG_6935.JPG'><BR>IMG_6935.JPG<br>38.53 KB</a><div class='inv'><br><a href='./images/20060323/IMG_6935.JPG' ALT='IMG_6935.JPG'>IMG_6935.JPG</a></div></td>
<td><A ID='IMG_6964.JPG' href='thewrapup.php?fileId=IMG_6964.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060323/IMG_6964.JPG' ALT='IMG_6964.JPG'><BR>IMG_6964.JPG<br>65.83 KB</a><div class='inv'><br><a href='./images/20060323/IMG_6964.JPG' ALT='IMG_6964.JPG'>IMG_6964.JPG</a></div></td>
<td><A ID='IMG_6971.JPG' href='thewrapup.php?fileId=IMG_6971.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060323/IMG_6971.JPG' ALT='IMG_6971.JPG'><BR>IMG_6971.JPG<br>66.47 KB</a><div class='inv'><br><a href='./images/20060323/IMG_6971.JPG' ALT='IMG_6971.JPG'>IMG_6971.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_6976.JPG' href='thewrapup.php?fileId=IMG_6976.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060323/IMG_6976.JPG' ALT='IMG_6976.JPG'><BR>IMG_6976.JPG<br>77.93 KB</a><div class='inv'><br><a href='./images/20060323/IMG_6976.JPG' ALT='IMG_6976.JPG'>IMG_6976.JPG</a></div></td>
<td><A ID='IMG_6979.JPG' href='thewrapup.php?fileId=IMG_6979.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060323/IMG_6979.JPG' ALT='IMG_6979.JPG'><BR>IMG_6979.JPG<br>56.22 KB</a><div class='inv'><br><a href='./images/20060323/IMG_6979.JPG' ALT='IMG_6979.JPG'>IMG_6979.JPG</a></div></td>
<td><A ID='IMG_7018.JPG' href='thewrapup.php?fileId=IMG_7018.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060323/IMG_7018.JPG' ALT='IMG_7018.JPG'><BR>IMG_7018.JPG<br>78.81 KB</a><div class='inv'><br><a href='./images/20060323/IMG_7018.JPG' ALT='IMG_7018.JPG'>IMG_7018.JPG</a></div></td>
<td><A ID='IMG_7028.JPG' href='thewrapup.php?fileId=IMG_7028.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060323/IMG_7028.JPG' ALT='IMG_7028.JPG'><BR>IMG_7028.JPG<br>61.9 KB</a><div class='inv'><br><a href='./images/20060323/IMG_7028.JPG' ALT='IMG_7028.JPG'>IMG_7028.JPG</a></div></td>
<td><A ID='IMG_7064.JPG' href='thewrapup.php?fileId=IMG_7064.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060323/IMG_7064.JPG' ALT='IMG_7064.JPG'><BR>IMG_7064.JPG<br>57.8 KB</a><div class='inv'><br><a href='./images/20060323/IMG_7064.JPG' ALT='IMG_7064.JPG'>IMG_7064.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_7080.JPG' href='thewrapup.php?fileId=IMG_7080.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060323/IMG_7080.JPG' ALT='IMG_7080.JPG'><BR>IMG_7080.JPG<br>71.19 KB</a><div class='inv'><br><a href='./images/20060323/IMG_7080.JPG' ALT='IMG_7080.JPG'>IMG_7080.JPG</a></div></td>
<td><A ID='IMG_7087.JPG' href='thewrapup.php?fileId=IMG_7087.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060323/IMG_7087.JPG' ALT='IMG_7087.JPG'><BR>IMG_7087.JPG<br>60.49 KB</a><div class='inv'><br><a href='./images/20060323/IMG_7087.JPG' ALT='IMG_7087.JPG'>IMG_7087.JPG</a></div></td>
<td><A ID='IMG_7088.JPG' href='thewrapup.php?fileId=IMG_7088.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060323/IMG_7088.JPG' ALT='IMG_7088.JPG'><BR>IMG_7088.JPG<br>69.7 KB</a><div class='inv'><br><a href='./images/20060323/IMG_7088.JPG' ALT='IMG_7088.JPG'>IMG_7088.JPG</a></div></td>
<td><A ID='IMG_7091.JPG' href='thewrapup.php?fileId=IMG_7091.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060323/IMG_7091.JPG' ALT='IMG_7091.JPG'><BR>IMG_7091.JPG<br>54.46 KB</a><div class='inv'><br><a href='./images/20060323/IMG_7091.JPG' ALT='IMG_7091.JPG'>IMG_7091.JPG</a></div></td>
<td><A ID='IMG_7098.JPG' href='thewrapup.php?fileId=IMG_7098.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060323/IMG_7098.JPG' ALT='IMG_7098.JPG'><BR>IMG_7098.JPG<br>55.16 KB</a><div class='inv'><br><a href='./images/20060323/IMG_7098.JPG' ALT='IMG_7098.JPG'>IMG_7098.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_7270.JPG' href='thewrapup.php?fileId=IMG_7270.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060323/IMG_7270.JPG' ALT='IMG_7270.JPG'><BR>IMG_7270.JPG<br>87.5 KB</a><div class='inv'><br><a href='./images/20060323/IMG_7270.JPG' ALT='IMG_7270.JPG'>IMG_7270.JPG</a></div></td>
<td><A ID='IMG_7283.JPG' href='thewrapup.php?fileId=IMG_7283.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060323/IMG_7283.JPG' ALT='IMG_7283.JPG'><BR>IMG_7283.JPG<br>80.41 KB</a><div class='inv'><br><a href='./images/20060323/IMG_7283.JPG' ALT='IMG_7283.JPG'>IMG_7283.JPG</a></div></td>
<td><A ID='IMG_7284.JPG' href='thewrapup.php?fileId=IMG_7284.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060323/IMG_7284.JPG' ALT='IMG_7284.JPG'><BR>IMG_7284.JPG<br>79.85 KB</a><div class='inv'><br><a href='./images/20060323/IMG_7284.JPG' ALT='IMG_7284.JPG'>IMG_7284.JPG</a></div></td>
<td><A ID='IMG_7298.JPG' href='thewrapup.php?fileId=IMG_7298.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060323/IMG_7298.JPG' ALT='IMG_7298.JPG'><BR>IMG_7298.JPG<br>76.83 KB</a><div class='inv'><br><a href='./images/20060323/IMG_7298.JPG' ALT='IMG_7298.JPG'>IMG_7298.JPG</a></div></td>
<td><A ID='IMG_7299.JPG' href='thewrapup.php?fileId=IMG_7299.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060323/IMG_7299.JPG' ALT='IMG_7299.JPG'><BR>IMG_7299.JPG<br>77.93 KB</a><div class='inv'><br><a href='./images/20060323/IMG_7299.JPG' ALT='IMG_7299.JPG'>IMG_7299.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_7301.JPG' href='thewrapup.php?fileId=IMG_7301.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060323/IMG_7301.JPG' ALT='IMG_7301.JPG'><BR>IMG_7301.JPG<br>56.92 KB</a><div class='inv'><br><a href='./images/20060323/IMG_7301.JPG' ALT='IMG_7301.JPG'>IMG_7301.JPG</a></div></td>
<td><A ID='IMG_7302.JPG' href='thewrapup.php?fileId=IMG_7302.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060323/IMG_7302.JPG' ALT='IMG_7302.JPG'><BR>IMG_7302.JPG<br>56.22 KB</a><div class='inv'><br><a href='./images/20060323/IMG_7302.JPG' ALT='IMG_7302.JPG'>IMG_7302.JPG</a></div></td>
<td><A ID='IMG_7303.JPG' href='thewrapup.php?fileId=IMG_7303.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060323/IMG_7303.JPG' ALT='IMG_7303.JPG'><BR>IMG_7303.JPG<br>56.18 KB</a><div class='inv'><br><a href='./images/20060323/IMG_7303.JPG' ALT='IMG_7303.JPG'>IMG_7303.JPG</a></div></td>
<td><A ID='IMG_7306.JPG' href='thewrapup.php?fileId=IMG_7306.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060323/IMG_7306.JPG' ALT='IMG_7306.JPG'><BR>IMG_7306.JPG<br>85.75 KB</a><div class='inv'><br><a href='./images/20060323/IMG_7306.JPG' ALT='IMG_7306.JPG'>IMG_7306.JPG</a></div></td>
<td><A ID='IMG_7332.JPG' href='thewrapup.php?fileId=IMG_7332.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060323/IMG_7332.JPG' ALT='IMG_7332.JPG'><BR>IMG_7332.JPG<br>74.99 KB</a><div class='inv'><br><a href='./images/20060323/IMG_7332.JPG' ALT='IMG_7332.JPG'>IMG_7332.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_7344.JPG' href='thewrapup.php?fileId=IMG_7344.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060323/IMG_7344.JPG' ALT='IMG_7344.JPG'><BR>IMG_7344.JPG<br>81.02 KB</a><div class='inv'><br><a href='./images/20060323/IMG_7344.JPG' ALT='IMG_7344.JPG'>IMG_7344.JPG</a></div></td>
<td><A ID='IMG_7347.JPG' href='thewrapup.php?fileId=IMG_7347.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060323/IMG_7347.JPG' ALT='IMG_7347.JPG'><BR>IMG_7347.JPG<br>65.32 KB</a><div class='inv'><br><a href='./images/20060323/IMG_7347.JPG' ALT='IMG_7347.JPG'>IMG_7347.JPG</a></div></td>
<td><A ID='IMG_7444.JPG' href='thewrapup.php?fileId=IMG_7444.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060323/IMG_7444.JPG' ALT='IMG_7444.JPG'><BR>IMG_7444.JPG<br>54.86 KB</a><div class='inv'><br><a href='./images/20060323/IMG_7444.JPG' ALT='IMG_7444.JPG'>IMG_7444.JPG</a></div></td>
<td><A ID='IMG_7447.JPG' href='thewrapup.php?fileId=IMG_7447.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060323/IMG_7447.JPG' ALT='IMG_7447.JPG'><BR>IMG_7447.JPG<br>60.46 KB</a><div class='inv'><br><a href='./images/20060323/IMG_7447.JPG' ALT='IMG_7447.JPG'>IMG_7447.JPG</a></div></td>
<td><A ID='IMG_7512.JPG' href='thewrapup.php?fileId=IMG_7512.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060323/IMG_7512.JPG' ALT='IMG_7512.JPG'><BR>IMG_7512.JPG<br>49.98 KB</a><div class='inv'><br><a href='./images/20060323/IMG_7512.JPG' ALT='IMG_7512.JPG'>IMG_7512.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_7867.JPG' href='thewrapup.php?fileId=IMG_7867.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060323/IMG_7867.JPG' ALT='IMG_7867.JPG'><BR>IMG_7867.JPG<br>50.75 KB</a><div class='inv'><br><a href='./images/20060323/IMG_7867.JPG' ALT='IMG_7867.JPG'>IMG_7867.JPG</a></div></td>
<td><A ID='IMG_8039.JPG' href='thewrapup.php?fileId=IMG_8039.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060323/IMG_8039.JPG' ALT='IMG_8039.JPG'><BR>IMG_8039.JPG<br>51.02 KB</a><div class='inv'><br><a href='./images/20060323/IMG_8039.JPG' ALT='IMG_8039.JPG'>IMG_8039.JPG</a></div></td>
<td><A ID='IMG_8040.JPG' href='thewrapup.php?fileId=IMG_8040.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060323/IMG_8040.JPG' ALT='IMG_8040.JPG'><BR>IMG_8040.JPG<br>43.23 KB</a><div class='inv'><br><a href='./images/20060323/IMG_8040.JPG' ALT='IMG_8040.JPG'>IMG_8040.JPG</a></div></td>
<td><A ID='IMG_8050.JPG' href='thewrapup.php?fileId=IMG_8050.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060323/IMG_8050.JPG' ALT='IMG_8050.JPG'><BR>IMG_8050.JPG<br>53.2 KB</a><div class='inv'><br><a href='./images/20060323/IMG_8050.JPG' ALT='IMG_8050.JPG'>IMG_8050.JPG</a></div></td>
<td><A ID='IMG_8052.JPG' href='thewrapup.php?fileId=IMG_8052.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060323/IMG_8052.JPG' ALT='IMG_8052.JPG'><BR>IMG_8052.JPG<br>42.62 KB</a><div class='inv'><br><a href='./images/20060323/IMG_8052.JPG' ALT='IMG_8052.JPG'>IMG_8052.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_8053.JPG' href='thewrapup.php?fileId=IMG_8053.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060323/IMG_8053.JPG' ALT='IMG_8053.JPG'><BR>IMG_8053.JPG<br>43.73 KB</a><div class='inv'><br><a href='./images/20060323/IMG_8053.JPG' ALT='IMG_8053.JPG'>IMG_8053.JPG</a></div></td>
<td><A ID='IMG_8092.JPG' href='thewrapup.php?fileId=IMG_8092.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060323/IMG_8092.JPG' ALT='IMG_8092.JPG'><BR>IMG_8092.JPG<br>66.27 KB</a><div class='inv'><br><a href='./images/20060323/IMG_8092.JPG' ALT='IMG_8092.JPG'>IMG_8092.JPG</a></div></td>
<td><A ID='IMG_8127.JPG' href='thewrapup.php?fileId=IMG_8127.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060323/IMG_8127.JPG' ALT='IMG_8127.JPG'><BR>IMG_8127.JPG<br>55.9 KB</a><div class='inv'><br><a href='./images/20060323/IMG_8127.JPG' ALT='IMG_8127.JPG'>IMG_8127.JPG</a></div></td>
<td><A ID='IMG_8132.JPG' href='thewrapup.php?fileId=IMG_8132.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060323/IMG_8132.JPG' ALT='IMG_8132.JPG'><BR>IMG_8132.JPG<br>49.99 KB</a><div class='inv'><br><a href='./images/20060323/IMG_8132.JPG' ALT='IMG_8132.JPG'>IMG_8132.JPG</a></div></td>
<td><A ID='IMG_8146.JPG' href='thewrapup.php?fileId=IMG_8146.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060323/IMG_8146.JPG' ALT='IMG_8146.JPG'><BR>IMG_8146.JPG<br>52.86 KB</a><div class='inv'><br><a href='./images/20060323/IMG_8146.JPG' ALT='IMG_8146.JPG'>IMG_8146.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_8162.JPG' href='thewrapup.php?fileId=IMG_8162.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060323/IMG_8162.JPG' ALT='IMG_8162.JPG'><BR>IMG_8162.JPG<br>51.88 KB</a><div class='inv'><br><a href='./images/20060323/IMG_8162.JPG' ALT='IMG_8162.JPG'>IMG_8162.JPG</a></div></td>
<td><A ID='IMG_8176.JPG' href='thewrapup.php?fileId=IMG_8176.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060323/IMG_8176.JPG' ALT='IMG_8176.JPG'><BR>IMG_8176.JPG<br>58.45 KB</a><div class='inv'><br><a href='./images/20060323/IMG_8176.JPG' ALT='IMG_8176.JPG'>IMG_8176.JPG</a></div></td>
<td><A ID='IMG_8178.JPG' href='thewrapup.php?fileId=IMG_8178.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060323/IMG_8178.JPG' ALT='IMG_8178.JPG'><BR>IMG_8178.JPG<br>59.91 KB</a><div class='inv'><br><a href='./images/20060323/IMG_8178.JPG' ALT='IMG_8178.JPG'>IMG_8178.JPG</a></div></td>
<td><A ID='IMG_8246.JPG' href='thewrapup.php?fileId=IMG_8246.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060323/IMG_8246.JPG' ALT='IMG_8246.JPG'><BR>IMG_8246.JPG<br>66.3 KB</a><div class='inv'><br><a href='./images/20060323/IMG_8246.JPG' ALT='IMG_8246.JPG'>IMG_8246.JPG</a></div></td>
<td><A ID='IMG_8248.JPG' href='thewrapup.php?fileId=IMG_8248.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060323/IMG_8248.JPG' ALT='IMG_8248.JPG'><BR>IMG_8248.JPG<br>54.72 KB</a><div class='inv'><br><a href='./images/20060323/IMG_8248.JPG' ALT='IMG_8248.JPG'>IMG_8248.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_8249.JPG' href='thewrapup.php?fileId=IMG_8249.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060323/IMG_8249.JPG' ALT='IMG_8249.JPG'><BR>IMG_8249.JPG<br>80.63 KB</a><div class='inv'><br><a href='./images/20060323/IMG_8249.JPG' ALT='IMG_8249.JPG'>IMG_8249.JPG</a></div></td>
<td><A ID='IMG_8257.JPG' href='thewrapup.php?fileId=IMG_8257.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060323/IMG_8257.JPG' ALT='IMG_8257.JPG'><BR>IMG_8257.JPG<br>66.82 KB</a><div class='inv'><br><a href='./images/20060323/IMG_8257.JPG' ALT='IMG_8257.JPG'>IMG_8257.JPG</a></div></td>
<td><A ID='IMG_8266.JPG' href='thewrapup.php?fileId=IMG_8266.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060323/IMG_8266.JPG' ALT='IMG_8266.JPG'><BR>IMG_8266.JPG<br>55.26 KB</a><div class='inv'><br><a href='./images/20060323/IMG_8266.JPG' ALT='IMG_8266.JPG'>IMG_8266.JPG</a></div></td>
<td><A ID='IMG_8273.JPG' href='thewrapup.php?fileId=IMG_8273.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060323/IMG_8273.JPG' ALT='IMG_8273.JPG'><BR>IMG_8273.JPG<br>35.78 KB</a><div class='inv'><br><a href='./images/20060323/IMG_8273.JPG' ALT='IMG_8273.JPG'>IMG_8273.JPG</a></div></td>
<td><A ID='IMG_8278.JPG' href='thewrapup.php?fileId=IMG_8278.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060323/IMG_8278.JPG' ALT='IMG_8278.JPG'><BR>IMG_8278.JPG<br>51.56 KB</a><div class='inv'><br><a href='./images/20060323/IMG_8278.JPG' ALT='IMG_8278.JPG'>IMG_8278.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_8283.JPG' href='thewrapup.php?fileId=IMG_8283.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060323/IMG_8283.JPG' ALT='IMG_8283.JPG'><BR>IMG_8283.JPG<br>60.21 KB</a><div class='inv'><br><a href='./images/20060323/IMG_8283.JPG' ALT='IMG_8283.JPG'>IMG_8283.JPG</a></div></td>
<td><A ID='IMG_8284.JPG' href='thewrapup.php?fileId=IMG_8284.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060323/IMG_8284.JPG' ALT='IMG_8284.JPG'><BR>IMG_8284.JPG<br>53.57 KB</a><div class='inv'><br><a href='./images/20060323/IMG_8284.JPG' ALT='IMG_8284.JPG'>IMG_8284.JPG</a></div></td>
<td><A ID='IMG_8286.JPG' href='thewrapup.php?fileId=IMG_8286.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060323/IMG_8286.JPG' ALT='IMG_8286.JPG'><BR>IMG_8286.JPG<br>62.08 KB</a><div class='inv'><br><a href='./images/20060323/IMG_8286.JPG' ALT='IMG_8286.JPG'>IMG_8286.JPG</a></div></td>
<td><A ID='IMG_8289.JPG' href='thewrapup.php?fileId=IMG_8289.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060323/IMG_8289.JPG' ALT='IMG_8289.JPG'><BR>IMG_8289.JPG<br>56.27 KB</a><div class='inv'><br><a href='./images/20060323/IMG_8289.JPG' ALT='IMG_8289.JPG'>IMG_8289.JPG</a></div></td>
<td><A ID='IMG_8290.JPG' href='thewrapup.php?fileId=IMG_8290.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060323/IMG_8290.JPG' ALT='IMG_8290.JPG'><BR>IMG_8290.JPG<br>68.78 KB</a><div class='inv'><br><a href='./images/20060323/IMG_8290.JPG' ALT='IMG_8290.JPG'>IMG_8290.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_8292.JPG' href='thewrapup.php?fileId=IMG_8292.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060323/IMG_8292.JPG' ALT='IMG_8292.JPG'><BR>IMG_8292.JPG<br>55.11 KB</a><div class='inv'><br><a href='./images/20060323/IMG_8292.JPG' ALT='IMG_8292.JPG'>IMG_8292.JPG</a></div></td>
<td><A ID='IMG_8295.JPG' href='thewrapup.php?fileId=IMG_8295.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060323/IMG_8295.JPG' ALT='IMG_8295.JPG'><BR>IMG_8295.JPG<br>49.93 KB</a><div class='inv'><br><a href='./images/20060323/IMG_8295.JPG' ALT='IMG_8295.JPG'>IMG_8295.JPG</a></div></td>
<td><A ID='IMG_8298.JPG' href='thewrapup.php?fileId=IMG_8298.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060323/IMG_8298.JPG' ALT='IMG_8298.JPG'><BR>IMG_8298.JPG<br>62.75 KB</a><div class='inv'><br><a href='./images/20060323/IMG_8298.JPG' ALT='IMG_8298.JPG'>IMG_8298.JPG</a></div></td>
<td><A ID='IMG_8300.JPG' href='thewrapup.php?fileId=IMG_8300.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060323/IMG_8300.JPG' ALT='IMG_8300.JPG'><BR>IMG_8300.JPG<br>61.22 KB</a><div class='inv'><br><a href='./images/20060323/IMG_8300.JPG' ALT='IMG_8300.JPG'>IMG_8300.JPG</a></div></td>
<td><A ID='IMG_8301.JPG' href='thewrapup.php?fileId=IMG_8301.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060323/IMG_8301.JPG' ALT='IMG_8301.JPG'><BR>IMG_8301.JPG<br>46.12 KB</a><div class='inv'><br><a href='./images/20060323/IMG_8301.JPG' ALT='IMG_8301.JPG'>IMG_8301.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_8307.JPG' href='thewrapup.php?fileId=IMG_8307.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060323/IMG_8307.JPG' ALT='IMG_8307.JPG'><BR>IMG_8307.JPG<br>73.81 KB</a><div class='inv'><br><a href='./images/20060323/IMG_8307.JPG' ALT='IMG_8307.JPG'>IMG_8307.JPG</a></div></td>
<td><A ID='IMG_8310.JPG' href='thewrapup.php?fileId=IMG_8310.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060323/IMG_8310.JPG' ALT='IMG_8310.JPG'><BR>IMG_8310.JPG<br>52.08 KB</a><div class='inv'><br><a href='./images/20060323/IMG_8310.JPG' ALT='IMG_8310.JPG'>IMG_8310.JPG</a></div></td>
<td><A ID='IMG_8315.JPG' href='thewrapup.php?fileId=IMG_8315.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060323/IMG_8315.JPG' ALT='IMG_8315.JPG'><BR>IMG_8315.JPG<br>118.43 KB</a><div class='inv'><br><a href='./images/20060323/IMG_8315.JPG' ALT='IMG_8315.JPG'>IMG_8315.JPG</a></div></td>
<td><A ID='IMG_8319.JPG' href='thewrapup.php?fileId=IMG_8319.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060323/IMG_8319.JPG' ALT='IMG_8319.JPG'><BR>IMG_8319.JPG<br>66.93 KB</a><div class='inv'><br><a href='./images/20060323/IMG_8319.JPG' ALT='IMG_8319.JPG'>IMG_8319.JPG</a></div></td>
<td><A ID='IMG_8320.JPG' href='thewrapup.php?fileId=IMG_8320.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060323/IMG_8320.JPG' ALT='IMG_8320.JPG'><BR>IMG_8320.JPG<br>57.76 KB</a><div class='inv'><br><a href='./images/20060323/IMG_8320.JPG' ALT='IMG_8320.JPG'>IMG_8320.JPG</a></div></td>
</tr>
</table>	</div>
</div>
</body>
</html>