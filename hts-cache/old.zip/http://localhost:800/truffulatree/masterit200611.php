<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - November 2006 - Q&A letters</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="Q&A letters">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="Q&A letters" href='masterit200601.php'>January 2006</a></li>
<li><a title="Q&A letters" href='masterit200602.php'>February 2006</a></li>
<li><a title="Q&A letters" href='masterit200603.php'>March 2006</a></li>
<li><a title="Q&A letters" href='masterit200604.php'>April 2006</a></li>
<li><a title="Q&A letters" href='masterit200605.php'>May 2006</a></li>
<li><a title="Q&A letters" href='masterit200606.php'>June 2006</a></li>
<li><a title="Q&A letters" href='masterit200607.php'>July 2006</a></li>
<li><a title="Q&A letters" href='masterit200608.php'>August 2006</a></li>
<li><a title="Q&A letters" href='masterit200609.php'>September 2006</a></li>
<li><a title="Q&A letters" href='masterit200610.php'>October 2006</a></li>
<li><div class='activemenu'>November 2006</div></li>
<li><a title="Q&A letters" href='masterit200612.php'>December 2006</a></li>
<li> </li><br><li>Or go back to:</li><li><a title='Q&A/MasterIT letters from 2006' href="masterit2006.php">2006 archive</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>November 2006</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Mark's writing' href="written.php">Professional Writing</a> > <a title='My weekly Q&A column in The Australian' href="masterIT.php">MasterIT</a> > <a title='Q&A/MasterIT letters from 2006' href="masterit2006.php">2006 archive</a> > <a title='Q&A letters' href="masterit200611.php">November 2006</a>
<br><br>		<br>
<h2>7/11/06</h2><br>
<b>Someone stole my email address, and I've been getting thousands of returned emails that I never sent, filling my mail box. From the number that I got back, they had to have sent hundreds of thousands out. Telstra, who were quite frankly useless, had no idea what to do, except change our email address. Do you know of other instances of this? Also, as Telstra are (to say the least) unhelpful, I am looking at changing all my phones etc. Can I find a company that actually cares about their customers, or is it a lost search?</b><br>
<br>
Sorry to hear about your woes. Like most of us, I've had my own hassles with Telstra over the years, but any vaguely competent helpdesk person should have been able to explain deal with this.<br>
<br>
What has most likely happened is that someone has been sending spam email out, with your address as the "from" address.<br>
<br>
Spammers, as we all know, are up there with lawyers, used car salespeople, politicians, recruiters and real estate agents (and hopefully I didn't just alienate TOO many readers!).<br>
<br>
Your problem arises because they often send their wares out using a forged "from" address. Spam lists contain literally millions of email addresses, but many of these are inevitably invalid, so the emails bounce back to the "from" address... i.e., back to you.<br>
<br>
Unfortunately, if your ISP doesn't filter these false bounces (which they can in many cases!), there's not much you can do, apart from change your address or set up some local filters of your own. Thankfully, in most cases the flood of messages won't last, as spammers tend to frequently change the pinched "from" addresses they use to get around ever-changing spam filters.<br>
<br>
It's probably not a bad idea to check your PC for viruses and Trojans too, just in case your PC has been taken over by a spammer and is sending mail on their behalf.<br>
<br>
Getting on to Telstra, well, they are certainly one of the worst value ISPs in Australia. I still find it mind-boggling that so many people use them as their service provider, but I guess that's brand name value for you.<br>
<br>
One ISP I'd highly recommend is Internode (http://internode.on.net.au). I've had very good experiences with them over the years, and they have excellent support people.<br>
<br>
iiNet are also ok, but they're larger, and less exemplary in the support department.<br>
<br>
Your best bet is to have a look at the Broadband Choice website (http://bc.whirlpool.net.au) - they have a very good, unbiased comparison of Australian ISPs available.<br>
<br>
<br>
<h2>14/11/06</h2><br>
<b>Would you know of any free programs to indicate the speed that data is being received/transmitted when connected to the Internet? I am using Windows XP Pro SP2 and connect to the Internet using Unwired's service. Could you also let me know where I can get the downloads?</b><br>
<br>
There are various programs that will claim to test your connection's speed, but ultimately, because they all work the same way, they suffer from the same problem.<br>
<br>
Basically, they work by transferring a known amount of data from and/or to a particular point on the Internet, whilst timing the transfer.<br>
<br>
The problem with this approach is that the speed can vary enormously depending on the location of the site in question. If it's very local, you'll get a result close to your actual theoretical top speed, but if it's on the other side of the world, your local connection's speed is unlikely to be the limiting factor.<br>
<br>
Because of this, some ISPs provide local speed test websites to help you, but Unwired don't seem to have one on offer.<br>
<br>
Ultimately, the best way to test your connection's speed is simply to try and find a fairly large file hosted by your own ISP, and download it. Your browser will report the transfer speed as it comes through.<br>
<br>
If your ISP doesn't have a file archive (and, once again, Unwired don't appear to), any local content connected to the Internet with a Big Fat Pipe is almost as good.<br>
<br>
Try grabbing something large from http://mirror.optusnet.com.au. Remember that you don't have to download the whole thing just to get an indication of the speed.<br>
<br>
Lastly, bear in mind that while wireless data connections have a theoretical top speed, in the real world they often run more slowly, to compensate for a bad signal.<br>
<br>
They also have to cope with varying load over multiple users, with only a limited amount of bandwidth for all on each base station.<br>
<br>
As such, it's quite possible that you'll find your connection's top speed varies quite a lot. It may be lower when it rains (water eats high frequency radio waves), or at particular times of the day.<br>
<br>
<br>
<h2>21/11/06</h2><br>
<b>I've recently acquired a digital camera, and have been happily snapping away. I set up the camera to overlay the date and time on each photo, because I like to have this information stored. However, a member of the family's younger generation suggested that this probably isn't necessary, as the camera stores the date already in the "EXIF". What is this mysterious EXIF, and how do I get at it?</b><br>
<br>
Exif, which stands for Exchangeable Image File Format, is a standard created some years ago to allow embedded information within certain types of images; in particular, JPEG and TIFF files.<br>
<br>
What happens is that, in addition to the actual picture information, various pieces of metadata (a fancy term for extra information) can be stored within the image file itself.<br>
<br>
All modern digital cameras store Exif information. At the very least, they store the date and time of the photo, the brand and model of camera, and various pieces of technical information related to the photography, like the exposure time, aperture, focal length, and even thumbnails of the full-sized image.<br>
<br>
This is really handy for developing your photographic skills - you can take a series of photographs with different settings without having to write anything down, and then review them on the computer later to find out which settings worked best.<br>
<br>
All good image management programs can read the Exif information and display it in a variety of ways.<br>
<br>
For example, Acdsee can display the Exif information with each picture, by right clicking and selecting properties. It can also sort your images by Exif information - for example, you can select a date or dates on a calendar, and the program will then list all the pictures that were taken on those days.<br>
<br>
Google's freebie, Picasa, also has good Exif support. You can grab it at picasa.google.com.au.<br>
<br>
There are also dozens of other programs out there to let you view, edit and manage Exif information, as well as it's kindred standard, the IPTC (International Press Telecommunications Council) metadata set. Google and Wikipedia will give you plenty of good starting points.<br>
<br>
<br>
<b>More on testing your Internet Connection Speed</b><br>
<br>
Last week I talked about various ways to test the speed of your Internet connection. I've since been pointed to the Line Speed Meter at www.tcpiq.com by a kindly reader. It's the most comprehensive speed monitoring tool I've seen to date, and is well worth a look.<br>
<br>
<i><p>Did the information on this page help you? Entertain you? Bore you? <a href="contact.php?subject=MasterIT">Drop me a line</a>.</p>

<p>If you're feeling particularly generous, you can even <a href="buypics.php">click here to send me some dot-com riches</a>. Think of it as online busking.</i></p>
	</div>
</div>
</body>
</html>