<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - Fuzzy Polaroid - MP3s from Fuzzy Polaroid's gigs at the Step Inn and Second Degree Bar</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="MP3s from Fuzzy Polaroid's gigs at the Step Inn and Second Degree Bar">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="Baker's Dozen MP3s (Mark Cocquio, Lindsay Halamek, Guy Bunn and he who must not be named)" href='bakersdozen.php'>Baker's Dozen</a></li>
<li><a title="MP3s from the CUE (Consistent User Experience - Mark Cocquio, Nathan Spargo and Wade Kuhn), including Monkey Magic and a really bad Gandhara cover" href='consistentuserexperience.php'>CUE</a></li>
<li><div class='activemenu'>Fuzzy Polaroid</div></li>
<li> </li><br><li>Or go back to:</li><li><a title='Sounds and music' href="music.php">Music</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>Fuzzy Polaroid</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Sounds and music' href="music.php">Music</a> > <a title='MP3s from Fuzzy Polaroid's gigs at the Step Inn and Second Degree Bar' href="fuzzypolaroidmp3s.php">Fuzzy Polaroid</a>
<br><br>		<br>
Fuzzy Polaroid is the latest musical endeavour that I've been roped into (and my debut as a drummer).<br>
<br>
We play a funky blues rock set of <a href="http://www.digi-comic.com" target="_blank">Nathan's</a> originals. Thus far we've had two whole gigs, and these are the MP3s from my little recorder which was present at both.<br>
<br>
It is left as an exercise to the listener to decide which version of each song they like better. I could tell you - but that would spoil the fun of making you listen to both.<br>
<br>
For pictures from the gigs, <a href="fuzzypolaroidpics.php">click here</a>.<br>
<br>
Nathan has also created a <a href="http://www.myspace.com/fuzzypolaroid" title="Fuzzy Polaroid" target="_blank">Myspace page for the band</a>, although it's really just demos at this stage. We'll record proper versions of the songs in due course I think (because that'll be FUN).<br>
 <br>
<img src="images/fuzzypolaroid.jpg" alt="Fuzzy Polaroid Poster"><br>
<br><br>
Files available for download:<br>
<ul class="dirlist"><li>Live at the Second Degree</li><ul class="dirlist"><li><a href="./files/fuzzypolaroid/Live at the Second Degree/01 - Don't You Wanna Know.mp3">01 - Don't You Wanna Know.mp3</a></li><li><a href="./files/fuzzypolaroid/Live at the Second Degree/02 - Rainy Day.mp3">02 - Rainy Day.mp3</a></li><li><a href="./files/fuzzypolaroid/Live at the Second Degree/03 - Brand New Attitude.mp3">03 - Brand New Attitude.mp3</a></li><li><a href="./files/fuzzypolaroid/Live at the Second Degree/04 - Sad Tale.mp3">04 - Sad Tale.mp3</a></li><li><a href="./files/fuzzypolaroid/Live at the Second Degree/05 - It Goes On.mp3">05 - It Goes On.mp3</a></li><li><a href="./files/fuzzypolaroid/Live at the Second Degree/06 - Intermission #1.mp3">06 - Intermission #1.mp3</a></li><li><a href="./files/fuzzypolaroid/Live at the Second Degree/07 - Rooster Blues.mp3">07 - Rooster Blues.mp3</a></li><li><a href="./files/fuzzypolaroid/Live at the Second Degree/08 - Second Intermission.mp3">08 - Second Intermission.mp3</a></li><li><a href="./files/fuzzypolaroid/Live at the Second Degree/09 - Told You So.mp3">09 - Told You So.mp3</a></li><li><a href="./files/fuzzypolaroid/Live at the Second Degree/10 - The Truth.mp3">10 - The Truth.mp3</a></li><li><a href="./files/fuzzypolaroid/Live at the Second Degree/11 - Relaxin'.mp3">11 - Relaxin'.mp3</a></li><li><a href="./files/fuzzypolaroid/Live at the Second Degree/12 - Open Your Eyes.mp3">12 - Open Your Eyes.mp3</a></li><li><a href="./files/fuzzypolaroid/Live at the Second Degree/13 - The Flame.mp3">13 - The Flame.mp3</a></li><li><a href="./files/fuzzypolaroid/Live at the Second Degree/14 - Tropical Storm Blues.mp3">14 - Tropical Storm Blues.mp3</a></li></ul><li>Live at the Step Inn</li><ul class="dirlist"><li><a href="./files/fuzzypolaroid/Live at the Step Inn/01 - Rainy Day.mp3">01 - Rainy Day.mp3</a></li><li><a href="./files/fuzzypolaroid/Live at the Step Inn/02 - Don't You Wanna Know.mp3">02 - Don't You Wanna Know.mp3</a></li><li><a href="./files/fuzzypolaroid/Live at the Step Inn/03 - Brand New Attitude.mp3">03 - Brand New Attitude.mp3</a></li><li><a href="./files/fuzzypolaroid/Live at the Step Inn/04 - Sad Tale.mp3">04 - Sad Tale.mp3</a></li><li><a href="./files/fuzzypolaroid/Live at the Step Inn/05 - It Goes On.mp3">05 - It Goes On.mp3</a></li><li><a href="./files/fuzzypolaroid/Live at the Step Inn/06 - Intermission #1.mp3">06 - Intermission #1.mp3</a></li><li><a href="./files/fuzzypolaroid/Live at the Step Inn/07 - Rooster Blues.mp3">07 - Rooster Blues.mp3</a></li><li><a href="./files/fuzzypolaroid/Live at the Step Inn/08 - Second Intermission.mp3">08 - Second Intermission.mp3</a></li><li><a href="./files/fuzzypolaroid/Live at the Step Inn/09 - Told You So.mp3">09 - Told You So.mp3</a></li><li><a href="./files/fuzzypolaroid/Live at the Step Inn/10 - The Truth.mp3">10 - The Truth.mp3</a></li><li><a href="./files/fuzzypolaroid/Live at the Step Inn/11 - Relaxin'.mp3">11 - Relaxin'.mp3</a></li><li><a href="./files/fuzzypolaroid/Live at the Step Inn/12 - Open Your Eyes.mp3">12 - Open Your Eyes.mp3</a></li><li><a href="./files/fuzzypolaroid/Live at the Step Inn/13 - The Flame.mp3">13 - The Flame.mp3</a></li><li><a href="./files/fuzzypolaroid/Live at the Step Inn/14 - Tropical Storm Blues.mp3">14 - Tropical Storm Blues.mp3</a></li></ul><li>Studio Recordings</li><ul class="dirlist"><li><a href="./files/fuzzypolaroid/Studio Recordings/Don't You Wanna Know.mp3">Don't You Wanna Know.mp3</a></li></ul></ul><!-- old method
getTheFiles($file);

function getTheFiles($folder) {
	if ($handle = opendir($folder)) {
		while (false !== ($file = readdir($handle))) {
			If ($file!= "." && $file!= ".." and !is_dir($folder."/".$file)) {
				$filesize = round(filesize ($folder."/".$file)/1024,2);
				echo "<tr><td><div align='left'><A href='$corelise$folder/$file'>$file</a></div></td><td><div align='left'>$filesize KB</div></td><tr>\n";
			} else {
			If ($file!= "." && $file!= ".." and is_dir($folder."/".$file)) {
				getTheFiles($file);
			}
		}
		closedir($handle);
	}
} -->
	</div>
</div>
</body>
</html>