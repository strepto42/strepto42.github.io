<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - 1/7/2005 - Blowing Bubbles in a Watery Tomb</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="Blowing Bubbles in a Watery Tomb">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="Greetings from a Bum" href='greetingsfromabum.php'>29/4/2005</a></li>
<li><a title="Onward" href='onward.php'>2/5/2005</a></li>
<li><a title="It's a tough life (pt 1: Bundaberg, Agnes Water and 1770)" href='itsatoughlife1.php'>17/5/2005</a></li>
<li><a title="It's a tough life (pt 2: Rockhampton, Emu Park and Great Keppel Island)" href='itsatoughlife2.php'>23/5/2005</a></li>
<li><a title="There and Back Again - a Yo-yo's Tale" href='thereandbackagain.php'>18/6/2005</a></li>
<li><a title="Platypi and Grey Nomads" href='platypiandgreynomads.php'>24/6/2005</a></li>
<li><div class='activemenu'>1/7/2005</div></li>
<li><a title="Pieces of History" href='piecesofhistory.php'>8/7/2005</a></li>
<li><a title="Walks and Waterfalls" href='walksandwaterfalls.php'>15/7/2005</a></li>
<li><a title="Mission to Tribulation" href='missiontotribulation.php'>22/7/2005</a></li>
<li><a title="Levity, Limestone and Lava" href='levitylimestoneandlava.php'>29/7/2005</a></li>
<li><a title="Into the Never Never" href='intothenevernever.php'>5/8/2005</a></li>
<li><a title="Slowing the pace in Darwin" href='slowingthepaceindarwin.php'>12/8/2005</a></li>
<li><a title="Blistering Barnacles and Leaping Lizards" href='leapinglizards.php'>19/8/2005</a></li>
<li><a title="Kakadu and Litchfield" href='kakadu.php'>26/8/2005</a></li>
<li><a title="Legacies of War" href='legaciesofwar.php'>2/9/2005</a></li>
<li><a title="Go West" href='gowest.php'>10/9/2005</a></li>
<li><a title="Things from Above" href='thingsfromabove.php'>16/9/2005</a></li>
<li><a title="The West Coast" href='thewestcoast.php'>23/9/2005</a></li>
<li><a title="Reefs and Red Dust" href='reefsandreddust.php'>30/9/2005</a></li>
<li><a title="The Pilbara" href='pilbara.php'>7/10/2005</a></li>
<li><a title="Paradise with a Headwind" href='paradisewithaheadwind.php'>14/10/2005</a></li>
<li><a title="Down the Coral Coast" href='downthecoralcoast.php'>21/10/2005</a></li>
<li><a title="Pinnacles and Pinnipeds" href='pinnaclesandpinnipeds.php'>28/10/2005</a></li>
<li><a title="A week in Perth" href='perth.php'>4/11/2005</a></li>
<li><a title="The Southwest (from Above and Below)" href='thesouthwest.php'>11/11/2005</a></li>
<li><a title="More Heights and Depths" href='moreheightsanddepths.php'>18/11/2005</a></li>
<li><a title="Across the Nullarbor (and a bit beyond)" href='nullarbor.php'>25/11/2005</a></li>
<li><a title="Double Whammy" href='doublewhammy.php'>9/12/2005</a></li>
<li><a title="Two Cities" href='twocities.php'>19/12/2005</a></li>
<li><a title="Tassie - Part 1" href='tassie1.php'>1/1/2006</a></li>
<li><a title="Tassie - Part 2" href='tassie2.php'>7/1/2006</a></li>
<li><a title="Full Circle" href='fullcircle.php'>26/1/2006</a></li>
<li><a title="The Wrap Up" href='thewrapup.php'>23/3/2006</a></li>
<li> </li><br><li>Or go back to:</li><li><a title='Travelouges and blogs from my trip around Australia' href="nerdseyeview.php">Nerd's Eye View</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>1/7/2005</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Travel stories and pictures' href="travel.php">Travelogues</a> > <a title='Travelouges and blogs from my trip around Australia' href="nerdseyeview.php">Nerd's Eye View</a> > <a title='Blowing Bubbles in a Watery Tomb' href="blowingbubbles.php">1/7/2005</a>
<br><br>		


<h1>Blowing Bubbles in a Watery Tomb</h1>

<a href="images/maps/Map050701.gif"><img src="images/maps/Map050701_sm.gif" align="right"></a>
<p>Hiya, me again, doing the usual update for the week. I'm going to try and send them weekly, or thereabouts, from now on. For all you Aussie Friday Slackers, I'll even try to get them out so you can procrastinate about work on a Friday arvo.</p>

<p>Incidentally, if anyone is sick of these essays and wants off the list, just ask. I won't be offended. Really. There are more than 100 of you now, and I'm sure that someone out there must be sick of the sound of my voice in their head (or at least inbox). Anyway, do just tell me, it's fine.</p>

<p>The rest of you, how's about an email from time to time? Eh? EH?</p>

<p>So, to take up the story again, I left Airlie beach after a couple of days. It was suitably unimpressive, although I did manage my first successful wardrive there. This is basically a questionably ethical geek activity where one drives around with the laptop on, scanning for open (unsecured) wireless networks with Internet access. It's basically scamming free Internet off poor schmoes who can't, or more commonly don't bother to, secure their wireless networks (it is, for the record, quite easy to put basic security on a wireless network).</p>

<p>Anyway I spent an hour on some FRC's connection (an in-joke, just keep reading). It was as exciting as it sounds.</p>

<p>Apart from a few nights of random drinking in Airlie, I went on a bushwalk or two around Shute Harbour, from whence I glimpsed the Whitsunday Islands off in the distance. The first day was nice, the second was miserable, and the weather basically got worse after that. I felt thoroughly justified in not spending several hundred dollars to get cold and wet on a boat with random drunken yobs.</p>

<p>In between the two walks (and after) I also spent a few nights up at a spot called Hydeaway Bay (sic), just next to Dingo Beach. I had noticed a "town" on my maps called Earlando near there (just north of Airlie Beach along the coast), and thought I'd check it out (as there was something in the air that night, and the stars were bright, you know). It turned out to be a privately owned, and now closed, resort of yesteryear; so these little coastal places were the nearest spots to crash.</p>

<p>Hydeaway Bay was actually a really nice place, really untouched by much development, or even mobile phone access. I get the feeling the locals like it like that way too. A band played at the pub on the Sunday afternoon, and they were an amusing mix of good and bad covers, both in content and performance (eg, they did a good version of Superstition, but massacred Better).</p>

<p>The caravan park there was pretty friendly too, and I met a nice German family who were holidaying from their current work in Rocky. We all sat around the fire yackketty-yakking into the wee small hours, ie, until about 9:30 when everyone goes to bed in these places. It's quite strange, I get up damn early these days by my usual standards. But that's par for the course when you're travelling.</p>
 
<p>Anyhow, moving right along, it was time for me to do just that and keep heading north, as time is ticking away. I headed up as far as Ayr, in the Burdekin district. The land up here is really starting to change noticeably (from sugarcane to sugarcane, but no seriously, it is :)). It's quite pretty and getting quite tropical � I'm back to shorts and t-shirt, even at night.</p>

<p>I stopped off in Ayr for a couple of nights, and caught War of the Worlds. Ho hum, nice special effects and loud noises, but a wee bit too much of Tom Cruise up close (betyoulikehimeh!) and is remodelled schnoz.</p>

<p>Ayr is an odd little town. Lots of backpackers are there for the fruit picking thing, not much else is going on though, apart from cane harvest. Nathan told me that few people these days burn the cane prior to harvest. Apparently no-one told the folks up here. I got some vaguely interesting pics, smoke inhalation, and a car covered in black ash whilst I was there. Beside all that, I didn't dislike Ayr though � maybe just because they had a decent cinema (for $8 no less!).</p>

<p>Yesterday, I finally did the Yongala dive. The basic story is that the 100m long S. S. Yongala went down with all on board (more than 100) in a cyclone in 1911, and wasn't found until the 50s. People didn't start diving it until the 70s, except for someone in between who stopped off to nick the propeller (which was very large and made of brass, and therefore valuable).</p>

<p>It lies in about 28m of water, and there are apparently bones inside, but you're not allowed to penetrate the wreck any more as it's dangerous and the bubbles inside were accelerating deterioration of the structure.</p>

<p>Anyway, these days, after being down for so long, it's basically an artificial coral reef in the rough shape of a ship lying on it's side. You can still make out plenty of features though, like deck rails, the broken masts, the engine room cylinder heads and even the toilets. The name plate is also partially visible.</p>

<p>I had good luck with the weather (it was calm and pretty dang nice out there). The water was even 23 degrees, not too cold at all with a wetsuit on (although some of the other people diving would disagree). I had two awesome dives, and rented a digital camera in a housing to take some snaps. Some of them are actually pretty cool, and they'll give you the idea of what it's like down there.</p>

<p>All the pics are below of course, so have a look. There are pics of the many many fish, plus a sleepy turtle, sea snakes galore (which are air breathers BTW, and are way more poisonous than land snakes, but their teeth are too far back in their head to bite you, and besides they're placid and sweet) and of course lots of colourful coral.</p>

<p>I also bummed some pictures of another couple of guys who were diving. They're a mixed bunch; one set are much bluer because the guy didn't have a filter on his camera � basically you lose most of the colour after 10 metres (the long wavelengths get attenuated first).</p>

<p>There are also four MPEG movies that I took with the camera. They're chunky and jerky, but somehow still actually capture the coolness of the experience (perhaps it's because they have sound). Ok, well, about 1% of the coolness... Anyway, links to these files are below too.</p>

<p>So, a big tick for "one of the top ten wreck dives in the world". Both dives were great, and long (40ish minutes), and quite deep at times. Thankfully we were diving off computers and not PADI tables, as I'd be dead now (on paper! calm down!) if we were.</p>

<p>After the dives, we had a BBQ btw, and there was this poor misshapen dog hanging around. Very sweet fellow, but I think he needed to be playing the banjo...</p>

<p>Anyway I think I'll be spoiled for underwater experiences soon, although there's still tons of stuff I've yet to see (like Manta Rays, dolphins and whales). Oh that reminds me, we saw dolphins on the surface in between the two dives. I was surprised when they let me jump in for a snorkel; and I was even more surprised that I was the only one who wanted to go � Tim you would have been there with me I'm sure - anyway alas they were nowhere to be found (by me at least) and all I saw was blueness and jellyfish. Hrmph.</p>

<p>I stayed the night in yet another caravan park, in Alva Beach (from where I did the diving today). As I was writing this, plugged in to power in the BBQ area, some� large� people have been scorching meat on the platter and sending up noisome clouds of smoke, which have turned out to contain tiny droplets of grease, which are now all over my laptop's screen. <a href="http://www.digi-comic.com/?comicId=37" target="_blank">This doesn't even begin to describe my homicidal feelings</a>, but really it's a free country, and a communal area, and the Outback Queenslander really just wouldn't understand, so I didn't bite or remove anyone's body parts.</p>

<p>Today I'm in Charters Towers. Haven't seen much apart from the inside of a net cafe yet, so I'll report on it next week.</p>

<p>After here, I think I'll most likely head in to the big smoke, ie Townsville, and stay there for a day or two to see if anything jogs in my brain, as I spent my first birthday there.</p>

<p>Oh, I've also decided to caption the pictures I attach to each email, so here we go, in order of appearance:</p>

<!-- 
<ul>
<li><a href="?fileId=IMG_3759.JPG">My own private Whitsunday coast beach (on a nice day)</a></li>
<li><a href="?fileId=IMG_3827.JPG">No it's not the yanks bombing us yet, it's just the cloud from people torching  sugarcane (at sunset of course as it's prettier that way)</a></li>
<li><a href="?fileId=Mark_DSC03684.JPG">"B'scuse me, I'm a sleepy turtle!"</a></li>
<li><a href="?fileId=Mark_DSC03701.JPG">Yours truly. Nice Bert-style monobrow on the mask hey.</a></li>
</ul> 
-->

<table width="800">
	<tr>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=IMG_3759.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20050701/IMG_3759.JPG' ALT='My own private Whitsunday coast beach (on a nice day)'><BR>My own private Whitsunday coast beach (on a nice day)</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=IMG_3827.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20050701/IMG_3827.JPG' ALT="No it's not the yanks bombing us yet, it's just the cloud from people torching sugarcane (at sunset of course as it's prettier that way)"><BR>No it's not the yanks bombing us yet, it's just the cloud from people torching sugarcane (at sunset of course as it's prettier that way)</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=Mark_DSC03684.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20050701/Mark_DSC03684.JPG' ALT="B'scuse me, I'm a sleepy turtle!"><BR>"B'scuse me, I'm a sleepy turtle!"</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=Mark_DSC03701.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20050701/Mark_DSC03701.JPG' ALT='Yours truly. Nice Bert-style monobrow on the mask hey.'><BR>Yours truly. Nice Bert-style monobrow on the mask hey.</a>
	</td>
	</tr>
</table>

<p>Thanks go to all those who are keeping in contact, it's good to hear the news from home and abroad. The rest of you will of course burn, screaming, in hell, if it exists, which it doesn't, so there. ;)</p>

<p>Till next time, take care...</p>

<p>To download the movies, click below. All files are 10-20 meg:<br>
<a href="files/nerdseyeview/MOV03707.MPG">MOV03707.MPG</a><br>
<a href="files/nerdseyeview/MOV03716.MPG">MOV03716.MPG</a><br>
<a href="files/nerdseyeview/MOV03723.MPG">MOV03723.MPG</a><br>
<a href="files/nerdseyeview/MOV03730.MPG">MOV03730.MPG</a><br>
</p>
<br><br>
All images in this gallery:<br>
<table width='800'>
<tr>
</tr>
<tr><td><A ID='IMG_3731.JPG' href='blowingbubbles.php?fileId=IMG_3731.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050701/IMG_3731.JPG' ALT='IMG_3731.JPG'><BR>IMG_3731.JPG<br>61.72 KB</a><div class='inv'><br><a href='./images/20050701/IMG_3731.JPG' ALT='IMG_3731.JPG'>IMG_3731.JPG</a></div></td>
<td><A ID='IMG_3738.JPG' href='blowingbubbles.php?fileId=IMG_3738.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050701/IMG_3738.JPG' ALT='IMG_3738.JPG'><BR>IMG_3738.JPG<br>70.06 KB</a><div class='inv'><br><a href='./images/20050701/IMG_3738.JPG' ALT='IMG_3738.JPG'>IMG_3738.JPG</a></div></td>
<td><A ID='IMG_3750.JPG' href='blowingbubbles.php?fileId=IMG_3750.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050701/IMG_3750.JPG' ALT='IMG_3750.JPG'><BR>IMG_3750.JPG<br>70.91 KB</a><div class='inv'><br><a href='./images/20050701/IMG_3750.JPG' ALT='IMG_3750.JPG'>IMG_3750.JPG</a></div></td>
<td><A ID='IMG_3752.JPG' href='blowingbubbles.php?fileId=IMG_3752.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050701/IMG_3752.JPG' ALT='IMG_3752.JPG'><BR>IMG_3752.JPG<br>72.23 KB</a><div class='inv'><br><a href='./images/20050701/IMG_3752.JPG' ALT='IMG_3752.JPG'>IMG_3752.JPG</a></div></td>
<td><A ID='IMG_3753.JPG' href='blowingbubbles.php?fileId=IMG_3753.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050701/IMG_3753.JPG' ALT='IMG_3753.JPG'><BR>IMG_3753.JPG<br>56.57 KB</a><div class='inv'><br><a href='./images/20050701/IMG_3753.JPG' ALT='IMG_3753.JPG'>IMG_3753.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_3759.JPG' href='blowingbubbles.php?fileId=IMG_3759.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050701/IMG_3759.JPG' ALT='IMG_3759.JPG'><BR>IMG_3759.JPG<br>76.55 KB</a><div class='inv'><br><a href='./images/20050701/IMG_3759.JPG' ALT='IMG_3759.JPG'>IMG_3759.JPG</a></div></td>
<td><A ID='IMG_3760.JPG' href='blowingbubbles.php?fileId=IMG_3760.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050701/IMG_3760.JPG' ALT='IMG_3760.JPG'><BR>IMG_3760.JPG<br>55.54 KB</a><div class='inv'><br><a href='./images/20050701/IMG_3760.JPG' ALT='IMG_3760.JPG'>IMG_3760.JPG</a></div></td>
<td><A ID='IMG_3761.JPG' href='blowingbubbles.php?fileId=IMG_3761.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050701/IMG_3761.JPG' ALT='IMG_3761.JPG'><BR>IMG_3761.JPG<br>54.82 KB</a><div class='inv'><br><a href='./images/20050701/IMG_3761.JPG' ALT='IMG_3761.JPG'>IMG_3761.JPG</a></div></td>
<td><A ID='IMG_3763.JPG' href='blowingbubbles.php?fileId=IMG_3763.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050701/IMG_3763.JPG' ALT='IMG_3763.JPG'><BR>IMG_3763.JPG<br>107.4 KB</a><div class='inv'><br><a href='./images/20050701/IMG_3763.JPG' ALT='IMG_3763.JPG'>IMG_3763.JPG</a></div></td>
<td><A ID='IMG_3764.JPG' href='blowingbubbles.php?fileId=IMG_3764.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050701/IMG_3764.JPG' ALT='IMG_3764.JPG'><BR>IMG_3764.JPG<br>123.96 KB</a><div class='inv'><br><a href='./images/20050701/IMG_3764.JPG' ALT='IMG_3764.JPG'>IMG_3764.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_3766.JPG' href='blowingbubbles.php?fileId=IMG_3766.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050701/IMG_3766.JPG' ALT='IMG_3766.JPG'><BR>IMG_3766.JPG<br>58.33 KB</a><div class='inv'><br><a href='./images/20050701/IMG_3766.JPG' ALT='IMG_3766.JPG'>IMG_3766.JPG</a></div></td>
<td><A ID='IMG_3769.JPG' href='blowingbubbles.php?fileId=IMG_3769.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050701/IMG_3769.JPG' ALT='IMG_3769.JPG'><BR>IMG_3769.JPG<br>45.58 KB</a><div class='inv'><br><a href='./images/20050701/IMG_3769.JPG' ALT='IMG_3769.JPG'>IMG_3769.JPG</a></div></td>
<td><A ID='IMG_3774.JPG' href='blowingbubbles.php?fileId=IMG_3774.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050701/IMG_3774.JPG' ALT='IMG_3774.JPG'><BR>IMG_3774.JPG<br>74.11 KB</a><div class='inv'><br><a href='./images/20050701/IMG_3774.JPG' ALT='IMG_3774.JPG'>IMG_3774.JPG</a></div></td>
<td><A ID='IMG_3777.JPG' href='blowingbubbles.php?fileId=IMG_3777.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050701/IMG_3777.JPG' ALT='IMG_3777.JPG'><BR>IMG_3777.JPG<br>52.93 KB</a><div class='inv'><br><a href='./images/20050701/IMG_3777.JPG' ALT='IMG_3777.JPG'>IMG_3777.JPG</a></div></td>
<td><A ID='IMG_3783.JPG' href='blowingbubbles.php?fileId=IMG_3783.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050701/IMG_3783.JPG' ALT='IMG_3783.JPG'><BR>IMG_3783.JPG<br>49.83 KB</a><div class='inv'><br><a href='./images/20050701/IMG_3783.JPG' ALT='IMG_3783.JPG'>IMG_3783.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_3786.JPG' href='blowingbubbles.php?fileId=IMG_3786.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050701/IMG_3786.JPG' ALT='IMG_3786.JPG'><BR>IMG_3786.JPG<br>62.11 KB</a><div class='inv'><br><a href='./images/20050701/IMG_3786.JPG' ALT='IMG_3786.JPG'>IMG_3786.JPG</a></div></td>
<td><A ID='IMG_3789.JPG' href='blowingbubbles.php?fileId=IMG_3789.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050701/IMG_3789.JPG' ALT='IMG_3789.JPG'><BR>IMG_3789.JPG<br>76.17 KB</a><div class='inv'><br><a href='./images/20050701/IMG_3789.JPG' ALT='IMG_3789.JPG'>IMG_3789.JPG</a></div></td>
<td><A ID='IMG_3790.JPG' href='blowingbubbles.php?fileId=IMG_3790.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050701/IMG_3790.JPG' ALT='IMG_3790.JPG'><BR>IMG_3790.JPG<br>71.44 KB</a><div class='inv'><br><a href='./images/20050701/IMG_3790.JPG' ALT='IMG_3790.JPG'>IMG_3790.JPG</a></div></td>
<td><A ID='IMG_3796.JPG' href='blowingbubbles.php?fileId=IMG_3796.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050701/IMG_3796.JPG' ALT='IMG_3796.JPG'><BR>IMG_3796.JPG<br>60.88 KB</a><div class='inv'><br><a href='./images/20050701/IMG_3796.JPG' ALT='IMG_3796.JPG'>IMG_3796.JPG</a></div></td>
<td><A ID='IMG_3799.JPG' href='blowingbubbles.php?fileId=IMG_3799.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050701/IMG_3799.JPG' ALT='IMG_3799.JPG'><BR>IMG_3799.JPG<br>50.81 KB</a><div class='inv'><br><a href='./images/20050701/IMG_3799.JPG' ALT='IMG_3799.JPG'>IMG_3799.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_3800.JPG' href='blowingbubbles.php?fileId=IMG_3800.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050701/IMG_3800.JPG' ALT='IMG_3800.JPG'><BR>IMG_3800.JPG<br>120.86 KB</a><div class='inv'><br><a href='./images/20050701/IMG_3800.JPG' ALT='IMG_3800.JPG'>IMG_3800.JPG</a></div></td>
<td><A ID='IMG_3801.JPG' href='blowingbubbles.php?fileId=IMG_3801.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050701/IMG_3801.JPG' ALT='IMG_3801.JPG'><BR>IMG_3801.JPG<br>63.37 KB</a><div class='inv'><br><a href='./images/20050701/IMG_3801.JPG' ALT='IMG_3801.JPG'>IMG_3801.JPG</a></div></td>
<td><A ID='IMG_3804.JPG' href='blowingbubbles.php?fileId=IMG_3804.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050701/IMG_3804.JPG' ALT='IMG_3804.JPG'><BR>IMG_3804.JPG<br>33.72 KB</a><div class='inv'><br><a href='./images/20050701/IMG_3804.JPG' ALT='IMG_3804.JPG'>IMG_3804.JPG</a></div></td>
<td><A ID='IMG_3805.JPG' href='blowingbubbles.php?fileId=IMG_3805.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050701/IMG_3805.JPG' ALT='IMG_3805.JPG'><BR>IMG_3805.JPG<br>58.25 KB</a><div class='inv'><br><a href='./images/20050701/IMG_3805.JPG' ALT='IMG_3805.JPG'>IMG_3805.JPG</a></div></td>
<td><A ID='IMG_3806.JPG' href='blowingbubbles.php?fileId=IMG_3806.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050701/IMG_3806.JPG' ALT='IMG_3806.JPG'><BR>IMG_3806.JPG<br>49.5 KB</a><div class='inv'><br><a href='./images/20050701/IMG_3806.JPG' ALT='IMG_3806.JPG'>IMG_3806.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_3808.JPG' href='blowingbubbles.php?fileId=IMG_3808.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050701/IMG_3808.JPG' ALT='IMG_3808.JPG'><BR>IMG_3808.JPG<br>46.43 KB</a><div class='inv'><br><a href='./images/20050701/IMG_3808.JPG' ALT='IMG_3808.JPG'>IMG_3808.JPG</a></div></td>
<td><A ID='IMG_3809.JPG' href='blowingbubbles.php?fileId=IMG_3809.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050701/IMG_3809.JPG' ALT='IMG_3809.JPG'><BR>IMG_3809.JPG<br>74.99 KB</a><div class='inv'><br><a href='./images/20050701/IMG_3809.JPG' ALT='IMG_3809.JPG'>IMG_3809.JPG</a></div></td>
<td><A ID='IMG_3813.JPG' href='blowingbubbles.php?fileId=IMG_3813.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050701/IMG_3813.JPG' ALT='IMG_3813.JPG'><BR>IMG_3813.JPG<br>61.14 KB</a><div class='inv'><br><a href='./images/20050701/IMG_3813.JPG' ALT='IMG_3813.JPG'>IMG_3813.JPG</a></div></td>
<td><A ID='IMG_3815.JPG' href='blowingbubbles.php?fileId=IMG_3815.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050701/IMG_3815.JPG' ALT='IMG_3815.JPG'><BR>IMG_3815.JPG<br>57.29 KB</a><div class='inv'><br><a href='./images/20050701/IMG_3815.JPG' ALT='IMG_3815.JPG'>IMG_3815.JPG</a></div></td>
<td><A ID='IMG_3818.JPG' href='blowingbubbles.php?fileId=IMG_3818.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050701/IMG_3818.JPG' ALT='IMG_3818.JPG'><BR>IMG_3818.JPG<br>64.44 KB</a><div class='inv'><br><a href='./images/20050701/IMG_3818.JPG' ALT='IMG_3818.JPG'>IMG_3818.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_3823.JPG' href='blowingbubbles.php?fileId=IMG_3823.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050701/IMG_3823.JPG' ALT='IMG_3823.JPG'><BR>IMG_3823.JPG<br>66.03 KB</a><div class='inv'><br><a href='./images/20050701/IMG_3823.JPG' ALT='IMG_3823.JPG'>IMG_3823.JPG</a></div></td>
<td><A ID='IMG_3826.JPG' href='blowingbubbles.php?fileId=IMG_3826.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050701/IMG_3826.JPG' ALT='IMG_3826.JPG'><BR>IMG_3826.JPG<br>47.43 KB</a><div class='inv'><br><a href='./images/20050701/IMG_3826.JPG' ALT='IMG_3826.JPG'>IMG_3826.JPG</a></div></td>
<td><A ID='IMG_3827.JPG' href='blowingbubbles.php?fileId=IMG_3827.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050701/IMG_3827.JPG' ALT='IMG_3827.JPG'><BR>IMG_3827.JPG<br>48.39 KB</a><div class='inv'><br><a href='./images/20050701/IMG_3827.JPG' ALT='IMG_3827.JPG'>IMG_3827.JPG</a></div></td>
<td><A ID='IMG_3828.JPG' href='blowingbubbles.php?fileId=IMG_3828.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050701/IMG_3828.JPG' ALT='IMG_3828.JPG'><BR>IMG_3828.JPG<br>25.88 KB</a><div class='inv'><br><a href='./images/20050701/IMG_3828.JPG' ALT='IMG_3828.JPG'>IMG_3828.JPG</a></div></td>
<td><A ID='IMG_3831.JPG' href='blowingbubbles.php?fileId=IMG_3831.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050701/IMG_3831.JPG' ALT='IMG_3831.JPG'><BR>IMG_3831.JPG<br>84.11 KB</a><div class='inv'><br><a href='./images/20050701/IMG_3831.JPG' ALT='IMG_3831.JPG'>IMG_3831.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_3833.JPG' href='blowingbubbles.php?fileId=IMG_3833.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050701/IMG_3833.JPG' ALT='IMG_3833.JPG'><BR>IMG_3833.JPG<br>66.07 KB</a><div class='inv'><br><a href='./images/20050701/IMG_3833.JPG' ALT='IMG_3833.JPG'>IMG_3833.JPG</a></div></td>
<td><A ID='IMG_3834.JPG' href='blowingbubbles.php?fileId=IMG_3834.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050701/IMG_3834.JPG' ALT='IMG_3834.JPG'><BR>IMG_3834.JPG<br>68.89 KB</a><div class='inv'><br><a href='./images/20050701/IMG_3834.JPG' ALT='IMG_3834.JPG'>IMG_3834.JPG</a></div></td>
<td><A ID='IMG_3835.JPG' href='blowingbubbles.php?fileId=IMG_3835.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050701/IMG_3835.JPG' ALT='IMG_3835.JPG'><BR>IMG_3835.JPG<br>41.79 KB</a><div class='inv'><br><a href='./images/20050701/IMG_3835.JPG' ALT='IMG_3835.JPG'>IMG_3835.JPG</a></div></td>
<td><A ID='IMG_3836.JPG' href='blowingbubbles.php?fileId=IMG_3836.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050701/IMG_3836.JPG' ALT='IMG_3836.JPG'><BR>IMG_3836.JPG<br>55.98 KB</a><div class='inv'><br><a href='./images/20050701/IMG_3836.JPG' ALT='IMG_3836.JPG'>IMG_3836.JPG</a></div></td>
<td><A ID='IMG_3839.JPG' href='blowingbubbles.php?fileId=IMG_3839.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050701/IMG_3839.JPG' ALT='IMG_3839.JPG'><BR>IMG_3839.JPG<br>83.1 KB</a><div class='inv'><br><a href='./images/20050701/IMG_3839.JPG' ALT='IMG_3839.JPG'>IMG_3839.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_3840.JPG' href='blowingbubbles.php?fileId=IMG_3840.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050701/IMG_3840.JPG' ALT='IMG_3840.JPG'><BR>IMG_3840.JPG<br>53.67 KB</a><div class='inv'><br><a href='./images/20050701/IMG_3840.JPG' ALT='IMG_3840.JPG'>IMG_3840.JPG</a></div></td>
<td><A ID='IMG_3843.JPG' href='blowingbubbles.php?fileId=IMG_3843.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050701/IMG_3843.JPG' ALT='IMG_3843.JPG'><BR>IMG_3843.JPG<br>89.57 KB</a><div class='inv'><br><a href='./images/20050701/IMG_3843.JPG' ALT='IMG_3843.JPG'>IMG_3843.JPG</a></div></td>
<td><A ID='IMG_3852.JPG' href='blowingbubbles.php?fileId=IMG_3852.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050701/IMG_3852.JPG' ALT='IMG_3852.JPG'><BR>IMG_3852.JPG<br>46.37 KB</a><div class='inv'><br><a href='./images/20050701/IMG_3852.JPG' ALT='IMG_3852.JPG'>IMG_3852.JPG</a></div></td>
<td><A ID='IMG_3857.JPG' href='blowingbubbles.php?fileId=IMG_3857.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050701/IMG_3857.JPG' ALT='IMG_3857.JPG'><BR>IMG_3857.JPG<br>57.16 KB</a><div class='inv'><br><a href='./images/20050701/IMG_3857.JPG' ALT='IMG_3857.JPG'>IMG_3857.JPG</a></div></td>
<td><A ID='IMG_3858.JPG' href='blowingbubbles.php?fileId=IMG_3858.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050701/IMG_3858.JPG' ALT='IMG_3858.JPG'><BR>IMG_3858.JPG<br>55.46 KB</a><div class='inv'><br><a href='./images/20050701/IMG_3858.JPG' ALT='IMG_3858.JPG'>IMG_3858.JPG</a></div></td>
</tr>
<tr><td><A ID='Jarod_P6300001.JPG' href='blowingbubbles.php?fileId=Jarod_P6300001.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050701/Jarod_P6300001.JPG' ALT='OLYMPUS DIGITAL CAMERA         '><BR>OLYMPUS DIGITAL CAMERA         <br>66.51 KB</a><div class='inv'><br><a href='./images/20050701/Jarod_P6300001.JPG' ALT='OLYMPUS DIGITAL CAMERA         '>OLYMPUS DIGITAL CAMERA         </a></div></td>
<td><A ID='Jarod_P6300002.JPG' href='blowingbubbles.php?fileId=Jarod_P6300002.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050701/Jarod_P6300002.JPG' ALT='OLYMPUS DIGITAL CAMERA         '><BR>OLYMPUS DIGITAL CAMERA         <br>54.13 KB</a><div class='inv'><br><a href='./images/20050701/Jarod_P6300002.JPG' ALT='OLYMPUS DIGITAL CAMERA         '>OLYMPUS DIGITAL CAMERA         </a></div></td>
<td><A ID='Jarod_P6300005.JPG' href='blowingbubbles.php?fileId=Jarod_P6300005.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050701/Jarod_P6300005.JPG' ALT='OLYMPUS DIGITAL CAMERA         '><BR>OLYMPUS DIGITAL CAMERA         <br>104.5 KB</a><div class='inv'><br><a href='./images/20050701/Jarod_P6300005.JPG' ALT='OLYMPUS DIGITAL CAMERA         '>OLYMPUS DIGITAL CAMERA         </a></div></td>
<td><A ID='Jarod_P6300008.JPG' href='blowingbubbles.php?fileId=Jarod_P6300008.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050701/Jarod_P6300008.JPG' ALT='OLYMPUS DIGITAL CAMERA         '><BR>OLYMPUS DIGITAL CAMERA         <br>91.71 KB</a><div class='inv'><br><a href='./images/20050701/Jarod_P6300008.JPG' ALT='OLYMPUS DIGITAL CAMERA         '>OLYMPUS DIGITAL CAMERA         </a></div></td>
<td><A ID='Jarod_P6300009.JPG' href='blowingbubbles.php?fileId=Jarod_P6300009.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050701/Jarod_P6300009.JPG' ALT='OLYMPUS DIGITAL CAMERA         '><BR>OLYMPUS DIGITAL CAMERA         <br>85.87 KB</a><div class='inv'><br><a href='./images/20050701/Jarod_P6300009.JPG' ALT='OLYMPUS DIGITAL CAMERA         '>OLYMPUS DIGITAL CAMERA         </a></div></td>
</tr>
<tr><td><A ID='Jarod_P6300010.JPG' href='blowingbubbles.php?fileId=Jarod_P6300010.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050701/Jarod_P6300010.JPG' ALT='OLYMPUS DIGITAL CAMERA         '><BR>OLYMPUS DIGITAL CAMERA         <br>38.97 KB</a><div class='inv'><br><a href='./images/20050701/Jarod_P6300010.JPG' ALT='OLYMPUS DIGITAL CAMERA         '>OLYMPUS DIGITAL CAMERA         </a></div></td>
<td><A ID='Jarod_P6300011.JPG' href='blowingbubbles.php?fileId=Jarod_P6300011.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050701/Jarod_P6300011.JPG' ALT='OLYMPUS DIGITAL CAMERA         '><BR>OLYMPUS DIGITAL CAMERA         <br>41.54 KB</a><div class='inv'><br><a href='./images/20050701/Jarod_P6300011.JPG' ALT='OLYMPUS DIGITAL CAMERA         '>OLYMPUS DIGITAL CAMERA         </a></div></td>
<td><A ID='Jarod_P6300023.JPG' href='blowingbubbles.php?fileId=Jarod_P6300023.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050701/Jarod_P6300023.JPG' ALT='OLYMPUS DIGITAL CAMERA         '><BR>OLYMPUS DIGITAL CAMERA         <br>54.64 KB</a><div class='inv'><br><a href='./images/20050701/Jarod_P6300023.JPG' ALT='OLYMPUS DIGITAL CAMERA         '>OLYMPUS DIGITAL CAMERA         </a></div></td>
<td><A ID='Jarod_P6300033.JPG' href='blowingbubbles.php?fileId=Jarod_P6300033.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050701/Jarod_P6300033.JPG' ALT='OLYMPUS DIGITAL CAMERA         '><BR>OLYMPUS DIGITAL CAMERA         <br>64.04 KB</a><div class='inv'><br><a href='./images/20050701/Jarod_P6300033.JPG' ALT='OLYMPUS DIGITAL CAMERA         '>OLYMPUS DIGITAL CAMERA         </a></div></td>
<td><A ID='Jarod_P6300035.JPG' href='blowingbubbles.php?fileId=Jarod_P6300035.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050701/Jarod_P6300035.JPG' ALT='OLYMPUS DIGITAL CAMERA         '><BR>OLYMPUS DIGITAL CAMERA         <br>49.62 KB</a><div class='inv'><br><a href='./images/20050701/Jarod_P6300035.JPG' ALT='OLYMPUS DIGITAL CAMERA         '>OLYMPUS DIGITAL CAMERA         </a></div></td>
</tr>
<tr><td><A ID='Jarod_P6300043.JPG' href='blowingbubbles.php?fileId=Jarod_P6300043.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050701/Jarod_P6300043.JPG' ALT='OLYMPUS DIGITAL CAMERA         '><BR>OLYMPUS DIGITAL CAMERA         <br>73.31 KB</a><div class='inv'><br><a href='./images/20050701/Jarod_P6300043.JPG' ALT='OLYMPUS DIGITAL CAMERA         '>OLYMPUS DIGITAL CAMERA         </a></div></td>
<td><A ID='Jarod_P6300049.JPG' href='blowingbubbles.php?fileId=Jarod_P6300049.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050701/Jarod_P6300049.JPG' ALT='OLYMPUS DIGITAL CAMERA         '><BR>OLYMPUS DIGITAL CAMERA         <br>82.88 KB</a><div class='inv'><br><a href='./images/20050701/Jarod_P6300049.JPG' ALT='OLYMPUS DIGITAL CAMERA         '>OLYMPUS DIGITAL CAMERA         </a></div></td>
<td><A ID='Jarod_P6300051.JPG' href='blowingbubbles.php?fileId=Jarod_P6300051.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050701/Jarod_P6300051.JPG' ALT='OLYMPUS DIGITAL CAMERA         '><BR>OLYMPUS DIGITAL CAMERA         <br>79.24 KB</a><div class='inv'><br><a href='./images/20050701/Jarod_P6300051.JPG' ALT='OLYMPUS DIGITAL CAMERA         '>OLYMPUS DIGITAL CAMERA         </a></div></td>
<td><A ID='Jarod_P6300055.JPG' href='blowingbubbles.php?fileId=Jarod_P6300055.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050701/Jarod_P6300055.JPG' ALT='OLYMPUS DIGITAL CAMERA         '><BR>OLYMPUS DIGITAL CAMERA         <br>98.89 KB</a><div class='inv'><br><a href='./images/20050701/Jarod_P6300055.JPG' ALT='OLYMPUS DIGITAL CAMERA         '>OLYMPUS DIGITAL CAMERA         </a></div></td>
<td><A ID='Jarod_P6300059.JPG' href='blowingbubbles.php?fileId=Jarod_P6300059.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050701/Jarod_P6300059.JPG' ALT='OLYMPUS DIGITAL CAMERA         '><BR>OLYMPUS DIGITAL CAMERA         <br>99.14 KB</a><div class='inv'><br><a href='./images/20050701/Jarod_P6300059.JPG' ALT='OLYMPUS DIGITAL CAMERA         '>OLYMPUS DIGITAL CAMERA         </a></div></td>
</tr>
<tr><td><A ID='Jarod_P6300063.JPG' href='blowingbubbles.php?fileId=Jarod_P6300063.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050701/Jarod_P6300063.JPG' ALT='OLYMPUS DIGITAL CAMERA         '><BR>OLYMPUS DIGITAL CAMERA         <br>77.71 KB</a><div class='inv'><br><a href='./images/20050701/Jarod_P6300063.JPG' ALT='OLYMPUS DIGITAL CAMERA         '>OLYMPUS DIGITAL CAMERA         </a></div></td>
<td><A ID='Jarod_P6300064.JPG' href='blowingbubbles.php?fileId=Jarod_P6300064.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050701/Jarod_P6300064.JPG' ALT='OLYMPUS DIGITAL CAMERA         '><BR>OLYMPUS DIGITAL CAMERA         <br>80.79 KB</a><div class='inv'><br><a href='./images/20050701/Jarod_P6300064.JPG' ALT='OLYMPUS DIGITAL CAMERA         '>OLYMPUS DIGITAL CAMERA         </a></div></td>
<td><A ID='Jarod_P6300065.JPG' href='blowingbubbles.php?fileId=Jarod_P6300065.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050701/Jarod_P6300065.JPG' ALT='OLYMPUS DIGITAL CAMERA         '><BR>OLYMPUS DIGITAL CAMERA         <br>43.44 KB</a><div class='inv'><br><a href='./images/20050701/Jarod_P6300065.JPG' ALT='OLYMPUS DIGITAL CAMERA         '>OLYMPUS DIGITAL CAMERA         </a></div></td>
<td><A ID='Jarod_P6300066.JPG' href='blowingbubbles.php?fileId=Jarod_P6300066.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050701/Jarod_P6300066.JPG' ALT='OLYMPUS DIGITAL CAMERA         '><BR>OLYMPUS DIGITAL CAMERA         <br>75.31 KB</a><div class='inv'><br><a href='./images/20050701/Jarod_P6300066.JPG' ALT='OLYMPUS DIGITAL CAMERA         '>OLYMPUS DIGITAL CAMERA         </a></div></td>
<td><A ID='Jarod_P6300067.JPG' href='blowingbubbles.php?fileId=Jarod_P6300067.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050701/Jarod_P6300067.JPG' ALT='OLYMPUS DIGITAL CAMERA         '><BR>OLYMPUS DIGITAL CAMERA         <br>82.16 KB</a><div class='inv'><br><a href='./images/20050701/Jarod_P6300067.JPG' ALT='OLYMPUS DIGITAL CAMERA         '>OLYMPUS DIGITAL CAMERA         </a></div></td>
</tr>
<tr><td><A ID='Jarod_P6300071.JPG' href='blowingbubbles.php?fileId=Jarod_P6300071.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050701/Jarod_P6300071.JPG' ALT='OLYMPUS DIGITAL CAMERA         '><BR>OLYMPUS DIGITAL CAMERA         <br>99.45 KB</a><div class='inv'><br><a href='./images/20050701/Jarod_P6300071.JPG' ALT='OLYMPUS DIGITAL CAMERA         '>OLYMPUS DIGITAL CAMERA         </a></div></td>
<td><A ID='Jarod_P6300077.JPG' href='blowingbubbles.php?fileId=Jarod_P6300077.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050701/Jarod_P6300077.JPG' ALT='OLYMPUS DIGITAL CAMERA         '><BR>OLYMPUS DIGITAL CAMERA         <br>31.59 KB</a><div class='inv'><br><a href='./images/20050701/Jarod_P6300077.JPG' ALT='OLYMPUS DIGITAL CAMERA         '>OLYMPUS DIGITAL CAMERA         </a></div></td>
<td><A ID='Jarod_P6300081.JPG' href='blowingbubbles.php?fileId=Jarod_P6300081.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050701/Jarod_P6300081.JPG' ALT='OLYMPUS DIGITAL CAMERA         '><BR>OLYMPUS DIGITAL CAMERA         <br>114.13 KB</a><div class='inv'><br><a href='./images/20050701/Jarod_P6300081.JPG' ALT='OLYMPUS DIGITAL CAMERA         '>OLYMPUS DIGITAL CAMERA         </a></div></td>
<td><A ID='Jarod_P6300087.JPG' href='blowingbubbles.php?fileId=Jarod_P6300087.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050701/Jarod_P6300087.JPG' ALT='OLYMPUS DIGITAL CAMERA         '><BR>OLYMPUS DIGITAL CAMERA         <br>92.6 KB</a><div class='inv'><br><a href='./images/20050701/Jarod_P6300087.JPG' ALT='OLYMPUS DIGITAL CAMERA         '>OLYMPUS DIGITAL CAMERA         </a></div></td>
<td><A ID='Mark_DSC03675.JPG' href='blowingbubbles.php?fileId=Mark_DSC03675.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050701/Mark_DSC03675.JPG' ALT='                               '><BR>                               <br>43.2 KB</a><div class='inv'><br><a href='./images/20050701/Mark_DSC03675.JPG' ALT='                               '>                               </a></div></td>
</tr>
<tr><td><A ID='Mark_DSC03678.JPG' href='blowingbubbles.php?fileId=Mark_DSC03678.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050701/Mark_DSC03678.JPG' ALT='                               '><BR>                               <br>35.65 KB</a><div class='inv'><br><a href='./images/20050701/Mark_DSC03678.JPG' ALT='                               '>                               </a></div></td>
<td><A ID='Mark_DSC03679.JPG' href='blowingbubbles.php?fileId=Mark_DSC03679.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050701/Mark_DSC03679.JPG' ALT='                               '><BR>                               <br>37 KB</a><div class='inv'><br><a href='./images/20050701/Mark_DSC03679.JPG' ALT='                               '>                               </a></div></td>
<td><A ID='Mark_DSC03680.JPG' href='blowingbubbles.php?fileId=Mark_DSC03680.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050701/Mark_DSC03680.JPG' ALT='                               '><BR>                               <br>44.13 KB</a><div class='inv'><br><a href='./images/20050701/Mark_DSC03680.JPG' ALT='                               '>                               </a></div></td>
<td><A ID='Mark_DSC03683.JPG' href='blowingbubbles.php?fileId=Mark_DSC03683.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050701/Mark_DSC03683.JPG' ALT='                               '><BR>                               <br>62.36 KB</a><div class='inv'><br><a href='./images/20050701/Mark_DSC03683.JPG' ALT='                               '>                               </a></div></td>
<td><A ID='Mark_DSC03684.JPG' href='blowingbubbles.php?fileId=Mark_DSC03684.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050701/Mark_DSC03684.JPG' ALT='                               '><BR>                               <br>83.36 KB</a><div class='inv'><br><a href='./images/20050701/Mark_DSC03684.JPG' ALT='                               '>                               </a></div></td>
</tr>
<tr><td><A ID='Mark_DSC03685.JPG' href='blowingbubbles.php?fileId=Mark_DSC03685.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050701/Mark_DSC03685.JPG' ALT='                               '><BR>                               <br>48.08 KB</a><div class='inv'><br><a href='./images/20050701/Mark_DSC03685.JPG' ALT='                               '>                               </a></div></td>
<td><A ID='Mark_DSC03687.JPG' href='blowingbubbles.php?fileId=Mark_DSC03687.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050701/Mark_DSC03687.JPG' ALT='                               '><BR>                               <br>25.26 KB</a><div class='inv'><br><a href='./images/20050701/Mark_DSC03687.JPG' ALT='                               '>                               </a></div></td>
<td><A ID='Mark_DSC03688.JPG' href='blowingbubbles.php?fileId=Mark_DSC03688.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050701/Mark_DSC03688.JPG' ALT='                               '><BR>                               <br>23.7 KB</a><div class='inv'><br><a href='./images/20050701/Mark_DSC03688.JPG' ALT='                               '>                               </a></div></td>
<td><A ID='Mark_DSC03689.JPG' href='blowingbubbles.php?fileId=Mark_DSC03689.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050701/Mark_DSC03689.JPG' ALT='                               '><BR>                               <br>32.47 KB</a><div class='inv'><br><a href='./images/20050701/Mark_DSC03689.JPG' ALT='                               '>                               </a></div></td>
<td><A ID='Mark_DSC03692.JPG' href='blowingbubbles.php?fileId=Mark_DSC03692.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050701/Mark_DSC03692.JPG' ALT='                               '><BR>                               <br>39.38 KB</a><div class='inv'><br><a href='./images/20050701/Mark_DSC03692.JPG' ALT='                               '>                               </a></div></td>
</tr>
<tr><td><A ID='Mark_DSC03694.JPG' href='blowingbubbles.php?fileId=Mark_DSC03694.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050701/Mark_DSC03694.JPG' ALT='                               '><BR>                               <br>59.09 KB</a><div class='inv'><br><a href='./images/20050701/Mark_DSC03694.JPG' ALT='                               '>                               </a></div></td>
<td><A ID='Mark_DSC03695.JPG' href='blowingbubbles.php?fileId=Mark_DSC03695.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050701/Mark_DSC03695.JPG' ALT='                               '><BR>                               <br>55.28 KB</a><div class='inv'><br><a href='./images/20050701/Mark_DSC03695.JPG' ALT='                               '>                               </a></div></td>
<td><A ID='Mark_DSC03698.JPG' href='blowingbubbles.php?fileId=Mark_DSC03698.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050701/Mark_DSC03698.JPG' ALT='                               '><BR>                               <br>27.43 KB</a><div class='inv'><br><a href='./images/20050701/Mark_DSC03698.JPG' ALT='                               '>                               </a></div></td>
<td><A ID='Mark_DSC03701.JPG' href='blowingbubbles.php?fileId=Mark_DSC03701.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050701/Mark_DSC03701.JPG' ALT='                               '><BR>                               <br>39.42 KB</a><div class='inv'><br><a href='./images/20050701/Mark_DSC03701.JPG' ALT='                               '>                               </a></div></td>
<td><A ID='Mark_DSC03702.JPG' href='blowingbubbles.php?fileId=Mark_DSC03702.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050701/Mark_DSC03702.JPG' ALT='                               '><BR>                               <br>32.64 KB</a><div class='inv'><br><a href='./images/20050701/Mark_DSC03702.JPG' ALT='                               '>                               </a></div></td>
</tr>
<tr><td><A ID='Mark_DSC03705.JPG' href='blowingbubbles.php?fileId=Mark_DSC03705.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050701/Mark_DSC03705.JPG' ALT='                               '><BR>                               <br>67.14 KB</a><div class='inv'><br><a href='./images/20050701/Mark_DSC03705.JPG' ALT='                               '>                               </a></div></td>
<td><A ID='Mark_DSC03706.JPG' href='blowingbubbles.php?fileId=Mark_DSC03706.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050701/Mark_DSC03706.JPG' ALT='                               '><BR>                               <br>53.45 KB</a><div class='inv'><br><a href='./images/20050701/Mark_DSC03706.JPG' ALT='                               '>                               </a></div></td>
<td><A ID='Mark_DSC03708.JPG' href='blowingbubbles.php?fileId=Mark_DSC03708.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050701/Mark_DSC03708.JPG' ALT='                               '><BR>                               <br>59.98 KB</a><div class='inv'><br><a href='./images/20050701/Mark_DSC03708.JPG' ALT='                               '>                               </a></div></td>
<td><A ID='Mark_DSC03709.JPG' href='blowingbubbles.php?fileId=Mark_DSC03709.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050701/Mark_DSC03709.JPG' ALT='                               '><BR>                               <br>49.04 KB</a><div class='inv'><br><a href='./images/20050701/Mark_DSC03709.JPG' ALT='                               '>                               </a></div></td>
<td><A ID='Mark_DSC03710.JPG' href='blowingbubbles.php?fileId=Mark_DSC03710.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050701/Mark_DSC03710.JPG' ALT='                               '><BR>                               <br>38.46 KB</a><div class='inv'><br><a href='./images/20050701/Mark_DSC03710.JPG' ALT='                               '>                               </a></div></td>
</tr>
<tr><td><A ID='Mark_DSC03711.JPG' href='blowingbubbles.php?fileId=Mark_DSC03711.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050701/Mark_DSC03711.JPG' ALT='                               '><BR>                               <br>56.59 KB</a><div class='inv'><br><a href='./images/20050701/Mark_DSC03711.JPG' ALT='                               '>                               </a></div></td>
<td><A ID='Mark_DSC03718.JPG' href='blowingbubbles.php?fileId=Mark_DSC03718.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050701/Mark_DSC03718.JPG' ALT='                               '><BR>                               <br>60.42 KB</a><div class='inv'><br><a href='./images/20050701/Mark_DSC03718.JPG' ALT='                               '>                               </a></div></td>
<td><A ID='Mark_DSC03719.JPG' href='blowingbubbles.php?fileId=Mark_DSC03719.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050701/Mark_DSC03719.JPG' ALT='                               '><BR>                               <br>53.17 KB</a><div class='inv'><br><a href='./images/20050701/Mark_DSC03719.JPG' ALT='                               '>                               </a></div></td>
<td><A ID='Mark_DSC03720.JPG' href='blowingbubbles.php?fileId=Mark_DSC03720.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050701/Mark_DSC03720.JPG' ALT='                               '><BR>                               <br>64.74 KB</a><div class='inv'><br><a href='./images/20050701/Mark_DSC03720.JPG' ALT='                               '>                               </a></div></td>
<td><A ID='Mark_DSC03721.JPG' href='blowingbubbles.php?fileId=Mark_DSC03721.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050701/Mark_DSC03721.JPG' ALT='                               '><BR>                               <br>59.89 KB</a><div class='inv'><br><a href='./images/20050701/Mark_DSC03721.JPG' ALT='                               '>                               </a></div></td>
</tr>
<tr><td><A ID='Mark_DSC03722.JPG' href='blowingbubbles.php?fileId=Mark_DSC03722.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050701/Mark_DSC03722.JPG' ALT='                               '><BR>                               <br>47.21 KB</a><div class='inv'><br><a href='./images/20050701/Mark_DSC03722.JPG' ALT='                               '>                               </a></div></td>
<td><A ID='Mark_DSC03724.JPG' href='blowingbubbles.php?fileId=Mark_DSC03724.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050701/Mark_DSC03724.JPG' ALT='                               '><BR>                               <br>35.82 KB</a><div class='inv'><br><a href='./images/20050701/Mark_DSC03724.JPG' ALT='                               '>                               </a></div></td>
<td><A ID='Mark_DSC03728.JPG' href='blowingbubbles.php?fileId=Mark_DSC03728.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050701/Mark_DSC03728.JPG' ALT='                               '><BR>                               <br>40.95 KB</a><div class='inv'><br><a href='./images/20050701/Mark_DSC03728.JPG' ALT='                               '>                               </a></div></td>
<td><A ID='Mark_DSC03741.JPG' href='blowingbubbles.php?fileId=Mark_DSC03741.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050701/Mark_DSC03741.JPG' ALT='                               '><BR>                               <br>31.38 KB</a><div class='inv'><br><a href='./images/20050701/Mark_DSC03741.JPG' ALT='                               '>                               </a></div></td>
<td><A ID='Mark_DSC03746.JPG' href='blowingbubbles.php?fileId=Mark_DSC03746.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050701/Mark_DSC03746.JPG' ALT='                               '><BR>                               <br>34.88 KB</a><div class='inv'><br><a href='./images/20050701/Mark_DSC03746.JPG' ALT='                               '>                               </a></div></td>
</tr>
<tr><td><A ID='Mark_DSC03748.JPG' href='blowingbubbles.php?fileId=Mark_DSC03748.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050701/Mark_DSC03748.JPG' ALT='                               '><BR>                               <br>20.14 KB</a><div class='inv'><br><a href='./images/20050701/Mark_DSC03748.JPG' ALT='                               '>                               </a></div></td>
<td><A ID='Mark_DSC03749.JPG' href='blowingbubbles.php?fileId=Mark_DSC03749.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050701/Mark_DSC03749.JPG' ALT='                               '><BR>                               <br>43.41 KB</a><div class='inv'><br><a href='./images/20050701/Mark_DSC03749.JPG' ALT='                               '>                               </a></div></td>
<td><A ID='Mark_DSC03750.JPG' href='blowingbubbles.php?fileId=Mark_DSC03750.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050701/Mark_DSC03750.JPG' ALT='                               '><BR>                               <br>20.8 KB</a><div class='inv'><br><a href='./images/20050701/Mark_DSC03750.JPG' ALT='                               '>                               </a></div></td>
<td><A ID='Sebastian_IMG_0001.JPG' href='blowingbubbles.php?fileId=Sebastian_IMG_0001.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050701/Sebastian_IMG_0001.JPG' ALT='Sebastian_IMG_0001.JPG'><BR>Sebastian_IMG_0001.JPG<br>68.08 KB</a><div class='inv'><br><a href='./images/20050701/Sebastian_IMG_0001.JPG' ALT='Sebastian_IMG_0001.JPG'>Sebastian_IMG_0001.JPG</a></div></td>
<td><A ID='Sebastian_IMG_0008.JPG' href='blowingbubbles.php?fileId=Sebastian_IMG_0008.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050701/Sebastian_IMG_0008.JPG' ALT='Sebastian_IMG_0008.JPG'><BR>Sebastian_IMG_0008.JPG<br>50.11 KB</a><div class='inv'><br><a href='./images/20050701/Sebastian_IMG_0008.JPG' ALT='Sebastian_IMG_0008.JPG'>Sebastian_IMG_0008.JPG</a></div></td>
</tr>
<tr><td><A ID='Sebastian_IMG_0040.JPG' href='blowingbubbles.php?fileId=Sebastian_IMG_0040.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050701/Sebastian_IMG_0040.JPG' ALT='Sebastian_IMG_0040.JPG'><BR>Sebastian_IMG_0040.JPG<br>55.6 KB</a><div class='inv'><br><a href='./images/20050701/Sebastian_IMG_0040.JPG' ALT='Sebastian_IMG_0040.JPG'>Sebastian_IMG_0040.JPG</a></div></td>
<td><A ID='Sebastian_IMG_0069.JPG' href='blowingbubbles.php?fileId=Sebastian_IMG_0069.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050701/Sebastian_IMG_0069.JPG' ALT='Sebastian_IMG_0069.JPG'><BR>Sebastian_IMG_0069.JPG<br>78.31 KB</a><div class='inv'><br><a href='./images/20050701/Sebastian_IMG_0069.JPG' ALT='Sebastian_IMG_0069.JPG'>Sebastian_IMG_0069.JPG</a></div></td>
<td><A ID='Sebastian_IMG_0073.JPG' href='blowingbubbles.php?fileId=Sebastian_IMG_0073.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050701/Sebastian_IMG_0073.JPG' ALT='Sebastian_IMG_0073.JPG'><BR>Sebastian_IMG_0073.JPG<br>22.93 KB</a><div class='inv'><br><a href='./images/20050701/Sebastian_IMG_0073.JPG' ALT='Sebastian_IMG_0073.JPG'>Sebastian_IMG_0073.JPG</a></div></td>
<td><A ID='Sebastian_IMG_0080.JPG' href='blowingbubbles.php?fileId=Sebastian_IMG_0080.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050701/Sebastian_IMG_0080.JPG' ALT='Sebastian_IMG_0080.JPG'><BR>Sebastian_IMG_0080.JPG<br>75.85 KB</a><div class='inv'><br><a href='./images/20050701/Sebastian_IMG_0080.JPG' ALT='Sebastian_IMG_0080.JPG'>Sebastian_IMG_0080.JPG</a></div></td>
<td><A ID='Sebastian_IMG_0083.JPG' href='blowingbubbles.php?fileId=Sebastian_IMG_0083.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050701/Sebastian_IMG_0083.JPG' ALT='Sebastian_IMG_0083.JPG'><BR>Sebastian_IMG_0083.JPG<br>76.44 KB</a><div class='inv'><br><a href='./images/20050701/Sebastian_IMG_0083.JPG' ALT='Sebastian_IMG_0083.JPG'>Sebastian_IMG_0083.JPG</a></div></td>
</tr>
<tr><td><A ID='Sebastian_IMG_0087.JPG' href='blowingbubbles.php?fileId=Sebastian_IMG_0087.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050701/Sebastian_IMG_0087.JPG' ALT='Sebastian_IMG_0087.JPG'><BR>Sebastian_IMG_0087.JPG<br>74.38 KB</a><div class='inv'><br><a href='./images/20050701/Sebastian_IMG_0087.JPG' ALT='Sebastian_IMG_0087.JPG'>Sebastian_IMG_0087.JPG</a></div></td>
<td><A ID='Sebastian_IMG_0092.JPG' href='blowingbubbles.php?fileId=Sebastian_IMG_0092.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050701/Sebastian_IMG_0092.JPG' ALT='Sebastian_IMG_0092.JPG'><BR>Sebastian_IMG_0092.JPG<br>66.51 KB</a><div class='inv'><br><a href='./images/20050701/Sebastian_IMG_0092.JPG' ALT='Sebastian_IMG_0092.JPG'>Sebastian_IMG_0092.JPG</a></div></td>
<td><A ID='Sebastian_IMG_0136.JPG' href='blowingbubbles.php?fileId=Sebastian_IMG_0136.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050701/Sebastian_IMG_0136.JPG' ALT='Sebastian_IMG_0136.JPG'><BR>Sebastian_IMG_0136.JPG<br>96.93 KB</a><div class='inv'><br><a href='./images/20050701/Sebastian_IMG_0136.JPG' ALT='Sebastian_IMG_0136.JPG'>Sebastian_IMG_0136.JPG</a></div></td>
<td><A ID='Sebastian_IMG_0144.JPG' href='blowingbubbles.php?fileId=Sebastian_IMG_0144.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050701/Sebastian_IMG_0144.JPG' ALT='Sebastian_IMG_0144.JPG'><BR>Sebastian_IMG_0144.JPG<br>69.78 KB</a><div class='inv'><br><a href='./images/20050701/Sebastian_IMG_0144.JPG' ALT='Sebastian_IMG_0144.JPG'>Sebastian_IMG_0144.JPG</a></div></td>
</tr>
</table>	</div>
</div>
</body>
</html>