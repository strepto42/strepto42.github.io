<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - 10/9/2005 - Go West</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="Go West">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="Greetings from a Bum" href='greetingsfromabum.php'>29/4/2005</a></li>
<li><a title="Onward" href='onward.php'>2/5/2005</a></li>
<li><a title="It's a tough life (pt 1: Bundaberg, Agnes Water and 1770)" href='itsatoughlife1.php'>17/5/2005</a></li>
<li><a title="It's a tough life (pt 2: Rockhampton, Emu Park and Great Keppel Island)" href='itsatoughlife2.php'>23/5/2005</a></li>
<li><a title="There and Back Again - a Yo-yo's Tale" href='thereandbackagain.php'>18/6/2005</a></li>
<li><a title="Platypi and Grey Nomads" href='platypiandgreynomads.php'>24/6/2005</a></li>
<li><a title="Blowing Bubbles in a Watery Tomb" href='blowingbubbles.php'>1/7/2005</a></li>
<li><a title="Pieces of History" href='piecesofhistory.php'>8/7/2005</a></li>
<li><a title="Walks and Waterfalls" href='walksandwaterfalls.php'>15/7/2005</a></li>
<li><a title="Mission to Tribulation" href='missiontotribulation.php'>22/7/2005</a></li>
<li><a title="Levity, Limestone and Lava" href='levitylimestoneandlava.php'>29/7/2005</a></li>
<li><a title="Into the Never Never" href='intothenevernever.php'>5/8/2005</a></li>
<li><a title="Slowing the pace in Darwin" href='slowingthepaceindarwin.php'>12/8/2005</a></li>
<li><a title="Blistering Barnacles and Leaping Lizards" href='leapinglizards.php'>19/8/2005</a></li>
<li><a title="Kakadu and Litchfield" href='kakadu.php'>26/8/2005</a></li>
<li><a title="Legacies of War" href='legaciesofwar.php'>2/9/2005</a></li>
<li><div class='activemenu'>10/9/2005</div></li>
<li><a title="Things from Above" href='thingsfromabove.php'>16/9/2005</a></li>
<li><a title="The West Coast" href='thewestcoast.php'>23/9/2005</a></li>
<li><a title="Reefs and Red Dust" href='reefsandreddust.php'>30/9/2005</a></li>
<li><a title="The Pilbara" href='pilbara.php'>7/10/2005</a></li>
<li><a title="Paradise with a Headwind" href='paradisewithaheadwind.php'>14/10/2005</a></li>
<li><a title="Down the Coral Coast" href='downthecoralcoast.php'>21/10/2005</a></li>
<li><a title="Pinnacles and Pinnipeds" href='pinnaclesandpinnipeds.php'>28/10/2005</a></li>
<li><a title="A week in Perth" href='perth.php'>4/11/2005</a></li>
<li><a title="The Southwest (from Above and Below)" href='thesouthwest.php'>11/11/2005</a></li>
<li><a title="More Heights and Depths" href='moreheightsanddepths.php'>18/11/2005</a></li>
<li><a title="Across the Nullarbor (and a bit beyond)" href='nullarbor.php'>25/11/2005</a></li>
<li><a title="Double Whammy" href='doublewhammy.php'>9/12/2005</a></li>
<li><a title="Two Cities" href='twocities.php'>19/12/2005</a></li>
<li><a title="Tassie - Part 1" href='tassie1.php'>1/1/2006</a></li>
<li><a title="Tassie - Part 2" href='tassie2.php'>7/1/2006</a></li>
<li><a title="Full Circle" href='fullcircle.php'>26/1/2006</a></li>
<li><a title="The Wrap Up" href='thewrapup.php'>23/3/2006</a></li>
<li> </li><br><li>Or go back to:</li><li><a title='Travelouges and blogs from my trip around Australia' href="nerdseyeview.php">Nerd's Eye View</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>10/9/2005</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Travel stories and pictures' href="travel.php">Travelogues</a> > <a title='Travelouges and blogs from my trip around Australia' href="nerdseyeview.php">Nerd's Eye View</a> > <a title='Go West' href="gowest.php">10/9/2005</a>
<br><br>		


<h1>Go West</h1>

<a href="images/maps/Map050910.gif"><img src="images/maps/Map050910_sm.gif" align="right"></a>

<p>(life is peaceful there). So the song goes, and it certainly seems to work for WA thus far.</p>

<p>So, it's another week. Pretend it's Friday if you like, even though I'm a day late.</p>

<p>As the title suggests, I've moved on, and as I write I'm in Kununurra, in the NW Kimberley. It's a balmy 35-40 today I'd say. Hopefully the sweat won't seep into my laptop as I type and fry it.</p>

<p>Rewinding back to last week, I spent a few more days at the hostel in Darwin, partially to catch up with Inse, the German girl who whipped my arse playing chess back in Mission Beach, and partially to be hanging around good company in general for my birthday on the Saturday. Go on, start with the late "happy birthday" messages. They will be accepted, and I won't even press the guilt trip, if they're accompanied by sizable cash donations. :)</p>

<p>Actually, it's fine, and those of you who know me well will know that I really don't care about birthdays (even other peoples! ;)). For me, it's just another excuse to play some music and drink some wine, and that's just what I did. We ended the night jamming with a fantastic blues harmonica player, who'd been playing for 14 years. Inse and her friend Catherine even bought me a cake! :)</p>

<p>Before leaving Darwin, I also payed one more visit to the Mindil Beach markets, and watched another killer sunset, heard some great music (from a drum and Didgeridoo band called Em Dee), and had a good feed.</p>

<p>Then it was time to move on. I drove to Katherine on Monday, accompanied by an Austrian guy called Martin that I had met at the backpackers in Darwin. He was most appreciative of my music collection, and we had a good return to our metal roots when he discovered the Iron Maiden.</p>

<p>On the way we stopped off briefly at Edith Falls (which is a lovely spot), then moved on to the backpackers in Katherine, which is one of the most chilled and noise-tolerant backpackers I've stayed at.</p>

<p>The guy running the place remembered me from my one night stay a month or so before, and practically insisted I play guitar all night. What could I do but comply? </p>

<p>After the second night of music, featuring some very drunk and loud Irish girls (who, admittedly, could sing really well), I think he may have been rethinking his request, although in fairness, most of the noise that night came from a random local guy having a domestic with his missus. Apparently he'd stolen all her clothes or something. There was an extended tearful exchange at about 3am, with him inside the paddy wagon, and her out. I have no idea if she was clothed at this stage.</p>

<p>Anyway the stay was nice, albeit brief. Martin and I spent the day doing a cruise up Katherine Gorge in Nitmiluk national park. We both expected it to be amusingly daggy (although I had to explain daggy to Martin, he understood the concept when I put it as "not cool"), and indeed it was.</p>

<p>It was mainly a boat full of older folks, bless 'em; I think we were the youngest there. The guide stressed that the "highly strenuous" 200m walk between gorges was optional, and not to do it if anyone was worried about having a heart attack, or had just had a hip replacement (and that last one is an actual quote).</p>

<p>Anyway it sounds like I'm being mean, but it was quite funny at the time. There was also quite a lot of groanworthy humour from our guide, but the place is amazingly beautiful.</p>

<p>After that, it was finally time to head to a new state, and I swapped Martin (who had to go back to Darwin) for a French guy called Jean, and headed off for Kununurra.</p>

<p>The drive from Katherine to Kununurra is really lovely, and one of the most picturesque to date on my trip. We stopped quite a few times, and Jean got to see his first croc, which was sitting in the Victoria River just under the bridge. It's hard to tell from the pic, but I think it might even be a freshwater croc (they have a longer nose and are generally cuter).</p>

<p>We made it across the WA border and into town just on sunset. I was going to have a rest day or two, but as things turned out, there was a tour of the Bungle Bungle Range in Purnululu National Park leaving the next morning (at 6am!), and I decided it was worthwhile getting up and doing it.</p>

<p>The Bungle Bungle (note without an "s", just like "The Kimberley") is an amazingly beautiful part of the world. I hadn't decided exactly what I was going to do about it though, as I'd heard it was 4WD only territory, and very rough going to get in, hence the decision to go on an organised tour. </p>

<p>As it turned out, the road has been recently upgraded, and I could well have driven it myself, but I'm glad I did a tour this time, as the group was small (and was composed of nice people), and the guide (a chap by the name of Kenton) was really knowledgeable. Plus, it meant that I didn't have to worry about wear and tear on the car, or food for that matter.</p>

<p>So off we headed at the crack of dawn, first down the highway for a few hours, stopping off at a few interesting spots, and then it was onto the dirt track for another hour and a half or so of bone-jarring corrugations.</p>

<p>Once we arrived, we set up camp, had lunch, and then headed to a spot called Echidna Chasm. Everone went snap-happy as we started walking in, and Kenton was rolling his eyes a bit. But it was out first close up view of this amazing place; the reds with blue sky background are fantastic.</p>

<p>We pushed on, and into the gorge, which goes for a rather long way, and gets pretty narrow at the end.</p>

<p>The rock in this part of the range is mostly conglomerate (lots of rocks cemented together basically), and the gorge is formed by water erosion during the wet season.</p>

<p>We also spotted a bower bird, with bower. I got a snap of the latter, but not the former, as it buggered off fairly quickly. Such is the problem with groups I suppose, but it's a trade-off.</p>

<p>After that we headed back via another nice spot called Froghole Gorge. More of the same really, but also very lovely.</p>

<p>From there, we headed back to camp, and climbed up a small limestone ridge for sunset. Unfortunately there were clouds, so we didn't get quite the spectacular view of the range that we could have, but that's life. It was still really quite lovely.</p>

<p>We then had dinner, and managed to get to bed quite early, with the intention of an early start to avoid some of the heat of the day.</p>

<p>All went well until it started raining just as I was drifting off under the stars (well, the clouds as it turned out...). It wasn't heavy rain though, and it didn't last for long, so before long we were all dead to the world. I did wake up at one point during the night, and the stars had come out, and it was indeed amazing.</p>

<p>The next day, as promised, we all got up at quarter-to-sparrowfart and packed up, had brekkie, and got on the road not long after 6.</p>

<p>After another 30kms of dirt or so, we got to our destination - the famous "beehive domes" in the southern part of the park.</p>

<p>In this area, the conglomerate rock has given way to sandstone, but it's a very fine sandstone, which is held together only by pressure, rather than being cemented together (like most sandstone that you might find).</p>

<p>This makes it very susceptible to erosion, but protective layers form on the surface, which slows the process.</p>

<p>The cool thing is that the sandstone has been deposited there in layers. Some layers have a higher clay content, which means it retains water long enough to support the growth of cyanobacteria. This primitive life form is what gives rocks that black colour under waterfalls etc. It goes grey when it's dry and inactive.</p>

<p>Other layers of the sandstone haven't got the bacteria, but instead they are high in iron oxides, and so you get an orange colour. The result, when water erodes the rock unevenly is striped layers of grey and orange, in rounded dome shapes.</p>

<p>The effect is amazing, and the scale of the place is huge, much bigger than I had pictured it.</p>

<p>We went for a long walk to a few nice spots, and saw some Aboriginal art and a couple of Ghost Bats. I also got a few snaps of a Yellow Spotted Tree Frog, including a lovely one of its yellow spotted bum.</p>

<p>Then we walked to an amazing spot called Cathedral Gorge, where we had lunch and relaxed for a while during the hottest part of the day (which was easily pushing 40 by then). Kenton played a bit of Didg for us, and the natural resonance of the place made it sound fantastic. It also shut up all the other tourists who were there nattering away at the time.</p>

<p>And that was that. From there, back to the car, out of the park, and back to Kununurra (with a quick stop off at a roadside grassfire) was a journey of about 6 hours, so we were all pretty knackered by the time we got back; hence the reason I'm writing on Saturday this week. :)</p>

<p>From here I shall be exploring the area nice and slowly. This part of Australia is simply amazing country. There is a real rugged beauty here that I haven't seen matched yet.</p>

<p>Hope you're all well, and I'll look forward to those requests for my bank details. :D</p>

<p>This weeks lovely snaps are:</p>
<!-- 
<ul>
<li><a href="?fileId=IMG_8425.JPG">Katherine Gorge</a></li>
<li><a href="?fileId=IMG_8515.JPG">Pondering the existence of God in Echidna Chasm</a></li>
<li><a href="?fileId=IMG_8599.JPG">The famous Beehive Domes</a></li>
<li><a href="?fileId=IMG_8616.JPG">Beehive dome and a termite mound</a></li>
<li><a href="?fileId=IMG_8646.JPG">Start of the Bungle Bungle Range road (it runs through a cattle station for 40kms)</a></li>
</ul>
 -->
<table width="800">
	<tr>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=IMG_8425.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20050910/IMG_8425.JPG' ALT='Katherine Gorge'><BR>Katherine Gorge</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=IMG_8515.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20050910/IMG_8515.JPG' ALT='Pondering the existence of God in Echidna Chasm'><BR>Pondering the existence of God in Echidna Chasm</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=IMG_8599.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20050910/IMG_8599.JPG' ALT='The famous Beehive Domes'><BR>The famous Beehive Domes</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=IMG_8616.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20050910/IMG_8616.JPG' ALT='Beehive dome and a termite mound'><BR>Beehive dome and a termite mound</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=IMG_8646.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20050910/IMG_8646.JPG' ALT='Start of the Bungle Bungle Range road (it runs through a cattle station for 40kms)'><BR>Start of the Bungle Bungle Range road (it runs through a cattle station for 40kms)</a>
	</td>
	</tr>
</table>

<br><br>
All images in this gallery:<br>
<table width='800'>
<tr>
</tr>
<tr><td><A ID='IMG_8292.JPG' href='gowest.php?fileId=IMG_8292.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050910/IMG_8292.JPG' ALT='IMG_8292.JPG'><BR>IMG_8292.JPG<br>89.57 KB</a><div class='inv'><br><a href='./images/20050910/IMG_8292.JPG' ALT='IMG_8292.JPG'>IMG_8292.JPG</a></div></td>
<td><A ID='IMG_8294.JPG' href='gowest.php?fileId=IMG_8294.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050910/IMG_8294.JPG' ALT='IMG_8294.JPG'><BR>IMG_8294.JPG<br>63.03 KB</a><div class='inv'><br><a href='./images/20050910/IMG_8294.JPG' ALT='IMG_8294.JPG'>IMG_8294.JPG</a></div></td>
<td><A ID='IMG_8295.JPG' href='gowest.php?fileId=IMG_8295.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050910/IMG_8295.JPG' ALT='IMG_8295.JPG'><BR>IMG_8295.JPG<br>50.28 KB</a><div class='inv'><br><a href='./images/20050910/IMG_8295.JPG' ALT='IMG_8295.JPG'>IMG_8295.JPG</a></div></td>
<td><A ID='IMG_8297.JPG' href='gowest.php?fileId=IMG_8297.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050910/IMG_8297.JPG' ALT='IMG_8297.JPG'><BR>IMG_8297.JPG<br>55.27 KB</a><div class='inv'><br><a href='./images/20050910/IMG_8297.JPG' ALT='IMG_8297.JPG'>IMG_8297.JPG</a></div></td>
<td><A ID='IMG_8300.JPG' href='gowest.php?fileId=IMG_8300.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050910/IMG_8300.JPG' ALT='IMG_8300.JPG'><BR>IMG_8300.JPG<br>49.61 KB</a><div class='inv'><br><a href='./images/20050910/IMG_8300.JPG' ALT='IMG_8300.JPG'>IMG_8300.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_8303.JPG' href='gowest.php?fileId=IMG_8303.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050910/IMG_8303.JPG' ALT='IMG_8303.JPG'><BR>IMG_8303.JPG<br>71.8 KB</a><div class='inv'><br><a href='./images/20050910/IMG_8303.JPG' ALT='IMG_8303.JPG'>IMG_8303.JPG</a></div></td>
<td><A ID='IMG_8305.JPG' href='gowest.php?fileId=IMG_8305.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050910/IMG_8305.JPG' ALT='IMG_8305.JPG'><BR>IMG_8305.JPG<br>56.19 KB</a><div class='inv'><br><a href='./images/20050910/IMG_8305.JPG' ALT='IMG_8305.JPG'>IMG_8305.JPG</a></div></td>
<td><A ID='IMG_8314.JPG' href='gowest.php?fileId=IMG_8314.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050910/IMG_8314.JPG' ALT='IMG_8314.JPG'><BR>IMG_8314.JPG<br>82.9 KB</a><div class='inv'><br><a href='./images/20050910/IMG_8314.JPG' ALT='IMG_8314.JPG'>IMG_8314.JPG</a></div></td>
<td><A ID='IMG_8316.JPG' href='gowest.php?fileId=IMG_8316.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050910/IMG_8316.JPG' ALT='IMG_8316.JPG'><BR>IMG_8316.JPG<br>66.18 KB</a><div class='inv'><br><a href='./images/20050910/IMG_8316.JPG' ALT='IMG_8316.JPG'>IMG_8316.JPG</a></div></td>
<td><A ID='IMG_8322.JPG' href='gowest.php?fileId=IMG_8322.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050910/IMG_8322.JPG' ALT='IMG_8322.JPG'><BR>IMG_8322.JPG<br>67.48 KB</a><div class='inv'><br><a href='./images/20050910/IMG_8322.JPG' ALT='IMG_8322.JPG'>IMG_8322.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_8323.JPG' href='gowest.php?fileId=IMG_8323.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050910/IMG_8323.JPG' ALT='IMG_8323.JPG'><BR>IMG_8323.JPG<br>52.44 KB</a><div class='inv'><br><a href='./images/20050910/IMG_8323.JPG' ALT='IMG_8323.JPG'>IMG_8323.JPG</a></div></td>
<td><A ID='IMG_8335.JPG' href='gowest.php?fileId=IMG_8335.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050910/IMG_8335.JPG' ALT='IMG_8335.JPG'><BR>IMG_8335.JPG<br>100.39 KB</a><div class='inv'><br><a href='./images/20050910/IMG_8335.JPG' ALT='IMG_8335.JPG'>IMG_8335.JPG</a></div></td>
<td><A ID='IMG_8336.JPG' href='gowest.php?fileId=IMG_8336.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050910/IMG_8336.JPG' ALT='IMG_8336.JPG'><BR>IMG_8336.JPG<br>134.36 KB</a><div class='inv'><br><a href='./images/20050910/IMG_8336.JPG' ALT='IMG_8336.JPG'>IMG_8336.JPG</a></div></td>
<td><A ID='IMG_8341.JPG' href='gowest.php?fileId=IMG_8341.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050910/IMG_8341.JPG' ALT='IMG_8341.JPG'><BR>IMG_8341.JPG<br>88.71 KB</a><div class='inv'><br><a href='./images/20050910/IMG_8341.JPG' ALT='IMG_8341.JPG'>IMG_8341.JPG</a></div></td>
<td><A ID='IMG_8347.JPG' href='gowest.php?fileId=IMG_8347.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050910/IMG_8347.JPG' ALT='IMG_8347.JPG'><BR>IMG_8347.JPG<br>73.17 KB</a><div class='inv'><br><a href='./images/20050910/IMG_8347.JPG' ALT='IMG_8347.JPG'>IMG_8347.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_8353.JPG' href='gowest.php?fileId=IMG_8353.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050910/IMG_8353.JPG' ALT='IMG_8353.JPG'><BR>IMG_8353.JPG<br>32.94 KB</a><div class='inv'><br><a href='./images/20050910/IMG_8353.JPG' ALT='IMG_8353.JPG'>IMG_8353.JPG</a></div></td>
<td><A ID='IMG_8358.JPG' href='gowest.php?fileId=IMG_8358.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050910/IMG_8358.JPG' ALT='IMG_8358.JPG'><BR>IMG_8358.JPG<br>43.72 KB</a><div class='inv'><br><a href='./images/20050910/IMG_8358.JPG' ALT='IMG_8358.JPG'>IMG_8358.JPG</a></div></td>
<td><A ID='IMG_8359.JPG' href='gowest.php?fileId=IMG_8359.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050910/IMG_8359.JPG' ALT='IMG_8359.JPG'><BR>IMG_8359.JPG<br>32.97 KB</a><div class='inv'><br><a href='./images/20050910/IMG_8359.JPG' ALT='IMG_8359.JPG'>IMG_8359.JPG</a></div></td>
<td><A ID='IMG_8365.JPG' href='gowest.php?fileId=IMG_8365.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050910/IMG_8365.JPG' ALT='IMG_8365.JPG'><BR>IMG_8365.JPG<br>31.02 KB</a><div class='inv'><br><a href='./images/20050910/IMG_8365.JPG' ALT='IMG_8365.JPG'>IMG_8365.JPG</a></div></td>
<td><A ID='IMG_8371.JPG' href='gowest.php?fileId=IMG_8371.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050910/IMG_8371.JPG' ALT='IMG_8371.JPG'><BR>IMG_8371.JPG<br>60.22 KB</a><div class='inv'><br><a href='./images/20050910/IMG_8371.JPG' ALT='IMG_8371.JPG'>IMG_8371.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_8375.JPG' href='gowest.php?fileId=IMG_8375.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050910/IMG_8375.JPG' ALT='IMG_8375.JPG'><BR>IMG_8375.JPG<br>74.34 KB</a><div class='inv'><br><a href='./images/20050910/IMG_8375.JPG' ALT='IMG_8375.JPG'>IMG_8375.JPG</a></div></td>
<td><A ID='IMG_8381.JPG' href='gowest.php?fileId=IMG_8381.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050910/IMG_8381.JPG' ALT='IMG_8381.JPG'><BR>IMG_8381.JPG<br>82.26 KB</a><div class='inv'><br><a href='./images/20050910/IMG_8381.JPG' ALT='IMG_8381.JPG'>IMG_8381.JPG</a></div></td>
<td><A ID='IMG_8385.JPG' href='gowest.php?fileId=IMG_8385.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050910/IMG_8385.JPG' ALT='IMG_8385.JPG'><BR>IMG_8385.JPG<br>52.89 KB</a><div class='inv'><br><a href='./images/20050910/IMG_8385.JPG' ALT='IMG_8385.JPG'>IMG_8385.JPG</a></div></td>
<td><A ID='IMG_8390.JPG' href='gowest.php?fileId=IMG_8390.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050910/IMG_8390.JPG' ALT='IMG_8390.JPG'><BR>IMG_8390.JPG<br>74.52 KB</a><div class='inv'><br><a href='./images/20050910/IMG_8390.JPG' ALT='IMG_8390.JPG'>IMG_8390.JPG</a></div></td>
<td><A ID='IMG_8392.JPG' href='gowest.php?fileId=IMG_8392.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050910/IMG_8392.JPG' ALT='IMG_8392.JPG'><BR>IMG_8392.JPG<br>66.62 KB</a><div class='inv'><br><a href='./images/20050910/IMG_8392.JPG' ALT='IMG_8392.JPG'>IMG_8392.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_8393.JPG' href='gowest.php?fileId=IMG_8393.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050910/IMG_8393.JPG' ALT='IMG_8393.JPG'><BR>IMG_8393.JPG<br>83.2 KB</a><div class='inv'><br><a href='./images/20050910/IMG_8393.JPG' ALT='IMG_8393.JPG'>IMG_8393.JPG</a></div></td>
<td><A ID='IMG_8399.JPG' href='gowest.php?fileId=IMG_8399.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050910/IMG_8399.JPG' ALT='IMG_8399.JPG'><BR>IMG_8399.JPG<br>85.45 KB</a><div class='inv'><br><a href='./images/20050910/IMG_8399.JPG' ALT='IMG_8399.JPG'>IMG_8399.JPG</a></div></td>
<td><A ID='IMG_8405.JPG' href='gowest.php?fileId=IMG_8405.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050910/IMG_8405.JPG' ALT='IMG_8405.JPG'><BR>IMG_8405.JPG<br>92 KB</a><div class='inv'><br><a href='./images/20050910/IMG_8405.JPG' ALT='IMG_8405.JPG'>IMG_8405.JPG</a></div></td>
<td><A ID='IMG_8409.JPG' href='gowest.php?fileId=IMG_8409.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050910/IMG_8409.JPG' ALT='IMG_8409.JPG'><BR>IMG_8409.JPG<br>74.97 KB</a><div class='inv'><br><a href='./images/20050910/IMG_8409.JPG' ALT='IMG_8409.JPG'>IMG_8409.JPG</a></div></td>
<td><A ID='IMG_8412.JPG' href='gowest.php?fileId=IMG_8412.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050910/IMG_8412.JPG' ALT='IMG_8412.JPG'><BR>IMG_8412.JPG<br>79.29 KB</a><div class='inv'><br><a href='./images/20050910/IMG_8412.JPG' ALT='IMG_8412.JPG'>IMG_8412.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_8413.JPG' href='gowest.php?fileId=IMG_8413.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050910/IMG_8413.JPG' ALT='IMG_8413.JPG'><BR>IMG_8413.JPG<br>70.99 KB</a><div class='inv'><br><a href='./images/20050910/IMG_8413.JPG' ALT='IMG_8413.JPG'>IMG_8413.JPG</a></div></td>
<td><A ID='IMG_8416.JPG' href='gowest.php?fileId=IMG_8416.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050910/IMG_8416.JPG' ALT='IMG_8416.JPG'><BR>IMG_8416.JPG<br>95.62 KB</a><div class='inv'><br><a href='./images/20050910/IMG_8416.JPG' ALT='IMG_8416.JPG'>IMG_8416.JPG</a></div></td>
<td><A ID='IMG_8417.JPG' href='gowest.php?fileId=IMG_8417.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050910/IMG_8417.JPG' ALT='IMG_8417.JPG'><BR>IMG_8417.JPG<br>62.99 KB</a><div class='inv'><br><a href='./images/20050910/IMG_8417.JPG' ALT='IMG_8417.JPG'>IMG_8417.JPG</a></div></td>
<td><A ID='IMG_8420.JPG' href='gowest.php?fileId=IMG_8420.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050910/IMG_8420.JPG' ALT='IMG_8420.JPG'><BR>IMG_8420.JPG<br>66.85 KB</a><div class='inv'><br><a href='./images/20050910/IMG_8420.JPG' ALT='IMG_8420.JPG'>IMG_8420.JPG</a></div></td>
<td><A ID='IMG_8421.JPG' href='gowest.php?fileId=IMG_8421.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050910/IMG_8421.JPG' ALT='IMG_8421.JPG'><BR>IMG_8421.JPG<br>77.5 KB</a><div class='inv'><br><a href='./images/20050910/IMG_8421.JPG' ALT='IMG_8421.JPG'>IMG_8421.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_8425.JPG' href='gowest.php?fileId=IMG_8425.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050910/IMG_8425.JPG' ALT='IMG_8425.JPG'><BR>IMG_8425.JPG<br>77.9 KB</a><div class='inv'><br><a href='./images/20050910/IMG_8425.JPG' ALT='IMG_8425.JPG'>IMG_8425.JPG</a></div></td>
<td><A ID='IMG_8426.JPG' href='gowest.php?fileId=IMG_8426.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050910/IMG_8426.JPG' ALT='IMG_8426.JPG'><BR>IMG_8426.JPG<br>77.97 KB</a><div class='inv'><br><a href='./images/20050910/IMG_8426.JPG' ALT='IMG_8426.JPG'>IMG_8426.JPG</a></div></td>
<td><A ID='IMG_8428.JPG' href='gowest.php?fileId=IMG_8428.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050910/IMG_8428.JPG' ALT='IMG_8428.JPG'><BR>IMG_8428.JPG<br>58.13 KB</a><div class='inv'><br><a href='./images/20050910/IMG_8428.JPG' ALT='IMG_8428.JPG'>IMG_8428.JPG</a></div></td>
<td><A ID='IMG_8433.JPG' href='gowest.php?fileId=IMG_8433.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050910/IMG_8433.JPG' ALT='IMG_8433.JPG'><BR>IMG_8433.JPG<br>73.48 KB</a><div class='inv'><br><a href='./images/20050910/IMG_8433.JPG' ALT='IMG_8433.JPG'>IMG_8433.JPG</a></div></td>
<td><A ID='IMG_8434.JPG' href='gowest.php?fileId=IMG_8434.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050910/IMG_8434.JPG' ALT='IMG_8434.JPG'><BR>IMG_8434.JPG<br>62.62 KB</a><div class='inv'><br><a href='./images/20050910/IMG_8434.JPG' ALT='IMG_8434.JPG'>IMG_8434.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_8436.JPG' href='gowest.php?fileId=IMG_8436.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050910/IMG_8436.JPG' ALT='IMG_8436.JPG'><BR>IMG_8436.JPG<br>85.97 KB</a><div class='inv'><br><a href='./images/20050910/IMG_8436.JPG' ALT='IMG_8436.JPG'>IMG_8436.JPG</a></div></td>
<td><A ID='IMG_8439.JPG' href='gowest.php?fileId=IMG_8439.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050910/IMG_8439.JPG' ALT='IMG_8439.JPG'><BR>IMG_8439.JPG<br>57.4 KB</a><div class='inv'><br><a href='./images/20050910/IMG_8439.JPG' ALT='IMG_8439.JPG'>IMG_8439.JPG</a></div></td>
<td><A ID='IMG_8441.JPG' href='gowest.php?fileId=IMG_8441.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050910/IMG_8441.JPG' ALT='IMG_8441.JPG'><BR>IMG_8441.JPG<br>52.97 KB</a><div class='inv'><br><a href='./images/20050910/IMG_8441.JPG' ALT='IMG_8441.JPG'>IMG_8441.JPG</a></div></td>
<td><A ID='IMG_8443.JPG' href='gowest.php?fileId=IMG_8443.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050910/IMG_8443.JPG' ALT='IMG_8443.JPG'><BR>IMG_8443.JPG<br>62.85 KB</a><div class='inv'><br><a href='./images/20050910/IMG_8443.JPG' ALT='IMG_8443.JPG'>IMG_8443.JPG</a></div></td>
<td><A ID='IMG_8445.JPG' href='gowest.php?fileId=IMG_8445.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050910/IMG_8445.JPG' ALT='IMG_8445.JPG'><BR>IMG_8445.JPG<br>35.9 KB</a><div class='inv'><br><a href='./images/20050910/IMG_8445.JPG' ALT='IMG_8445.JPG'>IMG_8445.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_8452.JPG' href='gowest.php?fileId=IMG_8452.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050910/IMG_8452.JPG' ALT='IMG_8452.JPG'><BR>IMG_8452.JPG<br>70.69 KB</a><div class='inv'><br><a href='./images/20050910/IMG_8452.JPG' ALT='IMG_8452.JPG'>IMG_8452.JPG</a></div></td>
<td><A ID='IMG_8464.JPG' href='gowest.php?fileId=IMG_8464.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050910/IMG_8464.JPG' ALT='IMG_8464.JPG'><BR>IMG_8464.JPG<br>107.48 KB</a><div class='inv'><br><a href='./images/20050910/IMG_8464.JPG' ALT='IMG_8464.JPG'>IMG_8464.JPG</a></div></td>
<td><A ID='IMG_8468.JPG' href='gowest.php?fileId=IMG_8468.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050910/IMG_8468.JPG' ALT='IMG_8468.JPG'><BR>IMG_8468.JPG<br>50.08 KB</a><div class='inv'><br><a href='./images/20050910/IMG_8468.JPG' ALT='IMG_8468.JPG'>IMG_8468.JPG</a></div></td>
<td><A ID='IMG_8473.JPG' href='gowest.php?fileId=IMG_8473.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050910/IMG_8473.JPG' ALT='IMG_8473.JPG'><BR>IMG_8473.JPG<br>77.93 KB</a><div class='inv'><br><a href='./images/20050910/IMG_8473.JPG' ALT='IMG_8473.JPG'>IMG_8473.JPG</a></div></td>
<td><A ID='IMG_8475.JPG' href='gowest.php?fileId=IMG_8475.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050910/IMG_8475.JPG' ALT='IMG_8475.JPG'><BR>IMG_8475.JPG<br>43.95 KB</a><div class='inv'><br><a href='./images/20050910/IMG_8475.JPG' ALT='IMG_8475.JPG'>IMG_8475.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_8476.JPG' href='gowest.php?fileId=IMG_8476.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050910/IMG_8476.JPG' ALT='IMG_8476.JPG'><BR>IMG_8476.JPG<br>75.67 KB</a><div class='inv'><br><a href='./images/20050910/IMG_8476.JPG' ALT='IMG_8476.JPG'>IMG_8476.JPG</a></div></td>
<td><A ID='IMG_8477.JPG' href='gowest.php?fileId=IMG_8477.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050910/IMG_8477.JPG' ALT='IMG_8477.JPG'><BR>IMG_8477.JPG<br>51 KB</a><div class='inv'><br><a href='./images/20050910/IMG_8477.JPG' ALT='IMG_8477.JPG'>IMG_8477.JPG</a></div></td>
<td><A ID='IMG_8489.JPG' href='gowest.php?fileId=IMG_8489.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050910/IMG_8489.JPG' ALT='IMG_8489.JPG'><BR>IMG_8489.JPG<br>60.39 KB</a><div class='inv'><br><a href='./images/20050910/IMG_8489.JPG' ALT='IMG_8489.JPG'>IMG_8489.JPG</a></div></td>
<td><A ID='IMG_8493.JPG' href='gowest.php?fileId=IMG_8493.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050910/IMG_8493.JPG' ALT='IMG_8493.JPG'><BR>IMG_8493.JPG<br>74.32 KB</a><div class='inv'><br><a href='./images/20050910/IMG_8493.JPG' ALT='IMG_8493.JPG'>IMG_8493.JPG</a></div></td>
<td><A ID='IMG_8496.JPG' href='gowest.php?fileId=IMG_8496.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050910/IMG_8496.JPG' ALT='IMG_8496.JPG'><BR>IMG_8496.JPG<br>105.94 KB</a><div class='inv'><br><a href='./images/20050910/IMG_8496.JPG' ALT='IMG_8496.JPG'>IMG_8496.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_8500.JPG' href='gowest.php?fileId=IMG_8500.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050910/IMG_8500.JPG' ALT='IMG_8500.JPG'><BR>IMG_8500.JPG<br>114.16 KB</a><div class='inv'><br><a href='./images/20050910/IMG_8500.JPG' ALT='IMG_8500.JPG'>IMG_8500.JPG</a></div></td>
<td><A ID='IMG_8502.JPG' href='gowest.php?fileId=IMG_8502.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050910/IMG_8502.JPG' ALT='IMG_8502.JPG'><BR>IMG_8502.JPG<br>126.39 KB</a><div class='inv'><br><a href='./images/20050910/IMG_8502.JPG' ALT='IMG_8502.JPG'>IMG_8502.JPG</a></div></td>
<td><A ID='IMG_8505.JPG' href='gowest.php?fileId=IMG_8505.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050910/IMG_8505.JPG' ALT='IMG_8505.JPG'><BR>IMG_8505.JPG<br>68.5 KB</a><div class='inv'><br><a href='./images/20050910/IMG_8505.JPG' ALT='IMG_8505.JPG'>IMG_8505.JPG</a></div></td>
<td><A ID='IMG_8509.JPG' href='gowest.php?fileId=IMG_8509.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050910/IMG_8509.JPG' ALT='IMG_8509.JPG'><BR>IMG_8509.JPG<br>102.2 KB</a><div class='inv'><br><a href='./images/20050910/IMG_8509.JPG' ALT='IMG_8509.JPG'>IMG_8509.JPG</a></div></td>
<td><A ID='IMG_8515.JPG' href='gowest.php?fileId=IMG_8515.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050910/IMG_8515.JPG' ALT='IMG_8515.JPG'><BR>IMG_8515.JPG<br>77.04 KB</a><div class='inv'><br><a href='./images/20050910/IMG_8515.JPG' ALT='IMG_8515.JPG'>IMG_8515.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_8525.JPG' href='gowest.php?fileId=IMG_8525.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050910/IMG_8525.JPG' ALT='IMG_8525.JPG'><BR>IMG_8525.JPG<br>76.35 KB</a><div class='inv'><br><a href='./images/20050910/IMG_8525.JPG' ALT='IMG_8525.JPG'>IMG_8525.JPG</a></div></td>
<td><A ID='IMG_8528.JPG' href='gowest.php?fileId=IMG_8528.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050910/IMG_8528.JPG' ALT='IMG_8528.JPG'><BR>IMG_8528.JPG<br>88.52 KB</a><div class='inv'><br><a href='./images/20050910/IMG_8528.JPG' ALT='IMG_8528.JPG'>IMG_8528.JPG</a></div></td>
<td><A ID='IMG_8531.JPG' href='gowest.php?fileId=IMG_8531.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050910/IMG_8531.JPG' ALT='IMG_8531.JPG'><BR>IMG_8531.JPG<br>120.18 KB</a><div class='inv'><br><a href='./images/20050910/IMG_8531.JPG' ALT='IMG_8531.JPG'>IMG_8531.JPG</a></div></td>
<td><A ID='IMG_8534.JPG' href='gowest.php?fileId=IMG_8534.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050910/IMG_8534.JPG' ALT='IMG_8534.JPG'><BR>IMG_8534.JPG<br>57.26 KB</a><div class='inv'><br><a href='./images/20050910/IMG_8534.JPG' ALT='IMG_8534.JPG'>IMG_8534.JPG</a></div></td>
<td><A ID='IMG_8535.JPG' href='gowest.php?fileId=IMG_8535.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050910/IMG_8535.JPG' ALT='IMG_8535.JPG'><BR>IMG_8535.JPG<br>50.11 KB</a><div class='inv'><br><a href='./images/20050910/IMG_8535.JPG' ALT='IMG_8535.JPG'>IMG_8535.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_8540.JPG' href='gowest.php?fileId=IMG_8540.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050910/IMG_8540.JPG' ALT='IMG_8540.JPG'><BR>IMG_8540.JPG<br>45.08 KB</a><div class='inv'><br><a href='./images/20050910/IMG_8540.JPG' ALT='IMG_8540.JPG'>IMG_8540.JPG</a></div></td>
<td><A ID='IMG_8545.JPG' href='gowest.php?fileId=IMG_8545.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050910/IMG_8545.JPG' ALT='IMG_8545.JPG'><BR>IMG_8545.JPG<br>40.26 KB</a><div class='inv'><br><a href='./images/20050910/IMG_8545.JPG' ALT='IMG_8545.JPG'>IMG_8545.JPG</a></div></td>
<td><A ID='IMG_8547.JPG' href='gowest.php?fileId=IMG_8547.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050910/IMG_8547.JPG' ALT='IMG_8547.JPG'><BR>IMG_8547.JPG<br>54.16 KB</a><div class='inv'><br><a href='./images/20050910/IMG_8547.JPG' ALT='IMG_8547.JPG'>IMG_8547.JPG</a></div></td>
<td><A ID='IMG_8550.JPG' href='gowest.php?fileId=IMG_8550.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050910/IMG_8550.JPG' ALT='IMG_8550.JPG'><BR>IMG_8550.JPG<br>29.96 KB</a><div class='inv'><br><a href='./images/20050910/IMG_8550.JPG' ALT='IMG_8550.JPG'>IMG_8550.JPG</a></div></td>
<td><A ID='IMG_8561.JPG' href='gowest.php?fileId=IMG_8561.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050910/IMG_8561.JPG' ALT='IMG_8561.JPG'><BR>IMG_8561.JPG<br>59.3 KB</a><div class='inv'><br><a href='./images/20050910/IMG_8561.JPG' ALT='IMG_8561.JPG'>IMG_8561.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_8564.JPG' href='gowest.php?fileId=IMG_8564.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050910/IMG_8564.JPG' ALT='IMG_8564.JPG'><BR>IMG_8564.JPG<br>79.31 KB</a><div class='inv'><br><a href='./images/20050910/IMG_8564.JPG' ALT='IMG_8564.JPG'>IMG_8564.JPG</a></div></td>
<td><A ID='IMG_8567.JPG' href='gowest.php?fileId=IMG_8567.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050910/IMG_8567.JPG' ALT='IMG_8567.JPG'><BR>IMG_8567.JPG<br>46.01 KB</a><div class='inv'><br><a href='./images/20050910/IMG_8567.JPG' ALT='IMG_8567.JPG'>IMG_8567.JPG</a></div></td>
<td><A ID='IMG_8570.JPG' href='gowest.php?fileId=IMG_8570.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050910/IMG_8570.JPG' ALT='IMG_8570.JPG'><BR>IMG_8570.JPG<br>48.46 KB</a><div class='inv'><br><a href='./images/20050910/IMG_8570.JPG' ALT='IMG_8570.JPG'>IMG_8570.JPG</a></div></td>
<td><A ID='IMG_8572.JPG' href='gowest.php?fileId=IMG_8572.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050910/IMG_8572.JPG' ALT='IMG_8572.JPG'><BR>IMG_8572.JPG<br>119.18 KB</a><div class='inv'><br><a href='./images/20050910/IMG_8572.JPG' ALT='IMG_8572.JPG'>IMG_8572.JPG</a></div></td>
<td><A ID='IMG_8574.JPG' href='gowest.php?fileId=IMG_8574.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050910/IMG_8574.JPG' ALT='IMG_8574.JPG'><BR>IMG_8574.JPG<br>59.08 KB</a><div class='inv'><br><a href='./images/20050910/IMG_8574.JPG' ALT='IMG_8574.JPG'>IMG_8574.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_8577.JPG' href='gowest.php?fileId=IMG_8577.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050910/IMG_8577.JPG' ALT='IMG_8577.JPG'><BR>IMG_8577.JPG<br>66.83 KB</a><div class='inv'><br><a href='./images/20050910/IMG_8577.JPG' ALT='IMG_8577.JPG'>IMG_8577.JPG</a></div></td>
<td><A ID='IMG_8579.JPG' href='gowest.php?fileId=IMG_8579.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050910/IMG_8579.JPG' ALT='IMG_8579.JPG'><BR>IMG_8579.JPG<br>64.67 KB</a><div class='inv'><br><a href='./images/20050910/IMG_8579.JPG' ALT='IMG_8579.JPG'>IMG_8579.JPG</a></div></td>
<td><A ID='IMG_8581.JPG' href='gowest.php?fileId=IMG_8581.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050910/IMG_8581.JPG' ALT='IMG_8581.JPG'><BR>IMG_8581.JPG<br>70.49 KB</a><div class='inv'><br><a href='./images/20050910/IMG_8581.JPG' ALT='IMG_8581.JPG'>IMG_8581.JPG</a></div></td>
<td><A ID='IMG_8584.JPG' href='gowest.php?fileId=IMG_8584.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050910/IMG_8584.JPG' ALT='IMG_8584.JPG'><BR>IMG_8584.JPG<br>86.9 KB</a><div class='inv'><br><a href='./images/20050910/IMG_8584.JPG' ALT='IMG_8584.JPG'>IMG_8584.JPG</a></div></td>
<td><A ID='IMG_8590.JPG' href='gowest.php?fileId=IMG_8590.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050910/IMG_8590.JPG' ALT='IMG_8590.JPG'><BR>IMG_8590.JPG<br>103.74 KB</a><div class='inv'><br><a href='./images/20050910/IMG_8590.JPG' ALT='IMG_8590.JPG'>IMG_8590.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_8593.JPG' href='gowest.php?fileId=IMG_8593.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050910/IMG_8593.JPG' ALT='IMG_8593.JPG'><BR>IMG_8593.JPG<br>54.97 KB</a><div class='inv'><br><a href='./images/20050910/IMG_8593.JPG' ALT='IMG_8593.JPG'>IMG_8593.JPG</a></div></td>
<td><A ID='IMG_8594.JPG' href='gowest.php?fileId=IMG_8594.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050910/IMG_8594.JPG' ALT='IMG_8594.JPG'><BR>IMG_8594.JPG<br>80.92 KB</a><div class='inv'><br><a href='./images/20050910/IMG_8594.JPG' ALT='IMG_8594.JPG'>IMG_8594.JPG</a></div></td>
<td><A ID='IMG_8596.JPG' href='gowest.php?fileId=IMG_8596.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050910/IMG_8596.JPG' ALT='IMG_8596.JPG'><BR>IMG_8596.JPG<br>73.11 KB</a><div class='inv'><br><a href='./images/20050910/IMG_8596.JPG' ALT='IMG_8596.JPG'>IMG_8596.JPG</a></div></td>
<td><A ID='IMG_8599.JPG' href='gowest.php?fileId=IMG_8599.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050910/IMG_8599.JPG' ALT='IMG_8599.JPG'><BR>IMG_8599.JPG<br>78.99 KB</a><div class='inv'><br><a href='./images/20050910/IMG_8599.JPG' ALT='IMG_8599.JPG'>IMG_8599.JPG</a></div></td>
<td><A ID='IMG_8600.JPG' href='gowest.php?fileId=IMG_8600.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050910/IMG_8600.JPG' ALT='IMG_8600.JPG'><BR>IMG_8600.JPG<br>53.48 KB</a><div class='inv'><br><a href='./images/20050910/IMG_8600.JPG' ALT='IMG_8600.JPG'>IMG_8600.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_8607.JPG' href='gowest.php?fileId=IMG_8607.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050910/IMG_8607.JPG' ALT='IMG_8607.JPG'><BR>IMG_8607.JPG<br>46.63 KB</a><div class='inv'><br><a href='./images/20050910/IMG_8607.JPG' ALT='IMG_8607.JPG'>IMG_8607.JPG</a></div></td>
<td><A ID='IMG_8611.JPG' href='gowest.php?fileId=IMG_8611.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050910/IMG_8611.JPG' ALT='IMG_8611.JPG'><BR>IMG_8611.JPG<br>75.77 KB</a><div class='inv'><br><a href='./images/20050910/IMG_8611.JPG' ALT='IMG_8611.JPG'>IMG_8611.JPG</a></div></td>
<td><A ID='IMG_8615.JPG' href='gowest.php?fileId=IMG_8615.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050910/IMG_8615.JPG' ALT='IMG_8615.JPG'><BR>IMG_8615.JPG<br>41.41 KB</a><div class='inv'><br><a href='./images/20050910/IMG_8615.JPG' ALT='IMG_8615.JPG'>IMG_8615.JPG</a></div></td>
<td><A ID='IMG_8616.JPG' href='gowest.php?fileId=IMG_8616.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050910/IMG_8616.JPG' ALT='IMG_8616.JPG'><BR>IMG_8616.JPG<br>68.66 KB</a><div class='inv'><br><a href='./images/20050910/IMG_8616.JPG' ALT='IMG_8616.JPG'>IMG_8616.JPG</a></div></td>
<td><A ID='IMG_8620.JPG' href='gowest.php?fileId=IMG_8620.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050910/IMG_8620.JPG' ALT='IMG_8620.JPG'><BR>IMG_8620.JPG<br>96.72 KB</a><div class='inv'><br><a href='./images/20050910/IMG_8620.JPG' ALT='IMG_8620.JPG'>IMG_8620.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_8623.JPG' href='gowest.php?fileId=IMG_8623.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050910/IMG_8623.JPG' ALT='IMG_8623.JPG'><BR>IMG_8623.JPG<br>76.5 KB</a><div class='inv'><br><a href='./images/20050910/IMG_8623.JPG' ALT='IMG_8623.JPG'>IMG_8623.JPG</a></div></td>
<td><A ID='IMG_8625.JPG' href='gowest.php?fileId=IMG_8625.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050910/IMG_8625.JPG' ALT='IMG_8625.JPG'><BR>IMG_8625.JPG<br>75.29 KB</a><div class='inv'><br><a href='./images/20050910/IMG_8625.JPG' ALT='IMG_8625.JPG'>IMG_8625.JPG</a></div></td>
<td><A ID='IMG_8630.JPG' href='gowest.php?fileId=IMG_8630.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050910/IMG_8630.JPG' ALT='IMG_8630.JPG'><BR>IMG_8630.JPG<br>101.55 KB</a><div class='inv'><br><a href='./images/20050910/IMG_8630.JPG' ALT='IMG_8630.JPG'>IMG_8630.JPG</a></div></td>
<td><A ID='IMG_8631.JPG' href='gowest.php?fileId=IMG_8631.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050910/IMG_8631.JPG' ALT='IMG_8631.JPG'><BR>IMG_8631.JPG<br>105.66 KB</a><div class='inv'><br><a href='./images/20050910/IMG_8631.JPG' ALT='IMG_8631.JPG'>IMG_8631.JPG</a></div></td>
<td><A ID='IMG_8633.JPG' href='gowest.php?fileId=IMG_8633.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050910/IMG_8633.JPG' ALT='IMG_8633.JPG'><BR>IMG_8633.JPG<br>73.15 KB</a><div class='inv'><br><a href='./images/20050910/IMG_8633.JPG' ALT='IMG_8633.JPG'>IMG_8633.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_8634.JPG' href='gowest.php?fileId=IMG_8634.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050910/IMG_8634.JPG' ALT='IMG_8634.JPG'><BR>IMG_8634.JPG<br>82.05 KB</a><div class='inv'><br><a href='./images/20050910/IMG_8634.JPG' ALT='IMG_8634.JPG'>IMG_8634.JPG</a></div></td>
<td><A ID='IMG_8640.JPG' href='gowest.php?fileId=IMG_8640.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050910/IMG_8640.JPG' ALT='IMG_8640.JPG'><BR>IMG_8640.JPG<br>86.36 KB</a><div class='inv'><br><a href='./images/20050910/IMG_8640.JPG' ALT='IMG_8640.JPG'>IMG_8640.JPG</a></div></td>
<td><A ID='IMG_8646.JPG' href='gowest.php?fileId=IMG_8646.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050910/IMG_8646.JPG' ALT='IMG_8646.JPG'><BR>IMG_8646.JPG<br>72.92 KB</a><div class='inv'><br><a href='./images/20050910/IMG_8646.JPG' ALT='IMG_8646.JPG'>IMG_8646.JPG</a></div></td>
<td><A ID='IMG_8648.JPG' href='gowest.php?fileId=IMG_8648.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050910/IMG_8648.JPG' ALT='IMG_8648.JPG'><BR>IMG_8648.JPG<br>76.97 KB</a><div class='inv'><br><a href='./images/20050910/IMG_8648.JPG' ALT='IMG_8648.JPG'>IMG_8648.JPG</a></div></td>
<td><A ID='IMG_8657.JPG' href='gowest.php?fileId=IMG_8657.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050910/IMG_8657.JPG' ALT='IMG_8657.JPG'><BR>IMG_8657.JPG<br>78.37 KB</a><div class='inv'><br><a href='./images/20050910/IMG_8657.JPG' ALT='IMG_8657.JPG'>IMG_8657.JPG</a></div></td>
</tr>
</table>	</div>
</div>
</body>
</html>