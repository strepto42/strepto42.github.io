<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - June 2005 - Q&A letters</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="Q&A letters">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="Q&A letters" href='masterit200501.php'>January 2005</a></li>
<li><a title="Q&A letters" href='masterit200502.php'>February 2005</a></li>
<li><a title="Q&A letters" href='masterit200503.php'>March 2005</a></li>
<li><a title="Q&A letters" href='masterit200504.php'>April 2005</a></li>
<li><a title="Q&A letters" href='masterit200505.php'>May 2005</a></li>
<li><div class='activemenu'>June 2005</div></li>
<li><a title="Q&A letters" href='masterit200507.php'>July 2005</a></li>
<li><a title="Q&A letters" href='masterit200508.php'>August 2005</a></li>
<li><a title="Q&A letters" href='masterit200509.php'>September 2005</a></li>
<li><a title="Q&A letters" href='masterit200510.php'>October 2005</a></li>
<li><a title="Q&A letters" href='masterit200511.php'>November 2005</a></li>
<li><a title="Q&A letters" href='masterit200512.php'>December 2005</a></li>
<li> </li><br><li>Or go back to:</li><li><a title='Q&A/MasterIT letters from 2005' href="masterit2005.php">2005 archive</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>June 2005</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Mark's writing' href="written.php">Professional Writing</a> > <a title='My weekly Q&A column in The Australian' href="masterIT.php">MasterIT</a> > <a title='Q&A/MasterIT letters from 2005' href="masterit2005.php">2005 archive</a> > <a title='Q&A letters' href="masterit200506.php">June 2005</a>
<br><br>		<br>
<h2>7/6/05</h2><br>
<b>I am running Windows XP Home with the free latest edition of the anti virus system AVG. On 20 April the daily test result showed 3 viruses. However, when asked for more details, the test report showed "No viruses found". Further information showed "Virus identified Java/ByteVerify" and the status column showed three reports as "Infected. Embedded objects" and one report "Infected Archive". Can you advise what all the above reports mean and what I should do about them?</b><br>
<br>
What happened here is that there was a virus was embedded inside a compressed archive. These files are just a way of grouping a few files together and making them take up less disk space by using mathematical magic.<br>
<br>
This particular virus, which I actually turned out to have myself, lives inside a Java archive (sometimes called a .JAR file). I only managed to detect it on my own system by enabling my virus scanner to specifically scan inside these files.<br>
<br>
This might sound a little scary, but if I had ever tried to access the file, it would have been picked up immediately. My own scanner just never picked it up in normal day to day usage, because I never tried to load it.<br>
<br>
It's probably worth explaining at this point the difference between having a virus file on your system, and your PC actually having contracted the virus. In the former case, which applies to us, we had the file lurking on our disk, but it had never been accessed, so it never became active. It's like being around people who have the flu, but not contracting it yourself.<br>
<br>
Some virus programs automatically exclude archive files from their scans, so if you want complete peace of mind, make sure this option is activated. In reality though, you won't have a problem as long as your scanner always scans files when they are read from disk. As far as further action goes, I wouldn't worry, the virus is most likely dead and gone.<br>
<br>
<br>
<b>Is Mozilla Firefox a more secure browsing program than Internet Explorer?</b><br>
<br>
Yes, definitely; check out www.secunia.com/product/4227 versus www.secunia.com/product/11.<br>
<br>
Mozilla is also a better browser when it comes to complying with html standards. Occasionally people code specifically for IE's oddities, but pages like this are increasingly rare.<br>
<br>
You also have many other benefits with Mozilla, like tabbed browsing, pop-up blocking and a host of useful plug-ins.<br>
<br>
You can download it from www.mozilla.org. A reader has also let me know of his site, www.firemonger.org, which provides free downloads of an easy, pre-packaged CD image for distributing and installing Mozilla and Thunderbird.<br>
<br>
<br>
<h2>14/6/05</h2><br>
<b>I want to give my pc a speed boost by replacing the CPU. I know I have a P4 1.6, but how do I find out which bus speed and pin format it has - is there a utility available which would be able to get the information from the motherboard?</b><br>
<br>
There are a few - a program called "wcpuid" is one of the better ones (tinyurl.com/3ued).<br>
<br>
It will tell you your CPU's speed and revision, as well as the bus speed, and vendor specific information about your motherboard.<br>
<br>
Next, you'll need to do a bit of reading to work out which options are open to you. I suggest checking out the manufacturer's website. They should list compatible processors and the socket type. You'll also want to verify the front side bus (FSB) speed of the new CPU, to make sure it's compatible with your board and RAM.<br>
<br>
<br>
<b>I recently bought a computer. I was told that I would get a 2.4Ghz AMD. In fact the computer came with an AMD Sempro 2500+. On taking the system home I started the system, and observed the following: Windows XP, "my computer" reports 1.7Ghz. The BIOS also reports the same processor speed - 1750Mhz). I spoke with the shop and was told that is the way the speed is reported, but they assured me that it was faster than 2.4Ghz. I'm hoping you can clarify this situation for me.</b><br>
<br>
The confusion you're experiencing is due to what's known as a steaming pile of marketing.<br>
<br>
The different speeds are due to the way Intel and AMD label their processors these <br>
days. In the old days, it was a case of a simple speed, end of story. <br>
<br>
The thing was, AMD's chips were actually faster than Intel's at a given speed, so some marketroid decided that instead of a the real speed rating, it would be less confusing for consumers (and more beneficial for AMD) if they started using an "equivalent" speed rating.<br>
<br>
The idea is that the 2500+ is roughly equal to an Intel P4 running at that speed, even though it's actual clock speed is only 1750mhz.<br>
<br>
Both Intel and AMD chips have their strengths and weaknesses. AMD's chips are  faster for games, whereas Intel tend to still score better for business apps, and day to day use.<br>
<br>
But the good news is that we live in the real world, not in magic benchmark land, so none of this really matters, as you're unlikely to notice any difference between the AMD 2500+ and a real Intel 2.4.<br>
<br>
You can play with http://www23.tomshardware.com if you want to check out endless benchmarks on the subject, and compare various CPUs.<br>
<br>
<br>
<h2>21/6/05</h2><br>
<b>I AM using a family tree program made by GSP. It uses a .gft format, which a Google search reveals is only used by this program and one other. I want to back up my data to a CD and make copies for other family members. The program allows me to Export to CD, but when I try to play it back, Windows XP will not recognise the format. I have tried to Save As in a different format but the only choices that appear are .gft or All Files. Is there any way of converting the .gft format to a format recognised by Windows?</b><br>
<br>
Firstly, double-check whether your version of GSP allows you to export your data as a gedcom file.<br>
<br>
According to http://www.my-history.co.uk/acatalog/compare.htm, which compares some family tree software, some versions of GSP do allow this.<br>
<br>
If you have an old version that doesn't allow it, your quickest option may be to upgrade.<br>
<br>
The gedcom is widely accepted as the standard for exchange of genealogical data, and many family tree programs can handle it.<br>
<br>
If you can't export to gedcom (.ged), I don't think there is an easy way to share these files, unless other people have the same program installed.<br>
<br>
Custom formats such as .gft have been around as long as computers. The software programmers invent their own structure for writing the program's data to disk. Unfortunately, this makes exchanging or converting the data almost impossible unless the software manufacturer releases the internal details of the format.<br>
<br>
Reverse engineering is sometimes possible, but it's neither easy (think hardcore geek territory), nor legal in most cases.<br>
<br>
If you can't export to gedcom and if you stick with GSP, you only have two options. You can get other people to install the same software, or you can<br>
capture screenshots and send them around in a static, graphic format.<br>
<br>
One can take a screenshot at any time in Windows by pressing the Prt Scn key. This will copy the current screen to the clipboard. You can capture just the active window only by holding down Alt at the same time. Then you'll need to go into an image editing program (such as Paint, which comes with Windows, and is on the Start menu under Accessories), and press control-V to paste the image, then save it and send it round.<br>
<br>
<br>
<h2>28/6/05</h2><br>
<b>My Windows ME crashes so frequently that I got Windows XP Professional. The problem is as to what I do next. Just install Windows XP and hope for the best? Somehow get rid of ME and install XP?</b><br>
<br>
There are two ways you can go. One is to do an "upgrade" install. This preserves all your installed programs and settings, but when you go from ME to XP, you can end up with an installation of Windows that has, shall we say, "character" (not in a good way).<br>
<br>
The other option is to do a fresh install. If you do this without formatting (wiping) the hard drive, your documents will be intact, but you'll have to reinstall all of your programs and settings, and you'll also have a lot of clutter on the disc.<br>
<br>
XP comes with a "files and settings transfer wizard", that supposedly helps you transfer programs and settings, but I've found it's value to be dubious, beyond copying basic Windows settings, which only take a few minutes to set up on the new system anyway.<br>
<br>
If you do format the disc as part of the install, you will lose everything, so a backup is advisable before you proceed, however, you will get many warnings during the install process before it will go ahead with a format.<br>
<br>
<br>
<b>I've been trying without success to install Explorer 6 SP1. I am currently running Windows ME with IE5.5. It downloads OK, and begins installing, but when it gets to 'extracting Internet Explorer 6 web browser', it installs up to 91%, I get a message that reads: "Setup was unable to install all the components. Please close all applications and try running setup again". How can I overcome this problem?</b><br>
<br>
The thing with the IE6SP1 installer, is that it downloads IE piecemeal from the Internet as it goes. Unfortunately, it seems to be failing to download some pieces of the pie.<br>
<br>
Often, Microsoft release big programs like this in two forms, one where a small installer downloads only the parts you need (saving time), and another where you download the whole lot manually in one go, and install locally.<br>
<br>
Unfortunately, I can't find the full installer anywhere on Microsoft's site. If it is there, it'll probably be enormous (75 megabytes or so) which, even over broadband, will take a while to download.<br>
<br>
It wouldn't be a MasterIT column if I didn't put in some evangelical advice about Mozilla, so perhaps as an alternative, you might like to try Firefox. It's free from www.mozilla.org.<br>
<br>
<i><p>Did the information on this page help you? Entertain you? Bore you? <a href="contact.php?subject=MasterIT">Drop me a line</a>.</p>

<p>If you're feeling particularly generous, you can even <a href="buypics.php">click here to send me some dot-com riches</a>. Think of it as online busking.</i></p>
	</div>
</div>
</body>
</html>