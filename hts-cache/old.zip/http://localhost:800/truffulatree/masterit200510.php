<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - October 2005 - Q&A letters</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="Q&A letters">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="Q&A letters" href='masterit200501.php'>January 2005</a></li>
<li><a title="Q&A letters" href='masterit200502.php'>February 2005</a></li>
<li><a title="Q&A letters" href='masterit200503.php'>March 2005</a></li>
<li><a title="Q&A letters" href='masterit200504.php'>April 2005</a></li>
<li><a title="Q&A letters" href='masterit200505.php'>May 2005</a></li>
<li><a title="Q&A letters" href='masterit200506.php'>June 2005</a></li>
<li><a title="Q&A letters" href='masterit200507.php'>July 2005</a></li>
<li><a title="Q&A letters" href='masterit200508.php'>August 2005</a></li>
<li><a title="Q&A letters" href='masterit200509.php'>September 2005</a></li>
<li><div class='activemenu'>October 2005</div></li>
<li><a title="Q&A letters" href='masterit200511.php'>November 2005</a></li>
<li><a title="Q&A letters" href='masterit200512.php'>December 2005</a></li>
<li> </li><br><li>Or go back to:</li><li><a title='Q&A/MasterIT letters from 2005' href="masterit2005.php">2005 archive</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>October 2005</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Mark's writing' href="written.php">Professional Writing</a> > <a title='My weekly Q&A column in The Australian' href="masterIT.php">MasterIT</a> > <a title='Q&A/MasterIT letters from 2005' href="masterit2005.php">2005 archive</a> > <a title='Q&A letters' href="masterit200510.php">October 2005</a>
<br><br>		<br>
<h2>4/10/05</h2><br>
<b>Every now and then, I get a window popping up on my PC titled "epolicy orchestrator agent monitor". There are generally a couple of cryptic items in the window, and there seems to be no rhyme or reason behind its appearance. Is it important?</b><br>
<br>
The window in question is a part of the McAfee antivirus system. Unfortunately I can't tell you exactly why or when it appears; however you can take solace in the fact that it happens to me too, on more than one PC.<br>
<br>
It's not really anything you need to worry about though, closing and ignoring it is a fine option. You might like to query McAfee directly about it; their tech support people should be able to shed a little more light on the subject.<br>
<br>
<br>
<b>I've recently invested in a digital camera, and I was discussing it at work with a colleague. He suggested that I shoot in "raw" mode, but I must confess to being an ignoramus with these things. Due to the magic of office politics, it seems somehow less embarrassing to write anonymously to a national newspaper and ask for help, so could you please elucidate?</b><br>
<br>
RAW mode is when the camera saves the picture data exactly as it comes off the sensor. Normally, digicams save pictures as JPEG files, after doing various manipulations, like adjusting the white balance, exposure and so on. This process changes the original data, and actually throws a bit of it away when the image is compressed to a JPEG (how much is lost depends on your image quality settings).<br>
<br>
RAW files let you have absolutely the highest quality, with no loss of information, but they will require more fiddling.<br>
<br>
You can also use RAW to rescue slightly dud pictures, by doing some manual tweaking, provided you have the right software, but Photoshop and similar products let you do this with JPEGs anyway.<br>
<br>
RAWs are a lot bigger too, so you won't be able to fit as many pictures on your camera.<br>
<br>
There's also no standard format for RAW images; different cameras produce their own variations. Often, you'll need special software to read them, although Photoshop supports a variety of RAW formats out of the box.<br>
<br>
Some cameras will let you save RAW and JPEG files simultaneously. This uses even more room on your card, but gives you the best of both worlds.<br>
<br>
Overall, unless you're getting really serious about digital photography, and are prepared to invest some time climbing a fairly steep technical learning curve, JPEGs will be fine for your happy snaps. Shooting RAW will definitely give you more nerd credibility; it's up to you to decide if this is a good thing or not.<br>
<br>
<br>
<h2>11/10/05</h2><br>
<b>I'm using Mozilla mail to write my emails, and sometimes when I hit reply, the previous email is quoted all on one line which flows off the right hand side of the window. Often, it seems to happen when I'm replying to emails written by people using other mail programs (like Outlook), or Hotmail. Is there some way to prevent this, and get the original email quoted correctly?</b><br>
<br>
Unfortunately you can't prevent this happening in the first place (without haranguing your friends into changing email program), but what you can do instead is go to the Edit menu, and select "rewrap". The results won't always be perfect, but they'll be a lot better.<br>
<br>
This function is also handy when cutting and pasting other text into your emails, an activity which sometimes results in slightly wacky formatting.<br>
<br>
<br>
<b>I have received some excellent pictures by email and I want to use them as wallpaper. How do I convert .eml files to a bmp format so that I can do this?</b><br>
<br>
The .eml format was created by Microsoft, and contains an entire saved email, including attachments. What you need to do is extract these attachments, and save them separately. First, open up the email by double clicking on the .eml file, then go to the File menu and select "save attachments".<br>
<br>
Choose the attachments that you want to save (if there is more than one), and pick a folder in which to save the files; the default is probably "my documents". Finally, click save.<br>
<br>
Now you'll need to select the picture as your wallpaper. Go into the desktop properties, select the appropriate tab and click browse, then choose your saved picture. Modern versions of Windows will be able to handle most common formats, not just .bmp files, but if you're using an older version like 98, you will need to convert the pictures first using a program like Acdsee.<br>
<br>
If you're getting sent lots of great backdrops and you want to be really clever, you can install a program to automatically change the backdrop at certain intervals.<br>
<br>
One such program, which I've found to be quite good, is the imaginatively named Wallpaper Changer, which can be found www.wallpaperchanger.de. Setting it up can be a little fiddly, but once it's going it works a treat.<br>
<br>
<br>
<h2>18/10/05</h2><br>
<b>When I boot up, and before my desktop appears, I get a message on the screen which reads: "This application has failed to start because Symstore.dll was not found. Reinstalling the application may fix this problem". The message is headed by:"ccRegVfy.exe - unable to locate component". I can click on the OK of course, but it is annoying and I want to remove the message, but how? I run Windows Registry Cleaner and Norton Security, also Windows XP.</b><br>
<br>
From what I've read, this is an issue with Norton Security. Apparently, completely uninstalling and reinstalling it will fix the problem, but in order to accomplish properly you might have to muck around with a special utility, depending on which version you have.<br>
<br>
Have a look at tinyurl.com/6m55v for more info.<br>
<br>
<br>
<b>Perhaps you could recommend a way to remove e-mail attachments before storage. I send many photos, and often send the same photos to several people, and so have multiple copies of each photo stored in my sent box. Ideally, the names of the photos sent would still be in the e-mail listed as attachments but the actual pictures would not be there wasting space.</b><br>
<br>
There's no way to do it in Outlook Express as supplied by Microsoft, but I've done a quick bit of digging and it looks like there are a few third party utilities that you could try.<br>
<br>
One such program is Quick Tools, which you can find at ajsystems.com/qt4.html. Note that once you remove the attachments, you'll still need to compress your mail folders by going to the File menu, and selecting folders->compact (or compact all) in order to get your disk space back.<br>
<br>
Unfortunately Quick Tools isn't free, but you can download a trial version first to see if it fits the bill.<br>
<br>
<br>
<b>I keep seeing "tinyurl" in your column, as well as in other places. What is this website?</b><br>
<br>
Tinyurl.com is a website that provides a simple redirection service, translating great big hulking URLs (or any URL for that matter) into little ones. Needless to say, these URLs are a bit more user-friendly, especially when it's a matter of typing them (as it is with a good old-school medium like print), or when your URL is so big it wraps over several lines in an email.<br>
<br>
You can go to tinyurl.com itself for the full story of course, as well as to create your own URL abbreviations. Best of all, it's free!<br>
<br>
<br>
<h2>25/10/05</h2><br>
<b>I have received some e-mails containing pictures/video but cannot seem to open them.  They do not indicate that there are attachments (but at 7mb there is something in there). I am using Outlook Express and Windows XP.</b><br>
<br>
You've most likely got a slightly mis-formatted message. This is normally the fault of the sending email program (sometimes they just don't quite get it right), but it can also be a result of the receiving program (Outlook Express in this case) being fussy too.<br>
<br>
This doesn't happen very often, but it's far from unheard of. The problem often rears it's ugly head when you cross platforms, for example when Macs send to PCs, or vice-versa.<br>
<br>
Whatever the case is, when you get the right combination (or wrong, so to speak) of programs and message, you can get a bum email that appears to have no attachments.<br>
<br>
Another possibility is that you might have been sent an attachment in a format that Outlook Express doesn't understand. There are only a few binary attachment formats used these days, and OE understands the main ones.<br>
<br>
Specifically, these are base64 encoded messages, and uuencoded messages. Both formats have their merits and bugbears (one of which is the problem discussed above), but they generally don't cause issues, and are widely accepted.<br>
<br>
Unfortunately, they do blow out the size of the email by significantly more than the size of the actual attachment (33-40%), so other, more recent protocols for attaching files to messages have been developed.<br>
<br>
One common one is yEnc, and it's often used in binaries newsgroups, where message size really starts to matter, as many many messages are being transmitted each day around the world. OE doesn't understand this format, so you'll need a plugin, or a different mail reader to cope with it.<br>
<br>
(If you're interested in more technical details, check out http://en.wikipedia.org/wiki/Yenc).<br>
<br>
In all likelihood though, encoding type isn't the problem. It's most likely the first thing I mentioned; just a mangled message due to a bad combination of sender/receiver mail programs, the wind blowing the wrong way, the pitch being soft, the phase of the moon being off... etc. :)<br>
<br>
If you have a Hotmail, Gmail or Yahoo account, try to get the person who sent you the message to resend it to one of those accounts; it may be possible to read it there.<br>
<br>
Finally, speaking of Gmail, don't forget that if you'd like an invite to open an account, just ask when you shoot your questions across to me.<br>
<br>
<i><p>Did the information on this page help you? Entertain you? Bore you? <a href="contact.php?subject=MasterIT">Drop me a line</a>.</p>

<p>If you're feeling particularly generous, you can even <a href="buypics.php">click here to send me some dot-com riches</a>. Think of it as online busking.</i></p>
	</div>
</div>
</body>
</html>