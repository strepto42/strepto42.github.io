<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - Shameless Panhandling - Give me Money!</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="Give me Money!">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>Shameless Panhandling</h1>
		
<br><br>		<br>
So, either you clicked on a 'contact me about this picture' link, or you clicked on the link to give me money.<br>
<br>
Nice work either way - you found the secret page!<br>
<br>
Re the pictures:<br>
<br>
If you'd like a full sized version of any of my pictures, just ask. I'm more than happy to send you an original, although they're big files (several megabytes each).<br>
<br>
Obviously, if you're wanting to use an image for commercial purposes, we'll have to come to some arragement, but by all means do ask. Media inquiries are quite welcome too. Anyway I'm not about to charge you millions of dollars (unless your name is <a href="images/bush_c_nt.jpg" title="It's true, Bush is a Map of Tassie">George W. Bush</a> or <a href="images/markc_howard3.jpg" title="Johnny deserves a swift flying side kick to the head">John Howard</a>, in which case no amount of money will secure you more than "<a href="http://www.imdb.com/title/tt0118826/" target="_blank">tell 'im he's dreamin'!</a>").<br>
<br>
In the unlikely event that you'd like to buy a print, I can organise that too. Having never done that though, pricing isn't exactly fixed, and will depend on the type and size of the print etc.<br>
<br>
You can also use Paypal now to throw a couple of coins my way, if you're so inclined. Think about it as online busking - I'm more likely to play that tune you really like if you chuck a coin into the guitar case. ;)<br>
<br>
Re the shameless panhandling:<br>
<br>
Today, some guy randomly came up to me when I was having my lunch in the city, and asked me for two bucks. He didn't look particularly bedraggled, and he didn't particularly have a good reason for wanting it (he mumbled something about 'being an artist'). I thought about it for a second, and then gave him two bucks. Why the hell not? Two dollars isn't exactly a fortune these days, and well, he asked.<br>
<br>
So I figured, what the hell? I may as well try the same sort of thing. I'll even give you something in return! If you enjoyed any of my pages *cough*badoptimus*cough*, or you just think I take the occasional ok picture, and want to encourage me to take more... well, chuck me a pittance.<br>
<br>
I'm actually quite curious to see if I ever make a single cent! If I do, hell, dot-com dollars can't be sneezed at!<br>
<br>
<a href="contact.php?subject=Your+disgusting+capitalistic+tendencies">Click here to contact me and discuss my disgusting capitalistic tendencies at length!</a><br>
<br>
And/or, click the button below to place a coin in the slot...<br>
<br>
<form action="https://www.paypal.com/cgi-bin/webscr" method="post"><input type="hidden" name="cmd" value="_xclick"><input type="hidden" name="business" value="strepto42@gmail.com"><input type="hidden" name="item_name" value="Shameless website panhandling"><input type="hidden" name="no_shipping" value="0"><input type="hidden" name="no_note" value="1"><input type="hidden" name="currency_code" value="AUD"><input type="hidden" name="tax" value="0"><input type="hidden" name="lc" value="AU"><input type="hidden" name="bn" value="PP-DonationsBF"><input type="image" src="http://www.truffulatree.com.au/images/paypal_giveusthem.gif" border="0" name="submit" alt="Make payments with PayPal - it's fast, free and secure!"><img alt="" border="0" src="https://www.paypal.com/en_AU/i/scr/pixel.gif" width="1" height="1"></form><br>
<br>
Go on, I'll send you some <a href="itsatoughlife2.php?fileId=IMG_2515.JPG">really</a> <a href="peaceconvergence.php?fileId=IMG_3321.JPG">nice</a> <a href="thesouthwest.php?fileId=IMG_2494.JPG">desktop</a> <a href="thingsfromabove.php?fileId=IMG_8708.JPG">backdrops</a> at the very least to say thanks.<br>
<br>


	</div>
</div>
</body>
</html>