<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - 12/8/2005 - Slowing the pace in Darwin</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="Slowing the pace in Darwin">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="Greetings from a Bum" href='greetingsfromabum.php'>29/4/2005</a></li>
<li><a title="Onward" href='onward.php'>2/5/2005</a></li>
<li><a title="It's a tough life (pt 1: Bundaberg, Agnes Water and 1770)" href='itsatoughlife1.php'>17/5/2005</a></li>
<li><a title="It's a tough life (pt 2: Rockhampton, Emu Park and Great Keppel Island)" href='itsatoughlife2.php'>23/5/2005</a></li>
<li><a title="There and Back Again - a Yo-yo's Tale" href='thereandbackagain.php'>18/6/2005</a></li>
<li><a title="Platypi and Grey Nomads" href='platypiandgreynomads.php'>24/6/2005</a></li>
<li><a title="Blowing Bubbles in a Watery Tomb" href='blowingbubbles.php'>1/7/2005</a></li>
<li><a title="Pieces of History" href='piecesofhistory.php'>8/7/2005</a></li>
<li><a title="Walks and Waterfalls" href='walksandwaterfalls.php'>15/7/2005</a></li>
<li><a title="Mission to Tribulation" href='missiontotribulation.php'>22/7/2005</a></li>
<li><a title="Levity, Limestone and Lava" href='levitylimestoneandlava.php'>29/7/2005</a></li>
<li><a title="Into the Never Never" href='intothenevernever.php'>5/8/2005</a></li>
<li><div class='activemenu'>12/8/2005</div></li>
<li><a title="Blistering Barnacles and Leaping Lizards" href='leapinglizards.php'>19/8/2005</a></li>
<li><a title="Kakadu and Litchfield" href='kakadu.php'>26/8/2005</a></li>
<li><a title="Legacies of War" href='legaciesofwar.php'>2/9/2005</a></li>
<li><a title="Go West" href='gowest.php'>10/9/2005</a></li>
<li><a title="Things from Above" href='thingsfromabove.php'>16/9/2005</a></li>
<li><a title="The West Coast" href='thewestcoast.php'>23/9/2005</a></li>
<li><a title="Reefs and Red Dust" href='reefsandreddust.php'>30/9/2005</a></li>
<li><a title="The Pilbara" href='pilbara.php'>7/10/2005</a></li>
<li><a title="Paradise with a Headwind" href='paradisewithaheadwind.php'>14/10/2005</a></li>
<li><a title="Down the Coral Coast" href='downthecoralcoast.php'>21/10/2005</a></li>
<li><a title="Pinnacles and Pinnipeds" href='pinnaclesandpinnipeds.php'>28/10/2005</a></li>
<li><a title="A week in Perth" href='perth.php'>4/11/2005</a></li>
<li><a title="The Southwest (from Above and Below)" href='thesouthwest.php'>11/11/2005</a></li>
<li><a title="More Heights and Depths" href='moreheightsanddepths.php'>18/11/2005</a></li>
<li><a title="Across the Nullarbor (and a bit beyond)" href='nullarbor.php'>25/11/2005</a></li>
<li><a title="Double Whammy" href='doublewhammy.php'>9/12/2005</a></li>
<li><a title="Two Cities" href='twocities.php'>19/12/2005</a></li>
<li><a title="Tassie - Part 1" href='tassie1.php'>1/1/2006</a></li>
<li><a title="Tassie - Part 2" href='tassie2.php'>7/1/2006</a></li>
<li><a title="Full Circle" href='fullcircle.php'>26/1/2006</a></li>
<li><a title="The Wrap Up" href='thewrapup.php'>23/3/2006</a></li>
<li> </li><br><li>Or go back to:</li><li><a title='Travelouges and blogs from my trip around Australia' href="nerdseyeview.php">Nerd's Eye View</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>12/8/2005</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Travel stories and pictures' href="travel.php">Travelogues</a> > <a title='Travelouges and blogs from my trip around Australia' href="nerdseyeview.php">Nerd's Eye View</a> > <a title='Slowing the pace in Darwin' href="slowingthepaceindarwin.php">12/8/2005</a>
<br><br>		


<h1>Slowing the pace in Darwin</h1>

<a href="images/maps/Map050812.gif"><img src="images/maps/Map050812_sm.gif" align="right"></a>
<p>Hello good people,</p>

<p>It's that time of week again. This time, I'm coming at you from Darwin, and I've gone as far North as I'll get on this trip, barring any unforseen kidnappings, lottery wins or other large cash donations. :)</p>

<p>Compared to the last couple of weeks, I haven't actually travelled that far, or done as much. The blame for this lies squarely on the shoulders of my fantastic Darwin hosts, Justine (ex-workmate) and Harley, who are very kindly providing me with a luxurious, internet-enabled, centrally located, air conditioned, and above all FREE place to stay in Darwin. Bastards!</p>

<p>I arrived here last Saturday, after an uneventful drive from Katherine. Along the way I stopped off briefly at the old Pine Creek mine (now a damn deep lake), and Adelaide River (mainly for a free cup of tea at the driver reviver).</p>

<p>Harley has cleverly evaded putting up with me by buggering off to Sydney for a work training course on Sunday. Justine hasn't been so lucky, but she's still smiling so I can't be that bad.</p>

<p>We spent Sunday at Berry Springs, an amazingly lovely swimming spot South of the city. The natural springs there are incredibly warm; the water is clear and deep, and lined with Pandanus Palms and other tropical plant life. Foolishly, I didn't take my camera. I think we'll head back this weekend though - so if we do I'll take it, as well as my snorkelling gear, as there are fish galore in the water too.</p>

<p>The rest of the week Justine has had to work, so I've been largely left to my own devices. Actually she's quite convinced that I only get out of bed 10 minutes before she gets home, as each day I've been sitting on the computer when she's walked in the door.</p>

<p>Admittedly I've been a little bit lazy; after all it's nice to have a place to relax like this. But I have been getting out and about a little bit too.</p>

<p>Monday I went on an exploratory ride around the CBD (such as it is here), and then up to East Point, where there are former naval gun emplacements.</p>

<p>Tuesday I did a little bit of shopping, and picked up a remote shutter release for the camera, so now I won't have to muck around with Gaffa tape to hold the button down when doing those nice star trail shots.</p>

<p>I also picked up an earpiece for my CDMA modem. This means that when I'm out of normal (GSM) phone reception (which is likely to be pretty much all the time once I leave Darwin), I can still make and receive calls using the CDMA widget that I bought for mobile Internet, provided that I have reception on it of course.</p>

<p>Anyway the number for that phone is exactly the same as my other mobile - just use 0427 instead of 0408. I need to have the computer on to use it of course, but it'll be there if I ever need it.</p>

<p>Tuesday night we sat around having a few wines, and I introduced Justine to instant messaging on the computer. She became completely engrossed in conversations with Nathan and Rhys and forgot to call Harley back. Oops. She also didn't notice that I was taking pictures of her. :)</p>

<p>Yesterday I thought I should actually get out and about a bit more, and so I headed off on another long ride around town. I ended up visiting the parliament house (empty of hard-working politicians of course), and the old Fannie Bay Jail (Gaol if you prefer), which made for some interesting pictures.</p>

<p>Apparently, the NT's last hanging (well, the last officially sanctioned one :| ) took place there, and most of the gallows (barring actual nooses) is still on display.</p>

<p>There are some great bike tracks around Darwin, and it's fairly flat, so I rode around some more, and headed north just about as far as one can go easily on the coast. I say just about, as the northernmost point I could ride to was a nudist beach, and whilst the potential of seeing men carrying large hairy cucumbers (as Wade once put it) didn't particularly faze me, my camera probably wouldn't have gone down too well (no puns intended).</p>

<p>I did like the sign though - "...nudity elsewhere is not permitted and is an OFFENCE". Presumably it makes Mother Nature cry, or something.</p>

<p>Anyway it was a nice 40km ride, although I almost got sunburned (as I wasn't wearing a shirt for most of the day). Actually, I suppose I should rub in the climate a bit more while I'm at it, as my sis tells me that it's been negative degrees with snow in Canberra.</p>

<p>So - Darwin has been 25-30 each day (including at night), and because it's the dry, the humidity has been quite moderate. I'm sure it gets a wee bit sticky in the wet, but right now it's bloody awesome!</p>

<p>It's also actually a surprisingly cosmopolitan city, due largely to it's proximity to Asia. Apparently it all shuts down during the wet, but right now it's bustling with markets and interesting folks from all walks of life.</p>

<p>Ok, back to the story; one more thing to relate. We headed to the night markets at Mindil beach last night, for a feed and a general sticky beak. The sunset was quite amazing (even by an old sunset cynic's standards), and I got some nice shots. A bit of pollution can work wonders for nature's art. All that Australia's photographers need now is a nice big volcanic eruption.</p>

<p>Anyway, we wandered around the markets for a while and I found plenty of odds and ends to take snaps of. The (presumably plaster) casts of baby's hands I found were somewhat disturbing. They brought to mind he baddie in Enter the Dragon. I also felt echoes of the original House of Wax (the classy one with Vincent Price, not the recent Paris Hilton abomination!).</p>

<p>So that's it from me this week. If you're incredibly bored, or just procrastinating and *really* don't want to get on with work, I've put all my old India travel stories from 2000 up on this website (<a href="india2000.php">click here to view</a>), as well as on Carl's site (<a href="http://www.and2makes4.com" target="_blank">www.and2makes4.com</a>). For the first time there are pictures to go with them too, so do feel free to check them out.</p>

<p>I'll also finally be organising some maps of my travels. Once these are done they'll go up on the website too, alongside each travel instalment.</p>

<p>Next week I'll be squeezing in some diving up here, and then heading out to some of the national parks round here (you may have heard of a place called Kakadu?) :)</p>

<p>Till then, take care!</p>

<p>This week's happy snaps:</p>
<!-- 
<ul>
<li><a href="?fileId=IMG_5973.JPG">Darwin CBD, such as it is!</a></li>
<li><a href="?fileId=IMG_6022.JPG">Budding computer nerd</a></li>
<li><a href="?fileId=IMG_6083.JPG">Amnesty International postcardesque</a></li>
<li><a href="?fileId=IMG_6107.JPG">How's the serenity...</a></li>
<li><a href="?fileId=IMG_6139.JPG">Bronzed babies, anyone?</a></li>
</ul>
 -->
<table width="800">
	<tr>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=IMG_5973.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20050812/IMG_5973.JPG' ALT='Darwin CBD, such as it is!'><BR>Darwin CBD, such as it is!</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=IMG_6022.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20050812/IMG_6022.JPG' ALT='Budding computer nerd'><BR>Budding computer nerd</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=IMG_6083.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20050812/IMG_6083.JPG' ALT='Amnesty International postcardesque'><BR>Amnesty International postcardesque</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=IMG_6107.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20050812/IMG_6107.JPG' ALT="How's the serenity..."><BR>How's the serenity...</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=IMG_6139.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20050812/IMG_6139.JPG' ALT='Bronzed babies, anyone?'><BR>Bronzed babies, anyone?</a>
	</td>
	</tr>
</table>

<br><br>
All images in this gallery:<br>
<table width='800'>
<tr>
</tr>
<tr><td><A ID='IMG_5956.JPG' href='slowingthepaceindarwin.php?fileId=IMG_5956.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050812/IMG_5956.JPG' ALT='IMG_5956.JPG'><BR>IMG_5956.JPG<br>80.95 KB</a><div class='inv'><br><a href='./images/20050812/IMG_5956.JPG' ALT='IMG_5956.JPG'>IMG_5956.JPG</a></div></td>
<td><A ID='IMG_5957.JPG' href='slowingthepaceindarwin.php?fileId=IMG_5957.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050812/IMG_5957.JPG' ALT='IMG_5957.JPG'><BR>IMG_5957.JPG<br>74.2 KB</a><div class='inv'><br><a href='./images/20050812/IMG_5957.JPG' ALT='IMG_5957.JPG'>IMG_5957.JPG</a></div></td>
<td><A ID='IMG_5958.JPG' href='slowingthepaceindarwin.php?fileId=IMG_5958.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050812/IMG_5958.JPG' ALT='IMG_5958.JPG'><BR>IMG_5958.JPG<br>85.38 KB</a><div class='inv'><br><a href='./images/20050812/IMG_5958.JPG' ALT='IMG_5958.JPG'>IMG_5958.JPG</a></div></td>
<td><A ID='IMG_5965.JPG' href='slowingthepaceindarwin.php?fileId=IMG_5965.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050812/IMG_5965.JPG' ALT='IMG_5965.JPG'><BR>IMG_5965.JPG<br>79.8 KB</a><div class='inv'><br><a href='./images/20050812/IMG_5965.JPG' ALT='IMG_5965.JPG'>IMG_5965.JPG</a></div></td>
<td><A ID='IMG_5970.JPG' href='slowingthepaceindarwin.php?fileId=IMG_5970.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050812/IMG_5970.JPG' ALT='IMG_5970.JPG'><BR>IMG_5970.JPG<br>84.57 KB</a><div class='inv'><br><a href='./images/20050812/IMG_5970.JPG' ALT='IMG_5970.JPG'>IMG_5970.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5971.JPG' href='slowingthepaceindarwin.php?fileId=IMG_5971.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050812/IMG_5971.JPG' ALT='IMG_5971.JPG'><BR>IMG_5971.JPG<br>65.28 KB</a><div class='inv'><br><a href='./images/20050812/IMG_5971.JPG' ALT='IMG_5971.JPG'>IMG_5971.JPG</a></div></td>
<td><A ID='IMG_5972.JPG' href='slowingthepaceindarwin.php?fileId=IMG_5972.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050812/IMG_5972.JPG' ALT='IMG_5972.JPG'><BR>IMG_5972.JPG<br>91.68 KB</a><div class='inv'><br><a href='./images/20050812/IMG_5972.JPG' ALT='IMG_5972.JPG'>IMG_5972.JPG</a></div></td>
<td><A ID='IMG_5973.JPG' href='slowingthepaceindarwin.php?fileId=IMG_5973.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050812/IMG_5973.JPG' ALT='IMG_5973.JPG'><BR>IMG_5973.JPG<br>40.36 KB</a><div class='inv'><br><a href='./images/20050812/IMG_5973.JPG' ALT='IMG_5973.JPG'>IMG_5973.JPG</a></div></td>
<td><A ID='IMG_5975.JPG' href='slowingthepaceindarwin.php?fileId=IMG_5975.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050812/IMG_5975.JPG' ALT='IMG_5975.JPG'><BR>IMG_5975.JPG<br>98.63 KB</a><div class='inv'><br><a href='./images/20050812/IMG_5975.JPG' ALT='IMG_5975.JPG'>IMG_5975.JPG</a></div></td>
<td><A ID='IMG_5976.JPG' href='slowingthepaceindarwin.php?fileId=IMG_5976.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050812/IMG_5976.JPG' ALT='IMG_5976.JPG'><BR>IMG_5976.JPG<br>121.01 KB</a><div class='inv'><br><a href='./images/20050812/IMG_5976.JPG' ALT='IMG_5976.JPG'>IMG_5976.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5978.JPG' href='slowingthepaceindarwin.php?fileId=IMG_5978.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050812/IMG_5978.JPG' ALT='IMG_5978.JPG'><BR>IMG_5978.JPG<br>93.43 KB</a><div class='inv'><br><a href='./images/20050812/IMG_5978.JPG' ALT='IMG_5978.JPG'>IMG_5978.JPG</a></div></td>
<td><A ID='IMG_5979.JPG' href='slowingthepaceindarwin.php?fileId=IMG_5979.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050812/IMG_5979.JPG' ALT='IMG_5979.JPG'><BR>IMG_5979.JPG<br>72.33 KB</a><div class='inv'><br><a href='./images/20050812/IMG_5979.JPG' ALT='IMG_5979.JPG'>IMG_5979.JPG</a></div></td>
<td><A ID='IMG_5980.JPG' href='slowingthepaceindarwin.php?fileId=IMG_5980.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050812/IMG_5980.JPG' ALT='IMG_5980.JPG'><BR>IMG_5980.JPG<br>60.33 KB</a><div class='inv'><br><a href='./images/20050812/IMG_5980.JPG' ALT='IMG_5980.JPG'>IMG_5980.JPG</a></div></td>
<td><A ID='IMG_5982.JPG' href='slowingthepaceindarwin.php?fileId=IMG_5982.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050812/IMG_5982.JPG' ALT='IMG_5982.JPG'><BR>IMG_5982.JPG<br>69.51 KB</a><div class='inv'><br><a href='./images/20050812/IMG_5982.JPG' ALT='IMG_5982.JPG'>IMG_5982.JPG</a></div></td>
<td><A ID='IMG_5983.JPG' href='slowingthepaceindarwin.php?fileId=IMG_5983.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050812/IMG_5983.JPG' ALT='IMG_5983.JPG'><BR>IMG_5983.JPG<br>59.66 KB</a><div class='inv'><br><a href='./images/20050812/IMG_5983.JPG' ALT='IMG_5983.JPG'>IMG_5983.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_6000.JPG' href='slowingthepaceindarwin.php?fileId=IMG_6000.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050812/IMG_6000.JPG' ALT='IMG_6000.JPG'><BR>IMG_6000.JPG<br>49 KB</a><div class='inv'><br><a href='./images/20050812/IMG_6000.JPG' ALT='IMG_6000.JPG'>IMG_6000.JPG</a></div></td>
<td><A ID='IMG_6006.JPG' href='slowingthepaceindarwin.php?fileId=IMG_6006.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050812/IMG_6006.JPG' ALT='IMG_6006.JPG'><BR>IMG_6006.JPG<br>44.12 KB</a><div class='inv'><br><a href='./images/20050812/IMG_6006.JPG' ALT='IMG_6006.JPG'>IMG_6006.JPG</a></div></td>
<td><A ID='IMG_6021.JPG' href='slowingthepaceindarwin.php?fileId=IMG_6021.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050812/IMG_6021.JPG' ALT='IMG_6021.JPG'><BR>IMG_6021.JPG<br>39.42 KB</a><div class='inv'><br><a href='./images/20050812/IMG_6021.JPG' ALT='IMG_6021.JPG'>IMG_6021.JPG</a></div></td>
<td><A ID='IMG_6022.JPG' href='slowingthepaceindarwin.php?fileId=IMG_6022.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050812/IMG_6022.JPG' ALT='IMG_6022.JPG'><BR>IMG_6022.JPG<br>56.68 KB</a><div class='inv'><br><a href='./images/20050812/IMG_6022.JPG' ALT='IMG_6022.JPG'>IMG_6022.JPG</a></div></td>
<td><A ID='IMG_6025.JPG' href='slowingthepaceindarwin.php?fileId=IMG_6025.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050812/IMG_6025.JPG' ALT='IMG_6025.JPG'><BR>IMG_6025.JPG<br>51.73 KB</a><div class='inv'><br><a href='./images/20050812/IMG_6025.JPG' ALT='IMG_6025.JPG'>IMG_6025.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_6027.JPG' href='slowingthepaceindarwin.php?fileId=IMG_6027.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050812/IMG_6027.JPG' ALT='IMG_6027.JPG'><BR>IMG_6027.JPG<br>102.76 KB</a><div class='inv'><br><a href='./images/20050812/IMG_6027.JPG' ALT='IMG_6027.JPG'>IMG_6027.JPG</a></div></td>
<td><A ID='IMG_6031.JPG' href='slowingthepaceindarwin.php?fileId=IMG_6031.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050812/IMG_6031.JPG' ALT='IMG_6031.JPG'><BR>IMG_6031.JPG<br>49.07 KB</a><div class='inv'><br><a href='./images/20050812/IMG_6031.JPG' ALT='IMG_6031.JPG'>IMG_6031.JPG</a></div></td>
<td><A ID='IMG_6032.JPG' href='slowingthepaceindarwin.php?fileId=IMG_6032.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050812/IMG_6032.JPG' ALT='IMG_6032.JPG'><BR>IMG_6032.JPG<br>59.43 KB</a><div class='inv'><br><a href='./images/20050812/IMG_6032.JPG' ALT='IMG_6032.JPG'>IMG_6032.JPG</a></div></td>
<td><A ID='IMG_6035.JPG' href='slowingthepaceindarwin.php?fileId=IMG_6035.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050812/IMG_6035.JPG' ALT='IMG_6035.JPG'><BR>IMG_6035.JPG<br>49.21 KB</a><div class='inv'><br><a href='./images/20050812/IMG_6035.JPG' ALT='IMG_6035.JPG'>IMG_6035.JPG</a></div></td>
<td><A ID='IMG_6039.JPG' href='slowingthepaceindarwin.php?fileId=IMG_6039.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050812/IMG_6039.JPG' ALT='IMG_6039.JPG'><BR>IMG_6039.JPG<br>40.44 KB</a><div class='inv'><br><a href='./images/20050812/IMG_6039.JPG' ALT='IMG_6039.JPG'>IMG_6039.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_6040.JPG' href='slowingthepaceindarwin.php?fileId=IMG_6040.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050812/IMG_6040.JPG' ALT='IMG_6040.JPG'><BR>IMG_6040.JPG<br>74.68 KB</a><div class='inv'><br><a href='./images/20050812/IMG_6040.JPG' ALT='IMG_6040.JPG'>IMG_6040.JPG</a></div></td>
<td><A ID='IMG_6042.JPG' href='slowingthepaceindarwin.php?fileId=IMG_6042.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050812/IMG_6042.JPG' ALT='IMG_6042.JPG'><BR>IMG_6042.JPG<br>37.65 KB</a><div class='inv'><br><a href='./images/20050812/IMG_6042.JPG' ALT='IMG_6042.JPG'>IMG_6042.JPG</a></div></td>
<td><A ID='IMG_6043.JPG' href='slowingthepaceindarwin.php?fileId=IMG_6043.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050812/IMG_6043.JPG' ALT='IMG_6043.JPG'><BR>IMG_6043.JPG<br>69.67 KB</a><div class='inv'><br><a href='./images/20050812/IMG_6043.JPG' ALT='IMG_6043.JPG'>IMG_6043.JPG</a></div></td>
<td><A ID='IMG_6044.JPG' href='slowingthepaceindarwin.php?fileId=IMG_6044.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050812/IMG_6044.JPG' ALT='IMG_6044.JPG'><BR>IMG_6044.JPG<br>57.74 KB</a><div class='inv'><br><a href='./images/20050812/IMG_6044.JPG' ALT='IMG_6044.JPG'>IMG_6044.JPG</a></div></td>
<td><A ID='IMG_6045.JPG' href='slowingthepaceindarwin.php?fileId=IMG_6045.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050812/IMG_6045.JPG' ALT='IMG_6045.JPG'><BR>IMG_6045.JPG<br>87.33 KB</a><div class='inv'><br><a href='./images/20050812/IMG_6045.JPG' ALT='IMG_6045.JPG'>IMG_6045.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_6046.JPG' href='slowingthepaceindarwin.php?fileId=IMG_6046.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050812/IMG_6046.JPG' ALT='IMG_6046.JPG'><BR>IMG_6046.JPG<br>79.12 KB</a><div class='inv'><br><a href='./images/20050812/IMG_6046.JPG' ALT='IMG_6046.JPG'>IMG_6046.JPG</a></div></td>
<td><A ID='IMG_6047.JPG' href='slowingthepaceindarwin.php?fileId=IMG_6047.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050812/IMG_6047.JPG' ALT='IMG_6047.JPG'><BR>IMG_6047.JPG<br>115.61 KB</a><div class='inv'><br><a href='./images/20050812/IMG_6047.JPG' ALT='IMG_6047.JPG'>IMG_6047.JPG</a></div></td>
<td><A ID='IMG_6048.JPG' href='slowingthepaceindarwin.php?fileId=IMG_6048.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050812/IMG_6048.JPG' ALT='IMG_6048.JPG'><BR>IMG_6048.JPG<br>105.31 KB</a><div class='inv'><br><a href='./images/20050812/IMG_6048.JPG' ALT='IMG_6048.JPG'>IMG_6048.JPG</a></div></td>
<td><A ID='IMG_6050.JPG' href='slowingthepaceindarwin.php?fileId=IMG_6050.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050812/IMG_6050.JPG' ALT='IMG_6050.JPG'><BR>IMG_6050.JPG<br>55.34 KB</a><div class='inv'><br><a href='./images/20050812/IMG_6050.JPG' ALT='IMG_6050.JPG'>IMG_6050.JPG</a></div></td>
<td><A ID='IMG_6051.JPG' href='slowingthepaceindarwin.php?fileId=IMG_6051.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050812/IMG_6051.JPG' ALT='IMG_6051.JPG'><BR>IMG_6051.JPG<br>58.29 KB</a><div class='inv'><br><a href='./images/20050812/IMG_6051.JPG' ALT='IMG_6051.JPG'>IMG_6051.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_6056.JPG' href='slowingthepaceindarwin.php?fileId=IMG_6056.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050812/IMG_6056.JPG' ALT='IMG_6056.JPG'><BR>IMG_6056.JPG<br>44.73 KB</a><div class='inv'><br><a href='./images/20050812/IMG_6056.JPG' ALT='IMG_6056.JPG'>IMG_6056.JPG</a></div></td>
<td><A ID='IMG_6059.JPG' href='slowingthepaceindarwin.php?fileId=IMG_6059.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050812/IMG_6059.JPG' ALT='IMG_6059.JPG'><BR>IMG_6059.JPG<br>68.46 KB</a><div class='inv'><br><a href='./images/20050812/IMG_6059.JPG' ALT='IMG_6059.JPG'>IMG_6059.JPG</a></div></td>
<td><A ID='IMG_6061.JPG' href='slowingthepaceindarwin.php?fileId=IMG_6061.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050812/IMG_6061.JPG' ALT='IMG_6061.JPG'><BR>IMG_6061.JPG<br>73.26 KB</a><div class='inv'><br><a href='./images/20050812/IMG_6061.JPG' ALT='IMG_6061.JPG'>IMG_6061.JPG</a></div></td>
<td><A ID='IMG_6063.JPG' href='slowingthepaceindarwin.php?fileId=IMG_6063.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050812/IMG_6063.JPG' ALT='IMG_6063.JPG'><BR>IMG_6063.JPG<br>59.63 KB</a><div class='inv'><br><a href='./images/20050812/IMG_6063.JPG' ALT='IMG_6063.JPG'>IMG_6063.JPG</a></div></td>
<td><A ID='IMG_6064.JPG' href='slowingthepaceindarwin.php?fileId=IMG_6064.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050812/IMG_6064.JPG' ALT='IMG_6064.JPG'><BR>IMG_6064.JPG<br>69.55 KB</a><div class='inv'><br><a href='./images/20050812/IMG_6064.JPG' ALT='IMG_6064.JPG'>IMG_6064.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_6066.JPG' href='slowingthepaceindarwin.php?fileId=IMG_6066.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050812/IMG_6066.JPG' ALT='IMG_6066.JPG'><BR>IMG_6066.JPG<br>62.47 KB</a><div class='inv'><br><a href='./images/20050812/IMG_6066.JPG' ALT='IMG_6066.JPG'>IMG_6066.JPG</a></div></td>
<td><A ID='IMG_6068.JPG' href='slowingthepaceindarwin.php?fileId=IMG_6068.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050812/IMG_6068.JPG' ALT='IMG_6068.JPG'><BR>IMG_6068.JPG<br>45.37 KB</a><div class='inv'><br><a href='./images/20050812/IMG_6068.JPG' ALT='IMG_6068.JPG'>IMG_6068.JPG</a></div></td>
<td><A ID='IMG_6071.JPG' href='slowingthepaceindarwin.php?fileId=IMG_6071.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050812/IMG_6071.JPG' ALT='IMG_6071.JPG'><BR>IMG_6071.JPG<br>49.41 KB</a><div class='inv'><br><a href='./images/20050812/IMG_6071.JPG' ALT='IMG_6071.JPG'>IMG_6071.JPG</a></div></td>
<td><A ID='IMG_6072.JPG' href='slowingthepaceindarwin.php?fileId=IMG_6072.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050812/IMG_6072.JPG' ALT='IMG_6072.JPG'><BR>IMG_6072.JPG<br>64.62 KB</a><div class='inv'><br><a href='./images/20050812/IMG_6072.JPG' ALT='IMG_6072.JPG'>IMG_6072.JPG</a></div></td>
<td><A ID='IMG_6073.JPG' href='slowingthepaceindarwin.php?fileId=IMG_6073.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050812/IMG_6073.JPG' ALT='IMG_6073.JPG'><BR>IMG_6073.JPG<br>35.67 KB</a><div class='inv'><br><a href='./images/20050812/IMG_6073.JPG' ALT='IMG_6073.JPG'>IMG_6073.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_6074.JPG' href='slowingthepaceindarwin.php?fileId=IMG_6074.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050812/IMG_6074.JPG' ALT='IMG_6074.JPG'><BR>IMG_6074.JPG<br>51.07 KB</a><div class='inv'><br><a href='./images/20050812/IMG_6074.JPG' ALT='IMG_6074.JPG'>IMG_6074.JPG</a></div></td>
<td><A ID='IMG_6077.JPG' href='slowingthepaceindarwin.php?fileId=IMG_6077.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050812/IMG_6077.JPG' ALT='IMG_6077.JPG'><BR>IMG_6077.JPG<br>52.69 KB</a><div class='inv'><br><a href='./images/20050812/IMG_6077.JPG' ALT='IMG_6077.JPG'>IMG_6077.JPG</a></div></td>
<td><A ID='IMG_6079.JPG' href='slowingthepaceindarwin.php?fileId=IMG_6079.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050812/IMG_6079.JPG' ALT='IMG_6079.JPG'><BR>IMG_6079.JPG<br>53.85 KB</a><div class='inv'><br><a href='./images/20050812/IMG_6079.JPG' ALT='IMG_6079.JPG'>IMG_6079.JPG</a></div></td>
<td><A ID='IMG_6080.JPG' href='slowingthepaceindarwin.php?fileId=IMG_6080.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050812/IMG_6080.JPG' ALT='IMG_6080.JPG'><BR>IMG_6080.JPG<br>57.86 KB</a><div class='inv'><br><a href='./images/20050812/IMG_6080.JPG' ALT='IMG_6080.JPG'>IMG_6080.JPG</a></div></td>
<td><A ID='IMG_6082.JPG' href='slowingthepaceindarwin.php?fileId=IMG_6082.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050812/IMG_6082.JPG' ALT='IMG_6082.JPG'><BR>IMG_6082.JPG<br>97.51 KB</a><div class='inv'><br><a href='./images/20050812/IMG_6082.JPG' ALT='IMG_6082.JPG'>IMG_6082.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_6083.JPG' href='slowingthepaceindarwin.php?fileId=IMG_6083.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050812/IMG_6083.JPG' ALT='IMG_6083.JPG'><BR>IMG_6083.JPG<br>56.43 KB</a><div class='inv'><br><a href='./images/20050812/IMG_6083.JPG' ALT='IMG_6083.JPG'>IMG_6083.JPG</a></div></td>
<td><A ID='IMG_6085.JPG' href='slowingthepaceindarwin.php?fileId=IMG_6085.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050812/IMG_6085.JPG' ALT='IMG_6085.JPG'><BR>IMG_6085.JPG<br>42.66 KB</a><div class='inv'><br><a href='./images/20050812/IMG_6085.JPG' ALT='IMG_6085.JPG'>IMG_6085.JPG</a></div></td>
<td><A ID='IMG_6087.JPG' href='slowingthepaceindarwin.php?fileId=IMG_6087.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050812/IMG_6087.JPG' ALT='IMG_6087.JPG'><BR>IMG_6087.JPG<br>38.54 KB</a><div class='inv'><br><a href='./images/20050812/IMG_6087.JPG' ALT='IMG_6087.JPG'>IMG_6087.JPG</a></div></td>
<td><A ID='IMG_6088.JPG' href='slowingthepaceindarwin.php?fileId=IMG_6088.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050812/IMG_6088.JPG' ALT='IMG_6088.JPG'><BR>IMG_6088.JPG<br>103.48 KB</a><div class='inv'><br><a href='./images/20050812/IMG_6088.JPG' ALT='IMG_6088.JPG'>IMG_6088.JPG</a></div></td>
<td><A ID='IMG_6097.JPG' href='slowingthepaceindarwin.php?fileId=IMG_6097.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050812/IMG_6097.JPG' ALT='IMG_6097.JPG'><BR>IMG_6097.JPG<br>27.84 KB</a><div class='inv'><br><a href='./images/20050812/IMG_6097.JPG' ALT='IMG_6097.JPG'>IMG_6097.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_6102.JPG' href='slowingthepaceindarwin.php?fileId=IMG_6102.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050812/IMG_6102.JPG' ALT='IMG_6102.JPG'><BR>IMG_6102.JPG<br>42.58 KB</a><div class='inv'><br><a href='./images/20050812/IMG_6102.JPG' ALT='IMG_6102.JPG'>IMG_6102.JPG</a></div></td>
<td><A ID='IMG_6104.JPG' href='slowingthepaceindarwin.php?fileId=IMG_6104.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050812/IMG_6104.JPG' ALT='IMG_6104.JPG'><BR>IMG_6104.JPG<br>61.02 KB</a><div class='inv'><br><a href='./images/20050812/IMG_6104.JPG' ALT='IMG_6104.JPG'>IMG_6104.JPG</a></div></td>
<td><A ID='IMG_6107.JPG' href='slowingthepaceindarwin.php?fileId=IMG_6107.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050812/IMG_6107.JPG' ALT='IMG_6107.JPG'><BR>IMG_6107.JPG<br>37.3 KB</a><div class='inv'><br><a href='./images/20050812/IMG_6107.JPG' ALT='IMG_6107.JPG'>IMG_6107.JPG</a></div></td>
<td><A ID='IMG_6110.JPG' href='slowingthepaceindarwin.php?fileId=IMG_6110.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050812/IMG_6110.JPG' ALT='IMG_6110.JPG'><BR>IMG_6110.JPG<br>35.25 KB</a><div class='inv'><br><a href='./images/20050812/IMG_6110.JPG' ALT='IMG_6110.JPG'>IMG_6110.JPG</a></div></td>
<td><A ID='IMG_6111.JPG' href='slowingthepaceindarwin.php?fileId=IMG_6111.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050812/IMG_6111.JPG' ALT='IMG_6111.JPG'><BR>IMG_6111.JPG<br>43.62 KB</a><div class='inv'><br><a href='./images/20050812/IMG_6111.JPG' ALT='IMG_6111.JPG'>IMG_6111.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_6113.JPG' href='slowingthepaceindarwin.php?fileId=IMG_6113.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050812/IMG_6113.JPG' ALT='IMG_6113.JPG'><BR>IMG_6113.JPG<br>56.81 KB</a><div class='inv'><br><a href='./images/20050812/IMG_6113.JPG' ALT='IMG_6113.JPG'>IMG_6113.JPG</a></div></td>
<td><A ID='IMG_6114.JPG' href='slowingthepaceindarwin.php?fileId=IMG_6114.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050812/IMG_6114.JPG' ALT='IMG_6114.JPG'><BR>IMG_6114.JPG<br>48.77 KB</a><div class='inv'><br><a href='./images/20050812/IMG_6114.JPG' ALT='IMG_6114.JPG'>IMG_6114.JPG</a></div></td>
<td><A ID='IMG_6116.JPG' href='slowingthepaceindarwin.php?fileId=IMG_6116.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050812/IMG_6116.JPG' ALT='IMG_6116.JPG'><BR>IMG_6116.JPG<br>77.2 KB</a><div class='inv'><br><a href='./images/20050812/IMG_6116.JPG' ALT='IMG_6116.JPG'>IMG_6116.JPG</a></div></td>
<td><A ID='IMG_6118.JPG' href='slowingthepaceindarwin.php?fileId=IMG_6118.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050812/IMG_6118.JPG' ALT='IMG_6118.JPG'><BR>IMG_6118.JPG<br>38.02 KB</a><div class='inv'><br><a href='./images/20050812/IMG_6118.JPG' ALT='IMG_6118.JPG'>IMG_6118.JPG</a></div></td>
<td><A ID='IMG_6123.JPG' href='slowingthepaceindarwin.php?fileId=IMG_6123.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050812/IMG_6123.JPG' ALT='IMG_6123.JPG'><BR>IMG_6123.JPG<br>68.82 KB</a><div class='inv'><br><a href='./images/20050812/IMG_6123.JPG' ALT='IMG_6123.JPG'>IMG_6123.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_6125.JPG' href='slowingthepaceindarwin.php?fileId=IMG_6125.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050812/IMG_6125.JPG' ALT='IMG_6125.JPG'><BR>IMG_6125.JPG<br>94.31 KB</a><div class='inv'><br><a href='./images/20050812/IMG_6125.JPG' ALT='IMG_6125.JPG'>IMG_6125.JPG</a></div></td>
<td><A ID='IMG_6126.JPG' href='slowingthepaceindarwin.php?fileId=IMG_6126.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050812/IMG_6126.JPG' ALT='IMG_6126.JPG'><BR>IMG_6126.JPG<br>48.49 KB</a><div class='inv'><br><a href='./images/20050812/IMG_6126.JPG' ALT='IMG_6126.JPG'>IMG_6126.JPG</a></div></td>
<td><A ID='IMG_6127.JPG' href='slowingthepaceindarwin.php?fileId=IMG_6127.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050812/IMG_6127.JPG' ALT='IMG_6127.JPG'><BR>IMG_6127.JPG<br>85.05 KB</a><div class='inv'><br><a href='./images/20050812/IMG_6127.JPG' ALT='IMG_6127.JPG'>IMG_6127.JPG</a></div></td>
<td><A ID='IMG_6128.JPG' href='slowingthepaceindarwin.php?fileId=IMG_6128.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050812/IMG_6128.JPG' ALT='IMG_6128.JPG'><BR>IMG_6128.JPG<br>55.44 KB</a><div class='inv'><br><a href='./images/20050812/IMG_6128.JPG' ALT='IMG_6128.JPG'>IMG_6128.JPG</a></div></td>
<td><A ID='IMG_6131.JPG' href='slowingthepaceindarwin.php?fileId=IMG_6131.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050812/IMG_6131.JPG' ALT='IMG_6131.JPG'><BR>IMG_6131.JPG<br>64.79 KB</a><div class='inv'><br><a href='./images/20050812/IMG_6131.JPG' ALT='IMG_6131.JPG'>IMG_6131.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_6132.JPG' href='slowingthepaceindarwin.php?fileId=IMG_6132.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050812/IMG_6132.JPG' ALT='IMG_6132.JPG'><BR>IMG_6132.JPG<br>77.58 KB</a><div class='inv'><br><a href='./images/20050812/IMG_6132.JPG' ALT='IMG_6132.JPG'>IMG_6132.JPG</a></div></td>
<td><A ID='IMG_6134.JPG' href='slowingthepaceindarwin.php?fileId=IMG_6134.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050812/IMG_6134.JPG' ALT='IMG_6134.JPG'><BR>IMG_6134.JPG<br>119.04 KB</a><div class='inv'><br><a href='./images/20050812/IMG_6134.JPG' ALT='IMG_6134.JPG'>IMG_6134.JPG</a></div></td>
<td><A ID='IMG_6135.JPG' href='slowingthepaceindarwin.php?fileId=IMG_6135.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050812/IMG_6135.JPG' ALT='IMG_6135.JPG'><BR>IMG_6135.JPG<br>86.46 KB</a><div class='inv'><br><a href='./images/20050812/IMG_6135.JPG' ALT='IMG_6135.JPG'>IMG_6135.JPG</a></div></td>
<td><A ID='IMG_6136.JPG' href='slowingthepaceindarwin.php?fileId=IMG_6136.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050812/IMG_6136.JPG' ALT='IMG_6136.JPG'><BR>IMG_6136.JPG<br>90.99 KB</a><div class='inv'><br><a href='./images/20050812/IMG_6136.JPG' ALT='IMG_6136.JPG'>IMG_6136.JPG</a></div></td>
<td><A ID='IMG_6138.JPG' href='slowingthepaceindarwin.php?fileId=IMG_6138.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050812/IMG_6138.JPG' ALT='IMG_6138.JPG'><BR>IMG_6138.JPG<br>78.99 KB</a><div class='inv'><br><a href='./images/20050812/IMG_6138.JPG' ALT='IMG_6138.JPG'>IMG_6138.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_6139.JPG' href='slowingthepaceindarwin.php?fileId=IMG_6139.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050812/IMG_6139.JPG' ALT='IMG_6139.JPG'><BR>IMG_6139.JPG<br>68.83 KB</a><div class='inv'><br><a href='./images/20050812/IMG_6139.JPG' ALT='IMG_6139.JPG'>IMG_6139.JPG</a></div></td>
<td><A ID='IMG_6140.JPG' href='slowingthepaceindarwin.php?fileId=IMG_6140.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050812/IMG_6140.JPG' ALT='IMG_6140.JPG'><BR>IMG_6140.JPG<br>43.54 KB</a><div class='inv'><br><a href='./images/20050812/IMG_6140.JPG' ALT='IMG_6140.JPG'>IMG_6140.JPG</a></div></td>
<td><A ID='IMG_6141.JPG' href='slowingthepaceindarwin.php?fileId=IMG_6141.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050812/IMG_6141.JPG' ALT='IMG_6141.JPG'><BR>IMG_6141.JPG<br>97.95 KB</a><div class='inv'><br><a href='./images/20050812/IMG_6141.JPG' ALT='IMG_6141.JPG'>IMG_6141.JPG</a></div></td>
<td><A ID='IMG_6142.JPG' href='slowingthepaceindarwin.php?fileId=IMG_6142.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050812/IMG_6142.JPG' ALT='IMG_6142.JPG'><BR>IMG_6142.JPG<br>75.25 KB</a><div class='inv'><br><a href='./images/20050812/IMG_6142.JPG' ALT='IMG_6142.JPG'>IMG_6142.JPG</a></div></td>
<td><A ID='IMG_6143.JPG' href='slowingthepaceindarwin.php?fileId=IMG_6143.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050812/IMG_6143.JPG' ALT='IMG_6143.JPG'><BR>IMG_6143.JPG<br>92.53 KB</a><div class='inv'><br><a href='./images/20050812/IMG_6143.JPG' ALT='IMG_6143.JPG'>IMG_6143.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_6144.JPG' href='slowingthepaceindarwin.php?fileId=IMG_6144.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050812/IMG_6144.JPG' ALT='IMG_6144.JPG'><BR>IMG_6144.JPG<br>82.55 KB</a><div class='inv'><br><a href='./images/20050812/IMG_6144.JPG' ALT='IMG_6144.JPG'>IMG_6144.JPG</a></div></td>
<td><A ID='IMG_6145.JPG' href='slowingthepaceindarwin.php?fileId=IMG_6145.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050812/IMG_6145.JPG' ALT='IMG_6145.JPG'><BR>IMG_6145.JPG<br>45.7 KB</a><div class='inv'><br><a href='./images/20050812/IMG_6145.JPG' ALT='IMG_6145.JPG'>IMG_6145.JPG</a></div></td>
<td><A ID='IMG_6149.JPG' href='slowingthepaceindarwin.php?fileId=IMG_6149.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050812/IMG_6149.JPG' ALT='IMG_6149.JPG'><BR>IMG_6149.JPG<br>50.24 KB</a><div class='inv'><br><a href='./images/20050812/IMG_6149.JPG' ALT='IMG_6149.JPG'>IMG_6149.JPG</a></div></td>
<td><A ID='IMG_6152.JPG' href='slowingthepaceindarwin.php?fileId=IMG_6152.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050812/IMG_6152.JPG' ALT='IMG_6152.JPG'><BR>IMG_6152.JPG<br>61.83 KB</a><div class='inv'><br><a href='./images/20050812/IMG_6152.JPG' ALT='IMG_6152.JPG'>IMG_6152.JPG</a></div></td>
<td><A ID='IMG_6154.JPG' href='slowingthepaceindarwin.php?fileId=IMG_6154.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050812/IMG_6154.JPG' ALT='IMG_6154.JPG'><BR>IMG_6154.JPG<br>35.68 KB</a><div class='inv'><br><a href='./images/20050812/IMG_6154.JPG' ALT='IMG_6154.JPG'>IMG_6154.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_6155.JPG' href='slowingthepaceindarwin.php?fileId=IMG_6155.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050812/IMG_6155.JPG' ALT='IMG_6155.JPG'><BR>IMG_6155.JPG<br>75.64 KB</a><div class='inv'><br><a href='./images/20050812/IMG_6155.JPG' ALT='IMG_6155.JPG'>IMG_6155.JPG</a></div></td>
<td><A ID='IMG_6156.JPG' href='slowingthepaceindarwin.php?fileId=IMG_6156.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050812/IMG_6156.JPG' ALT='IMG_6156.JPG'><BR>IMG_6156.JPG<br>49.93 KB</a><div class='inv'><br><a href='./images/20050812/IMG_6156.JPG' ALT='IMG_6156.JPG'>IMG_6156.JPG</a></div></td>
<td><A ID='IMG_6158.JPG' href='slowingthepaceindarwin.php?fileId=IMG_6158.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050812/IMG_6158.JPG' ALT='IMG_6158.JPG'><BR>IMG_6158.JPG<br>48.31 KB</a><div class='inv'><br><a href='./images/20050812/IMG_6158.JPG' ALT='IMG_6158.JPG'>IMG_6158.JPG</a></div></td>
<td><A ID='IMG_6161.JPG' href='slowingthepaceindarwin.php?fileId=IMG_6161.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050812/IMG_6161.JPG' ALT='IMG_6161.JPG'><BR>IMG_6161.JPG<br>55.41 KB</a><div class='inv'><br><a href='./images/20050812/IMG_6161.JPG' ALT='IMG_6161.JPG'>IMG_6161.JPG</a></div></td>
<td><A ID='IMG_6162.JPG' href='slowingthepaceindarwin.php?fileId=IMG_6162.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050812/IMG_6162.JPG' ALT='IMG_6162.JPG'><BR>IMG_6162.JPG<br>47.97 KB</a><div class='inv'><br><a href='./images/20050812/IMG_6162.JPG' ALT='IMG_6162.JPG'>IMG_6162.JPG</a></div></td>
</tr>
</table>	</div>
</div>
</body>
</html>