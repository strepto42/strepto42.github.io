<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - Cunningham's Gap - Image Gallery</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="Image Gallery">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="Pictures of my 28th Birthday party complete with Sparkler Bomb" href='28th.php'>28th Birthday</a></li>
<li><a title="Pictures of my 30th Birthday party" href='30th.php'>30th Birthday</a></li>
<li><a title="Michael Shamgar and Lindsay Halamek's 30th birthday bash photos" href='sl30th.php'>Shams & Linds' 30th</a></li>
<li><a title="Pictures of Andy Marinos's new flat, cat Toby, and Mum Pam Swain" href='andycatandflat.php'>Andy's Cat & Flat</a></li>
<li><a title="Pictures of a visit to Stephen Jackson's Farm" href='jackovisit.php'>Jacko's Farm</a></li>
<li><a title="Pictures taken at the Peace Convergence action in Rockhampton and Yeppoon in June 2005 to protest the joint US Australia military exercises (Operation Talisman Sabre)" href='peaceconvergence.php'>Peace Convergence</a></li>
<li><a title="Sydney trip - April '06" href='bridges.php'>Sydney, April 06</a></li>
<li><a title="Pics of Naima's 28th birthday dinner" href='mim28th.php'>Naima's 28th</a></li>
<li><a title="Brisbane CBD and the Story Bridge" href='brisbanepics1.php'>Brissie by Night 1</a></li>
<li><a title="Lamington National Park" href='lamington.php'>Lamington NP</a></li>
<li><a title="Various creatures and views from our Brisbane back yard" href='backyard.php'>Backyard Creatures</a></li>
<li><a title="Opening day of the Eleanor Schonell (Green) Bridge" href='greenbridge.php'>Green Bridge</a></li>
<li><a title="Pictutres from the 2006 Woodford Folk Festival" href='woodford0607.php'>Woodford 2006-2007</a></li>
<li><a title="One Cute Puppy" href='jezebel.php'>Jezebel</a></li>
<li><a title="Climbing at Kangaroo Point Cliffs" href='kangaroopt1.php'>Heather's Visit</a></li>
<li><a title="0x0021st (33rd) birthday celebrations" href='0x0021st.php'>0x0021st Birthday</a></li>
<li><a title="Nuptial photography" href='guyandalison.php'>Guy and Alison's Wedding</a></li>
<li><a title="Pictures from the 2007 Woodford Folk Festival" href='woodford0708.php'>Woodford 2007-2008</a></li>
<li><a title="Image gallery" href='sydneytrip0802.php'>Sydney & Yacaaba Head</a></li>
<li><a title="An impressive show by nature" href='lightning.php'>Thunderstorm Moonrise</a></li>
<li><a title="Frightening pictures of a shrinking beard" href='debearding.php'>De-bearding</a></li>
<li><a title="More Nuptial Photography" href='michaelandkaren.php'>Michael and Karen's Wedding</a></li>
<li><a title="A night of celebration" href='andrews21st.php'>Andrew's 21st</a></li>
<li><a title="Image Gallery" href='bloodyknee.php'>Bloody Knee</a></li>
<li><a title="Image Gallery" href='tyesbirthday.php'>Tye's Birthday</a></li>
<li><a title="Image Gallery" href='lasersocialising.php'>Laser Socialising</a></li>
<li><a title="Image Gallery" href='heatherandevan.php'>Heather and Evan's Wedding</a></li>
<li><a title="Image Gallery" href='woodford0809.php'>Woodford 2008-2009</a></li>
<li><a title="Image Gallery" href='allyandben.php'>Ally and Ben's Wedding</a></li>
<li><a title="Image Gallery" href='annes30th.php'>Anne's 30th</a></li>
<li><a title="Image Gallery" href='possumcreek.php'>Possum Creek</a></li>
<li><a title="Image Gallery" href='jamnight.php'>Jam Night</a></li>
<li><div class='activemenu'>Cunningham's Gap</div></li>
<li><a title="Image Gallery" href='bigcat.php'>Diving on Big Cat</a></li>
<li><a title="Images from my birthday jam" href='birthdayjam.php'>Music, mayhem and merriment</a></li>
<li><a title="Image Gallery" href='fuzzypolaroidpics.php'>Fuzzy Polaroid</a></li>
<li><a title="Image Gallery" href='zombiewalk2009.php'>2009 Zombie Walk</a></li>
<li> </li><br><li>Or go back to:</li><li><a title='Picture galleries' href="pictures.php">Photography</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>Cunningham's Gap</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Picture galleries' href="pictures.php">Photography</a> > <a title='Image Gallery' href="cunninghamsgap.php">Cunningham's Gap</a>
<br><br>		

<p>Ben, Moz and I spent a very relaxing day in the bush exploring Cunningham's Gap, about an hour southwest of Brisbane. The birds proved to be quite elusive but we still got a few nice shots, including some Bell Miners, Scrub Wrens and Thornbills (I think).</p>
<br><br>
All images in this gallery:<br>
<table width='800'>
<tr>
</tr>
<tr><td><A ID='IMG_6657.JPG' href='cunninghamsgap.php?fileId=IMG_6657.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20090725/IMG_6657.JPG' ALT='IMG_6657.JPG'><BR>IMG_6657.JPG<br>108.64 KB</a><div class='inv'><br><a href='./images/20090725/IMG_6657.JPG' ALT='IMG_6657.JPG'>IMG_6657.JPG</a></div></td>
<td><A ID='IMG_6658.JPG' href='cunninghamsgap.php?fileId=IMG_6658.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20090725/IMG_6658.JPG' ALT='IMG_6658.JPG'><BR>IMG_6658.JPG<br>105.33 KB</a><div class='inv'><br><a href='./images/20090725/IMG_6658.JPG' ALT='IMG_6658.JPG'>IMG_6658.JPG</a></div></td>
<td><A ID='IMG_6673.JPG' href='cunninghamsgap.php?fileId=IMG_6673.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20090725/IMG_6673.JPG' ALT='IMG_6673.JPG'><BR>IMG_6673.JPG<br>83.16 KB</a><div class='inv'><br><a href='./images/20090725/IMG_6673.JPG' ALT='IMG_6673.JPG'>IMG_6673.JPG</a></div></td>
<td><A ID='IMG_6675.JPG' href='cunninghamsgap.php?fileId=IMG_6675.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20090725/IMG_6675.JPG' ALT='IMG_6675.JPG'><BR>IMG_6675.JPG<br>96.22 KB</a><div class='inv'><br><a href='./images/20090725/IMG_6675.JPG' ALT='IMG_6675.JPG'>IMG_6675.JPG</a></div></td>
<td><A ID='IMG_6676.JPG' href='cunninghamsgap.php?fileId=IMG_6676.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20090725/IMG_6676.JPG' ALT='IMG_6676.JPG'><BR>IMG_6676.JPG<br>70.51 KB</a><div class='inv'><br><a href='./images/20090725/IMG_6676.JPG' ALT='IMG_6676.JPG'>IMG_6676.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_6678.JPG' href='cunninghamsgap.php?fileId=IMG_6678.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20090725/IMG_6678.JPG' ALT='IMG_6678.JPG'><BR>IMG_6678.JPG<br>103.57 KB</a><div class='inv'><br><a href='./images/20090725/IMG_6678.JPG' ALT='IMG_6678.JPG'>IMG_6678.JPG</a></div></td>
<td><A ID='IMG_6679.JPG' href='cunninghamsgap.php?fileId=IMG_6679.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20090725/IMG_6679.JPG' ALT='IMG_6679.JPG'><BR>IMG_6679.JPG<br>122.92 KB</a><div class='inv'><br><a href='./images/20090725/IMG_6679.JPG' ALT='IMG_6679.JPG'>IMG_6679.JPG</a></div></td>
<td><A ID='IMG_6680.JPG' href='cunninghamsgap.php?fileId=IMG_6680.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20090725/IMG_6680.JPG' ALT='IMG_6680.JPG'><BR>IMG_6680.JPG<br>115.77 KB</a><div class='inv'><br><a href='./images/20090725/IMG_6680.JPG' ALT='IMG_6680.JPG'>IMG_6680.JPG</a></div></td>
<td><A ID='IMG_6684.JPG' href='cunninghamsgap.php?fileId=IMG_6684.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20090725/IMG_6684.JPG' ALT='IMG_6684.JPG'><BR>IMG_6684.JPG<br>81.05 KB</a><div class='inv'><br><a href='./images/20090725/IMG_6684.JPG' ALT='IMG_6684.JPG'>IMG_6684.JPG</a></div></td>
<td><A ID='IMG_6686.JPG' href='cunninghamsgap.php?fileId=IMG_6686.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20090725/IMG_6686.JPG' ALT='IMG_6686.JPG'><BR>IMG_6686.JPG<br>67.63 KB</a><div class='inv'><br><a href='./images/20090725/IMG_6686.JPG' ALT='IMG_6686.JPG'>IMG_6686.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_6687.JPG' href='cunninghamsgap.php?fileId=IMG_6687.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20090725/IMG_6687.JPG' ALT='IMG_6687.JPG'><BR>IMG_6687.JPG<br>67.2 KB</a><div class='inv'><br><a href='./images/20090725/IMG_6687.JPG' ALT='IMG_6687.JPG'>IMG_6687.JPG</a></div></td>
<td><A ID='IMG_6688.JPG' href='cunninghamsgap.php?fileId=IMG_6688.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20090725/IMG_6688.JPG' ALT='IMG_6688.JPG'><BR>IMG_6688.JPG<br>71.6 KB</a><div class='inv'><br><a href='./images/20090725/IMG_6688.JPG' ALT='IMG_6688.JPG'>IMG_6688.JPG</a></div></td>
<td><A ID='IMG_6689.JPG' href='cunninghamsgap.php?fileId=IMG_6689.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20090725/IMG_6689.JPG' ALT='IMG_6689.JPG'><BR>IMG_6689.JPG<br>75.68 KB</a><div class='inv'><br><a href='./images/20090725/IMG_6689.JPG' ALT='IMG_6689.JPG'>IMG_6689.JPG</a></div></td>
<td><A ID='IMG_6690.JPG' href='cunninghamsgap.php?fileId=IMG_6690.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20090725/IMG_6690.JPG' ALT='IMG_6690.JPG'><BR>IMG_6690.JPG<br>97.29 KB</a><div class='inv'><br><a href='./images/20090725/IMG_6690.JPG' ALT='IMG_6690.JPG'>IMG_6690.JPG</a></div></td>
<td><A ID='IMG_6691.JPG' href='cunninghamsgap.php?fileId=IMG_6691.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20090725/IMG_6691.JPG' ALT='IMG_6691.JPG'><BR>IMG_6691.JPG<br>67.2 KB</a><div class='inv'><br><a href='./images/20090725/IMG_6691.JPG' ALT='IMG_6691.JPG'>IMG_6691.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_6692.JPG' href='cunninghamsgap.php?fileId=IMG_6692.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20090725/IMG_6692.JPG' ALT='IMG_6692.JPG'><BR>IMG_6692.JPG<br>51.67 KB</a><div class='inv'><br><a href='./images/20090725/IMG_6692.JPG' ALT='IMG_6692.JPG'>IMG_6692.JPG</a></div></td>
<td><A ID='IMG_6696.JPG' href='cunninghamsgap.php?fileId=IMG_6696.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20090725/IMG_6696.JPG' ALT='IMG_6696.JPG'><BR>IMG_6696.JPG<br>130.72 KB</a><div class='inv'><br><a href='./images/20090725/IMG_6696.JPG' ALT='IMG_6696.JPG'>IMG_6696.JPG</a></div></td>
<td><A ID='IMG_6698.JPG' href='cunninghamsgap.php?fileId=IMG_6698.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20090725/IMG_6698.JPG' ALT='IMG_6698.JPG'><BR>IMG_6698.JPG<br>133.62 KB</a><div class='inv'><br><a href='./images/20090725/IMG_6698.JPG' ALT='IMG_6698.JPG'>IMG_6698.JPG</a></div></td>
<td><A ID='IMG_6699.JPG' href='cunninghamsgap.php?fileId=IMG_6699.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20090725/IMG_6699.JPG' ALT='IMG_6699.JPG'><BR>IMG_6699.JPG<br>70.15 KB</a><div class='inv'><br><a href='./images/20090725/IMG_6699.JPG' ALT='IMG_6699.JPG'>IMG_6699.JPG</a></div></td>
<td><A ID='IMG_6700.JPG' href='cunninghamsgap.php?fileId=IMG_6700.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20090725/IMG_6700.JPG' ALT='Thornbill?'><BR>Thornbill?<br>59.32 KB</a><div class='inv'><br><a href='./images/20090725/IMG_6700.JPG' ALT='Thornbill?'>Thornbill?</a></div></td>
</tr>
<tr><td><A ID='IMG_6711.JPG' href='cunninghamsgap.php?fileId=IMG_6711.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20090725/IMG_6711.JPG' ALT='White Browed Scrub Wren'><BR>White Browed Scrub Wren<br>66.94 KB</a><div class='inv'><br><a href='./images/20090725/IMG_6711.JPG' ALT='White Browed Scrub Wren'>White Browed Scrub Wren</a></div></td>
<td><A ID='IMG_6720.JPG' href='cunninghamsgap.php?fileId=IMG_6720.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20090725/IMG_6720.JPG' ALT='White Browed Scrub Wren'><BR>White Browed Scrub Wren<br>57.54 KB</a><div class='inv'><br><a href='./images/20090725/IMG_6720.JPG' ALT='White Browed Scrub Wren'>White Browed Scrub Wren</a></div></td>
<td><A ID='IMG_6731.JPG' href='cunninghamsgap.php?fileId=IMG_6731.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20090725/IMG_6731.JPG' ALT='IMG_6731.JPG'><BR>IMG_6731.JPG<br>52.76 KB</a><div class='inv'><br><a href='./images/20090725/IMG_6731.JPG' ALT='IMG_6731.JPG'>IMG_6731.JPG</a></div></td>
<td><A ID='IMG_6732.JPG' href='cunninghamsgap.php?fileId=IMG_6732.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20090725/IMG_6732.JPG' ALT='IMG_6732.JPG'><BR>IMG_6732.JPG<br>117.6 KB</a><div class='inv'><br><a href='./images/20090725/IMG_6732.JPG' ALT='IMG_6732.JPG'>IMG_6732.JPG</a></div></td>
<td><A ID='IMG_6740.JPG' href='cunninghamsgap.php?fileId=IMG_6740.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20090725/IMG_6740.JPG' ALT='IMG_6740.JPG'><BR>IMG_6740.JPG<br>60.16 KB</a><div class='inv'><br><a href='./images/20090725/IMG_6740.JPG' ALT='IMG_6740.JPG'>IMG_6740.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_6742.JPG' href='cunninghamsgap.php?fileId=IMG_6742.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20090725/IMG_6742.JPG' ALT='IMG_6742.JPG'><BR>IMG_6742.JPG<br>103.4 KB</a><div class='inv'><br><a href='./images/20090725/IMG_6742.JPG' ALT='IMG_6742.JPG'>IMG_6742.JPG</a></div></td>
<td><A ID='IMG_6743.JPG' href='cunninghamsgap.php?fileId=IMG_6743.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20090725/IMG_6743.JPG' ALT='IMG_6743.JPG'><BR>IMG_6743.JPG<br>105.25 KB</a><div class='inv'><br><a href='./images/20090725/IMG_6743.JPG' ALT='IMG_6743.JPG'>IMG_6743.JPG</a></div></td>
<td><A ID='IMG_6744.JPG' href='cunninghamsgap.php?fileId=IMG_6744.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20090725/IMG_6744.JPG' ALT='Eedjot Ben'><BR>Eedjot Ben<br>71.66 KB</a><div class='inv'><br><a href='./images/20090725/IMG_6744.JPG' ALT='Eedjot Ben'>Eedjot Ben</a></div></td>
<td><A ID='IMG_6745.JPG' href='cunninghamsgap.php?fileId=IMG_6745.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20090725/IMG_6745.JPG' ALT='Mysterious Jedi Moz'><BR>Mysterious Jedi Moz<br>65.59 KB</a><div class='inv'><br><a href='./images/20090725/IMG_6745.JPG' ALT='Mysterious Jedi Moz'>Mysterious Jedi Moz</a></div></td>
<td><A ID='IMG_6748.JPG' href='cunninghamsgap.php?fileId=IMG_6748.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20090725/IMG_6748.JPG' ALT='IMG_6748.JPG'><BR>IMG_6748.JPG<br>72.74 KB</a><div class='inv'><br><a href='./images/20090725/IMG_6748.JPG' ALT='IMG_6748.JPG'>IMG_6748.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_6749.JPG' href='cunninghamsgap.php?fileId=IMG_6749.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20090725/IMG_6749.JPG' ALT='IMG_6749.JPG'><BR>IMG_6749.JPG<br>107.98 KB</a><div class='inv'><br><a href='./images/20090725/IMG_6749.JPG' ALT='IMG_6749.JPG'>IMG_6749.JPG</a></div></td>
<td><A ID='IMG_6754.JPG' href='cunninghamsgap.php?fileId=IMG_6754.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20090725/IMG_6754.JPG' ALT='IMG_6754.JPG'><BR>IMG_6754.JPG<br>96.03 KB</a><div class='inv'><br><a href='./images/20090725/IMG_6754.JPG' ALT='IMG_6754.JPG'>IMG_6754.JPG</a></div></td>
<td><A ID='IMG_6803.JPG' href='cunninghamsgap.php?fileId=IMG_6803.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20090725/IMG_6803.JPG' ALT='IMG_6803.JPG'><BR>IMG_6803.JPG<br>76.94 KB</a><div class='inv'><br><a href='./images/20090725/IMG_6803.JPG' ALT='IMG_6803.JPG'>IMG_6803.JPG</a></div></td>
<td><A ID='IMG_6804.JPG' href='cunninghamsgap.php?fileId=IMG_6804.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20090725/IMG_6804.JPG' ALT='IMG_6804.JPG'><BR>IMG_6804.JPG<br>79.06 KB</a><div class='inv'><br><a href='./images/20090725/IMG_6804.JPG' ALT='IMG_6804.JPG'>IMG_6804.JPG</a></div></td>
<td><A ID='IMG_6840.JPG' href='cunninghamsgap.php?fileId=IMG_6840.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20090725/IMG_6840.JPG' ALT='Bell Miner (Bellbird)'><BR>Bell Miner (Bellbird)<br>82.53 KB</a><div class='inv'><br><a href='./images/20090725/IMG_6840.JPG' ALT='Bell Miner (Bellbird)'>Bell Miner (Bellbird)</a></div></td>
</tr>
<tr><td><A ID='IMG_6846.JPG' href='cunninghamsgap.php?fileId=IMG_6846.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20090725/IMG_6846.JPG' ALT='Bell Miner (Bellbird)'><BR>Bell Miner (Bellbird)<br>78.72 KB</a><div class='inv'><br><a href='./images/20090725/IMG_6846.JPG' ALT='Bell Miner (Bellbird)'>Bell Miner (Bellbird)</a></div></td>
<td><A ID='IMG_6849.JPG' href='cunninghamsgap.php?fileId=IMG_6849.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20090725/IMG_6849.JPG' ALT='Bell Miner (Bellbird)'><BR>Bell Miner (Bellbird)<br>77.95 KB</a><div class='inv'><br><a href='./images/20090725/IMG_6849.JPG' ALT='Bell Miner (Bellbird)'>Bell Miner (Bellbird)</a></div></td>
<td><A ID='IMG_6852.JPG' href='cunninghamsgap.php?fileId=IMG_6852.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20090725/IMG_6852.JPG' ALT='Bell Miner (Bellbird)'><BR>Bell Miner (Bellbird)<br>61.52 KB</a><div class='inv'><br><a href='./images/20090725/IMG_6852.JPG' ALT='Bell Miner (Bellbird)'>Bell Miner (Bellbird)</a></div></td>
<td><A ID='IMG_6859.JPG' href='cunninghamsgap.php?fileId=IMG_6859.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20090725/IMG_6859.JPG' ALT='Bell Miner (Bellbird)'><BR>Bell Miner (Bellbird)<br>77.46 KB</a><div class='inv'><br><a href='./images/20090725/IMG_6859.JPG' ALT='Bell Miner (Bellbird)'>Bell Miner (Bellbird)</a></div></td>
<td><A ID='IMG_6870.JPG' href='cunninghamsgap.php?fileId=IMG_6870.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20090725/IMG_6870.JPG' ALT='IMG_6870.JPG'><BR>IMG_6870.JPG<br>81.49 KB</a><div class='inv'><br><a href='./images/20090725/IMG_6870.JPG' ALT='IMG_6870.JPG'>IMG_6870.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_6873.JPG' href='cunninghamsgap.php?fileId=IMG_6873.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20090725/IMG_6873.JPG' ALT='IMG_6873.JPG'><BR>IMG_6873.JPG<br>83.36 KB</a><div class='inv'><br><a href='./images/20090725/IMG_6873.JPG' ALT='IMG_6873.JPG'>IMG_6873.JPG</a></div></td>
<td><A ID='IMG_6878.JPG' href='cunninghamsgap.php?fileId=IMG_6878.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20090725/IMG_6878.JPG' ALT='IMG_6878.JPG'><BR>IMG_6878.JPG<br>74.29 KB</a><div class='inv'><br><a href='./images/20090725/IMG_6878.JPG' ALT='IMG_6878.JPG'>IMG_6878.JPG</a></div></td>
<td><A ID='IMG_6880.JPG' href='cunninghamsgap.php?fileId=IMG_6880.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20090725/IMG_6880.JPG' ALT='IMG_6880.JPG'><BR>IMG_6880.JPG<br>71.51 KB</a><div class='inv'><br><a href='./images/20090725/IMG_6880.JPG' ALT='IMG_6880.JPG'>IMG_6880.JPG</a></div></td>
<td><A ID='IMG_6881.JPG' href='cunninghamsgap.php?fileId=IMG_6881.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20090725/IMG_6881.JPG' ALT='IMG_6881.JPG'><BR>IMG_6881.JPG<br>56.95 KB</a><div class='inv'><br><a href='./images/20090725/IMG_6881.JPG' ALT='IMG_6881.JPG'>IMG_6881.JPG</a></div></td>
<td><A ID='IMG_6882.JPG' href='cunninghamsgap.php?fileId=IMG_6882.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20090725/IMG_6882.JPG' ALT='IMG_6882.JPG'><BR>IMG_6882.JPG<br>86.13 KB</a><div class='inv'><br><a href='./images/20090725/IMG_6882.JPG' ALT='IMG_6882.JPG'>IMG_6882.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_6884.JPG' href='cunninghamsgap.php?fileId=IMG_6884.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20090725/IMG_6884.JPG' ALT='IMG_6884.JPG'><BR>IMG_6884.JPG<br>81.49 KB</a><div class='inv'><br><a href='./images/20090725/IMG_6884.JPG' ALT='IMG_6884.JPG'>IMG_6884.JPG</a></div></td>
<td><A ID='IMG_6886.JPG' href='cunninghamsgap.php?fileId=IMG_6886.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20090725/IMG_6886.JPG' ALT='IMG_6886.JPG'><BR>IMG_6886.JPG<br>96.54 KB</a><div class='inv'><br><a href='./images/20090725/IMG_6886.JPG' ALT='IMG_6886.JPG'>IMG_6886.JPG</a></div></td>
<td><A ID='IMG_6887.JPG' href='cunninghamsgap.php?fileId=IMG_6887.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20090725/IMG_6887.JPG' ALT='IMG_6887.JPG'><BR>IMG_6887.JPG<br>93.53 KB</a><div class='inv'><br><a href='./images/20090725/IMG_6887.JPG' ALT='IMG_6887.JPG'>IMG_6887.JPG</a></div></td>
<td><A ID='IMG_6888.JPG' href='cunninghamsgap.php?fileId=IMG_6888.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20090725/IMG_6888.JPG' ALT='IMG_6888.JPG'><BR>IMG_6888.JPG<br>100.85 KB</a><div class='inv'><br><a href='./images/20090725/IMG_6888.JPG' ALT='IMG_6888.JPG'>IMG_6888.JPG</a></div></td>
<td><A ID='IMG_6889.JPG' href='cunninghamsgap.php?fileId=IMG_6889.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20090725/IMG_6889.JPG' ALT='IMG_6889.JPG'><BR>IMG_6889.JPG<br>79.27 KB</a><div class='inv'><br><a href='./images/20090725/IMG_6889.JPG' ALT='IMG_6889.JPG'>IMG_6889.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_6890.JPG' href='cunninghamsgap.php?fileId=IMG_6890.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20090725/IMG_6890.JPG' ALT='IMG_6890.JPG'><BR>IMG_6890.JPG<br>92.59 KB</a><div class='inv'><br><a href='./images/20090725/IMG_6890.JPG' ALT='IMG_6890.JPG'>IMG_6890.JPG</a></div></td>
<td><A ID='IMG_6892.JPG' href='cunninghamsgap.php?fileId=IMG_6892.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20090725/IMG_6892.JPG' ALT='IMG_6892.JPG'><BR>IMG_6892.JPG<br>67.93 KB</a><div class='inv'><br><a href='./images/20090725/IMG_6892.JPG' ALT='IMG_6892.JPG'>IMG_6892.JPG</a></div></td>
<td><A ID='IMG_6893.JPG' href='cunninghamsgap.php?fileId=IMG_6893.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20090725/IMG_6893.JPG' ALT='IMG_6893.JPG'><BR>IMG_6893.JPG<br>154.53 KB</a><div class='inv'><br><a href='./images/20090725/IMG_6893.JPG' ALT='IMG_6893.JPG'>IMG_6893.JPG</a></div></td>
</tr>
</table>	</div>
</div>
</body>
</html>