<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - February 2004 - Q&A letters</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="Q&A letters">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="Q&A letters" href='masterit200401.php'>January 2004</a></li>
<li><div class='activemenu'>February 2004</div></li>
<li><a title="Q&A letters" href='masterit200403.php'>March 2004</a></li>
<li><a title="Q&A letters" href='masterit200404.php'>April 2004</a></li>
<li><a title="Q&A letters" href='masterit200405.php'>May 2004</a></li>
<li><a title="Q&A letters" href='masterit200406.php'>June 2004</a></li>
<li><a title="Q&A letters" href='masterit200407.php'>July 2004</a></li>
<li><a title="Q&A letters" href='masterit200408.php'>August 2004</a></li>
<li><a title="Q&A letters" href='masterit200409.php'>September 2004</a></li>
<li><a title="Q&A letters" href='masterit200410.php'>October 2004</a></li>
<li><a title="Q&A letters" href='masterit200411.php'>November 2004</a></li>
<li><a title="Q&A letters" href='masterit200412.php'>December 2004</a></li>
<li> </li><br><li>Or go back to:</li><li><a title='Q&A/MasterIT letters from 2004' href="masterit2004.php">2004 archive</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>February 2004</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Mark's writing' href="written.php">Professional Writing</a> > <a title='My weekly Q&A column in The Australian' href="masterIT.php">MasterIT</a> > <a title='Q&A/MasterIT letters from 2004' href="masterit2004.php">2004 archive</a> > <a title='Q&A letters' href="masterit200402.php">February 2004</a>
<br><br>		<br>
<h2>3/2/2004</h2><br>
<b>I would like to put musical backing on a Photo Slide Show. When I download from a CD they are WMA & the program needs them to be WAV or MP3. How do I change them? Hope you can help!</b><br>
<br>
Your need to use a different program to copy the music, as Windows Media Player only lets you copy music from CD (otherwise known as ripping) in the proprietary Microsoft WMA format.<br>
<br>
Two good options are Musicmatch Jukebox (<a href="http://www.musicmatch.com" target="_blank">www.musicmatch.com</a>) and Exact Audio Copy (<a href="http://www.exactaudiocopy.de" target="_blank">www.exactaudiocopy.de</a>). The former is easier to use, but is commercial; the latter will give you better results (and is free), but is harder to set up initially. Novice users with do just fine with Musicmatch, but experts (and people who are completely anal about their music quality) will probably prefer EAC.<br>
<br>
<br>
<b>I recently asked the family geek about something, and the mumbled response involved looking it up on a "news group". I must confess complete ignorance in this matter being fairly new to the Internet; can the Master help?</b><br>
<br>
Newsgroups are basically text-based discussion forums. Usenet is the name of the large group of public newsgroups that are used by millions of people each day.<br>
<br>
Each group is like a mailing list that goes out to the world. If you post a message to it, millions of people can read it and respond. Each group has a specific topic or purpose, and these are often specialised, so for example if you are interested in photography you can look at "alt.photography" (the groups all have reasonably descriptive names).<br>
<br>
You can read and post to newsgroups using a news reader program - Outlook Express, Outlook and Mozilla are all able to do this (among many others), and you can search Usenet at groups.google.com (an extremely useful ability). Most groups are text based, but some also let you transmit and share files, like images.<br>
<br>
Online communities all have de facto rules and etiquette - and Usenet is one of the oldest and most diverse. It's a very good idea to read up on it before you start posting willy-nilly, or you might get a shock. A good starting point is <a href="http://www.ibiblio.org/usenet-i" target="_blank">www.ibiblio.org/usenet-i</a><br>
<br>
<br>
<h2>10/2/2004</h2><br>
<b>I've finally decided to upgrade my computer.  How can I transfer my existing mail from my current PC (using OE5 on Windows 95) to my new machine (using OE6 Win XP Professional)?</b><br>
<br>
First of all you'll need to copy the files that contain your old mail onto the new computer. Depending on their size, it may be sufficient to use a floppy disc, but it's more likely that you'll need something bigger, like a ZIP disk or CD-R.<br>
<br>
Finding the files where OE stores your mail is a battle in itself. The easiest way is to check the OE preferences. From the Tools menu, select Options, then click on the Maintenance tab. Next click the Store Folder button, and highlight the folder location that comes up. Make sure you highlight the entire thing - it will probably scroll off the right hand side of the box. Just click and drag the mouse to highlight it all.<br>
<br>
Now hit control-C to copy that location to the clipboard, press Windows-R (run), then press control-V to paste the location and hit enter. You should see a list of .dbx files corresponding to the names of your mail folders. These are the files you'll need to copy to the new PC.<br>
<br>
Once you've done that, fire up OE6, and select Import->Messages from the File menu. You'll get asked which program to import from - choose OE6; it's mail format is the same as 5.<br>
<br>
Now choose to import from a store directory, and then browse to the location you copied the old mail files to. From here you can choose to import all or just some of the folders. Note that you can't import the folders direct from CD, as OE needs write access to them (for some reason known only to Sir William Gates). You'll need to copy them to the hard drive before doing the import.<br>
<br>
You will probably also want to move over your address book from the old PC. The best way to do this is to select Export->Address Book from the File menu in OE5, and export as a text file. On the new PC, select File->Import->Other Address Book->Text file and you're set to go.<br>
<br>
<br>
<h2>17/2/2004</h2><br>
<b>My computer recently suffered an attack from a sweet but button obsessed toddler. He kindly powered my PC off while I was in the middle of stuff, and when I switched it back on I got an error message, namely that windows cannot read a file in C:WINNTSYSTEM32CONFIG, with a footnote about trying the recovery console. The plot thickens however, in that a subsequent reboot was successful. Turns out that I can boot one time in 5. There is also a strange buzzing noise (sort of a buzz-click-click-click) just before the error appears.</b><br>
<br>
Unfortunately, buzzing is Bad. Most likely your hard disc has grown some bad sectors, almost certainly as a direct result of being switched off whilst writing. The Master suggests that perhaps the small person is question should be steered away from careers involving nuclear missile silos and pieces of life support equipment. You may also want to install a Mollyguard (see <a href="http://www.tinyurl.com/35p8b" target="_blank">www.tinyurl.com/35p8b</a>) to prevent future catastrophe.<br>
<br>
Luckily you have a reasonable chance of fixing the problem, mainly because your PC still boots one time in 5. This suggests that the bad sectors on the hard disc are borderline and not horribly fatal. With luck we can fix them - without luck the word "reinstall" looms in your future.<br>
<br>
You'll need to boot into the recovery console - basically boot from your Windows CD, and press "R" at the appropriate time. A more involved set of instructions on the recovery console in general can be found at <a href="http://www.tinyurl.com/e01j" target="_blank">www.tinyurl.com/e01j</a>.<br>
<br>
Once you're in the recovery console, type CHKDSK C: /R (assuming your main drive was C:). Sit back and watch the percentage crawl upwards. Feel free to have a cuppa. Once this finishes, you'll probably get notification that errors were fixed. This is good.<br>
<br>
Now repeat the exercise, just to be sure. If you get told there were errors fixed this time round, it's time to start saving for a new hard drive. Saving very quickly, in fact. It's also time to make backups; your disc's days are probably numbered.<br>
<br>
Assuming all goes well, type EXIT and the computer should reboot. Cross your fingers and see if the problem is gone.<br>
<br>
<br>
<h2>24/2/2004</h2><br>
<b>I recently installed Microsoft Office 2002 on top of XP Professional. Upon setting up Microsoft Outlook, I keep getting a "Enter Network Password" dialog box that displays the mail server and account user names and password. I run a small home network that connects my newer and older PCs together.  The older one is running Windows 2000. How can I get rid of this "Enter Network Password" dialog, as it pops up numerous times when the "Send/Receive" button is used? Does it have to do with the set-up of my home network or Microsoft Outlook?</b><br>
<br>
It's unlikely to be your home network - Outlook is probably playing up. There can be a number of reasons for this including mail server unavailability, checking multiple POP addresses with the same username, and good old fashioned bugs in Outlook.<br>
<br>
Apart from cheekily suggesting a change to Mozilla (or Thunderbird, the standalone Mozilla mail component), have a look at the suggestions on the following pages: www.tinyurl.com/2nccr and www.tinyurl.com/2um3j.<br>
<br>
<br>
<b>I would like to reinstall Windows 98 (2nd ed) over my existing Windows 98 (2nd ed) in order to reinstate four files vnetsup.vxd; vredir.vxd: dfs,vxd and msnp32.dll. Could you please outline the procedure  for reinstalling windows98?</b><br>
<br>
You could probably track down just those files if you need them, but it should be fairly simple to do a "reinstall over the top" - i.e. one that preserves your settings, but fixes up Windows.<br>
<br>
It's actually a very good idea to do this to Windows 98 every six months or so (depending on usage), as it tends to suffer from "bitrot" - caused by corrupted files and wrong versions of DLLs incorrectly installed over the originals.<br>
<br>
If you can start Windows, just pop in the CD and start installation - then select upgrade rather than full install. It's that simple.<br>
<br>
Well, actually, it's not - it depends if the Windows CD you have is an OEM CD, or an upgrade CD, or a full blown copy. You'll need either of the latter two - the OEM CD will only let you do a complete nuke-everything reinstall (this is often considered bad), but assuming you can do the upgrade install you should be home free. <br>
<br>
<i><p>Did the information on this page help you? Entertain you? Bore you? <a href="contact.php?subject=MasterIT">Drop me a line</a>.</p>

<p>If you're feeling particularly generous, you can even <a href="buypics.php">click here to send me some dot-com riches</a>. Think of it as online busking.</i></p>
	</div>
</div>
</body>
</html>