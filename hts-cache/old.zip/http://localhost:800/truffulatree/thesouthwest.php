<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - 11/11/2005 - The Southwest (from Above and Below)</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="The Southwest (from Above and Below)">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="Greetings from a Bum" href='greetingsfromabum.php'>29/4/2005</a></li>
<li><a title="Onward" href='onward.php'>2/5/2005</a></li>
<li><a title="It's a tough life (pt 1: Bundaberg, Agnes Water and 1770)" href='itsatoughlife1.php'>17/5/2005</a></li>
<li><a title="It's a tough life (pt 2: Rockhampton, Emu Park and Great Keppel Island)" href='itsatoughlife2.php'>23/5/2005</a></li>
<li><a title="There and Back Again - a Yo-yo's Tale" href='thereandbackagain.php'>18/6/2005</a></li>
<li><a title="Platypi and Grey Nomads" href='platypiandgreynomads.php'>24/6/2005</a></li>
<li><a title="Blowing Bubbles in a Watery Tomb" href='blowingbubbles.php'>1/7/2005</a></li>
<li><a title="Pieces of History" href='piecesofhistory.php'>8/7/2005</a></li>
<li><a title="Walks and Waterfalls" href='walksandwaterfalls.php'>15/7/2005</a></li>
<li><a title="Mission to Tribulation" href='missiontotribulation.php'>22/7/2005</a></li>
<li><a title="Levity, Limestone and Lava" href='levitylimestoneandlava.php'>29/7/2005</a></li>
<li><a title="Into the Never Never" href='intothenevernever.php'>5/8/2005</a></li>
<li><a title="Slowing the pace in Darwin" href='slowingthepaceindarwin.php'>12/8/2005</a></li>
<li><a title="Blistering Barnacles and Leaping Lizards" href='leapinglizards.php'>19/8/2005</a></li>
<li><a title="Kakadu and Litchfield" href='kakadu.php'>26/8/2005</a></li>
<li><a title="Legacies of War" href='legaciesofwar.php'>2/9/2005</a></li>
<li><a title="Go West" href='gowest.php'>10/9/2005</a></li>
<li><a title="Things from Above" href='thingsfromabove.php'>16/9/2005</a></li>
<li><a title="The West Coast" href='thewestcoast.php'>23/9/2005</a></li>
<li><a title="Reefs and Red Dust" href='reefsandreddust.php'>30/9/2005</a></li>
<li><a title="The Pilbara" href='pilbara.php'>7/10/2005</a></li>
<li><a title="Paradise with a Headwind" href='paradisewithaheadwind.php'>14/10/2005</a></li>
<li><a title="Down the Coral Coast" href='downthecoralcoast.php'>21/10/2005</a></li>
<li><a title="Pinnacles and Pinnipeds" href='pinnaclesandpinnipeds.php'>28/10/2005</a></li>
<li><a title="A week in Perth" href='perth.php'>4/11/2005</a></li>
<li><div class='activemenu'>11/11/2005</div></li>
<li><a title="More Heights and Depths" href='moreheightsanddepths.php'>18/11/2005</a></li>
<li><a title="Across the Nullarbor (and a bit beyond)" href='nullarbor.php'>25/11/2005</a></li>
<li><a title="Double Whammy" href='doublewhammy.php'>9/12/2005</a></li>
<li><a title="Two Cities" href='twocities.php'>19/12/2005</a></li>
<li><a title="Tassie - Part 1" href='tassie1.php'>1/1/2006</a></li>
<li><a title="Tassie - Part 2" href='tassie2.php'>7/1/2006</a></li>
<li><a title="Full Circle" href='fullcircle.php'>26/1/2006</a></li>
<li><a title="The Wrap Up" href='thewrapup.php'>23/3/2006</a></li>
<li> </li><br><li>Or go back to:</li><li><a title='Travelouges and blogs from my trip around Australia' href="nerdseyeview.php">Nerd's Eye View</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>11/11/2005</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Travel stories and pictures' href="travel.php">Travelogues</a> > <a title='Travelouges and blogs from my trip around Australia' href="nerdseyeview.php">Nerd's Eye View</a> > <a title='The Southwest (from Above and Below)' href="thesouthwest.php">11/11/2005</a>
<br><br>		


<h1>The Southwest (from Above and Below)</h1>

<a href="images/maps/Map051111.gif"><img src="images/maps/Map051111_sm.gif" align="right"></a>

<p>Hi everyone, me again, with the latest instalment in the continuing saga that is Nerd's Eye View.</p>

<p>This week we're half way through the southwest corner of WA. Geographically, it's much smaller than the northern areas like the Kimberley, but it's packed with nice spots, so we're taking our time a bit.</p>

<p>We started off from Mandurah last week, and made our way inland a bit to Dryandra State Forest, a great spot where we camped for a night and did a few bushwalks. The area is very good for spotting Numbats, but we weren't in the right place at the right time, so we missed out on that particular cute critter, however, we did get to see an Echidna (which promptly curled up into a spiny ball), as well as various birds, including several that Jana hadn't yet ticked off.</p>

<p>From there we wound back toward the coast, and stopped off along the way for the night at a spot called Honeymoon Pool (once again usefully harvested from our free & cheap campsites book).</p>

<p>As well as being near the moderately interesting Wellington Dam, the campsite itself was quite lovely, and we went for a brief walk along the river in the morning. The weather was suitably overcast and damp, not to mention quite cool. This part of the world is still in the grip of an extended winter, and daytime temperatures are lucky to exceed 20 degrees.</p>

<p>This is not a bad thing though; the cooler temperatures combined with the scenery make the place feel quite lovely. It's reminiscent of the NSW Southern Highlands in some ways, although much of the vegetation is obviously endemic to the region (the trees tend to be a wee bit taller).</p>

<p>We headed off to see one such tree after the Wellington Dam stay. Dubbed the King Jarrah, it's thought to be about 500 years old, and it's quite impressive. Girth-wise, the <a href="missiontotribulation.php?fileId=IMG_4887.JPG">Red Cedar I visited on the east coast</a> is larger, but this fellow was taller.</p>

<p>After that first taste of the tall timber, we headed back to the coast for a few days, through Bunbury and then on to Busselton, from where I arranged some diving (yay!). Specifically, a dive or two of the HMAS Swan, sunk deliberately off the coast of Dunsborough as an artificial reef and wreck dive.</p>

<p>I had to wait a day to get out there, so we took the opportunity to relax indoors in a caravan park, as it was rainy and miserable. We've found that caravan parks tend to offer better value than hostels for two people, as you can generally get an on-site van or cabin (with your own kitchen, fridge and TV) for the same price as a basic hostel double room (with naught but a shoddy bed in many cases).</p>

<p>The Swan dives (puns on a postcard) were fantastic. The first was an orientation and general swim about, but on the second we did various swimthroughs of the actual wreck itself. I clocked up a few more diving firsts in this way, as I've never actually been inside a wreck. It was very, very cool (eg standing in the wheelhouse). The Swan was a navy boat, quite large, and was only sunk in '97, so it's still very much intact.</p>

<p>The second "first" I clocked up also involves the word "cool", as that was exactly what the water was. Previously I'd only dived on the east coast in lovely warm water. The water in this neck of the woods is just a wee bit cooler. Although hardly what you'd call freezing - 17 degrees - it's still cold enough to eat into your bones by the end of the dive if you lack gloves and a hood like I do.</p>

<p>Anyway, all up, it was fantastic. Best of all, there's another ex-navy wreck off the coast of Albany (the HMAS Perth) which I'll investigate next week. :)</p>

<p>Busselton also has another one of those historic jetties. This one is 2km long, and dates back to the 1800s, however, large sections of it have been replaced over the years, so it raises the question of just how historic it is.</p>

<p>Nonetheless, it was a nice walk out to the end, not least because there is an underwater observatory there, which takes you 8m below the surface. From there you can see lots of colourful soft corals and other creatures growing on the jetty pylons, as well as various fish and crabs doing their thing.</p>

<p>The windows are a type of Perspex, and are 10cm thick. Nonetheless, they offer a great view, and so of course various pictures abound, including a photo shoot of a particularly cute puffer fish that was just hanging around (and had been for a couple of days apparently; I guess it had nothing much better to do).</p>

<p>After Busselton, we headed to the westernmost points of the area, including the Leeuwin-Naturaliste National Park, and the Margaret River area.</p>

<p>There are also several caves in this area, and we stopped in at a couple. The first one was the Ngilgi Cave, some 40m deep. It's lit, so I took my camera down and snapped away. The formations here were certainly more impressive than the east coast above ground caves I'd already visited on my trip (but that's the nature of the various types of caves).</p>

<p>After an overnight stay at another lovely cheapo campsite, we visited another one called Giant's cave. It's normally only open during school holidays, but there was a school group going through on that particular day, so we took the opportunity to give it a go.</p>

<p>This cave experience was quite different again, and without permanent lighting it was hardhat and torch territory. Jana did the first bit with me, but then we hit a very tight squeeze up a couple of ladders, so I continued on my own for the rest, as she's really not at all fond of confined spaces. It was a pretty deep cave, 87m down at it's lowest point, with some very large caverns that have (perhaps unnervingly) been caused by cave-ins over the years.</p>

<p>As a result, the cave formations weren't nearly as plentiful, but it was still a great experience. My camera didn't accompany me as, given the lack of light, it really would have been quite pointless.</p>

<p>From there we continued our tour of the area, and had a lovely drive through the first of the enormous Karri forests. These towering, white-barked, straight trees are plentiful there, and once covered large parts of the south west.</p>

<p>We finally ended up driving south through Augusta to Cape Leeuwin, where there is a lighthouse, and the Indian and Southern Oceans meet. It was a pretty windy and cold spot, but the striking scenery more than made up for it.</p>

<p>We elected not to fork out another $20 to see the inside of the lighthouse, and instead checked out the old calcified waterwheel from yesteryear that was nearby.</p>

<p>After that it was off to yet another cheapo campsite, also quite nice although somewhat wetter when it rained on us a bit (but them's the breaks), and then on to Pemberton today.</p>

<p>From here we've explored a couple more of the national parks, and had some lovely drives through the forest. Jana, who is on her Ls, has even chauffeured me a couple of times.</p>

<p>Today we also took the time to visit the Gloucester Tree, which is a 68m high old Karri with spikes embedded into it's trunk, in a spiral spoke pattern. This lets you climb it easily, and up the top is an old fire observation post. Despite said ease, climbing the tree is still a pretty nerve-wracking experience, but the views from the top are spectacular.</p>

<p>That pretty much brings us up to date. For once, I think I'm experiencing colder weather than many (most?) of you, so revel in that fact if you like, although I'm quite liking it - for now. :)</p>

<p>Snappy shots for the week are:</p>

<table width="800">
	<tr>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=IMG_2226.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2226.JPG' ALT='Scores 9 on the evolutionary cuteness scale'><BR>Scores 9 on the evolutionary cuteness scale</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=IMG_2306.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2306.JPG' ALT='In the hall of the mountain king'><BR>In the hall of the mountain king</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=IMG_2420.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2420.JPG' ALT='Idiot with two oceans behind'><BR>Idiot with two oceans behind</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=IMG_2494.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2494.JPG' ALT='Splendid Wren (also scores highly on the cuteness scale)'><BR>Splendid Wren (also scores highly on the cuteness scale)</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=IMG_2511.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2511.JPG' ALT='The first 5 metres of the 68 metre Gloucester Tree '><BR>The first 5 metres of the 68 metre Gloucester Tree </a>
	</td>
	</tr>
</table>

<br><br>
All images in this gallery:<br>
<table width='800'>
<tr>
</tr>
<tr><td><A ID='IMG_2013.JPG' href='thesouthwest.php?fileId=IMG_2013.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2013.JPG' ALT='IMG_2013.JPG'><BR>IMG_2013.JPG<br>114.4 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2013.JPG' ALT='IMG_2013.JPG'>IMG_2013.JPG</a></div></td>
<td><A ID='IMG_2014.JPG' href='thesouthwest.php?fileId=IMG_2014.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2014.JPG' ALT='IMG_2014.JPG'><BR>IMG_2014.JPG<br>125.27 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2014.JPG' ALT='IMG_2014.JPG'>IMG_2014.JPG</a></div></td>
<td><A ID='IMG_2015.JPG' href='thesouthwest.php?fileId=IMG_2015.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2015.JPG' ALT='IMG_2015.JPG'><BR>IMG_2015.JPG<br>95.5 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2015.JPG' ALT='IMG_2015.JPG'>IMG_2015.JPG</a></div></td>
<td><A ID='IMG_2016.JPG' href='thesouthwest.php?fileId=IMG_2016.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2016.JPG' ALT='IMG_2016.JPG'><BR>IMG_2016.JPG<br>122.87 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2016.JPG' ALT='IMG_2016.JPG'>IMG_2016.JPG</a></div></td>
<td><A ID='IMG_2017.JPG' href='thesouthwest.php?fileId=IMG_2017.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2017.JPG' ALT='IMG_2017.JPG'><BR>IMG_2017.JPG<br>118.41 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2017.JPG' ALT='IMG_2017.JPG'>IMG_2017.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_2019.JPG' href='thesouthwest.php?fileId=IMG_2019.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2019.JPG' ALT='IMG_2019.JPG'><BR>IMG_2019.JPG<br>123.37 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2019.JPG' ALT='IMG_2019.JPG'>IMG_2019.JPG</a></div></td>
<td><A ID='IMG_2024.JPG' href='thesouthwest.php?fileId=IMG_2024.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2024.JPG' ALT='IMG_2024.JPG'><BR>IMG_2024.JPG<br>69.34 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2024.JPG' ALT='IMG_2024.JPG'>IMG_2024.JPG</a></div></td>
<td><A ID='IMG_2025.JPG' href='thesouthwest.php?fileId=IMG_2025.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2025.JPG' ALT='IMG_2025.JPG'><BR>IMG_2025.JPG<br>77.85 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2025.JPG' ALT='IMG_2025.JPG'>IMG_2025.JPG</a></div></td>
<td><A ID='IMG_2027.JPG' href='thesouthwest.php?fileId=IMG_2027.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2027.JPG' ALT='IMG_2027.JPG'><BR>IMG_2027.JPG<br>95.58 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2027.JPG' ALT='IMG_2027.JPG'>IMG_2027.JPG</a></div></td>
<td><A ID='IMG_2030.JPG' href='thesouthwest.php?fileId=IMG_2030.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2030.JPG' ALT='IMG_2030.JPG'><BR>IMG_2030.JPG<br>78.15 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2030.JPG' ALT='IMG_2030.JPG'>IMG_2030.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_2033.JPG' href='thesouthwest.php?fileId=IMG_2033.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2033.JPG' ALT='IMG_2033.JPG'><BR>IMG_2033.JPG<br>98.39 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2033.JPG' ALT='IMG_2033.JPG'>IMG_2033.JPG</a></div></td>
<td><A ID='IMG_2035.JPG' href='thesouthwest.php?fileId=IMG_2035.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2035.JPG' ALT='IMG_2035.JPG'><BR>IMG_2035.JPG<br>93.21 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2035.JPG' ALT='IMG_2035.JPG'>IMG_2035.JPG</a></div></td>
<td><A ID='IMG_2036.JPG' href='thesouthwest.php?fileId=IMG_2036.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2036.JPG' ALT='IMG_2036.JPG'><BR>IMG_2036.JPG<br>44.88 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2036.JPG' ALT='IMG_2036.JPG'>IMG_2036.JPG</a></div></td>
<td><A ID='IMG_2038.JPG' href='thesouthwest.php?fileId=IMG_2038.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2038.JPG' ALT='IMG_2038.JPG'><BR>IMG_2038.JPG<br>99.34 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2038.JPG' ALT='IMG_2038.JPG'>IMG_2038.JPG</a></div></td>
<td><A ID='IMG_2044.JPG' href='thesouthwest.php?fileId=IMG_2044.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2044.JPG' ALT='IMG_2044.JPG'><BR>IMG_2044.JPG<br>103.36 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2044.JPG' ALT='IMG_2044.JPG'>IMG_2044.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_2050.JPG' href='thesouthwest.php?fileId=IMG_2050.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2050.JPG' ALT='IMG_2050.JPG'><BR>IMG_2050.JPG<br>135.35 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2050.JPG' ALT='IMG_2050.JPG'>IMG_2050.JPG</a></div></td>
<td><A ID='IMG_2052.JPG' href='thesouthwest.php?fileId=IMG_2052.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2052.JPG' ALT='IMG_2052.JPG'><BR>IMG_2052.JPG<br>112.98 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2052.JPG' ALT='IMG_2052.JPG'>IMG_2052.JPG</a></div></td>
<td><A ID='IMG_2054.JPG' href='thesouthwest.php?fileId=IMG_2054.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2054.JPG' ALT='IMG_2054.JPG'><BR>IMG_2054.JPG<br>137.84 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2054.JPG' ALT='IMG_2054.JPG'>IMG_2054.JPG</a></div></td>
<td><A ID='IMG_2065.JPG' href='thesouthwest.php?fileId=IMG_2065.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2065.JPG' ALT='IMG_2065.JPG'><BR>IMG_2065.JPG<br>114.48 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2065.JPG' ALT='IMG_2065.JPG'>IMG_2065.JPG</a></div></td>
<td><A ID='IMG_2093.JPG' href='thesouthwest.php?fileId=IMG_2093.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2093.JPG' ALT='IMG_2093.JPG'><BR>IMG_2093.JPG<br>114.86 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2093.JPG' ALT='IMG_2093.JPG'>IMG_2093.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_2100.JPG' href='thesouthwest.php?fileId=IMG_2100.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2100.JPG' ALT='IMG_2100.JPG'><BR>IMG_2100.JPG<br>110.47 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2100.JPG' ALT='IMG_2100.JPG'>IMG_2100.JPG</a></div></td>
<td><A ID='IMG_2103.JPG' href='thesouthwest.php?fileId=IMG_2103.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2103.JPG' ALT='IMG_2103.JPG'><BR>IMG_2103.JPG<br>67.45 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2103.JPG' ALT='IMG_2103.JPG'>IMG_2103.JPG</a></div></td>
<td><A ID='IMG_2104.JPG' href='thesouthwest.php?fileId=IMG_2104.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2104.JPG' ALT='IMG_2104.JPG'><BR>IMG_2104.JPG<br>51.5 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2104.JPG' ALT='IMG_2104.JPG'>IMG_2104.JPG</a></div></td>
<td><A ID='IMG_2107.JPG' href='thesouthwest.php?fileId=IMG_2107.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2107.JPG' ALT='IMG_2107.JPG'><BR>IMG_2107.JPG<br>52.34 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2107.JPG' ALT='IMG_2107.JPG'>IMG_2107.JPG</a></div></td>
<td><A ID='IMG_2122.JPG' href='thesouthwest.php?fileId=IMG_2122.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2122.JPG' ALT='IMG_2122.JPG'><BR>IMG_2122.JPG<br>115.6 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2122.JPG' ALT='IMG_2122.JPG'>IMG_2122.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_2127.JPG' href='thesouthwest.php?fileId=IMG_2127.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2127.JPG' ALT='IMG_2127.JPG'><BR>IMG_2127.JPG<br>32.81 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2127.JPG' ALT='IMG_2127.JPG'>IMG_2127.JPG</a></div></td>
<td><A ID='IMG_2132.JPG' href='thesouthwest.php?fileId=IMG_2132.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2132.JPG' ALT='IMG_2132.JPG'><BR>IMG_2132.JPG<br>95.63 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2132.JPG' ALT='IMG_2132.JPG'>IMG_2132.JPG</a></div></td>
<td><A ID='IMG_2134.JPG' href='thesouthwest.php?fileId=IMG_2134.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2134.JPG' ALT='IMG_2134.JPG'><BR>IMG_2134.JPG<br>122.72 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2134.JPG' ALT='IMG_2134.JPG'>IMG_2134.JPG</a></div></td>
<td><A ID='IMG_2136.JPG' href='thesouthwest.php?fileId=IMG_2136.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2136.JPG' ALT='IMG_2136.JPG'><BR>IMG_2136.JPG<br>117.76 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2136.JPG' ALT='IMG_2136.JPG'>IMG_2136.JPG</a></div></td>
<td><A ID='IMG_2142.JPG' href='thesouthwest.php?fileId=IMG_2142.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2142.JPG' ALT='IMG_2142.JPG'><BR>IMG_2142.JPG<br>141.76 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2142.JPG' ALT='IMG_2142.JPG'>IMG_2142.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_2144.JPG' href='thesouthwest.php?fileId=IMG_2144.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2144.JPG' ALT='IMG_2144.JPG'><BR>IMG_2144.JPG<br>121.4 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2144.JPG' ALT='IMG_2144.JPG'>IMG_2144.JPG</a></div></td>
<td><A ID='IMG_2146.JPG' href='thesouthwest.php?fileId=IMG_2146.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2146.JPG' ALT='IMG_2146.JPG'><BR>IMG_2146.JPG<br>122.63 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2146.JPG' ALT='IMG_2146.JPG'>IMG_2146.JPG</a></div></td>
<td><A ID='IMG_2149.JPG' href='thesouthwest.php?fileId=IMG_2149.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2149.JPG' ALT='IMG_2149.JPG'><BR>IMG_2149.JPG<br>123.62 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2149.JPG' ALT='IMG_2149.JPG'>IMG_2149.JPG</a></div></td>
<td><A ID='IMG_2150.JPG' href='thesouthwest.php?fileId=IMG_2150.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2150.JPG' ALT='IMG_2150.JPG'><BR>IMG_2150.JPG<br>131.89 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2150.JPG' ALT='IMG_2150.JPG'>IMG_2150.JPG</a></div></td>
<td><A ID='IMG_2151.JPG' href='thesouthwest.php?fileId=IMG_2151.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2151.JPG' ALT='IMG_2151.JPG'><BR>IMG_2151.JPG<br>123.84 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2151.JPG' ALT='IMG_2151.JPG'>IMG_2151.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_2153.JPG' href='thesouthwest.php?fileId=IMG_2153.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2153.JPG' ALT='IMG_2153.JPG'><BR>IMG_2153.JPG<br>113.18 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2153.JPG' ALT='IMG_2153.JPG'>IMG_2153.JPG</a></div></td>
<td><A ID='IMG_2155.JPG' href='thesouthwest.php?fileId=IMG_2155.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2155.JPG' ALT='IMG_2155.JPG'><BR>IMG_2155.JPG<br>114.97 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2155.JPG' ALT='IMG_2155.JPG'>IMG_2155.JPG</a></div></td>
<td><A ID='IMG_2156.JPG' href='thesouthwest.php?fileId=IMG_2156.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2156.JPG' ALT='IMG_2156.JPG'><BR>IMG_2156.JPG<br>109.46 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2156.JPG' ALT='IMG_2156.JPG'>IMG_2156.JPG</a></div></td>
<td><A ID='IMG_2158.JPG' href='thesouthwest.php?fileId=IMG_2158.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2158.JPG' ALT='IMG_2158.JPG'><BR>IMG_2158.JPG<br>124.44 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2158.JPG' ALT='IMG_2158.JPG'>IMG_2158.JPG</a></div></td>
<td><A ID='IMG_2160.JPG' href='thesouthwest.php?fileId=IMG_2160.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2160.JPG' ALT='IMG_2160.JPG'><BR>IMG_2160.JPG<br>117.12 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2160.JPG' ALT='IMG_2160.JPG'>IMG_2160.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_2162.JPG' href='thesouthwest.php?fileId=IMG_2162.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2162.JPG' ALT='IMG_2162.JPG'><BR>IMG_2162.JPG<br>115.46 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2162.JPG' ALT='IMG_2162.JPG'>IMG_2162.JPG</a></div></td>
<td><A ID='IMG_2164.JPG' href='thesouthwest.php?fileId=IMG_2164.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2164.JPG' ALT='IMG_2164.JPG'><BR>IMG_2164.JPG<br>114.43 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2164.JPG' ALT='IMG_2164.JPG'>IMG_2164.JPG</a></div></td>
<td><A ID='IMG_2165.JPG' href='thesouthwest.php?fileId=IMG_2165.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2165.JPG' ALT='IMG_2165.JPG'><BR>IMG_2165.JPG<br>70.79 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2165.JPG' ALT='IMG_2165.JPG'>IMG_2165.JPG</a></div></td>
<td><A ID='IMG_2166.JPG' href='thesouthwest.php?fileId=IMG_2166.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2166.JPG' ALT='IMG_2166.JPG'><BR>IMG_2166.JPG<br>66.37 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2166.JPG' ALT='IMG_2166.JPG'>IMG_2166.JPG</a></div></td>
<td><A ID='IMG_2168.JPG' href='thesouthwest.php?fileId=IMG_2168.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2168.JPG' ALT='IMG_2168.JPG'><BR>IMG_2168.JPG<br>85 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2168.JPG' ALT='IMG_2168.JPG'>IMG_2168.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_2169.JPG' href='thesouthwest.php?fileId=IMG_2169.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2169.JPG' ALT='IMG_2169.JPG'><BR>IMG_2169.JPG<br>116.27 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2169.JPG' ALT='IMG_2169.JPG'>IMG_2169.JPG</a></div></td>
<td><A ID='IMG_2179.JPG' href='thesouthwest.php?fileId=IMG_2179.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2179.JPG' ALT='IMG_2179.JPG'><BR>IMG_2179.JPG<br>54.91 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2179.JPG' ALT='IMG_2179.JPG'>IMG_2179.JPG</a></div></td>
<td><A ID='IMG_2183.JPG' href='thesouthwest.php?fileId=IMG_2183.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2183.JPG' ALT='IMG_2183.JPG'><BR>IMG_2183.JPG<br>73.46 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2183.JPG' ALT='IMG_2183.JPG'>IMG_2183.JPG</a></div></td>
<td><A ID='IMG_2187.JPG' href='thesouthwest.php?fileId=IMG_2187.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2187.JPG' ALT='IMG_2187.JPG'><BR>IMG_2187.JPG<br>31.48 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2187.JPG' ALT='IMG_2187.JPG'>IMG_2187.JPG</a></div></td>
<td><A ID='IMG_2189.JPG' href='thesouthwest.php?fileId=IMG_2189.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2189.JPG' ALT='IMG_2189.JPG'><BR>IMG_2189.JPG<br>41.71 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2189.JPG' ALT='IMG_2189.JPG'>IMG_2189.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_2191.JPG' href='thesouthwest.php?fileId=IMG_2191.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2191.JPG' ALT='IMG_2191.JPG'><BR>IMG_2191.JPG<br>52.4 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2191.JPG' ALT='IMG_2191.JPG'>IMG_2191.JPG</a></div></td>
<td><A ID='IMG_2194.JPG' href='thesouthwest.php?fileId=IMG_2194.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2194.JPG' ALT='IMG_2194.JPG'><BR>IMG_2194.JPG<br>50.39 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2194.JPG' ALT='IMG_2194.JPG'>IMG_2194.JPG</a></div></td>
<td><A ID='IMG_2200.JPG' href='thesouthwest.php?fileId=IMG_2200.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2200.JPG' ALT='IMG_2200.JPG'><BR>IMG_2200.JPG<br>63.52 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2200.JPG' ALT='IMG_2200.JPG'>IMG_2200.JPG</a></div></td>
<td><A ID='IMG_2204.JPG' href='thesouthwest.php?fileId=IMG_2204.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2204.JPG' ALT='IMG_2204.JPG'><BR>IMG_2204.JPG<br>50.09 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2204.JPG' ALT='IMG_2204.JPG'>IMG_2204.JPG</a></div></td>
<td><A ID='IMG_2210.JPG' href='thesouthwest.php?fileId=IMG_2210.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2210.JPG' ALT='IMG_2210.JPG'><BR>IMG_2210.JPG<br>73.39 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2210.JPG' ALT='IMG_2210.JPG'>IMG_2210.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_2212.JPG' href='thesouthwest.php?fileId=IMG_2212.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2212.JPG' ALT='IMG_2212.JPG'><BR>IMG_2212.JPG<br>71.87 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2212.JPG' ALT='IMG_2212.JPG'>IMG_2212.JPG</a></div></td>
<td><A ID='IMG_2214.JPG' href='thesouthwest.php?fileId=IMG_2214.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2214.JPG' ALT='IMG_2214.JPG'><BR>IMG_2214.JPG<br>49.91 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2214.JPG' ALT='IMG_2214.JPG'>IMG_2214.JPG</a></div></td>
<td><A ID='IMG_2223.JPG' href='thesouthwest.php?fileId=IMG_2223.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2223.JPG' ALT='IMG_2223.JPG'><BR>IMG_2223.JPG<br>40.32 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2223.JPG' ALT='IMG_2223.JPG'>IMG_2223.JPG</a></div></td>
<td><A ID='IMG_2224.JPG' href='thesouthwest.php?fileId=IMG_2224.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2224.JPG' ALT='IMG_2224.JPG'><BR>IMG_2224.JPG<br>38.23 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2224.JPG' ALT='IMG_2224.JPG'>IMG_2224.JPG</a></div></td>
<td><A ID='IMG_2226.JPG' href='thesouthwest.php?fileId=IMG_2226.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2226.JPG' ALT='IMG_2226.JPG'><BR>IMG_2226.JPG<br>40.56 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2226.JPG' ALT='IMG_2226.JPG'>IMG_2226.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_2227.JPG' href='thesouthwest.php?fileId=IMG_2227.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2227.JPG' ALT='IMG_2227.JPG'><BR>IMG_2227.JPG<br>43.88 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2227.JPG' ALT='IMG_2227.JPG'>IMG_2227.JPG</a></div></td>
<td><A ID='IMG_2229.JPG' href='thesouthwest.php?fileId=IMG_2229.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2229.JPG' ALT='IMG_2229.JPG'><BR>IMG_2229.JPG<br>37.12 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2229.JPG' ALT='IMG_2229.JPG'>IMG_2229.JPG</a></div></td>
<td><A ID='IMG_2230.JPG' href='thesouthwest.php?fileId=IMG_2230.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2230.JPG' ALT='IMG_2230.JPG'><BR>IMG_2230.JPG<br>40.96 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2230.JPG' ALT='IMG_2230.JPG'>IMG_2230.JPG</a></div></td>
<td><A ID='IMG_2236.JPG' href='thesouthwest.php?fileId=IMG_2236.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2236.JPG' ALT='IMG_2236.JPG'><BR>IMG_2236.JPG<br>58.51 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2236.JPG' ALT='IMG_2236.JPG'>IMG_2236.JPG</a></div></td>
<td><A ID='IMG_2246.JPG' href='thesouthwest.php?fileId=IMG_2246.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2246.JPG' ALT='IMG_2246.JPG'><BR>IMG_2246.JPG<br>61.21 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2246.JPG' ALT='IMG_2246.JPG'>IMG_2246.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_2248.JPG' href='thesouthwest.php?fileId=IMG_2248.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2248.JPG' ALT='IMG_2248.JPG'><BR>IMG_2248.JPG<br>55.77 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2248.JPG' ALT='IMG_2248.JPG'>IMG_2248.JPG</a></div></td>
<td><A ID='IMG_2249.JPG' href='thesouthwest.php?fileId=IMG_2249.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2249.JPG' ALT='IMG_2249.JPG'><BR>IMG_2249.JPG<br>64.75 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2249.JPG' ALT='IMG_2249.JPG'>IMG_2249.JPG</a></div></td>
<td><A ID='IMG_2253.JPG' href='thesouthwest.php?fileId=IMG_2253.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2253.JPG' ALT='IMG_2253.JPG'><BR>IMG_2253.JPG<br>64.86 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2253.JPG' ALT='IMG_2253.JPG'>IMG_2253.JPG</a></div></td>
<td><A ID='IMG_2256.JPG' href='thesouthwest.php?fileId=IMG_2256.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2256.JPG' ALT='IMG_2256.JPG'><BR>IMG_2256.JPG<br>40.48 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2256.JPG' ALT='IMG_2256.JPG'>IMG_2256.JPG</a></div></td>
<td><A ID='IMG_2260.JPG' href='thesouthwest.php?fileId=IMG_2260.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2260.JPG' ALT='IMG_2260.JPG'><BR>IMG_2260.JPG<br>119.48 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2260.JPG' ALT='IMG_2260.JPG'>IMG_2260.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_2261.JPG' href='thesouthwest.php?fileId=IMG_2261.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2261.JPG' ALT='IMG_2261.JPG'><BR>IMG_2261.JPG<br>94.62 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2261.JPG' ALT='IMG_2261.JPG'>IMG_2261.JPG</a></div></td>
<td><A ID='IMG_2266.JPG' href='thesouthwest.php?fileId=IMG_2266.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2266.JPG' ALT='IMG_2266.JPG'><BR>IMG_2266.JPG<br>61.93 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2266.JPG' ALT='IMG_2266.JPG'>IMG_2266.JPG</a></div></td>
<td><A ID='IMG_2269.JPG' href='thesouthwest.php?fileId=IMG_2269.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2269.JPG' ALT='IMG_2269.JPG'><BR>IMG_2269.JPG<br>76.19 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2269.JPG' ALT='IMG_2269.JPG'>IMG_2269.JPG</a></div></td>
<td><A ID='IMG_2273.JPG' href='thesouthwest.php?fileId=IMG_2273.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2273.JPG' ALT='IMG_2273.JPG'><BR>IMG_2273.JPG<br>43.4 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2273.JPG' ALT='IMG_2273.JPG'>IMG_2273.JPG</a></div></td>
<td><A ID='IMG_2275.JPG' href='thesouthwest.php?fileId=IMG_2275.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2275.JPG' ALT='IMG_2275.JPG'><BR>IMG_2275.JPG<br>76.05 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2275.JPG' ALT='IMG_2275.JPG'>IMG_2275.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_2278.JPG' href='thesouthwest.php?fileId=IMG_2278.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2278.JPG' ALT='IMG_2278.JPG'><BR>IMG_2278.JPG<br>60.01 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2278.JPG' ALT='IMG_2278.JPG'>IMG_2278.JPG</a></div></td>
<td><A ID='IMG_2279.JPG' href='thesouthwest.php?fileId=IMG_2279.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2279.JPG' ALT='IMG_2279.JPG'><BR>IMG_2279.JPG<br>86.29 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2279.JPG' ALT='IMG_2279.JPG'>IMG_2279.JPG</a></div></td>
<td><A ID='IMG_2281.JPG' href='thesouthwest.php?fileId=IMG_2281.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2281.JPG' ALT='IMG_2281.JPG'><BR>IMG_2281.JPG<br>69.24 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2281.JPG' ALT='IMG_2281.JPG'>IMG_2281.JPG</a></div></td>
<td><A ID='IMG_2283.JPG' href='thesouthwest.php?fileId=IMG_2283.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2283.JPG' ALT='IMG_2283.JPG'><BR>IMG_2283.JPG<br>85.81 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2283.JPG' ALT='IMG_2283.JPG'>IMG_2283.JPG</a></div></td>
<td><A ID='IMG_2284.JPG' href='thesouthwest.php?fileId=IMG_2284.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2284.JPG' ALT='IMG_2284.JPG'><BR>IMG_2284.JPG<br>111.29 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2284.JPG' ALT='IMG_2284.JPG'>IMG_2284.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_2286.JPG' href='thesouthwest.php?fileId=IMG_2286.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2286.JPG' ALT='IMG_2286.JPG'><BR>IMG_2286.JPG<br>66.71 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2286.JPG' ALT='IMG_2286.JPG'>IMG_2286.JPG</a></div></td>
<td><A ID='IMG_2287.JPG' href='thesouthwest.php?fileId=IMG_2287.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2287.JPG' ALT='IMG_2287.JPG'><BR>IMG_2287.JPG<br>68.99 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2287.JPG' ALT='IMG_2287.JPG'>IMG_2287.JPG</a></div></td>
<td><A ID='IMG_2288.JPG' href='thesouthwest.php?fileId=IMG_2288.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2288.JPG' ALT='IMG_2288.JPG'><BR>IMG_2288.JPG<br>98.38 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2288.JPG' ALT='IMG_2288.JPG'>IMG_2288.JPG</a></div></td>
<td><A ID='IMG_2292.JPG' href='thesouthwest.php?fileId=IMG_2292.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2292.JPG' ALT='IMG_2292.JPG'><BR>IMG_2292.JPG<br>66.18 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2292.JPG' ALT='IMG_2292.JPG'>IMG_2292.JPG</a></div></td>
<td><A ID='IMG_2298.JPG' href='thesouthwest.php?fileId=IMG_2298.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2298.JPG' ALT='IMG_2298.JPG'><BR>IMG_2298.JPG<br>56.33 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2298.JPG' ALT='IMG_2298.JPG'>IMG_2298.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_2302.JPG' href='thesouthwest.php?fileId=IMG_2302.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2302.JPG' ALT='IMG_2302.JPG'><BR>IMG_2302.JPG<br>77.3 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2302.JPG' ALT='IMG_2302.JPG'>IMG_2302.JPG</a></div></td>
<td><A ID='IMG_2304.JPG' href='thesouthwest.php?fileId=IMG_2304.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2304.JPG' ALT='IMG_2304.JPG'><BR>IMG_2304.JPG<br>99.93 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2304.JPG' ALT='IMG_2304.JPG'>IMG_2304.JPG</a></div></td>
<td><A ID='IMG_2306.JPG' href='thesouthwest.php?fileId=IMG_2306.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2306.JPG' ALT='IMG_2306.JPG'><BR>IMG_2306.JPG<br>85.95 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2306.JPG' ALT='IMG_2306.JPG'>IMG_2306.JPG</a></div></td>
<td><A ID='IMG_2310.JPG' href='thesouthwest.php?fileId=IMG_2310.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2310.JPG' ALT='IMG_2310.JPG'><BR>IMG_2310.JPG<br>130.54 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2310.JPG' ALT='IMG_2310.JPG'>IMG_2310.JPG</a></div></td>
<td><A ID='IMG_2311.JPG' href='thesouthwest.php?fileId=IMG_2311.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2311.JPG' ALT='IMG_2311.JPG'><BR>IMG_2311.JPG<br>102.44 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2311.JPG' ALT='IMG_2311.JPG'>IMG_2311.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_2347.JPG' href='thesouthwest.php?fileId=IMG_2347.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2347.JPG' ALT='IMG_2347.JPG'><BR>IMG_2347.JPG<br>93.73 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2347.JPG' ALT='IMG_2347.JPG'>IMG_2347.JPG</a></div></td>
<td><A ID='IMG_2349.JPG' href='thesouthwest.php?fileId=IMG_2349.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2349.JPG' ALT='IMG_2349.JPG'><BR>IMG_2349.JPG<br>76.31 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2349.JPG' ALT='IMG_2349.JPG'>IMG_2349.JPG</a></div></td>
<td><A ID='IMG_2360.JPG' href='thesouthwest.php?fileId=IMG_2360.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2360.JPG' ALT='IMG_2360.JPG'><BR>IMG_2360.JPG<br>126.39 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2360.JPG' ALT='IMG_2360.JPG'>IMG_2360.JPG</a></div></td>
<td><A ID='IMG_2365.JPG' href='thesouthwest.php?fileId=IMG_2365.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2365.JPG' ALT='IMG_2365.JPG'><BR>IMG_2365.JPG<br>135.03 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2365.JPG' ALT='IMG_2365.JPG'>IMG_2365.JPG</a></div></td>
<td><A ID='IMG_2367.JPG' href='thesouthwest.php?fileId=IMG_2367.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2367.JPG' ALT='IMG_2367.JPG'><BR>IMG_2367.JPG<br>119.72 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2367.JPG' ALT='IMG_2367.JPG'>IMG_2367.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_2368.JPG' href='thesouthwest.php?fileId=IMG_2368.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2368.JPG' ALT='IMG_2368.JPG'><BR>IMG_2368.JPG<br>135.43 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2368.JPG' ALT='IMG_2368.JPG'>IMG_2368.JPG</a></div></td>
<td><A ID='IMG_2372.JPG' href='thesouthwest.php?fileId=IMG_2372.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2372.JPG' ALT='IMG_2372.JPG'><BR>IMG_2372.JPG<br>92.29 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2372.JPG' ALT='IMG_2372.JPG'>IMG_2372.JPG</a></div></td>
<td><A ID='IMG_2376.JPG' href='thesouthwest.php?fileId=IMG_2376.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2376.JPG' ALT='IMG_2376.JPG'><BR>IMG_2376.JPG<br>123.97 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2376.JPG' ALT='IMG_2376.JPG'>IMG_2376.JPG</a></div></td>
<td><A ID='IMG_2380.JPG' href='thesouthwest.php?fileId=IMG_2380.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2380.JPG' ALT='IMG_2380.JPG'><BR>IMG_2380.JPG<br>127.25 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2380.JPG' ALT='IMG_2380.JPG'>IMG_2380.JPG</a></div></td>
<td><A ID='IMG_2382.JPG' href='thesouthwest.php?fileId=IMG_2382.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2382.JPG' ALT='IMG_2382.JPG'><BR>IMG_2382.JPG<br>138.29 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2382.JPG' ALT='IMG_2382.JPG'>IMG_2382.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_2391.JPG' href='thesouthwest.php?fileId=IMG_2391.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2391.JPG' ALT='IMG_2391.JPG'><BR>IMG_2391.JPG<br>73.32 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2391.JPG' ALT='IMG_2391.JPG'>IMG_2391.JPG</a></div></td>
<td><A ID='IMG_2397.JPG' href='thesouthwest.php?fileId=IMG_2397.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2397.JPG' ALT='IMG_2397.JPG'><BR>IMG_2397.JPG<br>69.08 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2397.JPG' ALT='IMG_2397.JPG'>IMG_2397.JPG</a></div></td>
<td><A ID='IMG_2405.JPG' href='thesouthwest.php?fileId=IMG_2405.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2405.JPG' ALT='IMG_2405.JPG'><BR>IMG_2405.JPG<br>116.28 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2405.JPG' ALT='IMG_2405.JPG'>IMG_2405.JPG</a></div></td>
<td><A ID='IMG_2406.JPG' href='thesouthwest.php?fileId=IMG_2406.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2406.JPG' ALT='IMG_2406.JPG'><BR>IMG_2406.JPG<br>142.79 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2406.JPG' ALT='IMG_2406.JPG'>IMG_2406.JPG</a></div></td>
<td><A ID='IMG_2409.JPG' href='thesouthwest.php?fileId=IMG_2409.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2409.JPG' ALT='IMG_2409.JPG'><BR>IMG_2409.JPG<br>97.75 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2409.JPG' ALT='IMG_2409.JPG'>IMG_2409.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_2416.JPG' href='thesouthwest.php?fileId=IMG_2416.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2416.JPG' ALT='IMG_2416.JPG'><BR>IMG_2416.JPG<br>54.35 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2416.JPG' ALT='IMG_2416.JPG'>IMG_2416.JPG</a></div></td>
<td><A ID='IMG_2418.JPG' href='thesouthwest.php?fileId=IMG_2418.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2418.JPG' ALT='IMG_2418.JPG'><BR>IMG_2418.JPG<br>85.28 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2418.JPG' ALT='IMG_2418.JPG'>IMG_2418.JPG</a></div></td>
<td><A ID='IMG_2420.JPG' href='thesouthwest.php?fileId=IMG_2420.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2420.JPG' ALT='IMG_2420.JPG'><BR>IMG_2420.JPG<br>64.88 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2420.JPG' ALT='IMG_2420.JPG'>IMG_2420.JPG</a></div></td>
<td><A ID='IMG_2421.JPG' href='thesouthwest.php?fileId=IMG_2421.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2421.JPG' ALT='IMG_2421.JPG'><BR>IMG_2421.JPG<br>33.97 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2421.JPG' ALT='IMG_2421.JPG'>IMG_2421.JPG</a></div></td>
<td><A ID='IMG_2424.JPG' href='thesouthwest.php?fileId=IMG_2424.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2424.JPG' ALT='IMG_2424.JPG'><BR>IMG_2424.JPG<br>111.08 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2424.JPG' ALT='IMG_2424.JPG'>IMG_2424.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_2425.JPG' href='thesouthwest.php?fileId=IMG_2425.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2425.JPG' ALT='IMG_2425.JPG'><BR>IMG_2425.JPG<br>81.58 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2425.JPG' ALT='IMG_2425.JPG'>IMG_2425.JPG</a></div></td>
<td><A ID='IMG_2428.JPG' href='thesouthwest.php?fileId=IMG_2428.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2428.JPG' ALT='IMG_2428.JPG'><BR>IMG_2428.JPG<br>75.9 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2428.JPG' ALT='IMG_2428.JPG'>IMG_2428.JPG</a></div></td>
<td><A ID='IMG_2429.JPG' href='thesouthwest.php?fileId=IMG_2429.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2429.JPG' ALT='IMG_2429.JPG'><BR>IMG_2429.JPG<br>56.83 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2429.JPG' ALT='IMG_2429.JPG'>IMG_2429.JPG</a></div></td>
<td><A ID='IMG_2431.JPG' href='thesouthwest.php?fileId=IMG_2431.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2431.JPG' ALT='IMG_2431.JPG'><BR>IMG_2431.JPG<br>71.69 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2431.JPG' ALT='IMG_2431.JPG'>IMG_2431.JPG</a></div></td>
<td><A ID='IMG_2437.JPG' href='thesouthwest.php?fileId=IMG_2437.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2437.JPG' ALT='IMG_2437.JPG'><BR>IMG_2437.JPG<br>51.13 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2437.JPG' ALT='IMG_2437.JPG'>IMG_2437.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_2439.JPG' href='thesouthwest.php?fileId=IMG_2439.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2439.JPG' ALT='IMG_2439.JPG'><BR>IMG_2439.JPG<br>48.83 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2439.JPG' ALT='IMG_2439.JPG'>IMG_2439.JPG</a></div></td>
<td><A ID='IMG_2440.JPG' href='thesouthwest.php?fileId=IMG_2440.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2440.JPG' ALT='IMG_2440.JPG'><BR>IMG_2440.JPG<br>38.56 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2440.JPG' ALT='IMG_2440.JPG'>IMG_2440.JPG</a></div></td>
<td><A ID='IMG_2445.JPG' href='thesouthwest.php?fileId=IMG_2445.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2445.JPG' ALT='IMG_2445.JPG'><BR>IMG_2445.JPG<br>52.88 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2445.JPG' ALT='IMG_2445.JPG'>IMG_2445.JPG</a></div></td>
<td><A ID='IMG_2448.JPG' href='thesouthwest.php?fileId=IMG_2448.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2448.JPG' ALT='IMG_2448.JPG'><BR>IMG_2448.JPG<br>98.67 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2448.JPG' ALT='IMG_2448.JPG'>IMG_2448.JPG</a></div></td>
<td><A ID='IMG_2450.JPG' href='thesouthwest.php?fileId=IMG_2450.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2450.JPG' ALT='IMG_2450.JPG'><BR>IMG_2450.JPG<br>47.8 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2450.JPG' ALT='IMG_2450.JPG'>IMG_2450.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_2452.JPG' href='thesouthwest.php?fileId=IMG_2452.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2452.JPG' ALT='IMG_2452.JPG'><BR>IMG_2452.JPG<br>56.98 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2452.JPG' ALT='IMG_2452.JPG'>IMG_2452.JPG</a></div></td>
<td><A ID='IMG_2460.JPG' href='thesouthwest.php?fileId=IMG_2460.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2460.JPG' ALT='IMG_2460.JPG'><BR>IMG_2460.JPG<br>68.15 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2460.JPG' ALT='IMG_2460.JPG'>IMG_2460.JPG</a></div></td>
<td><A ID='IMG_2466.JPG' href='thesouthwest.php?fileId=IMG_2466.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2466.JPG' ALT='IMG_2466.JPG'><BR>IMG_2466.JPG<br>67.39 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2466.JPG' ALT='IMG_2466.JPG'>IMG_2466.JPG</a></div></td>
<td><A ID='IMG_2467.JPG' href='thesouthwest.php?fileId=IMG_2467.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2467.JPG' ALT='IMG_2467.JPG'><BR>IMG_2467.JPG<br>89.28 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2467.JPG' ALT='IMG_2467.JPG'>IMG_2467.JPG</a></div></td>
<td><A ID='IMG_2470.JPG' href='thesouthwest.php?fileId=IMG_2470.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2470.JPG' ALT='IMG_2470.JPG'><BR>IMG_2470.JPG<br>95.42 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2470.JPG' ALT='IMG_2470.JPG'>IMG_2470.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_2471.JPG' href='thesouthwest.php?fileId=IMG_2471.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2471.JPG' ALT='IMG_2471.JPG'><BR>IMG_2471.JPG<br>67.54 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2471.JPG' ALT='IMG_2471.JPG'>IMG_2471.JPG</a></div></td>
<td><A ID='IMG_2472.JPG' href='thesouthwest.php?fileId=IMG_2472.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2472.JPG' ALT='IMG_2472.JPG'><BR>IMG_2472.JPG<br>55.03 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2472.JPG' ALT='IMG_2472.JPG'>IMG_2472.JPG</a></div></td>
<td><A ID='IMG_2474.JPG' href='thesouthwest.php?fileId=IMG_2474.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2474.JPG' ALT='IMG_2474.JPG'><BR>IMG_2474.JPG<br>54.3 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2474.JPG' ALT='IMG_2474.JPG'>IMG_2474.JPG</a></div></td>
<td><A ID='IMG_2475.JPG' href='thesouthwest.php?fileId=IMG_2475.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2475.JPG' ALT='IMG_2475.JPG'><BR>IMG_2475.JPG<br>74.05 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2475.JPG' ALT='IMG_2475.JPG'>IMG_2475.JPG</a></div></td>
<td><A ID='IMG_2478.JPG' href='thesouthwest.php?fileId=IMG_2478.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2478.JPG' ALT='IMG_2478.JPG'><BR>IMG_2478.JPG<br>84.21 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2478.JPG' ALT='IMG_2478.JPG'>IMG_2478.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_2480.JPG' href='thesouthwest.php?fileId=IMG_2480.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2480.JPG' ALT='IMG_2480.JPG'><BR>IMG_2480.JPG<br>100.28 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2480.JPG' ALT='IMG_2480.JPG'>IMG_2480.JPG</a></div></td>
<td><A ID='IMG_2481.JPG' href='thesouthwest.php?fileId=IMG_2481.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2481.JPG' ALT='IMG_2481.JPG'><BR>IMG_2481.JPG<br>74.78 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2481.JPG' ALT='IMG_2481.JPG'>IMG_2481.JPG</a></div></td>
<td><A ID='IMG_2488.JPG' href='thesouthwest.php?fileId=IMG_2488.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2488.JPG' ALT='IMG_2488.JPG'><BR>IMG_2488.JPG<br>114 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2488.JPG' ALT='IMG_2488.JPG'>IMG_2488.JPG</a></div></td>
<td><A ID='IMG_2494.JPG' href='thesouthwest.php?fileId=IMG_2494.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2494.JPG' ALT='Male Splendid Fairy-Wren'><BR>Male Splendid Fairy-Wren<br>122.95 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2494.JPG' ALT='Male Splendid Fairy-Wren'>Male Splendid Fairy-Wren</a></div></td>
<td><A ID='IMG_2496.JPG' href='thesouthwest.php?fileId=IMG_2496.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2496.JPG' ALT='Male Splendid Fairy-Wren'><BR>Male Splendid Fairy-Wren<br>127.65 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2496.JPG' ALT='Male Splendid Fairy-Wren'>Male Splendid Fairy-Wren</a></div></td>
</tr>
<tr><td><A ID='IMG_2504.JPG' href='thesouthwest.php?fileId=IMG_2504.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2504.JPG' ALT='IMG_2504.JPG'><BR>IMG_2504.JPG<br>137 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2504.JPG' ALT='IMG_2504.JPG'>IMG_2504.JPG</a></div></td>
<td><A ID='IMG_2507.JPG' href='thesouthwest.php?fileId=IMG_2507.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2507.JPG' ALT='IMG_2507.JPG'><BR>IMG_2507.JPG<br>93.69 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2507.JPG' ALT='IMG_2507.JPG'>IMG_2507.JPG</a></div></td>
<td><A ID='IMG_2509.JPG' href='thesouthwest.php?fileId=IMG_2509.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2509.JPG' ALT='IMG_2509.JPG'><BR>IMG_2509.JPG<br>103.63 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2509.JPG' ALT='IMG_2509.JPG'>IMG_2509.JPG</a></div></td>
<td><A ID='IMG_2511.JPG' href='thesouthwest.php?fileId=IMG_2511.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2511.JPG' ALT='IMG_2511.JPG'><BR>IMG_2511.JPG<br>112.11 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2511.JPG' ALT='IMG_2511.JPG'>IMG_2511.JPG</a></div></td>
<td><A ID='IMG_2512.JPG' href='thesouthwest.php?fileId=IMG_2512.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2512.JPG' ALT='IMG_2512.JPG'><BR>IMG_2512.JPG<br>143.12 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2512.JPG' ALT='IMG_2512.JPG'>IMG_2512.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_2516.JPG' href='thesouthwest.php?fileId=IMG_2516.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2516.JPG' ALT='IMG_2516.JPG'><BR>IMG_2516.JPG<br>64 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2516.JPG' ALT='IMG_2516.JPG'>IMG_2516.JPG</a></div></td>
<td><A ID='IMG_2517.JPG' href='thesouthwest.php?fileId=IMG_2517.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2517.JPG' ALT='IMG_2517.JPG'><BR>IMG_2517.JPG<br>55.29 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2517.JPG' ALT='IMG_2517.JPG'>IMG_2517.JPG</a></div></td>
<td><A ID='IMG_2519.JPG' href='thesouthwest.php?fileId=IMG_2519.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2519.JPG' ALT='IMG_2519.JPG'><BR>IMG_2519.JPG<br>99.34 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2519.JPG' ALT='IMG_2519.JPG'>IMG_2519.JPG</a></div></td>
<td><A ID='IMG_2520.JPG' href='thesouthwest.php?fileId=IMG_2520.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2520.JPG' ALT='IMG_2520.JPG'><BR>IMG_2520.JPG<br>83.39 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2520.JPG' ALT='IMG_2520.JPG'>IMG_2520.JPG</a></div></td>
<td><A ID='IMG_2522.JPG' href='thesouthwest.php?fileId=IMG_2522.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2522.JPG' ALT='IMG_2522.JPG'><BR>IMG_2522.JPG<br>68.79 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2522.JPG' ALT='IMG_2522.JPG'>IMG_2522.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_2528.JPG' href='thesouthwest.php?fileId=IMG_2528.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2528.JPG' ALT='IMG_2528.JPG'><BR>IMG_2528.JPG<br>111.01 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2528.JPG' ALT='IMG_2528.JPG'>IMG_2528.JPG</a></div></td>
<td><A ID='IMG_2531.JPG' href='thesouthwest.php?fileId=IMG_2531.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2531.JPG' ALT='IMG_2531.JPG'><BR>IMG_2531.JPG<br>132.84 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2531.JPG' ALT='IMG_2531.JPG'>IMG_2531.JPG</a></div></td>
<td><A ID='IMG_2532.JPG' href='thesouthwest.php?fileId=IMG_2532.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2532.JPG' ALT='IMG_2532.JPG'><BR>IMG_2532.JPG<br>107.68 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2532.JPG' ALT='IMG_2532.JPG'>IMG_2532.JPG</a></div></td>
<td><A ID='IMG_2535.JPG' href='thesouthwest.php?fileId=IMG_2535.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2535.JPG' ALT='IMG_2535.JPG'><BR>IMG_2535.JPG<br>116.08 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2535.JPG' ALT='IMG_2535.JPG'>IMG_2535.JPG</a></div></td>
<td><A ID='IMG_2537.JPG' href='thesouthwest.php?fileId=IMG_2537.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2537.JPG' ALT='IMG_2537.JPG'><BR>IMG_2537.JPG<br>64.84 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2537.JPG' ALT='IMG_2537.JPG'>IMG_2537.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_2538.JPG' href='thesouthwest.php?fileId=IMG_2538.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051111/IMG_2538.JPG' ALT='IMG_2538.JPG'><BR>IMG_2538.JPG<br>132.83 KB</a><div class='inv'><br><a href='./images/20051111/IMG_2538.JPG' ALT='IMG_2538.JPG'>IMG_2538.JPG</a></div></td>
</tr>
</table>	</div>
</div>
</body>
</html>