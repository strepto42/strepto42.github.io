<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - 7/1/2006 - Tassie - Part 2</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="Tassie - Part 2">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="Greetings from a Bum" href='greetingsfromabum.php'>29/4/2005</a></li>
<li><a title="Onward" href='onward.php'>2/5/2005</a></li>
<li><a title="It's a tough life (pt 1: Bundaberg, Agnes Water and 1770)" href='itsatoughlife1.php'>17/5/2005</a></li>
<li><a title="It's a tough life (pt 2: Rockhampton, Emu Park and Great Keppel Island)" href='itsatoughlife2.php'>23/5/2005</a></li>
<li><a title="There and Back Again - a Yo-yo's Tale" href='thereandbackagain.php'>18/6/2005</a></li>
<li><a title="Platypi and Grey Nomads" href='platypiandgreynomads.php'>24/6/2005</a></li>
<li><a title="Blowing Bubbles in a Watery Tomb" href='blowingbubbles.php'>1/7/2005</a></li>
<li><a title="Pieces of History" href='piecesofhistory.php'>8/7/2005</a></li>
<li><a title="Walks and Waterfalls" href='walksandwaterfalls.php'>15/7/2005</a></li>
<li><a title="Mission to Tribulation" href='missiontotribulation.php'>22/7/2005</a></li>
<li><a title="Levity, Limestone and Lava" href='levitylimestoneandlava.php'>29/7/2005</a></li>
<li><a title="Into the Never Never" href='intothenevernever.php'>5/8/2005</a></li>
<li><a title="Slowing the pace in Darwin" href='slowingthepaceindarwin.php'>12/8/2005</a></li>
<li><a title="Blistering Barnacles and Leaping Lizards" href='leapinglizards.php'>19/8/2005</a></li>
<li><a title="Kakadu and Litchfield" href='kakadu.php'>26/8/2005</a></li>
<li><a title="Legacies of War" href='legaciesofwar.php'>2/9/2005</a></li>
<li><a title="Go West" href='gowest.php'>10/9/2005</a></li>
<li><a title="Things from Above" href='thingsfromabove.php'>16/9/2005</a></li>
<li><a title="The West Coast" href='thewestcoast.php'>23/9/2005</a></li>
<li><a title="Reefs and Red Dust" href='reefsandreddust.php'>30/9/2005</a></li>
<li><a title="The Pilbara" href='pilbara.php'>7/10/2005</a></li>
<li><a title="Paradise with a Headwind" href='paradisewithaheadwind.php'>14/10/2005</a></li>
<li><a title="Down the Coral Coast" href='downthecoralcoast.php'>21/10/2005</a></li>
<li><a title="Pinnacles and Pinnipeds" href='pinnaclesandpinnipeds.php'>28/10/2005</a></li>
<li><a title="A week in Perth" href='perth.php'>4/11/2005</a></li>
<li><a title="The Southwest (from Above and Below)" href='thesouthwest.php'>11/11/2005</a></li>
<li><a title="More Heights and Depths" href='moreheightsanddepths.php'>18/11/2005</a></li>
<li><a title="Across the Nullarbor (and a bit beyond)" href='nullarbor.php'>25/11/2005</a></li>
<li><a title="Double Whammy" href='doublewhammy.php'>9/12/2005</a></li>
<li><a title="Two Cities" href='twocities.php'>19/12/2005</a></li>
<li><a title="Tassie - Part 1" href='tassie1.php'>1/1/2006</a></li>
<li><div class='activemenu'>7/1/2006</div></li>
<li><a title="Full Circle" href='fullcircle.php'>26/1/2006</a></li>
<li><a title="The Wrap Up" href='thewrapup.php'>23/3/2006</a></li>
<li> </li><br><li>Or go back to:</li><li><a title='Travelouges and blogs from my trip around Australia' href="nerdseyeview.php">Nerd's Eye View</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>7/1/2006</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Travel stories and pictures' href="travel.php">Travelogues</a> > <a title='Travelouges and blogs from my trip around Australia' href="nerdseyeview.php">Nerd's Eye View</a> > <a title='Tassie - Part 2' href="tassie2.php">7/1/2006</a>
<br><br>		


<h1>Tassie - Part 2</h1>

<a href="images/maps/Map060107.gif"><img src="images/maps/Map060107_sm.gif" align="right"></a>

<p>Hi everyone, here I am again doing the email thing. Right now, I'm sitting on the Spirit of Tasmania III, heading back to Melbourne (well, I was when I wrote this). The ocean is scrolling past outside the window (and is pleasingly calm thus far), and it's a beautiful day - Tassie's bad weather seems to have passed, and since I last wrote it's actually been pretty damn nice most days. At last, we've been getting the southern summer experience - warm to hot sunshine with real bite to it, mixed with cool crisp air - it's almost like a Brissie winter in fact (but with a fiercer sun).</p>

<p>We've spent the last week (or however long it's been since I last wrote) exploring most of the rest of the island. Notably, we pretty much skipped Hobart, and completely ignored Port Arthur, basically because of geography, time and money (not to mention a certain amount of apathy, although seeing the Cascade Brewery would have been nice).</p>

<p>There's been no shortage of lovely scenery though, and Tasmania's east is quite different from the west. It's much more tamed in a way, in part due to the weather, which is (in general) kinder, and there is a lot of rolling green farmland. Of course there's still plenty of wilderness to explore (much of it is state forest, and on the logging list in some form or other, but at least it's there).</p>

<p>We started the week by heading to Freycinet National Park, and spent an afternoon walking around Coles bay and The Hazards, on a very pleasant 11km bushwalk, which took us past the idyllic Wineglass Bay and a couple of nice lookouts.</p>

<p>Freycinet seems to be a Tassie holiday destination of choice though - and all the local caravan parks were chockers with holiday makers and their broods. We ended up just managing to squeeze into a free camping spot up the coast a little way.</p>

<p>The following day we pushed on (north through some lovely scenery) to Douglas Apsley National Park, where we did a spot of walking, before moving on to Branxholm via St Helens and Moorina.</p>

<p>After camping on the cheap there we looped back to Ralph's Falls near Ringarooma, and did some more highland walking, before heading on an extensive drive through various forest back roads (of various qualities - some of which smelled of rally), before dropping in to see some more big trees near Mathinna.</p>

<p>From there it was more lovely forest and dirt track to Blessington and then back on the tar to Longford, where we stayed the night.</p>

<p>The next day we skipped further north, up to Launceston, the second largest city in the state, and spent a very pleasant few hours checking out some wetlands and an accompanying island on the Tamar River. The wetlands abound with wildlife, and we saw a green and gold frog, and various waterbirds including some sweet families of Black Swans.</p>

<p>Whilst in town we also checked out Cataract Gorge, which incorporates a local swimming spot. It was almost even hot enough to consider taking a dip - not that we did though, as the place was teeming, and no doubt the water would have been on the icy side.</p>

<p>Our last loop inland after Launceston was back to Great Lake (another of Tassie's artificial hydro reservoirs), which is up in the central highlands, and is in fact pretty close to the centre of the island (ok, so it's a bit too far north, but that's geographic poetic license). We wound our way up onto the plateau via the large Poatina Power Station, and looped around the lake to Miena.</p>

<p>It was a little surprising that, after the gentle farminess of the east coast and the south, Miena, a town only a few hours from Launceston, had a bit of a hillbilly frontier town feel to it (apparently the whole area is a "fishing Mecca"). After a little difficulty locating the caravan park (a few scruffy sites out the back of the local pub), we settled down to a nice sunset as a local Grey Kangaroo browsed for dinner nearby.</p>

<p>Our last day in Tassie started off by leaving Great Lake behind and heading back north. We stopped along the way to do a short walk, near a pretty little alpine lake, set amongst ancient Pencil Pines, right on the roof of the plateau (well, the roof as far as the highway is concerned). These amazing trees grow very slowly, and the "big" ones in the photos are thought to be over 1,000 years old.</p>

<p>Then it was back to the road trip, and we moved on to Liffey Falls (Bob Brown is apparently from the nearby town of the same name), which were quite lovely.</p>

<p>We then descended from the plateau via Deloraine (where Jana's Gran grew up), to visit Mole Creek and Marakoopa cave (which was quite pretty - and had cool glow worms which I totally failed to photograph because they didn't allow tripods).</p>

<p>Then it was back through Sheffield to Devonport for the night - or it would have been, had there been any accommodation in town - turns out the xmas holidays had one more sting for us. We eventually managed to find a cabin in Turners Beach (just up the road really), and it was a comfy end to the Tassie trip.</p>

<p>Now, of course, I'm afloat somewhere in Bass Strait, heading to Melbourne (alas, not Sydney direct).</p>

<p>We'll push on to Sydney town pretty quickly though - for the residents of said sprawling metropolis, the plan is to be in town on the 10th, and to stay for a week or so, before continuing back up to Brissie, and the end of the road (not to mention, the so-called real world. But we won't think about that now). :)</p>

<p>Hope everyone is well, I'll see many of you in Sydney no doubt!</p>

<p>The second set of Tassie selections are:</p>

<table width="800">
	<tr>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=IMG_5677.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5677.JPG' ALT='Wineglass Bay, Freycinet National Park'><BR>Wineglass Bay, Freycinet National Park</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=IMG_5765.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5765.JPG' ALT="Ralph's Falls before they fall"><BR>Ralph's Falls before they fall</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=IMG_5912.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5912.JPG' ALT='Pencil Pines in the central highlands'><BR>Pencil Pines in the central highlands</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=IMG_5986.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5986.JPG' ALT='Liffey Falls and two people who needed a fill flash'><BR>Liffey Falls and two people who needed a fill flash</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=IMG_6027.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_6027.JPG' ALT='Mount Roland, near Sheffield'><BR>Mount Roland, near Sheffield</a>
	</td>
	</tr>
</table>

<br><br>
All images in this gallery:<br>
<table width='800'>
<tr>
</tr>
<tr><td><A ID='IMG_5649.JPG' href='tassie2.php?fileId=IMG_5649.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5649.JPG' ALT='IMG_5649.JPG'><BR>IMG_5649.JPG<br>63.4 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5649.JPG' ALT='IMG_5649.JPG'>IMG_5649.JPG</a></div></td>
<td><A ID='IMG_5651.JPG' href='tassie2.php?fileId=IMG_5651.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5651.JPG' ALT='IMG_5651.JPG'><BR>IMG_5651.JPG<br>79.66 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5651.JPG' ALT='IMG_5651.JPG'>IMG_5651.JPG</a></div></td>
<td><A ID='IMG_5654.JPG' href='tassie2.php?fileId=IMG_5654.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5654.JPG' ALT='IMG_5654.JPG'><BR>IMG_5654.JPG<br>111.71 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5654.JPG' ALT='IMG_5654.JPG'>IMG_5654.JPG</a></div></td>
<td><A ID='IMG_5666.JPG' href='tassie2.php?fileId=IMG_5666.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5666.JPG' ALT='IMG_5666.JPG'><BR>IMG_5666.JPG<br>72.6 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5666.JPG' ALT='IMG_5666.JPG'>IMG_5666.JPG</a></div></td>
<td><A ID='IMG_5670.JPG' href='tassie2.php?fileId=IMG_5670.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5670.JPG' ALT='IMG_5670.JPG'><BR>IMG_5670.JPG<br>99.84 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5670.JPG' ALT='IMG_5670.JPG'>IMG_5670.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5677.JPG' href='tassie2.php?fileId=IMG_5677.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5677.JPG' ALT='IMG_5677.JPG'><BR>IMG_5677.JPG<br>71.52 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5677.JPG' ALT='IMG_5677.JPG'>IMG_5677.JPG</a></div></td>
<td><A ID='IMG_5679.JPG' href='tassie2.php?fileId=IMG_5679.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5679.JPG' ALT='IMG_5679.JPG'><BR>IMG_5679.JPG<br>64.62 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5679.JPG' ALT='IMG_5679.JPG'>IMG_5679.JPG</a></div></td>
<td><A ID='IMG_5680.JPG' href='tassie2.php?fileId=IMG_5680.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5680.JPG' ALT='IMG_5680.JPG'><BR>IMG_5680.JPG<br>69.34 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5680.JPG' ALT='IMG_5680.JPG'>IMG_5680.JPG</a></div></td>
<td><A ID='IMG_5684.JPG' href='tassie2.php?fileId=IMG_5684.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5684.JPG' ALT='IMG_5684.JPG'><BR>IMG_5684.JPG<br>92.2 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5684.JPG' ALT='IMG_5684.JPG'>IMG_5684.JPG</a></div></td>
<td><A ID='IMG_5687.JPG' href='tassie2.php?fileId=IMG_5687.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5687.JPG' ALT='IMG_5687.JPG'><BR>IMG_5687.JPG<br>65.98 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5687.JPG' ALT='IMG_5687.JPG'>IMG_5687.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5694.JPG' href='tassie2.php?fileId=IMG_5694.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5694.JPG' ALT='IMG_5694.JPG'><BR>IMG_5694.JPG<br>56.83 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5694.JPG' ALT='IMG_5694.JPG'>IMG_5694.JPG</a></div></td>
<td><A ID='IMG_5697.JPG' href='tassie2.php?fileId=IMG_5697.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5697.JPG' ALT='IMG_5697.JPG'><BR>IMG_5697.JPG<br>55.58 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5697.JPG' ALT='IMG_5697.JPG'>IMG_5697.JPG</a></div></td>
<td><A ID='IMG_5700.JPG' href='tassie2.php?fileId=IMG_5700.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5700.JPG' ALT='IMG_5700.JPG'><BR>IMG_5700.JPG<br>76.91 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5700.JPG' ALT='IMG_5700.JPG'>IMG_5700.JPG</a></div></td>
<td><A ID='IMG_5702.JPG' href='tassie2.php?fileId=IMG_5702.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5702.JPG' ALT='IMG_5702.JPG'><BR>IMG_5702.JPG<br>64.62 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5702.JPG' ALT='IMG_5702.JPG'>IMG_5702.JPG</a></div></td>
<td><A ID='IMG_5705.JPG' href='tassie2.php?fileId=IMG_5705.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5705.JPG' ALT='IMG_5705.JPG'><BR>IMG_5705.JPG<br>68.51 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5705.JPG' ALT='IMG_5705.JPG'>IMG_5705.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5707.JPG' href='tassie2.php?fileId=IMG_5707.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5707.JPG' ALT='IMG_5707.JPG'><BR>IMG_5707.JPG<br>70.48 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5707.JPG' ALT='IMG_5707.JPG'>IMG_5707.JPG</a></div></td>
<td><A ID='IMG_5708.JPG' href='tassie2.php?fileId=IMG_5708.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5708.JPG' ALT='IMG_5708.JPG'><BR>IMG_5708.JPG<br>62.29 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5708.JPG' ALT='IMG_5708.JPG'>IMG_5708.JPG</a></div></td>
<td><A ID='IMG_5712.JPG' href='tassie2.php?fileId=IMG_5712.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5712.JPG' ALT='IMG_5712.JPG'><BR>IMG_5712.JPG<br>68.7 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5712.JPG' ALT='IMG_5712.JPG'>IMG_5712.JPG</a></div></td>
<td><A ID='IMG_5716.JPG' href='tassie2.php?fileId=IMG_5716.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5716.JPG' ALT='IMG_5716.JPG'><BR>IMG_5716.JPG<br>48.4 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5716.JPG' ALT='IMG_5716.JPG'>IMG_5716.JPG</a></div></td>
<td><A ID='IMG_5717.JPG' href='tassie2.php?fileId=IMG_5717.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5717.JPG' ALT='IMG_5717.JPG'><BR>IMG_5717.JPG<br>72.69 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5717.JPG' ALT='IMG_5717.JPG'>IMG_5717.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5721.JPG' href='tassie2.php?fileId=IMG_5721.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5721.JPG' ALT='IMG_5721.JPG'><BR>IMG_5721.JPG<br>116.46 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5721.JPG' ALT='IMG_5721.JPG'>IMG_5721.JPG</a></div></td>
<td><A ID='IMG_5723.JPG' href='tassie2.php?fileId=IMG_5723.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5723.JPG' ALT='IMG_5723.JPG'><BR>IMG_5723.JPG<br>160.2 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5723.JPG' ALT='IMG_5723.JPG'>IMG_5723.JPG</a></div></td>
<td><A ID='IMG_5725.JPG' href='tassie2.php?fileId=IMG_5725.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5725.JPG' ALT='IMG_5725.JPG'><BR>IMG_5725.JPG<br>135.95 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5725.JPG' ALT='IMG_5725.JPG'>IMG_5725.JPG</a></div></td>
<td><A ID='IMG_5729.JPG' href='tassie2.php?fileId=IMG_5729.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5729.JPG' ALT='IMG_5729.JPG'><BR>IMG_5729.JPG<br>104.41 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5729.JPG' ALT='IMG_5729.JPG'>IMG_5729.JPG</a></div></td>
<td><A ID='IMG_5734.JPG' href='tassie2.php?fileId=IMG_5734.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5734.JPG' ALT='IMG_5734.JPG'><BR>IMG_5734.JPG<br>86.05 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5734.JPG' ALT='IMG_5734.JPG'>IMG_5734.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5735.JPG' href='tassie2.php?fileId=IMG_5735.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5735.JPG' ALT='IMG_5735.JPG'><BR>IMG_5735.JPG<br>73.79 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5735.JPG' ALT='IMG_5735.JPG'>IMG_5735.JPG</a></div></td>
<td><A ID='IMG_5736.JPG' href='tassie2.php?fileId=IMG_5736.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5736.JPG' ALT='IMG_5736.JPG'><BR>IMG_5736.JPG<br>89.11 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5736.JPG' ALT='IMG_5736.JPG'>IMG_5736.JPG</a></div></td>
<td><A ID='IMG_5737.JPG' href='tassie2.php?fileId=IMG_5737.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5737.JPG' ALT='IMG_5737.JPG'><BR>IMG_5737.JPG<br>58.48 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5737.JPG' ALT='IMG_5737.JPG'>IMG_5737.JPG</a></div></td>
<td><A ID='IMG_5739.JPG' href='tassie2.php?fileId=IMG_5739.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5739.JPG' ALT='IMG_5739.JPG'><BR>IMG_5739.JPG<br>60.54 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5739.JPG' ALT='IMG_5739.JPG'>IMG_5739.JPG</a></div></td>
<td><A ID='IMG_5744.JPG' href='tassie2.php?fileId=IMG_5744.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5744.JPG' ALT='IMG_5744.JPG'><BR>IMG_5744.JPG<br>66.79 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5744.JPG' ALT='IMG_5744.JPG'>IMG_5744.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5745.JPG' href='tassie2.php?fileId=IMG_5745.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5745.JPG' ALT='IMG_5745.JPG'><BR>IMG_5745.JPG<br>81.87 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5745.JPG' ALT='IMG_5745.JPG'>IMG_5745.JPG</a></div></td>
<td><A ID='IMG_5747.JPG' href='tassie2.php?fileId=IMG_5747.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5747.JPG' ALT='IMG_5747.JPG'><BR>IMG_5747.JPG<br>96.56 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5747.JPG' ALT='IMG_5747.JPG'>IMG_5747.JPG</a></div></td>
<td><A ID='IMG_5754.JPG' href='tassie2.php?fileId=IMG_5754.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5754.JPG' ALT='IMG_5754.JPG'><BR>IMG_5754.JPG<br>94.63 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5754.JPG' ALT='IMG_5754.JPG'>IMG_5754.JPG</a></div></td>
<td><A ID='IMG_5760.JPG' href='tassie2.php?fileId=IMG_5760.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5760.JPG' ALT='IMG_5760.JPG'><BR>IMG_5760.JPG<br>83.12 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5760.JPG' ALT='IMG_5760.JPG'>IMG_5760.JPG</a></div></td>
<td><A ID='IMG_5763.JPG' href='tassie2.php?fileId=IMG_5763.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5763.JPG' ALT='IMG_5763.JPG'><BR>IMG_5763.JPG<br>75.11 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5763.JPG' ALT='IMG_5763.JPG'>IMG_5763.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5764.JPG' href='tassie2.php?fileId=IMG_5764.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5764.JPG' ALT='IMG_5764.JPG'><BR>IMG_5764.JPG<br>91.81 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5764.JPG' ALT='IMG_5764.JPG'>IMG_5764.JPG</a></div></td>
<td><A ID='IMG_5765.JPG' href='tassie2.php?fileId=IMG_5765.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5765.JPG' ALT='IMG_5765.JPG'><BR>IMG_5765.JPG<br>117.64 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5765.JPG' ALT='IMG_5765.JPG'>IMG_5765.JPG</a></div></td>
<td><A ID='IMG_5766.JPG' href='tassie2.php?fileId=IMG_5766.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5766.JPG' ALT='IMG_5766.JPG'><BR>IMG_5766.JPG<br>120.93 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5766.JPG' ALT='IMG_5766.JPG'>IMG_5766.JPG</a></div></td>
<td><A ID='IMG_5768.JPG' href='tassie2.php?fileId=IMG_5768.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5768.JPG' ALT='IMG_5768.JPG'><BR>IMG_5768.JPG<br>129.33 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5768.JPG' ALT='IMG_5768.JPG'>IMG_5768.JPG</a></div></td>
<td><A ID='IMG_5769.JPG' href='tassie2.php?fileId=IMG_5769.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5769.JPG' ALT='IMG_5769.JPG'><BR>IMG_5769.JPG<br>135.09 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5769.JPG' ALT='IMG_5769.JPG'>IMG_5769.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5771.JPG' href='tassie2.php?fileId=IMG_5771.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5771.JPG' ALT='IMG_5771.JPG'><BR>IMG_5771.JPG<br>106.38 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5771.JPG' ALT='IMG_5771.JPG'>IMG_5771.JPG</a></div></td>
<td><A ID='IMG_5774.JPG' href='tassie2.php?fileId=IMG_5774.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5774.JPG' ALT='IMG_5774.JPG'><BR>IMG_5774.JPG<br>82.28 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5774.JPG' ALT='IMG_5774.JPG'>IMG_5774.JPG</a></div></td>
<td><A ID='IMG_5776.JPG' href='tassie2.php?fileId=IMG_5776.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5776.JPG' ALT='IMG_5776.JPG'><BR>IMG_5776.JPG<br>68.5 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5776.JPG' ALT='IMG_5776.JPG'>IMG_5776.JPG</a></div></td>
<td><A ID='IMG_5777.JPG' href='tassie2.php?fileId=IMG_5777.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5777.JPG' ALT='IMG_5777.JPG'><BR>IMG_5777.JPG<br>110.53 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5777.JPG' ALT='IMG_5777.JPG'>IMG_5777.JPG</a></div></td>
<td><A ID='IMG_5783.JPG' href='tassie2.php?fileId=IMG_5783.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5783.JPG' ALT='IMG_5783.JPG'><BR>IMG_5783.JPG<br>61.28 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5783.JPG' ALT='IMG_5783.JPG'>IMG_5783.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5784.JPG' href='tassie2.php?fileId=IMG_5784.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5784.JPG' ALT='IMG_5784.JPG'><BR>IMG_5784.JPG<br>65.35 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5784.JPG' ALT='IMG_5784.JPG'>IMG_5784.JPG</a></div></td>
<td><A ID='IMG_5786.JPG' href='tassie2.php?fileId=IMG_5786.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5786.JPG' ALT='IMG_5786.JPG'><BR>IMG_5786.JPG<br>58.89 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5786.JPG' ALT='IMG_5786.JPG'>IMG_5786.JPG</a></div></td>
<td><A ID='IMG_5789.JPG' href='tassie2.php?fileId=IMG_5789.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5789.JPG' ALT='IMG_5789.JPG'><BR>IMG_5789.JPG<br>80.2 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5789.JPG' ALT='IMG_5789.JPG'>IMG_5789.JPG</a></div></td>
<td><A ID='IMG_5791.JPG' href='tassie2.php?fileId=IMG_5791.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5791.JPG' ALT='IMG_5791.JPG'><BR>IMG_5791.JPG<br>100.97 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5791.JPG' ALT='IMG_5791.JPG'>IMG_5791.JPG</a></div></td>
<td><A ID='IMG_5795.JPG' href='tassie2.php?fileId=IMG_5795.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5795.JPG' ALT='IMG_5795.JPG'><BR>IMG_5795.JPG<br>91.27 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5795.JPG' ALT='IMG_5795.JPG'>IMG_5795.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5796.JPG' href='tassie2.php?fileId=IMG_5796.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5796.JPG' ALT='IMG_5796.JPG'><BR>IMG_5796.JPG<br>108.25 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5796.JPG' ALT='IMG_5796.JPG'>IMG_5796.JPG</a></div></td>
<td><A ID='IMG_5797.JPG' href='tassie2.php?fileId=IMG_5797.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5797.JPG' ALT='IMG_5797.JPG'><BR>IMG_5797.JPG<br>117.37 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5797.JPG' ALT='IMG_5797.JPG'>IMG_5797.JPG</a></div></td>
<td><A ID='IMG_5798.JPG' href='tassie2.php?fileId=IMG_5798.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5798.JPG' ALT='IMG_5798.JPG'><BR>IMG_5798.JPG<br>37.69 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5798.JPG' ALT='IMG_5798.JPG'>IMG_5798.JPG</a></div></td>
<td><A ID='IMG_5799.JPG' href='tassie2.php?fileId=IMG_5799.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5799.JPG' ALT='IMG_5799.JPG'><BR>IMG_5799.JPG<br>108.09 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5799.JPG' ALT='IMG_5799.JPG'>IMG_5799.JPG</a></div></td>
<td><A ID='IMG_5801.JPG' href='tassie2.php?fileId=IMG_5801.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5801.JPG' ALT='IMG_5801.JPG'><BR>IMG_5801.JPG<br>111.94 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5801.JPG' ALT='IMG_5801.JPG'>IMG_5801.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5803.JPG' href='tassie2.php?fileId=IMG_5803.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5803.JPG' ALT='IMG_5803.JPG'><BR>IMG_5803.JPG<br>109.83 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5803.JPG' ALT='IMG_5803.JPG'>IMG_5803.JPG</a></div></td>
<td><A ID='IMG_5806.JPG' href='tassie2.php?fileId=IMG_5806.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5806.JPG' ALT='IMG_5806.JPG'><BR>IMG_5806.JPG<br>125.75 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5806.JPG' ALT='IMG_5806.JPG'>IMG_5806.JPG</a></div></td>
<td><A ID='IMG_5807.JPG' href='tassie2.php?fileId=IMG_5807.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5807.JPG' ALT='IMG_5807.JPG'><BR>IMG_5807.JPG<br>106.46 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5807.JPG' ALT='IMG_5807.JPG'>IMG_5807.JPG</a></div></td>
<td><A ID='IMG_5817.JPG' href='tassie2.php?fileId=IMG_5817.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5817.JPG' ALT='IMG_5817.JPG'><BR>IMG_5817.JPG<br>63.76 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5817.JPG' ALT='IMG_5817.JPG'>IMG_5817.JPG</a></div></td>
<td><A ID='IMG_5818.JPG' href='tassie2.php?fileId=IMG_5818.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5818.JPG' ALT='IMG_5818.JPG'><BR>IMG_5818.JPG<br>56.77 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5818.JPG' ALT='IMG_5818.JPG'>IMG_5818.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5822.JPG' href='tassie2.php?fileId=IMG_5822.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5822.JPG' ALT='IMG_5822.JPG'><BR>IMG_5822.JPG<br>79.61 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5822.JPG' ALT='IMG_5822.JPG'>IMG_5822.JPG</a></div></td>
<td><A ID='IMG_5823.JPG' href='tassie2.php?fileId=IMG_5823.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5823.JPG' ALT='IMG_5823.JPG'><BR>IMG_5823.JPG<br>93.5 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5823.JPG' ALT='IMG_5823.JPG'>IMG_5823.JPG</a></div></td>
<td><A ID='IMG_5829.JPG' href='tassie2.php?fileId=IMG_5829.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5829.JPG' ALT='IMG_5829.JPG'><BR>IMG_5829.JPG<br>43.85 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5829.JPG' ALT='IMG_5829.JPG'>IMG_5829.JPG</a></div></td>
<td><A ID='IMG_5830.JPG' href='tassie2.php?fileId=IMG_5830.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5830.JPG' ALT='IMG_5830.JPG'><BR>IMG_5830.JPG<br>106.4 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5830.JPG' ALT='IMG_5830.JPG'>IMG_5830.JPG</a></div></td>
<td><A ID='IMG_5832.JPG' href='tassie2.php?fileId=IMG_5832.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5832.JPG' ALT='IMG_5832.JPG'><BR>IMG_5832.JPG<br>45.98 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5832.JPG' ALT='IMG_5832.JPG'>IMG_5832.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5837.JPG' href='tassie2.php?fileId=IMG_5837.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5837.JPG' ALT='IMG_5837.JPG'><BR>IMG_5837.JPG<br>54.67 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5837.JPG' ALT='IMG_5837.JPG'>IMG_5837.JPG</a></div></td>
<td><A ID='IMG_5842.JPG' href='tassie2.php?fileId=IMG_5842.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5842.JPG' ALT='IMG_5842.JPG'><BR>IMG_5842.JPG<br>71.28 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5842.JPG' ALT='IMG_5842.JPG'>IMG_5842.JPG</a></div></td>
<td><A ID='IMG_5847.JPG' href='tassie2.php?fileId=IMG_5847.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5847.JPG' ALT='IMG_5847.JPG'><BR>IMG_5847.JPG<br>71.66 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5847.JPG' ALT='IMG_5847.JPG'>IMG_5847.JPG</a></div></td>
<td><A ID='IMG_5848.JPG' href='tassie2.php?fileId=IMG_5848.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5848.JPG' ALT='IMG_5848.JPG'><BR>IMG_5848.JPG<br>44.05 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5848.JPG' ALT='IMG_5848.JPG'>IMG_5848.JPG</a></div></td>
<td><A ID='IMG_5849.JPG' href='tassie2.php?fileId=IMG_5849.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5849.JPG' ALT='IMG_5849.JPG'><BR>IMG_5849.JPG<br>48.91 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5849.JPG' ALT='IMG_5849.JPG'>IMG_5849.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5851.JPG' href='tassie2.php?fileId=IMG_5851.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5851.JPG' ALT='IMG_5851.JPG'><BR>IMG_5851.JPG<br>104.8 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5851.JPG' ALT='IMG_5851.JPG'>IMG_5851.JPG</a></div></td>
<td><A ID='IMG_5853.JPG' href='tassie2.php?fileId=IMG_5853.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5853.JPG' ALT='IMG_5853.JPG'><BR>IMG_5853.JPG<br>76.62 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5853.JPG' ALT='IMG_5853.JPG'>IMG_5853.JPG</a></div></td>
<td><A ID='IMG_5857.JPG' href='tassie2.php?fileId=IMG_5857.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5857.JPG' ALT='IMG_5857.JPG'><BR>IMG_5857.JPG<br>46.34 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5857.JPG' ALT='IMG_5857.JPG'>IMG_5857.JPG</a></div></td>
<td><A ID='IMG_5863.JPG' href='tassie2.php?fileId=IMG_5863.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5863.JPG' ALT='IMG_5863.JPG'><BR>IMG_5863.JPG<br>34.04 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5863.JPG' ALT='IMG_5863.JPG'>IMG_5863.JPG</a></div></td>
<td><A ID='IMG_5866.JPG' href='tassie2.php?fileId=IMG_5866.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5866.JPG' ALT='IMG_5866.JPG'><BR>IMG_5866.JPG<br>76.37 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5866.JPG' ALT='IMG_5866.JPG'>IMG_5866.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5868.JPG' href='tassie2.php?fileId=IMG_5868.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5868.JPG' ALT='IMG_5868.JPG'><BR>IMG_5868.JPG<br>78.86 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5868.JPG' ALT='IMG_5868.JPG'>IMG_5868.JPG</a></div></td>
<td><A ID='IMG_5872.JPG' href='tassie2.php?fileId=IMG_5872.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5872.JPG' ALT='IMG_5872.JPG'><BR>IMG_5872.JPG<br>121.72 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5872.JPG' ALT='IMG_5872.JPG'>IMG_5872.JPG</a></div></td>
<td><A ID='IMG_5874.JPG' href='tassie2.php?fileId=IMG_5874.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5874.JPG' ALT='IMG_5874.JPG'><BR>IMG_5874.JPG<br>95.13 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5874.JPG' ALT='IMG_5874.JPG'>IMG_5874.JPG</a></div></td>
<td><A ID='IMG_5875.JPG' href='tassie2.php?fileId=IMG_5875.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5875.JPG' ALT='IMG_5875.JPG'><BR>IMG_5875.JPG<br>61.67 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5875.JPG' ALT='IMG_5875.JPG'>IMG_5875.JPG</a></div></td>
<td><A ID='IMG_5876.JPG' href='tassie2.php?fileId=IMG_5876.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5876.JPG' ALT='IMG_5876.JPG'><BR>IMG_5876.JPG<br>81.43 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5876.JPG' ALT='IMG_5876.JPG'>IMG_5876.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5877.JPG' href='tassie2.php?fileId=IMG_5877.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5877.JPG' ALT='IMG_5877.JPG'><BR>IMG_5877.JPG<br>81.08 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5877.JPG' ALT='IMG_5877.JPG'>IMG_5877.JPG</a></div></td>
<td><A ID='IMG_5878.JPG' href='tassie2.php?fileId=IMG_5878.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5878.JPG' ALT='IMG_5878.JPG'><BR>IMG_5878.JPG<br>54.37 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5878.JPG' ALT='IMG_5878.JPG'>IMG_5878.JPG</a></div></td>
<td><A ID='IMG_5880.JPG' href='tassie2.php?fileId=IMG_5880.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5880.JPG' ALT='IMG_5880.JPG'><BR>IMG_5880.JPG<br>76.67 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5880.JPG' ALT='IMG_5880.JPG'>IMG_5880.JPG</a></div></td>
<td><A ID='IMG_5883.JPG' href='tassie2.php?fileId=IMG_5883.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5883.JPG' ALT='IMG_5883.JPG'><BR>IMG_5883.JPG<br>79.99 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5883.JPG' ALT='IMG_5883.JPG'>IMG_5883.JPG</a></div></td>
<td><A ID='IMG_5884.JPG' href='tassie2.php?fileId=IMG_5884.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5884.JPG' ALT='IMG_5884.JPG'><BR>IMG_5884.JPG<br>57.93 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5884.JPG' ALT='IMG_5884.JPG'>IMG_5884.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5885.JPG' href='tassie2.php?fileId=IMG_5885.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5885.JPG' ALT='IMG_5885.JPG'><BR>IMG_5885.JPG<br>59.53 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5885.JPG' ALT='IMG_5885.JPG'>IMG_5885.JPG</a></div></td>
<td><A ID='IMG_5888.JPG' href='tassie2.php?fileId=IMG_5888.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5888.JPG' ALT='IMG_5888.JPG'><BR>IMG_5888.JPG<br>58.73 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5888.JPG' ALT='IMG_5888.JPG'>IMG_5888.JPG</a></div></td>
<td><A ID='IMG_5889.JPG' href='tassie2.php?fileId=IMG_5889.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5889.JPG' ALT='IMG_5889.JPG'><BR>IMG_5889.JPG<br>84.12 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5889.JPG' ALT='IMG_5889.JPG'>IMG_5889.JPG</a></div></td>
<td><A ID='IMG_5890.JPG' href='tassie2.php?fileId=IMG_5890.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5890.JPG' ALT='IMG_5890.JPG'><BR>IMG_5890.JPG<br>88.76 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5890.JPG' ALT='IMG_5890.JPG'>IMG_5890.JPG</a></div></td>
<td><A ID='IMG_5892.JPG' href='tassie2.php?fileId=IMG_5892.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5892.JPG' ALT='IMG_5892.JPG'><BR>IMG_5892.JPG<br>87.42 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5892.JPG' ALT='IMG_5892.JPG'>IMG_5892.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5894.JPG' href='tassie2.php?fileId=IMG_5894.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5894.JPG' ALT='IMG_5894.JPG'><BR>IMG_5894.JPG<br>129.55 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5894.JPG' ALT='IMG_5894.JPG'>IMG_5894.JPG</a></div></td>
<td><A ID='IMG_5896.JPG' href='tassie2.php?fileId=IMG_5896.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5896.JPG' ALT='IMG_5896.JPG'><BR>IMG_5896.JPG<br>92.45 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5896.JPG' ALT='IMG_5896.JPG'>IMG_5896.JPG</a></div></td>
<td><A ID='IMG_5898.JPG' href='tassie2.php?fileId=IMG_5898.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5898.JPG' ALT='IMG_5898.JPG'><BR>IMG_5898.JPG<br>73.92 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5898.JPG' ALT='IMG_5898.JPG'>IMG_5898.JPG</a></div></td>
<td><A ID='IMG_5902.JPG' href='tassie2.php?fileId=IMG_5902.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5902.JPG' ALT='IMG_5902.JPG'><BR>IMG_5902.JPG<br>80.67 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5902.JPG' ALT='IMG_5902.JPG'>IMG_5902.JPG</a></div></td>
<td><A ID='IMG_5903.JPG' href='tassie2.php?fileId=IMG_5903.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5903.JPG' ALT='IMG_5903.JPG'><BR>IMG_5903.JPG<br>82.23 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5903.JPG' ALT='IMG_5903.JPG'>IMG_5903.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5905.JPG' href='tassie2.php?fileId=IMG_5905.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5905.JPG' ALT='IMG_5905.JPG'><BR>IMG_5905.JPG<br>74.9 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5905.JPG' ALT='IMG_5905.JPG'>IMG_5905.JPG</a></div></td>
<td><A ID='IMG_5912.JPG' href='tassie2.php?fileId=IMG_5912.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5912.JPG' ALT='IMG_5912.JPG'><BR>IMG_5912.JPG<br>104.73 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5912.JPG' ALT='IMG_5912.JPG'>IMG_5912.JPG</a></div></td>
<td><A ID='IMG_5916.JPG' href='tassie2.php?fileId=IMG_5916.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5916.JPG' ALT='IMG_5916.JPG'><BR>IMG_5916.JPG<br>109.55 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5916.JPG' ALT='IMG_5916.JPG'>IMG_5916.JPG</a></div></td>
<td><A ID='IMG_5917.JPG' href='tassie2.php?fileId=IMG_5917.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5917.JPG' ALT='IMG_5917.JPG'><BR>IMG_5917.JPG<br>131.51 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5917.JPG' ALT='IMG_5917.JPG'>IMG_5917.JPG</a></div></td>
<td><A ID='IMG_5923.JPG' href='tassie2.php?fileId=IMG_5923.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5923.JPG' ALT='IMG_5923.JPG'><BR>IMG_5923.JPG<br>70.58 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5923.JPG' ALT='IMG_5923.JPG'>IMG_5923.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5924.JPG' href='tassie2.php?fileId=IMG_5924.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5924.JPG' ALT='IMG_5924.JPG'><BR>IMG_5924.JPG<br>68.92 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5924.JPG' ALT='IMG_5924.JPG'>IMG_5924.JPG</a></div></td>
<td><A ID='IMG_5926.JPG' href='tassie2.php?fileId=IMG_5926.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5926.JPG' ALT='IMG_5926.JPG'><BR>IMG_5926.JPG<br>103.03 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5926.JPG' ALT='IMG_5926.JPG'>IMG_5926.JPG</a></div></td>
<td><A ID='IMG_5927.JPG' href='tassie2.php?fileId=IMG_5927.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5927.JPG' ALT='IMG_5927.JPG'><BR>IMG_5927.JPG<br>117.57 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5927.JPG' ALT='IMG_5927.JPG'>IMG_5927.JPG</a></div></td>
<td><A ID='IMG_5928.JPG' href='tassie2.php?fileId=IMG_5928.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5928.JPG' ALT='IMG_5928.JPG'><BR>IMG_5928.JPG<br>95.03 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5928.JPG' ALT='IMG_5928.JPG'>IMG_5928.JPG</a></div></td>
<td><A ID='IMG_5932.JPG' href='tassie2.php?fileId=IMG_5932.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5932.JPG' ALT='IMG_5932.JPG'><BR>IMG_5932.JPG<br>89.43 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5932.JPG' ALT='IMG_5932.JPG'>IMG_5932.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5934.JPG' href='tassie2.php?fileId=IMG_5934.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5934.JPG' ALT='IMG_5934.JPG'><BR>IMG_5934.JPG<br>96.74 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5934.JPG' ALT='IMG_5934.JPG'>IMG_5934.JPG</a></div></td>
<td><A ID='IMG_5941.JPG' href='tassie2.php?fileId=IMG_5941.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5941.JPG' ALT='IMG_5941.JPG'><BR>IMG_5941.JPG<br>75.65 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5941.JPG' ALT='IMG_5941.JPG'>IMG_5941.JPG</a></div></td>
<td><A ID='IMG_5949.JPG' href='tassie2.php?fileId=IMG_5949.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5949.JPG' ALT='IMG_5949.JPG'><BR>IMG_5949.JPG<br>115.34 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5949.JPG' ALT='IMG_5949.JPG'>IMG_5949.JPG</a></div></td>
<td><A ID='IMG_5950.JPG' href='tassie2.php?fileId=IMG_5950.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5950.JPG' ALT='IMG_5950.JPG'><BR>IMG_5950.JPG<br>55.59 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5950.JPG' ALT='IMG_5950.JPG'>IMG_5950.JPG</a></div></td>
<td><A ID='IMG_5951.JPG' href='tassie2.php?fileId=IMG_5951.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5951.JPG' ALT='IMG_5951.JPG'><BR>IMG_5951.JPG<br>116.26 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5951.JPG' ALT='IMG_5951.JPG'>IMG_5951.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5955.JPG' href='tassie2.php?fileId=IMG_5955.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5955.JPG' ALT='IMG_5955.JPG'><BR>IMG_5955.JPG<br>53.95 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5955.JPG' ALT='IMG_5955.JPG'>IMG_5955.JPG</a></div></td>
<td><A ID='IMG_5961.JPG' href='tassie2.php?fileId=IMG_5961.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5961.JPG' ALT='IMG_5961.JPG'><BR>IMG_5961.JPG<br>89.99 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5961.JPG' ALT='IMG_5961.JPG'>IMG_5961.JPG</a></div></td>
<td><A ID='IMG_5964.JPG' href='tassie2.php?fileId=IMG_5964.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5964.JPG' ALT='IMG_5964.JPG'><BR>IMG_5964.JPG<br>126.11 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5964.JPG' ALT='IMG_5964.JPG'>IMG_5964.JPG</a></div></td>
<td><A ID='IMG_5966.JPG' href='tassie2.php?fileId=IMG_5966.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5966.JPG' ALT='IMG_5966.JPG'><BR>IMG_5966.JPG<br>82.87 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5966.JPG' ALT='IMG_5966.JPG'>IMG_5966.JPG</a></div></td>
<td><A ID='IMG_5970.JPG' href='tassie2.php?fileId=IMG_5970.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5970.JPG' ALT='IMG_5970.JPG'><BR>IMG_5970.JPG<br>100.13 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5970.JPG' ALT='IMG_5970.JPG'>IMG_5970.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5986.JPG' href='tassie2.php?fileId=IMG_5986.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5986.JPG' ALT='IMG_5986.JPG'><BR>IMG_5986.JPG<br>86.96 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5986.JPG' ALT='IMG_5986.JPG'>IMG_5986.JPG</a></div></td>
<td><A ID='IMG_5989.JPG' href='tassie2.php?fileId=IMG_5989.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5989.JPG' ALT='IMG_5989.JPG'><BR>IMG_5989.JPG<br>107.01 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5989.JPG' ALT='IMG_5989.JPG'>IMG_5989.JPG</a></div></td>
<td><A ID='IMG_5991.JPG' href='tassie2.php?fileId=IMG_5991.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5991.JPG' ALT='IMG_5991.JPG'><BR>IMG_5991.JPG<br>115.51 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5991.JPG' ALT='IMG_5991.JPG'>IMG_5991.JPG</a></div></td>
<td><A ID='IMG_5992.JPG' href='tassie2.php?fileId=IMG_5992.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5992.JPG' ALT='IMG_5992.JPG'><BR>IMG_5992.JPG<br>106.01 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5992.JPG' ALT='IMG_5992.JPG'>IMG_5992.JPG</a></div></td>
<td><A ID='IMG_5995.JPG' href='tassie2.php?fileId=IMG_5995.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5995.JPG' ALT='IMG_5995.JPG'><BR>IMG_5995.JPG<br>106.53 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5995.JPG' ALT='IMG_5995.JPG'>IMG_5995.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5999.JPG' href='tassie2.php?fileId=IMG_5999.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_5999.JPG' ALT='IMG_5999.JPG'><BR>IMG_5999.JPG<br>81.53 KB</a><div class='inv'><br><a href='./images/20060107/IMG_5999.JPG' ALT='IMG_5999.JPG'>IMG_5999.JPG</a></div></td>
<td><A ID='IMG_6000.JPG' href='tassie2.php?fileId=IMG_6000.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_6000.JPG' ALT='IMG_6000.JPG'><BR>IMG_6000.JPG<br>96.57 KB</a><div class='inv'><br><a href='./images/20060107/IMG_6000.JPG' ALT='IMG_6000.JPG'>IMG_6000.JPG</a></div></td>
<td><A ID='IMG_6003.JPG' href='tassie2.php?fileId=IMG_6003.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_6003.JPG' ALT='IMG_6003.JPG'><BR>IMG_6003.JPG<br>122.86 KB</a><div class='inv'><br><a href='./images/20060107/IMG_6003.JPG' ALT='IMG_6003.JPG'>IMG_6003.JPG</a></div></td>
<td><A ID='IMG_6004.JPG' href='tassie2.php?fileId=IMG_6004.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_6004.JPG' ALT='IMG_6004.JPG'><BR>IMG_6004.JPG<br>66.27 KB</a><div class='inv'><br><a href='./images/20060107/IMG_6004.JPG' ALT='IMG_6004.JPG'>IMG_6004.JPG</a></div></td>
<td><A ID='IMG_6005.JPG' href='tassie2.php?fileId=IMG_6005.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_6005.JPG' ALT='IMG_6005.JPG'><BR>IMG_6005.JPG<br>75.68 KB</a><div class='inv'><br><a href='./images/20060107/IMG_6005.JPG' ALT='IMG_6005.JPG'>IMG_6005.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_6006.JPG' href='tassie2.php?fileId=IMG_6006.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_6006.JPG' ALT='IMG_6006.JPG'><BR>IMG_6006.JPG<br>77.97 KB</a><div class='inv'><br><a href='./images/20060107/IMG_6006.JPG' ALT='IMG_6006.JPG'>IMG_6006.JPG</a></div></td>
<td><A ID='IMG_6007.JPG' href='tassie2.php?fileId=IMG_6007.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_6007.JPG' ALT='IMG_6007.JPG'><BR>IMG_6007.JPG<br>83.48 KB</a><div class='inv'><br><a href='./images/20060107/IMG_6007.JPG' ALT='IMG_6007.JPG'>IMG_6007.JPG</a></div></td>
<td><A ID='IMG_6008.JPG' href='tassie2.php?fileId=IMG_6008.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_6008.JPG' ALT='IMG_6008.JPG'><BR>IMG_6008.JPG<br>52.62 KB</a><div class='inv'><br><a href='./images/20060107/IMG_6008.JPG' ALT='IMG_6008.JPG'>IMG_6008.JPG</a></div></td>
<td><A ID='IMG_6012.JPG' href='tassie2.php?fileId=IMG_6012.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_6012.JPG' ALT='IMG_6012.JPG'><BR>IMG_6012.JPG<br>73.52 KB</a><div class='inv'><br><a href='./images/20060107/IMG_6012.JPG' ALT='IMG_6012.JPG'>IMG_6012.JPG</a></div></td>
<td><A ID='IMG_6014.JPG' href='tassie2.php?fileId=IMG_6014.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_6014.JPG' ALT='IMG_6014.JPG'><BR>IMG_6014.JPG<br>63.44 KB</a><div class='inv'><br><a href='./images/20060107/IMG_6014.JPG' ALT='IMG_6014.JPG'>IMG_6014.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_6016.JPG' href='tassie2.php?fileId=IMG_6016.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_6016.JPG' ALT='IMG_6016.JPG'><BR>IMG_6016.JPG<br>93.32 KB</a><div class='inv'><br><a href='./images/20060107/IMG_6016.JPG' ALT='IMG_6016.JPG'>IMG_6016.JPG</a></div></td>
<td><A ID='IMG_6022.JPG' href='tassie2.php?fileId=IMG_6022.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_6022.JPG' ALT='IMG_6022.JPG'><BR>IMG_6022.JPG<br>49.11 KB</a><div class='inv'><br><a href='./images/20060107/IMG_6022.JPG' ALT='IMG_6022.JPG'>IMG_6022.JPG</a></div></td>
<td><A ID='IMG_6027.JPG' href='tassie2.php?fileId=IMG_6027.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_6027.JPG' ALT='IMG_6027.JPG'><BR>IMG_6027.JPG<br>79.35 KB</a><div class='inv'><br><a href='./images/20060107/IMG_6027.JPG' ALT='IMG_6027.JPG'>IMG_6027.JPG</a></div></td>
<td><A ID='IMG_6029.JPG' href='tassie2.php?fileId=IMG_6029.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_6029.JPG' ALT='IMG_6029.JPG'><BR>IMG_6029.JPG<br>58.97 KB</a><div class='inv'><br><a href='./images/20060107/IMG_6029.JPG' ALT='IMG_6029.JPG'>IMG_6029.JPG</a></div></td>
<td><A ID='IMG_6032.JPG' href='tassie2.php?fileId=IMG_6032.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_6032.JPG' ALT='IMG_6032.JPG'><BR>IMG_6032.JPG<br>75.88 KB</a><div class='inv'><br><a href='./images/20060107/IMG_6032.JPG' ALT='IMG_6032.JPG'>IMG_6032.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_6035.JPG' href='tassie2.php?fileId=IMG_6035.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_6035.JPG' ALT='IMG_6035.JPG'><BR>IMG_6035.JPG<br>52.99 KB</a><div class='inv'><br><a href='./images/20060107/IMG_6035.JPG' ALT='IMG_6035.JPG'>IMG_6035.JPG</a></div></td>
<td><A ID='IMG_6037.JPG' href='tassie2.php?fileId=IMG_6037.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_6037.JPG' ALT='IMG_6037.JPG'><BR>IMG_6037.JPG<br>71.79 KB</a><div class='inv'><br><a href='./images/20060107/IMG_6037.JPG' ALT='IMG_6037.JPG'>IMG_6037.JPG</a></div></td>
<td><A ID='IMG_6038.JPG' href='tassie2.php?fileId=IMG_6038.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_6038.JPG' ALT='IMG_6038.JPG'><BR>IMG_6038.JPG<br>86.6 KB</a><div class='inv'><br><a href='./images/20060107/IMG_6038.JPG' ALT='IMG_6038.JPG'>IMG_6038.JPG</a></div></td>
<td><A ID='IMG_6042.JPG' href='tassie2.php?fileId=IMG_6042.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_6042.JPG' ALT='IMG_6042.JPG'><BR>IMG_6042.JPG<br>97.05 KB</a><div class='inv'><br><a href='./images/20060107/IMG_6042.JPG' ALT='IMG_6042.JPG'>IMG_6042.JPG</a></div></td>
<td><A ID='IMG_6043.JPG' href='tassie2.php?fileId=IMG_6043.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_6043.JPG' ALT='IMG_6043.JPG'><BR>IMG_6043.JPG<br>82.48 KB</a><div class='inv'><br><a href='./images/20060107/IMG_6043.JPG' ALT='IMG_6043.JPG'>IMG_6043.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_6044.JPG' href='tassie2.php?fileId=IMG_6044.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_6044.JPG' ALT='IMG_6044.JPG'><BR>IMG_6044.JPG<br>62.09 KB</a><div class='inv'><br><a href='./images/20060107/IMG_6044.JPG' ALT='IMG_6044.JPG'>IMG_6044.JPG</a></div></td>
<td><A ID='IMG_6046.JPG' href='tassie2.php?fileId=IMG_6046.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_6046.JPG' ALT='IMG_6046.JPG'><BR>IMG_6046.JPG<br>57.21 KB</a><div class='inv'><br><a href='./images/20060107/IMG_6046.JPG' ALT='IMG_6046.JPG'>IMG_6046.JPG</a></div></td>
<td><A ID='IMG_6047.JPG' href='tassie2.php?fileId=IMG_6047.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_6047.JPG' ALT='IMG_6047.JPG'><BR>IMG_6047.JPG<br>100.39 KB</a><div class='inv'><br><a href='./images/20060107/IMG_6047.JPG' ALT='IMG_6047.JPG'>IMG_6047.JPG</a></div></td>
<td><A ID='IMG_6048.JPG' href='tassie2.php?fileId=IMG_6048.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_6048.JPG' ALT='IMG_6048.JPG'><BR>IMG_6048.JPG<br>93.55 KB</a><div class='inv'><br><a href='./images/20060107/IMG_6048.JPG' ALT='IMG_6048.JPG'>IMG_6048.JPG</a></div></td>
<td><A ID='IMG_6049.JPG' href='tassie2.php?fileId=IMG_6049.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_6049.JPG' ALT='IMG_6049.JPG'><BR>IMG_6049.JPG<br>40.41 KB</a><div class='inv'><br><a href='./images/20060107/IMG_6049.JPG' ALT='IMG_6049.JPG'>IMG_6049.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_6053.JPG' href='tassie2.php?fileId=IMG_6053.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_6053.JPG' ALT='IMG_6053.JPG'><BR>IMG_6053.JPG<br>75.41 KB</a><div class='inv'><br><a href='./images/20060107/IMG_6053.JPG' ALT='IMG_6053.JPG'>IMG_6053.JPG</a></div></td>
<td><A ID='IMG_6055.JPG' href='tassie2.php?fileId=IMG_6055.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_6055.JPG' ALT='IMG_6055.JPG'><BR>IMG_6055.JPG<br>65.08 KB</a><div class='inv'><br><a href='./images/20060107/IMG_6055.JPG' ALT='IMG_6055.JPG'>IMG_6055.JPG</a></div></td>
<td><A ID='IMG_6056.JPG' href='tassie2.php?fileId=IMG_6056.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_6056.JPG' ALT='IMG_6056.JPG'><BR>IMG_6056.JPG<br>70.34 KB</a><div class='inv'><br><a href='./images/20060107/IMG_6056.JPG' ALT='IMG_6056.JPG'>IMG_6056.JPG</a></div></td>
<td><A ID='IMG_6064.JPG' href='tassie2.php?fileId=IMG_6064.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_6064.JPG' ALT='IMG_6064.JPG'><BR>IMG_6064.JPG<br>63.97 KB</a><div class='inv'><br><a href='./images/20060107/IMG_6064.JPG' ALT='IMG_6064.JPG'>IMG_6064.JPG</a></div></td>
<td><A ID='IMG_6067.JPG' href='tassie2.php?fileId=IMG_6067.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060107/IMG_6067.JPG' ALT='IMG_6067.JPG'><BR>IMG_6067.JPG<br>55.97 KB</a><div class='inv'><br><a href='./images/20060107/IMG_6067.JPG' ALT='IMG_6067.JPG'>IMG_6067.JPG</a></div></td>
</tr>
</table>	</div>
</div>
</body>
</html>