<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - December 2006 - Q&A letters</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="Q&A letters">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="Q&A letters" href='masterit200601.php'>January 2006</a></li>
<li><a title="Q&A letters" href='masterit200602.php'>February 2006</a></li>
<li><a title="Q&A letters" href='masterit200603.php'>March 2006</a></li>
<li><a title="Q&A letters" href='masterit200604.php'>April 2006</a></li>
<li><a title="Q&A letters" href='masterit200605.php'>May 2006</a></li>
<li><a title="Q&A letters" href='masterit200606.php'>June 2006</a></li>
<li><a title="Q&A letters" href='masterit200607.php'>July 2006</a></li>
<li><a title="Q&A letters" href='masterit200608.php'>August 2006</a></li>
<li><a title="Q&A letters" href='masterit200609.php'>September 2006</a></li>
<li><a title="Q&A letters" href='masterit200610.php'>October 2006</a></li>
<li><a title="Q&A letters" href='masterit200611.php'>November 2006</a></li>
<li><div class='activemenu'>December 2006</div></li>
<li> </li><br><li>Or go back to:</li><li><a title='Q&A/MasterIT letters from 2006' href="masterit2006.php">2006 archive</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>December 2006</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Mark's writing' href="written.php">Professional Writing</a> > <a title='My weekly Q&A column in The Australian' href="masterIT.php">MasterIT</a> > <a title='Q&A/MasterIT letters from 2006' href="masterit2006.php">2006 archive</a> > <a title='Q&A letters' href="masterit200612.php">December 2006</a>
<br><br>		<br>
<h2>5/12/06</h2><br>
<b>I took your advice regarding getting a spam filter, but while looking on one of the sites, I now have a new task bar, toolbar888 - how do I remove it?</b><br>
<br>
Unfortunately toolbar888 appears to be a piece of spyware.<br>
<br>
It's sad, but these days even benevolent programs like spam filters and their kin can turn out to be Trojans that harbour nasties like this - the very things they're supposed to remove.<br>
<br>
Grab yourself a reputable spyware remover like Adaware (www.lavasoft.de) or Spybot Search and Destroy (www.safer-networking.org); they should make short work of the grubby little monster.<br>
<br>
<br>
<b>I was wondering if it's possible to make Windows run certain programs automatically, at a given time and/or interval? For example, I would like to set up an automatic defrag every month or so, to run in the middle of the night.</b><br>
<br>
It's quite easy to make XP run programs automatically; you just need to become acquainted with the Task Scheduler.<br>
<br>
It's accessed via the Control Panel. The option you are after is called "Scheduled Tasks". If you're using the newer, simplified XP control panel layout, rather than the classic layout, it's filed under "Performance & Maintenance". <br>
<br>
Once open, double click the "Add Scheduled Task" icon, and proceed through the wizard. You'll need to tell it which program to run (by browsing to its location), and, of course, when to run it.<br>
<br>
For once Microsoft have got it right, and you can specify a variety of schedules and options; examples include: run once only, or at startup, daily, weekly, or when your computer is idle.<br>
<br>
Setting up a task to run a full defrag is, therefore, pretty easy. Microsoft even have full instructions for doing it yourself at tinyurl.com/4k6r8.<br>
<br>
Bear in mind that XP already does a partial defrag from time to time when your system is idle, so you probably don't need to schedule a full defrag terribly often.<br>
<br>
Also, it's a good idea to think about scheduling a backup before each defrag. The MS defrag is fairly safe, but nonetheless, if the power goes out in the middle of such an operation the potential for total disaster, albeit small, is still there.<br>
<br>
<i><p>Did the information on this page help you? Entertain you? Bore you? <a href="contact.php?subject=MasterIT">Drop me a line</a>.</p>

<p>If you're feeling particularly generous, you can even <a href="buypics.php">click here to send me some dot-com riches</a>. Think of it as online busking.</i></p>
	</div>
</div>
</body>
</html>