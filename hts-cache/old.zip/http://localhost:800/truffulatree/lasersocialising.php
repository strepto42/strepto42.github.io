<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - Laser Socialising - Image Gallery</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="Image Gallery">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="Pictures of my 28th Birthday party complete with Sparkler Bomb" href='28th.php'>28th Birthday</a></li>
<li><a title="Pictures of my 30th Birthday party" href='30th.php'>30th Birthday</a></li>
<li><a title="Michael Shamgar and Lindsay Halamek's 30th birthday bash photos" href='sl30th.php'>Shams & Linds' 30th</a></li>
<li><a title="Pictures of Andy Marinos's new flat, cat Toby, and Mum Pam Swain" href='andycatandflat.php'>Andy's Cat & Flat</a></li>
<li><a title="Pictures of a visit to Stephen Jackson's Farm" href='jackovisit.php'>Jacko's Farm</a></li>
<li><a title="Pictures taken at the Peace Convergence action in Rockhampton and Yeppoon in June 2005 to protest the joint US Australia military exercises (Operation Talisman Sabre)" href='peaceconvergence.php'>Peace Convergence</a></li>
<li><a title="Sydney trip - April '06" href='bridges.php'>Sydney, April 06</a></li>
<li><a title="Pics of Naima's 28th birthday dinner" href='mim28th.php'>Naima's 28th</a></li>
<li><a title="Brisbane CBD and the Story Bridge" href='brisbanepics1.php'>Brissie by Night 1</a></li>
<li><a title="Lamington National Park" href='lamington.php'>Lamington NP</a></li>
<li><a title="Various creatures and views from our Brisbane back yard" href='backyard.php'>Backyard Creatures</a></li>
<li><a title="Opening day of the Eleanor Schonell (Green) Bridge" href='greenbridge.php'>Green Bridge</a></li>
<li><a title="Pictutres from the 2006 Woodford Folk Festival" href='woodford0607.php'>Woodford 2006-2007</a></li>
<li><a title="One Cute Puppy" href='jezebel.php'>Jezebel</a></li>
<li><a title="Climbing at Kangaroo Point Cliffs" href='kangaroopt1.php'>Heather's Visit</a></li>
<li><a title="0x0021st (33rd) birthday celebrations" href='0x0021st.php'>0x0021st Birthday</a></li>
<li><a title="Nuptial photography" href='guyandalison.php'>Guy and Alison's Wedding</a></li>
<li><a title="Pictures from the 2007 Woodford Folk Festival" href='woodford0708.php'>Woodford 2007-2008</a></li>
<li><a title="Image gallery" href='sydneytrip0802.php'>Sydney & Yacaaba Head</a></li>
<li><a title="An impressive show by nature" href='lightning.php'>Thunderstorm Moonrise</a></li>
<li><a title="Frightening pictures of a shrinking beard" href='debearding.php'>De-bearding</a></li>
<li><a title="More Nuptial Photography" href='michaelandkaren.php'>Michael and Karen's Wedding</a></li>
<li><a title="A night of celebration" href='andrews21st.php'>Andrew's 21st</a></li>
<li><a title="Image Gallery" href='bloodyknee.php'>Bloody Knee</a></li>
<li><a title="Image Gallery" href='tyesbirthday.php'>Tye's Birthday</a></li>
<li><div class='activemenu'>Laser Socialising</div></li>
<li><a title="Image Gallery" href='heatherandevan.php'>Heather and Evan's Wedding</a></li>
<li><a title="Image Gallery" href='woodford0809.php'>Woodford 2008-2009</a></li>
<li><a title="Image Gallery" href='allyandben.php'>Ally and Ben's Wedding</a></li>
<li><a title="Image Gallery" href='annes30th.php'>Anne's 30th</a></li>
<li><a title="Image Gallery" href='possumcreek.php'>Possum Creek</a></li>
<li><a title="Image Gallery" href='jamnight.php'>Jam Night</a></li>
<li><a title="Image Gallery" href='cunninghamsgap.php'>Cunningham's Gap</a></li>
<li><a title="Image Gallery" href='bigcat.php'>Diving on Big Cat</a></li>
<li><a title="Images from my birthday jam" href='birthdayjam.php'>Music, mayhem and merriment</a></li>
<li><a title="Image Gallery" href='fuzzypolaroidpics.php'>Fuzzy Polaroid</a></li>
<li><a title="Image Gallery" href='zombiewalk2009.php'>2009 Zombie Walk</a></li>
<li> </li><br><li>Or go back to:</li><li><a title='Picture galleries' href="pictures.php">Photography</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>Laser Socialising</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Picture galleries' href="pictures.php">Photography</a> > <a title='Image Gallery' href="lasersocialising.php">Laser Socialising</a>
<br><br>		

<p>Good food, great company, fancy cameras, red wine and a green laser. What more could you need for a top evening?</p>
<br><br>
All images in this gallery:<br>
<table width='800'>
<tr>
</tr>
<tr><td><A ID='IMG_0437.JPG' href='lasersocialising.php?fileId=IMG_0437.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20081118/IMG_0437.JPG' ALT='IMG_0437.JPG'><BR>IMG_0437.JPG<br>66.66 KB</a><div class='inv'><br><a href='./images/20081118/IMG_0437.JPG' ALT='IMG_0437.JPG'>IMG_0437.JPG</a></div></td>
<td><A ID='IMG_0485.JPG' href='lasersocialising.php?fileId=IMG_0485.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20081118/IMG_0485.JPG' ALT='IMG_0485.JPG'><BR>IMG_0485.JPG<br>59.79 KB</a><div class='inv'><br><a href='./images/20081118/IMG_0485.JPG' ALT='IMG_0485.JPG'>IMG_0485.JPG</a></div></td>
<td><A ID='IMG_0486.JPG' href='lasersocialising.php?fileId=IMG_0486.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20081118/IMG_0486.JPG' ALT='IMG_0486.JPG'><BR>IMG_0486.JPG<br>47.78 KB</a><div class='inv'><br><a href='./images/20081118/IMG_0486.JPG' ALT='IMG_0486.JPG'>IMG_0486.JPG</a></div></td>
<td><A ID='IMG_0488.JPG' href='lasersocialising.php?fileId=IMG_0488.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20081118/IMG_0488.JPG' ALT='IMG_0488.JPG'><BR>IMG_0488.JPG<br>53.01 KB</a><div class='inv'><br><a href='./images/20081118/IMG_0488.JPG' ALT='IMG_0488.JPG'>IMG_0488.JPG</a></div></td>
<td><A ID='IMG_0500.JPG' href='lasersocialising.php?fileId=IMG_0500.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20081118/IMG_0500.JPG' ALT='IMG_0500.JPG'><BR>IMG_0500.JPG<br>36 KB</a><div class='inv'><br><a href='./images/20081118/IMG_0500.JPG' ALT='IMG_0500.JPG'>IMG_0500.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_0502.JPG' href='lasersocialising.php?fileId=IMG_0502.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20081118/IMG_0502.JPG' ALT='IMG_0502.JPG'><BR>IMG_0502.JPG<br>76.72 KB</a><div class='inv'><br><a href='./images/20081118/IMG_0502.JPG' ALT='IMG_0502.JPG'>IMG_0502.JPG</a></div></td>
<td><A ID='IMG_0504.JPG' href='lasersocialising.php?fileId=IMG_0504.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20081118/IMG_0504.JPG' ALT='IMG_0504.JPG'><BR>IMG_0504.JPG<br>75.48 KB</a><div class='inv'><br><a href='./images/20081118/IMG_0504.JPG' ALT='IMG_0504.JPG'>IMG_0504.JPG</a></div></td>
<td><A ID='IMG_0516.JPG' href='lasersocialising.php?fileId=IMG_0516.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20081118/IMG_0516.JPG' ALT='IMG_0516.JPG'><BR>IMG_0516.JPG<br>62.01 KB</a><div class='inv'><br><a href='./images/20081118/IMG_0516.JPG' ALT='IMG_0516.JPG'>IMG_0516.JPG</a></div></td>
<td><A ID='IMG_0520.JPG' href='lasersocialising.php?fileId=IMG_0520.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20081118/IMG_0520.JPG' ALT='IMG_0520.JPG'><BR>IMG_0520.JPG<br>29.78 KB</a><div class='inv'><br><a href='./images/20081118/IMG_0520.JPG' ALT='IMG_0520.JPG'>IMG_0520.JPG</a></div></td>
<td><A ID='IMG_0522.JPG' href='lasersocialising.php?fileId=IMG_0522.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20081118/IMG_0522.JPG' ALT='IMG_0522.JPG'><BR>IMG_0522.JPG<br>68.6 KB</a><div class='inv'><br><a href='./images/20081118/IMG_0522.JPG' ALT='IMG_0522.JPG'>IMG_0522.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_0524.JPG' href='lasersocialising.php?fileId=IMG_0524.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20081118/IMG_0524.JPG' ALT='IMG_0524.JPG'><BR>IMG_0524.JPG<br>51.87 KB</a><div class='inv'><br><a href='./images/20081118/IMG_0524.JPG' ALT='IMG_0524.JPG'>IMG_0524.JPG</a></div></td>
<td><A ID='IMG_0525.JPG' href='lasersocialising.php?fileId=IMG_0525.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20081118/IMG_0525.JPG' ALT='IMG_0525.JPG'><BR>IMG_0525.JPG<br>46.73 KB</a><div class='inv'><br><a href='./images/20081118/IMG_0525.JPG' ALT='IMG_0525.JPG'>IMG_0525.JPG</a></div></td>
<td><A ID='IMG_0555.JPG' href='lasersocialising.php?fileId=IMG_0555.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20081118/IMG_0555.JPG' ALT='IMG_0555.JPG'><BR>IMG_0555.JPG<br>36.37 KB</a><div class='inv'><br><a href='./images/20081118/IMG_0555.JPG' ALT='IMG_0555.JPG'>IMG_0555.JPG</a></div></td>
<td><A ID='IMG_0566.JPG' href='lasersocialising.php?fileId=IMG_0566.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20081118/IMG_0566.JPG' ALT='IMG_0566.JPG'><BR>IMG_0566.JPG<br>45.1 KB</a><div class='inv'><br><a href='./images/20081118/IMG_0566.JPG' ALT='IMG_0566.JPG'>IMG_0566.JPG</a></div></td>
<td><A ID='IMG_0570.JPG' href='lasersocialising.php?fileId=IMG_0570.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20081118/IMG_0570.JPG' ALT='IMG_0570.JPG'><BR>IMG_0570.JPG<br>48.38 KB</a><div class='inv'><br><a href='./images/20081118/IMG_0570.JPG' ALT='IMG_0570.JPG'>IMG_0570.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_0575.JPG' href='lasersocialising.php?fileId=IMG_0575.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20081118/IMG_0575.JPG' ALT='IMG_0575.JPG'><BR>IMG_0575.JPG<br>56.45 KB</a><div class='inv'><br><a href='./images/20081118/IMG_0575.JPG' ALT='IMG_0575.JPG'>IMG_0575.JPG</a></div></td>
<td><A ID='IMG_0584.JPG' href='lasersocialising.php?fileId=IMG_0584.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20081118/IMG_0584.JPG' ALT='IMG_0584.JPG'><BR>IMG_0584.JPG<br>83.48 KB</a><div class='inv'><br><a href='./images/20081118/IMG_0584.JPG' ALT='IMG_0584.JPG'>IMG_0584.JPG</a></div></td>
<td><A ID='IMG_0586.JPG' href='lasersocialising.php?fileId=IMG_0586.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20081118/IMG_0586.JPG' ALT='IMG_0586.JPG'><BR>IMG_0586.JPG<br>69.96 KB</a><div class='inv'><br><a href='./images/20081118/IMG_0586.JPG' ALT='IMG_0586.JPG'>IMG_0586.JPG</a></div></td>
<td><A ID='IMG_0588.JPG' href='lasersocialising.php?fileId=IMG_0588.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20081118/IMG_0588.JPG' ALT='IMG_0588.JPG'><BR>IMG_0588.JPG<br>71.91 KB</a><div class='inv'><br><a href='./images/20081118/IMG_0588.JPG' ALT='IMG_0588.JPG'>IMG_0588.JPG</a></div></td>
<td><A ID='IMG_0590.JPG' href='lasersocialising.php?fileId=IMG_0590.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20081118/IMG_0590.JPG' ALT='IMG_0590.JPG'><BR>IMG_0590.JPG<br>64.3 KB</a><div class='inv'><br><a href='./images/20081118/IMG_0590.JPG' ALT='IMG_0590.JPG'>IMG_0590.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_0592.JPG' href='lasersocialising.php?fileId=IMG_0592.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20081118/IMG_0592.JPG' ALT='IMG_0592.JPG'><BR>IMG_0592.JPG<br>72.71 KB</a><div class='inv'><br><a href='./images/20081118/IMG_0592.JPG' ALT='IMG_0592.JPG'>IMG_0592.JPG</a></div></td>
<td><A ID='IMG_0593.JPG' href='lasersocialising.php?fileId=IMG_0593.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20081118/IMG_0593.JPG' ALT='IMG_0593.JPG'><BR>IMG_0593.JPG<br>79 KB</a><div class='inv'><br><a href='./images/20081118/IMG_0593.JPG' ALT='IMG_0593.JPG'>IMG_0593.JPG</a></div></td>
<td><A ID='IMG_0594.JPG' href='lasersocialising.php?fileId=IMG_0594.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20081118/IMG_0594.JPG' ALT='IMG_0594.JPG'><BR>IMG_0594.JPG<br>69.43 KB</a><div class='inv'><br><a href='./images/20081118/IMG_0594.JPG' ALT='IMG_0594.JPG'>IMG_0594.JPG</a></div></td>
<td><A ID='IMG_0596.JPG' href='lasersocialising.php?fileId=IMG_0596.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20081118/IMG_0596.JPG' ALT='IMG_0596.JPG'><BR>IMG_0596.JPG<br>50.82 KB</a><div class='inv'><br><a href='./images/20081118/IMG_0596.JPG' ALT='IMG_0596.JPG'>IMG_0596.JPG</a></div></td>
<td><A ID='IMG_0601.JPG' href='lasersocialising.php?fileId=IMG_0601.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20081118/IMG_0601.JPG' ALT='IMG_0601.JPG'><BR>IMG_0601.JPG<br>55.9 KB</a><div class='inv'><br><a href='./images/20081118/IMG_0601.JPG' ALT='IMG_0601.JPG'>IMG_0601.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_0602.JPG' href='lasersocialising.php?fileId=IMG_0602.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20081118/IMG_0602.JPG' ALT='IMG_0602.JPG'><BR>IMG_0602.JPG<br>52.83 KB</a><div class='inv'><br><a href='./images/20081118/IMG_0602.JPG' ALT='IMG_0602.JPG'>IMG_0602.JPG</a></div></td>
</tr>
</table>	</div>
</div>
</body>
</html>