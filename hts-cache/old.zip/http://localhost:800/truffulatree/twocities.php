<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - 19/12/2005 - Two Cities</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="Two Cities">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="Greetings from a Bum" href='greetingsfromabum.php'>29/4/2005</a></li>
<li><a title="Onward" href='onward.php'>2/5/2005</a></li>
<li><a title="It's a tough life (pt 1: Bundaberg, Agnes Water and 1770)" href='itsatoughlife1.php'>17/5/2005</a></li>
<li><a title="It's a tough life (pt 2: Rockhampton, Emu Park and Great Keppel Island)" href='itsatoughlife2.php'>23/5/2005</a></li>
<li><a title="There and Back Again - a Yo-yo's Tale" href='thereandbackagain.php'>18/6/2005</a></li>
<li><a title="Platypi and Grey Nomads" href='platypiandgreynomads.php'>24/6/2005</a></li>
<li><a title="Blowing Bubbles in a Watery Tomb" href='blowingbubbles.php'>1/7/2005</a></li>
<li><a title="Pieces of History" href='piecesofhistory.php'>8/7/2005</a></li>
<li><a title="Walks and Waterfalls" href='walksandwaterfalls.php'>15/7/2005</a></li>
<li><a title="Mission to Tribulation" href='missiontotribulation.php'>22/7/2005</a></li>
<li><a title="Levity, Limestone and Lava" href='levitylimestoneandlava.php'>29/7/2005</a></li>
<li><a title="Into the Never Never" href='intothenevernever.php'>5/8/2005</a></li>
<li><a title="Slowing the pace in Darwin" href='slowingthepaceindarwin.php'>12/8/2005</a></li>
<li><a title="Blistering Barnacles and Leaping Lizards" href='leapinglizards.php'>19/8/2005</a></li>
<li><a title="Kakadu and Litchfield" href='kakadu.php'>26/8/2005</a></li>
<li><a title="Legacies of War" href='legaciesofwar.php'>2/9/2005</a></li>
<li><a title="Go West" href='gowest.php'>10/9/2005</a></li>
<li><a title="Things from Above" href='thingsfromabove.php'>16/9/2005</a></li>
<li><a title="The West Coast" href='thewestcoast.php'>23/9/2005</a></li>
<li><a title="Reefs and Red Dust" href='reefsandreddust.php'>30/9/2005</a></li>
<li><a title="The Pilbara" href='pilbara.php'>7/10/2005</a></li>
<li><a title="Paradise with a Headwind" href='paradisewithaheadwind.php'>14/10/2005</a></li>
<li><a title="Down the Coral Coast" href='downthecoralcoast.php'>21/10/2005</a></li>
<li><a title="Pinnacles and Pinnipeds" href='pinnaclesandpinnipeds.php'>28/10/2005</a></li>
<li><a title="A week in Perth" href='perth.php'>4/11/2005</a></li>
<li><a title="The Southwest (from Above and Below)" href='thesouthwest.php'>11/11/2005</a></li>
<li><a title="More Heights and Depths" href='moreheightsanddepths.php'>18/11/2005</a></li>
<li><a title="Across the Nullarbor (and a bit beyond)" href='nullarbor.php'>25/11/2005</a></li>
<li><a title="Double Whammy" href='doublewhammy.php'>9/12/2005</a></li>
<li><div class='activemenu'>19/12/2005</div></li>
<li><a title="Tassie - Part 1" href='tassie1.php'>1/1/2006</a></li>
<li><a title="Tassie - Part 2" href='tassie2.php'>7/1/2006</a></li>
<li><a title="Full Circle" href='fullcircle.php'>26/1/2006</a></li>
<li><a title="The Wrap Up" href='thewrapup.php'>23/3/2006</a></li>
<li> </li><br><li>Or go back to:</li><li><a title='Travelouges and blogs from my trip around Australia' href="nerdseyeview.php">Nerd's Eye View</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>19/12/2005</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Travel stories and pictures' href="travel.php">Travelogues</a> > <a title='Travelouges and blogs from my trip around Australia' href="nerdseyeview.php">Nerd's Eye View</a> > <a title='Two Cities' href="twocities.php">19/12/2005</a>
<br><br>		


<h1>Two Cities</h1>

<a href="images/maps/Map051219.gif"><img src="images/maps/Map051219_sm.gif" align="right"></a>

<p>Hi everyone. Here's yet another sporadic update; it seems the silly season is in full swing, so my timing may as well be off. :)</p>

<p>Today we arrived in Tasmania, having spent the last week and a bit in and around Melbourne. I've also had my quick weekend trip to Brisbane, just to add some extra kilometres to the story.</p>

<p>In fact, picking up from last time, the Brisvegas trip is the first thing that happened. Those of you who know me well will know that I've been doing <a href="http://www.pitkd.com" target="_blank">Taekwondo</a> for a few years now, and I flew up to watch an ex-student of mine, Vince, go for his 1st Dan.</p>

<p>The 1st Dan grading is held over two weeks, with part one testing all the techniques, patterns and knowledge. Part two involves breaking techniques and lots of controlled free sparring, and it was this part that I came up to see.</p>

<p>Vince of course passed well, which I knew he would. :) I played paparazzi, and my mate Rhys lent me his superb 70-200 F2.8 L series lens (for the non camera nerds out there - think of a large, white, heavy, unsubtle bastard of a lens), so I got some nice close ups and action shots.</p>

<p>Whilst in Brissie I stayed at Alison and Ben's place, and got to mind Ferris the cat. Cheers for the free accommodation guys! Lindsay and partner Ally also came to visit on the Friday. As you can see from the sheen on everyone in the photos, it was a typical sticky evening. I also did a breeze-in-breeze-out at Nick and Lola's place (my long suffering ex-employers), and the other <a href="http://www.digicon.com.au?nerd=mark" target="_blank">ex-</a><a href="http://www.digicon.com.au?nerd=nathan" target="_blank">Digicon</a> <a href="http://www.digicon.com.au?nerd=john" target="_blank">folks</a> on the list may be amused to hear that I saw Gerald there.</p>

<p>(Gerald is the lovely old fellow who did most of the office renovations over the years, and hence was probably responsible for more sales of headphones than any number of hi-fi shop attendants over a similar period of time).</p>

<p>Anyway, all up, visiting 'vegas was a strange - if brief - experience, not least because of the sudden climatic buffeting. It started me realising that the Nerd's Eye adventure is entering it's twilight hours. God forbid, but I may have to get some sort of real(ish) job in a mere matter of weeks (unless my website ad clicks increase by about a thousandfold, in which case I will become a dot-com baron). :)</p>

<p>Last Monday I flew back to Melbourne, and spent most of the week at Michael's (a.k.a. Shams') place. Dave was also visiting from Sydney, so it was a good little reunion. Jana alternated between there and her sister Hildy's, where we both stayed on Friday night.</p>

<p>Cheers to both for the free stays. It's nice to have good company and free broadband, and both <a href="http://www.magdalena.com.au" target="_blank">Hildy</a> and <a href="http://www.nocturnal-central.com" target="_blank">Shams</a> run their own businesses, so it's fantastic for them to take the time.</p>

<p>Two other Melbourne highlights were a visit to the Museum, of which the usual photos abound (most recommended - they have a great number of excellent displays there, which we unfortunately arrived too late to visit properly), and of my purchase of a replacement bike.</p>

<p>The bike cost a few pennies more than my old one, but I figured it was a good opportunity to upgrade, and hey, it's xmas. The new one is very shiny and has disc brakes, which means that it can pitch you over the handlebars with much less effort than it takes on those other models. :)</p>

<p>On Saturday night, we went on a trip out to the Dandenong Ranges, for dinner with Penelope and Jack, who had often stayed with us up in Brissie (<a href="http://www.penelopeswales.com" target="_blank">Penelope is a muso</a> and travels quite a bit).</p>

<p>Their setting in the hills was quite lovely, with surrounds of forest patches and fields with those funny round hay bales. Apparently the day before we arrived it had rained, and several of the new bales had rolled and crashed their way down the hill, much to the farmer's dismay. One managed to lodge itself in their garden - thankfully it stopped before demolishing a wall; they're pretty big things!</p>

<p>From there, we headed back to Melbourne, and stopped along the way at the William Ricketts sanctuary, a slice of forest populated with sculptures. The grey and damp day seemed quite appropriate when surrounded by tree ferns and bush spirits.</p>

<p>Once back in the city, we went on one final wander around the CBD for some socialising and photography, and then we headed to the port and boarded the overnight ferry for Devonport in Tasmania.</p>

<p>The ship is pretty massive (it has various bars, restaurants and a foul room full of pokies in addition to the accommodation). It ploughs along through Bass Strait at nearly 50kms an hour (whatever that is in knots). Despite it's massiveness, the trip was quite rough at times. Thankfully, unlike a number of others we saw, neither of us were overly bothered in the "turning green" sense.</p>

<p>That brings us up to date again. From Devonport we'll plan our time on Tassie. I can see lots of lovely forest walks in our future. From there we'll catch the ferry directly back to Sydney sometime in January.</p>

<p>So - as I probably won't write again for a few weeks, enjoy the holidays, overeating and so on that is the done thing at this time of year. Do try not to buy too much crap that you don't need. If you're travelling, travel safely, and perhaps I'll see you in 2006!</p>

<p>The latest selection of snaps:</p>

<table width="800">
	<tr>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=IMG_4318.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4318.JPG' ALT='Vince bruises some boards'><BR>Vince bruises some boards</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=IMG_4480.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4480.JPG' ALT='Dead but still beautiful'><BR>Dead but still beautiful</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=IMG_4524.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4524.JPG' ALT="Penelope's back yard"><BR>Penelope's back yard</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=IMG_4550.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4550.JPG' ALT="One of William Ricketts' old men of the forest"><BR>One of William Ricketts' old men of the forest</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=IMG_4574.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4574.JPG' ALT='Melbourne CBD and the Yarra River'><BR>Melbourne CBD and the Yarra River</a>
	</td>
	</tr>
</table>

<br><br>
All images in this gallery:<br>
<table width='800'>
<tr>
</tr>
<tr><td><A ID='IMG_4158.JPG' href='twocities.php?fileId=IMG_4158.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4158.JPG' ALT='IMG_4158.JPG'><BR>IMG_4158.JPG<br>48.04 KB</a><div class='inv'><br><a href='./images/20051219/IMG_4158.JPG' ALT='IMG_4158.JPG'>IMG_4158.JPG</a></div></td>
<td><A ID='IMG_4159.JPG' href='twocities.php?fileId=IMG_4159.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4159.JPG' ALT='IMG_4159.JPG'><BR>IMG_4159.JPG<br>44.36 KB</a><div class='inv'><br><a href='./images/20051219/IMG_4159.JPG' ALT='IMG_4159.JPG'>IMG_4159.JPG</a></div></td>
<td><A ID='IMG_4164.JPG' href='twocities.php?fileId=IMG_4164.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4164.JPG' ALT='IMG_4164.JPG'><BR>IMG_4164.JPG<br>47.27 KB</a><div class='inv'><br><a href='./images/20051219/IMG_4164.JPG' ALT='IMG_4164.JPG'>IMG_4164.JPG</a></div></td>
<td><A ID='IMG_4165.JPG' href='twocities.php?fileId=IMG_4165.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4165.JPG' ALT='IMG_4165.JPG'><BR>IMG_4165.JPG<br>49.41 KB</a><div class='inv'><br><a href='./images/20051219/IMG_4165.JPG' ALT='IMG_4165.JPG'>IMG_4165.JPG</a></div></td>
<td><A ID='IMG_4169.JPG' href='twocities.php?fileId=IMG_4169.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4169.JPG' ALT='IMG_4169.JPG'><BR>IMG_4169.JPG<br>52.14 KB</a><div class='inv'><br><a href='./images/20051219/IMG_4169.JPG' ALT='IMG_4169.JPG'>IMG_4169.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_4173.JPG' href='twocities.php?fileId=IMG_4173.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4173.JPG' ALT='IMG_4173.JPG'><BR>IMG_4173.JPG<br>47.19 KB</a><div class='inv'><br><a href='./images/20051219/IMG_4173.JPG' ALT='IMG_4173.JPG'>IMG_4173.JPG</a></div></td>
<td><A ID='IMG_4178.JPG' href='twocities.php?fileId=IMG_4178.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4178.JPG' ALT='IMG_4178.JPG'><BR>IMG_4178.JPG<br>50.34 KB</a><div class='inv'><br><a href='./images/20051219/IMG_4178.JPG' ALT='IMG_4178.JPG'>IMG_4178.JPG</a></div></td>
<td><A ID='IMG_4202.JPG' href='twocities.php?fileId=IMG_4202.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4202.JPG' ALT='IMG_4202.JPG'><BR>IMG_4202.JPG<br>65.97 KB</a><div class='inv'><br><a href='./images/20051219/IMG_4202.JPG' ALT='IMG_4202.JPG'>IMG_4202.JPG</a></div></td>
<td><A ID='IMG_4203.JPG' href='twocities.php?fileId=IMG_4203.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4203.JPG' ALT='IMG_4203.JPG'><BR>IMG_4203.JPG<br>62.02 KB</a><div class='inv'><br><a href='./images/20051219/IMG_4203.JPG' ALT='IMG_4203.JPG'>IMG_4203.JPG</a></div></td>
<td><A ID='IMG_4211.JPG' href='twocities.php?fileId=IMG_4211.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4211.JPG' ALT='IMG_4211.JPG'><BR>IMG_4211.JPG<br>56.19 KB</a><div class='inv'><br><a href='./images/20051219/IMG_4211.JPG' ALT='IMG_4211.JPG'>IMG_4211.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_4222.JPG' href='twocities.php?fileId=IMG_4222.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4222.JPG' ALT='IMG_4222.JPG'><BR>IMG_4222.JPG<br>53.39 KB</a><div class='inv'><br><a href='./images/20051219/IMG_4222.JPG' ALT='IMG_4222.JPG'>IMG_4222.JPG</a></div></td>
<td><A ID='IMG_4226.JPG' href='twocities.php?fileId=IMG_4226.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4226.JPG' ALT='IMG_4226.JPG'><BR>IMG_4226.JPG<br>76.81 KB</a><div class='inv'><br><a href='./images/20051219/IMG_4226.JPG' ALT='IMG_4226.JPG'>IMG_4226.JPG</a></div></td>
<td><A ID='IMG_4228.JPG' href='twocities.php?fileId=IMG_4228.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4228.JPG' ALT='IMG_4228.JPG'><BR>IMG_4228.JPG<br>80.41 KB</a><div class='inv'><br><a href='./images/20051219/IMG_4228.JPG' ALT='IMG_4228.JPG'>IMG_4228.JPG</a></div></td>
<td><A ID='IMG_4231.JPG' href='twocities.php?fileId=IMG_4231.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4231.JPG' ALT='IMG_4231.JPG'><BR>IMG_4231.JPG<br>77.73 KB</a><div class='inv'><br><a href='./images/20051219/IMG_4231.JPG' ALT='IMG_4231.JPG'>IMG_4231.JPG</a></div></td>
<td><A ID='IMG_4232.JPG' href='twocities.php?fileId=IMG_4232.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4232.JPG' ALT='IMG_4232.JPG'><BR>IMG_4232.JPG<br>66.05 KB</a><div class='inv'><br><a href='./images/20051219/IMG_4232.JPG' ALT='IMG_4232.JPG'>IMG_4232.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_4233.JPG' href='twocities.php?fileId=IMG_4233.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4233.JPG' ALT='IMG_4233.JPG'><BR>IMG_4233.JPG<br>87.38 KB</a><div class='inv'><br><a href='./images/20051219/IMG_4233.JPG' ALT='IMG_4233.JPG'>IMG_4233.JPG</a></div></td>
<td><A ID='IMG_4235.JPG' href='twocities.php?fileId=IMG_4235.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4235.JPG' ALT='IMG_4235.JPG'><BR>IMG_4235.JPG<br>79.83 KB</a><div class='inv'><br><a href='./images/20051219/IMG_4235.JPG' ALT='IMG_4235.JPG'>IMG_4235.JPG</a></div></td>
<td><A ID='IMG_4238.JPG' href='twocities.php?fileId=IMG_4238.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4238.JPG' ALT='IMG_4238.JPG'><BR>IMG_4238.JPG<br>59.17 KB</a><div class='inv'><br><a href='./images/20051219/IMG_4238.JPG' ALT='IMG_4238.JPG'>IMG_4238.JPG</a></div></td>
<td><A ID='IMG_4261.JPG' href='twocities.php?fileId=IMG_4261.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4261.JPG' ALT='IMG_4261.JPG'><BR>IMG_4261.JPG<br>58.26 KB</a><div class='inv'><br><a href='./images/20051219/IMG_4261.JPG' ALT='IMG_4261.JPG'>IMG_4261.JPG</a></div></td>
<td><A ID='IMG_4285.JPG' href='twocities.php?fileId=IMG_4285.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4285.JPG' ALT='IMG_4285.JPG'><BR>IMG_4285.JPG<br>59.6 KB</a><div class='inv'><br><a href='./images/20051219/IMG_4285.JPG' ALT='IMG_4285.JPG'>IMG_4285.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_4292.JPG' href='twocities.php?fileId=IMG_4292.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4292.JPG' ALT='IMG_4292.JPG'><BR>IMG_4292.JPG<br>57.09 KB</a><div class='inv'><br><a href='./images/20051219/IMG_4292.JPG' ALT='IMG_4292.JPG'>IMG_4292.JPG</a></div></td>
<td><A ID='IMG_4318.JPG' href='twocities.php?fileId=IMG_4318.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4318.JPG' ALT='IMG_4318.JPG'><BR>IMG_4318.JPG<br>55.26 KB</a><div class='inv'><br><a href='./images/20051219/IMG_4318.JPG' ALT='IMG_4318.JPG'>IMG_4318.JPG</a></div></td>
<td><A ID='IMG_4330.JPG' href='twocities.php?fileId=IMG_4330.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4330.JPG' ALT='IMG_4330.JPG'><BR>IMG_4330.JPG<br>50.89 KB</a><div class='inv'><br><a href='./images/20051219/IMG_4330.JPG' ALT='IMG_4330.JPG'>IMG_4330.JPG</a></div></td>
<td><A ID='IMG_4334.JPG' href='twocities.php?fileId=IMG_4334.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4334.JPG' ALT='IMG_4334.JPG'><BR>IMG_4334.JPG<br>55.11 KB</a><div class='inv'><br><a href='./images/20051219/IMG_4334.JPG' ALT='IMG_4334.JPG'>IMG_4334.JPG</a></div></td>
<td><A ID='IMG_4338.JPG' href='twocities.php?fileId=IMG_4338.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4338.JPG' ALT='IMG_4338.JPG'><BR>IMG_4338.JPG<br>51.81 KB</a><div class='inv'><br><a href='./images/20051219/IMG_4338.JPG' ALT='IMG_4338.JPG'>IMG_4338.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_4341.JPG' href='twocities.php?fileId=IMG_4341.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4341.JPG' ALT='IMG_4341.JPG'><BR>IMG_4341.JPG<br>79.28 KB</a><div class='inv'><br><a href='./images/20051219/IMG_4341.JPG' ALT='IMG_4341.JPG'>IMG_4341.JPG</a></div></td>
<td><A ID='IMG_4342.JPG' href='twocities.php?fileId=IMG_4342.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4342.JPG' ALT='IMG_4342.JPG'><BR>IMG_4342.JPG<br>56.77 KB</a><div class='inv'><br><a href='./images/20051219/IMG_4342.JPG' ALT='IMG_4342.JPG'>IMG_4342.JPG</a></div></td>
<td><A ID='IMG_4344.JPG' href='twocities.php?fileId=IMG_4344.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4344.JPG' ALT='IMG_4344.JPG'><BR>IMG_4344.JPG<br>50.43 KB</a><div class='inv'><br><a href='./images/20051219/IMG_4344.JPG' ALT='IMG_4344.JPG'>IMG_4344.JPG</a></div></td>
<td><A ID='IMG_4352.JPG' href='twocities.php?fileId=IMG_4352.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4352.JPG' ALT='IMG_4352.JPG'><BR>IMG_4352.JPG<br>64.36 KB</a><div class='inv'><br><a href='./images/20051219/IMG_4352.JPG' ALT='IMG_4352.JPG'>IMG_4352.JPG</a></div></td>
<td><A ID='IMG_4353.JPG' href='twocities.php?fileId=IMG_4353.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4353.JPG' ALT='IMG_4353.JPG'><BR>IMG_4353.JPG<br>86.97 KB</a><div class='inv'><br><a href='./images/20051219/IMG_4353.JPG' ALT='IMG_4353.JPG'>IMG_4353.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_4356.JPG' href='twocities.php?fileId=IMG_4356.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4356.JPG' ALT='IMG_4356.JPG'><BR>IMG_4356.JPG<br>57.22 KB</a><div class='inv'><br><a href='./images/20051219/IMG_4356.JPG' ALT='IMG_4356.JPG'>IMG_4356.JPG</a></div></td>
<td><A ID='IMG_4359.JPG' href='twocities.php?fileId=IMG_4359.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4359.JPG' ALT='IMG_4359.JPG'><BR>IMG_4359.JPG<br>75.77 KB</a><div class='inv'><br><a href='./images/20051219/IMG_4359.JPG' ALT='IMG_4359.JPG'>IMG_4359.JPG</a></div></td>
<td><A ID='IMG_4365.JPG' href='twocities.php?fileId=IMG_4365.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4365.JPG' ALT='IMG_4365.JPG'><BR>IMG_4365.JPG<br>59.31 KB</a><div class='inv'><br><a href='./images/20051219/IMG_4365.JPG' ALT='IMG_4365.JPG'>IMG_4365.JPG</a></div></td>
<td><A ID='IMG_4371.JPG' href='twocities.php?fileId=IMG_4371.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4371.JPG' ALT='IMG_4371.JPG'><BR>IMG_4371.JPG<br>63.5 KB</a><div class='inv'><br><a href='./images/20051219/IMG_4371.JPG' ALT='IMG_4371.JPG'>IMG_4371.JPG</a></div></td>
<td><A ID='IMG_4373.JPG' href='twocities.php?fileId=IMG_4373.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4373.JPG' ALT='IMG_4373.JPG'><BR>IMG_4373.JPG<br>57.98 KB</a><div class='inv'><br><a href='./images/20051219/IMG_4373.JPG' ALT='IMG_4373.JPG'>IMG_4373.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_4375.JPG' href='twocities.php?fileId=IMG_4375.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4375.JPG' ALT='IMG_4375.JPG'><BR>IMG_4375.JPG<br>61.88 KB</a><div class='inv'><br><a href='./images/20051219/IMG_4375.JPG' ALT='IMG_4375.JPG'>IMG_4375.JPG</a></div></td>
<td><A ID='IMG_4376.JPG' href='twocities.php?fileId=IMG_4376.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4376.JPG' ALT='IMG_4376.JPG'><BR>IMG_4376.JPG<br>73.08 KB</a><div class='inv'><br><a href='./images/20051219/IMG_4376.JPG' ALT='IMG_4376.JPG'>IMG_4376.JPG</a></div></td>
<td><A ID='IMG_4377.JPG' href='twocities.php?fileId=IMG_4377.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4377.JPG' ALT='IMG_4377.JPG'><BR>IMG_4377.JPG<br>50.17 KB</a><div class='inv'><br><a href='./images/20051219/IMG_4377.JPG' ALT='IMG_4377.JPG'>IMG_4377.JPG</a></div></td>
<td><A ID='IMG_4388.JPG' href='twocities.php?fileId=IMG_4388.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4388.JPG' ALT='IMG_4388.JPG'><BR>IMG_4388.JPG<br>65 KB</a><div class='inv'><br><a href='./images/20051219/IMG_4388.JPG' ALT='IMG_4388.JPG'>IMG_4388.JPG</a></div></td>
<td><A ID='IMG_4389.JPG' href='twocities.php?fileId=IMG_4389.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4389.JPG' ALT='IMG_4389.JPG'><BR>IMG_4389.JPG<br>61.45 KB</a><div class='inv'><br><a href='./images/20051219/IMG_4389.JPG' ALT='IMG_4389.JPG'>IMG_4389.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_4397.JPG' href='twocities.php?fileId=IMG_4397.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4397.JPG' ALT='IMG_4397.JPG'><BR>IMG_4397.JPG<br>61.78 KB</a><div class='inv'><br><a href='./images/20051219/IMG_4397.JPG' ALT='IMG_4397.JPG'>IMG_4397.JPG</a></div></td>
<td><A ID='IMG_4430.JPG' href='twocities.php?fileId=IMG_4430.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4430.JPG' ALT='IMG_4430.JPG'><BR>IMG_4430.JPG<br>80.87 KB</a><div class='inv'><br><a href='./images/20051219/IMG_4430.JPG' ALT='IMG_4430.JPG'>IMG_4430.JPG</a></div></td>
<td><A ID='IMG_4436.JPG' href='twocities.php?fileId=IMG_4436.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4436.JPG' ALT='IMG_4436.JPG'><BR>IMG_4436.JPG<br>63.21 KB</a><div class='inv'><br><a href='./images/20051219/IMG_4436.JPG' ALT='IMG_4436.JPG'>IMG_4436.JPG</a></div></td>
<td><A ID='IMG_4437.JPG' href='twocities.php?fileId=IMG_4437.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4437.JPG' ALT='IMG_4437.JPG'><BR>IMG_4437.JPG<br>60.26 KB</a><div class='inv'><br><a href='./images/20051219/IMG_4437.JPG' ALT='IMG_4437.JPG'>IMG_4437.JPG</a></div></td>
<td><A ID='IMG_4446.JPG' href='twocities.php?fileId=IMG_4446.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4446.JPG' ALT='IMG_4446.JPG'><BR>IMG_4446.JPG<br>48.82 KB</a><div class='inv'><br><a href='./images/20051219/IMG_4446.JPG' ALT='IMG_4446.JPG'>IMG_4446.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_4451.JPG' href='twocities.php?fileId=IMG_4451.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4451.JPG' ALT='IMG_4451.JPG'><BR>IMG_4451.JPG<br>88.11 KB</a><div class='inv'><br><a href='./images/20051219/IMG_4451.JPG' ALT='IMG_4451.JPG'>IMG_4451.JPG</a></div></td>
<td><A ID='IMG_4455.JPG' href='twocities.php?fileId=IMG_4455.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4455.JPG' ALT='IMG_4455.JPG'><BR>IMG_4455.JPG<br>72.87 KB</a><div class='inv'><br><a href='./images/20051219/IMG_4455.JPG' ALT='IMG_4455.JPG'>IMG_4455.JPG</a></div></td>
<td><A ID='IMG_4457.JPG' href='twocities.php?fileId=IMG_4457.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4457.JPG' ALT='IMG_4457.JPG'><BR>IMG_4457.JPG<br>57.57 KB</a><div class='inv'><br><a href='./images/20051219/IMG_4457.JPG' ALT='IMG_4457.JPG'>IMG_4457.JPG</a></div></td>
<td><A ID='IMG_4460.JPG' href='twocities.php?fileId=IMG_4460.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4460.JPG' ALT='IMG_4460.JPG'><BR>IMG_4460.JPG<br>82.17 KB</a><div class='inv'><br><a href='./images/20051219/IMG_4460.JPG' ALT='IMG_4460.JPG'>IMG_4460.JPG</a></div></td>
<td><A ID='IMG_4463.JPG' href='twocities.php?fileId=IMG_4463.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4463.JPG' ALT='IMG_4463.JPG'><BR>IMG_4463.JPG<br>88.82 KB</a><div class='inv'><br><a href='./images/20051219/IMG_4463.JPG' ALT='IMG_4463.JPG'>IMG_4463.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_4466.JPG' href='twocities.php?fileId=IMG_4466.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4466.JPG' ALT='IMG_4466.JPG'><BR>IMG_4466.JPG<br>36.16 KB</a><div class='inv'><br><a href='./images/20051219/IMG_4466.JPG' ALT='IMG_4466.JPG'>IMG_4466.JPG</a></div></td>
<td><A ID='IMG_4468.JPG' href='twocities.php?fileId=IMG_4468.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4468.JPG' ALT='IMG_4468.JPG'><BR>IMG_4468.JPG<br>39.07 KB</a><div class='inv'><br><a href='./images/20051219/IMG_4468.JPG' ALT='IMG_4468.JPG'>IMG_4468.JPG</a></div></td>
<td><A ID='IMG_4469.JPG' href='twocities.php?fileId=IMG_4469.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4469.JPG' ALT='IMG_4469.JPG'><BR>IMG_4469.JPG<br>62.12 KB</a><div class='inv'><br><a href='./images/20051219/IMG_4469.JPG' ALT='IMG_4469.JPG'>IMG_4469.JPG</a></div></td>
<td><A ID='IMG_4470.JPG' href='twocities.php?fileId=IMG_4470.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4470.JPG' ALT='IMG_4470.JPG'><BR>IMG_4470.JPG<br>36.71 KB</a><div class='inv'><br><a href='./images/20051219/IMG_4470.JPG' ALT='IMG_4470.JPG'>IMG_4470.JPG</a></div></td>
<td><A ID='IMG_4471.JPG' href='twocities.php?fileId=IMG_4471.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4471.JPG' ALT='IMG_4471.JPG'><BR>IMG_4471.JPG<br>32.31 KB</a><div class='inv'><br><a href='./images/20051219/IMG_4471.JPG' ALT='IMG_4471.JPG'>IMG_4471.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_4474.JPG' href='twocities.php?fileId=IMG_4474.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4474.JPG' ALT='IMG_4474.JPG'><BR>IMG_4474.JPG<br>58.76 KB</a><div class='inv'><br><a href='./images/20051219/IMG_4474.JPG' ALT='IMG_4474.JPG'>IMG_4474.JPG</a></div></td>
<td><A ID='IMG_4476.JPG' href='twocities.php?fileId=IMG_4476.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4476.JPG' ALT='IMG_4476.JPG'><BR>IMG_4476.JPG<br>53.31 KB</a><div class='inv'><br><a href='./images/20051219/IMG_4476.JPG' ALT='IMG_4476.JPG'>IMG_4476.JPG</a></div></td>
<td><A ID='IMG_4477.JPG' href='twocities.php?fileId=IMG_4477.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4477.JPG' ALT='IMG_4477.JPG'><BR>IMG_4477.JPG<br>65.72 KB</a><div class='inv'><br><a href='./images/20051219/IMG_4477.JPG' ALT='IMG_4477.JPG'>IMG_4477.JPG</a></div></td>
<td><A ID='IMG_4480.JPG' href='twocities.php?fileId=IMG_4480.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4480.JPG' ALT='IMG_4480.JPG'><BR>IMG_4480.JPG<br>66.28 KB</a><div class='inv'><br><a href='./images/20051219/IMG_4480.JPG' ALT='IMG_4480.JPG'>IMG_4480.JPG</a></div></td>
<td><A ID='IMG_4482.JPG' href='twocities.php?fileId=IMG_4482.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4482.JPG' ALT='IMG_4482.JPG'><BR>IMG_4482.JPG<br>110.88 KB</a><div class='inv'><br><a href='./images/20051219/IMG_4482.JPG' ALT='IMG_4482.JPG'>IMG_4482.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_4483.JPG' href='twocities.php?fileId=IMG_4483.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4483.JPG' ALT='IMG_4483.JPG'><BR>IMG_4483.JPG<br>79.07 KB</a><div class='inv'><br><a href='./images/20051219/IMG_4483.JPG' ALT='IMG_4483.JPG'>IMG_4483.JPG</a></div></td>
<td><A ID='IMG_4485.JPG' href='twocities.php?fileId=IMG_4485.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4485.JPG' ALT='IMG_4485.JPG'><BR>IMG_4485.JPG<br>101.75 KB</a><div class='inv'><br><a href='./images/20051219/IMG_4485.JPG' ALT='IMG_4485.JPG'>IMG_4485.JPG</a></div></td>
<td><A ID='IMG_4486.JPG' href='twocities.php?fileId=IMG_4486.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4486.JPG' ALT='IMG_4486.JPG'><BR>IMG_4486.JPG<br>92.82 KB</a><div class='inv'><br><a href='./images/20051219/IMG_4486.JPG' ALT='IMG_4486.JPG'>IMG_4486.JPG</a></div></td>
<td><A ID='IMG_4487.JPG' href='twocities.php?fileId=IMG_4487.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4487.JPG' ALT='IMG_4487.JPG'><BR>IMG_4487.JPG<br>81.95 KB</a><div class='inv'><br><a href='./images/20051219/IMG_4487.JPG' ALT='IMG_4487.JPG'>IMG_4487.JPG</a></div></td>
<td><A ID='IMG_4488.JPG' href='twocities.php?fileId=IMG_4488.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4488.JPG' ALT='IMG_4488.JPG'><BR>IMG_4488.JPG<br>76.22 KB</a><div class='inv'><br><a href='./images/20051219/IMG_4488.JPG' ALT='IMG_4488.JPG'>IMG_4488.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_4491.JPG' href='twocities.php?fileId=IMG_4491.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4491.JPG' ALT='IMG_4491.JPG'><BR>IMG_4491.JPG<br>44.2 KB</a><div class='inv'><br><a href='./images/20051219/IMG_4491.JPG' ALT='IMG_4491.JPG'>IMG_4491.JPG</a></div></td>
<td><A ID='IMG_4492.JPG' href='twocities.php?fileId=IMG_4492.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4492.JPG' ALT='IMG_4492.JPG'><BR>IMG_4492.JPG<br>59.37 KB</a><div class='inv'><br><a href='./images/20051219/IMG_4492.JPG' ALT='IMG_4492.JPG'>IMG_4492.JPG</a></div></td>
<td><A ID='IMG_4494.JPG' href='twocities.php?fileId=IMG_4494.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4494.JPG' ALT='IMG_4494.JPG'><BR>IMG_4494.JPG<br>40.98 KB</a><div class='inv'><br><a href='./images/20051219/IMG_4494.JPG' ALT='IMG_4494.JPG'>IMG_4494.JPG</a></div></td>
<td><A ID='IMG_4496.JPG' href='twocities.php?fileId=IMG_4496.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4496.JPG' ALT='IMG_4496.JPG'><BR>IMG_4496.JPG<br>90.99 KB</a><div class='inv'><br><a href='./images/20051219/IMG_4496.JPG' ALT='IMG_4496.JPG'>IMG_4496.JPG</a></div></td>
<td><A ID='IMG_4497.JPG' href='twocities.php?fileId=IMG_4497.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4497.JPG' ALT='IMG_4497.JPG'><BR>IMG_4497.JPG<br>105.2 KB</a><div class='inv'><br><a href='./images/20051219/IMG_4497.JPG' ALT='IMG_4497.JPG'>IMG_4497.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_4499.JPG' href='twocities.php?fileId=IMG_4499.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4499.JPG' ALT='IMG_4499.JPG'><BR>IMG_4499.JPG<br>101.76 KB</a><div class='inv'><br><a href='./images/20051219/IMG_4499.JPG' ALT='IMG_4499.JPG'>IMG_4499.JPG</a></div></td>
<td><A ID='IMG_4501.JPG' href='twocities.php?fileId=IMG_4501.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4501.JPG' ALT='IMG_4501.JPG'><BR>IMG_4501.JPG<br>109.39 KB</a><div class='inv'><br><a href='./images/20051219/IMG_4501.JPG' ALT='IMG_4501.JPG'>IMG_4501.JPG</a></div></td>
<td><A ID='IMG_4502.JPG' href='twocities.php?fileId=IMG_4502.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4502.JPG' ALT='IMG_4502.JPG'><BR>IMG_4502.JPG<br>92.79 KB</a><div class='inv'><br><a href='./images/20051219/IMG_4502.JPG' ALT='IMG_4502.JPG'>IMG_4502.JPG</a></div></td>
<td><A ID='IMG_4509.JPG' href='twocities.php?fileId=IMG_4509.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4509.JPG' ALT='IMG_4509.JPG'><BR>IMG_4509.JPG<br>64.95 KB</a><div class='inv'><br><a href='./images/20051219/IMG_4509.JPG' ALT='IMG_4509.JPG'>IMG_4509.JPG</a></div></td>
<td><A ID='IMG_4515.JPG' href='twocities.php?fileId=IMG_4515.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4515.JPG' ALT='IMG_4515.JPG'><BR>IMG_4515.JPG<br>79.65 KB</a><div class='inv'><br><a href='./images/20051219/IMG_4515.JPG' ALT='IMG_4515.JPG'>IMG_4515.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_4516.JPG' href='twocities.php?fileId=IMG_4516.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4516.JPG' ALT='IMG_4516.JPG'><BR>IMG_4516.JPG<br>66.05 KB</a><div class='inv'><br><a href='./images/20051219/IMG_4516.JPG' ALT='IMG_4516.JPG'>IMG_4516.JPG</a></div></td>
<td><A ID='IMG_4519.JPG' href='twocities.php?fileId=IMG_4519.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4519.JPG' ALT='IMG_4519.JPG'><BR>IMG_4519.JPG<br>65.53 KB</a><div class='inv'><br><a href='./images/20051219/IMG_4519.JPG' ALT='IMG_4519.JPG'>IMG_4519.JPG</a></div></td>
<td><A ID='IMG_4521.JPG' href='twocities.php?fileId=IMG_4521.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4521.JPG' ALT='IMG_4521.JPG'><BR>IMG_4521.JPG<br>56.69 KB</a><div class='inv'><br><a href='./images/20051219/IMG_4521.JPG' ALT='IMG_4521.JPG'>IMG_4521.JPG</a></div></td>
<td><A ID='IMG_4522.JPG' href='twocities.php?fileId=IMG_4522.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4522.JPG' ALT='IMG_4522.JPG'><BR>IMG_4522.JPG<br>94.08 KB</a><div class='inv'><br><a href='./images/20051219/IMG_4522.JPG' ALT='IMG_4522.JPG'>IMG_4522.JPG</a></div></td>
<td><A ID='IMG_4524.JPG' href='twocities.php?fileId=IMG_4524.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4524.JPG' ALT='IMG_4524.JPG'><BR>IMG_4524.JPG<br>61.38 KB</a><div class='inv'><br><a href='./images/20051219/IMG_4524.JPG' ALT='IMG_4524.JPG'>IMG_4524.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_4529.JPG' href='twocities.php?fileId=IMG_4529.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4529.JPG' ALT='IMG_4529.JPG'><BR>IMG_4529.JPG<br>51.49 KB</a><div class='inv'><br><a href='./images/20051219/IMG_4529.JPG' ALT='IMG_4529.JPG'>IMG_4529.JPG</a></div></td>
<td><A ID='IMG_4533.JPG' href='twocities.php?fileId=IMG_4533.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4533.JPG' ALT='IMG_4533.JPG'><BR>IMG_4533.JPG<br>46.01 KB</a><div class='inv'><br><a href='./images/20051219/IMG_4533.JPG' ALT='IMG_4533.JPG'>IMG_4533.JPG</a></div></td>
<td><A ID='IMG_4537.JPG' href='twocities.php?fileId=IMG_4537.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4537.JPG' ALT='IMG_4537.JPG'><BR>IMG_4537.JPG<br>42.36 KB</a><div class='inv'><br><a href='./images/20051219/IMG_4537.JPG' ALT='IMG_4537.JPG'>IMG_4537.JPG</a></div></td>
<td><A ID='IMG_4539.JPG' href='twocities.php?fileId=IMG_4539.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4539.JPG' ALT='IMG_4539.JPG'><BR>IMG_4539.JPG<br>37.88 KB</a><div class='inv'><br><a href='./images/20051219/IMG_4539.JPG' ALT='IMG_4539.JPG'>IMG_4539.JPG</a></div></td>
<td><A ID='IMG_4543.JPG' href='twocities.php?fileId=IMG_4543.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4543.JPG' ALT='IMG_4543.JPG'><BR>IMG_4543.JPG<br>31.59 KB</a><div class='inv'><br><a href='./images/20051219/IMG_4543.JPG' ALT='IMG_4543.JPG'>IMG_4543.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_4544.JPG' href='twocities.php?fileId=IMG_4544.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4544.JPG' ALT='IMG_4544.JPG'><BR>IMG_4544.JPG<br>85.29 KB</a><div class='inv'><br><a href='./images/20051219/IMG_4544.JPG' ALT='IMG_4544.JPG'>IMG_4544.JPG</a></div></td>
<td><A ID='IMG_4549.JPG' href='twocities.php?fileId=IMG_4549.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4549.JPG' ALT='IMG_4549.JPG'><BR>IMG_4549.JPG<br>88.25 KB</a><div class='inv'><br><a href='./images/20051219/IMG_4549.JPG' ALT='IMG_4549.JPG'>IMG_4549.JPG</a></div></td>
<td><A ID='IMG_4550.JPG' href='twocities.php?fileId=IMG_4550.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4550.JPG' ALT='IMG_4550.JPG'><BR>IMG_4550.JPG<br>74.93 KB</a><div class='inv'><br><a href='./images/20051219/IMG_4550.JPG' ALT='IMG_4550.JPG'>IMG_4550.JPG</a></div></td>
<td><A ID='IMG_4552.JPG' href='twocities.php?fileId=IMG_4552.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4552.JPG' ALT='IMG_4552.JPG'><BR>IMG_4552.JPG<br>103.92 KB</a><div class='inv'><br><a href='./images/20051219/IMG_4552.JPG' ALT='IMG_4552.JPG'>IMG_4552.JPG</a></div></td>
<td><A ID='IMG_4554.JPG' href='twocities.php?fileId=IMG_4554.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4554.JPG' ALT='IMG_4554.JPG'><BR>IMG_4554.JPG<br>116.74 KB</a><div class='inv'><br><a href='./images/20051219/IMG_4554.JPG' ALT='IMG_4554.JPG'>IMG_4554.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_4556.JPG' href='twocities.php?fileId=IMG_4556.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4556.JPG' ALT='IMG_4556.JPG'><BR>IMG_4556.JPG<br>85.92 KB</a><div class='inv'><br><a href='./images/20051219/IMG_4556.JPG' ALT='IMG_4556.JPG'>IMG_4556.JPG</a></div></td>
<td><A ID='IMG_4557.JPG' href='twocities.php?fileId=IMG_4557.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4557.JPG' ALT='IMG_4557.JPG'><BR>IMG_4557.JPG<br>102.07 KB</a><div class='inv'><br><a href='./images/20051219/IMG_4557.JPG' ALT='IMG_4557.JPG'>IMG_4557.JPG</a></div></td>
<td><A ID='IMG_4561.JPG' href='twocities.php?fileId=IMG_4561.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4561.JPG' ALT='IMG_4561.JPG'><BR>IMG_4561.JPG<br>75.55 KB</a><div class='inv'><br><a href='./images/20051219/IMG_4561.JPG' ALT='IMG_4561.JPG'>IMG_4561.JPG</a></div></td>
<td><A ID='IMG_4563.JPG' href='twocities.php?fileId=IMG_4563.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4563.JPG' ALT='IMG_4563.JPG'><BR>IMG_4563.JPG<br>41.54 KB</a><div class='inv'><br><a href='./images/20051219/IMG_4563.JPG' ALT='IMG_4563.JPG'>IMG_4563.JPG</a></div></td>
<td><A ID='IMG_4565.JPG' href='twocities.php?fileId=IMG_4565.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4565.JPG' ALT='IMG_4565.JPG'><BR>IMG_4565.JPG<br>35.88 KB</a><div class='inv'><br><a href='./images/20051219/IMG_4565.JPG' ALT='IMG_4565.JPG'>IMG_4565.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_4566.JPG' href='twocities.php?fileId=IMG_4566.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4566.JPG' ALT='IMG_4566.JPG'><BR>IMG_4566.JPG<br>48.8 KB</a><div class='inv'><br><a href='./images/20051219/IMG_4566.JPG' ALT='IMG_4566.JPG'>IMG_4566.JPG</a></div></td>
<td><A ID='IMG_4567.JPG' href='twocities.php?fileId=IMG_4567.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4567.JPG' ALT='IMG_4567.JPG'><BR>IMG_4567.JPG<br>82 KB</a><div class='inv'><br><a href='./images/20051219/IMG_4567.JPG' ALT='IMG_4567.JPG'>IMG_4567.JPG</a></div></td>
<td><A ID='IMG_4569.JPG' href='twocities.php?fileId=IMG_4569.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4569.JPG' ALT='IMG_4569.JPG'><BR>IMG_4569.JPG<br>86.29 KB</a><div class='inv'><br><a href='./images/20051219/IMG_4569.JPG' ALT='IMG_4569.JPG'>IMG_4569.JPG</a></div></td>
<td><A ID='IMG_4571.JPG' href='twocities.php?fileId=IMG_4571.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4571.JPG' ALT='IMG_4571.JPG'><BR>IMG_4571.JPG<br>72.99 KB</a><div class='inv'><br><a href='./images/20051219/IMG_4571.JPG' ALT='IMG_4571.JPG'>IMG_4571.JPG</a></div></td>
<td><A ID='IMG_4572.JPG' href='twocities.php?fileId=IMG_4572.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4572.JPG' ALT='IMG_4572.JPG'><BR>IMG_4572.JPG<br>67.85 KB</a><div class='inv'><br><a href='./images/20051219/IMG_4572.JPG' ALT='IMG_4572.JPG'>IMG_4572.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_4574.JPG' href='twocities.php?fileId=IMG_4574.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4574.JPG' ALT='IMG_4574.JPG'><BR>IMG_4574.JPG<br>75.25 KB</a><div class='inv'><br><a href='./images/20051219/IMG_4574.JPG' ALT='IMG_4574.JPG'>IMG_4574.JPG</a></div></td>
<td><A ID='IMG_4576.JPG' href='twocities.php?fileId=IMG_4576.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4576.JPG' ALT='IMG_4576.JPG'><BR>IMG_4576.JPG<br>76.51 KB</a><div class='inv'><br><a href='./images/20051219/IMG_4576.JPG' ALT='IMG_4576.JPG'>IMG_4576.JPG</a></div></td>
<td><A ID='IMG_4577.JPG' href='twocities.php?fileId=IMG_4577.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4577.JPG' ALT='IMG_4577.JPG'><BR>IMG_4577.JPG<br>44.57 KB</a><div class='inv'><br><a href='./images/20051219/IMG_4577.JPG' ALT='IMG_4577.JPG'>IMG_4577.JPG</a></div></td>
<td><A ID='IMG_4581.JPG' href='twocities.php?fileId=IMG_4581.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4581.JPG' ALT='IMG_4581.JPG'><BR>IMG_4581.JPG<br>57.11 KB</a><div class='inv'><br><a href='./images/20051219/IMG_4581.JPG' ALT='IMG_4581.JPG'>IMG_4581.JPG</a></div></td>
<td><A ID='IMG_4583.JPG' href='twocities.php?fileId=IMG_4583.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4583.JPG' ALT='IMG_4583.JPG'><BR>IMG_4583.JPG<br>52.78 KB</a><div class='inv'><br><a href='./images/20051219/IMG_4583.JPG' ALT='IMG_4583.JPG'>IMG_4583.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_4584.JPG' href='twocities.php?fileId=IMG_4584.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4584.JPG' ALT='IMG_4584.JPG'><BR>IMG_4584.JPG<br>66.19 KB</a><div class='inv'><br><a href='./images/20051219/IMG_4584.JPG' ALT='IMG_4584.JPG'>IMG_4584.JPG</a></div></td>
<td><A ID='IMG_4585.JPG' href='twocities.php?fileId=IMG_4585.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4585.JPG' ALT='IMG_4585.JPG'><BR>IMG_4585.JPG<br>54.53 KB</a><div class='inv'><br><a href='./images/20051219/IMG_4585.JPG' ALT='IMG_4585.JPG'>IMG_4585.JPG</a></div></td>
<td><A ID='IMG_4586.JPG' href='twocities.php?fileId=IMG_4586.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051219/IMG_4586.JPG' ALT='IMG_4586.JPG'><BR>IMG_4586.JPG<br>48.03 KB</a><div class='inv'><br><a href='./images/20051219/IMG_4586.JPG' ALT='IMG_4586.JPG'>IMG_4586.JPG</a></div></td>
<td><A ID='Rhys_IMG_3389.JPG' href='twocities.php?fileId=Rhys_IMG_3389.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051219/Rhys_IMG_3389.JPG' ALT='Rhys_IMG_3389.JPG'><BR>Rhys_IMG_3389.JPG<br>58.77 KB</a><div class='inv'><br><a href='./images/20051219/Rhys_IMG_3389.JPG' ALT='Rhys_IMG_3389.JPG'>Rhys_IMG_3389.JPG</a></div></td>
<td><A ID='Rhys_IMG_3392.JPG' href='twocities.php?fileId=Rhys_IMG_3392.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051219/Rhys_IMG_3392.JPG' ALT='Rhys_IMG_3392.JPG'><BR>Rhys_IMG_3392.JPG<br>52.09 KB</a><div class='inv'><br><a href='./images/20051219/Rhys_IMG_3392.JPG' ALT='Rhys_IMG_3392.JPG'>Rhys_IMG_3392.JPG</a></div></td>
</tr>
<tr><td><A ID='Rhys_IMG_3403.JPG' href='twocities.php?fileId=Rhys_IMG_3403.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051219/Rhys_IMG_3403.JPG' ALT='Rhys_IMG_3403.JPG'><BR>Rhys_IMG_3403.JPG<br>44.9 KB</a><div class='inv'><br><a href='./images/20051219/Rhys_IMG_3403.JPG' ALT='Rhys_IMG_3403.JPG'>Rhys_IMG_3403.JPG</a></div></td>
<td><A ID='Rhys_IMG_3406.JPG' href='twocities.php?fileId=Rhys_IMG_3406.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051219/Rhys_IMG_3406.JPG' ALT='Rhys_IMG_3406.JPG'><BR>Rhys_IMG_3406.JPG<br>62.97 KB</a><div class='inv'><br><a href='./images/20051219/Rhys_IMG_3406.JPG' ALT='Rhys_IMG_3406.JPG'>Rhys_IMG_3406.JPG</a></div></td>
</tr>
</table>	</div>
</div>
</body>
</html>