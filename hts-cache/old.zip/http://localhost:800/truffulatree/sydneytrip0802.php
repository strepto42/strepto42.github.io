<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - Sydney & Yacaaba Head - Image gallery</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="Image gallery">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="Pictures of my 28th Birthday party complete with Sparkler Bomb" href='28th.php'>28th Birthday</a></li>
<li><a title="Pictures of my 30th Birthday party" href='30th.php'>30th Birthday</a></li>
<li><a title="Michael Shamgar and Lindsay Halamek's 30th birthday bash photos" href='sl30th.php'>Shams & Linds' 30th</a></li>
<li><a title="Pictures of Andy Marinos's new flat, cat Toby, and Mum Pam Swain" href='andycatandflat.php'>Andy's Cat & Flat</a></li>
<li><a title="Pictures of a visit to Stephen Jackson's Farm" href='jackovisit.php'>Jacko's Farm</a></li>
<li><a title="Pictures taken at the Peace Convergence action in Rockhampton and Yeppoon in June 2005 to protest the joint US Australia military exercises (Operation Talisman Sabre)" href='peaceconvergence.php'>Peace Convergence</a></li>
<li><a title="Sydney trip - April '06" href='bridges.php'>Sydney, April 06</a></li>
<li><a title="Pics of Naima's 28th birthday dinner" href='mim28th.php'>Naima's 28th</a></li>
<li><a title="Brisbane CBD and the Story Bridge" href='brisbanepics1.php'>Brissie by Night 1</a></li>
<li><a title="Lamington National Park" href='lamington.php'>Lamington NP</a></li>
<li><a title="Various creatures and views from our Brisbane back yard" href='backyard.php'>Backyard Creatures</a></li>
<li><a title="Opening day of the Eleanor Schonell (Green) Bridge" href='greenbridge.php'>Green Bridge</a></li>
<li><a title="Pictutres from the 2006 Woodford Folk Festival" href='woodford0607.php'>Woodford 2006-2007</a></li>
<li><a title="One Cute Puppy" href='jezebel.php'>Jezebel</a></li>
<li><a title="Climbing at Kangaroo Point Cliffs" href='kangaroopt1.php'>Heather's Visit</a></li>
<li><a title="0x0021st (33rd) birthday celebrations" href='0x0021st.php'>0x0021st Birthday</a></li>
<li><a title="Nuptial photography" href='guyandalison.php'>Guy and Alison's Wedding</a></li>
<li><a title="Pictures from the 2007 Woodford Folk Festival" href='woodford0708.php'>Woodford 2007-2008</a></li>
<li><div class='activemenu'>Sydney & Yacaaba Head</div></li>
<li><a title="An impressive show by nature" href='lightning.php'>Thunderstorm Moonrise</a></li>
<li><a title="Frightening pictures of a shrinking beard" href='debearding.php'>De-bearding</a></li>
<li><a title="More Nuptial Photography" href='michaelandkaren.php'>Michael and Karen's Wedding</a></li>
<li><a title="A night of celebration" href='andrews21st.php'>Andrew's 21st</a></li>
<li><a title="Image Gallery" href='bloodyknee.php'>Bloody Knee</a></li>
<li><a title="Image Gallery" href='tyesbirthday.php'>Tye's Birthday</a></li>
<li><a title="Image Gallery" href='lasersocialising.php'>Laser Socialising</a></li>
<li><a title="Image Gallery" href='heatherandevan.php'>Heather and Evan's Wedding</a></li>
<li><a title="Image Gallery" href='woodford0809.php'>Woodford 2008-2009</a></li>
<li><a title="Image Gallery" href='allyandben.php'>Ally and Ben's Wedding</a></li>
<li><a title="Image Gallery" href='annes30th.php'>Anne's 30th</a></li>
<li><a title="Image Gallery" href='possumcreek.php'>Possum Creek</a></li>
<li><a title="Image Gallery" href='jamnight.php'>Jam Night</a></li>
<li><a title="Image Gallery" href='cunninghamsgap.php'>Cunningham's Gap</a></li>
<li><a title="Image Gallery" href='bigcat.php'>Diving on Big Cat</a></li>
<li><a title="Images from my birthday jam" href='birthdayjam.php'>Music, mayhem and merriment</a></li>
<li><a title="Image Gallery" href='fuzzypolaroidpics.php'>Fuzzy Polaroid</a></li>
<li><a title="Image Gallery" href='zombiewalk2009.php'>2009 Zombie Walk</a></li>
<li> </li><br><li>Or go back to:</li><li><a title='Picture galleries' href="pictures.php">Photography</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>Sydney & Yacaaba Head</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Picture galleries' href="pictures.php">Photography</a> > <a title='Image gallery' href="sydneytrip0802.php">Sydney & Yacaaba Head</a>
<br><br>		

<p>I took a little trip down to Sydney in early February. There were various things to attend to: work, which I shan't go on about here (but which did essentially pay for the trip), my Dad's 70th, and a couple of concerts.</p>

<p>Said concerts bracketed the trip; on the first night after arriving I took in the simple pleasures of Rage Against the Machine with Andy (thanks for the ticket!), and the final night in town I spent re-living my youth and savouring the awesomeness that is Iron Maiden.</p>

<p>I was cameraless at both those events though, so tough.</p>

<p>In between I spent quite a lot of time catching up (ie, boozing on) with friends and family (and our good mate the <a href="?fileId=IMG_2200.JPG">Single Malt</a> made an appearance for Dad's birthday).</p>

<p>In particular I had a most pleasant jam with Guy (and his <a href="?fileId=IMG_2281.JPG">ridiculous drumkit</a>) and Lindsay (thanks to Kath and her ill-fated Golf for the amp!). Kath, Cameron and I also caught up with Alan (who's house I finally got to see).</p>

<p>I also finally got to see Wade's place, and keep his neighbours awake with my extra-loud singing as we jammed the night away.</p>

<p>On another occasion I spent a very relaxing evening wandering around Circular Quay and the Rocks with my Swiss friend Anna (whom I had met in <a href="thingsfromabove.php">Kununurra</a>, several years and another world ago). It was a picture perfect evening, and we took the ferry back home, but neither of us had our camera. Oh well. :)</p>

<p>Other visits included an evening with Yvonne (and her new beau), and one with Jack, Ally and Tim (who's new semi-bald nut made for some <a href="?fileId=IMG_2302.JPG">nice portraiture</a>), and a trip up to Katoomba to see Daniel, Anne and Meredith. I'd planned some nice bush walks while up there but the weather put a stop to that. We did get to see <a href="?fileId=IMG_2397.JPG">the Cascades in full flow</a> though which was nice.</p>

<p>The weather seemed to conspire against me quite a lot actually, but I did get one good walk in - while staying with Dave and Katy at their new place in Buladelah. We took a trip out to <a href="http://maps.google.com.au/maps?f=q&hl=en&geocode=&q=tea+gardens&ie=UTF8&ll=-32.685764,152.181931&spn=0.118328,0.215607&t=h&z=13" target="_blank">Hawk's Nest/Tea Gardens</a> and had a great time taking in the beach and walking up to the top of <a href="?fileId=IMG_2796.JPG">Yacaaba Head</a>.</p>

<p>The weather was very kind to us that day; it barely rained at all, but the clouds made for some great <a href="?fileId=IMG_2716.JPG">dramatic</a> <a href="?fileId=IMG_2724.JPG">landscapes</a>. It turned out that we had made the right decision to go walking there too, as back in Buladelah it apparently rained so hard the place nearly floated away. So yay.</p>

<p>My last taste of nature was on the way back, when I stopped overnight at Minnie Water (a lovely place). Once again it rained so I didn't go for a bush walk, but I did get some great shots of a very purty and obliging <a href="?fileId=IMG_2867.JPG" title="Emu">Emu</a> on the way out.</p>

<p>Anyway, enjoy the pictures!</p>
<br><br>
All images in this gallery:<br>
<table width='800'>
<tr>
</tr>
<tr><td><A ID='IMG_2076.JPG' href='sydneytrip0802.php?fileId=IMG_2076.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2076.JPG' ALT='One fat caterpillar'><BR>One fat caterpillar<br>44.68 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2076.JPG' ALT='One fat caterpillar'>One fat caterpillar</a></div></td>
<td><A ID='IMG_2103.JPG' href='sydneytrip0802.php?fileId=IMG_2103.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2103.JPG' ALT='One fat caterpillar'><BR>One fat caterpillar<br>48.26 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2103.JPG' ALT='One fat caterpillar'>One fat caterpillar</a></div></td>
<td><A ID='IMG_2155.JPG' href='sydneytrip0802.php?fileId=IMG_2155.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2155.JPG' ALT='One fat caterpillar'><BR>One fat caterpillar<br>77.58 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2155.JPG' ALT='One fat caterpillar'>One fat caterpillar</a></div></td>
<td><A ID='IMG_2176.JPG' href='sydneytrip0802.php?fileId=IMG_2176.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2176.JPG' ALT='Andy & Kylie'><BR>Andy & Kylie<br>48.6 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2176.JPG' ALT='Andy & Kylie'>Andy & Kylie</a></div></td>
<td><A ID='IMG_2180.JPG' href='sydneytrip0802.php?fileId=IMG_2180.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2180.JPG' ALT='Andy'><BR>Andy<br>49.89 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2180.JPG' ALT='Andy'>Andy</a></div></td>
</tr>
<tr><td><A ID='IMG_2182.JPG' href='sydneytrip0802.php?fileId=IMG_2182.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2182.JPG' ALT='Heather & Ev'><BR>Heather & Ev<br>65.72 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2182.JPG' ALT='Heather & Ev'>Heather & Ev</a></div></td>
<td><A ID='IMG_2184.JPG' href='sydneytrip0802.php?fileId=IMG_2184.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2184.JPG' ALT='Dad with the single malt'><BR>Dad with the single malt<br>66.21 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2184.JPG' ALT='Dad with the single malt'>Dad with the single malt</a></div></td>
<td><A ID='IMG_2199.JPG' href='sydneytrip0802.php?fileId=IMG_2199.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2199.JPG' ALT='Mum & I'><BR>Mum & I<br>62.02 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2199.JPG' ALT='Mum & I'>Mum & I</a></div></td>
<td><A ID='IMG_2200.JPG' href='sydneytrip0802.php?fileId=IMG_2200.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2200.JPG' ALT='Happiness is a single malt'><BR>Happiness is a single malt<br>61.44 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2200.JPG' ALT='Happiness is a single malt'>Happiness is a single malt</a></div></td>
<td><A ID='IMG_2211.JPG' href='sydneytrip0802.php?fileId=IMG_2211.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2211.JPG' ALT='Ev'><BR>Ev<br>47.97 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2211.JPG' ALT='Ev'>Ev</a></div></td>
</tr>
<tr><td><A ID='IMG_2225.JPG' href='sydneytrip0802.php?fileId=IMG_2225.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2225.JPG' ALT='IMG_2225.JPG'><BR>IMG_2225.JPG<br>60.23 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2225.JPG' ALT='IMG_2225.JPG'>IMG_2225.JPG</a></div></td>
<td><A ID='IMG_2227.JPG' href='sydneytrip0802.php?fileId=IMG_2227.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2227.JPG' ALT='Keeping a close eye on it'><BR>Keeping a close eye on it<br>56.73 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2227.JPG' ALT='Keeping a close eye on it'>Keeping a close eye on it</a></div></td>
<td><A ID='IMG_2230.JPG' href='sydneytrip0802.php?fileId=IMG_2230.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2230.JPG' ALT='No comment'><BR>No comment<br>59.93 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2230.JPG' ALT='No comment'>No comment</a></div></td>
<td><A ID='IMG_2232.JPG' href='sydneytrip0802.php?fileId=IMG_2232.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2232.JPG' ALT='Heather being cute'><BR>Heather being cute<br>60.32 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2232.JPG' ALT='Heather being cute'>Heather being cute</a></div></td>
<td><A ID='IMG_2233.JPG' href='sydneytrip0802.php?fileId=IMG_2233.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2233.JPG' ALT='Heather being cute'><BR>Heather being cute<br>47.15 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2233.JPG' ALT='Heather being cute'>Heather being cute</a></div></td>
</tr>
<tr><td><A ID='IMG_2243.JPG' href='sydneytrip0802.php?fileId=IMG_2243.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2243.JPG' ALT='IMG_2243.JPG'><BR>IMG_2243.JPG<br>50.09 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2243.JPG' ALT='IMG_2243.JPG'>IMG_2243.JPG</a></div></td>
<td><A ID='IMG_2246.JPG' href='sydneytrip0802.php?fileId=IMG_2246.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2246.JPG' ALT='Awww'><BR>Awww<br>70.95 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2246.JPG' ALT='Awww'>Awww</a></div></td>
<td><A ID='IMG_2249.JPG' href='sydneytrip0802.php?fileId=IMG_2249.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2249.JPG' ALT='Puppies!'><BR>Puppies!<br>60.75 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2249.JPG' ALT='Puppies!'>Puppies!</a></div></td>
<td><A ID='IMG_2258.JPG' href='sydneytrip0802.php?fileId=IMG_2258.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2258.JPG' ALT='Alan'><BR>Alan<br>50.21 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2258.JPG' ALT='Alan'>Alan</a></div></td>
<td><A ID='IMG_2267.JPG' href='sydneytrip0802.php?fileId=IMG_2267.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2267.JPG' ALT='IMG_2267.JPG'><BR>IMG_2267.JPG<br>49.32 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2267.JPG' ALT='IMG_2267.JPG'>IMG_2267.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_2273.JPG' href='sydneytrip0802.php?fileId=IMG_2273.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2273.JPG' ALT='Setting up the monster kit'><BR>Setting up the monster kit<br>70.01 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2273.JPG' ALT='Setting up the monster kit'>Setting up the monster kit</a></div></td>
<td><A ID='IMG_2276.JPG' href='sydneytrip0802.php?fileId=IMG_2276.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2276.JPG' ALT='Guy and his baker's dozen cymbals'><BR>Guy and his baker's dozen cymbals<br>77.76 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2276.JPG' ALT='Guy and his baker's dozen cymbals'>Guy and his baker's dozen cymbals</a></div></td>
<td><A ID='IMG_2279.JPG' href='sydneytrip0802.php?fileId=IMG_2279.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2279.JPG' ALT='Linds rocks out conservatively'><BR>Linds rocks out conservatively<br>56.01 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2279.JPG' ALT='Linds rocks out conservatively'>Linds rocks out conservatively</a></div></td>
<td><A ID='IMG_2281.JPG' href='sydneytrip0802.php?fileId=IMG_2281.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2281.JPG' ALT='I got blisters on my fingers!'><BR>I got blisters on my fingers!<br>68.59 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2281.JPG' ALT='I got blisters on my fingers!'>I got blisters on my fingers!</a></div></td>
<td><A ID='IMG_2286.JPG' href='sydneytrip0802.php?fileId=IMG_2286.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2286.JPG' ALT='Guy and Linds packing up'><BR>Guy and Linds packing up<br>80.02 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2286.JPG' ALT='Guy and Linds packing up'>Guy and Linds packing up</a></div></td>
</tr>
<tr><td><A ID='IMG_2293.JPG' href='sydneytrip0802.php?fileId=IMG_2293.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2293.JPG' ALT='Tim and Jack'><BR>Tim and Jack<br>76.55 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2293.JPG' ALT='Tim and Jack'>Tim and Jack</a></div></td>
<td><A ID='IMG_2295.JPG' href='sydneytrip0802.php?fileId=IMG_2295.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2295.JPG' ALT='Ally, Tim and Jack'><BR>Ally, Tim and Jack<br>78.22 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2295.JPG' ALT='Ally, Tim and Jack'>Ally, Tim and Jack</a></div></td>
<td><A ID='IMG_2297.JPG' href='sydneytrip0802.php?fileId=IMG_2297.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2297.JPG' ALT='Jack and Ally'><BR>Jack and Ally<br>56.95 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2297.JPG' ALT='Jack and Ally'>Jack and Ally</a></div></td>
<td><A ID='IMG_2299.JPG' href='sydneytrip0802.php?fileId=IMG_2299.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2299.JPG' ALT='Jack and Ally'><BR>Jack and Ally<br>61.58 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2299.JPG' ALT='Jack and Ally'>Jack and Ally</a></div></td>
<td><A ID='IMG_2302.JPG' href='sydneytrip0802.php?fileId=IMG_2302.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2302.JPG' ALT='Tim'><BR>Tim<br>37.06 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2302.JPG' ALT='Tim'>Tim</a></div></td>
</tr>
<tr><td><A ID='IMG_2304.JPG' href='sydneytrip0802.php?fileId=IMG_2304.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2304.JPG' ALT='Ally'><BR>Ally<br>36.69 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2304.JPG' ALT='Ally'>Ally</a></div></td>
<td><A ID='IMG_2306.JPG' href='sydneytrip0802.php?fileId=IMG_2306.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2306.JPG' ALT='Jack'><BR>Jack<br>40.58 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2306.JPG' ALT='Jack'>Jack</a></div></td>
<td><A ID='IMG_2309.JPG' href='sydneytrip0802.php?fileId=IMG_2309.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2309.JPG' ALT='Jack'><BR>Jack<br>43.01 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2309.JPG' ALT='Jack'>Jack</a></div></td>
<td><A ID='IMG_2313.JPG' href='sydneytrip0802.php?fileId=IMG_2313.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2313.JPG' ALT='Tim'><BR>Tim<br>38.92 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2313.JPG' ALT='Tim'>Tim</a></div></td>
<td><A ID='IMG_2315.JPG' href='sydneytrip0802.php?fileId=IMG_2315.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2315.JPG' ALT='Tim'><BR>Tim<br>38.75 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2315.JPG' ALT='Tim'>Tim</a></div></td>
</tr>
<tr><td><A ID='IMG_2316.JPG' href='sydneytrip0802.php?fileId=IMG_2316.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2316.JPG' ALT='Jack ponders'><BR>Jack ponders<br>47.7 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2316.JPG' ALT='Jack ponders'>Jack ponders</a></div></td>
<td><A ID='IMG_2327.JPG' href='sydneytrip0802.php?fileId=IMG_2327.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2327.JPG' ALT='Tim ponders'><BR>Tim ponders<br>43.2 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2327.JPG' ALT='Tim ponders'>Tim ponders</a></div></td>
<td><A ID='IMG_2335.JPG' href='sydneytrip0802.php?fileId=IMG_2335.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2335.JPG' ALT='I ponder'><BR>I ponder<br>34.44 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2335.JPG' ALT='I ponder'>I ponder</a></div></td>
<td><A ID='IMG_2374.JPG' href='sydneytrip0802.php?fileId=IMG_2374.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2374.JPG' ALT='Cats and lasers'><BR>Cats and lasers<br>61.03 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2374.JPG' ALT='Cats and lasers'>Cats and lasers</a></div></td>
<td><A ID='IMG_2379.JPG' href='sydneytrip0802.php?fileId=IMG_2379.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2379.JPG' ALT='Cats and lasers'><BR>Cats and lasers<br>75 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2379.JPG' ALT='Cats and lasers'>Cats and lasers</a></div></td>
</tr>
<tr><td><A ID='IMG_2388.JPG' href='sydneytrip0802.php?fileId=IMG_2388.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2388.JPG' ALT='Cats and lasers'><BR>Cats and lasers<br>69.78 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2388.JPG' ALT='Cats and lasers'>Cats and lasers</a></div></td>
<td><A ID='IMG_2390.JPG' href='sydneytrip0802.php?fileId=IMG_2390.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2390.JPG' ALT='IMG_2390.JPG'><BR>IMG_2390.JPG<br>65.61 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2390.JPG' ALT='IMG_2390.JPG'>IMG_2390.JPG</a></div></td>
<td><A ID='IMG_2392.JPG' href='sydneytrip0802.php?fileId=IMG_2392.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2392.JPG' ALT='Echo point & the three sisters, as seen by many tourists'><BR>Echo point & the three sisters, as seen by many tourists<br>52.89 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2392.JPG' ALT='Echo point & the three sisters, as seen by many tourists'>Echo point & the three sisters, as seen by many tourists</a></div></td>
<td><A ID='IMG_2397.JPG' href='sydneytrip0802.php?fileId=IMG_2397.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2397.JPG' ALT='The Cascades cascading'><BR>The Cascades cascading<br>88.47 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2397.JPG' ALT='The Cascades cascading'>The Cascades cascading</a></div></td>
<td><A ID='IMG_2405.JPG' href='sydneytrip0802.php?fileId=IMG_2405.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2405.JPG' ALT='The Cascades cascading'><BR>The Cascades cascading<br>54.81 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2405.JPG' ALT='The Cascades cascading'>The Cascades cascading</a></div></td>
</tr>
<tr><td><A ID='IMG_2408.JPG' href='sydneytrip0802.php?fileId=IMG_2408.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2408.JPG' ALT='IMG_2408.JPG'><BR>IMG_2408.JPG<br>63.73 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2408.JPG' ALT='IMG_2408.JPG'>IMG_2408.JPG</a></div></td>
<td><A ID='IMG_2416.JPG' href='sydneytrip0802.php?fileId=IMG_2416.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2416.JPG' ALT='Katoomba tourist irony'><BR>Katoomba tourist irony<br>37.05 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2416.JPG' ALT='Katoomba tourist irony'>Katoomba tourist irony</a></div></td>
<td><A ID='IMG_2553.JPG' href='sydneytrip0802.php?fileId=IMG_2553.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2553.JPG' ALT='Wade'><BR>Wade<br>51.1 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2553.JPG' ALT='Wade'>Wade</a></div></td>
<td><A ID='IMG_2555.JPG' href='sydneytrip0802.php?fileId=IMG_2555.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2555.JPG' ALT='Wade'><BR>Wade<br>49.07 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2555.JPG' ALT='Wade'>Wade</a></div></td>
<td><A ID='IMG_2580.JPG' href='sydneytrip0802.php?fileId=IMG_2580.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2580.JPG' ALT='IMG_2580.JPG'><BR>IMG_2580.JPG<br>65.1 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2580.JPG' ALT='IMG_2580.JPG'>IMG_2580.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_2588.JPG' href='sydneytrip0802.php?fileId=IMG_2588.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2588.JPG' ALT='Magpie with lunch'><BR>Magpie with lunch<br>70.2 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2588.JPG' ALT='Magpie with lunch'>Magpie with lunch</a></div></td>
<td><A ID='IMG_2590.JPG' href='sydneytrip0802.php?fileId=IMG_2590.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2590.JPG' ALT='A parked Plover'><BR>A parked Plover<br>57.95 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2590.JPG' ALT='A parked Plover'>A parked Plover</a></div></td>
<td><A ID='IMG_2592.JPG' href='sydneytrip0802.php?fileId=IMG_2592.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2592.JPG' ALT='Water Dragon'><BR>Water Dragon<br>69.73 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2592.JPG' ALT='Water Dragon'>Water Dragon</a></div></td>
<td><A ID='IMG_2594.JPG' href='sydneytrip0802.php?fileId=IMG_2594.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2594.JPG' ALT='Australian Pelicans'><BR>Australian Pelicans<br>87.18 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2594.JPG' ALT='Australian Pelicans'>Australian Pelicans</a></div></td>
<td><A ID='IMG_2598.JPG' href='sydneytrip0802.php?fileId=IMG_2598.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2598.JPG' ALT='Australian Pelican'><BR>Australian Pelican<br>69.9 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2598.JPG' ALT='Australian Pelican'>Australian Pelican</a></div></td>
</tr>
<tr><td><A ID='IMG_2603.JPG' href='sydneytrip0802.php?fileId=IMG_2603.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2603.JPG' ALT='Welcome Swallows'><BR>Welcome Swallows<br>42.86 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2603.JPG' ALT='Welcome Swallows'>Welcome Swallows</a></div></td>
<td><A ID='IMG_2619.JPG' href='sydneytrip0802.php?fileId=IMG_2619.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2619.JPG' ALT='Welcome Swallow'><BR>Welcome Swallow<br>33.59 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2619.JPG' ALT='Welcome Swallow'>Welcome Swallow</a></div></td>
<td><A ID='IMG_2622.JPG' href='sydneytrip0802.php?fileId=IMG_2622.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2622.JPG' ALT='White Breasted Sea Eagle'><BR>White Breasted Sea Eagle<br>24.65 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2622.JPG' ALT='White Breasted Sea Eagle'>White Breasted Sea Eagle</a></div></td>
<td><A ID='IMG_2631.JPG' href='sydneytrip0802.php?fileId=IMG_2631.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2631.JPG' ALT='IMG_2631.JPG'><BR>IMG_2631.JPG<br>41.29 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2631.JPG' ALT='IMG_2631.JPG'>IMG_2631.JPG</a></div></td>
<td><A ID='IMG_2635.JPG' href='sydneytrip0802.php?fileId=IMG_2635.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2635.JPG' ALT='IMG_2635.JPG'><BR>IMG_2635.JPG<br>122.4 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2635.JPG' ALT='IMG_2635.JPG'>IMG_2635.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_2636.JPG' href='sydneytrip0802.php?fileId=IMG_2636.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2636.JPG' ALT='IMG_2636.JPG'><BR>IMG_2636.JPG<br>96.34 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2636.JPG' ALT='IMG_2636.JPG'>IMG_2636.JPG</a></div></td>
<td><A ID='IMG_2638.JPG' href='sydneytrip0802.php?fileId=IMG_2638.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2638.JPG' ALT='IMG_2638.JPG'><BR>IMG_2638.JPG<br>75.61 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2638.JPG' ALT='IMG_2638.JPG'>IMG_2638.JPG</a></div></td>
<td><A ID='IMG_2641.JPG' href='sydneytrip0802.php?fileId=IMG_2641.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2641.JPG' ALT='IMG_2641.JPG'><BR>IMG_2641.JPG<br>51.42 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2641.JPG' ALT='IMG_2641.JPG'>IMG_2641.JPG</a></div></td>
<td><A ID='IMG_2642.JPG' href='sydneytrip0802.php?fileId=IMG_2642.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2642.JPG' ALT='IMG_2642.JPG'><BR>IMG_2642.JPG<br>57.22 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2642.JPG' ALT='IMG_2642.JPG'>IMG_2642.JPG</a></div></td>
<td><A ID='IMG_2646.JPG' href='sydneytrip0802.php?fileId=IMG_2646.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2646.JPG' ALT='IMG_2646.JPG'><BR>IMG_2646.JPG<br>68.72 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2646.JPG' ALT='IMG_2646.JPG'>IMG_2646.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_2648.JPG' href='sydneytrip0802.php?fileId=IMG_2648.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2648.JPG' ALT='IMG_2648.JPG'><BR>IMG_2648.JPG<br>45.72 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2648.JPG' ALT='IMG_2648.JPG'>IMG_2648.JPG</a></div></td>
<td><A ID='IMG_2651.JPG' href='sydneytrip0802.php?fileId=IMG_2651.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2651.JPG' ALT='IMG_2651.JPG'><BR>IMG_2651.JPG<br>62.9 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2651.JPG' ALT='IMG_2651.JPG'>IMG_2651.JPG</a></div></td>
<td><A ID='IMG_2652.JPG' href='sydneytrip0802.php?fileId=IMG_2652.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2652.JPG' ALT='IMG_2652.JPG'><BR>IMG_2652.JPG<br>63.04 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2652.JPG' ALT='IMG_2652.JPG'>IMG_2652.JPG</a></div></td>
<td><A ID='IMG_2665.JPG' href='sydneytrip0802.php?fileId=IMG_2665.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2665.JPG' ALT='Male Coel'><BR>Male Coel<br>103.39 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2665.JPG' ALT='Male Coel'>Male Coel</a></div></td>
<td><A ID='IMG_2668.JPG' href='sydneytrip0802.php?fileId=IMG_2668.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2668.JPG' ALT='Katy and the boys'><BR>Katy and the boys<br>80.09 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2668.JPG' ALT='Katy and the boys'>Katy and the boys</a></div></td>
</tr>
<tr><td><A ID='IMG_2672.JPG' href='sydneytrip0802.php?fileId=IMG_2672.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2672.JPG' ALT='Dave and Katy's place'><BR>Dave and Katy's place<br>69.04 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2672.JPG' ALT='Dave and Katy's place'>Dave and Katy's place</a></div></td>
<td><A ID='IMG_2677.JPG' href='sydneytrip0802.php?fileId=IMG_2677.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2677.JPG' ALT='Dave feeling mellow'><BR>Dave feeling mellow<br>42.82 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2677.JPG' ALT='Dave feeling mellow'>Dave feeling mellow</a></div></td>
<td><A ID='IMG_2682.JPG' href='sydneytrip0802.php?fileId=IMG_2682.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2682.JPG' ALT='Zen and Smudge feeling mellow'><BR>Zen and Smudge feeling mellow<br>62.48 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2682.JPG' ALT='Zen and Smudge feeling mellow'>Zen and Smudge feeling mellow</a></div></td>
<td><A ID='IMG_2686.JPG' href='sydneytrip0802.php?fileId=IMG_2686.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2686.JPG' ALT='Yacaaba Head'><BR>Yacaaba Head<br>66.83 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2686.JPG' ALT='Yacaaba Head'>Yacaaba Head</a></div></td>
<td><A ID='IMG_2688.JPG' href='sydneytrip0802.php?fileId=IMG_2688.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2688.JPG' ALT='IMG_2688.JPG'><BR>IMG_2688.JPG<br>64.97 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2688.JPG' ALT='IMG_2688.JPG'>IMG_2688.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_2692.JPG' href='sydneytrip0802.php?fileId=IMG_2692.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2692.JPG' ALT='IMG_2692.JPG'><BR>IMG_2692.JPG<br>59.72 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2692.JPG' ALT='IMG_2692.JPG'>IMG_2692.JPG</a></div></td>
<td><A ID='IMG_2695.JPG' href='sydneytrip0802.php?fileId=IMG_2695.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2695.JPG' ALT='IMG_2695.JPG'><BR>IMG_2695.JPG<br>83.61 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2695.JPG' ALT='IMG_2695.JPG'>IMG_2695.JPG</a></div></td>
<td><A ID='IMG_2697.JPG' href='sydneytrip0802.php?fileId=IMG_2697.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2697.JPG' ALT='IMG_2697.JPG'><BR>IMG_2697.JPG<br>47.68 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2697.JPG' ALT='IMG_2697.JPG'>IMG_2697.JPG</a></div></td>
<td><A ID='IMG_2700.JPG' href='sydneytrip0802.php?fileId=IMG_2700.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2700.JPG' ALT='4WD fish-crushin' action!'><BR>4WD fish-crushin' action!<br>57.43 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2700.JPG' ALT='4WD fish-crushin' action!'>4WD fish-crushin' action!</a></div></td>
<td><A ID='IMG_2705.JPG' href='sydneytrip0802.php?fileId=IMG_2705.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2705.JPG' ALT='Katy at work'><BR>Katy at work<br>50.76 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2705.JPG' ALT='Katy at work'>Katy at work</a></div></td>
</tr>
<tr><td><A ID='IMG_2708.JPG' href='sydneytrip0802.php?fileId=IMG_2708.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2708.JPG' ALT='Katy at work'><BR>Katy at work<br>52.85 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2708.JPG' ALT='Katy at work'>Katy at work</a></div></td>
<td><A ID='IMG_2713.JPG' href='sydneytrip0802.php?fileId=IMG_2713.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2713.JPG' ALT='Crested Tern'><BR>Crested Tern<br>31.26 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2713.JPG' ALT='Crested Tern'>Crested Tern</a></div></td>
<td><A ID='IMG_2715.JPG' href='sydneytrip0802.php?fileId=IMG_2715.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2715.JPG' ALT='IMG_2715.JPG'><BR>IMG_2715.JPG<br>43.19 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2715.JPG' ALT='IMG_2715.JPG'>IMG_2715.JPG</a></div></td>
<td><A ID='IMG_2716.JPG' href='sydneytrip0802.php?fileId=IMG_2716.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2716.JPG' ALT='Yes, I know the horizon isn't straight. Get over it.'><BR>Yes, I know the horizon isn't straight. Get over it.<br>46.08 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2716.JPG' ALT='Yes, I know the horizon isn't straight. Get over it.'>Yes, I know the horizon isn't straight. Get over it.</a></div></td>
<td><A ID='IMG_2717.JPG' href='sydneytrip0802.php?fileId=IMG_2717.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2717.JPG' ALT='Striking beach landscape'><BR>Striking beach landscape<br>44.8 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2717.JPG' ALT='Striking beach landscape'>Striking beach landscape</a></div></td>
</tr>
<tr><td><A ID='IMG_2718.JPG' href='sydneytrip0802.php?fileId=IMG_2718.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2718.JPG' ALT='Dave and Katy at Yacaaba Head'><BR>Dave and Katy at Yacaaba Head<br>52.9 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2718.JPG' ALT='Dave and Katy at Yacaaba Head'>Dave and Katy at Yacaaba Head</a></div></td>
<td><A ID='IMG_2720.JPG' href='sydneytrip0802.php?fileId=IMG_2720.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2720.JPG' ALT='Looking back towards Hawk's Nest'><BR>Looking back towards Hawk's Nest<br>50.56 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2720.JPG' ALT='Looking back towards Hawk's Nest'>Looking back towards Hawk's Nest</a></div></td>
<td><A ID='IMG_2721.JPG' href='sydneytrip0802.php?fileId=IMG_2721.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2721.JPG' ALT='Yacaaba Head'><BR>Yacaaba Head<br>65.49 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2721.JPG' ALT='Yacaaba Head'>Yacaaba Head</a></div></td>
<td><A ID='IMG_2724.JPG' href='sydneytrip0802.php?fileId=IMG_2724.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2724.JPG' ALT='Yacaaba Head'><BR>Yacaaba Head<br>79.06 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2724.JPG' ALT='Yacaaba Head'>Yacaaba Head</a></div></td>
<td><A ID='IMG_2736.JPG' href='sydneytrip0802.php?fileId=IMG_2736.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2736.JPG' ALT='Yacaaba Head'><BR>Yacaaba Head<br>136.6 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2736.JPG' ALT='Yacaaba Head'>Yacaaba Head</a></div></td>
</tr>
<tr><td><A ID='IMG_2737.JPG' href='sydneytrip0802.php?fileId=IMG_2737.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2737.JPG' ALT='Yacaaba Head'><BR>Yacaaba Head<br>55.42 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2737.JPG' ALT='Yacaaba Head'>Yacaaba Head</a></div></td>
<td><A ID='IMG_2744.JPG' href='sydneytrip0802.php?fileId=IMG_2744.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2744.JPG' ALT='Looking south'><BR>Looking south<br>72.82 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2744.JPG' ALT='Looking south'>Looking south</a></div></td>
<td><A ID='IMG_2745.JPG' href='sydneytrip0802.php?fileId=IMG_2745.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2745.JPG' ALT='IMG_2745.JPG'><BR>IMG_2745.JPG<br>70.7 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2745.JPG' ALT='IMG_2745.JPG'>IMG_2745.JPG</a></div></td>
<td><A ID='IMG_2748.JPG' href='sydneytrip0802.php?fileId=IMG_2748.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2748.JPG' ALT='Golden Orb weaver'><BR>Golden Orb weaver<br>34.18 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2748.JPG' ALT='Golden Orb weaver'>Golden Orb weaver</a></div></td>
<td><A ID='IMG_2755.JPG' href='sydneytrip0802.php?fileId=IMG_2755.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2755.JPG' ALT='IMG_2755.JPG'><BR>IMG_2755.JPG<br>120.74 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2755.JPG' ALT='IMG_2755.JPG'>IMG_2755.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_2757.JPG' href='sydneytrip0802.php?fileId=IMG_2757.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2757.JPG' ALT='IMG_2757.JPG'><BR>IMG_2757.JPG<br>113.77 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2757.JPG' ALT='IMG_2757.JPG'>IMG_2757.JPG</a></div></td>
<td><A ID='IMG_2760.JPG' href='sydneytrip0802.php?fileId=IMG_2760.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2760.JPG' ALT='IMG_2760.JPG'><BR>IMG_2760.JPG<br>131.74 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2760.JPG' ALT='IMG_2760.JPG'>IMG_2760.JPG</a></div></td>
<td><A ID='IMG_2766.JPG' href='sydneytrip0802.php?fileId=IMG_2766.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2766.JPG' ALT='Dave is actually on the phone to Lindsay'><BR>Dave is actually on the phone to Lindsay<br>74.24 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2766.JPG' ALT='Dave is actually on the phone to Lindsay'>Dave is actually on the phone to Lindsay</a></div></td>
<td><A ID='IMG_2767.JPG' href='sydneytrip0802.php?fileId=IMG_2767.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2767.JPG' ALT='IMG_2767.JPG'><BR>IMG_2767.JPG<br>80.33 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2767.JPG' ALT='IMG_2767.JPG'>IMG_2767.JPG</a></div></td>
<td><A ID='IMG_2769.JPG' href='sydneytrip0802.php?fileId=IMG_2769.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2769.JPG' ALT='IMG_2769.JPG'><BR>IMG_2769.JPG<br>75.93 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2769.JPG' ALT='IMG_2769.JPG'>IMG_2769.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_2773.JPG' href='sydneytrip0802.php?fileId=IMG_2773.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2773.JPG' ALT='IMG_2773.JPG'><BR>IMG_2773.JPG<br>82.6 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2773.JPG' ALT='IMG_2773.JPG'>IMG_2773.JPG</a></div></td>
<td><A ID='IMG_2781.JPG' href='sydneytrip0802.php?fileId=IMG_2781.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2781.JPG' ALT='White Browed Scrub Wren'><BR>White Browed Scrub Wren<br>114.99 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2781.JPG' ALT='White Browed Scrub Wren'>White Browed Scrub Wren</a></div></td>
<td><A ID='IMG_2784.JPG' href='sydneytrip0802.php?fileId=IMG_2784.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2784.JPG' ALT='IMG_2784.JPG'><BR>IMG_2784.JPG<br>89.1 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2784.JPG' ALT='IMG_2784.JPG'>IMG_2784.JPG</a></div></td>
<td><A ID='IMG_2785.JPG' href='sydneytrip0802.php?fileId=IMG_2785.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2785.JPG' ALT='IMG_2785.JPG'><BR>IMG_2785.JPG<br>90.96 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2785.JPG' ALT='IMG_2785.JPG'>IMG_2785.JPG</a></div></td>
<td><A ID='IMG_2787.JPG' href='sydneytrip0802.php?fileId=IMG_2787.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2787.JPG' ALT='IMG_2787.JPG'><BR>IMG_2787.JPG<br>110.11 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2787.JPG' ALT='IMG_2787.JPG'>IMG_2787.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_2789.JPG' href='sydneytrip0802.php?fileId=IMG_2789.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2789.JPG' ALT='IMG_2789.JPG'><BR>IMG_2789.JPG<br>58.4 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2789.JPG' ALT='IMG_2789.JPG'>IMG_2789.JPG</a></div></td>
<td><A ID='IMG_2793.JPG' href='sydneytrip0802.php?fileId=IMG_2793.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2793.JPG' ALT='Rainbow!'><BR>Rainbow!<br>31.81 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2793.JPG' ALT='Rainbow!'>Rainbow!</a></div></td>
<td><A ID='IMG_2794.JPG' href='sydneytrip0802.php?fileId=IMG_2794.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2794.JPG' ALT='Dunes'><BR>Dunes<br>70.23 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2794.JPG' ALT='Dunes'>Dunes</a></div></td>
<td><A ID='IMG_2795.JPG' href='sydneytrip0802.php?fileId=IMG_2795.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2795.JPG' ALT='Yacaaba Head again'><BR>Yacaaba Head again<br>51.63 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2795.JPG' ALT='Yacaaba Head again'>Yacaaba Head again</a></div></td>
<td><A ID='IMG_2796.JPG' href='sydneytrip0802.php?fileId=IMG_2796.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2796.JPG' ALT='Yacaaba Head with rainbow'><BR>Yacaaba Head with rainbow<br>54.76 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2796.JPG' ALT='Yacaaba Head with rainbow'>Yacaaba Head with rainbow</a></div></td>
</tr>
<tr><td><A ID='IMG_2803.JPG' href='sydneytrip0802.php?fileId=IMG_2803.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2803.JPG' ALT='Rainbow over Buladelah'><BR>Rainbow over Buladelah<br>38.52 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2803.JPG' ALT='Rainbow over Buladelah'>Rainbow over Buladelah</a></div></td>
<td><A ID='IMG_2808.JPG' href='sydneytrip0802.php?fileId=IMG_2808.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2808.JPG' ALT='Rainbow over Buladelah'><BR>Rainbow over Buladelah<br>33.6 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2808.JPG' ALT='Rainbow over Buladelah'>Rainbow over Buladelah</a></div></td>
<td><A ID='IMG_2816.JPG' href='sydneytrip0802.php?fileId=IMG_2816.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2816.JPG' ALT='Wot?'><BR>Wot?<br>41.25 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2816.JPG' ALT='Wot?'>Wot?</a></div></td>
<td><A ID='IMG_2819.JPG' href='sydneytrip0802.php?fileId=IMG_2819.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2819.JPG' ALT='IMG_2819.JPG'><BR>IMG_2819.JPG<br>61.77 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2819.JPG' ALT='IMG_2819.JPG'>IMG_2819.JPG</a></div></td>
<td><A ID='IMG_2823.JPG' href='sydneytrip0802.php?fileId=IMG_2823.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2823.JPG' ALT='Overexposed off-camera flash'><BR>Overexposed off-camera flash<br>43.69 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2823.JPG' ALT='Overexposed off-camera flash'>Overexposed off-camera flash</a></div></td>
</tr>
<tr><td><A ID='IMG_2829.JPG' href='sydneytrip0802.php?fileId=IMG_2829.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2829.JPG' ALT='Just disturbing'><BR>Just disturbing<br>67.1 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2829.JPG' ALT='Just disturbing'>Just disturbing</a></div></td>
<td><A ID='IMG_2833.JPG' href='sydneytrip0802.php?fileId=IMG_2833.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2833.JPG' ALT='Awww, kids'><BR>Awww, kids<br>70.34 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2833.JPG' ALT='Awww, kids'>Awww, kids</a></div></td>
<td><A ID='IMG_2835.JPG' href='sydneytrip0802.php?fileId=IMG_2835.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2835.JPG' ALT='Is that a flash in your shirt? Also disturbing.'><BR>Is that a flash in your shirt? Also disturbing.<br>35.96 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2835.JPG' ALT='Is that a flash in your shirt? Also disturbing.'>Is that a flash in your shirt? Also disturbing.</a></div></td>
<td><A ID='IMG_2848.JPG' href='sydneytrip0802.php?fileId=IMG_2848.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2848.JPG' ALT='Dave being photogenic'><BR>Dave being photogenic<br>36.88 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2848.JPG' ALT='Dave being photogenic'>Dave being photogenic</a></div></td>
<td><A ID='IMG_2867.JPG' href='sydneytrip0802.php?fileId=IMG_2867.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2867.JPG' ALT='A gorgeous Emu'><BR>A gorgeous Emu<br>84.52 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2867.JPG' ALT='A gorgeous Emu'>A gorgeous Emu</a></div></td>
</tr>
<tr><td><A ID='IMG_2871.JPG' href='sydneytrip0802.php?fileId=IMG_2871.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080212/IMG_2871.JPG' ALT='Emu'><BR>Emu<br>108.06 KB</a><div class='inv'><br><a href='./images/20080212/IMG_2871.JPG' ALT='Emu'>Emu</a></div></td>
</tr>
</table>	</div>
</div>
</body>
</html>