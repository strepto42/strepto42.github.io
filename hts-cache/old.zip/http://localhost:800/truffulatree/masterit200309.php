<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - September 2003 - Q&A letters</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="Q&A letters">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="Q&A letters" href='masterit200301.php'>January 2003</a></li>
<li><a title="Q&A letters" href='masterit200302.php'>February 2003</a></li>
<li><a title="Q&A letters" href='masterit200303.php'>March 2003</a></li>
<li><a title="Q&A letters" href='masterit200304.php'>April 2003</a></li>
<li><a title="Q&A letters" href='masterit200305.php'>May 2003</a></li>
<li><a title="Q&A letters" href='masterit200306.php'>June 2003</a></li>
<li><a title="Q&A letters" href='masterit200307.php'>July 2003</a></li>
<li><a title="Q&A letters" href='masterit200308.php'>August 2003</a></li>
<li><div class='activemenu'>September 2003</div></li>
<li><a title="Q&A letters" href='masterit200310.php'>October 2003</a></li>
<li><a title="Q&A letters" href='masterit200311.php'>November 2003</a></li>
<li><a title="Q&A letters" href='masterit200312.php'>December 2003</a></li>
<li> </li><br><li>Or go back to:</li><li><a title='Q&A/MasterIT letters from 2003' href="masterit2003.php">2003 archive</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>September 2003</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Mark's writing' href="written.php">Professional Writing</a> > <a title='My weekly Q&A column in The Australian' href="masterIT.php">MasterIT</a> > <a title='Q&A/MasterIT letters from 2003' href="masterit2003.php">2003 archive</a> > <a title='Q&A letters' href="masterit200309.php">September 2003</a>
<br><br>		<br>
<h2>2/9/03</h2><br>
<b>My Word 6.0c suddenly started printing each time, when I open any Word or text document since some weeks ago. I have searched all Win98 and Word 6 settings and cannot fix this annoying problem. I have to keep the printer switched off. The system is otherwise normal.<br>
 <br>
Windows 98 Original version, Epson Stylus Colour 400 printer, Pentium 4. I have Norton 2003 Internet Security, which is continuously updated. I have never had a Virus to my knowledge. Does the registry of Win98 play tricks ?</b><br>
<br>
The registry itself doesn't play tricks, but it can harbour them in the form of odd settings. In this case though it seems less likely.<br>
<br>
In all honesty, the Master is quite stumped with this one. You might have inadvertently recorded a macro that is being started whenever you open a document; or it could be a macro virus, but it seems unlikely given that you're using anti-virus software.<br>
<br>
Apart from the usual "upgrade everything" advice (after all, Word 6 and Win98 first edition are both a little long in the tooth now), you could try searching for, and temporarily renaming the file "normal.dot".<br>
<br>
This is the default document template for Word - it contains various macros and default settings. Rename it and then check to see if the problem is still here.<br>
<br>
Also, make sure your printer driver is up to date. It's unlikely to be the culprit, but stranger things have happened, and it all helps in the process of elimination.<br>
<br>
<br>
<b>Could you please point me to a good site to convert units from different measuring systems? I've found a couple of simple ones but I'm sure there must be an ultimate website for such things out there.</b><br>
<br>
A good site is <a href="http://www.metric.fsworld.co.uk" target="_blank">www.metric.fsworld.co.uk</a>, which has a ton of conversions online. Interestingly, Google actually supports unit conversion now, with it's new calculator feature.<br>
<br>
Just type the term into the search box and it'll report the answer. For example, "pi*10^2". You can also include units, for example "1 mile + 1 kilometre".<br>
<br>
Unit conversions can be done by typing in "convert rods to metres", or just "gallons in litres".<br>
<br>
For more info on the Google calculator and other funky Google features check out <a href="http://www.google.com/help/features.html" target="_blank">www.google.com/help/features.html</a>.<br>
<br>
<br>
<h2>9/9/03</h2><br>
<b>I'm running Windows XP Pro with 512MB of memory. Periodically the machine goes to 100% CPU utilization. Task manager shows two tasks, svchost and spoolsv are the culprits. Running "tasklist /SVC" from shows that the svchost process in question is running the dnscache service.<br>
<br>
Sometimes the problem goes away of its own accord, sometimes it then recurs. Killing both processes will fix the problem in the short term, but they restart and may loop again.<br>
<br>
I have a home network with other windows (95,98) and Linux machines on it and this machine is the print server and Internet gateway. I'm suspicious that the problem occurs after an internet dial-up session is terminated.</b><br>
<br>
It's hard to pin down, but it does feel like a problem associated with the machine's role as a gateway/server.<br>
<br>
The dnscache service caches lookups of domain names, and is used as part of the machine's Internet gateway function.<br>
<br>
The spoolsv service handles the spooling of print jobs. It will be dealing with your network print jobs.<br>
<br>
The fact that both of these are giving you grief might mean that you have two separate problems, or that one problem is causing the other in turn.<br>
<br>
Firstly, make sure your network bindings are stripped back to the bare minimum. This means that you should only have the Client for Microsoft Networks, TCP/IP, and perhaps File and Print Sharing installed on each of the Windows machines (including the server).<br>
<br>
Secondly, make sure that you're not binding anything but TCP/IP to the dial-up connection. In addition to potentially causing problems, binding your internal network to the Internet connection opens your computer wide up to the rest of the world. This is A Bad Thing.<br>
<br>
You should also make sure that your printer driver(s) are up to date (perhaps even try reinstalling them), and make sure that you've been to windowsupdate.com and patched everything up on all the Windows boxes. <br>
<br>
Linux is unlikely to be a problem, but Samba can make life interesting at times (if you're running it). Try removing the box(es) from the network temporarily and see if the problem goes away, just to help narrow things down.<br>
<br>
<br>
<h2>16/9/03</h2><br>
<b>I just upgraded from Windows 2000 to XP, and now I notice that there is a new item in my network connection properties called "QoS Packet Scheduler". Just wondering if this is a good thing to have installed, or just another piece of Microsoft junk?</b><br>
<br>
Apparently, the Quality of Service Packet Scheduler doesn't do much at the moment. Its purpose is to help manage network traffic for certain applications. A QoS aware program can reserve a certain amount of available network bandwidth in order to ensure that its data gets through, and perform a couple of other tricks to improve its performance.<br>
<br>
In practice not many programs make use of this facility yet, so it's unlikely to make any difference (positive or negative) to anything if it's enabled. The bottom line here is the ol' "if it ain't broke, don't fix it".<br>
<br>
<br>
<b>I've been getting lots of virus emails lately, but when I reply to the people (some of whom I don't even know) warning them that they have a virus, they insist that they don't. Some even accused ME of having a virus! What's going on? I'm pretty sure I don't have a virus; my scanner is up to date and a full scan reveals nothing.</b><br>
<br>
If you're up to date and the scanner says that you're clean, you almost certainly are. What is happening is that someone who has your address has a virus.<br>
<br>
A lot of viruses hide their origins by faking their 'from' address. They just go through the victim's address book, sending to everyone, and making it look like they came from some other random name in the address book.<br>
<br>
Unfortunately it can be quite hard to work out who the real person is who has the virus. Viewing the complete message source can sometimes help narrow it down to a particular ISP, but often this isn't much help, and the really clever viruses can completely fake their origins.<br>
<br>
The best option here is just to bin the offending messages, and wait for the infected person or people wake up and remove the virus.<br>
<br>
<br>
<h2>23/9/03</h2><br>
<b>I recently had my home PC's hard disc re-partitioned to load Linux as an alternative operating system. Now I have the choice, when turning my computer on, to either startup Windows 2000 or Red Hat 8. I have a number of questions relating to this.<br>
<br>
1. My Dell PC has a 15 inch flat LCD screen - and I don't seem to have a driver to run Linux using this screen. You see the Catch 22 problem - I can't see the screen to take the appropriate action! Do you have any ideas to get around this problem?</b><br>
<br>
When you say you can't run Linux on this screen, we assume you mean that you can't run X (the GUI). You'll probably need to run the LCD using the standard VGA connector, rather than the newer DVI output. In theory the DVI connection will give you a better picture, but in practice you're unlikely to notice any difference.<br>
<br>
The only alternative is hacking away at your Linux configuration files; probably not something you want to be trying as a new user.<br>
 <br>
<b>2. Will home uses be hit for a Linux user license from the company SCO?</b><br>
<br>
In short, it's pretty unlikely. So far the only winners in the SCO vs Linux battle seem to be the lawyers. Regardless of court decisions, the open source community is militantly anti-SCO, and definitely doesn't welcome their tactics, so, regarding getting money out of Linux users, they've got Buckley's.<br>
 <br>
<b>3. My ultimate intention is to use the far cheaper Linux word processing software. Is it possible to alternately read/edit MS Word and Linux based word processor files? What about if they're on the same computer but on different partitions?</b><br>
<br>
Absolutely. The likes of Openoffice are already well established in the Linux community.<br>
<br>
Exchanging files with your Windows partitions is also fairly easy to achieve, but will require a small amount of fiddling. You're best off creating a dedicated FAT32 partition for the purpose, as Linux doesn't yet have mature NTFS drivers.<br>
<br>
There are plenty of good guides out there, one example can be found at <a href="http://www.geocities.com/epark/linux" target="_blank">www.geocities.com/epark/linux</a>.<br>
<br>
<br>
<h2>30/9/03</h2><br>
<b>I am using Microsoft Internet Explorer 6.0 and I cannot change my homepage. When I go to "Tools" and then "Internet Options" the "Address space" in the "Homepage" section is fogged and I cannot type anything into it, and the three buttons "Use Current", "Use Default" and "Use Blank" are also fogged and cannot be activated.<br>
<br>
I have been to Microsoft's support website, and reloaded Internet Explorer 6.0 three times now but without any success.</b><br>
<br>
It sounds like your registry has been configured to lock this out - IE 5 and above support doing this.<br>
<br>
There are two possibilities here. The first possibility is that your machine is on a corporate network, and the BOFH Sysadmin has set a network policy to prevent you from changing the homepage. If this is the case grovelling and bribery may help (no guarantees though).<br>
<br>
The second option is that some third party software has changed the setting on you.<br>
<br>
First of all check any third party software that may influence your browser. For example Spybot (privacy software) can (apparently) disable your homepage settings by checking a box in "advanced user->immunize".<br>
<br>
You can also check the system security policy by running the policy editor (Start->Run, type GPEDIT.MSC). In the left Window, under user configuration, expand Administrative Templates, Windows Components, and click on Internet Explorer.<br>
<br>
In the right window, make sure "Disable changing home page settings" is set to Not Configured" or "Disabled".<br>
<br>
<br>
<b>What's that bloody Windows button on the keyboard good for? Apart from opening the Start menu (which I can do with a click anyway), and making Bill Gates smug because he has his own personal key on everyone's PC!</b><br>
<br>
In short, not much. In times gone by it seemed the Windows key was specially designed to annoy gamers, by making the PC flip back to windows whenever it was accidentally hit (usually in the middle of a frantic Quake fire fight).<br>
<br>
It's only real use is as a shortcut key. For example Windows-E brings up an Explorer window (which is actually useful!), Windows-R brings up Run Program, and (Shift)-Windows-M minimises/restores all windows. A complete list can be found at <a href="http://www.seoconsultants.com/windows/key" target="_blank">www.seoconsultants.com/windows/key</a>.<br>
<br>
<i><p>Did the information on this page help you? Entertain you? Bore you? <a href="contact.php?subject=MasterIT">Drop me a line</a>.</p>

<p>If you're feeling particularly generous, you can even <a href="buypics.php">click here to send me some dot-com riches</a>. Think of it as online busking.</i></p>
	</div>
</div>
</body>
</html>