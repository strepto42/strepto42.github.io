<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - Jezebel - One Cute Puppy</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="One Cute Puppy">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="Pictures of my 28th Birthday party complete with Sparkler Bomb" href='28th.php'>28th Birthday</a></li>
<li><a title="Pictures of my 30th Birthday party" href='30th.php'>30th Birthday</a></li>
<li><a title="Michael Shamgar and Lindsay Halamek's 30th birthday bash photos" href='sl30th.php'>Shams & Linds' 30th</a></li>
<li><a title="Pictures of Andy Marinos's new flat, cat Toby, and Mum Pam Swain" href='andycatandflat.php'>Andy's Cat & Flat</a></li>
<li><a title="Pictures of a visit to Stephen Jackson's Farm" href='jackovisit.php'>Jacko's Farm</a></li>
<li><a title="Pictures taken at the Peace Convergence action in Rockhampton and Yeppoon in June 2005 to protest the joint US Australia military exercises (Operation Talisman Sabre)" href='peaceconvergence.php'>Peace Convergence</a></li>
<li><a title="Sydney trip - April '06" href='bridges.php'>Sydney, April 06</a></li>
<li><a title="Pics of Naima's 28th birthday dinner" href='mim28th.php'>Naima's 28th</a></li>
<li><a title="Brisbane CBD and the Story Bridge" href='brisbanepics1.php'>Brissie by Night 1</a></li>
<li><a title="Lamington National Park" href='lamington.php'>Lamington NP</a></li>
<li><a title="Various creatures and views from our Brisbane back yard" href='backyard.php'>Backyard Creatures</a></li>
<li><a title="Opening day of the Eleanor Schonell (Green) Bridge" href='greenbridge.php'>Green Bridge</a></li>
<li><a title="Pictutres from the 2006 Woodford Folk Festival" href='woodford0607.php'>Woodford 2006-2007</a></li>
<li><div class='activemenu'>Jezebel</div></li>
<li><a title="Climbing at Kangaroo Point Cliffs" href='kangaroopt1.php'>Heather's Visit</a></li>
<li><a title="0x0021st (33rd) birthday celebrations" href='0x0021st.php'>0x0021st Birthday</a></li>
<li><a title="Nuptial photography" href='guyandalison.php'>Guy and Alison's Wedding</a></li>
<li><a title="Pictures from the 2007 Woodford Folk Festival" href='woodford0708.php'>Woodford 2007-2008</a></li>
<li><a title="Image gallery" href='sydneytrip0802.php'>Sydney & Yacaaba Head</a></li>
<li><a title="An impressive show by nature" href='lightning.php'>Thunderstorm Moonrise</a></li>
<li><a title="Frightening pictures of a shrinking beard" href='debearding.php'>De-bearding</a></li>
<li><a title="More Nuptial Photography" href='michaelandkaren.php'>Michael and Karen's Wedding</a></li>
<li><a title="A night of celebration" href='andrews21st.php'>Andrew's 21st</a></li>
<li><a title="Image Gallery" href='bloodyknee.php'>Bloody Knee</a></li>
<li><a title="Image Gallery" href='tyesbirthday.php'>Tye's Birthday</a></li>
<li><a title="Image Gallery" href='lasersocialising.php'>Laser Socialising</a></li>
<li><a title="Image Gallery" href='heatherandevan.php'>Heather and Evan's Wedding</a></li>
<li><a title="Image Gallery" href='woodford0809.php'>Woodford 2008-2009</a></li>
<li><a title="Image Gallery" href='allyandben.php'>Ally and Ben's Wedding</a></li>
<li><a title="Image Gallery" href='annes30th.php'>Anne's 30th</a></li>
<li><a title="Image Gallery" href='possumcreek.php'>Possum Creek</a></li>
<li><a title="Image Gallery" href='jamnight.php'>Jam Night</a></li>
<li><a title="Image Gallery" href='cunninghamsgap.php'>Cunningham's Gap</a></li>
<li><a title="Image Gallery" href='bigcat.php'>Diving on Big Cat</a></li>
<li><a title="Images from my birthday jam" href='birthdayjam.php'>Music, mayhem and merriment</a></li>
<li><a title="Image Gallery" href='fuzzypolaroidpics.php'>Fuzzy Polaroid</a></li>
<li><a title="Image Gallery" href='zombiewalk2009.php'>2009 Zombie Walk</a></li>
<li> </li><br><li>Or go back to:</li><li><a title='Picture galleries' href="pictures.php">Photography</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>Jezebel</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Picture galleries' href="pictures.php">Photography</a> > <a title='One Cute Puppy' href="jezebel.php">Jezebel</a>
<br><br>		

<p>We have a new puppy. Her name is <a href="http://en.wikipedia.org/wiki/Jezebel" target="_blank">Jezebel</a>. She is, of course, extremely cute.</p>

<p>I've always wanted to get search engine hits for "pictures of puppies", just to pollute the Internet, so here goes. I'll try not to upload <i>too</i> many "baby photos" here, but the cutest simply must be shared with the world.</p>

<p>Like typical doting parents, we've put her on <a href="http://puppywar.com/stats.php?id=44062" target="_blank">puppywar.com</a>, and of course with a picture like that she should bloody well win, but there's <a href="http://puppywar.com/stats.php?id=21881" target="_blank">no</a> <a href="http://puppywar.com/stats.php?id=12577" target="_blank">accounting</a> for <a href="http://puppywar.com/stats.php?id=40385" target="_blank">taste</a>.</p>

<p>Update: She's now old enough to get out and visit the local dog park. Much <a href="?fileId=IMG_6825.JPG">crazed wrestling</a> and chasing of tennis balls is the order of the day. She's also becoming somewhat less <a href="?fileId=IMG_6533.JPG">naughty</a> as she gets older - although she is clearly cabable of still being an <a href="?fileId=IMG_6876.JPG">extremely naughty puppy</a> at times.</p>
<br><br>
All images in this gallery:<br>
<table width='800'>
<tr>
</tr>
<tr><td><A ID='IMG_5275.JPG' href='jezebel.php?fileId=IMG_5275.JPG'><img src='modules/cms/showthumb.php?image=../.././images/jezebel/IMG_5275.JPG' ALT='IMG_5275.JPG'><BR>IMG_5275.JPG<br>62.57 KB</a><div class='inv'><br><a href='./images/jezebel/IMG_5275.JPG' ALT='IMG_5275.JPG'>IMG_5275.JPG</a></div></td>
<td><A ID='IMG_5277.JPG' href='jezebel.php?fileId=IMG_5277.JPG'><img src='modules/cms/showthumb.php?image=../.././images/jezebel/IMG_5277.JPG' ALT='IMG_5277.JPG'><BR>IMG_5277.JPG<br>66.05 KB</a><div class='inv'><br><a href='./images/jezebel/IMG_5277.JPG' ALT='IMG_5277.JPG'>IMG_5277.JPG</a></div></td>
<td><A ID='IMG_5282.JPG' href='jezebel.php?fileId=IMG_5282.JPG'><img src='modules/cms/showthumb.php?image=../.././images/jezebel/IMG_5282.JPG' ALT='IMG_5282.JPG'><BR>IMG_5282.JPG<br>103.34 KB</a><div class='inv'><br><a href='./images/jezebel/IMG_5282.JPG' ALT='IMG_5282.JPG'>IMG_5282.JPG</a></div></td>
<td><A ID='IMG_5288.JPG' href='jezebel.php?fileId=IMG_5288.JPG'><img src='modules/cms/showthumb.php?image=../.././images/jezebel/IMG_5288.JPG' ALT='IMG_5288.JPG'><BR>IMG_5288.JPG<br>62.77 KB</a><div class='inv'><br><a href='./images/jezebel/IMG_5288.JPG' ALT='IMG_5288.JPG'>IMG_5288.JPG</a></div></td>
<td><A ID='IMG_5302.JPG' href='jezebel.php?fileId=IMG_5302.JPG'><img src='modules/cms/showthumb.php?image=../.././images/jezebel/IMG_5302.JPG' ALT='IMG_5302.JPG'><BR>IMG_5302.JPG<br>52.99 KB</a><div class='inv'><br><a href='./images/jezebel/IMG_5302.JPG' ALT='IMG_5302.JPG'>IMG_5302.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5315.JPG' href='jezebel.php?fileId=IMG_5315.JPG'><img src='modules/cms/showthumb.php?image=../.././images/jezebel/IMG_5315.JPG' ALT='IMG_5315.JPG'><BR>IMG_5315.JPG<br>46.72 KB</a><div class='inv'><br><a href='./images/jezebel/IMG_5315.JPG' ALT='IMG_5315.JPG'>IMG_5315.JPG</a></div></td>
<td><A ID='IMG_5330.JPG' href='jezebel.php?fileId=IMG_5330.JPG'><img src='modules/cms/showthumb.php?image=../.././images/jezebel/IMG_5330.JPG' ALT='Jezebel looking extremely cute'><BR>Jezebel looking extremely cute<br>42.6 KB</a><div class='inv'><br><a href='./images/jezebel/IMG_5330.JPG' ALT='Jezebel looking extremely cute'>Jezebel looking extremely cute</a></div></td>
<td><A ID='IMG_5350.JPG' href='jezebel.php?fileId=IMG_5350.JPG'><img src='modules/cms/showthumb.php?image=../.././images/jezebel/IMG_5350.JPG' ALT='IMG_5350.JPG'><BR>IMG_5350.JPG<br>49.43 KB</a><div class='inv'><br><a href='./images/jezebel/IMG_5350.JPG' ALT='IMG_5350.JPG'>IMG_5350.JPG</a></div></td>
<td><A ID='IMG_5355.JPG' href='jezebel.php?fileId=IMG_5355.JPG'><img src='modules/cms/showthumb.php?image=../.././images/jezebel/IMG_5355.JPG' ALT='IMG_5355.JPG'><BR>IMG_5355.JPG<br>111.27 KB</a><div class='inv'><br><a href='./images/jezebel/IMG_5355.JPG' ALT='IMG_5355.JPG'>IMG_5355.JPG</a></div></td>
<td><A ID='IMG_5363.JPG' href='jezebel.php?fileId=IMG_5363.JPG'><img src='modules/cms/showthumb.php?image=../.././images/jezebel/IMG_5363.JPG' ALT='IMG_5363.JPG'><BR>IMG_5363.JPG<br>81.22 KB</a><div class='inv'><br><a href='./images/jezebel/IMG_5363.JPG' ALT='IMG_5363.JPG'>IMG_5363.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5365.JPG' href='jezebel.php?fileId=IMG_5365.JPG'><img src='modules/cms/showthumb.php?image=../.././images/jezebel/IMG_5365.JPG' ALT='IMG_5365.JPG'><BR>IMG_5365.JPG<br>35.51 KB</a><div class='inv'><br><a href='./images/jezebel/IMG_5365.JPG' ALT='IMG_5365.JPG'>IMG_5365.JPG</a></div></td>
<td><A ID='IMG_5385.JPG' href='jezebel.php?fileId=IMG_5385.JPG'><img src='modules/cms/showthumb.php?image=../.././images/jezebel/IMG_5385.JPG' ALT='IMG_5385.JPG'><BR>IMG_5385.JPG<br>78.64 KB</a><div class='inv'><br><a href='./images/jezebel/IMG_5385.JPG' ALT='IMG_5385.JPG'>IMG_5385.JPG</a></div></td>
<td><A ID='IMG_5387.JPG' href='jezebel.php?fileId=IMG_5387.JPG'><img src='modules/cms/showthumb.php?image=../.././images/jezebel/IMG_5387.JPG' ALT='IMG_5387.JPG'><BR>IMG_5387.JPG<br>95.23 KB</a><div class='inv'><br><a href='./images/jezebel/IMG_5387.JPG' ALT='IMG_5387.JPG'>IMG_5387.JPG</a></div></td>
<td><A ID='IMG_5450.JPG' href='jezebel.php?fileId=IMG_5450.JPG'><img src='modules/cms/showthumb.php?image=../.././images/jezebel/IMG_5450.JPG' ALT='IMG_5450.JPG'><BR>IMG_5450.JPG<br>73.14 KB</a><div class='inv'><br><a href='./images/jezebel/IMG_5450.JPG' ALT='IMG_5450.JPG'>IMG_5450.JPG</a></div></td>
<td><A ID='IMG_5591.JPG' href='jezebel.php?fileId=IMG_5591.JPG'><img src='modules/cms/showthumb.php?image=../.././images/jezebel/IMG_5591.JPG' ALT='IMG_5591.JPG'><BR>IMG_5591.JPG<br>76.25 KB</a><div class='inv'><br><a href='./images/jezebel/IMG_5591.JPG' ALT='IMG_5591.JPG'>IMG_5591.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5595.JPG' href='jezebel.php?fileId=IMG_5595.JPG'><img src='modules/cms/showthumb.php?image=../.././images/jezebel/IMG_5595.JPG' ALT='IMG_5595.JPG'><BR>IMG_5595.JPG<br>57.9 KB</a><div class='inv'><br><a href='./images/jezebel/IMG_5595.JPG' ALT='IMG_5595.JPG'>IMG_5595.JPG</a></div></td>
<td><A ID='IMG_5601.JPG' href='jezebel.php?fileId=IMG_5601.JPG'><img src='modules/cms/showthumb.php?image=../.././images/jezebel/IMG_5601.JPG' ALT='IMG_5601.JPG'><BR>IMG_5601.JPG<br>57.19 KB</a><div class='inv'><br><a href='./images/jezebel/IMG_5601.JPG' ALT='IMG_5601.JPG'>IMG_5601.JPG</a></div></td>
<td><A ID='IMG_5608.JPG' href='jezebel.php?fileId=IMG_5608.JPG'><img src='modules/cms/showthumb.php?image=../.././images/jezebel/IMG_5608.JPG' ALT='IMG_5608.JPG'><BR>IMG_5608.JPG<br>70.51 KB</a><div class='inv'><br><a href='./images/jezebel/IMG_5608.JPG' ALT='IMG_5608.JPG'>IMG_5608.JPG</a></div></td>
<td><A ID='IMG_5612.JPG' href='jezebel.php?fileId=IMG_5612.JPG'><img src='modules/cms/showthumb.php?image=../.././images/jezebel/IMG_5612.JPG' ALT='IMG_5612.JPG'><BR>IMG_5612.JPG<br>50.33 KB</a><div class='inv'><br><a href='./images/jezebel/IMG_5612.JPG' ALT='IMG_5612.JPG'>IMG_5612.JPG</a></div></td>
<td><A ID='IMG_5649.JPG' href='jezebel.php?fileId=IMG_5649.JPG'><img src='modules/cms/showthumb.php?image=../.././images/jezebel/IMG_5649.JPG' ALT='IMG_5649.JPG'><BR>IMG_5649.JPG<br>56.44 KB</a><div class='inv'><br><a href='./images/jezebel/IMG_5649.JPG' ALT='IMG_5649.JPG'>IMG_5649.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5653.JPG' href='jezebel.php?fileId=IMG_5653.JPG'><img src='modules/cms/showthumb.php?image=../.././images/jezebel/IMG_5653.JPG' ALT='IMG_5653.JPG'><BR>IMG_5653.JPG<br>52.93 KB</a><div class='inv'><br><a href='./images/jezebel/IMG_5653.JPG' ALT='IMG_5653.JPG'>IMG_5653.JPG</a></div></td>
<td><A ID='IMG_5658.JPG' href='jezebel.php?fileId=IMG_5658.JPG'><img src='modules/cms/showthumb.php?image=../.././images/jezebel/IMG_5658.JPG' ALT='IMG_5658.JPG'><BR>IMG_5658.JPG<br>66.5 KB</a><div class='inv'><br><a href='./images/jezebel/IMG_5658.JPG' ALT='IMG_5658.JPG'>IMG_5658.JPG</a></div></td>
<td><A ID='IMG_5806.JPG' href='jezebel.php?fileId=IMG_5806.JPG'><img src='modules/cms/showthumb.php?image=../.././images/jezebel/IMG_5806.JPG' ALT='IMG_5806.JPG'><BR>IMG_5806.JPG<br>47.95 KB</a><div class='inv'><br><a href='./images/jezebel/IMG_5806.JPG' ALT='IMG_5806.JPG'>IMG_5806.JPG</a></div></td>
<td><A ID='IMG_6469.JPG' href='jezebel.php?fileId=IMG_6469.JPG'><img src='modules/cms/showthumb.php?image=../.././images/jezebel/IMG_6469.JPG' ALT='IMG_6469.JPG'><BR>IMG_6469.JPG<br>51.83 KB</a><div class='inv'><br><a href='./images/jezebel/IMG_6469.JPG' ALT='IMG_6469.JPG'>IMG_6469.JPG</a></div></td>
<td><A ID='IMG_6473.JPG' href='jezebel.php?fileId=IMG_6473.JPG'><img src='modules/cms/showthumb.php?image=../.././images/jezebel/IMG_6473.JPG' ALT='IMG_6473.JPG'><BR>IMG_6473.JPG<br>62.62 KB</a><div class='inv'><br><a href='./images/jezebel/IMG_6473.JPG' ALT='IMG_6473.JPG'>IMG_6473.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_6476.JPG' href='jezebel.php?fileId=IMG_6476.JPG'><img src='modules/cms/showthumb.php?image=../.././images/jezebel/IMG_6476.JPG' ALT='IMG_6476.JPG'><BR>IMG_6476.JPG<br>51.45 KB</a><div class='inv'><br><a href='./images/jezebel/IMG_6476.JPG' ALT='IMG_6476.JPG'>IMG_6476.JPG</a></div></td>
<td><A ID='IMG_6477.JPG' href='jezebel.php?fileId=IMG_6477.JPG'><img src='modules/cms/showthumb.php?image=../.././images/jezebel/IMG_6477.JPG' ALT='IMG_6477.JPG'><BR>IMG_6477.JPG<br>60.52 KB</a><div class='inv'><br><a href='./images/jezebel/IMG_6477.JPG' ALT='IMG_6477.JPG'>IMG_6477.JPG</a></div></td>
<td><A ID='IMG_6482.JPG' href='jezebel.php?fileId=IMG_6482.JPG'><img src='modules/cms/showthumb.php?image=../.././images/jezebel/IMG_6482.JPG' ALT='IMG_6482.JPG'><BR>IMG_6482.JPG<br>46.56 KB</a><div class='inv'><br><a href='./images/jezebel/IMG_6482.JPG' ALT='IMG_6482.JPG'>IMG_6482.JPG</a></div></td>
<td><A ID='IMG_6498.JPG' href='jezebel.php?fileId=IMG_6498.JPG'><img src='modules/cms/showthumb.php?image=../.././images/jezebel/IMG_6498.JPG' ALT='IMG_6498.JPG'><BR>IMG_6498.JPG<br>125.77 KB</a><div class='inv'><br><a href='./images/jezebel/IMG_6498.JPG' ALT='IMG_6498.JPG'>IMG_6498.JPG</a></div></td>
<td><A ID='IMG_6501.JPG' href='jezebel.php?fileId=IMG_6501.JPG'><img src='modules/cms/showthumb.php?image=../.././images/jezebel/IMG_6501.JPG' ALT='IMG_6501.JPG'><BR>IMG_6501.JPG<br>103.56 KB</a><div class='inv'><br><a href='./images/jezebel/IMG_6501.JPG' ALT='IMG_6501.JPG'>IMG_6501.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_6520.JPG' href='jezebel.php?fileId=IMG_6520.JPG'><img src='modules/cms/showthumb.php?image=../.././images/jezebel/IMG_6520.JPG' ALT='IMG_6520.JPG'><BR>IMG_6520.JPG<br>92.48 KB</a><div class='inv'><br><a href='./images/jezebel/IMG_6520.JPG' ALT='IMG_6520.JPG'>IMG_6520.JPG</a></div></td>
<td><A ID='IMG_6523.JPG' href='jezebel.php?fileId=IMG_6523.JPG'><img src='modules/cms/showthumb.php?image=../.././images/jezebel/IMG_6523.JPG' ALT='IMG_6523.JPG'><BR>IMG_6523.JPG<br>87.27 KB</a><div class='inv'><br><a href='./images/jezebel/IMG_6523.JPG' ALT='IMG_6523.JPG'>IMG_6523.JPG</a></div></td>
<td><A ID='IMG_6531.JPG' href='jezebel.php?fileId=IMG_6531.JPG'><img src='modules/cms/showthumb.php?image=../.././images/jezebel/IMG_6531.JPG' ALT='IMG_6531.JPG'><BR>IMG_6531.JPG<br>41.6 KB</a><div class='inv'><br><a href='./images/jezebel/IMG_6531.JPG' ALT='IMG_6531.JPG'>IMG_6531.JPG</a></div></td>
<td><A ID='IMG_6533.JPG' href='jezebel.php?fileId=IMG_6533.JPG'><img src='modules/cms/showthumb.php?image=../.././images/jezebel/IMG_6533.JPG' ALT='IMG_6533.JPG'><BR>IMG_6533.JPG<br>47.89 KB</a><div class='inv'><br><a href='./images/jezebel/IMG_6533.JPG' ALT='IMG_6533.JPG'>IMG_6533.JPG</a></div></td>
<td><A ID='IMG_6541.JPG' href='jezebel.php?fileId=IMG_6541.JPG'><img src='modules/cms/showthumb.php?image=../.././images/jezebel/IMG_6541.JPG' ALT='IMG_6541.JPG'><BR>IMG_6541.JPG<br>67.45 KB</a><div class='inv'><br><a href='./images/jezebel/IMG_6541.JPG' ALT='IMG_6541.JPG'>IMG_6541.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_6562.JPG' href='jezebel.php?fileId=IMG_6562.JPG'><img src='modules/cms/showthumb.php?image=../.././images/jezebel/IMG_6562.JPG' ALT='IMG_6562.JPG'><BR>IMG_6562.JPG<br>49.79 KB</a><div class='inv'><br><a href='./images/jezebel/IMG_6562.JPG' ALT='IMG_6562.JPG'>IMG_6562.JPG</a></div></td>
<td><A ID='IMG_6578.JPG' href='jezebel.php?fileId=IMG_6578.JPG'><img src='modules/cms/showthumb.php?image=../.././images/jezebel/IMG_6578.JPG' ALT='IMG_6578.JPG'><BR>IMG_6578.JPG<br>52.54 KB</a><div class='inv'><br><a href='./images/jezebel/IMG_6578.JPG' ALT='IMG_6578.JPG'>IMG_6578.JPG</a></div></td>
<td><A ID='IMG_6580.JPG' href='jezebel.php?fileId=IMG_6580.JPG'><img src='modules/cms/showthumb.php?image=../.././images/jezebel/IMG_6580.JPG' ALT='IMG_6580.JPG'><BR>IMG_6580.JPG<br>45.93 KB</a><div class='inv'><br><a href='./images/jezebel/IMG_6580.JPG' ALT='IMG_6580.JPG'>IMG_6580.JPG</a></div></td>
<td><A ID='IMG_6581.JPG' href='jezebel.php?fileId=IMG_6581.JPG'><img src='modules/cms/showthumb.php?image=../.././images/jezebel/IMG_6581.JPG' ALT='IMG_6581.JPG'><BR>IMG_6581.JPG<br>48.73 KB</a><div class='inv'><br><a href='./images/jezebel/IMG_6581.JPG' ALT='IMG_6581.JPG'>IMG_6581.JPG</a></div></td>
<td><A ID='IMG_6584.JPG' href='jezebel.php?fileId=IMG_6584.JPG'><img src='modules/cms/showthumb.php?image=../.././images/jezebel/IMG_6584.JPG' ALT='IMG_6584.JPG'><BR>IMG_6584.JPG<br>57.51 KB</a><div class='inv'><br><a href='./images/jezebel/IMG_6584.JPG' ALT='IMG_6584.JPG'>IMG_6584.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_6598.JPG' href='jezebel.php?fileId=IMG_6598.JPG'><img src='modules/cms/showthumb.php?image=../.././images/jezebel/IMG_6598.JPG' ALT='IMG_6598.JPG'><BR>IMG_6598.JPG<br>54.66 KB</a><div class='inv'><br><a href='./images/jezebel/IMG_6598.JPG' ALT='IMG_6598.JPG'>IMG_6598.JPG</a></div></td>
<td><A ID='IMG_6601.JPG' href='jezebel.php?fileId=IMG_6601.JPG'><img src='modules/cms/showthumb.php?image=../.././images/jezebel/IMG_6601.JPG' ALT='IMG_6601.JPG'><BR>IMG_6601.JPG<br>55.75 KB</a><div class='inv'><br><a href='./images/jezebel/IMG_6601.JPG' ALT='IMG_6601.JPG'>IMG_6601.JPG</a></div></td>
<td><A ID='IMG_6756.JPG' href='jezebel.php?fileId=IMG_6756.JPG'><img src='modules/cms/showthumb.php?image=../.././images/jezebel/IMG_6756.JPG' ALT='IMG_6756.JPG'><BR>IMG_6756.JPG<br>55.88 KB</a><div class='inv'><br><a href='./images/jezebel/IMG_6756.JPG' ALT='IMG_6756.JPG'>IMG_6756.JPG</a></div></td>
<td><A ID='IMG_6759.JPG' href='jezebel.php?fileId=IMG_6759.JPG'><img src='modules/cms/showthumb.php?image=../.././images/jezebel/IMG_6759.JPG' ALT='IMG_6759.JPG'><BR>IMG_6759.JPG<br>44.89 KB</a><div class='inv'><br><a href='./images/jezebel/IMG_6759.JPG' ALT='IMG_6759.JPG'>IMG_6759.JPG</a></div></td>
<td><A ID='IMG_6763.JPG' href='jezebel.php?fileId=IMG_6763.JPG'><img src='modules/cms/showthumb.php?image=../.././images/jezebel/IMG_6763.JPG' ALT='IMG_6763.JPG'><BR>IMG_6763.JPG<br>64.26 KB</a><div class='inv'><br><a href='./images/jezebel/IMG_6763.JPG' ALT='IMG_6763.JPG'>IMG_6763.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_6784.JPG' href='jezebel.php?fileId=IMG_6784.JPG'><img src='modules/cms/showthumb.php?image=../.././images/jezebel/IMG_6784.JPG' ALT='IMG_6784.JPG'><BR>IMG_6784.JPG<br>83.49 KB</a><div class='inv'><br><a href='./images/jezebel/IMG_6784.JPG' ALT='IMG_6784.JPG'>IMG_6784.JPG</a></div></td>
<td><A ID='IMG_6785.JPG' href='jezebel.php?fileId=IMG_6785.JPG'><img src='modules/cms/showthumb.php?image=../.././images/jezebel/IMG_6785.JPG' ALT='IMG_6785.JPG'><BR>IMG_6785.JPG<br>63.49 KB</a><div class='inv'><br><a href='./images/jezebel/IMG_6785.JPG' ALT='IMG_6785.JPG'>IMG_6785.JPG</a></div></td>
<td><A ID='IMG_6792.JPG' href='jezebel.php?fileId=IMG_6792.JPG'><img src='modules/cms/showthumb.php?image=../.././images/jezebel/IMG_6792.JPG' ALT='IMG_6792.JPG'><BR>IMG_6792.JPG<br>53.51 KB</a><div class='inv'><br><a href='./images/jezebel/IMG_6792.JPG' ALT='IMG_6792.JPG'>IMG_6792.JPG</a></div></td>
<td><A ID='IMG_6809.JPG' href='jezebel.php?fileId=IMG_6809.JPG'><img src='modules/cms/showthumb.php?image=../.././images/jezebel/IMG_6809.JPG' ALT='IMG_6809.JPG'><BR>IMG_6809.JPG<br>62.79 KB</a><div class='inv'><br><a href='./images/jezebel/IMG_6809.JPG' ALT='IMG_6809.JPG'>IMG_6809.JPG</a></div></td>
<td><A ID='IMG_6814.JPG' href='jezebel.php?fileId=IMG_6814.JPG'><img src='modules/cms/showthumb.php?image=../.././images/jezebel/IMG_6814.JPG' ALT='IMG_6814.JPG'><BR>IMG_6814.JPG<br>61.08 KB</a><div class='inv'><br><a href='./images/jezebel/IMG_6814.JPG' ALT='IMG_6814.JPG'>IMG_6814.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_6818.JPG' href='jezebel.php?fileId=IMG_6818.JPG'><img src='modules/cms/showthumb.php?image=../.././images/jezebel/IMG_6818.JPG' ALT='IMG_6818.JPG'><BR>IMG_6818.JPG<br>71.91 KB</a><div class='inv'><br><a href='./images/jezebel/IMG_6818.JPG' ALT='IMG_6818.JPG'>IMG_6818.JPG</a></div></td>
<td><A ID='IMG_6824.JPG' href='jezebel.php?fileId=IMG_6824.JPG'><img src='modules/cms/showthumb.php?image=../.././images/jezebel/IMG_6824.JPG' ALT='IMG_6824.JPG'><BR>IMG_6824.JPG<br>56.42 KB</a><div class='inv'><br><a href='./images/jezebel/IMG_6824.JPG' ALT='IMG_6824.JPG'>IMG_6824.JPG</a></div></td>
<td><A ID='IMG_6825.JPG' href='jezebel.php?fileId=IMG_6825.JPG'><img src='modules/cms/showthumb.php?image=../.././images/jezebel/IMG_6825.JPG' ALT='IMG_6825.JPG'><BR>IMG_6825.JPG<br>59.39 KB</a><div class='inv'><br><a href='./images/jezebel/IMG_6825.JPG' ALT='IMG_6825.JPG'>IMG_6825.JPG</a></div></td>
<td><A ID='IMG_6829.JPG' href='jezebel.php?fileId=IMG_6829.JPG'><img src='modules/cms/showthumb.php?image=../.././images/jezebel/IMG_6829.JPG' ALT='IMG_6829.JPG'><BR>IMG_6829.JPG<br>57.2 KB</a><div class='inv'><br><a href='./images/jezebel/IMG_6829.JPG' ALT='IMG_6829.JPG'>IMG_6829.JPG</a></div></td>
<td><A ID='IMG_6832.JPG' href='jezebel.php?fileId=IMG_6832.JPG'><img src='modules/cms/showthumb.php?image=../.././images/jezebel/IMG_6832.JPG' ALT='IMG_6832.JPG'><BR>IMG_6832.JPG<br>57.31 KB</a><div class='inv'><br><a href='./images/jezebel/IMG_6832.JPG' ALT='IMG_6832.JPG'>IMG_6832.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_6833.JPG' href='jezebel.php?fileId=IMG_6833.JPG'><img src='modules/cms/showthumb.php?image=../.././images/jezebel/IMG_6833.JPG' ALT='IMG_6833.JPG'><BR>IMG_6833.JPG<br>82.02 KB</a><div class='inv'><br><a href='./images/jezebel/IMG_6833.JPG' ALT='IMG_6833.JPG'>IMG_6833.JPG</a></div></td>
<td><A ID='IMG_6853.JPG' href='jezebel.php?fileId=IMG_6853.JPG'><img src='modules/cms/showthumb.php?image=../.././images/jezebel/IMG_6853.JPG' ALT='IMG_6853.JPG'><BR>IMG_6853.JPG<br>75.31 KB</a><div class='inv'><br><a href='./images/jezebel/IMG_6853.JPG' ALT='IMG_6853.JPG'>IMG_6853.JPG</a></div></td>
<td><A ID='IMG_6855.JPG' href='jezebel.php?fileId=IMG_6855.JPG'><img src='modules/cms/showthumb.php?image=../.././images/jezebel/IMG_6855.JPG' ALT='IMG_6855.JPG'><BR>IMG_6855.JPG<br>56.1 KB</a><div class='inv'><br><a href='./images/jezebel/IMG_6855.JPG' ALT='IMG_6855.JPG'>IMG_6855.JPG</a></div></td>
<td><A ID='IMG_6876.JPG' href='jezebel.php?fileId=IMG_6876.JPG'><img src='modules/cms/showthumb.php?image=../.././images/jezebel/IMG_6876.JPG' ALT='Naughty Puppy'><BR>Naughty Puppy<br>37.22 KB</a><div class='inv'><br><a href='./images/jezebel/IMG_6876.JPG' ALT='Naughty Puppy'>Naughty Puppy</a></div></td>
</tr>
</table>	</div>
</div>
</body>
</html>