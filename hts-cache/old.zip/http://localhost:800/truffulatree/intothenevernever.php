<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - 5/8/2005 - Into the Never Never</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="Into the Never Never">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="Greetings from a Bum" href='greetingsfromabum.php'>29/4/2005</a></li>
<li><a title="Onward" href='onward.php'>2/5/2005</a></li>
<li><a title="It's a tough life (pt 1: Bundaberg, Agnes Water and 1770)" href='itsatoughlife1.php'>17/5/2005</a></li>
<li><a title="It's a tough life (pt 2: Rockhampton, Emu Park and Great Keppel Island)" href='itsatoughlife2.php'>23/5/2005</a></li>
<li><a title="There and Back Again - a Yo-yo's Tale" href='thereandbackagain.php'>18/6/2005</a></li>
<li><a title="Platypi and Grey Nomads" href='platypiandgreynomads.php'>24/6/2005</a></li>
<li><a title="Blowing Bubbles in a Watery Tomb" href='blowingbubbles.php'>1/7/2005</a></li>
<li><a title="Pieces of History" href='piecesofhistory.php'>8/7/2005</a></li>
<li><a title="Walks and Waterfalls" href='walksandwaterfalls.php'>15/7/2005</a></li>
<li><a title="Mission to Tribulation" href='missiontotribulation.php'>22/7/2005</a></li>
<li><a title="Levity, Limestone and Lava" href='levitylimestoneandlava.php'>29/7/2005</a></li>
<li><div class='activemenu'>5/8/2005</div></li>
<li><a title="Slowing the pace in Darwin" href='slowingthepaceindarwin.php'>12/8/2005</a></li>
<li><a title="Blistering Barnacles and Leaping Lizards" href='leapinglizards.php'>19/8/2005</a></li>
<li><a title="Kakadu and Litchfield" href='kakadu.php'>26/8/2005</a></li>
<li><a title="Legacies of War" href='legaciesofwar.php'>2/9/2005</a></li>
<li><a title="Go West" href='gowest.php'>10/9/2005</a></li>
<li><a title="Things from Above" href='thingsfromabove.php'>16/9/2005</a></li>
<li><a title="The West Coast" href='thewestcoast.php'>23/9/2005</a></li>
<li><a title="Reefs and Red Dust" href='reefsandreddust.php'>30/9/2005</a></li>
<li><a title="The Pilbara" href='pilbara.php'>7/10/2005</a></li>
<li><a title="Paradise with a Headwind" href='paradisewithaheadwind.php'>14/10/2005</a></li>
<li><a title="Down the Coral Coast" href='downthecoralcoast.php'>21/10/2005</a></li>
<li><a title="Pinnacles and Pinnipeds" href='pinnaclesandpinnipeds.php'>28/10/2005</a></li>
<li><a title="A week in Perth" href='perth.php'>4/11/2005</a></li>
<li><a title="The Southwest (from Above and Below)" href='thesouthwest.php'>11/11/2005</a></li>
<li><a title="More Heights and Depths" href='moreheightsanddepths.php'>18/11/2005</a></li>
<li><a title="Across the Nullarbor (and a bit beyond)" href='nullarbor.php'>25/11/2005</a></li>
<li><a title="Double Whammy" href='doublewhammy.php'>9/12/2005</a></li>
<li><a title="Two Cities" href='twocities.php'>19/12/2005</a></li>
<li><a title="Tassie - Part 1" href='tassie1.php'>1/1/2006</a></li>
<li><a title="Tassie - Part 2" href='tassie2.php'>7/1/2006</a></li>
<li><a title="Full Circle" href='fullcircle.php'>26/1/2006</a></li>
<li><a title="The Wrap Up" href='thewrapup.php'>23/3/2006</a></li>
<li> </li><br><li>Or go back to:</li><li><a title='Travelouges and blogs from my trip around Australia' href="nerdseyeview.php">Nerd's Eye View</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>5/8/2005</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Travel stories and pictures' href="travel.php">Travelogues</a> > <a title='Travelouges and blogs from my trip around Australia' href="nerdseyeview.php">Nerd's Eye View</a> > <a title='Into the Never Never' href="intothenevernever.php">5/8/2005</a>
<br><br>		


<h1>Into the Never Never</h1>

<a href="images/maps/Map050805.gif"><img src="images/maps/Map050805_sm.gif" align="right"></a>
<p>Hi all, looks like it's story time again!</p>

<p>Well, since last week, I've done a fair few kilometres, and I've finally left sunny QLD for the even sunnier NT, and as I write this I'm sitting as far North as I've been yet, in Katherine, shirtless, in 30+ degree heat... It feels like a Sydney summer afternoon! Hell yeah.</p>

<p>But first things first (and now that I've annoyed everyone). I spent two nights in Karumba (last fri and sat). On the first night, when I wrote the last email, they had a free sausage sizzle. "Goody!" I thought, being a cheapskate traveller bum. The catch was that it was part of the afternoon social event, consisting of many caravanning oldies.</p>

<p>In between the terrible music (live and pre-recorded - I swear they played a song with the main chorus line being "if I said you had a beautiful body, would you hold it against me?" and all I could think of was the Monty Python phrasebook sketch), a bloke got up and did some bush poetry, which was actually very entertaining (for me especially).</p>

<p>Initially, I thought he wouldn't be able to stand, let alone speak, as when he got up he was clearly pissed and could hardly string 3 words together, but he delivered his poems (both about a cattle dog that bit off another dog's balls, and then mounted another one) with unusual clarity and poise.</p>

<p>Anyway it was quite amusing, and I got my free snags (4 of 'em!).</p>

<p>I also got to know my caravan park "neighbour", a fellow called Mel who had apparently won lotto a few years ago, and now travels most of the year. He also won various other things, so perhaps some people do have genetic luck. Bastard.</p>

<p>He was an interesting chap actually, and he'd worked in the music industry a fair bit (including mixing the Hey Hey It's Saturday band for a time), and so he had some amusing stories. We shared a few beers on my second night, and wept together at modern music's mediocrity.</p>

<p>He also came round one afternoon to show me what had been found in the stomach of a fish that someone had caught - the remains of a Mantis Prawn (see pic on the website). Those spikes are seriously sharp - I have no idea how the fish managed to swallow it!</p>

<p>Apart from that, I rode around the town a bit, took lots of pictures (of the many circling birds of prey), and spent an arvo at the Sunset Cafe watching the sun go down over the water, with beer in hand of course.</p>

<p>To complete the circle, I took a few more pics at night, then at dawn. I quite liked Karumba, despite it's complete lack of anything to do but fish (which I don't do).</p>

<p>From there I pushed on, and drove all day to reach Mt Isa, the big mining town in NW QLD. It's a massive mine, a big producer of copper, lead, silver and something else I can't remember right this second (and I'm too lazy to look up even though the literature is in my car somewhere).</p>

<p>I'd heard it's a pretty rough place, with far more men than women in town. Personally I didn't mind it, although I didn't go out on the town. I did explore a little on the bike, and I suppose at times I could sense an undercurrent of repressed agro in some people, but no more so than in many other country places.</p>

<p>Anyway I opted out of hitting the town of an evening, mainly because the hostel had a nice group of people, and I spent two enjoyable nights there playing music (of course) and drinking (of course). The photos of said nights are on my site; a ukulele was produced at one stage and made for some amusing photos. One of them is definitely a "possessed by rock" pic.</p>

<p>I also went up to the town lookout and did a shiny-lights-night-photo-shoot, the results of which I am quite happy with, although I am starting to crave L glass.</p>

<p>Anyhow, after getting the car serviced (no dramas, so yay), I pushed on to Camooweal, near the NT border.</p>

<p>There's not much to Camooweal. All I knew of it was the name, from a Slim Dusty song that used to play on long car trips when I was a kid. The song ends with "...so I think I'll not go back to Camooweal". I must concur, although there are caves there, in the form of massive sinkholes, which could be interesting to explore, but only after a few years of training. :) I did go look at one, but it was fairly boring example, and someone had been chucking rubbish in there. Nice.</p>

<p>So that was it for QLD - the next day I headed across the border, and through the Barkley Tableland to Three Ways - where you can go North to Darwin, South to Adelaide via Alice, or back to QLD.</p>

<p>There aren't a whole lot of roads in this part of the world - the tableland is a bloody massive, bloody desolate place, and really hammers home the whole BIGness of this country. It's all very well and good to appreciate it academically, but until you drive ALL DAY in a straight line, and pass maybe two roadhouses and three dirt tracks it's hard to get the full picture.</p>

<p>The long drives were pretty much without incident. Occasionally you'd run across a poor dead roo with various birds pecking away. A few times in QLD, I'd seen massive Wedge Tailed Eagles feasting on the roadkill, but they'd always fly away before I could stop and take a pic. These birds are amazing though, and have to be seen to be believed (especially the bigger ones; these are BIG birds). I'm still questing for a really GOOD pic of a wedgie (jokes on a postcard...), but they're more and more common as you go through the territory (which I guess was the point of the story) so I should get a money shot eventually.</p>

<p>Anyway, at Three Ways, I headed South for a bit, to the Devil's Marbles. These are big weathered blocks of granite, and they glow nicely in the sun, especially at dawn and dusk. They're very touristy and photographed of course; but I couldn't resist taking countless snaps myself, including a couple of night shots. I've only put a selection up here website, but they tell the story.</p>

<p>In the end it was another dusk/night/dawn shoot, after which I pushed on, back up North to a spot called Daly Waters, via Tennant Creek and an old ghost town called Newcastle Waters (in which the most interesting thing was an old school graffitied public phone).</p>

<p>The pub at Daly is full of strange memorabilia, including underwear donated by visitors. I chose not to donate.</p>

<p>They also have a nightly show there with a precocious 15 year old playing pretty good country music and telling pretty bad jokes, as well as a guy who plays and sings with chooks on his head. I believe he's been on Red Faces.</p>

<p>It was fairly entertaining actually, in a daggy sort of way. The oldies liked it of course - and boy are there a lot of them. In fact, since leaving Cairns, it's been Grey Nomads with vans all the way, and far fewer backpackers.</p>

<p>But back to the story. After Daly Waters I continued up to Katherine, which is where I am now. I stopped off at the Mataranka hot spring, but couldn't be bothered taking a dip, as 34 degree water is too warm when it's 30 outside! There is also a replica of the homestead the used in the movie "We of the Never Never" there. Maybe I should see it sometime.</p>

<p>I haven't explored Katherine yet, and tomorrow I'll push on to Darwin (to invade Justine's house), but I'll be back here shortly on my way to the Kimberley; like I said, road choices up here are somewhat limited. </p>

<p>Somewhere along the way I have also passed the 10,000km mark on my speedo; ie 10k since leaving Brisbane. It was 7k to Cairns, a straight line trip of only 2k, so I have been zigging and zagging a bit. But that's the object of the exercise.</p>

<p>The car is filthy but holding up well, as I suspected it would. It chews a litre of oil every thousand kilometres or so, but that's bearable, and it's actually quite comfortable to sleep in, as long as there are no mozzies to torment me at 4am.</p>

<p>I've also discovered (by timing my trips, doing maths and correlating with my GPS like a good nerd) that my car's speedometer under-reads by exactly 10%. Strangely, the odometer doesn't. I suspect a conspiracy by auto manufacturers to slow us all down. Just think - all this time, when I thought I was exceeding the speed limit by 10kph, I was in fact doing a legal speed! Oh the shame...</p>

<p>On another random note, if anyone tried to send me an email in the last few days and it bounced, just send it again. My home computer had... issues.</p>

<p>This week's piccies are:</p>
<!-- 
<ul>
<li><a href="?fileId=IMG_5526.JPG">Fishing in Karumba</a></li>
<li><a href="?fileId=IMG_5703.JPG">Mt Isa mine with ghost who walks</a></li>
<li><a href="?fileId=IMG_5727.JPG">Into the NT... empty and desolate</a></li>
<li><a href="?fileId=IMG_5839.JPG">Devil's Marbles with amazing desert stars</a></li>
<li><a href="?fileId=IMG_5863.JPG">Dawn paints the marbles red</a></li>
</ul>
 -->
<table width="800">
	<tr>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=IMG_5526.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20050805/IMG_5526.JPG' ALT='Fishing in Karumba'><BR>Fishing in Karumba</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=IMG_5703.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20050805/IMG_5703.JPG' ALT='Mt Isa mine with ghost who walks'><BR>Mt Isa mine with ghost who walks</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=IMG_5727.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20050805/IMG_5727.JPG' ALT='Into the NT... empty and desolate'><BR>Into the NT... empty and desolate</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=IMG_5839.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20050805/IMG_5839.JPG' ALT="Devil's Marbles with amazing desert stars"><BR>Devil's Marbles with amazing desert stars</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=IMG_5863.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20050805/IMG_5863.JPG' ALT='Dawn paints the marbles red'><BR>Dawn paints the marbles red</a>
	</td>
	</tr>
</table>

<p>And now I believe it's beer o'clock (get yourself one too, if you just read all that in one go!). Till next week, take care!</p>

<br><br>
All images in this gallery:<br>
<table width='800'>
<tr>
</tr>
<tr><td><A ID='IMG_5491.JPG' href='intothenevernever.php?fileId=IMG_5491.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050805/IMG_5491.JPG' ALT='IMG_5491.JPG'><BR>IMG_5491.JPG<br>66.77 KB</a><div class='inv'><br><a href='./images/20050805/IMG_5491.JPG' ALT='IMG_5491.JPG'>IMG_5491.JPG</a></div></td>
<td><A ID='IMG_5494.JPG' href='intothenevernever.php?fileId=IMG_5494.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050805/IMG_5494.JPG' ALT='IMG_5494.JPG'><BR>IMG_5494.JPG<br>73.62 KB</a><div class='inv'><br><a href='./images/20050805/IMG_5494.JPG' ALT='IMG_5494.JPG'>IMG_5494.JPG</a></div></td>
<td><A ID='IMG_5495.JPG' href='intothenevernever.php?fileId=IMG_5495.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050805/IMG_5495.JPG' ALT='IMG_5495.JPG'><BR>IMG_5495.JPG<br>44.13 KB</a><div class='inv'><br><a href='./images/20050805/IMG_5495.JPG' ALT='IMG_5495.JPG'>IMG_5495.JPG</a></div></td>
<td><A ID='IMG_5497.JPG' href='intothenevernever.php?fileId=IMG_5497.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050805/IMG_5497.JPG' ALT='IMG_5497.JPG'><BR>IMG_5497.JPG<br>60.05 KB</a><div class='inv'><br><a href='./images/20050805/IMG_5497.JPG' ALT='IMG_5497.JPG'>IMG_5497.JPG</a></div></td>
<td><A ID='IMG_5500.JPG' href='intothenevernever.php?fileId=IMG_5500.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050805/IMG_5500.JPG' ALT='IMG_5500.JPG'><BR>IMG_5500.JPG<br>53.75 KB</a><div class='inv'><br><a href='./images/20050805/IMG_5500.JPG' ALT='IMG_5500.JPG'>IMG_5500.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5512.JPG' href='intothenevernever.php?fileId=IMG_5512.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050805/IMG_5512.JPG' ALT='IMG_5512.JPG'><BR>IMG_5512.JPG<br>23.63 KB</a><div class='inv'><br><a href='./images/20050805/IMG_5512.JPG' ALT='IMG_5512.JPG'>IMG_5512.JPG</a></div></td>
<td><A ID='IMG_5520.JPG' href='intothenevernever.php?fileId=IMG_5520.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050805/IMG_5520.JPG' ALT='IMG_5520.JPG'><BR>IMG_5520.JPG<br>25.53 KB</a><div class='inv'><br><a href='./images/20050805/IMG_5520.JPG' ALT='IMG_5520.JPG'>IMG_5520.JPG</a></div></td>
<td><A ID='IMG_5526.JPG' href='intothenevernever.php?fileId=IMG_5526.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050805/IMG_5526.JPG' ALT='IMG_5526.JPG'><BR>IMG_5526.JPG<br>49.23 KB</a><div class='inv'><br><a href='./images/20050805/IMG_5526.JPG' ALT='IMG_5526.JPG'>IMG_5526.JPG</a></div></td>
<td><A ID='IMG_5533.JPG' href='intothenevernever.php?fileId=IMG_5533.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050805/IMG_5533.JPG' ALT='IMG_5533.JPG'><BR>IMG_5533.JPG<br>35.91 KB</a><div class='inv'><br><a href='./images/20050805/IMG_5533.JPG' ALT='IMG_5533.JPG'>IMG_5533.JPG</a></div></td>
<td><A ID='IMG_5539.JPG' href='intothenevernever.php?fileId=IMG_5539.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050805/IMG_5539.JPG' ALT='IMG_5539.JPG'><BR>IMG_5539.JPG<br>54.21 KB</a><div class='inv'><br><a href='./images/20050805/IMG_5539.JPG' ALT='IMG_5539.JPG'>IMG_5539.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5542.JPG' href='intothenevernever.php?fileId=IMG_5542.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050805/IMG_5542.JPG' ALT='IMG_5542.JPG'><BR>IMG_5542.JPG<br>81.83 KB</a><div class='inv'><br><a href='./images/20050805/IMG_5542.JPG' ALT='IMG_5542.JPG'>IMG_5542.JPG</a></div></td>
<td><A ID='IMG_5550.JPG' href='intothenevernever.php?fileId=IMG_5550.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050805/IMG_5550.JPG' ALT='IMG_5550.JPG'><BR>IMG_5550.JPG<br>28.95 KB</a><div class='inv'><br><a href='./images/20050805/IMG_5550.JPG' ALT='IMG_5550.JPG'>IMG_5550.JPG</a></div></td>
<td><A ID='IMG_5551.JPG' href='intothenevernever.php?fileId=IMG_5551.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050805/IMG_5551.JPG' ALT='IMG_5551.JPG'><BR>IMG_5551.JPG<br>62.3 KB</a><div class='inv'><br><a href='./images/20050805/IMG_5551.JPG' ALT='IMG_5551.JPG'>IMG_5551.JPG</a></div></td>
<td><A ID='IMG_5557.JPG' href='intothenevernever.php?fileId=IMG_5557.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050805/IMG_5557.JPG' ALT='IMG_5557.JPG'><BR>IMG_5557.JPG<br>46.76 KB</a><div class='inv'><br><a href='./images/20050805/IMG_5557.JPG' ALT='IMG_5557.JPG'>IMG_5557.JPG</a></div></td>
<td><A ID='IMG_5562.JPG' href='intothenevernever.php?fileId=IMG_5562.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050805/IMG_5562.JPG' ALT='IMG_5562.JPG'><BR>IMG_5562.JPG<br>43.3 KB</a><div class='inv'><br><a href='./images/20050805/IMG_5562.JPG' ALT='IMG_5562.JPG'>IMG_5562.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5572.JPG' href='intothenevernever.php?fileId=IMG_5572.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050805/IMG_5572.JPG' ALT='IMG_5572.JPG'><BR>IMG_5572.JPG<br>38 KB</a><div class='inv'><br><a href='./images/20050805/IMG_5572.JPG' ALT='IMG_5572.JPG'>IMG_5572.JPG</a></div></td>
<td><A ID='IMG_5576.JPG' href='intothenevernever.php?fileId=IMG_5576.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050805/IMG_5576.JPG' ALT='IMG_5576.JPG'><BR>IMG_5576.JPG<br>38.1 KB</a><div class='inv'><br><a href='./images/20050805/IMG_5576.JPG' ALT='IMG_5576.JPG'>IMG_5576.JPG</a></div></td>
<td><A ID='IMG_5579.JPG' href='intothenevernever.php?fileId=IMG_5579.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050805/IMG_5579.JPG' ALT='IMG_5579.JPG'><BR>IMG_5579.JPG<br>29.22 KB</a><div class='inv'><br><a href='./images/20050805/IMG_5579.JPG' ALT='IMG_5579.JPG'>IMG_5579.JPG</a></div></td>
<td><A ID='IMG_5613.JPG' href='intothenevernever.php?fileId=IMG_5613.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050805/IMG_5613.JPG' ALT='IMG_5613.JPG'><BR>IMG_5613.JPG<br>31.8 KB</a><div class='inv'><br><a href='./images/20050805/IMG_5613.JPG' ALT='IMG_5613.JPG'>IMG_5613.JPG</a></div></td>
<td><A ID='IMG_5617.JPG' href='intothenevernever.php?fileId=IMG_5617.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050805/IMG_5617.JPG' ALT='IMG_5617.JPG'><BR>IMG_5617.JPG<br>26.03 KB</a><div class='inv'><br><a href='./images/20050805/IMG_5617.JPG' ALT='IMG_5617.JPG'>IMG_5617.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5619.JPG' href='intothenevernever.php?fileId=IMG_5619.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050805/IMG_5619.JPG' ALT='IMG_5619.JPG'><BR>IMG_5619.JPG<br>44.42 KB</a><div class='inv'><br><a href='./images/20050805/IMG_5619.JPG' ALT='IMG_5619.JPG'>IMG_5619.JPG</a></div></td>
<td><A ID='IMG_5628.JPG' href='intothenevernever.php?fileId=IMG_5628.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050805/IMG_5628.JPG' ALT='IMG_5628.JPG'><BR>IMG_5628.JPG<br>89.28 KB</a><div class='inv'><br><a href='./images/20050805/IMG_5628.JPG' ALT='IMG_5628.JPG'>IMG_5628.JPG</a></div></td>
<td><A ID='IMG_5633.JPG' href='intothenevernever.php?fileId=IMG_5633.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050805/IMG_5633.JPG' ALT='IMG_5633.JPG'><BR>IMG_5633.JPG<br>62.87 KB</a><div class='inv'><br><a href='./images/20050805/IMG_5633.JPG' ALT='IMG_5633.JPG'>IMG_5633.JPG</a></div></td>
<td><A ID='IMG_5642.JPG' href='intothenevernever.php?fileId=IMG_5642.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050805/IMG_5642.JPG' ALT='IMG_5642.JPG'><BR>IMG_5642.JPG<br>44.98 KB</a><div class='inv'><br><a href='./images/20050805/IMG_5642.JPG' ALT='IMG_5642.JPG'>IMG_5642.JPG</a></div></td>
<td><A ID='IMG_5646.JPG' href='intothenevernever.php?fileId=IMG_5646.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050805/IMG_5646.JPG' ALT='IMG_5646.JPG'><BR>IMG_5646.JPG<br>53.26 KB</a><div class='inv'><br><a href='./images/20050805/IMG_5646.JPG' ALT='IMG_5646.JPG'>IMG_5646.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5649.JPG' href='intothenevernever.php?fileId=IMG_5649.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050805/IMG_5649.JPG' ALT='IMG_5649.JPG'><BR>IMG_5649.JPG<br>89.12 KB</a><div class='inv'><br><a href='./images/20050805/IMG_5649.JPG' ALT='IMG_5649.JPG'>IMG_5649.JPG</a></div></td>
<td><A ID='IMG_5650.JPG' href='intothenevernever.php?fileId=IMG_5650.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050805/IMG_5650.JPG' ALT='IMG_5650.JPG'><BR>IMG_5650.JPG<br>54.6 KB</a><div class='inv'><br><a href='./images/20050805/IMG_5650.JPG' ALT='IMG_5650.JPG'>IMG_5650.JPG</a></div></td>
<td><A ID='IMG_5654.JPG' href='intothenevernever.php?fileId=IMG_5654.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050805/IMG_5654.JPG' ALT='IMG_5654.JPG'><BR>IMG_5654.JPG<br>85.17 KB</a><div class='inv'><br><a href='./images/20050805/IMG_5654.JPG' ALT='IMG_5654.JPG'>IMG_5654.JPG</a></div></td>
<td><A ID='IMG_5655.JPG' href='intothenevernever.php?fileId=IMG_5655.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050805/IMG_5655.JPG' ALT='IMG_5655.JPG'><BR>IMG_5655.JPG<br>77.76 KB</a><div class='inv'><br><a href='./images/20050805/IMG_5655.JPG' ALT='IMG_5655.JPG'>IMG_5655.JPG</a></div></td>
<td><A ID='IMG_5678.JPG' href='intothenevernever.php?fileId=IMG_5678.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050805/IMG_5678.JPG' ALT='IMG_5678.JPG'><BR>IMG_5678.JPG<br>72.24 KB</a><div class='inv'><br><a href='./images/20050805/IMG_5678.JPG' ALT='IMG_5678.JPG'>IMG_5678.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5682.JPG' href='intothenevernever.php?fileId=IMG_5682.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050805/IMG_5682.JPG' ALT='IMG_5682.JPG'><BR>IMG_5682.JPG<br>53.45 KB</a><div class='inv'><br><a href='./images/20050805/IMG_5682.JPG' ALT='IMG_5682.JPG'>IMG_5682.JPG</a></div></td>
<td><A ID='IMG_5692.JPG' href='intothenevernever.php?fileId=IMG_5692.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050805/IMG_5692.JPG' ALT='IMG_5692.JPG'><BR>IMG_5692.JPG<br>72.69 KB</a><div class='inv'><br><a href='./images/20050805/IMG_5692.JPG' ALT='IMG_5692.JPG'>IMG_5692.JPG</a></div></td>
<td><A ID='IMG_5695.JPG' href='intothenevernever.php?fileId=IMG_5695.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050805/IMG_5695.JPG' ALT='IMG_5695.JPG'><BR>IMG_5695.JPG<br>60.63 KB</a><div class='inv'><br><a href='./images/20050805/IMG_5695.JPG' ALT='IMG_5695.JPG'>IMG_5695.JPG</a></div></td>
<td><A ID='IMG_5700.JPG' href='intothenevernever.php?fileId=IMG_5700.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050805/IMG_5700.JPG' ALT='IMG_5700.JPG'><BR>IMG_5700.JPG<br>39.92 KB</a><div class='inv'><br><a href='./images/20050805/IMG_5700.JPG' ALT='IMG_5700.JPG'>IMG_5700.JPG</a></div></td>
<td><A ID='IMG_5701.JPG' href='intothenevernever.php?fileId=IMG_5701.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050805/IMG_5701.JPG' ALT='IMG_5701.JPG'><BR>IMG_5701.JPG<br>59.91 KB</a><div class='inv'><br><a href='./images/20050805/IMG_5701.JPG' ALT='IMG_5701.JPG'>IMG_5701.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5703.JPG' href='intothenevernever.php?fileId=IMG_5703.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050805/IMG_5703.JPG' ALT='IMG_5703.JPG'><BR>IMG_5703.JPG<br>72.32 KB</a><div class='inv'><br><a href='./images/20050805/IMG_5703.JPG' ALT='IMG_5703.JPG'>IMG_5703.JPG</a></div></td>
<td><A ID='IMG_5705.JPG' href='intothenevernever.php?fileId=IMG_5705.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050805/IMG_5705.JPG' ALT='IMG_5705.JPG'><BR>IMG_5705.JPG<br>53.35 KB</a><div class='inv'><br><a href='./images/20050805/IMG_5705.JPG' ALT='IMG_5705.JPG'>IMG_5705.JPG</a></div></td>
<td><A ID='IMG_5707.JPG' href='intothenevernever.php?fileId=IMG_5707.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050805/IMG_5707.JPG' ALT='IMG_5707.JPG'><BR>IMG_5707.JPG<br>44.91 KB</a><div class='inv'><br><a href='./images/20050805/IMG_5707.JPG' ALT='IMG_5707.JPG'>IMG_5707.JPG</a></div></td>
<td><A ID='IMG_5708.JPG' href='intothenevernever.php?fileId=IMG_5708.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050805/IMG_5708.JPG' ALT='IMG_5708.JPG'><BR>IMG_5708.JPG<br>56.82 KB</a><div class='inv'><br><a href='./images/20050805/IMG_5708.JPG' ALT='IMG_5708.JPG'>IMG_5708.JPG</a></div></td>
<td><A ID='IMG_5709.JPG' href='intothenevernever.php?fileId=IMG_5709.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050805/IMG_5709.JPG' ALT='IMG_5709.JPG'><BR>IMG_5709.JPG<br>65.09 KB</a><div class='inv'><br><a href='./images/20050805/IMG_5709.JPG' ALT='IMG_5709.JPG'>IMG_5709.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5710.JPG' href='intothenevernever.php?fileId=IMG_5710.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050805/IMG_5710.JPG' ALT='IMG_5710.JPG'><BR>IMG_5710.JPG<br>56.8 KB</a><div class='inv'><br><a href='./images/20050805/IMG_5710.JPG' ALT='IMG_5710.JPG'>IMG_5710.JPG</a></div></td>
<td><A ID='IMG_5714.JPG' href='intothenevernever.php?fileId=IMG_5714.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050805/IMG_5714.JPG' ALT='IMG_5714.JPG'><BR>IMG_5714.JPG<br>55.58 KB</a><div class='inv'><br><a href='./images/20050805/IMG_5714.JPG' ALT='IMG_5714.JPG'>IMG_5714.JPG</a></div></td>
<td><A ID='IMG_5720.JPG' href='intothenevernever.php?fileId=IMG_5720.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050805/IMG_5720.JPG' ALT='IMG_5720.JPG'><BR>IMG_5720.JPG<br>120.88 KB</a><div class='inv'><br><a href='./images/20050805/IMG_5720.JPG' ALT='IMG_5720.JPG'>IMG_5720.JPG</a></div></td>
<td><A ID='IMG_5723.JPG' href='intothenevernever.php?fileId=IMG_5723.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050805/IMG_5723.JPG' ALT='IMG_5723.JPG'><BR>IMG_5723.JPG<br>142.19 KB</a><div class='inv'><br><a href='./images/20050805/IMG_5723.JPG' ALT='IMG_5723.JPG'>IMG_5723.JPG</a></div></td>
<td><A ID='IMG_5726.JPG' href='intothenevernever.php?fileId=IMG_5726.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050805/IMG_5726.JPG' ALT='IMG_5726.JPG'><BR>IMG_5726.JPG<br>62.25 KB</a><div class='inv'><br><a href='./images/20050805/IMG_5726.JPG' ALT='IMG_5726.JPG'>IMG_5726.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5727.JPG' href='intothenevernever.php?fileId=IMG_5727.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050805/IMG_5727.JPG' ALT='IMG_5727.JPG'><BR>IMG_5727.JPG<br>52.41 KB</a><div class='inv'><br><a href='./images/20050805/IMG_5727.JPG' ALT='IMG_5727.JPG'>IMG_5727.JPG</a></div></td>
<td><A ID='IMG_5728.JPG' href='intothenevernever.php?fileId=IMG_5728.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050805/IMG_5728.JPG' ALT='IMG_5728.JPG'><BR>IMG_5728.JPG<br>58.68 KB</a><div class='inv'><br><a href='./images/20050805/IMG_5728.JPG' ALT='IMG_5728.JPG'>IMG_5728.JPG</a></div></td>
<td><A ID='IMG_5730.JPG' href='intothenevernever.php?fileId=IMG_5730.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050805/IMG_5730.JPG' ALT='IMG_5730.JPG'><BR>IMG_5730.JPG<br>56.9 KB</a><div class='inv'><br><a href='./images/20050805/IMG_5730.JPG' ALT='IMG_5730.JPG'>IMG_5730.JPG</a></div></td>
<td><A ID='IMG_5732.JPG' href='intothenevernever.php?fileId=IMG_5732.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050805/IMG_5732.JPG' ALT='IMG_5732.JPG'><BR>IMG_5732.JPG<br>65.41 KB</a><div class='inv'><br><a href='./images/20050805/IMG_5732.JPG' ALT='IMG_5732.JPG'>IMG_5732.JPG</a></div></td>
<td><A ID='IMG_5735.JPG' href='intothenevernever.php?fileId=IMG_5735.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050805/IMG_5735.JPG' ALT='IMG_5735.JPG'><BR>IMG_5735.JPG<br>39.73 KB</a><div class='inv'><br><a href='./images/20050805/IMG_5735.JPG' ALT='IMG_5735.JPG'>IMG_5735.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5737.JPG' href='intothenevernever.php?fileId=IMG_5737.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050805/IMG_5737.JPG' ALT='IMG_5737.JPG'><BR>IMG_5737.JPG<br>59.05 KB</a><div class='inv'><br><a href='./images/20050805/IMG_5737.JPG' ALT='IMG_5737.JPG'>IMG_5737.JPG</a></div></td>
<td><A ID='IMG_5740.JPG' href='intothenevernever.php?fileId=IMG_5740.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050805/IMG_5740.JPG' ALT='IMG_5740.JPG'><BR>IMG_5740.JPG<br>48.34 KB</a><div class='inv'><br><a href='./images/20050805/IMG_5740.JPG' ALT='IMG_5740.JPG'>IMG_5740.JPG</a></div></td>
<td><A ID='IMG_5742.JPG' href='intothenevernever.php?fileId=IMG_5742.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050805/IMG_5742.JPG' ALT='IMG_5742.JPG'><BR>IMG_5742.JPG<br>51.35 KB</a><div class='inv'><br><a href='./images/20050805/IMG_5742.JPG' ALT='IMG_5742.JPG'>IMG_5742.JPG</a></div></td>
<td><A ID='IMG_5745.JPG' href='intothenevernever.php?fileId=IMG_5745.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050805/IMG_5745.JPG' ALT='IMG_5745.JPG'><BR>IMG_5745.JPG<br>49.98 KB</a><div class='inv'><br><a href='./images/20050805/IMG_5745.JPG' ALT='IMG_5745.JPG'>IMG_5745.JPG</a></div></td>
<td><A ID='IMG_5747.JPG' href='intothenevernever.php?fileId=IMG_5747.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050805/IMG_5747.JPG' ALT='IMG_5747.JPG'><BR>IMG_5747.JPG<br>41.87 KB</a><div class='inv'><br><a href='./images/20050805/IMG_5747.JPG' ALT='IMG_5747.JPG'>IMG_5747.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5750.JPG' href='intothenevernever.php?fileId=IMG_5750.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050805/IMG_5750.JPG' ALT='IMG_5750.JPG'><BR>IMG_5750.JPG<br>93.69 KB</a><div class='inv'><br><a href='./images/20050805/IMG_5750.JPG' ALT='IMG_5750.JPG'>IMG_5750.JPG</a></div></td>
<td><A ID='IMG_5752.JPG' href='intothenevernever.php?fileId=IMG_5752.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050805/IMG_5752.JPG' ALT='IMG_5752.JPG'><BR>IMG_5752.JPG<br>75.05 KB</a><div class='inv'><br><a href='./images/20050805/IMG_5752.JPG' ALT='IMG_5752.JPG'>IMG_5752.JPG</a></div></td>
<td><A ID='IMG_5753.JPG' href='intothenevernever.php?fileId=IMG_5753.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050805/IMG_5753.JPG' ALT='IMG_5753.JPG'><BR>IMG_5753.JPG<br>66.87 KB</a><div class='inv'><br><a href='./images/20050805/IMG_5753.JPG' ALT='IMG_5753.JPG'>IMG_5753.JPG</a></div></td>
<td><A ID='IMG_5758.JPG' href='intothenevernever.php?fileId=IMG_5758.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050805/IMG_5758.JPG' ALT='IMG_5758.JPG'><BR>IMG_5758.JPG<br>77.64 KB</a><div class='inv'><br><a href='./images/20050805/IMG_5758.JPG' ALT='IMG_5758.JPG'>IMG_5758.JPG</a></div></td>
<td><A ID='IMG_5760.JPG' href='intothenevernever.php?fileId=IMG_5760.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050805/IMG_5760.JPG' ALT='IMG_5760.JPG'><BR>IMG_5760.JPG<br>104.8 KB</a><div class='inv'><br><a href='./images/20050805/IMG_5760.JPG' ALT='IMG_5760.JPG'>IMG_5760.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5765.JPG' href='intothenevernever.php?fileId=IMG_5765.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050805/IMG_5765.JPG' ALT='IMG_5765.JPG'><BR>IMG_5765.JPG<br>74.46 KB</a><div class='inv'><br><a href='./images/20050805/IMG_5765.JPG' ALT='IMG_5765.JPG'>IMG_5765.JPG</a></div></td>
<td><A ID='IMG_5772.JPG' href='intothenevernever.php?fileId=IMG_5772.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050805/IMG_5772.JPG' ALT='IMG_5772.JPG'><BR>IMG_5772.JPG<br>78.25 KB</a><div class='inv'><br><a href='./images/20050805/IMG_5772.JPG' ALT='IMG_5772.JPG'>IMG_5772.JPG</a></div></td>
<td><A ID='IMG_5777.JPG' href='intothenevernever.php?fileId=IMG_5777.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050805/IMG_5777.JPG' ALT='IMG_5777.JPG'><BR>IMG_5777.JPG<br>105.23 KB</a><div class='inv'><br><a href='./images/20050805/IMG_5777.JPG' ALT='IMG_5777.JPG'>IMG_5777.JPG</a></div></td>
<td><A ID='IMG_5778.JPG' href='intothenevernever.php?fileId=IMG_5778.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050805/IMG_5778.JPG' ALT='IMG_5778.JPG'><BR>IMG_5778.JPG<br>80.1 KB</a><div class='inv'><br><a href='./images/20050805/IMG_5778.JPG' ALT='IMG_5778.JPG'>IMG_5778.JPG</a></div></td>
<td><A ID='IMG_5781.JPG' href='intothenevernever.php?fileId=IMG_5781.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050805/IMG_5781.JPG' ALT='IMG_5781.JPG'><BR>IMG_5781.JPG<br>57.01 KB</a><div class='inv'><br><a href='./images/20050805/IMG_5781.JPG' ALT='IMG_5781.JPG'>IMG_5781.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5782.JPG' href='intothenevernever.php?fileId=IMG_5782.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050805/IMG_5782.JPG' ALT='IMG_5782.JPG'><BR>IMG_5782.JPG<br>69.8 KB</a><div class='inv'><br><a href='./images/20050805/IMG_5782.JPG' ALT='IMG_5782.JPG'>IMG_5782.JPG</a></div></td>
<td><A ID='IMG_5785.JPG' href='intothenevernever.php?fileId=IMG_5785.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050805/IMG_5785.JPG' ALT='IMG_5785.JPG'><BR>IMG_5785.JPG<br>55.08 KB</a><div class='inv'><br><a href='./images/20050805/IMG_5785.JPG' ALT='IMG_5785.JPG'>IMG_5785.JPG</a></div></td>
<td><A ID='IMG_5788.JPG' href='intothenevernever.php?fileId=IMG_5788.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050805/IMG_5788.JPG' ALT='IMG_5788.JPG'><BR>IMG_5788.JPG<br>71.08 KB</a><div class='inv'><br><a href='./images/20050805/IMG_5788.JPG' ALT='IMG_5788.JPG'>IMG_5788.JPG</a></div></td>
<td><A ID='IMG_5789.JPG' href='intothenevernever.php?fileId=IMG_5789.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050805/IMG_5789.JPG' ALT='IMG_5789.JPG'><BR>IMG_5789.JPG<br>63.25 KB</a><div class='inv'><br><a href='./images/20050805/IMG_5789.JPG' ALT='IMG_5789.JPG'>IMG_5789.JPG</a></div></td>
<td><A ID='IMG_5792.JPG' href='intothenevernever.php?fileId=IMG_5792.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050805/IMG_5792.JPG' ALT='IMG_5792.JPG'><BR>IMG_5792.JPG<br>51.48 KB</a><div class='inv'><br><a href='./images/20050805/IMG_5792.JPG' ALT='IMG_5792.JPG'>IMG_5792.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5794.JPG' href='intothenevernever.php?fileId=IMG_5794.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050805/IMG_5794.JPG' ALT='IMG_5794.JPG'><BR>IMG_5794.JPG<br>49.07 KB</a><div class='inv'><br><a href='./images/20050805/IMG_5794.JPG' ALT='IMG_5794.JPG'>IMG_5794.JPG</a></div></td>
<td><A ID='IMG_5796.JPG' href='intothenevernever.php?fileId=IMG_5796.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050805/IMG_5796.JPG' ALT='IMG_5796.JPG'><BR>IMG_5796.JPG<br>75.88 KB</a><div class='inv'><br><a href='./images/20050805/IMG_5796.JPG' ALT='IMG_5796.JPG'>IMG_5796.JPG</a></div></td>
<td><A ID='IMG_5814.JPG' href='intothenevernever.php?fileId=IMG_5814.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050805/IMG_5814.JPG' ALT='IMG_5814.JPG'><BR>IMG_5814.JPG<br>33.16 KB</a><div class='inv'><br><a href='./images/20050805/IMG_5814.JPG' ALT='IMG_5814.JPG'>IMG_5814.JPG</a></div></td>
<td><A ID='IMG_5823.JPG' href='intothenevernever.php?fileId=IMG_5823.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050805/IMG_5823.JPG' ALT='IMG_5823.JPG'><BR>IMG_5823.JPG<br>42.79 KB</a><div class='inv'><br><a href='./images/20050805/IMG_5823.JPG' ALT='IMG_5823.JPG'>IMG_5823.JPG</a></div></td>
<td><A ID='IMG_5828.JPG' href='intothenevernever.php?fileId=IMG_5828.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050805/IMG_5828.JPG' ALT='IMG_5828.JPG'><BR>IMG_5828.JPG<br>59.74 KB</a><div class='inv'><br><a href='./images/20050805/IMG_5828.JPG' ALT='IMG_5828.JPG'>IMG_5828.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5830.JPG' href='intothenevernever.php?fileId=IMG_5830.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050805/IMG_5830.JPG' ALT='IMG_5830.JPG'><BR>IMG_5830.JPG<br>52.29 KB</a><div class='inv'><br><a href='./images/20050805/IMG_5830.JPG' ALT='IMG_5830.JPG'>IMG_5830.JPG</a></div></td>
<td><A ID='IMG_5832.JPG' href='intothenevernever.php?fileId=IMG_5832.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050805/IMG_5832.JPG' ALT='IMG_5832.JPG'><BR>IMG_5832.JPG<br>55.95 KB</a><div class='inv'><br><a href='./images/20050805/IMG_5832.JPG' ALT='IMG_5832.JPG'>IMG_5832.JPG</a></div></td>
<td><A ID='IMG_5839.JPG' href='intothenevernever.php?fileId=IMG_5839.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050805/IMG_5839.JPG' ALT='IMG_5839.JPG'><BR>IMG_5839.JPG<br>60.14 KB</a><div class='inv'><br><a href='./images/20050805/IMG_5839.JPG' ALT='IMG_5839.JPG'>IMG_5839.JPG</a></div></td>
<td><A ID='IMG_5840.JPG' href='intothenevernever.php?fileId=IMG_5840.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050805/IMG_5840.JPG' ALT='IMG_5840.JPG'><BR>IMG_5840.JPG<br>42.12 KB</a><div class='inv'><br><a href='./images/20050805/IMG_5840.JPG' ALT='IMG_5840.JPG'>IMG_5840.JPG</a></div></td>
<td><A ID='IMG_5842.JPG' href='intothenevernever.php?fileId=IMG_5842.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050805/IMG_5842.JPG' ALT='IMG_5842.JPG'><BR>IMG_5842.JPG<br>28.73 KB</a><div class='inv'><br><a href='./images/20050805/IMG_5842.JPG' ALT='IMG_5842.JPG'>IMG_5842.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5860.JPG' href='intothenevernever.php?fileId=IMG_5860.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050805/IMG_5860.JPG' ALT='IMG_5860.JPG'><BR>IMG_5860.JPG<br>61.7 KB</a><div class='inv'><br><a href='./images/20050805/IMG_5860.JPG' ALT='IMG_5860.JPG'>IMG_5860.JPG</a></div></td>
<td><A ID='IMG_5861.JPG' href='intothenevernever.php?fileId=IMG_5861.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050805/IMG_5861.JPG' ALT='IMG_5861.JPG'><BR>IMG_5861.JPG<br>59.47 KB</a><div class='inv'><br><a href='./images/20050805/IMG_5861.JPG' ALT='IMG_5861.JPG'>IMG_5861.JPG</a></div></td>
<td><A ID='IMG_5863.JPG' href='intothenevernever.php?fileId=IMG_5863.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050805/IMG_5863.JPG' ALT='IMG_5863.JPG'><BR>IMG_5863.JPG<br>53.82 KB</a><div class='inv'><br><a href='./images/20050805/IMG_5863.JPG' ALT='IMG_5863.JPG'>IMG_5863.JPG</a></div></td>
<td><A ID='IMG_5864.JPG' href='intothenevernever.php?fileId=IMG_5864.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050805/IMG_5864.JPG' ALT='IMG_5864.JPG'><BR>IMG_5864.JPG<br>60.6 KB</a><div class='inv'><br><a href='./images/20050805/IMG_5864.JPG' ALT='IMG_5864.JPG'>IMG_5864.JPG</a></div></td>
<td><A ID='IMG_5870.JPG' href='intothenevernever.php?fileId=IMG_5870.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050805/IMG_5870.JPG' ALT='IMG_5870.JPG'><BR>IMG_5870.JPG<br>141.02 KB</a><div class='inv'><br><a href='./images/20050805/IMG_5870.JPG' ALT='IMG_5870.JPG'>IMG_5870.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5872.JPG' href='intothenevernever.php?fileId=IMG_5872.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050805/IMG_5872.JPG' ALT='IMG_5872.JPG'><BR>IMG_5872.JPG<br>150.55 KB</a><div class='inv'><br><a href='./images/20050805/IMG_5872.JPG' ALT='IMG_5872.JPG'>IMG_5872.JPG</a></div></td>
<td><A ID='IMG_5873.JPG' href='intothenevernever.php?fileId=IMG_5873.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050805/IMG_5873.JPG' ALT='IMG_5873.JPG'><BR>IMG_5873.JPG<br>66.54 KB</a><div class='inv'><br><a href='./images/20050805/IMG_5873.JPG' ALT='IMG_5873.JPG'>IMG_5873.JPG</a></div></td>
<td><A ID='IMG_5875.JPG' href='intothenevernever.php?fileId=IMG_5875.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050805/IMG_5875.JPG' ALT='IMG_5875.JPG'><BR>IMG_5875.JPG<br>66.81 KB</a><div class='inv'><br><a href='./images/20050805/IMG_5875.JPG' ALT='IMG_5875.JPG'>IMG_5875.JPG</a></div></td>
<td><A ID='IMG_5877.JPG' href='intothenevernever.php?fileId=IMG_5877.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050805/IMG_5877.JPG' ALT='IMG_5877.JPG'><BR>IMG_5877.JPG<br>94.93 KB</a><div class='inv'><br><a href='./images/20050805/IMG_5877.JPG' ALT='IMG_5877.JPG'>IMG_5877.JPG</a></div></td>
<td><A ID='IMG_5879.JPG' href='intothenevernever.php?fileId=IMG_5879.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050805/IMG_5879.JPG' ALT='IMG_5879.JPG'><BR>IMG_5879.JPG<br>109.55 KB</a><div class='inv'><br><a href='./images/20050805/IMG_5879.JPG' ALT='IMG_5879.JPG'>IMG_5879.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5889.JPG' href='intothenevernever.php?fileId=IMG_5889.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050805/IMG_5889.JPG' ALT='IMG_5889.JPG'><BR>IMG_5889.JPG<br>100.43 KB</a><div class='inv'><br><a href='./images/20050805/IMG_5889.JPG' ALT='IMG_5889.JPG'>IMG_5889.JPG</a></div></td>
<td><A ID='IMG_5898.JPG' href='intothenevernever.php?fileId=IMG_5898.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050805/IMG_5898.JPG' ALT='IMG_5898.JPG'><BR>IMG_5898.JPG<br>60.69 KB</a><div class='inv'><br><a href='./images/20050805/IMG_5898.JPG' ALT='IMG_5898.JPG'>IMG_5898.JPG</a></div></td>
<td><A ID='IMG_5899.JPG' href='intothenevernever.php?fileId=IMG_5899.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050805/IMG_5899.JPG' ALT='IMG_5899.JPG'><BR>IMG_5899.JPG<br>59.96 KB</a><div class='inv'><br><a href='./images/20050805/IMG_5899.JPG' ALT='IMG_5899.JPG'>IMG_5899.JPG</a></div></td>
<td><A ID='IMG_5901.JPG' href='intothenevernever.php?fileId=IMG_5901.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050805/IMG_5901.JPG' ALT='IMG_5901.JPG'><BR>IMG_5901.JPG<br>40.6 KB</a><div class='inv'><br><a href='./images/20050805/IMG_5901.JPG' ALT='IMG_5901.JPG'>IMG_5901.JPG</a></div></td>
<td><A ID='IMG_5905.JPG' href='intothenevernever.php?fileId=IMG_5905.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050805/IMG_5905.JPG' ALT='IMG_5905.JPG'><BR>IMG_5905.JPG<br>101.49 KB</a><div class='inv'><br><a href='./images/20050805/IMG_5905.JPG' ALT='IMG_5905.JPG'>IMG_5905.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5907.JPG' href='intothenevernever.php?fileId=IMG_5907.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050805/IMG_5907.JPG' ALT='IMG_5907.JPG'><BR>IMG_5907.JPG<br>102.31 KB</a><div class='inv'><br><a href='./images/20050805/IMG_5907.JPG' ALT='IMG_5907.JPG'>IMG_5907.JPG</a></div></td>
<td><A ID='IMG_5908.JPG' href='intothenevernever.php?fileId=IMG_5908.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050805/IMG_5908.JPG' ALT='IMG_5908.JPG'><BR>IMG_5908.JPG<br>66.41 KB</a><div class='inv'><br><a href='./images/20050805/IMG_5908.JPG' ALT='IMG_5908.JPG'>IMG_5908.JPG</a></div></td>
<td><A ID='IMG_5913.JPG' href='intothenevernever.php?fileId=IMG_5913.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050805/IMG_5913.JPG' ALT='IMG_5913.JPG'><BR>IMG_5913.JPG<br>80.52 KB</a><div class='inv'><br><a href='./images/20050805/IMG_5913.JPG' ALT='IMG_5913.JPG'>IMG_5913.JPG</a></div></td>
<td><A ID='IMG_5916.JPG' href='intothenevernever.php?fileId=IMG_5916.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050805/IMG_5916.JPG' ALT='IMG_5916.JPG'><BR>IMG_5916.JPG<br>73.06 KB</a><div class='inv'><br><a href='./images/20050805/IMG_5916.JPG' ALT='IMG_5916.JPG'>IMG_5916.JPG</a></div></td>
<td><A ID='IMG_5922.JPG' href='intothenevernever.php?fileId=IMG_5922.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050805/IMG_5922.JPG' ALT='IMG_5922.JPG'><BR>IMG_5922.JPG<br>72.7 KB</a><div class='inv'><br><a href='./images/20050805/IMG_5922.JPG' ALT='IMG_5922.JPG'>IMG_5922.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5923.JPG' href='intothenevernever.php?fileId=IMG_5923.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050805/IMG_5923.JPG' ALT='IMG_5923.JPG'><BR>IMG_5923.JPG<br>111.64 KB</a><div class='inv'><br><a href='./images/20050805/IMG_5923.JPG' ALT='IMG_5923.JPG'>IMG_5923.JPG</a></div></td>
<td><A ID='IMG_5925.JPG' href='intothenevernever.php?fileId=IMG_5925.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050805/IMG_5925.JPG' ALT='IMG_5925.JPG'><BR>IMG_5925.JPG<br>102.65 KB</a><div class='inv'><br><a href='./images/20050805/IMG_5925.JPG' ALT='IMG_5925.JPG'>IMG_5925.JPG</a></div></td>
<td><A ID='IMG_5929.JPG' href='intothenevernever.php?fileId=IMG_5929.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050805/IMG_5929.JPG' ALT='IMG_5929.JPG'><BR>IMG_5929.JPG<br>86.68 KB</a><div class='inv'><br><a href='./images/20050805/IMG_5929.JPG' ALT='IMG_5929.JPG'>IMG_5929.JPG</a></div></td>
<td><A ID='IMG_5931.JPG' href='intothenevernever.php?fileId=IMG_5931.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050805/IMG_5931.JPG' ALT='IMG_5931.JPG'><BR>IMG_5931.JPG<br>135.39 KB</a><div class='inv'><br><a href='./images/20050805/IMG_5931.JPG' ALT='IMG_5931.JPG'>IMG_5931.JPG</a></div></td>
<td><A ID='IMG_5934.JPG' href='intothenevernever.php?fileId=IMG_5934.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050805/IMG_5934.JPG' ALT='IMG_5934.JPG'><BR>IMG_5934.JPG<br>109.4 KB</a><div class='inv'><br><a href='./images/20050805/IMG_5934.JPG' ALT='IMG_5934.JPG'>IMG_5934.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5939.JPG' href='intothenevernever.php?fileId=IMG_5939.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050805/IMG_5939.JPG' ALT='IMG_5939.JPG'><BR>IMG_5939.JPG<br>48.56 KB</a><div class='inv'><br><a href='./images/20050805/IMG_5939.JPG' ALT='IMG_5939.JPG'>IMG_5939.JPG</a></div></td>
<td><A ID='IMG_5946.JPG' href='intothenevernever.php?fileId=IMG_5946.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050805/IMG_5946.JPG' ALT='IMG_5946.JPG'><BR>IMG_5946.JPG<br>71.12 KB</a><div class='inv'><br><a href='./images/20050805/IMG_5946.JPG' ALT='IMG_5946.JPG'>IMG_5946.JPG</a></div></td>
<td><A ID='IMG_5948.JPG' href='intothenevernever.php?fileId=IMG_5948.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050805/IMG_5948.JPG' ALT='IMG_5948.JPG'><BR>IMG_5948.JPG<br>33.63 KB</a><div class='inv'><br><a href='./images/20050805/IMG_5948.JPG' ALT='IMG_5948.JPG'>IMG_5948.JPG</a></div></td>
<td><A ID='IMG_5955.JPG' href='intothenevernever.php?fileId=IMG_5955.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050805/IMG_5955.JPG' ALT='IMG_5955.JPG'><BR>IMG_5955.JPG<br>108.16 KB</a><div class='inv'><br><a href='./images/20050805/IMG_5955.JPG' ALT='IMG_5955.JPG'>IMG_5955.JPG</a></div></td>
</tr>
</table>	</div>
</div>
</body>
</html>