<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - July 2006 - Q&A letters</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="Q&A letters">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="Q&A letters" href='masterit200601.php'>January 2006</a></li>
<li><a title="Q&A letters" href='masterit200602.php'>February 2006</a></li>
<li><a title="Q&A letters" href='masterit200603.php'>March 2006</a></li>
<li><a title="Q&A letters" href='masterit200604.php'>April 2006</a></li>
<li><a title="Q&A letters" href='masterit200605.php'>May 2006</a></li>
<li><a title="Q&A letters" href='masterit200606.php'>June 2006</a></li>
<li><div class='activemenu'>July 2006</div></li>
<li><a title="Q&A letters" href='masterit200608.php'>August 2006</a></li>
<li><a title="Q&A letters" href='masterit200609.php'>September 2006</a></li>
<li><a title="Q&A letters" href='masterit200610.php'>October 2006</a></li>
<li><a title="Q&A letters" href='masterit200611.php'>November 2006</a></li>
<li><a title="Q&A letters" href='masterit200612.php'>December 2006</a></li>
<li> </li><br><li>Or go back to:</li><li><a title='Q&A/MasterIT letters from 2006' href="masterit2006.php">2006 archive</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>July 2006</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Mark's writing' href="written.php">Professional Writing</a> > <a title='My weekly Q&A column in The Australian' href="masterIT.php">MasterIT</a> > <a title='Q&A/MasterIT letters from 2006' href="masterit2006.php">2006 archive</a> > <a title='Q&A letters' href="masterit200607.php">July 2006</a>
<br><br>		<br>
<h2>4/7/06</h2><br>
<b>My father in-law is doing the grey nomad thing in his bertha-sized 'bago, and wants Internet access. One option is to attach a satellite dish, but would his 'bago need to be even more bertha? Who provides this service, and how many arms and legs might it cost, or would you recommend some other option?</b><br>
<br>
Satellite dishes are a popular way of receiving TV on the road, but the Internet side of things makes for quite a different animal.<br>
<br>
Most commonly, satellite connections use a phone line for uploads, which means it isn't of much use when travelling. Two way satellite is available, but it's a fixed service that needs professional installation, so it's not a travel option (and even if it was, it will also set you back several limbs).<br>
<br>
The best option is to look at a CDMA wireless solution. Telstra, being the lumbering Hydra that it is, offers two versions of this; one through Bigpond and one through Telstra Mobile. Both cost the same and use the same network, but use different (albeit equivalent) hardware.<br>
<br>
The Bigpond version comes with email addresses and web hosting space, whereas the Mobile version does not (it just provides the connection). The mobile version, however, will function as a CDMA mobile phone, capable of making and receiving calls and text messages, but only when it's plugged into a host computer. <br>
<br>
Links for the two products are:<br>
<br>
http://www.telstra.com.au/mobile/business/products/mobilebroadband.htm<br>
http://my.bigpond.com/internetplans/broadband/wireless/mobile_plans/default.jsp<br>
<br>
CDMA coverage is quite good (most populated areas are covered), and whilst the raw speed of the connection is nothing to write home about in rural areas (it's about twice modem speed), it does work well.<br>
<br>
If you're in the right coverage area, you can also connect in a much faster mode (called EV-DO), which will give you broadband-like download speeds. Currently these fast coverage areas are only located in capital cities and a few other regional centres.<br>
<br>
Telstra, of course, have a complete monopoly here, and so the value for money of the service isn't amazing (even if the pricing is nowhere near as scary as it is for satellite).<br>
<br>
For example, Telstra's policy of charging in minimum blocks of 5 minutes is quite irritating, and it also makes it quite hard to accurately keep track of how much time you've used.<br>
<br>
Nonetheless, in a massive country like Oz, CDMA is the best solution.<br>
<br>
<br>
<h2>25/7/06</h2><br>
<b>From time to time I come across the advice to backup my hard drive. I have Windows XP and one link advises me to go to System Tools and to use the backup function, but I don't seem to have this. What method do you recommend for backing up my hard drive? (I have a Dell Dimension 8300).</b><br>
<br>
XP Pro comes with Microsoft backup installed, but XP Home doesn't. It is available though - see http://tinyurl.com/3vvzg.<br>
<br>
Regardless of availability, Microsoft must love supporting other businesses, because Windows' backup programs have always stunk, particularly because they've never supported optical removable media or data compression.<br>
<br>
After trying many third party backup programs over the years, I finally settled on a thing called Acronis Trueimage. It's not free, but it is excellent (both in function and reliability).<br>
<br>
You can find it at <a href="http://www.acronis.com" target="_blank">http://www.acronis.com</a>. The home version will set you back $US50, but there is also a trial version available so you can give it a go.<br>
<br>
Another, very similar product that many people use is Norton Ghost. It has the almost the same feature set as Acronis, but it doesn't quite have the same reliability. In fact, it's just another rebadged product which Symantec/Norton have bought; originally it was called Powerquest v2i backup.<br>
<br>
Symantec do this all the time, and rarely actually write their own software, which is partly why they have so many problems. If only their software engineers were as good as their marketing department, their reputation amongst IT support staff might be better.<br>
<br>
Anyway, some key features you should look for in any good backup software include:<br>
<br>
- the ability to backup entire disks, or just specified files and folders<br>
- being able to run in the background automatically, to a schedule if you like<br>
- support for removable media, as well as file-based network backups<br>
- support for data compression<br>
<br>
Perhaps most importantly, a good set of good disaster recovery options is also essential - if you can't restore your system there's no point in backing it up.<br>
<br>
<br>
<b>Hi, I run identical windows (2000 pro) at work and at home, at work windows remembers user names and passwords from the first letter punched in, at home it does not. Our IT bloke does not know how to switch the feature on, can you help?</b><br>
<br>
It's hidden away in the Internet Explorer options. Go to tools->options in IE, then select the Content tab, then click the Autocomplete button, and tick the various boxes.<br>
<br>
<i><p>Did the information on this page help you? Entertain you? Bore you? <a href="contact.php?subject=MasterIT">Drop me a line</a>.</p>

<p>If you're feeling particularly generous, you can even <a href="buypics.php">click here to send me some dot-com riches</a>. Think of it as online busking.</i></p>
	</div>
</div>
</body>
</html>