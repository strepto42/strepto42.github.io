<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - September 2004 - Q&A letters</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="Q&A letters">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="Q&A letters" href='masterit200401.php'>January 2004</a></li>
<li><a title="Q&A letters" href='masterit200402.php'>February 2004</a></li>
<li><a title="Q&A letters" href='masterit200403.php'>March 2004</a></li>
<li><a title="Q&A letters" href='masterit200404.php'>April 2004</a></li>
<li><a title="Q&A letters" href='masterit200405.php'>May 2004</a></li>
<li><a title="Q&A letters" href='masterit200406.php'>June 2004</a></li>
<li><a title="Q&A letters" href='masterit200407.php'>July 2004</a></li>
<li><a title="Q&A letters" href='masterit200408.php'>August 2004</a></li>
<li><div class='activemenu'>September 2004</div></li>
<li><a title="Q&A letters" href='masterit200410.php'>October 2004</a></li>
<li><a title="Q&A letters" href='masterit200411.php'>November 2004</a></li>
<li><a title="Q&A letters" href='masterit200412.php'>December 2004</a></li>
<li> </li><br><li>Or go back to:</li><li><a title='Q&A/MasterIT letters from 2004' href="masterit2004.php">2004 archive</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>September 2004</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Mark's writing' href="written.php">Professional Writing</a> > <a title='My weekly Q&A column in The Australian' href="masterIT.php">MasterIT</a> > <a title='Q&A/MasterIT letters from 2004' href="masterit2004.php">2004 archive</a> > <a title='Q&A letters' href="masterit200409.php">September 2004</a>
<br><br>		<br>
<h2>7/9/04</h2><br>
<b>I have recently bought a new PC and transferred all my E-mail (.pst) file over from the old one. The moment I started using this PST-file, I noticed that Outlook took about 30 seconds to bring up my Inbox. There is some HD activity but not much. I have tried to start from scratch - no E-mails at all - with no change, deleted and re-installed MS Office but to no avail; Outlook still takes about 30 seconds to display my Inbox. What could be the cause of this?</b><br>
<br>
There can be a couple of reasons why Outlook is slow to start. Sometimes it is due to corrupt configuration or mail files, but in your case I suspect that it may be MSN Messenger starting up with Outlook XP, causing a delay.<br>
<br>
If you start Outlook and go to Tools->Options->Other, then deselect Enable Messenger the problem should be solved.<br>
<br>
If this doesn't help, some other Outlook troubleshooting tips can be found at www.rk-net.com/Windows9X/Outlook1.htm.<br>
<br>
<br>
<b>Recently I've noticed quite a few download sites have a link to use something called "Bittorrent". When I follow these links all I get is a .torrent file and not the file I am after. Do I need to install something? What is "Bittorrent"?</b><br>
<br>
Bittorrent is a means of distributing files which takes the load off any one central server. It works a little bit like a miniature peer-to-peer network, set up specifically for just one file. When you download a file with Bittorrent, you also simultaneously upload parts of it which you already have received to other people.<br>
<br>
In order to use Bittorrent you need to download a special program. You can get the original at bitconjurer.org/BitTorrent, or a more configurable (but more advanced) client called Bittornado from bittornado.com.<br>
<br>
Torrent files are advantageous in that they can let you download something very quickly (if enough other people are downloading the file), and they take the load off any one server, making it much cheaper for people to host large downloads.<br>
<br>
Of course, this also makes them the preferred distribution method for pirate movies and so on, hosted by wretched hives of scum and villainy. Finding these is left as an exercise to the reader, with a reminder that any resultant beatings by lawyers or starving movie stars will be incurred by said reader, and not by the Master.<br>
<br>
<br>
<h2>14/9/04</h2><br>
<b>Is it possible to define a button & short cut key, so that paste always pastes unformatted text?</b><br>
<br>
It sure is. I think I answered this one last year actually, but it's such a useful one I may put it in again, as I use it all the time. (As Arthur C. Clarke once said: if you can't plagiarise yourself, who can you plagiarise?)<br>
<br>
Making the shortcut to paste plain text in Word 2000 is as simple as creating a keyboard macro (for something like ALT-V) and binding it to the "paste special" function.<br>
<br>
This is as simple as pressing control, alt and the numeric pad "+" key together, selecting "paste special" from the edit menu, pressing ALT-V, and clicking assign.<br>
<br>
<br>
<b>My PC has recently started refusing to shut down. After I have manually switched it off and on, I get Scandisk, and a message appears saying "Scandisk detected an invalid long filename entry on this drive. To fix this problem, run Scandisk for Windows". I press enter and Scandisk completes its check. I can then logon but am still unable to shutdown. I have to go through this process each time.</b><br>
<br>
I think you have two problems here. One is the scandisk long filename thing, and the other is Windows' inability to shut down.<br>
<br>
Dealing with the former, Scandisk is ok, but it doesn't fix everything, and getting your hands on a more comprehensive disk checking program will probably be of benefit.<br>
<br>
I don't have any current recommendations (as I haven't needed a disk utility for a while), but a quick Google should come up with some (hopefully free) options. <br>
<br>
Regarding Windows not shutting down, it just sounds more like a typical case of bit rot, which 95/98/ME are susceptible to.<br>
<br>
At the risk of sounding like the Microsoft help line, fixing it may just be as simple as reinstalling Windows (which is annoying, but if you do an upgrade install rather than a complete fresh install you shouldn't lose any important settings).<br>
<br>
Unfortunately the whole 95/98/ME line of Windows is inherently unstable and goes bad over time. Windows 2000 and XP are vastly superior in this regard, but of course they require more RAM, disk space, and general computeriness, and there's the cost of upgrading the OS too.<br>
<br>
<br>
<h2>21/9/04</h2><br>
<b>Dear Master, I'm pretty sure my boss has been reading my email. I was wondering how hard it is to set up some kind of encryption. I've heard of PGP - is it easy to set up with Outlook?</b><br>
<br>
Before we discuss how to do it, it's a good idea to pause for a moment to point out that, if you're talking about a work email account, your boss almost certainly has the right to read your mail. Corporate accounts are just that - corporate - and they're owned by the corporation, not by you.<br>
<br>
The standard rule of thumb is that you don't write anything in a work email that you don't want your boss (or the strange, hairy IT admin guy two floors down) to read.<br>
<br>
The easiest way to get around this whole issue of course, is to get a private email address. Even a Hotmail account will do.<br>
<br>
That said, if your company doesn't allow webmail, or you're the office malcontent and you'd like to make some sort of mutinous statement (especially given that last Sunday was Talk Like a Pirate Day), encrypting your email is pretty easy.<br>
<br>
PGP (which stands for Pretty Good Privacy) and S/MIME are the two most common ways of securing mail. Both have advantages; but for the layperson S/MIME is probably easier to set up.<br>
<br>
There is a discussion on the merits of both, as well as a good introduction to the topic of email security at tinyurl.com/6m5ro.<br>
<br>
The article also has example instructions for obtaining a security certificate, and getting encryption set up on a Mac. Microsoft have fairly detailed instructions for Outlook at support.microsoft.com/?kbid=286159, and if you'd prefer to roll your own PGP solution, there is a good list of Win32 PGP plugins at tinyurl.com/rqfa.<br>
<br>
Encrypting everything will certainly prevent your boss reading mail that's been bcc-ed automatically, but at the end of the day, no amount of encryption is going to stop someone logging on to your terminal, firing up Outlook and reading your mail in situ. <br>
<br>
There are other options on corporate networks too - mail administrators can generally browse anyone's Outlook folders at will. Sometimes it's best just not to write it down to begin with.<br>
<br>
<br>
<h2>28/9/04</h2><br>
<b>I am using a 486 with Windows 95 connected to an equally archaic modem. 28.8 perhaps or worse. This is fine for my internet needs at the moment but I am hobbled by Macromedia Flash animations used by advertisers. They run extremely slowly and make checking my email excruciating as the animations seem to get priority over me.</b><br>
 <br>
I have unchecked play animations in the advanced internet options, but no joy. Even when I set the animations to low res to speed things up a bit Flash resets to its default of hi res as soon as I click a link. How do I stop Flash animations from playing on my machine, period?<br>
<br>
It was indeed a sad day when advertisers realised they could get around image-based ad-blockers by using Flash instead. Even more enlightened browser developers like the Mozilla lads haven't yet cottoned on to the idea of extending "block images from this server" to "block images and Flash animations from this server". Guys, hello!<br>
<br>
Anyway, uninstalling Flash is an option - however you'll be left with the irritation of being prompted to install it every time you hit a page with Flash content.<br>
<br>
Luckily there are two better options, and combination of both will probably serve you well.<br>
<br>
First off, download a utility dedicated to the job of disabling flash. Many are available (as a quick Google search reveals), one example can be found at www.unhsolutions.net/FPC. Secondly, install an updated hosts file to help block ads at the source. More info and a good example are available at everythingisnt.com/hosts.html.<br>
<br>
<br>
<b>We recently "clean booted" the system, and now the Dial Up window for Ozemail comes up at switch on & refuses to close. We have gone through all the usual things as in "Help" and all we get for the trouble is for the system to freeze more. We ran Norton anti virus and System Works, and also Spy Sweeper. If there is another program competing to cause the problem we are unable to identify it.</b><br>
<br>
Unfortunately you don't say which version of Windows you're using (rule of thumb - oversupplying the Master with information will not get you in trouble), but if it's NT or 2000 you can stop the PC trying to dial up automatically by disabling the "Remote Access AutoDial Manager" service. Don't worry if that sounds hairy, it's quite easy - there are good instructions at tinyurl.com/4495m.<br>
<br>
<i><p>Did the information on this page help you? Entertain you? Bore you? <a href="contact.php?subject=MasterIT">Drop me a line</a>.</p>

<p>If you're feeling particularly generous, you can even <a href="buypics.php">click here to send me some dot-com riches</a>. Think of it as online busking.</i></p>
	</div>
</div>
</body>
</html>