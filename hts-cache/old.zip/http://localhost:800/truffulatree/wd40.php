<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - WD40 - WD40 cans going whoosh and Sparkler Bomb videos</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="WD40 cans going whoosh and Sparkler Bomb videos">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="A page dedicated to the worst Optimus Prime outfits on the net" href='badoptimus.php'>Bad Optimus</a></li>
<li><div class='activemenu'>WD40</div></li>
<li><a title="2weeks.com internet art concept site" href='2weeks.php'>2weeks.com</a></li>
<li><a title="A pong game featuring Rudi Mueller's head by John Hawkins" href='rudipong.php'>Rudipong</a></li>
<li><a title="The Random Domain Name Game" href='rdng.php'>RDNG</a></li>
<li><a title="Various animations for download" href='anims.php'>Animations</a></li>
<li><a title="Arnold Schwarzenegger and Michael Jackson soundboards" href='soundboards.php'>Soundboards</a></li>
<li> </li><br><li>Or go back to:</li><li><a title='Silly things for your amusement' href="silliness.php">Silliness</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>WD40</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Silly things for your amusement' href="silliness.php">Silliness</a> > <a title='WD40 cans going whoosh and Sparkler Bomb videos' href="wd40.php">WD40</a>
<br><br>		
<br>
<p>A couple of years back when I was applying for a new job, some of the upstart geeks at the place managed to find my homepage,
and I had already attained the mantle of "The Pyro" before I even started. The thing is, I think in the end the bosses asked which
of two candidates the guys preferred, and of course they answered "The Pyro guy! Hire him!". So as I'm updating my website,
I feel I should retain this page in order to help my job prospects. If you're a prospective employer, I promise not to set fire
to anything whilst at work.</p>

<p>Anyway without further ado - an image of something going whoosh, and an explantion:</p>

<a href="images/wdx5large.jpg"><img src="images/wd40.jpg" alt="Whooshka! An image of a wd40 can going whoosh" border="0" WIDTH="640" HEIGHT="428"></a>

<p>Way back when I wore the badge of foolish youth (as opposed to the badge labelled "fabulously mature adult" I sport now)
I quite liked things that went whoosh, bang and crump. I even manged to like these things and keep all my fingers (barring a little
mid-digital hair now and then), my testicles, eyes, and indeed, my life; all despite some moments of incredible stupidity that I still
boggle over. So thank you, Universe.</p>

<p>To explain the above image, I first have to thank my good friend Timbo for passing on the sacred knowledge of a couple of
things that fall into the aforementioned "whoosh" category: namely, how to "set off" a can of WD40 (the subject of this page), and
Sparkler Bombs (although it has to be said that we expanded the concept of using a piddling 50 or so sparklers to several thousand).</p>

<p>If you've come here from <a href="http://www.dansdata.com/personal/Bombs.html" target="_blank">Daniel's Sparkler Bomb page</a>
I'm sure you'll know about those - if not feel free to visit it after downloading the animations below.</p>

<p>Anyway the point of this page is to a) provide a historical record of something silly but spectacular that we used to do, and b)
replace the horrid cranky old WD40 page that dated back to my first Frontpage website. Ick.</p>

<p>The basic concept was this:
<ul>
	<li>Buy can(s) of <a href="http://www.wd40.com" target="_blank">WD40</a> (a general purpose aerosol squeak stopper and lock unsticker based largely on kerosene)</li>
	<li>Find deserted place (eg beach - see above, carpark rooftop - see video)</li>
	<li>Confirm absence of people in blue uniforms with big sticks</li>
	<li>Squirt some WD40 into the lid, pour it into the lip around the nozzle</li>
	<li>Remove said nozzle leaving valve exposed</li>
	<li>Light liquid</li>
	<li>Retreat</li>
</ul>
</p>

<p>The burning liquid would eventually melt the valve and the can would jettison its contents skyward, igniting them on the way.</p>

<p>Now, if the idea of setting fire to an aerosol can sounds somewhat Darwinish to you, I agree. The gamble was, I feel, pretty
sure though, given that a) the plastic valve was the weakest point in the can, and b) it never went boom, nor did I ever hear of one doing
so (ok not exactly the most solid logic proof on the planet, but hey, the Universe liked me). Sometimes they wouldn't go
whoosh; they'd just burn away slowly leaking for 20 minutes. But there was never an almightly <!-- <a href="files/wd40/kaboom.wav"> -->kaboom<!-- </a> -->.
Thankfully.</p>

<p>Nowadays this doesn't work anyhow; they changed the valve design years ago, most likely to stop the cans going whoosh in housefires.
So this page is just here as a legacy. Plus, the picture is pretty - in the big version you can see the small jet of liquid just above the
flaming can. There were actually 5 cans lit that night, but it was too windy and only one went off. Incidentally, the flame in the
picture is about 3 metres high. The Gold Coast's residents must love Schoolies Week.</p>

<p>So anyway, regarding booty - apart from clicking on the picture for a bigger version, you can click below for a nice backdrop
I made once based on it, and for a couple of videos featuring a WD40 can going whoosh, as well as several sparkler bombs. <strong>I do recommend the 
Vivaldi one, as the quality is superior, and it has actual audio</strong>. And yes, the links below are annoying redirectors - the traffic
started to mount for poor <a href="http://www.nocturnal-central.com" target="_blank">Shams</a> who is giving me free hosting, so I thought I should burden my ISP instead. :) Enjoy!</p>

<p>P.S. The videos are copyright, noncommercial use is fine though. Contact me with a big cheque if you wanna air them on CNN. I have a DV version of the Vivaldi one.</p>

<p>P.P.S. I won't even put in a paragraph about how you shouldn't set fire to random aerosol cans. If you wanna chuck them in fires
and kill yourself (and others), be my guest. Feel free to send me the snuff flick. Also, please do not bother emailing me to ask for help making bombs, or doing other stupid shit.
I'm well past that now.</p>

<p>P.P.P.S. So, were you entertained? Should an ad appear appropriate to your needs... feel free to investigate. You might want to look around too, before you go. <a href="nerdseyeview.php">Click here</a> to read about my epic trip around Australia. Click <a href="pictures.php">here</a> for various other picture galleries.</p>
<p>If you're feeling particularly generous, you can even click on the button below to send me some dot-com riches. Go on, save yourself from a flaming fireball by giving me the money instead of buying that aerosol for the bonfire.</p>
<a href="buypics.php"><img src="images/paypal_giveusthem.gif" alt="Give me the cashhhhhh!" title="Give me the cashhhhhh!" border="0"></a>

<br><br><table>
Files available for download:<br>
<tr><td><div align='left'><A href='files/wd40/flameseyes1.png'>flameseyes1.png</a></div></td><td><div align='left'>1129.31 KB</div></td><tr>
<tr><td><div align='left'><A href='files/wd40/kaboom.wav'>kaboom.wav</a></div></td><td><div align='left'>52.86 KB</div></td><tr>
<tr><td><div align='left'><A href='files/wd40/SparklerBombMania.rar'>SparklerBombMania.rar</a></div></td><td><div align='left'>3293.02 KB</div></td><tr>
<tr><td><div align='left'><A href='files/wd40/VivaldiPyro.avi'>VivaldiPyro.avi</a></div></td><td><div align='left'>13140 KB</div></td><tr>
<tr><td><div align='left'><A href='files/wd40/VivaldiPyro.rar'>VivaldiPyro.rar</a></div></td><td><div align='left'>12648.18 KB</div></td><tr>
</table>	</div>
</div>
</body>
</html>