<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - 4/11/2005 - A week in Perth</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="A week in Perth">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="Greetings from a Bum" href='greetingsfromabum.php'>29/4/2005</a></li>
<li><a title="Onward" href='onward.php'>2/5/2005</a></li>
<li><a title="It's a tough life (pt 1: Bundaberg, Agnes Water and 1770)" href='itsatoughlife1.php'>17/5/2005</a></li>
<li><a title="It's a tough life (pt 2: Rockhampton, Emu Park and Great Keppel Island)" href='itsatoughlife2.php'>23/5/2005</a></li>
<li><a title="There and Back Again - a Yo-yo's Tale" href='thereandbackagain.php'>18/6/2005</a></li>
<li><a title="Platypi and Grey Nomads" href='platypiandgreynomads.php'>24/6/2005</a></li>
<li><a title="Blowing Bubbles in a Watery Tomb" href='blowingbubbles.php'>1/7/2005</a></li>
<li><a title="Pieces of History" href='piecesofhistory.php'>8/7/2005</a></li>
<li><a title="Walks and Waterfalls" href='walksandwaterfalls.php'>15/7/2005</a></li>
<li><a title="Mission to Tribulation" href='missiontotribulation.php'>22/7/2005</a></li>
<li><a title="Levity, Limestone and Lava" href='levitylimestoneandlava.php'>29/7/2005</a></li>
<li><a title="Into the Never Never" href='intothenevernever.php'>5/8/2005</a></li>
<li><a title="Slowing the pace in Darwin" href='slowingthepaceindarwin.php'>12/8/2005</a></li>
<li><a title="Blistering Barnacles and Leaping Lizards" href='leapinglizards.php'>19/8/2005</a></li>
<li><a title="Kakadu and Litchfield" href='kakadu.php'>26/8/2005</a></li>
<li><a title="Legacies of War" href='legaciesofwar.php'>2/9/2005</a></li>
<li><a title="Go West" href='gowest.php'>10/9/2005</a></li>
<li><a title="Things from Above" href='thingsfromabove.php'>16/9/2005</a></li>
<li><a title="The West Coast" href='thewestcoast.php'>23/9/2005</a></li>
<li><a title="Reefs and Red Dust" href='reefsandreddust.php'>30/9/2005</a></li>
<li><a title="The Pilbara" href='pilbara.php'>7/10/2005</a></li>
<li><a title="Paradise with a Headwind" href='paradisewithaheadwind.php'>14/10/2005</a></li>
<li><a title="Down the Coral Coast" href='downthecoralcoast.php'>21/10/2005</a></li>
<li><a title="Pinnacles and Pinnipeds" href='pinnaclesandpinnipeds.php'>28/10/2005</a></li>
<li><div class='activemenu'>4/11/2005</div></li>
<li><a title="The Southwest (from Above and Below)" href='thesouthwest.php'>11/11/2005</a></li>
<li><a title="More Heights and Depths" href='moreheightsanddepths.php'>18/11/2005</a></li>
<li><a title="Across the Nullarbor (and a bit beyond)" href='nullarbor.php'>25/11/2005</a></li>
<li><a title="Double Whammy" href='doublewhammy.php'>9/12/2005</a></li>
<li><a title="Two Cities" href='twocities.php'>19/12/2005</a></li>
<li><a title="Tassie - Part 1" href='tassie1.php'>1/1/2006</a></li>
<li><a title="Tassie - Part 2" href='tassie2.php'>7/1/2006</a></li>
<li><a title="Full Circle" href='fullcircle.php'>26/1/2006</a></li>
<li><a title="The Wrap Up" href='thewrapup.php'>23/3/2006</a></li>
<li> </li><br><li>Or go back to:</li><li><a title='Travelouges and blogs from my trip around Australia' href="nerdseyeview.php">Nerd's Eye View</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>4/11/2005</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Travel stories and pictures' href="travel.php">Travelogues</a> > <a title='Travelouges and blogs from my trip around Australia' href="nerdseyeview.php">Nerd's Eye View</a> > <a title='A week in Perth' href="perth.php">4/11/2005</a>
<br><br>		


<h1>A week in Perth</h1>

<a href="images/maps/Map051104.gif"><img src="images/maps/Map051104_sm.gif" align="right"></a>

<p>(or thereabouts). Well, we finally made it to WA's big smoke last Saturday, after the last update. The Toodyay jazz festival had turned out to be mostly an evening/Sunday affair, so we decided it was best to push on.</p>

<p>After driving in from the north, we stopped off briefly in Scarborough before heading into to the CBD. We spent a large part of the day wandering around looking at accommodation, but in the end we couldn't find anything with suitable parking (which wasn't terribly surprising in hindsight). It is a city after all, and in the end, we ended up back in Scarborough, and I caught up with Rik briefly, who was on holiday from Sydney.</p>

<p>The next day we headed down to Fremantle, where we ended up staying for the rest of our mainland city stint.</p>

<p>Fremantle, or "Freo", is a pretty nice spot, somewhat akin to the likes of Bondi in Sydney. It's south of the CBD and lies on the coast.</p>

<p>We finished off our first day there catching up on missed big smoke activities, like seeing movies. In fact we saw two just for the hell of it; Charlie and the Chocolate Factory (which was quite good, and had lots of chocolate), and Serenity (which was also quite good, and had less chocolate, more space ships, and violence).</p>

<p>We spent the next few days exploring the city, mostly by bicycle, as there are paths a-plenty along the Swan river. Highlights included getting lost (and discovering that Fremantle is actually quite a long way from the city if you go the wrong way), visiting the museum in town (full of interesting stuff), checking out King's Park (a lovely spot overlooking the city), and visiting the address where my parents and I used to live way back when.</p>

<p>As you no doubt know by now, I was born in Perth, but don't remember it at all (being very young at the time). Unfortunately, the old suburb where we used to live (Applecross) has become a foul, subdivided brick mansion land. Concrete columns and front lawns devoid of grass abound. We rode around it for a while; almost all the original houses are gone (one in forty perhaps survives). Such is progress.</p>

<p>Apart from that, and one other slightly amusing thing that I'll mention in a minute, Perth is quite a lovely city. The river and associated bike paths put Brisbane to shame (which isn't all that hard actually), and I was reminded of a quieter version of Sydney in a lot of ways.</p>

<p>The amusing thing we noticed though, is that there seems to be an oddly high proportion of weirdos (for want of a better term) wandering around this city. Perhaps we arrived during the middle of a convention, but the number of oddballs (of all varieties, from harmless to disturbing) that we spotted on our trips was certainly cause for amused discussion.</p>

<p>Other highlights from our stay included getting my car serviced, and shopping.</p>

<p>Our final excursion saw us head out to Rottnest Island for two days and a night. This low-lying, yet fairly sizable island lies off the Perth coast. It's a bit of a holiday haven for the city folk. We spent a couple of non-holiday weekdays there, and yet the place was still teeming with people (and countless school kiddies, no doubt on camp).</p>

<p>The island has very few cars, and is therefore perfectly suited to cycling, and so this is exactly what we did, somehow to the tune of 90+ kms over the two days.</p>

<p>We managed to see most of the island, which is bordered by lovely beaches and bits of reef, and has a centre of salt lakes and scrubby hills. There's plenty of wildlife about, and we spotted numerous birds, King Skinks, Dugites (a type of cute venomous snake), and of course the inescapable Quokkas. These last are a type of small marsupial, once common in the Perth area, but now pretty much limited to the island. They're related to Wallabies, and are very cute. And they're everywhere. Back in the 1600s, the Dutch somehow managed to mistake them for rats, hence the name "Rottnest" (Rat's nest).</p>

<p>I was also going to go diving, but missed out as they cancelled the session due to insufficient numbers. Humbug.</p>

<p>Anyway, adding up Perth and Rottnest, we clocked up a very healthy total of kilometres on the bikes during our stay; I'm guessing a couple of hundred all said, a most satisfying amount.</p>

<p>Now we're into our final leg of WA, the south-west, another type of country again, much more fertile and temperate. After that it'll be the Nullarbor, but that's a story for another week.</p>

<p>Hope all is well in your worlds. Commiserations to my Dad, who's hard drive died an ungainly death this week.</p>

<p>Till next time...</p>

<p>These are this pics for this week:</p>

<table width="800">
	<tr>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=IMG_1781.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20051104/IMG_1781.JPG' ALT='The Perth CBD'><BR>The Perth CBD</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=IMG_1792.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20051104/IMG_1792.JPG' ALT='Pedal action on the Swan River'><BR>Pedal action on the Swan River</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=IMG_1828.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20051104/IMG_1828.JPG' ALT='Fremantle Docks'><BR>Fremantle Docks</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=IMG_1868.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20051104/IMG_1868.JPG' ALT='Rottnest Island coastline'><BR>Rottnest Island coastline</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=IMG_2011.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20051104/IMG_2011.JPG' ALT='Striking a pose, Quokka style (he looks so cute, he could almost be human)'><BR>Striking a pose, Quokka style (he looks so cute, he could almost be human)</a>
	</td>
	</tr>
</table>

<br><br>
All images in this gallery:<br>
<table width='800'>
<tr>
</tr>
<tr><td><A ID='IMG_1768.JPG' href='perth.php?fileId=IMG_1768.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051104/IMG_1768.JPG' ALT='IMG_1768.JPG'><BR>IMG_1768.JPG<br>49.47 KB</a><div class='inv'><br><a href='./images/20051104/IMG_1768.JPG' ALT='IMG_1768.JPG'>IMG_1768.JPG</a></div></td>
<td><A ID='IMG_1772.JPG' href='perth.php?fileId=IMG_1772.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051104/IMG_1772.JPG' ALT='IMG_1772.JPG'><BR>IMG_1772.JPG<br>77.66 KB</a><div class='inv'><br><a href='./images/20051104/IMG_1772.JPG' ALT='IMG_1772.JPG'>IMG_1772.JPG</a></div></td>
<td><A ID='IMG_1774.JPG' href='perth.php?fileId=IMG_1774.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051104/IMG_1774.JPG' ALT='IMG_1774.JPG'><BR>IMG_1774.JPG<br>76.45 KB</a><div class='inv'><br><a href='./images/20051104/IMG_1774.JPG' ALT='IMG_1774.JPG'>IMG_1774.JPG</a></div></td>
<td><A ID='IMG_1778.JPG' href='perth.php?fileId=IMG_1778.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051104/IMG_1778.JPG' ALT='IMG_1778.JPG'><BR>IMG_1778.JPG<br>43.92 KB</a><div class='inv'><br><a href='./images/20051104/IMG_1778.JPG' ALT='IMG_1778.JPG'>IMG_1778.JPG</a></div></td>
<td><A ID='IMG_1779.JPG' href='perth.php?fileId=IMG_1779.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051104/IMG_1779.JPG' ALT='IMG_1779.JPG'><BR>IMG_1779.JPG<br>71.78 KB</a><div class='inv'><br><a href='./images/20051104/IMG_1779.JPG' ALT='IMG_1779.JPG'>IMG_1779.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_1780.JPG' href='perth.php?fileId=IMG_1780.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051104/IMG_1780.JPG' ALT='IMG_1780.JPG'><BR>IMG_1780.JPG<br>52.57 KB</a><div class='inv'><br><a href='./images/20051104/IMG_1780.JPG' ALT='IMG_1780.JPG'>IMG_1780.JPG</a></div></td>
<td><A ID='IMG_1781.JPG' href='perth.php?fileId=IMG_1781.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051104/IMG_1781.JPG' ALT='IMG_1781.JPG'><BR>IMG_1781.JPG<br>72.78 KB</a><div class='inv'><br><a href='./images/20051104/IMG_1781.JPG' ALT='IMG_1781.JPG'>IMG_1781.JPG</a></div></td>
<td><A ID='IMG_1782.JPG' href='perth.php?fileId=IMG_1782.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051104/IMG_1782.JPG' ALT='IMG_1782.JPG'><BR>IMG_1782.JPG<br>78.46 KB</a><div class='inv'><br><a href='./images/20051104/IMG_1782.JPG' ALT='IMG_1782.JPG'>IMG_1782.JPG</a></div></td>
<td><A ID='IMG_1784.JPG' href='perth.php?fileId=IMG_1784.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051104/IMG_1784.JPG' ALT='IMG_1784.JPG'><BR>IMG_1784.JPG<br>80.37 KB</a><div class='inv'><br><a href='./images/20051104/IMG_1784.JPG' ALT='IMG_1784.JPG'>IMG_1784.JPG</a></div></td>
<td><A ID='IMG_1785.JPG' href='perth.php?fileId=IMG_1785.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051104/IMG_1785.JPG' ALT='IMG_1785.JPG'><BR>IMG_1785.JPG<br>64.47 KB</a><div class='inv'><br><a href='./images/20051104/IMG_1785.JPG' ALT='IMG_1785.JPG'>IMG_1785.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_1787.JPG' href='perth.php?fileId=IMG_1787.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051104/IMG_1787.JPG' ALT='IMG_1787.JPG'><BR>IMG_1787.JPG<br>79.73 KB</a><div class='inv'><br><a href='./images/20051104/IMG_1787.JPG' ALT='IMG_1787.JPG'>IMG_1787.JPG</a></div></td>
<td><A ID='IMG_1790.JPG' href='perth.php?fileId=IMG_1790.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051104/IMG_1790.JPG' ALT='IMG_1790.JPG'><BR>IMG_1790.JPG<br>67.22 KB</a><div class='inv'><br><a href='./images/20051104/IMG_1790.JPG' ALT='IMG_1790.JPG'>IMG_1790.JPG</a></div></td>
<td><A ID='IMG_1792.JPG' href='perth.php?fileId=IMG_1792.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051104/IMG_1792.JPG' ALT='IMG_1792.JPG'><BR>IMG_1792.JPG<br>70.19 KB</a><div class='inv'><br><a href='./images/20051104/IMG_1792.JPG' ALT='IMG_1792.JPG'>IMG_1792.JPG</a></div></td>
<td><A ID='IMG_1796.JPG' href='perth.php?fileId=IMG_1796.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051104/IMG_1796.JPG' ALT='IMG_1796.JPG'><BR>IMG_1796.JPG<br>108.79 KB</a><div class='inv'><br><a href='./images/20051104/IMG_1796.JPG' ALT='IMG_1796.JPG'>IMG_1796.JPG</a></div></td>
<td><A ID='IMG_1801.JPG' href='perth.php?fileId=IMG_1801.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051104/IMG_1801.JPG' ALT='IMG_1801.JPG'><BR>IMG_1801.JPG<br>88.26 KB</a><div class='inv'><br><a href='./images/20051104/IMG_1801.JPG' ALT='IMG_1801.JPG'>IMG_1801.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_1802.JPG' href='perth.php?fileId=IMG_1802.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051104/IMG_1802.JPG' ALT='IMG_1802.JPG'><BR>IMG_1802.JPG<br>40.23 KB</a><div class='inv'><br><a href='./images/20051104/IMG_1802.JPG' ALT='IMG_1802.JPG'>IMG_1802.JPG</a></div></td>
<td><A ID='IMG_1803.JPG' href='perth.php?fileId=IMG_1803.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051104/IMG_1803.JPG' ALT='IMG_1803.JPG'><BR>IMG_1803.JPG<br>50.23 KB</a><div class='inv'><br><a href='./images/20051104/IMG_1803.JPG' ALT='IMG_1803.JPG'>IMG_1803.JPG</a></div></td>
<td><A ID='IMG_1804.JPG' href='perth.php?fileId=IMG_1804.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051104/IMG_1804.JPG' ALT='IMG_1804.JPG'><BR>IMG_1804.JPG<br>85.81 KB</a><div class='inv'><br><a href='./images/20051104/IMG_1804.JPG' ALT='IMG_1804.JPG'>IMG_1804.JPG</a></div></td>
<td><A ID='IMG_1806.JPG' href='perth.php?fileId=IMG_1806.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051104/IMG_1806.JPG' ALT='IMG_1806.JPG'><BR>IMG_1806.JPG<br>54.24 KB</a><div class='inv'><br><a href='./images/20051104/IMG_1806.JPG' ALT='IMG_1806.JPG'>IMG_1806.JPG</a></div></td>
<td><A ID='IMG_1808.JPG' href='perth.php?fileId=IMG_1808.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051104/IMG_1808.JPG' ALT='IMG_1808.JPG'><BR>IMG_1808.JPG<br>69.4 KB</a><div class='inv'><br><a href='./images/20051104/IMG_1808.JPG' ALT='IMG_1808.JPG'>IMG_1808.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_1809.JPG' href='perth.php?fileId=IMG_1809.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051104/IMG_1809.JPG' ALT='IMG_1809.JPG'><BR>IMG_1809.JPG<br>50.68 KB</a><div class='inv'><br><a href='./images/20051104/IMG_1809.JPG' ALT='IMG_1809.JPG'>IMG_1809.JPG</a></div></td>
<td><A ID='IMG_1811.JPG' href='perth.php?fileId=IMG_1811.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051104/IMG_1811.JPG' ALT='IMG_1811.JPG'><BR>IMG_1811.JPG<br>41.69 KB</a><div class='inv'><br><a href='./images/20051104/IMG_1811.JPG' ALT='IMG_1811.JPG'>IMG_1811.JPG</a></div></td>
<td><A ID='IMG_1812.JPG' href='perth.php?fileId=IMG_1812.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051104/IMG_1812.JPG' ALT='IMG_1812.JPG'><BR>IMG_1812.JPG<br>38.97 KB</a><div class='inv'><br><a href='./images/20051104/IMG_1812.JPG' ALT='IMG_1812.JPG'>IMG_1812.JPG</a></div></td>
<td><A ID='IMG_1813.JPG' href='perth.php?fileId=IMG_1813.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051104/IMG_1813.JPG' ALT='IMG_1813.JPG'><BR>IMG_1813.JPG<br>63.42 KB</a><div class='inv'><br><a href='./images/20051104/IMG_1813.JPG' ALT='IMG_1813.JPG'>IMG_1813.JPG</a></div></td>
<td><A ID='IMG_1814.JPG' href='perth.php?fileId=IMG_1814.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051104/IMG_1814.JPG' ALT='IMG_1814.JPG'><BR>IMG_1814.JPG<br>45.43 KB</a><div class='inv'><br><a href='./images/20051104/IMG_1814.JPG' ALT='IMG_1814.JPG'>IMG_1814.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_1815.JPG' href='perth.php?fileId=IMG_1815.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051104/IMG_1815.JPG' ALT='IMG_1815.JPG'><BR>IMG_1815.JPG<br>65.29 KB</a><div class='inv'><br><a href='./images/20051104/IMG_1815.JPG' ALT='IMG_1815.JPG'>IMG_1815.JPG</a></div></td>
<td><A ID='IMG_1817.JPG' href='perth.php?fileId=IMG_1817.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051104/IMG_1817.JPG' ALT='IMG_1817.JPG'><BR>IMG_1817.JPG<br>71.85 KB</a><div class='inv'><br><a href='./images/20051104/IMG_1817.JPG' ALT='IMG_1817.JPG'>IMG_1817.JPG</a></div></td>
<td><A ID='IMG_1819.JPG' href='perth.php?fileId=IMG_1819.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051104/IMG_1819.JPG' ALT='IMG_1819.JPG'><BR>IMG_1819.JPG<br>58.34 KB</a><div class='inv'><br><a href='./images/20051104/IMG_1819.JPG' ALT='IMG_1819.JPG'>IMG_1819.JPG</a></div></td>
<td><A ID='IMG_1820.JPG' href='perth.php?fileId=IMG_1820.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051104/IMG_1820.JPG' ALT='IMG_1820.JPG'><BR>IMG_1820.JPG<br>58.04 KB</a><div class='inv'><br><a href='./images/20051104/IMG_1820.JPG' ALT='IMG_1820.JPG'>IMG_1820.JPG</a></div></td>
<td><A ID='IMG_1821.JPG' href='perth.php?fileId=IMG_1821.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051104/IMG_1821.JPG' ALT='IMG_1821.JPG'><BR>IMG_1821.JPG<br>70.32 KB</a><div class='inv'><br><a href='./images/20051104/IMG_1821.JPG' ALT='IMG_1821.JPG'>IMG_1821.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_1822.JPG' href='perth.php?fileId=IMG_1822.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051104/IMG_1822.JPG' ALT='IMG_1822.JPG'><BR>IMG_1822.JPG<br>75.11 KB</a><div class='inv'><br><a href='./images/20051104/IMG_1822.JPG' ALT='IMG_1822.JPG'>IMG_1822.JPG</a></div></td>
<td><A ID='IMG_1823.JPG' href='perth.php?fileId=IMG_1823.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051104/IMG_1823.JPG' ALT='IMG_1823.JPG'><BR>IMG_1823.JPG<br>83.48 KB</a><div class='inv'><br><a href='./images/20051104/IMG_1823.JPG' ALT='IMG_1823.JPG'>IMG_1823.JPG</a></div></td>
<td><A ID='IMG_1827.JPG' href='perth.php?fileId=IMG_1827.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051104/IMG_1827.JPG' ALT='IMG_1827.JPG'><BR>IMG_1827.JPG<br>50.91 KB</a><div class='inv'><br><a href='./images/20051104/IMG_1827.JPG' ALT='IMG_1827.JPG'>IMG_1827.JPG</a></div></td>
<td><A ID='IMG_1828.JPG' href='perth.php?fileId=IMG_1828.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051104/IMG_1828.JPG' ALT='IMG_1828.JPG'><BR>IMG_1828.JPG<br>53.69 KB</a><div class='inv'><br><a href='./images/20051104/IMG_1828.JPG' ALT='IMG_1828.JPG'>IMG_1828.JPG</a></div></td>
<td><A ID='IMG_1831.JPG' href='perth.php?fileId=IMG_1831.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051104/IMG_1831.JPG' ALT='IMG_1831.JPG'><BR>IMG_1831.JPG<br>56.72 KB</a><div class='inv'><br><a href='./images/20051104/IMG_1831.JPG' ALT='IMG_1831.JPG'>IMG_1831.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_1836.JPG' href='perth.php?fileId=IMG_1836.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051104/IMG_1836.JPG' ALT='IMG_1836.JPG'><BR>IMG_1836.JPG<br>58.88 KB</a><div class='inv'><br><a href='./images/20051104/IMG_1836.JPG' ALT='IMG_1836.JPG'>IMG_1836.JPG</a></div></td>
<td><A ID='IMG_1837.JPG' href='perth.php?fileId=IMG_1837.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051104/IMG_1837.JPG' ALT='IMG_1837.JPG'><BR>IMG_1837.JPG<br>66.97 KB</a><div class='inv'><br><a href='./images/20051104/IMG_1837.JPG' ALT='IMG_1837.JPG'>IMG_1837.JPG</a></div></td>
<td><A ID='IMG_1840.JPG' href='perth.php?fileId=IMG_1840.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051104/IMG_1840.JPG' ALT='IMG_1840.JPG'><BR>IMG_1840.JPG<br>50.43 KB</a><div class='inv'><br><a href='./images/20051104/IMG_1840.JPG' ALT='IMG_1840.JPG'>IMG_1840.JPG</a></div></td>
<td><A ID='IMG_1842.JPG' href='perth.php?fileId=IMG_1842.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051104/IMG_1842.JPG' ALT='IMG_1842.JPG'><BR>IMG_1842.JPG<br>47.72 KB</a><div class='inv'><br><a href='./images/20051104/IMG_1842.JPG' ALT='IMG_1842.JPG'>IMG_1842.JPG</a></div></td>
<td><A ID='IMG_1848.JPG' href='perth.php?fileId=IMG_1848.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051104/IMG_1848.JPG' ALT='IMG_1848.JPG'><BR>IMG_1848.JPG<br>76.23 KB</a><div class='inv'><br><a href='./images/20051104/IMG_1848.JPG' ALT='IMG_1848.JPG'>IMG_1848.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_1856.JPG' href='perth.php?fileId=IMG_1856.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051104/IMG_1856.JPG' ALT='IMG_1856.JPG'><BR>IMG_1856.JPG<br>73.38 KB</a><div class='inv'><br><a href='./images/20051104/IMG_1856.JPG' ALT='IMG_1856.JPG'>IMG_1856.JPG</a></div></td>
<td><A ID='IMG_1861.JPG' href='perth.php?fileId=IMG_1861.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051104/IMG_1861.JPG' ALT='IMG_1861.JPG'><BR>IMG_1861.JPG<br>54.97 KB</a><div class='inv'><br><a href='./images/20051104/IMG_1861.JPG' ALT='IMG_1861.JPG'>IMG_1861.JPG</a></div></td>
<td><A ID='IMG_1863.JPG' href='perth.php?fileId=IMG_1863.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051104/IMG_1863.JPG' ALT='IMG_1863.JPG'><BR>IMG_1863.JPG<br>58.6 KB</a><div class='inv'><br><a href='./images/20051104/IMG_1863.JPG' ALT='IMG_1863.JPG'>IMG_1863.JPG</a></div></td>
<td><A ID='IMG_1868.JPG' href='perth.php?fileId=IMG_1868.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051104/IMG_1868.JPG' ALT='IMG_1868.JPG'><BR>IMG_1868.JPG<br>68.29 KB</a><div class='inv'><br><a href='./images/20051104/IMG_1868.JPG' ALT='IMG_1868.JPG'>IMG_1868.JPG</a></div></td>
<td><A ID='IMG_1869.JPG' href='perth.php?fileId=IMG_1869.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051104/IMG_1869.JPG' ALT='IMG_1869.JPG'><BR>IMG_1869.JPG<br>58.48 KB</a><div class='inv'><br><a href='./images/20051104/IMG_1869.JPG' ALT='IMG_1869.JPG'>IMG_1869.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_1871.JPG' href='perth.php?fileId=IMG_1871.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051104/IMG_1871.JPG' ALT='IMG_1871.JPG'><BR>IMG_1871.JPG<br>53.54 KB</a><div class='inv'><br><a href='./images/20051104/IMG_1871.JPG' ALT='IMG_1871.JPG'>IMG_1871.JPG</a></div></td>
<td><A ID='IMG_1872.JPG' href='perth.php?fileId=IMG_1872.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051104/IMG_1872.JPG' ALT='IMG_1872.JPG'><BR>IMG_1872.JPG<br>65.16 KB</a><div class='inv'><br><a href='./images/20051104/IMG_1872.JPG' ALT='IMG_1872.JPG'>IMG_1872.JPG</a></div></td>
<td><A ID='IMG_1875.JPG' href='perth.php?fileId=IMG_1875.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051104/IMG_1875.JPG' ALT='IMG_1875.JPG'><BR>IMG_1875.JPG<br>125.12 KB</a><div class='inv'><br><a href='./images/20051104/IMG_1875.JPG' ALT='IMG_1875.JPG'>IMG_1875.JPG</a></div></td>
<td><A ID='IMG_1877.JPG' href='perth.php?fileId=IMG_1877.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051104/IMG_1877.JPG' ALT='IMG_1877.JPG'><BR>IMG_1877.JPG<br>67.25 KB</a><div class='inv'><br><a href='./images/20051104/IMG_1877.JPG' ALT='IMG_1877.JPG'>IMG_1877.JPG</a></div></td>
<td><A ID='IMG_1886.JPG' href='perth.php?fileId=IMG_1886.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051104/IMG_1886.JPG' ALT='IMG_1886.JPG'><BR>IMG_1886.JPG<br>46.27 KB</a><div class='inv'><br><a href='./images/20051104/IMG_1886.JPG' ALT='IMG_1886.JPG'>IMG_1886.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_1891.JPG' href='perth.php?fileId=IMG_1891.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051104/IMG_1891.JPG' ALT='IMG_1891.JPG'><BR>IMG_1891.JPG<br>98.38 KB</a><div class='inv'><br><a href='./images/20051104/IMG_1891.JPG' ALT='IMG_1891.JPG'>IMG_1891.JPG</a></div></td>
<td><A ID='IMG_1893.JPG' href='perth.php?fileId=IMG_1893.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051104/IMG_1893.JPG' ALT='IMG_1893.JPG'><BR>IMG_1893.JPG<br>47.22 KB</a><div class='inv'><br><a href='./images/20051104/IMG_1893.JPG' ALT='IMG_1893.JPG'>IMG_1893.JPG</a></div></td>
<td><A ID='IMG_1902.JPG' href='perth.php?fileId=IMG_1902.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051104/IMG_1902.JPG' ALT='IMG_1902.JPG'><BR>IMG_1902.JPG<br>123.63 KB</a><div class='inv'><br><a href='./images/20051104/IMG_1902.JPG' ALT='IMG_1902.JPG'>IMG_1902.JPG</a></div></td>
<td><A ID='IMG_1903.JPG' href='perth.php?fileId=IMG_1903.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051104/IMG_1903.JPG' ALT='IMG_1903.JPG'><BR>IMG_1903.JPG<br>81.03 KB</a><div class='inv'><br><a href='./images/20051104/IMG_1903.JPG' ALT='IMG_1903.JPG'>IMG_1903.JPG</a></div></td>
<td><A ID='IMG_1911.JPG' href='perth.php?fileId=IMG_1911.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051104/IMG_1911.JPG' ALT='IMG_1911.JPG'><BR>IMG_1911.JPG<br>52.5 KB</a><div class='inv'><br><a href='./images/20051104/IMG_1911.JPG' ALT='IMG_1911.JPG'>IMG_1911.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_1924.JPG' href='perth.php?fileId=IMG_1924.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051104/IMG_1924.JPG' ALT='IMG_1924.JPG'><BR>IMG_1924.JPG<br>100.67 KB</a><div class='inv'><br><a href='./images/20051104/IMG_1924.JPG' ALT='IMG_1924.JPG'>IMG_1924.JPG</a></div></td>
<td><A ID='IMG_1927.JPG' href='perth.php?fileId=IMG_1927.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051104/IMG_1927.JPG' ALT='IMG_1927.JPG'><BR>IMG_1927.JPG<br>62.53 KB</a><div class='inv'><br><a href='./images/20051104/IMG_1927.JPG' ALT='IMG_1927.JPG'>IMG_1927.JPG</a></div></td>
<td><A ID='IMG_1932.JPG' href='perth.php?fileId=IMG_1932.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051104/IMG_1932.JPG' ALT='Two Dugites getting friendly'><BR>Two Dugites getting friendly<br>127.53 KB</a><div class='inv'><br><a href='./images/20051104/IMG_1932.JPG' ALT='Two Dugites getting friendly'>Two Dugites getting friendly</a></div></td>
<td><A ID='IMG_1941.JPG' href='perth.php?fileId=IMG_1941.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051104/IMG_1941.JPG' ALT='IMG_1941.JPG'><BR>IMG_1941.JPG<br>60.62 KB</a><div class='inv'><br><a href='./images/20051104/IMG_1941.JPG' ALT='IMG_1941.JPG'>IMG_1941.JPG</a></div></td>
<td><A ID='IMG_1947.JPG' href='perth.php?fileId=IMG_1947.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051104/IMG_1947.JPG' ALT='IMG_1947.JPG'><BR>IMG_1947.JPG<br>78.53 KB</a><div class='inv'><br><a href='./images/20051104/IMG_1947.JPG' ALT='IMG_1947.JPG'>IMG_1947.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_1949.JPG' href='perth.php?fileId=IMG_1949.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051104/IMG_1949.JPG' ALT='IMG_1949.JPG'><BR>IMG_1949.JPG<br>51.11 KB</a><div class='inv'><br><a href='./images/20051104/IMG_1949.JPG' ALT='IMG_1949.JPG'>IMG_1949.JPG</a></div></td>
<td><A ID='IMG_1954.JPG' href='perth.php?fileId=IMG_1954.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051104/IMG_1954.JPG' ALT='IMG_1954.JPG'><BR>IMG_1954.JPG<br>60.06 KB</a><div class='inv'><br><a href='./images/20051104/IMG_1954.JPG' ALT='IMG_1954.JPG'>IMG_1954.JPG</a></div></td>
<td><A ID='IMG_1961.JPG' href='perth.php?fileId=IMG_1961.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051104/IMG_1961.JPG' ALT='IMG_1961.JPG'><BR>IMG_1961.JPG<br>47.34 KB</a><div class='inv'><br><a href='./images/20051104/IMG_1961.JPG' ALT='IMG_1961.JPG'>IMG_1961.JPG</a></div></td>
<td><A ID='IMG_1963.JPG' href='perth.php?fileId=IMG_1963.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051104/IMG_1963.JPG' ALT='IMG_1963.JPG'><BR>IMG_1963.JPG<br>116.83 KB</a><div class='inv'><br><a href='./images/20051104/IMG_1963.JPG' ALT='IMG_1963.JPG'>IMG_1963.JPG</a></div></td>
<td><A ID='IMG_1966.JPG' href='perth.php?fileId=IMG_1966.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051104/IMG_1966.JPG' ALT='IMG_1966.JPG'><BR>IMG_1966.JPG<br>64.42 KB</a><div class='inv'><br><a href='./images/20051104/IMG_1966.JPG' ALT='IMG_1966.JPG'>IMG_1966.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_1968.JPG' href='perth.php?fileId=IMG_1968.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051104/IMG_1968.JPG' ALT='IMG_1968.JPG'><BR>IMG_1968.JPG<br>56.42 KB</a><div class='inv'><br><a href='./images/20051104/IMG_1968.JPG' ALT='IMG_1968.JPG'>IMG_1968.JPG</a></div></td>
<td><A ID='IMG_1970.JPG' href='perth.php?fileId=IMG_1970.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051104/IMG_1970.JPG' ALT='IMG_1970.JPG'><BR>IMG_1970.JPG<br>53.33 KB</a><div class='inv'><br><a href='./images/20051104/IMG_1970.JPG' ALT='IMG_1970.JPG'>IMG_1970.JPG</a></div></td>
<td><A ID='IMG_1976.JPG' href='perth.php?fileId=IMG_1976.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051104/IMG_1976.JPG' ALT='IMG_1976.JPG'><BR>IMG_1976.JPG<br>58.08 KB</a><div class='inv'><br><a href='./images/20051104/IMG_1976.JPG' ALT='IMG_1976.JPG'>IMG_1976.JPG</a></div></td>
<td><A ID='IMG_1977.JPG' href='perth.php?fileId=IMG_1977.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051104/IMG_1977.JPG' ALT='IMG_1977.JPG'><BR>IMG_1977.JPG<br>56.57 KB</a><div class='inv'><br><a href='./images/20051104/IMG_1977.JPG' ALT='IMG_1977.JPG'>IMG_1977.JPG</a></div></td>
<td><A ID='IMG_1978.JPG' href='perth.php?fileId=IMG_1978.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051104/IMG_1978.JPG' ALT='IMG_1978.JPG'><BR>IMG_1978.JPG<br>78.26 KB</a><div class='inv'><br><a href='./images/20051104/IMG_1978.JPG' ALT='IMG_1978.JPG'>IMG_1978.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_1982.JPG' href='perth.php?fileId=IMG_1982.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051104/IMG_1982.JPG' ALT='IMG_1982.JPG'><BR>IMG_1982.JPG<br>51.73 KB</a><div class='inv'><br><a href='./images/20051104/IMG_1982.JPG' ALT='IMG_1982.JPG'>IMG_1982.JPG</a></div></td>
<td><A ID='IMG_1991.JPG' href='perth.php?fileId=IMG_1991.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051104/IMG_1991.JPG' ALT='IMG_1991.JPG'><BR>IMG_1991.JPG<br>50.71 KB</a><div class='inv'><br><a href='./images/20051104/IMG_1991.JPG' ALT='IMG_1991.JPG'>IMG_1991.JPG</a></div></td>
<td><A ID='IMG_1992.JPG' href='perth.php?fileId=IMG_1992.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051104/IMG_1992.JPG' ALT='IMG_1992.JPG'><BR>IMG_1992.JPG<br>59.37 KB</a><div class='inv'><br><a href='./images/20051104/IMG_1992.JPG' ALT='IMG_1992.JPG'>IMG_1992.JPG</a></div></td>
<td><A ID='IMG_1999.JPG' href='perth.php?fileId=IMG_1999.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051104/IMG_1999.JPG' ALT='IMG_1999.JPG'><BR>IMG_1999.JPG<br>58.25 KB</a><div class='inv'><br><a href='./images/20051104/IMG_1999.JPG' ALT='IMG_1999.JPG'>IMG_1999.JPG</a></div></td>
<td><A ID='IMG_2003.JPG' href='perth.php?fileId=IMG_2003.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051104/IMG_2003.JPG' ALT='IMG_2003.JPG'><BR>IMG_2003.JPG<br>64.08 KB</a><div class='inv'><br><a href='./images/20051104/IMG_2003.JPG' ALT='IMG_2003.JPG'>IMG_2003.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_2004.JPG' href='perth.php?fileId=IMG_2004.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051104/IMG_2004.JPG' ALT='IMG_2004.JPG'><BR>IMG_2004.JPG<br>85.36 KB</a><div class='inv'><br><a href='./images/20051104/IMG_2004.JPG' ALT='IMG_2004.JPG'>IMG_2004.JPG</a></div></td>
<td><A ID='IMG_2007.JPG' href='perth.php?fileId=IMG_2007.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051104/IMG_2007.JPG' ALT='IMG_2007.JPG'><BR>IMG_2007.JPG<br>65.38 KB</a><div class='inv'><br><a href='./images/20051104/IMG_2007.JPG' ALT='IMG_2007.JPG'>IMG_2007.JPG</a></div></td>
<td><A ID='IMG_2011.JPG' href='perth.php?fileId=IMG_2011.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051104/IMG_2011.JPG' ALT='IMG_2011.JPG'><BR>IMG_2011.JPG<br>56.82 KB</a><div class='inv'><br><a href='./images/20051104/IMG_2011.JPG' ALT='IMG_2011.JPG'>IMG_2011.JPG</a></div></td>
<td><A ID='IMG_2012.JPG' href='perth.php?fileId=IMG_2012.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051104/IMG_2012.JPG' ALT='IMG_2012.JPG'><BR>IMG_2012.JPG<br>53.14 KB</a><div class='inv'><br><a href='./images/20051104/IMG_2012.JPG' ALT='IMG_2012.JPG'>IMG_2012.JPG</a></div></td>
</tr>
</table>	</div>
</div>
</body>
</html>