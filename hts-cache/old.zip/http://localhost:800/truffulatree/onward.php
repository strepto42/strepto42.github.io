<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - 2/5/2005 - Onward</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="Onward">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="Greetings from a Bum" href='greetingsfromabum.php'>29/4/2005</a></li>
<li><div class='activemenu'>2/5/2005</div></li>
<li><a title="It's a tough life (pt 1: Bundaberg, Agnes Water and 1770)" href='itsatoughlife1.php'>17/5/2005</a></li>
<li><a title="It's a tough life (pt 2: Rockhampton, Emu Park and Great Keppel Island)" href='itsatoughlife2.php'>23/5/2005</a></li>
<li><a title="There and Back Again - a Yo-yo's Tale" href='thereandbackagain.php'>18/6/2005</a></li>
<li><a title="Platypi and Grey Nomads" href='platypiandgreynomads.php'>24/6/2005</a></li>
<li><a title="Blowing Bubbles in a Watery Tomb" href='blowingbubbles.php'>1/7/2005</a></li>
<li><a title="Pieces of History" href='piecesofhistory.php'>8/7/2005</a></li>
<li><a title="Walks and Waterfalls" href='walksandwaterfalls.php'>15/7/2005</a></li>
<li><a title="Mission to Tribulation" href='missiontotribulation.php'>22/7/2005</a></li>
<li><a title="Levity, Limestone and Lava" href='levitylimestoneandlava.php'>29/7/2005</a></li>
<li><a title="Into the Never Never" href='intothenevernever.php'>5/8/2005</a></li>
<li><a title="Slowing the pace in Darwin" href='slowingthepaceindarwin.php'>12/8/2005</a></li>
<li><a title="Blistering Barnacles and Leaping Lizards" href='leapinglizards.php'>19/8/2005</a></li>
<li><a title="Kakadu and Litchfield" href='kakadu.php'>26/8/2005</a></li>
<li><a title="Legacies of War" href='legaciesofwar.php'>2/9/2005</a></li>
<li><a title="Go West" href='gowest.php'>10/9/2005</a></li>
<li><a title="Things from Above" href='thingsfromabove.php'>16/9/2005</a></li>
<li><a title="The West Coast" href='thewestcoast.php'>23/9/2005</a></li>
<li><a title="Reefs and Red Dust" href='reefsandreddust.php'>30/9/2005</a></li>
<li><a title="The Pilbara" href='pilbara.php'>7/10/2005</a></li>
<li><a title="Paradise with a Headwind" href='paradisewithaheadwind.php'>14/10/2005</a></li>
<li><a title="Down the Coral Coast" href='downthecoralcoast.php'>21/10/2005</a></li>
<li><a title="Pinnacles and Pinnipeds" href='pinnaclesandpinnipeds.php'>28/10/2005</a></li>
<li><a title="A week in Perth" href='perth.php'>4/11/2005</a></li>
<li><a title="The Southwest (from Above and Below)" href='thesouthwest.php'>11/11/2005</a></li>
<li><a title="More Heights and Depths" href='moreheightsanddepths.php'>18/11/2005</a></li>
<li><a title="Across the Nullarbor (and a bit beyond)" href='nullarbor.php'>25/11/2005</a></li>
<li><a title="Double Whammy" href='doublewhammy.php'>9/12/2005</a></li>
<li><a title="Two Cities" href='twocities.php'>19/12/2005</a></li>
<li><a title="Tassie - Part 1" href='tassie1.php'>1/1/2006</a></li>
<li><a title="Tassie - Part 2" href='tassie2.php'>7/1/2006</a></li>
<li><a title="Full Circle" href='fullcircle.php'>26/1/2006</a></li>
<li><a title="The Wrap Up" href='thewrapup.php'>23/3/2006</a></li>
<li> </li><br><li>Or go back to:</li><li><a title='Travelouges and blogs from my trip around Australia' href="nerdseyeview.php">Nerd's Eye View</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>2/5/2005</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Travel stories and pictures' href="travel.php">Travelogues</a> > <a title='Travelouges and blogs from my trip around Australia' href="nerdseyeview.php">Nerd's Eye View</a> > <a title='Onward' href="onward.php">2/5/2005</a>
<br><br>		


<h1>Onward</h1>

<a href="images/maps/Map050502.gif"><img src="images/maps/Map050502_sm.gif" align="right"></a>
<p>Here I am again... taking up the story from before, I left the Peregian
and headed towards Rainbow beach.</p>

<p>It was a nice place to stay though. Everyone I met has been very
friendly and pleasant. My closest neighbours were all nice.</p>

<p>Nearest was a guy called Chris who is a mad windsurfer (Carl, he really
reminded me of you for some reason; his manner more than anything else -
the long ocean stare hey ;)).</p>

<p>He showed me some photos of him doing summersaults in the surf. He also
turned out to be the brother of the Oz Cable Guy
(http://www.ozcableguy.com), if you've heard of him. Small world.</p>

<p>We had an amusing nerd session in the caravan park, hooking up our
laptops with Bluetooth so I could fix him up with Quicktime (to let him
view his mobile phone videos). He was most appreciative.</p>

<p>I also left a burned cd of some perfectly legal software for him,
figured he'd appreciate it.</p>

<p>Another, older fellow and I bonded almost immediately with our shared
hatred of John Howard and the way this country, and it's people, have
become in recent years. I have a feeling that Johnny and Dubya are not
the most popular people in these sorts of places.</p>

<p>During my travels I shall endeavour to find some of the people who
actually voted for Howard - because buggered if I can now, or have been
able to to date (barring one or two people on this mailing list whom I
shall not name - yet! ;)).</p>

<p>It's been nice though, as it's made me feel a lot more comfortable about
leaving my stuff around in places like this. It's a pain to tie up my
bike all the time, and it's much nicer to trust people. Besides, no one
in their right mind will steal my bike, unless they are my size or
bigger, as they'd just end up cracking their ging gang goolie goolies
on the enormous frame (for those who haven't seen my bike, it's the size
of a cow).</p>

<p>I've also seen the Hitch Hiker's movie now. Suffice to say that I think
everyone is being a bit too kind about it. Maybe I am just a raving
loony extremist nerd fan, but I have to say... Yanks just don't get it.
They took a loose plot used to drive sketch comedy and tried to make it
a proper movie, which is fine, but they also cut half the jokes, ruined
the other half and added some lame ones of their own. Which is not ok.
<sigh>.</p>

<p>Anyway, enough with the ranting and back-story. I had my first adventure
on the way to Rainbow beach.</p>

<p>There are two ways to get there basically, one is a long roundabout
road, and the other is to drive along the coast, basically along a beach
for about 50kms.</p>

<p>Wasn't sure if my car would be up for it (it is 4WD, but it's not A
4WD), so I spoke to the folks at the National Parks permit place, who
reckoned it would be fine with my car, provided I went a low tide and so
on. No worries, she'll be right mate.</p>

<p>So I got the times for the tides, and caught the ferry over the river.</p>

<p>The tide was still coming in so I had a beer and killed a little bit of
time a local pub there. There were Mynah birds flying around inside the
pub, one was at the bar for a while staring at various bottles, I think
trying to work out whether it wanted a Jack Daniels or not. I didn't get
a photo though as it buggered off fairly quickly.</p>

<p>Then I set off for the beach. The idea was, drive on, drive up to the
headland, drive overland briefly to skip the rocky point, and then drive
up the beach on the other side to the town.</p>

<p>I foolishly followed a couple of 4WDs onto the beach without scouting it
out, and rapidly became aware of the fact that a) they weren't going
fast so I couldn't keep my momentum up, and b) the sand was too soft and
my car no longer had clearance. So I got bogged with 1 minute. Great.</p>

<p>I flagged down an older couple in a 4WD; they kindly rescued the
poor city boy, and towed me out onto the hard sand. After that all was
well. I drove up the beach for a good hour, stopped at a place called
Red Canyon, some eroded sands full of iron oxide basically, and got some
snaps (see attached).</p>

<p>There is a camping area on the beach, with no-camping areas on either
side. The camping area was packed, worse than usual due to the long
weekend. There were 4WDs everywhere.</p>

<p>I should take a moment to point out that all this is kind of foul
really. Driving on beaches is not the most environmentally sound idea,
and I find it quite odd actually that National Parks and Wildlife allow
it, as the area is basically one big national park.</p>

<p>Of course, I was part of the problem myself, wasn't I.</p>

<p>I suppose I was just curious to do it, and it seemed a more interesting
road to travel (and it is officially a road - with a speed limit of 80).
It feels fouler in hindsight, and it's not something I feel the need to
do again.</p>

<p>Also, I now know where all those yuppies with their urban monsters go,
with their broods, on long weekends. And somehow they still manage not
to get mud on them.</p>

<p>So, having alienated a certain proportion of this mailing list (hey you
all knew you were subscribing to a certain amount of pontification), I
should get on with the story.</p>

<p>I got up to the end of the beach, actually missed the turnoff to the
overland track, and had to double back. After getting bogged again. In
really shallow dry sand. Oh the embarrassment, but it serves me right.</p>

<p>It was only a minor bog this time though, and 5 guys appeared and
immediately pushed me out without even having to ask, thankfully before
I managed to set fire to my clutch.</p>

<p>My experiences with the evil dry sand had therefore made the crossing
onto the track look a lot harder now. After scouting it out on
foot, I picked some promising looking ruts and charged � victory!</p>

<p>Once I got to the other end of the short overland track, I faced the
same dilemma � unfortunately this time the wet sand strip on the far
side of the mush was much smaller, so I waited for the tide to go out a
bit more (rather than risk charging headlong into the ocean, which would
have been a Bad Look indeed).</p>

<p>I helped push some other guys out while I waited, it was nice to see
people with actual 4WD vehicles can get stuck too. They took a look at
my car and said "you made it to here in THAT?!"</p>

<p>This crossing actually looked a lot hairier than the last, so I was
pretty pessimistic about my chances, even after my previous success, but
eventually I picked a path and charged, and made it.</p>

<p>There were plenty of people round each time anyway, and I could have
gotten towed out, but it would have been rather embarrassing. Once on
the dry I was fine all the way back as the tide was out. I've since seen
photos of what happens to cars that get stuck here when the tide comes
in - they basically get smashed to pieces on the rocks. Nice!</p>

<p>So all in all it was probably not the most sensible (practically or
environmentally) way to have gone, but it was a valuable learning
experience. Better to find out how easily my car gets bogged when
surrounded by people with tow ropes, than to find it out on some desert
track miles from nowhere (and yes this means I that shall be avoiding
said desert tracks :))</p>

<p>Now I've parked myself at the local caravan park, it's fine but the
mozzies are a bit nasty here. I'll hang for a day or two and investigate
the possibility of doing some diving. If it looks promising I'll do
that, if not I'll just head on, in the general direction of the exciting
metropolis known as Bundaberg.</p>

<p>Once again, I hope all is well in your worlds. I've had some requests
for a pic of the fully armed and operational vehicle, so they're
attached too. James - the platform is working fabulously, thanks again
so much for the help.</p>

<p>Thanks also go to Alan who just happened to be round when I desperately
needed an SMTP server, and he kindly obliged within seconds.</p>

<br><br>
All images in this gallery:<br>
<table width='800'>
<tr>
</tr>
<tr><td><A ID='IMG_2089.JPG' href='onward.php?fileId=IMG_2089.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050502/IMG_2089.JPG' ALT='The Nerdseyeviewmobile'><BR>The Nerdseyeviewmobile<br>109.51 KB</a><div class='inv'><br><a href='./images/20050502/IMG_2089.JPG' ALT='The Nerdseyeviewmobile'>The Nerdseyeviewmobile</a></div></td>
<td><A ID='IMG_2091.JPG' href='onward.php?fileId=IMG_2091.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050502/IMG_2091.JPG' ALT='The Nerdseyeviewmobile and bike'><BR>The Nerdseyeviewmobile and bike<br>99 KB</a><div class='inv'><br><a href='./images/20050502/IMG_2091.JPG' ALT='The Nerdseyeviewmobile and bike'>The Nerdseyeviewmobile and bike</a></div></td>
<td><A ID='IMG_2092.JPG' href='onward.php?fileId=IMG_2092.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050502/IMG_2092.JPG' ALT='Beach destruction in the Great Sandy National Park'><BR>Beach destruction in the Great Sandy National Park<br>51.31 KB</a><div class='inv'><br><a href='./images/20050502/IMG_2092.JPG' ALT='Beach destruction in the Great Sandy National Park'>Beach destruction in the Great Sandy National Park</a></div></td>
<td><A ID='IMG_2094.JPG' href='onward.php?fileId=IMG_2094.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050502/IMG_2094.JPG' ALT='Great Sandy National Park looking south with the Nerdseyeviewmobile'><BR>Great Sandy National Park looking south with the Nerdseyeviewmobile<br>48.38 KB</a><div class='inv'><br><a href='./images/20050502/IMG_2094.JPG' ALT='Great Sandy National Park looking south with the Nerdseyeviewmobile'>Great Sandy National Park looking south with the Nerdseyeviewmobile</a></div></td>
<td><A ID='IMG_2095.JPG' href='onward.php?fileId=IMG_2095.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050502/IMG_2095.JPG' ALT='Entrance to Red Canyon'><BR>Entrance to Red Canyon<br>112.77 KB</a><div class='inv'><br><a href='./images/20050502/IMG_2095.JPG' ALT='Entrance to Red Canyon'>Entrance to Red Canyon</a></div></td>
</tr>
<tr><td><A ID='IMG_2097.JPG' href='onward.php?fileId=IMG_2097.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050502/IMG_2097.JPG' ALT='Red Canyon, Great Sandy National Park'><BR>Red Canyon, Great Sandy National Park<br>91.9 KB</a><div class='inv'><br><a href='./images/20050502/IMG_2097.JPG' ALT='Red Canyon, Great Sandy National Park'>Red Canyon, Great Sandy National Park</a></div></td>
<td><A ID='IMG_2099.JPG' href='onward.php?fileId=IMG_2099.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050502/IMG_2099.JPG' ALT='Red Canyon, Great Sandy National Park'><BR>Red Canyon, Great Sandy National Park<br>86.48 KB</a><div class='inv'><br><a href='./images/20050502/IMG_2099.JPG' ALT='Red Canyon, Great Sandy National Park'>Red Canyon, Great Sandy National Park</a></div></td>
<td><A ID='IMG_2101.JPG' href='onward.php?fileId=IMG_2101.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050502/IMG_2101.JPG' ALT='Red Canyon, Great Sandy National Park'><BR>Red Canyon, Great Sandy National Park<br>78.5 KB</a><div class='inv'><br><a href='./images/20050502/IMG_2101.JPG' ALT='Red Canyon, Great Sandy National Park'>Red Canyon, Great Sandy National Park</a></div></td>
<td><A ID='IMG_2102.JPG' href='onward.php?fileId=IMG_2102.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050502/IMG_2102.JPG' ALT='Red Canyon, Great Sandy National Park'><BR>Red Canyon, Great Sandy National Park<br>67.44 KB</a><div class='inv'><br><a href='./images/20050502/IMG_2102.JPG' ALT='Red Canyon, Great Sandy National Park'>Red Canyon, Great Sandy National Park</a></div></td>
<td><A ID='IMG_2104.JPG' href='onward.php?fileId=IMG_2104.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050502/IMG_2104.JPG' ALT='Red Canyon, Great Sandy National Park'><BR>Red Canyon, Great Sandy National Park<br>85.58 KB</a><div class='inv'><br><a href='./images/20050502/IMG_2104.JPG' ALT='Red Canyon, Great Sandy National Park'>Red Canyon, Great Sandy National Park</a></div></td>
</tr>
<tr><td><A ID='IMG_2106.JPG' href='onward.php?fileId=IMG_2106.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050502/IMG_2106.JPG' ALT='Looking South, Great Sandy National Park'><BR>Looking South, Great Sandy National Park<br>71.81 KB</a><div class='inv'><br><a href='./images/20050502/IMG_2106.JPG' ALT='Looking South, Great Sandy National Park'>Looking South, Great Sandy National Park</a></div></td>
<td><A ID='IMG_2107.JPG' href='onward.php?fileId=IMG_2107.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050502/IMG_2107.JPG' ALT='Great Sandy National Park'><BR>Great Sandy National Park<br>64.88 KB</a><div class='inv'><br><a href='./images/20050502/IMG_2107.JPG' ALT='Great Sandy National Park'>Great Sandy National Park</a></div></td>
<td><A ID='IMG_2108.JPG' href='onward.php?fileId=IMG_2108.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050502/IMG_2108.JPG' ALT='Looking North, Great Sandy National Park'><BR>Looking North, Great Sandy National Park<br>51.97 KB</a><div class='inv'><br><a href='./images/20050502/IMG_2108.JPG' ALT='Looking North, Great Sandy National Park'>Looking North, Great Sandy National Park</a></div></td>
<td><A ID='IMG_2109.JPG' href='onward.php?fileId=IMG_2109.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050502/IMG_2109.JPG' ALT='Great Sandy National Park'><BR>Great Sandy National Park<br>65.7 KB</a><div class='inv'><br><a href='./images/20050502/IMG_2109.JPG' ALT='Great Sandy National Park'>Great Sandy National Park</a></div></td>
<td><A ID='IMG_2111.JPG' href='onward.php?fileId=IMG_2111.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050502/IMG_2111.JPG' ALT='Red Canyon, Great Sandy National Park'><BR>Red Canyon, Great Sandy National Park<br>74.83 KB</a><div class='inv'><br><a href='./images/20050502/IMG_2111.JPG' ALT='Red Canyon, Great Sandy National Park'>Red Canyon, Great Sandy National Park</a></div></td>
</tr>
<tr><td><A ID='IMG_2116.JPG' href='onward.php?fileId=IMG_2116.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050502/IMG_2116.JPG' ALT='Surfing off the headland, Great Sandy National Park'><BR>Surfing off the headland, Great Sandy National Park<br>59.67 KB</a><div class='inv'><br><a href='./images/20050502/IMG_2116.JPG' ALT='Surfing off the headland, Great Sandy National Park'>Surfing off the headland, Great Sandy National Park</a></div></td>
<td><A ID='IMG_2118.JPG' href='onward.php?fileId=IMG_2118.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050502/IMG_2118.JPG' ALT='Carlo Sandblow, Rainbow Beach'><BR>Carlo Sandblow, Rainbow Beach<br>42.16 KB</a><div class='inv'><br><a href='./images/20050502/IMG_2118.JPG' ALT='Carlo Sandblow, Rainbow Beach'>Carlo Sandblow, Rainbow Beach</a></div></td>
<td><A ID='IMG_2120.JPG' href='onward.php?fileId=IMG_2120.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050502/IMG_2120.JPG' ALT='Carlo Sandblow, Rainbow Beach'><BR>Carlo Sandblow, Rainbow Beach<br>58.57 KB</a><div class='inv'><br><a href='./images/20050502/IMG_2120.JPG' ALT='Carlo Sandblow, Rainbow Beach'>Carlo Sandblow, Rainbow Beach</a></div></td>
<td><A ID='IMG_2121.JPG' href='onward.php?fileId=IMG_2121.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050502/IMG_2121.JPG' ALT='Carlo Sandblow, Rainbow Beach'><BR>Carlo Sandblow, Rainbow Beach<br>40.86 KB</a><div class='inv'><br><a href='./images/20050502/IMG_2121.JPG' ALT='Carlo Sandblow, Rainbow Beach'>Carlo Sandblow, Rainbow Beach</a></div></td>
<td><A ID='IMG_2122.JPG' href='onward.php?fileId=IMG_2122.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050502/IMG_2122.JPG' ALT='Carlo Sandblow, Rainbow Beach'><BR>Carlo Sandblow, Rainbow Beach<br>45.82 KB</a><div class='inv'><br><a href='./images/20050502/IMG_2122.JPG' ALT='Carlo Sandblow, Rainbow Beach'>Carlo Sandblow, Rainbow Beach</a></div></td>
</tr>
<tr><td><A ID='IMG_2123.JPG' href='onward.php?fileId=IMG_2123.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050502/IMG_2123.JPG' ALT='Carlo Sandblow, Rainbow Beach'><BR>Carlo Sandblow, Rainbow Beach<br>62.76 KB</a><div class='inv'><br><a href='./images/20050502/IMG_2123.JPG' ALT='Carlo Sandblow, Rainbow Beach'>Carlo Sandblow, Rainbow Beach</a></div></td>
<td><A ID='IMG_2124.JPG' href='onward.php?fileId=IMG_2124.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050502/IMG_2124.JPG' ALT='Rain on the swimming pool, Rainbow Beach'><BR>Rain on the swimming pool, Rainbow Beach<br>59.3 KB</a><div class='inv'><br><a href='./images/20050502/IMG_2124.JPG' ALT='Rain on the swimming pool, Rainbow Beach'>Rain on the swimming pool, Rainbow Beach</a></div></td>
<td><A ID='IMG_2128.JPG' href='onward.php?fileId=IMG_2128.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050502/IMG_2128.JPG' ALT='Welcome Swallow, Rainbow Beach'><BR>Welcome Swallow, Rainbow Beach<br>41.75 KB</a><div class='inv'><br><a href='./images/20050502/IMG_2128.JPG' ALT='Welcome Swallow, Rainbow Beach'>Welcome Swallow, Rainbow Beach</a></div></td>
<td><A ID='IMG_2130.JPG' href='onward.php?fileId=IMG_2130.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050502/IMG_2130.JPG' ALT='Sparrow, Rainbow Beach'><BR>Sparrow, Rainbow Beach<br>43.96 KB</a><div class='inv'><br><a href='./images/20050502/IMG_2130.JPG' ALT='Sparrow, Rainbow Beach'>Sparrow, Rainbow Beach</a></div></td>
<td><A ID='IMG_2131.JPG' href='onward.php?fileId=IMG_2131.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050502/IMG_2131.JPG' ALT='Sparrow, Rainbow Beach'><BR>Sparrow, Rainbow Beach<br>47.28 KB</a><div class='inv'><br><a href='./images/20050502/IMG_2131.JPG' ALT='Sparrow, Rainbow Beach'>Sparrow, Rainbow Beach</a></div></td>
</tr>
</table>	</div>
</div>
</body>
</html>