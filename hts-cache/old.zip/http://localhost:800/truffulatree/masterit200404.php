<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - April 2004 - Q&A letters</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="Q&A letters">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="Q&A letters" href='masterit200401.php'>January 2004</a></li>
<li><a title="Q&A letters" href='masterit200402.php'>February 2004</a></li>
<li><a title="Q&A letters" href='masterit200403.php'>March 2004</a></li>
<li><div class='activemenu'>April 2004</div></li>
<li><a title="Q&A letters" href='masterit200405.php'>May 2004</a></li>
<li><a title="Q&A letters" href='masterit200406.php'>June 2004</a></li>
<li><a title="Q&A letters" href='masterit200407.php'>July 2004</a></li>
<li><a title="Q&A letters" href='masterit200408.php'>August 2004</a></li>
<li><a title="Q&A letters" href='masterit200409.php'>September 2004</a></li>
<li><a title="Q&A letters" href='masterit200410.php'>October 2004</a></li>
<li><a title="Q&A letters" href='masterit200411.php'>November 2004</a></li>
<li><a title="Q&A letters" href='masterit200412.php'>December 2004</a></li>
<li> </li><br><li>Or go back to:</li><li><a title='Q&A/MasterIT letters from 2004' href="masterit2004.php">2004 archive</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>April 2004</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Mark's writing' href="written.php">Professional Writing</a> > <a title='My weekly Q&A column in The Australian' href="masterIT.php">MasterIT</a> > <a title='Q&A/MasterIT letters from 2004' href="masterit2004.php">2004 archive</a> > <a title='Q&A letters' href="masterit200404.php">April 2004</a>
<br><br>		<br>
<h2>6/4/04</h2><br>
<b>On my HP pav 721 with XP home I get a constant stream of crashes followed by auto reboots and the "Windows has recovered from a serious error" message. On sending them the Microsoft online crash analysis says the problem is caused by a device driver but cannot determine the precise cause. I have not installed any new hardware or software recently. Device Manager shows all drivers are working properly and there are no updates available on the update site. Any suggestions?</b><br>
<br>
The fact that you've not installed any new hardware or software recently points to a hardware failure of some sort.<br>
<br>
Of course, the Master could be completely wrong, and it could be a software problem. Before you start crawling around under desks and the like, double check Device Manager, and enable the viewing of hidden devices (View->Show Hidden Devices). <br>
<br>
Also, disable the reboot-after-bluescreen feature (Control Panel->System->Advanced->Error Reporting), and make a note of the particular file/device that is crashing, as you might be able to trace it back to a specific piece of hardware or software.<br>
<br>
If it is a hardware problem, it could be anything from flaky ram to a dying power supply, so you want to try and narrow it down with a process of elimination.<br>
<br>
Start off by making sure it's not a heat-related fault. If the computer runs fine when first switched on and then starts crashing later this is your prime candidate. Check that all the various fans inside are still working properly; it could be something as simple as a large Easter Dust Bunny on the CPU or graphics card cooler (note that these are the least tasty variety of bunny).<br>
<br>
Barring anything thermal, check that all the computer's internals are firmly in place, including power cables, data cables, coolers and expansion cards. The latter two can be given a gentle wiggle to make sure they're still making good contact, as can memory modules.<br>
<br>
Be careful though, as computer guts are often mechanically quite delicate, and most things are sensitive to static electricity, so work with your shoes off (note to techies - this is an excellent justification for walking around the office barefoot).<br>
<br>
<br>
<h2>13/4/04</h2><br>
<b>I've been puzzled by something for a while. We take the magic of ZIP and JPG files for granted, but I'd like to know how they make data smaller. I have a vague feeling for the idea (something to do with redundant data being omitted), but I just don't grock it.</b><br>
<br>
The short answer is that it's all thanks to Nasty Maths. First though it's important to distinguish between two types of files compression: lossy and non-lossy.<br>
<br>
The two names pretty much describe the difference - lossy compression works by throwing away data that you (in theory) won't miss. This is fine for images and sounds but not for other data.<br>
<br>
Non-lossy compression has been around for years, and the ubiquitous ZIP file is probably the most well known example of the idea these days. The ZIP algorithm itself is a pretty complicated piece of maths (look up the "deflate" algorithm if you dare), but to illustrate the concept we can go with the simplest form of file compression, run length encoding (RLE).<br>
<br>
Take for example a blob of data, 00111111. This took 8 digits to represent. Now imagine that instead we store the data in code that simply says "two zeros and six ones". It takes less space to represent and we can re-create our original data with no information lost, but at the cost of some computation to decode it.<br>
<br>
As you may guess, data with repeating patterns compresses much more efficiently, hence the reason text files compress much better than programs.<br>
<br>
Lossy compression is a completely different beastie. It's used in JPG image files, MP3 audio files and various video file formats (to name a few). The mechanics of each media type are different, but the principle is the same - information is simplified in a way that the brain doesn't notice (much), provided you don't take too much away.<br>
<br>
For example, in the case of a picture fine detail might be omitted. Omit too much and you'll notice. Omit just the right amount and you can save a goodly amount of space.<br>
<br>
Of course, this is just scratching the surface of a very complicated subject. You can sink your teeth in at <a href="http://tinyurl.com/3y6u9" target="_blank">http://tinyurl.com/3y6u9</a> and <a href="http://tinyurl.com/2hq9r" target="_blank">http://tinyurl.com/2hq9r</a><br>
<br>
<br>
<h2>20/4/04</h2><br>
<b>My bloody Windows Media Player keeps crashing. It used to work just fine - now it hangs about 3 seconds into playback of anything (audio or video). Funny thing is the playback continues just fine; but the program is unresponsive. Any ideas? It's version 9 by the way.</b><br>
<br>
It sounds like your media library has been corrupted. You can try deleting it from "Documents and Settings{your login}Local SettingsApplication DataMicrosoftMedia Player". Unfortunately of course this means that all your library information will be gone too, but you should be able to rebuild it fairly easily.<br>
<br>
And now for the usual anti-Microsoft pontificating - you might also like to try another player like Winamp (2 or 5), iTunes or Musicmatch (especially for audio). Windows Media Player is fine for a quick-and-dirty video player, but it's media library really bogs down when you feed it a large amount of information.<br>
<br>
<br>
<b>When I attempt to defrag my computer, the process reaches the stage of being 15% through, then freezes. I have tried leaving the computer running overnight to no avail. Norton does not reveal any problems. Can you offer any advice?<br>
 <br>
I am in my late 60's, not very computer literate, just trying to pick up what I can through articles, newspapers and the like. I enjoy reading IT Alive each week but am often at a loss to know what some of the abbreviations stand for and their meaning. For example in today's edition: WMA; MP3; PDA's to name a few, but this happens to me every week. If there is a source that you can direct me to that can help me, I would be very appreciative.</b><br>
<br>
Regarding the defrag, this appears to be a common problem with earlier versions of Windows - try running it after starting in Safe Mode (see tinyurl.com/2xde for information on how to do this).<br>
<br>
As far as the jargon goes, you're not alone. The Master even had to look up what PDA stood for again ("Personal Digital Assistant", one for the Wank File); new terms and acronyms pop their heads up almost daily.<br>
<br>
Two excellent sites for de-mystifying just about everything are <a href="wikipedia.org" target="_blank">Wikipedia</a> and <a href="everything2.com" target="_blank">everything2</a>. There's also a lot of general hacker culture and jargon explained at tinyurl.com/2j3hw.<br>
<br>
<br>
<h2>27/4/04</h2><br>
<b>Dear Master, certain friends of mine insist on sending me various "chain" style emails with assorted warnings about viruses, tales about giant bears (and sharks), sickeningly cute (yet dubious) friendship stories, as well as links to websites stating that I should have died years ago for eating various things. Is there a good website out there that I can use to debunk or confirm these things?</b><br>
<br>
For debunking many of the usual chain emails you want to go straight to snopes.com. Just look up the topic with a few select keywords and smugly send an email back to your friends. For things of a medical nature you might also like to poke around quackwatch.org.<br>
<br>
Unfortunately discouraging the cute teddy-bear-emails is never easy with some people; as least not without coming across as rude, or as having Asperger Syndrome. Bouncing said emails with a program like Mailwasher is also considered impolite, and will generally lead to confusion. As always, the delete key is your friend. Rolling your eyes is optional.<br>
<br>
<br>
<b>I remember reading that someone was up in arms about "master/slave" hard drive terminology. It got me wondering - why do we need to set up drives this way? And do SATA drives have the same problem?</b><br>
<br>
The whole master/slave thing is a peculiarity of the IDE hard drive interface. Much of the IDE controller hardware sits on the drive's controller board itself, and not on the motherboard, so when you have two drives set up on your IDE cable you need to deactivate one of the controllers, as they don't play well together. The "master" drive's controller then controls both drives. Incidentally, this is why if you stick two CD drives on one IDE cable, and one bogs down with a bad CD, they both tend to bog down.<br>
<br>
Serial ATA drives are set up in a one-cable-one-drive way, so the master/slave setting is obsolete. SCSI drives also don't have this problem (as they have much smarter controllers), although they do need to have a unique address configured.<br>
<br>
And yes, the master/slave terminology itself was recently requested by LA County to be avoided, prompting a certain amount of outrage. Good old Snopes has a summary at snopes.com/inboxer/outrage/master.asp.<br>
<br>
<br>
Send queries and the fingers of chain letter forwarders to <a href="contact.php?subject=MasterIT">(the masterit contact email address)</a><br>
<br>
<i><p>Did the information on this page help you? Entertain you? Bore you? <a href="contact.php?subject=MasterIT">Drop me a line</a>.</p>

<p>If you're feeling particularly generous, you can even <a href="buypics.php">click here to send me some dot-com riches</a>. Think of it as online busking.</i></p>
	</div>
</div>
</body>
</html>