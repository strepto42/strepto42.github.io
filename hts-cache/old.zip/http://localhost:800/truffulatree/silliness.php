<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - Silliness - Silly things for your amusement</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="Silly things for your amusement">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="truffulatree.com.au homepage" href="home.php">Home</a></li>
<li> </li><br>
<li><a title="About me" href='about.php'>About</a></li>
<li><a title="Picture galleries" href='pictures.php'>Photography</a></li>
<li><a title="Travel stories and pictures" href='travel.php'>Travelogues</a></li>
<li><a title="Mark's writing" href='written.php'>Professional Writing</a></li>
<li><a title="Programming work I've done" href='programming.php'>Programming</a></li>
<li><a title="Sounds and music" href='music.php'>Music</a></li>
<li><div class='activemenu'>Silliness</div></li>
<ul>
<li><a title="A page dedicated to the worst Optimus Prime outfits on the net" href='badoptimus.php'>Bad Optimus</a></li>
<li><a title="WD40 cans going whoosh and Sparkler Bomb videos" href='wd40.php'>WD40</a></li>
<li><a title="2weeks.com internet art concept site" href='2weeks.php'>2weeks.com</a></li>
<li><a title="A pong game featuring Rudi Mueller's head by John Hawkins" href='rudipong.php'>Rudipong</a></li>
<li><a title="The Random Domain Name Game" href='rdng.php'>RDNG</a></li>
<li><a title="Various animations for download" href='anims.php'>Animations</a></li>
<li><a title="Arnold Schwarzenegger and Michael Jackson soundboards" href='soundboards.php'>Soundboards</a></li>
</ul>
<li><a title="Old stuff from my site" href='archive.php'>Archive</a></li>
<li><a title="Contact me" href='contact.php'>Contact</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>Silliness</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Silly things for your amusement' href="silliness.php">Silliness</a>
<br>Select a link on the left to continue navigating.<br><br>		<br>
Here are some silly things for your amusement.<br>
<br>
Rudipong is dedicated to our former former Sysadmin, Rudi. You need a fairly recent JVM to run it properly, or the sounds don't work. Be warned though, once they start, they may not stop! ;)<br>
<br>
RDNG is the Random Domain Name Game.<br>
<br>
<a href="http://www.2weeks.com">2weeks.com</a> is our very own Random Domain, and is what the Internet is all about.<br>
<br>
Bad Optimus is a page dedicated to the worst Optimus Prime suits we could find with Google's image search.<br>
<br>
The WD40 page is a legacy of my old Pyro days, and has some cool <a href="http://www.dansdata.com/personal/Bombs.html" target="_blank">Sparkler Bomb</a> videos. Ironically it get more hits than any other page on this site, especially from dimwit Yanks around the Fourth of July.<br>
<br>
Enjoy!<br>


	</div>
</div>
</body>
</html>