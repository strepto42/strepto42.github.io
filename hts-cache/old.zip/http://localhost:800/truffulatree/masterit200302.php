<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - February 2003 - Q&A letters</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="Q&A letters">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="Q&A letters" href='masterit200301.php'>January 2003</a></li>
<li><div class='activemenu'>February 2003</div></li>
<li><a title="Q&A letters" href='masterit200303.php'>March 2003</a></li>
<li><a title="Q&A letters" href='masterit200304.php'>April 2003</a></li>
<li><a title="Q&A letters" href='masterit200305.php'>May 2003</a></li>
<li><a title="Q&A letters" href='masterit200306.php'>June 2003</a></li>
<li><a title="Q&A letters" href='masterit200307.php'>July 2003</a></li>
<li><a title="Q&A letters" href='masterit200308.php'>August 2003</a></li>
<li><a title="Q&A letters" href='masterit200309.php'>September 2003</a></li>
<li><a title="Q&A letters" href='masterit200310.php'>October 2003</a></li>
<li><a title="Q&A letters" href='masterit200311.php'>November 2003</a></li>
<li><a title="Q&A letters" href='masterit200312.php'>December 2003</a></li>
<li> </li><br><li>Or go back to:</li><li><a title='Q&A/MasterIT letters from 2003' href="masterit2003.php">2003 archive</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>February 2003</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Mark's writing' href="written.php">Professional Writing</a> > <a title='My weekly Q&A column in The Australian' href="masterIT.php">MasterIT</a> > <a title='Q&A/MasterIT letters from 2003' href="masterit2003.php">2003 archive</a> > <a title='Q&A letters' href="masterit200302.php">February 2003</a>
<br><br>		<br>
<h2>4/2/03</h2><br>
<b>I have recently changed to windows XP from 98 and the autorun feature on my games no longer functions. Is there some way of enabling this?</b><br>
<br>
Autorun in XP is a little more complex than in previous versions of windows. The easiest way to enable it is by installing TweakUI, which can be downloaded here: <br>
<br>
<a href="http://www.microsoft.com/windowsxp/pro/downloads/powertoys.asp" target="_blank">http://www.microsoft.com/windowsxp/pro/downloads/powertoys.asp</a><br>
<br>
TweakUI is a nifty little package that will let you configure all sorts of hidden settings, including Autorun, which can be found under the "My Computer -> Autoplay" branch. Make sure that your CDROM drive letter is selected under "drives", as well as enabling the setting in "types".<br>
<br>
<br>
<b>My computer OS is Win98SE. Every time when I start Windows, the computer freezes. The frustrating result is that I have to press the reset button a couple of times before I can get to my desktop. Is there something that I can do to fix this problem? Grateful if you can offer advice.</b><br>
<br>
A number of things can cause this sort of behaviour; unfortunately there's no easy fix, and you'll just have to try things one at a time to work out what the problem is. The first step is to work out if the problem is caused by your hardware or software.<br>
<br>
A fairly standard approach (and a favourite of Microsoft Technical Support) is to reinstall Windows. This sounds like a bit of a cop out, but earlier versions of windows, namely 95, 98 and ME do "go rotten" after a while, and a reinstall will often fix things up.<br>
<br>
You can reinstall without losing all your settings by putting in the Windows CD once Windows has already started and running Setup. Specify that you want to upgrade rather than perform a fresh install.<br>
<br>
You should also make sure you have the most up to date drivers for your hardware. Drivers supplied on CD are rarely the most current; go to the manufacturer's website to get the most up to date version.<br>
<br>
If this doesn't help, the problem could be hardware related. A common candidate for freezes on startup is a faulty power supply, but bad RAM or a loose component (such as an expansion card or the CPU cooler) could also be to blame, especially if the computer freezes at other times.<br>
<br>
<br>
<h2>11/2/03</h2><br>
<b>What software will I need to network a Mac running OSX with a W2K PC? Where can I find some details instructions on how to do it? </b><br>
<br>
Traditionally, getting Macs and PCs talking is a fiddly operation. MacOS has no native support for NetBIOS (Microsoft's networking "language"), and so to have proper Windows network connectivity you'll need to install some third party software on the Mac.<br>
<br>
One popular and solid choice that's been around for a while is a package called Dave (<a href="http://www.thursby.com" target="_blank">www.thursby.com</a>). It supports multiple versions of Mac OS, including OSX. Be prepared for some sticker shock though - a single license will set you back $US149.<br>
<br>
For more general information on Mac-PC interaction, check out <a href="http://www.macwindows.com" target="_blank">www.macwindows.com</a>.<br>
 <br>
<br>
<b>How should one go about cleaning up a PC after months of general use and browsing to restore performance? Is it even worth the trouble?</b><br>
<br>
A well-used Windows installation will indeed accumulate a fair bit of crud over time. Whether or not it is worth the trouble of cleaning this up depends on your point of view.<br>
<br>
Newer PCs are extremely fast, and have heaps more storage space than their counterparts from a few years ago, so often any performance gain to be had by cleaning up a well-used PC will be negligible.<br>
<br>
If your PC is a few years old though - or if you're like us here at MasterIT (where it's simply the principle of the thing) - two easy things that will help clean up your PC.<br>
<br>
First up, run the Disk Cleanup Wizard, located in the Start Menu under Accessories->System Tools->Disk Cleanup. After thinking for a while, Windows will give you a bunch of options for cleaning up various temporary files.<br>
<br>
Once this completes, you may also like to run the Disk Defragmenter (located in the same menu).<br>
<br>
Defragmenting your disk should make Windows, and programs in general, start slightly more quickly, however bear in mind that your mileage may vary. <br>
<br>
Also remember that it's always a good idea to back up your data before defragmenting, as a power outage in the middle of a defrag can be disastrous.<br>
<br>
<br>
<h2>18/2/03</h2><br>
<b>I'm frustrated with Microsoft Word. It insists on changing what I type all the time. For example, when I try to make a list of points it insists on indenting the text and using it's own styles. How do I turn off this annoying behaviour?</b><br>
<br>
Word is famous for this sort of thing; it will routinely interfere with what you're trying to do in the name of making life easier.<br>
<br>
Sometimes, it uses its power for good, like when it automatically replaces common mistakes (like "teh" with "the"), but mostly Word uses its power for evil, or at least irritation. The universally loved paper clip and unwanted bullet lists are just the tip of the iceberg.<br>
<br>
Thankfully, all this "help" can be turned off. Go to the Tools menu and select AutoCorrect. Most of the options in here are self-explanatory - at the least, you'll probably want to disable a few items under the AutoFormat As You Type tab.<br>
<br>
<br>
<b>Does Win98 support those little tiny removable USB storage devices? It certainly doesn't have them listed in its range of default drivers.</b><br>
<br>
It depends on the device in question. Your best bet is to check the manufacturer's website before purchase.<br>
<br>
A quick check with Google revealed quite a few devices that have drivers for Win98.<br>
<br>
<br>
<b>What is it with Word 2000, that whenever you want to select text that spreads across more than one page, the thing goes into hyperdrive and selects the next thirty or so pages before it can be yanked back. It drives me practically insane. Is there a way to stop if from overdoing its job?</b><br>
<br>
Once again, we're Feeling the Love with MS Word. Unfortunately, there doesn't seem to be a solution to this.<br>
<br>
The problem is that Word - and many other Windows applications - seem to go very quickly from barely scrolling mode to hyperdrive mode when you try to select text.<br>
<br>
The best one can do is to move the mouse very carefully when one nears the bottom of the screen (and enters the area where things start to scroll), and try to find a sweet spot for scrolling speed.<br>
<br>
<br>
<h2>25/2/03</h2><br>
<b>I've recently discovered the joys of instant messaging. The only problem is half my friends use MSN Messenger whilst others use ICQ and AOL. Is there some program I can use to talk to people on all these systems without having to install all the different programs?</b><br>
<br>
There are indeed programs that will let you do this. A couple of popular choices are Trillian (found at <a href="http://www.ceruleanstudios.com" target="_blank">www.ceruleanstudios.com</a>) and Gaim (<a href="http://gaim.sourceforge.net" target="_blank">gaim.sourceforge.net</a>).<br>
<br>
Trillian is a Windows-only product, whereas Gaim is an Open Source project and can be used with Linux (and maybe even Macs running OSX - no guarantees though) as well as Windows. Both programs support a variety of instant messaging protocols, including Yahoo, ICQ, MSN, AOL, and even IRC.<br>
<br>
They also have some nifty features that the original programs lack, like the ability to log in using multiple identities at the same time, and window transparency for that extra bit of subtlety while you chat your working day away.<br>
<br>
<br>
<b>My friend told me the other day that you can get a virus without even opening an email - all you have to do is receive it! Is this true? I always thought that you had to actively open an infected email before you could get one.</b><br>
<br>
It's not possible to become infected just by receiving an email. Unfortunately, it IS possible to get a virus just by opening an email.<br>
<br>
It all depends on which email program you use, and which virus we're talking about.<br>
<br>
Outlook and Outlook Express are probably the worst and most exploited email clients as far as viruses go. Most of the worst viruses and worms from the last few years have exploited the ability of Outlook to run complex and powerful scripts just by having the user open an attachment (or even just be previewing the email in a few nasty cases).<br>
<br>
Netscape Messenger and Mozilla are less vulnerable, but they still support more primitive scripting in emails, and you can't let your guard down entirely.<br>
<br>
As always, the best solutions are prevention (in the form of a good anti-virus program with up to date virus data) and common sense (in the form of not opening suspicious emails or attachments).<br>
<br>
<i><p>Did the information on this page help you? Entertain you? Bore you? <a href="contact.php?subject=MasterIT">Drop me a line</a>.</p>

<p>If you're feeling particularly generous, you can even <a href="buypics.php">click here to send me some dot-com riches</a>. Think of it as online busking.</i></p>
	</div>
</div>
</body>
</html>