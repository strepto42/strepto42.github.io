<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - 23/5/2005 - It's a tough life (pt 2: Rockhampton, Emu Park and Great Keppel Island)</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="It's a tough life (pt 2: Rockhampton, Emu Park and Great Keppel Island)">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="Greetings from a Bum" href='greetingsfromabum.php'>29/4/2005</a></li>
<li><a title="Onward" href='onward.php'>2/5/2005</a></li>
<li><a title="It's a tough life (pt 1: Bundaberg, Agnes Water and 1770)" href='itsatoughlife1.php'>17/5/2005</a></li>
<li><div class='activemenu'>23/5/2005</div></li>
<li><a title="There and Back Again - a Yo-yo's Tale" href='thereandbackagain.php'>18/6/2005</a></li>
<li><a title="Platypi and Grey Nomads" href='platypiandgreynomads.php'>24/6/2005</a></li>
<li><a title="Blowing Bubbles in a Watery Tomb" href='blowingbubbles.php'>1/7/2005</a></li>
<li><a title="Pieces of History" href='piecesofhistory.php'>8/7/2005</a></li>
<li><a title="Walks and Waterfalls" href='walksandwaterfalls.php'>15/7/2005</a></li>
<li><a title="Mission to Tribulation" href='missiontotribulation.php'>22/7/2005</a></li>
<li><a title="Levity, Limestone and Lava" href='levitylimestoneandlava.php'>29/7/2005</a></li>
<li><a title="Into the Never Never" href='intothenevernever.php'>5/8/2005</a></li>
<li><a title="Slowing the pace in Darwin" href='slowingthepaceindarwin.php'>12/8/2005</a></li>
<li><a title="Blistering Barnacles and Leaping Lizards" href='leapinglizards.php'>19/8/2005</a></li>
<li><a title="Kakadu and Litchfield" href='kakadu.php'>26/8/2005</a></li>
<li><a title="Legacies of War" href='legaciesofwar.php'>2/9/2005</a></li>
<li><a title="Go West" href='gowest.php'>10/9/2005</a></li>
<li><a title="Things from Above" href='thingsfromabove.php'>16/9/2005</a></li>
<li><a title="The West Coast" href='thewestcoast.php'>23/9/2005</a></li>
<li><a title="Reefs and Red Dust" href='reefsandreddust.php'>30/9/2005</a></li>
<li><a title="The Pilbara" href='pilbara.php'>7/10/2005</a></li>
<li><a title="Paradise with a Headwind" href='paradisewithaheadwind.php'>14/10/2005</a></li>
<li><a title="Down the Coral Coast" href='downthecoralcoast.php'>21/10/2005</a></li>
<li><a title="Pinnacles and Pinnipeds" href='pinnaclesandpinnipeds.php'>28/10/2005</a></li>
<li><a title="A week in Perth" href='perth.php'>4/11/2005</a></li>
<li><a title="The Southwest (from Above and Below)" href='thesouthwest.php'>11/11/2005</a></li>
<li><a title="More Heights and Depths" href='moreheightsanddepths.php'>18/11/2005</a></li>
<li><a title="Across the Nullarbor (and a bit beyond)" href='nullarbor.php'>25/11/2005</a></li>
<li><a title="Double Whammy" href='doublewhammy.php'>9/12/2005</a></li>
<li><a title="Two Cities" href='twocities.php'>19/12/2005</a></li>
<li><a title="Tassie - Part 1" href='tassie1.php'>1/1/2006</a></li>
<li><a title="Tassie - Part 2" href='tassie2.php'>7/1/2006</a></li>
<li><a title="Full Circle" href='fullcircle.php'>26/1/2006</a></li>
<li><a title="The Wrap Up" href='thewrapup.php'>23/3/2006</a></li>
<li> </li><br><li>Or go back to:</li><li><a title='Travelouges and blogs from my trip around Australia' href="nerdseyeview.php">Nerd's Eye View</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>23/5/2005</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Travel stories and pictures' href="travel.php">Travelogues</a> > <a title='Travelouges and blogs from my trip around Australia' href="nerdseyeview.php">Nerd's Eye View</a> > <a title='It's a tough life (pt 2: Rockhampton, Emu Park and Great Keppel Island)' href="itsatoughlife2.php">23/5/2005</a>
<br><br>		


<h1>It's a tough life (pt 2: Rockhampton, Emu Park and Great Keppel Island)</h1>

<a href="images/maps/Map050523.gif"><img src="images/maps/Map050523_sm.gif" align="right"></a>
<p>...continued from <a href="itsatoughlife1.php">Part 1</a> (well, duh)</p>

<p>I was starting to grow roots in Agnes, so I decided it was time to move on. I drove to Rockhampton, and ended up sleeping in the car, as I got in rather late. As a result, I was woken up by the sun fairly early, so I went for a drive and explored the town (which didn't take long).</p>

<p>I happened upon a strange structure in the river � the Fitzroy River Barrage. Took some arty photos, one of which is attached. It rather reminded me of something from Half Life 2, for those who know it. Thankfully, the tranquil morning was not spoiled by large striding tripod aliens with huge guns and bad attitudes. (non-nerds, just ignore and keep reading).</p>

<p>Rocky isn't actually that exciting though, so I moved on, to a spot called Emu Park, which is quiet and coastal basically. There is a memorial to Capatain Cook here which has tuned pipes as part of it's structure, so it sings dolefully when the wind blows.</p>

<p>From there I hopped over to Great Keppel Island, where I was originally going for one night. In the end I spent four days and three nights there.</p>

<p>Great Keppel is, basically, bloody paradise. I was lucky with the weather (it was perfect, thank you very much), but nonetheless, everywhere you looked was a postcard.</p>

<p>I basically spent the time snorkelling in the sun, lying in the sun, walking on largely deserted and untouched beaches, watching the sunsets (each more gorgeous than the last), and relaxing in the evening with some of the best pizza I've ever had, and a few beers.</p>

<p>The snorkelling is amazing there � there's no need to dive as you can just swim over reef, which is like being in an aquarium full of tropical fish.</p>

<p>I lost count of how many turtles I saw � including plenty that were not at all worried about me diving down and hanging out next to them. I also saw a Leopard Shark (<a target="_blank" href="http://tinyurl.com/9wfb5">http://tinyurl.com/9wfb5</a>), more stingrays than I can count (including some big buggers � but I still haven't seen a Manta), and squillions of fish, big and small. And of course, nice coral.</p>

<p>I spent one of the four days trekking across to the far side of the island with a couple of other guys. We had a beach all to ourselves with a fantastic bit of reef (photo attached to annoy you). It was quite a mission as the island is big and hilly in places, but well worth it. The phrase "how's the serenity..." came to mind often.</p>

<p>Anyway, that's me pretty much up to date. I'm starting to get used to this tropical paradise nonsense, even if the east coast is one big backpacker train between Cairns and Sydney (I keep running into the same people again and again). It'll be nice to get of the beaten track a little, but for now, hell, life is pretty good.</p>

<p>I've also finally gotten off my bum and stuck up some content on my website. See - well, here really! Each time I send an email, it'll end up here too � with more photos to annoy you. If you'd like a full size version of any of my pics, just let me know. Carl - I shall also post the emails and pics on your site when I get a chance.</p>

<p>You may also have noticed that I've put Google ads on my site, in an effort to sell out and generally cheapen myself morally, whilst richening myself financially. So far it's going fantastically - I'm apparently $US2.67 richer. At this rate, within a few thousand years, I'll never have to work again. </p>

<p>Anyway, hope all is well back in the world. Once again, feel free to write to me. </p>

<br><br>
All images in this gallery:<br>
<table width='800'>
<tr>
</tr>
<tr><td><A ID='IMG_2400.JPG' href='itsatoughlife2.php?fileId=IMG_2400.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050523/IMG_2400.JPG' ALT='Fitzroy River Barrage, Rockhampton'><BR>Fitzroy River Barrage, Rockhampton<br>65.58 KB</a><div class='inv'><br><a href='./images/20050523/IMG_2400.JPG' ALT='Fitzroy River Barrage, Rockhampton'>Fitzroy River Barrage, Rockhampton</a></div></td>
<td><A ID='IMG_2403.JPG' href='itsatoughlife2.php?fileId=IMG_2403.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050523/IMG_2403.JPG' ALT='Fitzroy River Barrage, Rockhampton'><BR>Fitzroy River Barrage, Rockhampton<br>74.26 KB</a><div class='inv'><br><a href='./images/20050523/IMG_2403.JPG' ALT='Fitzroy River Barrage, Rockhampton'>Fitzroy River Barrage, Rockhampton</a></div></td>
<td><A ID='IMG_2404.JPG' href='itsatoughlife2.php?fileId=IMG_2404.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050523/IMG_2404.JPG' ALT='The Fitzroy River Barrage, Rockhampton'><BR>The Fitzroy River Barrage, Rockhampton<br>83.77 KB</a><div class='inv'><br><a href='./images/20050523/IMG_2404.JPG' ALT='The Fitzroy River Barrage, Rockhampton'>The Fitzroy River Barrage, Rockhampton</a></div></td>
<td><A ID='IMG_2407.JPG' href='itsatoughlife2.php?fileId=IMG_2407.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050523/IMG_2407.JPG' ALT='Fitzroy River Barrage, Rockhampton'><BR>Fitzroy River Barrage, Rockhampton<br>68.02 KB</a><div class='inv'><br><a href='./images/20050523/IMG_2407.JPG' ALT='Fitzroy River Barrage, Rockhampton'>Fitzroy River Barrage, Rockhampton</a></div></td>
<td><A ID='IMG_2408.JPG' href='itsatoughlife2.php?fileId=IMG_2408.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050523/IMG_2408.JPG' ALT='Fitzroy River Barrage, Rockhampton'><BR>Fitzroy River Barrage, Rockhampton<br>62.45 KB</a><div class='inv'><br><a href='./images/20050523/IMG_2408.JPG' ALT='Fitzroy River Barrage, Rockhampton'>Fitzroy River Barrage, Rockhampton</a></div></td>
</tr>
<tr><td><A ID='IMG_2410.JPG' href='itsatoughlife2.php?fileId=IMG_2410.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050523/IMG_2410.JPG' ALT='Fitzroy River Barrage, Rockhampton'><BR>Fitzroy River Barrage, Rockhampton<br>68.81 KB</a><div class='inv'><br><a href='./images/20050523/IMG_2410.JPG' ALT='Fitzroy River Barrage, Rockhampton'>Fitzroy River Barrage, Rockhampton</a></div></td>
<td><A ID='IMG_2412.JPG' href='itsatoughlife2.php?fileId=IMG_2412.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050523/IMG_2412.JPG' ALT='Fitzroy River Barrage, Rockhampton'><BR>Fitzroy River Barrage, Rockhampton<br>81.82 KB</a><div class='inv'><br><a href='./images/20050523/IMG_2412.JPG' ALT='Fitzroy River Barrage, Rockhampton'>Fitzroy River Barrage, Rockhampton</a></div></td>
<td><A ID='IMG_2414.JPG' href='itsatoughlife2.php?fileId=IMG_2414.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050523/IMG_2414.JPG' ALT='Rockhampton'><BR>Rockhampton<br>88.62 KB</a><div class='inv'><br><a href='./images/20050523/IMG_2414.JPG' ALT='Rockhampton'>Rockhampton</a></div></td>
<td><A ID='IMG_2417.JPG' href='itsatoughlife2.php?fileId=IMG_2417.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050523/IMG_2417.JPG' ALT='Criterion Hotel, Rockhampton'><BR>Criterion Hotel, Rockhampton<br>79.24 KB</a><div class='inv'><br><a href='./images/20050523/IMG_2417.JPG' ALT='Criterion Hotel, Rockhampton'>Criterion Hotel, Rockhampton</a></div></td>
<td><A ID='IMG_2419.JPG' href='itsatoughlife2.php?fileId=IMG_2419.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050523/IMG_2419.JPG' ALT='Old customs building, Rockhampton'><BR>Old customs building, Rockhampton<br>110.26 KB</a><div class='inv'><br><a href='./images/20050523/IMG_2419.JPG' ALT='Old customs building, Rockhampton'>Old customs building, Rockhampton</a></div></td>
</tr>
<tr><td><A ID='IMG_2420.JPG' href='itsatoughlife2.php?fileId=IMG_2420.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050523/IMG_2420.JPG' ALT='Valuebull, Rockhampton'><BR>Valuebull, Rockhampton<br>80.58 KB</a><div class='inv'><br><a href='./images/20050523/IMG_2420.JPG' ALT='Valuebull, Rockhampton'>Valuebull, Rockhampton</a></div></td>
<td><A ID='IMG_2421.JPG' href='itsatoughlife2.php?fileId=IMG_2421.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050523/IMG_2421.JPG' ALT='Commercial Hotel, Rockhampton'><BR>Commercial Hotel, Rockhampton<br>74.22 KB</a><div class='inv'><br><a href='./images/20050523/IMG_2421.JPG' ALT='Commercial Hotel, Rockhampton'>Commercial Hotel, Rockhampton</a></div></td>
<td><A ID='IMG_2427.JPG' href='itsatoughlife2.php?fileId=IMG_2427.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050523/IMG_2427.JPG' ALT='Captain Cook Memorial, Emu Park. The wind makes it sing a doleful tune.'><BR>Captain Cook Memorial, Emu Park. The wind makes it sing a doleful tune.<br>45.03 KB</a><div class='inv'><br><a href='./images/20050523/IMG_2427.JPG' ALT='Captain Cook Memorial, Emu Park. The wind makes it sing a doleful tune.'>Captain Cook Memorial, Emu Park. The wind makes it sing a doleful tune.</a></div></td>
<td><A ID='IMG_2429.JPG' href='itsatoughlife2.php?fileId=IMG_2429.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050523/IMG_2429.JPG' ALT='Great Keppel Island as seen from Emu Park'><BR>Great Keppel Island as seen from Emu Park<br>45.06 KB</a><div class='inv'><br><a href='./images/20050523/IMG_2429.JPG' ALT='Great Keppel Island as seen from Emu Park'>Great Keppel Island as seen from Emu Park</a></div></td>
<td><A ID='IMG_2437.JPG' href='itsatoughlife2.php?fileId=IMG_2437.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050523/IMG_2437.JPG' ALT='Yeppoon from the ferry to Great Keppel Island '><BR>Yeppoon from the ferry to Great Keppel Island <br>57.88 KB</a><div class='inv'><br><a href='./images/20050523/IMG_2437.JPG' ALT='Yeppoon from the ferry to Great Keppel Island '>Yeppoon from the ferry to Great Keppel Island </a></div></td>
</tr>
<tr><td><A ID='IMG_2440.JPG' href='itsatoughlife2.php?fileId=IMG_2440.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050523/IMG_2440.JPG' ALT='Sunset on Great Keppel Island'><BR>Sunset on Great Keppel Island<br>44.09 KB</a><div class='inv'><br><a href='./images/20050523/IMG_2440.JPG' ALT='Sunset on Great Keppel Island'>Sunset on Great Keppel Island</a></div></td>
<td><A ID='IMG_2445.JPG' href='itsatoughlife2.php?fileId=IMG_2445.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050523/IMG_2445.JPG' ALT='Jannuka, Great Keppel Island'><BR>Jannuka, Great Keppel Island<br>54.98 KB</a><div class='inv'><br><a href='./images/20050523/IMG_2445.JPG' ALT='Jannuka, Great Keppel Island'>Jannuka, Great Keppel Island</a></div></td>
<td><A ID='IMG_2451.JPG' href='itsatoughlife2.php?fileId=IMG_2451.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050523/IMG_2451.JPG' ALT='Sunset, Great Keppel Island'><BR>Sunset, Great Keppel Island<br>37.01 KB</a><div class='inv'><br><a href='./images/20050523/IMG_2451.JPG' ALT='Sunset, Great Keppel Island'>Sunset, Great Keppel Island</a></div></td>
<td><A ID='IMG_2452.JPG' href='itsatoughlife2.php?fileId=IMG_2452.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050523/IMG_2452.JPG' ALT='Couple on the beach at Sunset, Great Keppel Island'><BR>Couple on the beach at Sunset, Great Keppel Island<br>49.06 KB</a><div class='inv'><br><a href='./images/20050523/IMG_2452.JPG' ALT='Couple on the beach at Sunset, Great Keppel Island'>Couple on the beach at Sunset, Great Keppel Island</a></div></td>
<td><A ID='IMG_2455.JPG' href='itsatoughlife2.php?fileId=IMG_2455.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050523/IMG_2455.JPG' ALT='The mainland from Great Keppel Island'><BR>The mainland from Great Keppel Island<br>73.44 KB</a><div class='inv'><br><a href='./images/20050523/IMG_2455.JPG' ALT='The mainland from Great Keppel Island'>The mainland from Great Keppel Island</a></div></td>
</tr>
<tr><td><A ID='IMG_2457.JPG' href='itsatoughlife2.php?fileId=IMG_2457.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050523/IMG_2457.JPG' ALT='Scott'><BR>Scott<br>99.26 KB</a><div class='inv'><br><a href='./images/20050523/IMG_2457.JPG' ALT='Scott'>Scott</a></div></td>
<td><A ID='IMG_2458.JPG' href='itsatoughlife2.php?fileId=IMG_2458.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050523/IMG_2458.JPG' ALT='Guinea Fowl and a chook'><BR>Guinea Fowl and a chook<br>76.32 KB</a><div class='inv'><br><a href='./images/20050523/IMG_2458.JPG' ALT='Guinea Fowl and a chook'>Guinea Fowl and a chook</a></div></td>
<td><A ID='IMG_2459.JPG' href='itsatoughlife2.php?fileId=IMG_2459.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050523/IMG_2459.JPG' ALT='Guinea Fowl'><BR>Guinea Fowl<br>115.57 KB</a><div class='inv'><br><a href='./images/20050523/IMG_2459.JPG' ALT='Guinea Fowl'>Guinea Fowl</a></div></td>
<td><A ID='IMG_2460.JPG' href='itsatoughlife2.php?fileId=IMG_2460.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050523/IMG_2460.JPG' ALT='Scott, Guinea Fowl and a chook'><BR>Scott, Guinea Fowl and a chook<br>79.88 KB</a><div class='inv'><br><a href='./images/20050523/IMG_2460.JPG' ALT='Scott, Guinea Fowl and a chook'>Scott, Guinea Fowl and a chook</a></div></td>
<td><A ID='IMG_2461.JPG' href='itsatoughlife2.php?fileId=IMG_2461.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050523/IMG_2461.JPG' ALT='Peacock'><BR>Peacock<br>74.49 KB</a><div class='inv'><br><a href='./images/20050523/IMG_2461.JPG' ALT='Peacock'>Peacock</a></div></td>
</tr>
<tr><td><A ID='IMG_2464.JPG' href='itsatoughlife2.php?fileId=IMG_2464.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050523/IMG_2464.JPG' ALT='Scott, Stephan and various birds'><BR>Scott, Stephan and various birds<br>106.9 KB</a><div class='inv'><br><a href='./images/20050523/IMG_2464.JPG' ALT='Scott, Stephan and various birds'>Scott, Stephan and various birds</a></div></td>
<td><A ID='IMG_2465.JPG' href='itsatoughlife2.php?fileId=IMG_2465.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050523/IMG_2465.JPG' ALT='Peacock'><BR>Peacock<br>124.23 KB</a><div class='inv'><br><a href='./images/20050523/IMG_2465.JPG' ALT='Peacock'>Peacock</a></div></td>
<td><A ID='IMG_2466.JPG' href='itsatoughlife2.php?fileId=IMG_2466.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050523/IMG_2466.JPG' ALT='Looking to the Lighthouse, Great Keppel Island'><BR>Looking to the Lighthouse, Great Keppel Island<br>72.95 KB</a><div class='inv'><br><a href='./images/20050523/IMG_2466.JPG' ALT='Looking to the Lighthouse, Great Keppel Island'>Looking to the Lighthouse, Great Keppel Island</a></div></td>
<td><A ID='IMG_2468.JPG' href='itsatoughlife2.php?fileId=IMG_2468.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050523/IMG_2468.JPG' ALT='Wreck Beach, Great Keppel Island'><BR>Wreck Beach, Great Keppel Island<br>81.03 KB</a><div class='inv'><br><a href='./images/20050523/IMG_2468.JPG' ALT='Wreck Beach, Great Keppel Island'>Wreck Beach, Great Keppel Island</a></div></td>
<td><A ID='IMG_2471.JPG' href='itsatoughlife2.php?fileId=IMG_2471.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050523/IMG_2471.JPG' ALT='Wreck Beach with fringing reef, Great Keppel Island'><BR>Wreck Beach with fringing reef, Great Keppel Island<br>50.44 KB</a><div class='inv'><br><a href='./images/20050523/IMG_2471.JPG' ALT='Wreck Beach with fringing reef, Great Keppel Island'>Wreck Beach with fringing reef, Great Keppel Island</a></div></td>
</tr>
<tr><td><A ID='IMG_2472.JPG' href='itsatoughlife2.php?fileId=IMG_2472.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050523/IMG_2472.JPG' ALT='Wreck Beach, Great Keppel Island'><BR>Wreck Beach, Great Keppel Island<br>64.49 KB</a><div class='inv'><br><a href='./images/20050523/IMG_2472.JPG' ALT='Wreck Beach, Great Keppel Island'>Wreck Beach, Great Keppel Island</a></div></td>
<td><A ID='IMG_2475.JPG' href='itsatoughlife2.php?fileId=IMG_2475.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050523/IMG_2475.JPG' ALT='Wreck Beach, Great Keppel Island'><BR>Wreck Beach, Great Keppel Island<br>56.34 KB</a><div class='inv'><br><a href='./images/20050523/IMG_2475.JPG' ALT='Wreck Beach, Great Keppel Island'>Wreck Beach, Great Keppel Island</a></div></td>
<td><A ID='IMG_2476.JPG' href='itsatoughlife2.php?fileId=IMG_2476.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050523/IMG_2476.JPG' ALT='Wreck Beach, Great Keppel Island'><BR>Wreck Beach, Great Keppel Island<br>47.22 KB</a><div class='inv'><br><a href='./images/20050523/IMG_2476.JPG' ALT='Wreck Beach, Great Keppel Island'>Wreck Beach, Great Keppel Island</a></div></td>
<td><A ID='IMG_2477.JPG' href='itsatoughlife2.php?fileId=IMG_2477.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050523/IMG_2477.JPG' ALT='Wreck Beach, Great Keppel Island'><BR>Wreck Beach, Great Keppel Island<br>49.16 KB</a><div class='inv'><br><a href='./images/20050523/IMG_2477.JPG' ALT='Wreck Beach, Great Keppel Island'>Wreck Beach, Great Keppel Island</a></div></td>
<td><A ID='IMG_2480.JPG' href='itsatoughlife2.php?fileId=IMG_2480.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050523/IMG_2480.JPG' ALT='Looking east from the western side of Great Keppel'><BR>Looking east from the western side of Great Keppel<br>34.45 KB</a><div class='inv'><br><a href='./images/20050523/IMG_2480.JPG' ALT='Looking east from the western side of Great Keppel'>Looking east from the western side of Great Keppel</a></div></td>
</tr>
<tr><td><A ID='IMG_2482.JPG' href='itsatoughlife2.php?fileId=IMG_2482.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050523/IMG_2482.JPG' ALT='Scott and Stephan after a good day's snorkelling'><BR>Scott and Stephan after a good day's snorkelling<br>90.96 KB</a><div class='inv'><br><a href='./images/20050523/IMG_2482.JPG' ALT='Scott and Stephan after a good day's snorkelling'>Scott and Stephan after a good day's snorkelling</a></div></td>
<td><A ID='IMG_2484.JPG' href='itsatoughlife2.php?fileId=IMG_2484.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050523/IMG_2484.JPG' ALT='Sunset from the top of Great Keppel'><BR>Sunset from the top of Great Keppel<br>46.54 KB</a><div class='inv'><br><a href='./images/20050523/IMG_2484.JPG' ALT='Sunset from the top of Great Keppel'>Sunset from the top of Great Keppel</a></div></td>
<td><A ID='IMG_2488.JPG' href='itsatoughlife2.php?fileId=IMG_2488.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050523/IMG_2488.JPG' ALT='Random people'><BR>Random people<br>48.86 KB</a><div class='inv'><br><a href='./images/20050523/IMG_2488.JPG' ALT='Random people'>Random people</a></div></td>
<td><A ID='IMG_2491.JPG' href='itsatoughlife2.php?fileId=IMG_2491.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050523/IMG_2491.JPG' ALT='The main beach, Great Keppel Island'><BR>The main beach, Great Keppel Island<br>38.43 KB</a><div class='inv'><br><a href='./images/20050523/IMG_2491.JPG' ALT='The main beach, Great Keppel Island'>The main beach, Great Keppel Island</a></div></td>
<td><A ID='IMG_2498.JPG' href='itsatoughlife2.php?fileId=IMG_2498.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050523/IMG_2498.JPG' ALT='Hundreds of tiny crabs scuttling away from me on the sands of Great Keppel Island'><BR>Hundreds of tiny crabs scuttling away from me on the sands of Great Keppel Island<br>74.1 KB</a><div class='inv'><br><a href='./images/20050523/IMG_2498.JPG' ALT='Hundreds of tiny crabs scuttling away from me on the sands of Great Keppel Island'>Hundreds of tiny crabs scuttling away from me on the sands of Great Keppel Island</a></div></td>
</tr>
<tr><td><A ID='IMG_2499.JPG' href='itsatoughlife2.php?fileId=IMG_2499.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050523/IMG_2499.JPG' ALT='Balls of sand deposited by crabs'><BR>Balls of sand deposited by crabs<br>62.87 KB</a><div class='inv'><br><a href='./images/20050523/IMG_2499.JPG' ALT='Balls of sand deposited by crabs'>Balls of sand deposited by crabs</a></div></td>
<td><A ID='IMG_2501.JPG' href='itsatoughlife2.php?fileId=IMG_2501.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050523/IMG_2501.JPG' ALT='Another beach, Great Keppel'><BR>Another beach, Great Keppel<br>62.34 KB</a><div class='inv'><br><a href='./images/20050523/IMG_2501.JPG' ALT='Another beach, Great Keppel'>Another beach, Great Keppel</a></div></td>
<td><A ID='IMG_2505.JPG' href='itsatoughlife2.php?fileId=IMG_2505.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050523/IMG_2505.JPG' ALT='The underwater observatory near Great Keppel Island'><BR>The underwater observatory near Great Keppel Island<br>45.39 KB</a><div class='inv'><br><a href='./images/20050523/IMG_2505.JPG' ALT='The underwater observatory near Great Keppel Island'>The underwater observatory near Great Keppel Island</a></div></td>
<td><A ID='IMG_2506.JPG' href='itsatoughlife2.php?fileId=IMG_2506.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050523/IMG_2506.JPG' ALT='Quartz veins in the rocks'><BR>Quartz veins in the rocks<br>108.33 KB</a><div class='inv'><br><a href='./images/20050523/IMG_2506.JPG' ALT='Quartz veins in the rocks'>Quartz veins in the rocks</a></div></td>
<td><A ID='IMG_2508.JPG' href='itsatoughlife2.php?fileId=IMG_2508.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050523/IMG_2508.JPG' ALT='Interesting tidal drainage patterns in the sand, Great Keppel Island'><BR>Interesting tidal drainage patterns in the sand, Great Keppel Island<br>47.56 KB</a><div class='inv'><br><a href='./images/20050523/IMG_2508.JPG' ALT='Interesting tidal drainage patterns in the sand, Great Keppel Island'>Interesting tidal drainage patterns in the sand, Great Keppel Island</a></div></td>
</tr>
<tr><td><A ID='IMG_2509.JPG' href='itsatoughlife2.php?fileId=IMG_2509.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050523/IMG_2509.JPG' ALT='Interesting tidal drainage patterns in the sand, Great Keppel Island'><BR>Interesting tidal drainage patterns in the sand, Great Keppel Island<br>48.17 KB</a><div class='inv'><br><a href='./images/20050523/IMG_2509.JPG' ALT='Interesting tidal drainage patterns in the sand, Great Keppel Island'>Interesting tidal drainage patterns in the sand, Great Keppel Island</a></div></td>
<td><A ID='IMG_2511.JPG' href='itsatoughlife2.php?fileId=IMG_2511.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050523/IMG_2511.JPG' ALT='Interesting tidal drainage patterns in the sand, Great Keppel Island'><BR>Interesting tidal drainage patterns in the sand, Great Keppel Island<br>50.94 KB</a><div class='inv'><br><a href='./images/20050523/IMG_2511.JPG' ALT='Interesting tidal drainage patterns in the sand, Great Keppel Island'>Interesting tidal drainage patterns in the sand, Great Keppel Island</a></div></td>
<td><A ID='IMG_2514.JPG' href='itsatoughlife2.php?fileId=IMG_2514.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050523/IMG_2514.JPG' ALT='Kookaburra'><BR>Kookaburra<br>61.09 KB</a><div class='inv'><br><a href='./images/20050523/IMG_2514.JPG' ALT='Kookaburra'>Kookaburra</a></div></td>
<td><A ID='IMG_2515.JPG' href='itsatoughlife2.php?fileId=IMG_2515.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050523/IMG_2515.JPG' ALT='A magical sunset on Great Keppel Island'><BR>A magical sunset on Great Keppel Island<br>31.7 KB</a><div class='inv'><br><a href='./images/20050523/IMG_2515.JPG' ALT='A magical sunset on Great Keppel Island'>A magical sunset on Great Keppel Island</a></div></td>
<td><A ID='IMG_2529.JPG' href='itsatoughlife2.php?fileId=IMG_2529.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050523/IMG_2529.JPG' ALT='Bush Stone-Curlew, or Thicknee on Great Keppel Island'><BR>Bush Stone-Curlew, or Thicknee on Great Keppel Island<br>72.22 KB</a><div class='inv'><br><a href='./images/20050523/IMG_2529.JPG' ALT='Bush Stone-Curlew, or Thicknee on Great Keppel Island'>Bush Stone-Curlew, or Thicknee on Great Keppel Island</a></div></td>
</tr>
<tr><td><A ID='IMG_2533.JPG' href='itsatoughlife2.php?fileId=IMG_2533.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050523/IMG_2533.JPG' ALT='Sunset on Great Keppel'><BR>Sunset on Great Keppel<br>39.94 KB</a><div class='inv'><br><a href='./images/20050523/IMG_2533.JPG' ALT='Sunset on Great Keppel'>Sunset on Great Keppel</a></div></td>
<td><A ID='IMG_2537.JPG' href='itsatoughlife2.php?fileId=IMG_2537.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050523/IMG_2537.JPG' ALT='Leaving Great Keppel Island'><BR>Leaving Great Keppel Island<br>57.45 KB</a><div class='inv'><br><a href='./images/20050523/IMG_2537.JPG' ALT='Leaving Great Keppel Island'>Leaving Great Keppel Island</a></div></td>
<td><A ID='IMG_2541.JPG' href='itsatoughlife2.php?fileId=IMG_2541.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050523/IMG_2541.JPG' ALT='Leaving Great Keppel Island'><BR>Leaving Great Keppel Island<br>50.16 KB</a><div class='inv'><br><a href='./images/20050523/IMG_2541.JPG' ALT='Leaving Great Keppel Island'>Leaving Great Keppel Island</a></div></td>
<td><A ID='IMG_2547.JPG' href='itsatoughlife2.php?fileId=IMG_2547.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050523/IMG_2547.JPG' ALT='White-lipped Tree Frog, Emu Park'><BR>White-lipped Tree Frog, Emu Park<br>64.14 KB</a><div class='inv'><br><a href='./images/20050523/IMG_2547.JPG' ALT='White-lipped Tree Frog, Emu Park'>White-lipped Tree Frog, Emu Park</a></div></td>
<td><A ID='IMG_2548.JPG' href='itsatoughlife2.php?fileId=IMG_2548.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050523/IMG_2548.JPG' ALT='A White-lipped Tree Frog, Emu Park'><BR>A White-lipped Tree Frog, Emu Park<br>67.29 KB</a><div class='inv'><br><a href='./images/20050523/IMG_2548.JPG' ALT='A White-lipped Tree Frog, Emu Park'>A White-lipped Tree Frog, Emu Park</a></div></td>
</tr>
<tr><td><A ID='IMG_2549.JPG' href='itsatoughlife2.php?fileId=IMG_2549.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050523/IMG_2549.JPG' ALT='Emu's Beach House'><BR>Emu's Beach House<br>77.03 KB</a><div class='inv'><br><a href='./images/20050523/IMG_2549.JPG' ALT='Emu's Beach House'>Emu's Beach House</a></div></td>
<td><A ID='IMG_2554.JPG' href='itsatoughlife2.php?fileId=IMG_2554.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050523/IMG_2554.JPG' ALT='Black Swan'><BR>Black Swan<br>72.11 KB</a><div class='inv'><br><a href='./images/20050523/IMG_2554.JPG' ALT='Black Swan'>Black Swan</a></div></td>
<td><A ID='IMG_2568.JPG' href='itsatoughlife2.php?fileId=IMG_2568.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050523/IMG_2568.JPG' ALT='Black Swans'><BR>Black Swans<br>102.24 KB</a><div class='inv'><br><a href='./images/20050523/IMG_2568.JPG' ALT='Black Swans'>Black Swans</a></div></td>
</tr>
</table>	</div>
</div>
</body>
</html>