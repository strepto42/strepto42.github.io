<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - De-bearding - Frightening pictures of a shrinking beard</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="Frightening pictures of a shrinking beard">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="Pictures of my 28th Birthday party complete with Sparkler Bomb" href='28th.php'>28th Birthday</a></li>
<li><a title="Pictures of my 30th Birthday party" href='30th.php'>30th Birthday</a></li>
<li><a title="Michael Shamgar and Lindsay Halamek's 30th birthday bash photos" href='sl30th.php'>Shams & Linds' 30th</a></li>
<li><a title="Pictures of Andy Marinos's new flat, cat Toby, and Mum Pam Swain" href='andycatandflat.php'>Andy's Cat & Flat</a></li>
<li><a title="Pictures of a visit to Stephen Jackson's Farm" href='jackovisit.php'>Jacko's Farm</a></li>
<li><a title="Pictures taken at the Peace Convergence action in Rockhampton and Yeppoon in June 2005 to protest the joint US Australia military exercises (Operation Talisman Sabre)" href='peaceconvergence.php'>Peace Convergence</a></li>
<li><a title="Sydney trip - April '06" href='bridges.php'>Sydney, April 06</a></li>
<li><a title="Pics of Naima's 28th birthday dinner" href='mim28th.php'>Naima's 28th</a></li>
<li><a title="Brisbane CBD and the Story Bridge" href='brisbanepics1.php'>Brissie by Night 1</a></li>
<li><a title="Lamington National Park" href='lamington.php'>Lamington NP</a></li>
<li><a title="Various creatures and views from our Brisbane back yard" href='backyard.php'>Backyard Creatures</a></li>
<li><a title="Opening day of the Eleanor Schonell (Green) Bridge" href='greenbridge.php'>Green Bridge</a></li>
<li><a title="Pictutres from the 2006 Woodford Folk Festival" href='woodford0607.php'>Woodford 2006-2007</a></li>
<li><a title="One Cute Puppy" href='jezebel.php'>Jezebel</a></li>
<li><a title="Climbing at Kangaroo Point Cliffs" href='kangaroopt1.php'>Heather's Visit</a></li>
<li><a title="0x0021st (33rd) birthday celebrations" href='0x0021st.php'>0x0021st Birthday</a></li>
<li><a title="Nuptial photography" href='guyandalison.php'>Guy and Alison's Wedding</a></li>
<li><a title="Pictures from the 2007 Woodford Folk Festival" href='woodford0708.php'>Woodford 2007-2008</a></li>
<li><a title="Image gallery" href='sydneytrip0802.php'>Sydney & Yacaaba Head</a></li>
<li><a title="An impressive show by nature" href='lightning.php'>Thunderstorm Moonrise</a></li>
<li><div class='activemenu'>De-bearding</div></li>
<li><a title="More Nuptial Photography" href='michaelandkaren.php'>Michael and Karen's Wedding</a></li>
<li><a title="A night of celebration" href='andrews21st.php'>Andrew's 21st</a></li>
<li><a title="Image Gallery" href='bloodyknee.php'>Bloody Knee</a></li>
<li><a title="Image Gallery" href='tyesbirthday.php'>Tye's Birthday</a></li>
<li><a title="Image Gallery" href='lasersocialising.php'>Laser Socialising</a></li>
<li><a title="Image Gallery" href='heatherandevan.php'>Heather and Evan's Wedding</a></li>
<li><a title="Image Gallery" href='woodford0809.php'>Woodford 2008-2009</a></li>
<li><a title="Image Gallery" href='allyandben.php'>Ally and Ben's Wedding</a></li>
<li><a title="Image Gallery" href='annes30th.php'>Anne's 30th</a></li>
<li><a title="Image Gallery" href='possumcreek.php'>Possum Creek</a></li>
<li><a title="Image Gallery" href='jamnight.php'>Jam Night</a></li>
<li><a title="Image Gallery" href='cunninghamsgap.php'>Cunningham's Gap</a></li>
<li><a title="Image Gallery" href='bigcat.php'>Diving on Big Cat</a></li>
<li><a title="Images from my birthday jam" href='birthdayjam.php'>Music, mayhem and merriment</a></li>
<li><a title="Image Gallery" href='fuzzypolaroidpics.php'>Fuzzy Polaroid</a></li>
<li><a title="Image Gallery" href='zombiewalk2009.php'>2009 Zombie Walk</a></li>
<li> </li><br><li>Or go back to:</li><li><a title='Picture galleries' href="pictures.php">Photography</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>De-bearding</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Picture galleries' href="pictures.php">Photography</a> > <a title='Frightening pictures of a shrinking beard' href="debearding.php">De-bearding</a>
<br><br>		

<p>It was time for the beard to go, but when you have facial hair, it's important to make the most of it.</p>

<p>As it's taken me more than 30 years to be able to grow any decent sort of mo', I felt that a quick dabble into the world of beard and moustache styling was called for, if only to frighten myself and some small children. I must admit a certain amount of inspiration for this page came from <a href="http://torylawson.com/newsite/index.php?page_id=10" title="Fantastic Debearding page" target="_blank">this fantastic effort</a>, however, I'd already thought of most of these beard stages before finding it, and he never took it to its frightening, but logical conclusion.</p>

<p>First up, we have the full beard. Relatively unscary.</p>

<p>Next though, we have the <a href="http://en.wikipedia.org/wiki/Lemmy" target="_blank">Lemmy</a>. It's such a fine beard - I actually sported the Lemmy for about a week. Yes, I wore it out in public. Several times I walked past something reflective and scared myself; such is the nature of the Lemmy. It's also a fantastic beard for scowling in.</p>

<p>The next logical stage is the <a href="http://www.youtube.com/watch?v=Eg-ti_Nm-f0" target="_blank">Muttonchops</a> beard. It looked pretty pathetic on me, and just didn't have the sheer ROCK BALLS of the Lemmy, so it quickly evolved into The <a href="http://sunday.ninemsn.com.au/sunday/film_reviews/article_108.asp?s=1" target="_blank">Pando</a>.

<p>The other fellow's page refers to The Pando as a "Gunslinger", which I can see, especially if you are American and have no idea who Pando is (hint: get <a href="http://www.imdb.com/title/tt0145547/" title="Two Hands" target="_blank">the movie</a> out, it's bloody fantastic). You could also call this beard a <a href="http://en.wikipedia.org/wiki/Merv_Hughes" title="Merv Hughes" target="_blank">Merv</a>, although <a href="http://www.everydayshouldbesaturday.com/2007/03/28/mustache-of-the-day-cricket-world-cup-salute/" title="Merv's Moustache">his</a> is of course infinitely superior.</p>

<p>Next things start to get a bit scary: The <a href="http://en.wikipedia.org/wiki/Ned_Flanders" title="Ned Flanders" target="_blank">Flanders</a>. Hi-delly ho-delly neighbourino!</p>

<p>Finally, the logical conclusion at which all shrinking moustaches must arrive: The Hitler. You could also call it the Charlie Chaplian of course, but I think Adolf has pretty much ruined this moustanche for everyone now (and it doesn't help that that fucknuckle arseclown <a href="http://orvillelloyddouglas.files.wordpress.com/2007/07/robert-mugabe1.jpg" target="_blank">Mugabe</a> has one too). It's amazing how much authority one carries with this beard though. My first effort was a bit blonde, so I got out a texta and coloured it in. Enjoy.</p>
<br><br>
All images in this gallery:<br>
<table width='800'>
<tr>
</tr>
<tr><td><A ID='IMG_3751.JPG' href='debearding.php?fileId=IMG_3751.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080518/IMG_3751.JPG' ALT='The Full Beard'><BR>The Full Beard<br>58.42 KB</a><div class='inv'><br><a href='./images/20080518/IMG_3751.JPG' ALT='The Full Beard'>The Full Beard</a></div></td>
<td><A ID='IMG_3753.JPG' href='debearding.php?fileId=IMG_3753.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080518/IMG_3753.JPG' ALT='The Full Beard'><BR>The Full Beard<br>63.28 KB</a><div class='inv'><br><a href='./images/20080518/IMG_3753.JPG' ALT='The Full Beard'>The Full Beard</a></div></td>
<td><A ID='IMG_3759.JPG' href='debearding.php?fileId=IMG_3759.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080518/IMG_3759.JPG' ALT='The Full Beard'><BR>The Full Beard<br>58.44 KB</a><div class='inv'><br><a href='./images/20080518/IMG_3759.JPG' ALT='The Full Beard'>The Full Beard</a></div></td>
<td><A ID='IMG_3760.JPG' href='debearding.php?fileId=IMG_3760.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080518/IMG_3760.JPG' ALT='The Lemmy'><BR>The Lemmy<br>55.35 KB</a><div class='inv'><br><a href='./images/20080518/IMG_3760.JPG' ALT='The Lemmy'>The Lemmy</a></div></td>
<td><A ID='IMG_3761.JPG' href='debearding.php?fileId=IMG_3761.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080518/IMG_3761.JPG' ALT='The Lemmy - Grrr!'><BR>The Lemmy - Grrr!<br>48.96 KB</a><div class='inv'><br><a href='./images/20080518/IMG_3761.JPG' ALT='The Lemmy - Grrr!'>The Lemmy - Grrr!</a></div></td>
</tr>
<tr><td><A ID='IMG_3763.JPG' href='debearding.php?fileId=IMG_3763.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080518/IMG_3763.JPG' ALT='The Lemmy - jowellerific!'><BR>The Lemmy - jowellerific!<br>55.82 KB</a><div class='inv'><br><a href='./images/20080518/IMG_3763.JPG' ALT='The Lemmy - jowellerific!'>The Lemmy - jowellerific!</a></div></td>
<td><A ID='IMG_3766.JPG' href='debearding.php?fileId=IMG_3766.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080518/IMG_3766.JPG' ALT='The Lemmy'><BR>The Lemmy<br>48.05 KB</a><div class='inv'><br><a href='./images/20080518/IMG_3766.JPG' ALT='The Lemmy'>The Lemmy</a></div></td>
<td><A ID='IMG_3771.JPG' href='debearding.php?fileId=IMG_3771.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080518/IMG_3771.JPG' ALT='The Lemmy'><BR>The Lemmy<br>57.86 KB</a><div class='inv'><br><a href='./images/20080518/IMG_3771.JPG' ALT='The Lemmy'>The Lemmy</a></div></td>
<td><A ID='IMG_3773.JPG' href='debearding.php?fileId=IMG_3773.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080518/IMG_3773.JPG' ALT='The Lemmy'><BR>The Lemmy<br>60.24 KB</a><div class='inv'><br><a href='./images/20080518/IMG_3773.JPG' ALT='The Lemmy'>The Lemmy</a></div></td>
<td><A ID='IMG_3777.JPG' href='debearding.php?fileId=IMG_3777.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080518/IMG_3777.JPG' ALT='A softer side to the Lemmy'><BR>A softer side to the Lemmy<br>58.46 KB</a><div class='inv'><br><a href='./images/20080518/IMG_3777.JPG' ALT='A softer side to the Lemmy'>A softer side to the Lemmy</a></div></td>
</tr>
<tr><td><A ID='IMG_4123.JPG' href='debearding.php?fileId=IMG_4123.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080518/IMG_4123.JPG' ALT='Muttonchops'><BR>Muttonchops<br>53.62 KB</a><div class='inv'><br><a href='./images/20080518/IMG_4123.JPG' ALT='Muttonchops'>Muttonchops</a></div></td>
<td><A ID='IMG_4128.JPG' href='debearding.php?fileId=IMG_4128.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080518/IMG_4128.JPG' ALT='Muttonchops - yahhr!'><BR>Muttonchops - yahhr!<br>62.17 KB</a><div class='inv'><br><a href='./images/20080518/IMG_4128.JPG' ALT='Muttonchops - yahhr!'>Muttonchops - yahhr!</a></div></td>
<td><A ID='IMG_4129.JPG' href='debearding.php?fileId=IMG_4129.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080518/IMG_4129.JPG' ALT='The Pando'><BR>The Pando<br>57.62 KB</a><div class='inv'><br><a href='./images/20080518/IMG_4129.JPG' ALT='The Pando'>The Pando</a></div></td>
<td><A ID='IMG_4130.JPG' href='debearding.php?fileId=IMG_4130.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080518/IMG_4130.JPG' ALT='The Pando'><BR>The Pando<br>56.51 KB</a><div class='inv'><br><a href='./images/20080518/IMG_4130.JPG' ALT='The Pando'>The Pando</a></div></td>
<td><A ID='IMG_4131.JPG' href='debearding.php?fileId=IMG_4131.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080518/IMG_4131.JPG' ALT='The Pando'><BR>The Pando<br>57.37 KB</a><div class='inv'><br><a href='./images/20080518/IMG_4131.JPG' ALT='The Pando'>The Pando</a></div></td>
</tr>
<tr><td><A ID='IMG_4133.JPG' href='debearding.php?fileId=IMG_4133.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080518/IMG_4133.JPG' ALT='The Flanders'><BR>The Flanders<br>57.15 KB</a><div class='inv'><br><a href='./images/20080518/IMG_4133.JPG' ALT='The Flanders'>The Flanders</a></div></td>
<td><A ID='IMG_4134.JPG' href='debearding.php?fileId=IMG_4134.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080518/IMG_4134.JPG' ALT='The Flanders'><BR>The Flanders<br>59.19 KB</a><div class='inv'><br><a href='./images/20080518/IMG_4134.JPG' ALT='The Flanders'>The Flanders</a></div></td>
<td><A ID='IMG_4135.JPG' href='debearding.php?fileId=IMG_4135.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080518/IMG_4135.JPG' ALT='The Flanders - eek!'><BR>The Flanders - eek!<br>61.14 KB</a><div class='inv'><br><a href='./images/20080518/IMG_4135.JPG' ALT='The Flanders - eek!'>The Flanders - eek!</a></div></td>
<td><A ID='IMG_4136.JPG' href='debearding.php?fileId=IMG_4136.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080518/IMG_4136.JPG' ALT='The Hitler - RRRRROUSE!'><BR>The Hitler - RRRRROUSE!<br>50.34 KB</a><div class='inv'><br><a href='./images/20080518/IMG_4136.JPG' ALT='The Hitler - RRRRROUSE!'>The Hitler - RRRRROUSE!</a></div></td>
<td><A ID='IMG_4138.JPG' href='debearding.php?fileId=IMG_4138.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080518/IMG_4138.JPG' ALT='The Hitler'><BR>The Hitler<br>53.13 KB</a><div class='inv'><br><a href='./images/20080518/IMG_4138.JPG' ALT='The Hitler'>The Hitler</a></div></td>
</tr>
<tr><td><A ID='IMG_4140.JPG' href='debearding.php?fileId=IMG_4140.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080518/IMG_4140.JPG' ALT='The Hitler'><BR>The Hitler<br>60.62 KB</a><div class='inv'><br><a href='./images/20080518/IMG_4140.JPG' ALT='The Hitler'>The Hitler</a></div></td>
<td><A ID='IMG_4142.JPG' href='debearding.php?fileId=IMG_4142.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080518/IMG_4142.JPG' ALT='The Hitler'><BR>The Hitler<br>55.02 KB</a><div class='inv'><br><a href='./images/20080518/IMG_4142.JPG' ALT='The Hitler'>The Hitler</a></div></td>
<td><A ID='IMG_4143.JPG' href='debearding.php?fileId=IMG_4143.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080518/IMG_4143.JPG' ALT='The Hitler'><BR>The Hitler<br>54.87 KB</a><div class='inv'><br><a href='./images/20080518/IMG_4143.JPG' ALT='The Hitler'>The Hitler</a></div></td>
<td><A ID='IMG_4145.JPG' href='debearding.php?fileId=IMG_4145.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080518/IMG_4145.JPG' ALT='Clean shaven'><BR>Clean shaven<br>54.05 KB</a><div class='inv'><br><a href='./images/20080518/IMG_4145.JPG' ALT='Clean shaven'>Clean shaven</a></div></td>
<td><A ID='IMG_4146.JPG' href='debearding.php?fileId=IMG_4146.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080518/IMG_4146.JPG' ALT='Clean shaven at last'><BR>Clean shaven at last<br>51.08 KB</a><div class='inv'><br><a href='./images/20080518/IMG_4146.JPG' ALT='Clean shaven at last'>Clean shaven at last</a></div></td>
</tr>
</table>	</div>
</div>
</body>
</html>