<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - Baker's Dozen - Baker's Dozen MP3s (Mark Cocquio, Lindsay Halamek, Guy Bunn and he who must not be named)</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="Baker's Dozen MP3s (Mark Cocquio, Lindsay Halamek, Guy Bunn and he who must not be named)">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><div class='activemenu'>Baker's Dozen</div></li>
<li><a title="MP3s from the CUE (Consistent User Experience - Mark Cocquio, Nathan Spargo and Wade Kuhn), including Monkey Magic and a really bad Gandhara cover" href='consistentuserexperience.php'>CUE</a></li>
<li><a title="MP3s from Fuzzy Polaroid's gigs at the Step Inn and Second Degree Bar" href='fuzzypolaroidmp3s.php'>Fuzzy Polaroid</a></li>
<li> </li><br><li>Or go back to:</li><li><a title='Sounds and music' href="music.php">Music</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>Baker's Dozen</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Sounds and music' href="music.php">Music</a> > <a title='Baker's Dozen MP3s (Mark Cocquio, Lindsay Halamek, Guy Bunn and he who must not be named)' href="bakersdozen.php">Baker's Dozen</a>
<br><br>		<br>
<br>
Ah, history. These tracks were created back in my post high-school days. Metal lives on. And, like a plague of madmen, it's breaking out of hell.<br>
<br><br>
Files available for download:<br>
<ul class="dirlist"><li><a href="./files/bakersdozen/01 - Breaking Out of Hell.mp3">01 - Breaking Out of Hell.mp3</a></li><li><a href="./files/bakersdozen/02 - Chelmsford Chant.mp3">02 - Chelmsford Chant.mp3</a></li><li><a href="./files/bakersdozen/03 - Strutter.mp3">03 - Strutter.mp3</a></li><li><a href="./files/bakersdozen/04 - Point Blank.mp3">04 - Point Blank.mp3</a></li><li><a href="./files/bakersdozen/05 - Freedom Fighter.mp3">05 - Freedom Fighter.mp3</a></li></ul><!-- old method
getTheFiles($file);

function getTheFiles($folder) {
	if ($handle = opendir($folder)) {
		while (false !== ($file = readdir($handle))) {
			If ($file!= "." && $file!= ".." and !is_dir($folder."/".$file)) {
				$filesize = round(filesize ($folder."/".$file)/1024,2);
				echo "<tr><td><div align='left'><A href='$corelise$folder/$file'>$file</a></div></td><td><div align='left'>$filesize KB</div></td><tr>\n";
			} else {
			If ($file!= "." && $file!= ".." and is_dir($folder."/".$file)) {
				getTheFiles($file);
			}
		}
		closedir($handle);
	}
} -->
	</div>
</div>
</body>
</html>