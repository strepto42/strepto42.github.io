<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - Green Bridge - Opening day of the Eleanor Schonell (Green) Bridge</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="Opening day of the Eleanor Schonell (Green) Bridge">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="Pictures of my 28th Birthday party complete with Sparkler Bomb" href='28th.php'>28th Birthday</a></li>
<li><a title="Pictures of my 30th Birthday party" href='30th.php'>30th Birthday</a></li>
<li><a title="Michael Shamgar and Lindsay Halamek's 30th birthday bash photos" href='sl30th.php'>Shams & Linds' 30th</a></li>
<li><a title="Pictures of Andy Marinos's new flat, cat Toby, and Mum Pam Swain" href='andycatandflat.php'>Andy's Cat & Flat</a></li>
<li><a title="Pictures of a visit to Stephen Jackson's Farm" href='jackovisit.php'>Jacko's Farm</a></li>
<li><a title="Pictures taken at the Peace Convergence action in Rockhampton and Yeppoon in June 2005 to protest the joint US Australia military exercises (Operation Talisman Sabre)" href='peaceconvergence.php'>Peace Convergence</a></li>
<li><a title="Sydney trip - April '06" href='bridges.php'>Sydney, April 06</a></li>
<li><a title="Pics of Naima's 28th birthday dinner" href='mim28th.php'>Naima's 28th</a></li>
<li><a title="Brisbane CBD and the Story Bridge" href='brisbanepics1.php'>Brissie by Night 1</a></li>
<li><a title="Lamington National Park" href='lamington.php'>Lamington NP</a></li>
<li><a title="Various creatures and views from our Brisbane back yard" href='backyard.php'>Backyard Creatures</a></li>
<li><div class='activemenu'>Green Bridge</div></li>
<li><a title="Pictutres from the 2006 Woodford Folk Festival" href='woodford0607.php'>Woodford 2006-2007</a></li>
<li><a title="One Cute Puppy" href='jezebel.php'>Jezebel</a></li>
<li><a title="Climbing at Kangaroo Point Cliffs" href='kangaroopt1.php'>Heather's Visit</a></li>
<li><a title="0x0021st (33rd) birthday celebrations" href='0x0021st.php'>0x0021st Birthday</a></li>
<li><a title="Nuptial photography" href='guyandalison.php'>Guy and Alison's Wedding</a></li>
<li><a title="Pictures from the 2007 Woodford Folk Festival" href='woodford0708.php'>Woodford 2007-2008</a></li>
<li><a title="Image gallery" href='sydneytrip0802.php'>Sydney & Yacaaba Head</a></li>
<li><a title="An impressive show by nature" href='lightning.php'>Thunderstorm Moonrise</a></li>
<li><a title="Frightening pictures of a shrinking beard" href='debearding.php'>De-bearding</a></li>
<li><a title="More Nuptial Photography" href='michaelandkaren.php'>Michael and Karen's Wedding</a></li>
<li><a title="A night of celebration" href='andrews21st.php'>Andrew's 21st</a></li>
<li><a title="Image Gallery" href='bloodyknee.php'>Bloody Knee</a></li>
<li><a title="Image Gallery" href='tyesbirthday.php'>Tye's Birthday</a></li>
<li><a title="Image Gallery" href='lasersocialising.php'>Laser Socialising</a></li>
<li><a title="Image Gallery" href='heatherandevan.php'>Heather and Evan's Wedding</a></li>
<li><a title="Image Gallery" href='woodford0809.php'>Woodford 2008-2009</a></li>
<li><a title="Image Gallery" href='allyandben.php'>Ally and Ben's Wedding</a></li>
<li><a title="Image Gallery" href='annes30th.php'>Anne's 30th</a></li>
<li><a title="Image Gallery" href='possumcreek.php'>Possum Creek</a></li>
<li><a title="Image Gallery" href='jamnight.php'>Jam Night</a></li>
<li><a title="Image Gallery" href='cunninghamsgap.php'>Cunningham's Gap</a></li>
<li><a title="Image Gallery" href='bigcat.php'>Diving on Big Cat</a></li>
<li><a title="Images from my birthday jam" href='birthdayjam.php'>Music, mayhem and merriment</a></li>
<li><a title="Image Gallery" href='fuzzypolaroidpics.php'>Fuzzy Polaroid</a></li>
<li><a title="Image Gallery" href='zombiewalk2009.php'>2009 Zombie Walk</a></li>
<li> </li><br><li>Or go back to:</li><li><a title='Picture galleries' href="pictures.php">Photography</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>Green Bridge</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Picture galleries' href="pictures.php">Photography</a> > <a title='Opening day of the Eleanor Schonell (Green) Bridge' href="greenbridge.php">Green Bridge</a>
<br><br>		

<p>The new bridge up the road from us opened today. Its working title was the Green Bridge (as it's for pedestrians, busses and cyclists only) but they've given it the committee treatment, and officially named it the Eleanor Schonell Bridge. No disrespect to Eleanor, but it's a bit of an ungainly name for a bridge. With luck people will ignore it and keep calling it the Green Bridge, which is a perfectly good name in my ranty opinion.</p>

<p>Anyway, for want of something better to do I rode up and had a wander around the opening festivities with my camera. The bridge was open to all and sundry, although for some reason you couldn't take your bike on the road - only pedestrians were allowed on it. Bikes had to stick to the bike path, with was of course full of pedestrians too. Go figure. I would have quizzed one of the security blokes about it, but they were all decidedly grumpy. Still, I guess that's a requirement of working security (and yes, there are plenty of friendly security folks out there, just like there are plenty of intelligent ones. They're just in the minority).</p>

<p>Anyway, back to the photos. I've also just acquired an <a href="http://dansdata.blogsome.com/2006/12/06/white-trees-black-sky" target="_blank">IR-pass filter</a>, so I took some photos with that while I was there too. Dutton Park Cemetary (which is next door) is particularly atmospheric in IR. I took colour shots for comparison too, they're paired up below. The IR shots are mildly photoshopped, to bring out a bit more contrast and remove noise, as well as to remove the purple colour cast that they have out of the camera.</p>

<p>For $25, it's quite a nifty effect!</p>

<br><br>
All images in this gallery:<br>
<table width='800'>
<tr>
</tr>
<tr><td><A ID='IMG_2686.JPG' href='greenbridge.php?fileId=IMG_2686.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061217/IMG_2686.JPG' ALT='IMG_2686.JPG'><BR>IMG_2686.JPG<br>45.4 KB</a><div class='inv'><br><a href='./images/20061217/IMG_2686.JPG' ALT='IMG_2686.JPG'>IMG_2686.JPG</a></div></td>
<td><A ID='IMG_2688.JPG' href='greenbridge.php?fileId=IMG_2688.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061217/IMG_2688.JPG' ALT='IMG_2688.JPG'><BR>IMG_2688.JPG<br>52.18 KB</a><div class='inv'><br><a href='./images/20061217/IMG_2688.JPG' ALT='IMG_2688.JPG'>IMG_2688.JPG</a></div></td>
<td><A ID='IMG_2689.JPG' href='greenbridge.php?fileId=IMG_2689.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061217/IMG_2689.JPG' ALT='IMG_2689.JPG'><BR>IMG_2689.JPG<br>50.28 KB</a><div class='inv'><br><a href='./images/20061217/IMG_2689.JPG' ALT='IMG_2689.JPG'>IMG_2689.JPG</a></div></td>
<td><A ID='IMG_2690.JPG' href='greenbridge.php?fileId=IMG_2690.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061217/IMG_2690.JPG' ALT='IMG_2690.JPG'><BR>IMG_2690.JPG<br>65.8 KB</a><div class='inv'><br><a href='./images/20061217/IMG_2690.JPG' ALT='IMG_2690.JPG'>IMG_2690.JPG</a></div></td>
<td><A ID='IMG_2692.JPG' href='greenbridge.php?fileId=IMG_2692.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061217/IMG_2692.JPG' ALT='IMG_2692.JPG'><BR>IMG_2692.JPG<br>72.85 KB</a><div class='inv'><br><a href='./images/20061217/IMG_2692.JPG' ALT='IMG_2692.JPG'>IMG_2692.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_2695.JPG' href='greenbridge.php?fileId=IMG_2695.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061217/IMG_2695.JPG' ALT='Eleanor Schonell Bridge'><BR>Eleanor Schonell Bridge<br>70.17 KB</a><div class='inv'><br><a href='./images/20061217/IMG_2695.JPG' ALT='Eleanor Schonell Bridge'>Eleanor Schonell Bridge</a></div></td>
<td><A ID='IMG_2697.JPG' href='greenbridge.php?fileId=IMG_2697.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061217/IMG_2697.JPG' ALT='Eleanor Schonell Bridge in near infrared'><BR>Eleanor Schonell Bridge in near infrared<br>58.29 KB</a><div class='inv'><br><a href='./images/20061217/IMG_2697.JPG' ALT='Eleanor Schonell Bridge in near infrared'>Eleanor Schonell Bridge in near infrared</a></div></td>
<td><A ID='IMG_2701.JPG' href='greenbridge.php?fileId=IMG_2701.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061217/IMG_2701.JPG' ALT='IMG_2701.JPG'><BR>IMG_2701.JPG<br>57.78 KB</a><div class='inv'><br><a href='./images/20061217/IMG_2701.JPG' ALT='IMG_2701.JPG'>IMG_2701.JPG</a></div></td>
<td><A ID='IMG_2702.JPG' href='greenbridge.php?fileId=IMG_2702.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061217/IMG_2702.JPG' ALT='Dutton Park Cemetary'><BR>Dutton Park Cemetary<br>114.41 KB</a><div class='inv'><br><a href='./images/20061217/IMG_2702.JPG' ALT='Dutton Park Cemetary'>Dutton Park Cemetary</a></div></td>
<td><A ID='IMG_2711.JPG' href='greenbridge.php?fileId=IMG_2711.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061217/IMG_2711.JPG' ALT='Dutton Park Cemetary in near Infrared'><BR>Dutton Park Cemetary in near Infrared<br>82.8 KB</a><div class='inv'><br><a href='./images/20061217/IMG_2711.JPG' ALT='Dutton Park Cemetary in near Infrared'>Dutton Park Cemetary in near Infrared</a></div></td>
</tr>
<tr><td><A ID='IMG_2720.JPG' href='greenbridge.php?fileId=IMG_2720.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061217/IMG_2720.JPG' ALT='IMG_2720.JPG'><BR>IMG_2720.JPG<br>61.13 KB</a><div class='inv'><br><a href='./images/20061217/IMG_2720.JPG' ALT='IMG_2720.JPG'>IMG_2720.JPG</a></div></td>
<td><A ID='IMG_2724.JPG' href='greenbridge.php?fileId=IMG_2724.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061217/IMG_2724.JPG' ALT='IMG_2724.JPG'><BR>IMG_2724.JPG<br>51.4 KB</a><div class='inv'><br><a href='./images/20061217/IMG_2724.JPG' ALT='IMG_2724.JPG'>IMG_2724.JPG</a></div></td>
<td><A ID='IMG_2728.JPG' href='greenbridge.php?fileId=IMG_2728.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061217/IMG_2728.JPG' ALT='IMG_2728.JPG'><BR>IMG_2728.JPG<br>52.24 KB</a><div class='inv'><br><a href='./images/20061217/IMG_2728.JPG' ALT='IMG_2728.JPG'>IMG_2728.JPG</a></div></td>
<td><A ID='IMG_2730.JPG' href='greenbridge.php?fileId=IMG_2730.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061217/IMG_2730.JPG' ALT='IMG_2730.JPG'><BR>IMG_2730.JPG<br>36.11 KB</a><div class='inv'><br><a href='./images/20061217/IMG_2730.JPG' ALT='IMG_2730.JPG'>IMG_2730.JPG</a></div></td>
<td><A ID='IMG_2732.JPG' href='greenbridge.php?fileId=IMG_2732.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061217/IMG_2732.JPG' ALT='IMG_2732.JPG'><BR>IMG_2732.JPG<br>60.71 KB</a><div class='inv'><br><a href='./images/20061217/IMG_2732.JPG' ALT='IMG_2732.JPG'>IMG_2732.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_2733.JPG' href='greenbridge.php?fileId=IMG_2733.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061217/IMG_2733.JPG' ALT='Dutton Park Cemetary'><BR>Dutton Park Cemetary<br>116.15 KB</a><div class='inv'><br><a href='./images/20061217/IMG_2733.JPG' ALT='Dutton Park Cemetary'>Dutton Park Cemetary</a></div></td>
<td><A ID='IMG_2734.JPG' href='greenbridge.php?fileId=IMG_2734.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061217/IMG_2734.JPG' ALT='Dutton Park Cemetary'><BR>Dutton Park Cemetary<br>127.52 KB</a><div class='inv'><br><a href='./images/20061217/IMG_2734.JPG' ALT='Dutton Park Cemetary'>Dutton Park Cemetary</a></div></td>
<td><A ID='IMG_2739.JPG' href='greenbridge.php?fileId=IMG_2739.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061217/IMG_2739.JPG' ALT='Dutton Park Cemetary'><BR>Dutton Park Cemetary<br>123.07 KB</a><div class='inv'><br><a href='./images/20061217/IMG_2739.JPG' ALT='Dutton Park Cemetary'>Dutton Park Cemetary</a></div></td>
<td><A ID='IMG_2743.JPG' href='greenbridge.php?fileId=IMG_2743.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061217/IMG_2743.JPG' ALT='Dutton Park Cemetary in near Infrared'><BR>Dutton Park Cemetary in near Infrared<br>79.52 KB</a><div class='inv'><br><a href='./images/20061217/IMG_2743.JPG' ALT='Dutton Park Cemetary in near Infrared'>Dutton Park Cemetary in near Infrared</a></div></td>
<td><A ID='IMG_2748.JPG' href='greenbridge.php?fileId=IMG_2748.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061217/IMG_2748.JPG' ALT='Dutton Park Cemetary'><BR>Dutton Park Cemetary<br>104.75 KB</a><div class='inv'><br><a href='./images/20061217/IMG_2748.JPG' ALT='Dutton Park Cemetary'>Dutton Park Cemetary</a></div></td>
</tr>
<tr><td><A ID='IMG_2753.JPG' href='greenbridge.php?fileId=IMG_2753.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061217/IMG_2753.JPG' ALT='Dutton Park Cemetary in near Infrared'><BR>Dutton Park Cemetary in near Infrared<br>79.4 KB</a><div class='inv'><br><a href='./images/20061217/IMG_2753.JPG' ALT='Dutton Park Cemetary in near Infrared'>Dutton Park Cemetary in near Infrared</a></div></td>
</tr>
</table>	</div>
</div>
</body>
</html>