<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - Soundboards - Arnold Schwarzenegger and Michael Jackson soundboards</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="Arnold Schwarzenegger and Michael Jackson soundboards">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="A page dedicated to the worst Optimus Prime outfits on the net" href='badoptimus.php'>Bad Optimus</a></li>
<li><a title="WD40 cans going whoosh and Sparkler Bomb videos" href='wd40.php'>WD40</a></li>
<li><a title="2weeks.com internet art concept site" href='2weeks.php'>2weeks.com</a></li>
<li><a title="A pong game featuring Rudi Mueller's head by John Hawkins" href='rudipong.php'>Rudipong</a></li>
<li><a title="The Random Domain Name Game" href='rdng.php'>RDNG</a></li>
<li><a title="Various animations for download" href='anims.php'>Animations</a></li>
<li><div class='activemenu'>Soundboards</div></li>
<li> </li><br><li>Or go back to:</li><li><a title='Silly things for your amusement' href="silliness.php">Silliness</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>Soundboards</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Silly things for your amusement' href="silliness.php">Silliness</a> > <a title='Arnold Schwarzenegger and Michael Jackson soundboards' href="soundboards.php">Soundboards</a>
<br><br>		<br>
We love soundboards. Soundboards are fun. Here are two of the best - Arnie's Ultimate and Wacko Jacko's beat box.<br>
<br><br>
Files available for download:<br>
<ul class="dirlist"><li><a href="./files/soundboards/arnoldultimate.rar">arnoldultimate.rar</a></li><li><a href="./files/soundboards/beatbox1_0plus.rar">beatbox1_0plus.rar</a></li></ul><!-- old method
getTheFiles($file);

function getTheFiles($folder) {
	if ($handle = opendir($folder)) {
		while (false !== ($file = readdir($handle))) {
			If ($file!= "." && $file!= ".." and !is_dir($folder."/".$file)) {
				$filesize = round(filesize ($folder."/".$file)/1024,2);
				echo "<tr><td><div align='left'><A href='$corelise$folder/$file'>$file</a></div></td><td><div align='left'>$filesize KB</div></td><tr>\n";
			} else {
			If ($file!= "." && $file!= ".." and is_dir($folder."/".$file)) {
				getTheFiles($file);
			}
		}
		closedir($handle);
	}
} -->
	</div>
</div>
</body>
</html>