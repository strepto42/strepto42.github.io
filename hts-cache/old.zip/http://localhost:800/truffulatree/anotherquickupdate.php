<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - 19/10/2000 - Another quick update from the land of rupees...</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="Another quick update from the land of rupees...">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="Greetings from the Other Side" href='greetingsfromtheotherside.php'>16/10/2000</a></li>
<li><div class='activemenu'>19/10/2000</div></li>
<li><a title="More Miscellaneous Ramblings from the Teeming Subcontinent" href='subcontinentramblings.php'>25/10/2000</a></li>
<li><a title="Indian Update" href='indianupdate.php'>4/11/2000</a></li>
<li><a title="From the Ganges to the Taj... and beyond" href='gangestotaj.php'>18/11/2000</a></li>
<li><a title="Camels, Tigers, Elephants and Octopussies" href='camelstigersoctopussies.php'>9/12/2000</a></li>
<li><a title="Back to bloody reality" href='backtobloodyreality.php'>14/12/2000</a></li>
<li> </li><br><li>Or go back to:</li><li><a title='Travelouges from my trip through India in 2000' href="india2000.php">India 2000</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>19/10/2000</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Travel stories and pictures' href="travel.php">Travelogues</a> > <a title='Travelouges from my trip through India in 2000' href="india2000.php">India 2000</a> > <a title='Another quick update from the land of rupees...' href="anotherquickupdate.php">19/10/2000</a>
<br><br>		


<h1>Another quick update from the land of rupees...</h1>

<p>Been in Delhi now for 4 days, will be leaving today, going up north to 
Dahramsala (sp?), which I'm really looking forward to. Delhi has been 
interesting, but it's very polluted, and rather crowded as well.</p>

<p>A few funny stories... People here want to sell you anything and everything. 
Went in to the city centre the other day, and we were practically hassled 
non stop. I could have had my ears cleaned, but I opted out of that one, 
even though the guy had a book full of testimonials (which he obviously 
insisted people write after he had worked his magic). Not sure if he tore 
out the bad ones. I acutally thought his book said 'car cleaning' at 
first...</p>

<p>Jana gave in and had her shoes shined, as they really needed it and we 
figured that the shoeshine guys wouldn't ever leave us alone if she didn't. 
It's funny, lots of people recognise the shoes (Blundstones) as Australian, 
even here.</p>

<p>Have also been offered various hankies, drums, flutes, belts, blocks of 
hashish, free maps (just come visit my friend's travel shop!), etc...</p>

<p>The written word over here is also frequently amusing... some examples:</p>

<p>'Bargain cum Sale'<br>
'Please keep foot donw - thank you darlinig' (in an auto-rickshaw, which is 
like cross between a moped and a Trabant, in which you can have good travel 
for a small fee, plus the excitement of nearly running into things every 5 
seconds - mind you they seem do drive pretty damn well given the 
circumstances, so mum you can calm down now :))<br>
'Egg Scumbled'<br>
'Scumbled Egg' - both from our hotel's menu. Never did find out what the 
difference is. They were different prices however.</p>

<p>Also from the menu: various things with "chilly", "pan cakes", "cheese 
omelate", "ice pot" (some sort of cold drink), various "sandwitches", plus a 
few others that I can't remember.</p>

<p>Anyway I'm having a ball, and pitying those of you in your fun jobs. Sorry, 
couldn't resist... :)</p>

<br><br>
All images in this gallery:<br>
<table width='800'>
<tr>
</tr>
<tr><td><A ID='F1000006.JPG' href='anotherquickupdate.php?fileId=F1000006.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001019/F1000006.JPG' ALT='F1000006.JPG'><BR>F1000006.JPG<br>127.98 KB</a><div class='inv'><br><a href='./images/20001019/F1000006.JPG' ALT='F1000006.JPG'>F1000006.JPG</a></div></td>
</tr>
</table>	</div>
</div>
</body>
</html>