<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - 9/12/2000 - Camels, Tigers, Elephants and Octopussies</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="Camels, Tigers, Elephants and Octopussies">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="Greetings from the Other Side" href='greetingsfromtheotherside.php'>16/10/2000</a></li>
<li><a title="Another quick update from the land of rupees..." href='anotherquickupdate.php'>19/10/2000</a></li>
<li><a title="More Miscellaneous Ramblings from the Teeming Subcontinent" href='subcontinentramblings.php'>25/10/2000</a></li>
<li><a title="Indian Update" href='indianupdate.php'>4/11/2000</a></li>
<li><a title="From the Ganges to the Taj... and beyond" href='gangestotaj.php'>18/11/2000</a></li>
<li><div class='activemenu'>9/12/2000</div></li>
<li><a title="Back to bloody reality" href='backtobloodyreality.php'>14/12/2000</a></li>
<li> </li><br><li>Or go back to:</li><li><a title='Travelouges from my trip through India in 2000' href="india2000.php">India 2000</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>9/12/2000</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Travel stories and pictures' href="travel.php">Travelogues</a> > <a title='Travelouges from my trip through India in 2000' href="india2000.php">India 2000</a> > <a title='Camels, Tigers, Elephants and Octopussies' href="camelstigersoctopussies.php">9/12/2000</a>
<br><br>		


<h1>Camels, Tigers, Elephants and Octopussies</h1>

<p>Hello again to all and sundry!</p>

<p>Once again I have left it a while to write, so there are quite a few 
adventures to report. Thanks to everyone for writing, it's nice to hear a 
little news of home and to stay in touch.</p>

<p>But yeah, this is gonna be a bit over-long. So grab a cup of your favourite 
steaming beverage!</p>

<p>From a toilet bowl: Vitreous HINDware<br>
From a menu: FISH FOOD (they meant "fish")<br>
From the streets of Delhi: Say NO to plastic bags. Heed it kids.</p>

<p>So let's see. If memory serves me correctly (for once) I wrote the last 
update in Jaipur. We'd just been to see various palaces and observatories.</p>

<p>The next day was similar. We visited a place just out of town, called Ambur, 
which had a very impressive fort on the top of a hill. Quite a big place too 
- you could get slightly lost in there without too much trouble. Lots of 
different levels, twisty passages, balconies, ornate doorways etc. It 
reminded me a little of a Quake level, although it must be said that the 
association should probably be the other way round, what with the fort being 
in the real world, and of course it is much more satisfying to walk around 
something for real than on a computer screen. And you can actually touch 
things.</p>

<p>We caught an auto-rickshaw on the way out there; the driver was the same one 
we'd had the day before and he insisted on taking us for free as we paid him 
way too much previously. It was nice to meet someone voluntarily honest. :) 
Although his friend may have pressured him into it, we found out later.</p>

<p>Stopped off along the way as well, and saw a few things - a palace in the 
middle of a lake (which looked quite nice), and a snake charmer. He offered 
to let us touch the cobras but we elected not to at the time. We were both 
pretty sure they would have had their fangs removed (especially given how he 
would bat the snake gently on the head to make it flatten it's neck out), 
but we weren't sure at the time. Found out later that they do indeed de-fang 
them. Snake charmers are not stupid. At least, the ones who are still alive 
aren't.</p>

<p>We also bought one of his snake charming instruments. It makes a horrible 
noise to the untrained. I'm sure you'll all enjoy it when I get back. Jana 
is.</p>

<p>That was pretty much it for Jaipur. There was plenty to do there, but we're 
having to cut our stays short now, to only three days or so, in order to fit 
everything in. Getting sick in Varansi ate up a week all up, so we have to 
hot foot it a bit now.</p>

<p>Next on the agenda was Jaisalmer, in far western India, on the border of the 
desert between India and Pakistan. The bus ride was a long one, and I think, 
to date the worst.</p>

<p>It wasn't the 14 odd hours.</p>

<p>It wasn't so much the seats that didn't recline (but were somehow randomly 
set in a reclining position - well, some were more than others, for example 
the seats in FRONT of us were WAY back, whereas ours were pretty much 
upright).</p>

<p>It wasn't even the crying baby, which was thankfully not a screamer.</p>

<p>It wasn't the suicidal driver either, once we got used to him.</p>

<p>It was more the fact that once the bus got up to speed, the windows 
*rattled*. I'm not talking sydney-government-schoolbus-rattles. I'm talking 
machine guns and jackhammers in your ears. It was fun.</p>

<p>In fact, the only thing louder than the bus's windows, was the incredibly 
piercing wailing hindi pop music being played at maximum volume for half the 
night (the LATER half mostly). To give you an idea of the volume of said 
music, I could only drown it out completely if I had the discman playing 
Metallica's 'Blackened' at a volume too painful for even me.</p>

<p>So needless to say, we arrived fresh, well rested, happy and rearing to go.</p>

<p>Heh. Actually, arriving is generally quite pleasant after these bus trips. 
Can't think why.</p>

<p>But anyway, we got to Jaisalmer. I think Jaisalmer is now up there in the 
favourites for India, along with Varanasi and Dharamsala. Definitely go 
there if you go to India (it is well worth the bus ride).</p>

<p>It's a lovely place, all brown and orange desert colours, with a great big 
fort on the hill (they like their forts over here), which for once actually 
houses people, and is more than just a withering monument. Jaisalmer isn't a 
very big city actually, a fair proportion would live inside the fort, along 
with various temples and the obligatory palace or two. It's a nice friendly 
place, and fairly clean as well.</p>

<p>Apart from the fort, many people come to Jaisalmer to go on a Camel Safari, 
out in the desert. We felt this had to be done. Eventually decided to do 
three days and two nights.</p>

<p>Day 1.</p>

<p>We started out at the hotel, and met the other people we'd be safariing 
with. Apart from us there were three girls from England whose names escape 
me, and a Scottish guy called Robbie. We all wedged into a jeep and got 
taken about 30kms out of town, and met up with the camels and our guides. So 
we hopped up onto our camels, they stood up, we nearly fell off, and away we 
went, at a nice slow walk.</p>

<p>Camels are funny creatures. I have decided that I quite like them. Apart 
from the fact that they look pretty odd, they make all sorts of amusing 
nosies. Most of said noises are cranky ones. I think next time I watch any 
of the Star Wars moviews, I'll be hearing camels whenever a fearsome beastie 
growls and gargles!</p>

<p>For all their complaining though, they were quite a peaceful bunch of 
animals. Probably quite used to having idiot westerners with no idea on 
their backs. I'd heard about camels spitting and biting, but none of these 
were the type. Which is good really; someone there was of the opinion that 
you could get syphillis from a camel bite. Have to check up on that one.</p>

<p>Camel riding is quite pleasent and peaceful, once you and your arse get used 
to it. As one of the English girls said, you could write a book about our 
safari: "Three Days on a Camel by Major Bumsore."</p>

<p>Camels have, say, four speeds.</p>

<p>1. Walking. This is pretty easy on the bum once you get used to the motion 
of the camel.</p>

<p>2. Trotting (I'll call it that for argument's sake) slowly. This is pretty 
bumpy. You can get used to it after a while, and keeping from bouncing off 
at times distracts you from the repeated impacts into your already 
complaining bum. Camel saddles don't have stirrups.</p>

<p>3. Trotting quickly. This speed I only experienced a couple of times, and 
that was enough. Incredibly bouncy, and it suddenly feels like your arse is 
being bashed against anvils. You actually get significant air in between 
bounces. This provides a great opportunity for the camel to suddenly change 
direction slightly, making you almost fall off.</p>

<p>4. Galloping. Didn't do this myself, but saw it. Camels actually do change 
to a gallop after a certain speed. Apparently it's smoother than the fast 
trot, but I didn't find out. :)</p>

<p>We spent the first half of the way going pretty leisurely. It was still 
enough to make me pretty stiff the first time we got off the camels (to look 
at a small village). Saw a few of these villages actually, amazing that 
people live out there in the desert like that, with it only raining a few 
times a year.</p>

<p>The scenery wasn't just 'sand, and lots of it' either - we weren't on dunes 
as such mostly. Just very sandy, rocky ground, with various desert plants 
around the place (most of which had lovely thorns, one of which my camel 
considerately dragged my leg through - when I was wearing shorts).</p>

<p>Stopped for lunch under a nice tree, to everyone's relief. Had great food 
too - our guides were pretty good cooks.</p>

<p>The afternoon was probably the worst for me. I was incredibly sore and could 
hardly move my legs when we had stopped for lunch. And the afternoon saw a 
lot of walking and a fair bit of trotting. I know I'm just sounding like a 
big wuss, but at the time it was pretty painful. I kept bashing my ging gang 
goolie goolies whenever we started trotting. One of the Indian guys asked me 
how my banana was at the end of the day. I don't think he was talking about 
fruit. Anyway, I got to find out what "bow-legged" means, first hand. :)</p>

<p>We got to where we were going in the end, and it was well worth it. Spent 
the first night on some sand dunes, not huge ones, but pretty big, and after 
they stuffed us full of food again we climbed into our sleeping bags and 
watched the shooting stars. Nice stars in the desert. Will have to go out 
into the Australian outback sometime and see the stars, as from there 
they're supposed to be pretty damn good (and better than India).</p>

<p>Day 2.</p>

<p>Got up at the crack o dawn, and saw a lovely sunrise to match the sunset 
we'd watched from the dune the night before. Had a good feed and off we went 
again.</p>

<p>Not so painful this time. You'd get used to it pretty quickly I think, a 
week or so and it wouldn't hurt at all. The guides who were with us 
obviously weren't at all worried.</p>

<p>Stopped off for lunch again after a few more little villages, and then after 
lunch the 3 girls left, as they were only doing one night. Quitters. Some 
lame excuse about a train to catch. :)</p>

<p>That left Jana and I, and Robbie the Scot. He was pretty good value 
actually, and had just spent a year in Australia (which meant we could 
understand what he was saying), and was going back home to the Isle of Skye 
after India - just about the most cold and miserable place on earth from the 
way he described it. Needless to say he was very pleased about this. About 
the trucks and busses driving down the road he once said "these guys manage 
to make driving on a straight road look dangerous!". It's very true. It'll 
be odd to get back to order and rules and people afraid of getting sued.</p>

<p>Anyway we rode on to another campsite and spent the second night there. It 
was near a little village, and within a short time half a dozen locals had 
showed up to sit around the fire and share a little Indian mirth and 
chatter. Robbie got hassled a bit for lacking facial hair. I got a bit too, 
as I have grown the beard, but not the mo'. Indian males almost ALL have 
moustaches. It's seen as a little babyish to not have one I think. But 
Robbie gave as good as he got in true Scot style.</p>

<p>There were some funny characters in that group. All very happy people 
though. One guy kept asking questions, and when we replied would say "oh my 
god!". I've been trying to work out how to write it the same way he said it, 
as it was very funny, but I can't seem to get it in text. The nearest I 
could come I guess would be way somebody Jewish rolls their eyes and says 
"oi vey!" (or an Aussie might say "bloody hell!"). Anyway. Guess you had to 
be there.</p>

<p>Day 3.</p>

<p>Not much to report, a lazy campfire breakfast after watching the dawn again 
(it's kind of hard to sleep in when you're outdoors), then a camel ride back 
to the road where we met the jeep to take us back. I ended up with a 
passenger, a kid of about 8 or 10, on the back of my camel. He wanted to go 
very fast all the time. My arse didn't agree. In the end we got there and I 
survived.</p>

<p>The safari is definitely something you want to do if you come here, it was 
worth all the pain, which I am probably exaggerating a little.</p>

<p>So that was it for the desert and Jaisalmer. Next stop after yet another 
interminable bus journey was a place called Udaipur. It's a nice city, with 
a big lake, and a famous island hotel out on the lake. The James bond film 
"Octopussy" was filmed (or part thereof) in this town, and needless to say 
the locals are incredibly proud of it. Just about every hotel shows the 
movie every night; bugger the fact that it was shot 20 years ago! :)</p>

<p>I sat through it for the hell if it. Get it out on video by all means and 
watch it, but I warn you, it ain't so good. Roger Moore isn't a patch on 
good 'ol Sean.</p>

<p>But it is interesting to see some of the India bits - the movie is 20 years 
old or something like that, and the auto-rickshaws haven't changed a bit. :)</p>

<p>Not much else to report from Udaipur. Visited the obligatory palace, and saw 
many fine artworks - the miniature paintings they do here are quite amazing. 
Took a boat ride on the lake; twas nice, peaceful. A little polluted on the 
shore, but you get that in India.</p>

<p>Next stop for us was a place called Bundi. Smallish town, but very nice it 
turned out. We were basically just killing a day there on our way to Bhopal. 
We'd also just about run out of cash at this point, and getting more isn't 
that easy in India. You need to be in a big town before you see an ATM, and 
even then a lot of the time they don't work with my card. So we had 
basically a very limited budget here - just enough for accomodation and bus 
tickets, plus maybe a small amount of food.</p>

<p>There's a big palace on the hill in Bundi, and we thought we may as well 
visit it given we had most of the day to kill. As soon as we were through 
the door the usual guide-out-of-nowhere approached us, and offered to show 
us around. The palace in Bundi has some lovely big murals.</p>

<p>We explained that we had no money, but this guy turned out to be really 
nice. Billu (that was his name) simply said "money is not God!" and insisted 
we see the place anyway, and send him money later when we had some. In the 
end he gave us an excellent tour, and took us back to his house for an 
enormous lunch. Then he took us to see two big Bawrees, or step-wells, that 
are famous in the town. These are quite large impressive stone buildings in 
the ground, and are quite deep (your homework is to look them up as I can't 
really describe them well). After that his wife made us some wonderful food 
for our bus trip.</p>

<p>It's lovely to meet someone like that over here, where so many people are 
trying to rip you off. As one guy said to me on a train, 60% of people are 
good, and 40% bad. The hard part is knowing who is which of course.</p>

<p>Next stop was Bhopal, which has the dubious honour of having been the site 
of the world's worst industrial disaster. Tis also the capital of the state 
we were in. Not much to report from there at all - got some cash, and hopped 
on a train to Jabalpur. Not much there either - supposed to be a nice place 
near town called Marble Rocks but we didn't make it there.</p>

<p>From here we hopped on a bus to Khana National Park, which among other 
things is a famous Tiger sanctuary, with more than 130 Tigers in the park.</p>

<p>We spent the next morning going round the part on the back of a Jeep (which 
they called a "Gypsy" for some reason - all the hotels advertised "Gypsy 
Rides", which I'm not even going to make a joke about - I leave that as an 
excercise to the reader).</p>

<p>It was lovely in the park. It was also about -1 degrees when we left the 
hotel, and we kinda froze. But it was all worth it. Saw various types of 
Deer, various birds, including Peacocks of course, and a pack of wild dogs 
(they weren't too wild at the time, what with it being bloody freezing and 
all).</p>

<p>We did get to see Tigers too, but sort of cheated to do it. The people in 
the park use Elephants to find then, and then hem them in on both sides, and 
you can pay to go on another Elephant to see the Tigers (briefly). This 
sounded a bit nasty to the Tigers to us, but the reality of it was that they 
were resting and not at all particularly 'trapped'. They didn't seem to 
fussed at all.</p>

<p>So we saw two males, young ones I believe. I was very impressed - they are 
absolutely beautiful animals, and despite the fact that they were resting 
their eyes were sharp and missed nothing. They were almost hypnotising. I 
can't remember if I've seen Tigers at the zoo, but nothing on TV compared to 
seeing them in their natural environment. They had a real presence and 
majesty all of their own, which I would imagine a zoo tiger would lack. 
Their colour was gorgeous. As we left them I remember feeling quite 
profoundly sad that they'll probably not be around for very much longer, in 
spite of the good work being done at the park, and other places like it.</p>

<p>We also drove around a fair bit on the back of the Jeep, and saw lots of 
other Tiger *tracks*, but no Tigers. Damn things were probably all watching 
us from 10 metres in the bush, but that's all you need there to be 
invisible, even if you are quite strikingly coloured.</p>

<p>But all up it was well worth the long dusty travel to get there - I'll 
always remember those two Tigers.</p>

<p>One other amusing story from that trip - on the way there and back the bus 
stopped for half and hour at a little town (Manda or Mandla I think is was). 
There was this old Indian chap there, who was very friendly and quite 
amusing. He bought us tea, and insisted we didn't pay. He also insisted we 
try Paan, which is an Indian preparation that revolves around a Betel Nut. 
It is actually addictive in the long term, and makes your teeth and mouth 
turn red (also in the long term!). If you go to India and someone talking to 
you looks like they've just had lunch with Monsieur Dracula, it's because of 
Paan.</p>

<p>But one is fine, and it was interesting to try. They put all sorts of things 
on an edible leaf, lime paste and other tasty things, along with the Betel, 
and tie it up with a clove. You pop the whole thing in your mouth and chew 
it a while, and then eventually spit it it out and add another red splotch 
to the pavement. It's supposed to be mildly intoxicating ("good for ENERGY!" 
as the old guy said). Didn't seem to be for us.</p>

<p>The old guy (I can't remember his name but have it written down somewhere) 
had obviously been into his Paan for a while judging by the state of his 
teeth. Turns out he was a retired schoolteacher. We thought he might have 
travelled as he spoke English quite differently to most people here, but he 
said he hadn't. He used some very quaint phrases - for example when asking 
if you liked something (like the Paan) he would ask "So do you relish it?!". 
Anyway, I've rambled enough about the old fellow, but he really was quite 
nice and friendly.</p>

<p>So. From Khana we've basically travelled uneventfully. Only memorable thing 
from the train trip was a kid who bubbled at me "which country?" (as they 
all do over here), and when I said "Australia" he immediately replied with a 
very ocker "Oh, G'Day mate!!". It threw me big time, and was quite funny.</p>

<p>We're in Bombay/Mumbai now, and tomorrow we'll head off for our last round 
of sightseeing, some impressive and very old caves at Ajanta and Elora, and 
a nice old meteorite crater near Lonar. Should be good.</p>

<p>So chances are the next email I'll send will be from home, as I'm heading 
back to the land of Oz on the 15th. If not it'll be just before I leave.</p>

<p>Insane people may want to know when the plane arrives - I think it is 
8:30pm, next friday. ;)</p>

<p>Anyway, that's it! Only a week to go, and then back to the 'real' world. 
Yay.</p>
<br><br>
All images in this gallery:<br>
<table width='800'>
<tr>
</tr>
<tr><td><A ID='F1020028.JPG' href='camelstigersoctopussies.php?fileId=F1020028.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001209/F1020028.JPG' ALT='F1020028.JPG'><BR>F1020028.JPG<br>87.39 KB</a><div class='inv'><br><a href='./images/20001209/F1020028.JPG' ALT='F1020028.JPG'>F1020028.JPG</a></div></td>
<td><A ID='F1020029.JPG' href='camelstigersoctopussies.php?fileId=F1020029.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001209/F1020029.JPG' ALT='F1020029.JPG'><BR>F1020029.JPG<br>107.4 KB</a><div class='inv'><br><a href='./images/20001209/F1020029.JPG' ALT='F1020029.JPG'>F1020029.JPG</a></div></td>
<td><A ID='F1020030.JPG' href='camelstigersoctopussies.php?fileId=F1020030.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001209/F1020030.JPG' ALT='F1020030.JPG'><BR>F1020030.JPG<br>99.45 KB</a><div class='inv'><br><a href='./images/20001209/F1020030.JPG' ALT='F1020030.JPG'>F1020030.JPG</a></div></td>
<td><A ID='F1020034.JPG' href='camelstigersoctopussies.php?fileId=F1020034.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001209/F1020034.JPG' ALT='F1020034.JPG'><BR>F1020034.JPG<br>102.02 KB</a><div class='inv'><br><a href='./images/20001209/F1020034.JPG' ALT='F1020034.JPG'>F1020034.JPG</a></div></td>
<td><A ID='F1020035.JPG' href='camelstigersoctopussies.php?fileId=F1020035.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001209/F1020035.JPG' ALT='F1020035.JPG'><BR>F1020035.JPG<br>90.4 KB</a><div class='inv'><br><a href='./images/20001209/F1020035.JPG' ALT='F1020035.JPG'>F1020035.JPG</a></div></td>
</tr>
<tr><td><A ID='F1020037.JPG' href='camelstigersoctopussies.php?fileId=F1020037.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001209/F1020037.JPG' ALT='F1020037.JPG'><BR>F1020037.JPG<br>120.05 KB</a><div class='inv'><br><a href='./images/20001209/F1020037.JPG' ALT='F1020037.JPG'>F1020037.JPG</a></div></td>
<td><A ID='F1030001.JPG' href='camelstigersoctopussies.php?fileId=F1030001.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001209/F1030001.JPG' ALT='F1030001.JPG'><BR>F1030001.JPG<br>150.6 KB</a><div class='inv'><br><a href='./images/20001209/F1030001.JPG' ALT='F1030001.JPG'>F1030001.JPG</a></div></td>
<td><A ID='F1030002.JPG' href='camelstigersoctopussies.php?fileId=F1030002.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001209/F1030002.JPG' ALT='F1030002.JPG'><BR>F1030002.JPG<br>91.69 KB</a><div class='inv'><br><a href='./images/20001209/F1030002.JPG' ALT='F1030002.JPG'>F1030002.JPG</a></div></td>
<td><A ID='F1030003.JPG' href='camelstigersoctopussies.php?fileId=F1030003.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001209/F1030003.JPG' ALT='F1030003.JPG'><BR>F1030003.JPG<br>99.51 KB</a><div class='inv'><br><a href='./images/20001209/F1030003.JPG' ALT='F1030003.JPG'>F1030003.JPG</a></div></td>
<td><A ID='F1030004.JPG' href='camelstigersoctopussies.php?fileId=F1030004.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001209/F1030004.JPG' ALT='F1030004.JPG'><BR>F1030004.JPG<br>85.37 KB</a><div class='inv'><br><a href='./images/20001209/F1030004.JPG' ALT='F1030004.JPG'>F1030004.JPG</a></div></td>
</tr>
<tr><td><A ID='F1030005.JPG' href='camelstigersoctopussies.php?fileId=F1030005.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001209/F1030005.JPG' ALT='F1030005.JPG'><BR>F1030005.JPG<br>94.6 KB</a><div class='inv'><br><a href='./images/20001209/F1030005.JPG' ALT='F1030005.JPG'>F1030005.JPG</a></div></td>
<td><A ID='F1030006.JPG' href='camelstigersoctopussies.php?fileId=F1030006.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001209/F1030006.JPG' ALT='F1030006.JPG'><BR>F1030006.JPG<br>200.83 KB</a><div class='inv'><br><a href='./images/20001209/F1030006.JPG' ALT='F1030006.JPG'>F1030006.JPG</a></div></td>
<td><A ID='F1030007.JPG' href='camelstigersoctopussies.php?fileId=F1030007.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001209/F1030007.JPG' ALT='F1030007.JPG'><BR>F1030007.JPG<br>96.43 KB</a><div class='inv'><br><a href='./images/20001209/F1030007.JPG' ALT='F1030007.JPG'>F1030007.JPG</a></div></td>
<td><A ID='F1030009.JPG' href='camelstigersoctopussies.php?fileId=F1030009.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001209/F1030009.JPG' ALT='F1030009.JPG'><BR>F1030009.JPG<br>115.72 KB</a><div class='inv'><br><a href='./images/20001209/F1030009.JPG' ALT='F1030009.JPG'>F1030009.JPG</a></div></td>
<td><A ID='F1030010.JPG' href='camelstigersoctopussies.php?fileId=F1030010.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001209/F1030010.JPG' ALT='F1030010.JPG'><BR>F1030010.JPG<br>155.8 KB</a><div class='inv'><br><a href='./images/20001209/F1030010.JPG' ALT='F1030010.JPG'>F1030010.JPG</a></div></td>
</tr>
<tr><td><A ID='F1030012.JPG' href='camelstigersoctopussies.php?fileId=F1030012.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001209/F1030012.JPG' ALT='F1030012.JPG'><BR>F1030012.JPG<br>88.83 KB</a><div class='inv'><br><a href='./images/20001209/F1030012.JPG' ALT='F1030012.JPG'>F1030012.JPG</a></div></td>
<td><A ID='F1030014.JPG' href='camelstigersoctopussies.php?fileId=F1030014.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001209/F1030014.JPG' ALT='F1030014.JPG'><BR>F1030014.JPG<br>90.54 KB</a><div class='inv'><br><a href='./images/20001209/F1030014.JPG' ALT='F1030014.JPG'>F1030014.JPG</a></div></td>
<td><A ID='F1030015.JPG' href='camelstigersoctopussies.php?fileId=F1030015.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001209/F1030015.JPG' ALT='F1030015.JPG'><BR>F1030015.JPG<br>85.87 KB</a><div class='inv'><br><a href='./images/20001209/F1030015.JPG' ALT='F1030015.JPG'>F1030015.JPG</a></div></td>
<td><A ID='F1030017.JPG' href='camelstigersoctopussies.php?fileId=F1030017.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001209/F1030017.JPG' ALT='F1030017.JPG'><BR>F1030017.JPG<br>88.79 KB</a><div class='inv'><br><a href='./images/20001209/F1030017.JPG' ALT='F1030017.JPG'>F1030017.JPG</a></div></td>
<td><A ID='F1030018.JPG' href='camelstigersoctopussies.php?fileId=F1030018.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001209/F1030018.JPG' ALT='F1030018.JPG'><BR>F1030018.JPG<br>117.57 KB</a><div class='inv'><br><a href='./images/20001209/F1030018.JPG' ALT='F1030018.JPG'>F1030018.JPG</a></div></td>
</tr>
<tr><td><A ID='F1030020.JPG' href='camelstigersoctopussies.php?fileId=F1030020.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001209/F1030020.JPG' ALT='F1030020.JPG'><BR>F1030020.JPG<br>76.38 KB</a><div class='inv'><br><a href='./images/20001209/F1030020.JPG' ALT='F1030020.JPG'>F1030020.JPG</a></div></td>
<td><A ID='F1030021.JPG' href='camelstigersoctopussies.php?fileId=F1030021.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001209/F1030021.JPG' ALT='F1030021.JPG'><BR>F1030021.JPG<br>73.38 KB</a><div class='inv'><br><a href='./images/20001209/F1030021.JPG' ALT='F1030021.JPG'>F1030021.JPG</a></div></td>
<td><A ID='F1030027.JPG' href='camelstigersoctopussies.php?fileId=F1030027.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001209/F1030027.JPG' ALT='F1030027.JPG'><BR>F1030027.JPG<br>101.23 KB</a><div class='inv'><br><a href='./images/20001209/F1030027.JPG' ALT='F1030027.JPG'>F1030027.JPG</a></div></td>
<td><A ID='F1030028.JPG' href='camelstigersoctopussies.php?fileId=F1030028.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001209/F1030028.JPG' ALT='F1030028.JPG'><BR>F1030028.JPG<br>108.85 KB</a><div class='inv'><br><a href='./images/20001209/F1030028.JPG' ALT='F1030028.JPG'>F1030028.JPG</a></div></td>
<td><A ID='F1030029.JPG' href='camelstigersoctopussies.php?fileId=F1030029.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001209/F1030029.JPG' ALT='F1030029.JPG'><BR>F1030029.JPG<br>100.13 KB</a><div class='inv'><br><a href='./images/20001209/F1030029.JPG' ALT='F1030029.JPG'>F1030029.JPG</a></div></td>
</tr>
<tr><td><A ID='F1030030.JPG' href='camelstigersoctopussies.php?fileId=F1030030.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001209/F1030030.JPG' ALT='F1030030.JPG'><BR>F1030030.JPG<br>94.15 KB</a><div class='inv'><br><a href='./images/20001209/F1030030.JPG' ALT='F1030030.JPG'>F1030030.JPG</a></div></td>
<td><A ID='F1030031.JPG' href='camelstigersoctopussies.php?fileId=F1030031.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001209/F1030031.JPG' ALT='F1030031.JPG'><BR>F1030031.JPG<br>95.97 KB</a><div class='inv'><br><a href='./images/20001209/F1030031.JPG' ALT='F1030031.JPG'>F1030031.JPG</a></div></td>
<td><A ID='F1030032.JPG' href='camelstigersoctopussies.php?fileId=F1030032.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001209/F1030032.JPG' ALT='F1030032.JPG'><BR>F1030032.JPG<br>83.2 KB</a><div class='inv'><br><a href='./images/20001209/F1030032.JPG' ALT='F1030032.JPG'>F1030032.JPG</a></div></td>
<td><A ID='F1030036.JPG' href='camelstigersoctopussies.php?fileId=F1030036.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001209/F1030036.JPG' ALT='F1030036.JPG'><BR>F1030036.JPG<br>113.5 KB</a><div class='inv'><br><a href='./images/20001209/F1030036.JPG' ALT='F1030036.JPG'>F1030036.JPG</a></div></td>
<td><A ID='F1030037.JPG' href='camelstigersoctopussies.php?fileId=F1030037.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001209/F1030037.JPG' ALT='F1030037.JPG'><BR>F1030037.JPG<br>120.27 KB</a><div class='inv'><br><a href='./images/20001209/F1030037.JPG' ALT='F1030037.JPG'>F1030037.JPG</a></div></td>
</tr>
<tr><td><A ID='F1040001.JPG' href='camelstigersoctopussies.php?fileId=F1040001.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001209/F1040001.JPG' ALT='F1040001.JPG'><BR>F1040001.JPG<br>102.84 KB</a><div class='inv'><br><a href='./images/20001209/F1040001.JPG' ALT='F1040001.JPG'>F1040001.JPG</a></div></td>
<td><A ID='F1040003.JPG' href='camelstigersoctopussies.php?fileId=F1040003.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001209/F1040003.JPG' ALT='F1040003.JPG'><BR>F1040003.JPG<br>28.27 KB</a><div class='inv'><br><a href='./images/20001209/F1040003.JPG' ALT='F1040003.JPG'>F1040003.JPG</a></div></td>
<td><A ID='F1040004.JPG' href='camelstigersoctopussies.php?fileId=F1040004.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001209/F1040004.JPG' ALT='F1040004.JPG'><BR>F1040004.JPG<br>92.08 KB</a><div class='inv'><br><a href='./images/20001209/F1040004.JPG' ALT='F1040004.JPG'>F1040004.JPG</a></div></td>
<td><A ID='F1040005.JPG' href='camelstigersoctopussies.php?fileId=F1040005.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001209/F1040005.JPG' ALT='F1040005.JPG'><BR>F1040005.JPG<br>84.42 KB</a><div class='inv'><br><a href='./images/20001209/F1040005.JPG' ALT='F1040005.JPG'>F1040005.JPG</a></div></td>
<td><A ID='F1040006.JPG' href='camelstigersoctopussies.php?fileId=F1040006.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001209/F1040006.JPG' ALT='F1040006.JPG'><BR>F1040006.JPG<br>104.8 KB</a><div class='inv'><br><a href='./images/20001209/F1040006.JPG' ALT='F1040006.JPG'>F1040006.JPG</a></div></td>
</tr>
<tr><td><A ID='F1040007.JPG' href='camelstigersoctopussies.php?fileId=F1040007.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001209/F1040007.JPG' ALT='F1040007.JPG'><BR>F1040007.JPG<br>94.09 KB</a><div class='inv'><br><a href='./images/20001209/F1040007.JPG' ALT='F1040007.JPG'>F1040007.JPG</a></div></td>
<td><A ID='F1040008.JPG' href='camelstigersoctopussies.php?fileId=F1040008.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001209/F1040008.JPG' ALT='F1040008.JPG'><BR>F1040008.JPG<br>92.49 KB</a><div class='inv'><br><a href='./images/20001209/F1040008.JPG' ALT='F1040008.JPG'>F1040008.JPG</a></div></td>
<td><A ID='F1040010.JPG' href='camelstigersoctopussies.php?fileId=F1040010.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001209/F1040010.JPG' ALT='F1040010.JPG'><BR>F1040010.JPG<br>54.21 KB</a><div class='inv'><br><a href='./images/20001209/F1040010.JPG' ALT='F1040010.JPG'>F1040010.JPG</a></div></td>
<td><A ID='F1040011.JPG' href='camelstigersoctopussies.php?fileId=F1040011.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001209/F1040011.JPG' ALT='F1040011.JPG'><BR>F1040011.JPG<br>54.36 KB</a><div class='inv'><br><a href='./images/20001209/F1040011.JPG' ALT='F1040011.JPG'>F1040011.JPG</a></div></td>
<td><A ID='F1040012.JPG' href='camelstigersoctopussies.php?fileId=F1040012.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001209/F1040012.JPG' ALT='F1040012.JPG'><BR>F1040012.JPG<br>75.99 KB</a><div class='inv'><br><a href='./images/20001209/F1040012.JPG' ALT='F1040012.JPG'>F1040012.JPG</a></div></td>
</tr>
<tr><td><A ID='F1040013.JPG' href='camelstigersoctopussies.php?fileId=F1040013.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001209/F1040013.JPG' ALT='F1040013.JPG'><BR>F1040013.JPG<br>65.22 KB</a><div class='inv'><br><a href='./images/20001209/F1040013.JPG' ALT='F1040013.JPG'>F1040013.JPG</a></div></td>
<td><A ID='F1040015.JPG' href='camelstigersoctopussies.php?fileId=F1040015.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001209/F1040015.JPG' ALT='F1040015.JPG'><BR>F1040015.JPG<br>41.17 KB</a><div class='inv'><br><a href='./images/20001209/F1040015.JPG' ALT='F1040015.JPG'>F1040015.JPG</a></div></td>
<td><A ID='F1040016.JPG' href='camelstigersoctopussies.php?fileId=F1040016.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001209/F1040016.JPG' ALT='F1040016.JPG'><BR>F1040016.JPG<br>87.19 KB</a><div class='inv'><br><a href='./images/20001209/F1040016.JPG' ALT='F1040016.JPG'>F1040016.JPG</a></div></td>
<td><A ID='F1040019.JPG' href='camelstigersoctopussies.php?fileId=F1040019.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001209/F1040019.JPG' ALT='F1040019.JPG'><BR>F1040019.JPG<br>99.77 KB</a><div class='inv'><br><a href='./images/20001209/F1040019.JPG' ALT='F1040019.JPG'>F1040019.JPG</a></div></td>
<td><A ID='F1040022.JPG' href='camelstigersoctopussies.php?fileId=F1040022.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001209/F1040022.JPG' ALT='F1040022.JPG'><BR>F1040022.JPG<br>78.34 KB</a><div class='inv'><br><a href='./images/20001209/F1040022.JPG' ALT='F1040022.JPG'>F1040022.JPG</a></div></td>
</tr>
<tr><td><A ID='F1040023.JPG' href='camelstigersoctopussies.php?fileId=F1040023.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001209/F1040023.JPG' ALT='F1040023.JPG'><BR>F1040023.JPG<br>66.82 KB</a><div class='inv'><br><a href='./images/20001209/F1040023.JPG' ALT='F1040023.JPG'>F1040023.JPG</a></div></td>
<td><A ID='F1040024.JPG' href='camelstigersoctopussies.php?fileId=F1040024.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001209/F1040024.JPG' ALT='F1040024.JPG'><BR>F1040024.JPG<br>52.82 KB</a><div class='inv'><br><a href='./images/20001209/F1040024.JPG' ALT='F1040024.JPG'>F1040024.JPG</a></div></td>
<td><A ID='F1040025.JPG' href='camelstigersoctopussies.php?fileId=F1040025.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001209/F1040025.JPG' ALT='F1040025.JPG'><BR>F1040025.JPG<br>104.04 KB</a><div class='inv'><br><a href='./images/20001209/F1040025.JPG' ALT='F1040025.JPG'>F1040025.JPG</a></div></td>
<td><A ID='F1040026.JPG' href='camelstigersoctopussies.php?fileId=F1040026.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001209/F1040026.JPG' ALT='F1040026.JPG'><BR>F1040026.JPG<br>65.02 KB</a><div class='inv'><br><a href='./images/20001209/F1040026.JPG' ALT='F1040026.JPG'>F1040026.JPG</a></div></td>
<td><A ID='F1040027.JPG' href='camelstigersoctopussies.php?fileId=F1040027.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001209/F1040027.JPG' ALT='F1040027.JPG'><BR>F1040027.JPG<br>63.03 KB</a><div class='inv'><br><a href='./images/20001209/F1040027.JPG' ALT='F1040027.JPG'>F1040027.JPG</a></div></td>
</tr>
<tr><td><A ID='F1040028.JPG' href='camelstigersoctopussies.php?fileId=F1040028.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001209/F1040028.JPG' ALT='F1040028.JPG'><BR>F1040028.JPG<br>113.44 KB</a><div class='inv'><br><a href='./images/20001209/F1040028.JPG' ALT='F1040028.JPG'>F1040028.JPG</a></div></td>
<td><A ID='F1040029.JPG' href='camelstigersoctopussies.php?fileId=F1040029.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001209/F1040029.JPG' ALT='F1040029.JPG'><BR>F1040029.JPG<br>101.17 KB</a><div class='inv'><br><a href='./images/20001209/F1040029.JPG' ALT='F1040029.JPG'>F1040029.JPG</a></div></td>
<td><A ID='F1040030.JPG' href='camelstigersoctopussies.php?fileId=F1040030.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001209/F1040030.JPG' ALT='F1040030.JPG'><BR>F1040030.JPG<br>80.19 KB</a><div class='inv'><br><a href='./images/20001209/F1040030.JPG' ALT='F1040030.JPG'>F1040030.JPG</a></div></td>
<td><A ID='F1040031.JPG' href='camelstigersoctopussies.php?fileId=F1040031.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001209/F1040031.JPG' ALT='F1040031.JPG'><BR>F1040031.JPG<br>71.03 KB</a><div class='inv'><br><a href='./images/20001209/F1040031.JPG' ALT='F1040031.JPG'>F1040031.JPG</a></div></td>
<td><A ID='F1040033.JPG' href='camelstigersoctopussies.php?fileId=F1040033.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001209/F1040033.JPG' ALT='F1040033.JPG'><BR>F1040033.JPG<br>89.99 KB</a><div class='inv'><br><a href='./images/20001209/F1040033.JPG' ALT='F1040033.JPG'>F1040033.JPG</a></div></td>
</tr>
<tr><td><A ID='F1040034.JPG' href='camelstigersoctopussies.php?fileId=F1040034.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001209/F1040034.JPG' ALT='F1040034.JPG'><BR>F1040034.JPG<br>140.04 KB</a><div class='inv'><br><a href='./images/20001209/F1040034.JPG' ALT='F1040034.JPG'>F1040034.JPG</a></div></td>
<td><A ID='F1040035.JPG' href='camelstigersoctopussies.php?fileId=F1040035.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001209/F1040035.JPG' ALT='F1040035.JPG'><BR>F1040035.JPG<br>121.57 KB</a><div class='inv'><br><a href='./images/20001209/F1040035.JPG' ALT='F1040035.JPG'>F1040035.JPG</a></div></td>
<td><A ID='F1040036.JPG' href='camelstigersoctopussies.php?fileId=F1040036.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001209/F1040036.JPG' ALT='F1040036.JPG'><BR>F1040036.JPG<br>80.8 KB</a><div class='inv'><br><a href='./images/20001209/F1040036.JPG' ALT='F1040036.JPG'>F1040036.JPG</a></div></td>
<td><A ID='F1050001.JPG' href='camelstigersoctopussies.php?fileId=F1050001.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001209/F1050001.JPG' ALT='F1050001.JPG'><BR>F1050001.JPG<br>72.4 KB</a><div class='inv'><br><a href='./images/20001209/F1050001.JPG' ALT='F1050001.JPG'>F1050001.JPG</a></div></td>
<td><A ID='F1050003.JPG' href='camelstigersoctopussies.php?fileId=F1050003.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001209/F1050003.JPG' ALT='F1050003.JPG'><BR>F1050003.JPG<br>132.9 KB</a><div class='inv'><br><a href='./images/20001209/F1050003.JPG' ALT='F1050003.JPG'>F1050003.JPG</a></div></td>
</tr>
<tr><td><A ID='F1050004.JPG' href='camelstigersoctopussies.php?fileId=F1050004.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001209/F1050004.JPG' ALT='F1050004.JPG'><BR>F1050004.JPG<br>74.96 KB</a><div class='inv'><br><a href='./images/20001209/F1050004.JPG' ALT='F1050004.JPG'>F1050004.JPG</a></div></td>
<td><A ID='F1050005.JPG' href='camelstigersoctopussies.php?fileId=F1050005.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001209/F1050005.JPG' ALT='F1050005.JPG'><BR>F1050005.JPG<br>80.03 KB</a><div class='inv'><br><a href='./images/20001209/F1050005.JPG' ALT='F1050005.JPG'>F1050005.JPG</a></div></td>
<td><A ID='F1050006.JPG' href='camelstigersoctopussies.php?fileId=F1050006.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001209/F1050006.JPG' ALT='F1050006.JPG'><BR>F1050006.JPG<br>116.17 KB</a><div class='inv'><br><a href='./images/20001209/F1050006.JPG' ALT='F1050006.JPG'>F1050006.JPG</a></div></td>
<td><A ID='F1050007.JPG' href='camelstigersoctopussies.php?fileId=F1050007.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001209/F1050007.JPG' ALT='F1050007.JPG'><BR>F1050007.JPG<br>147.36 KB</a><div class='inv'><br><a href='./images/20001209/F1050007.JPG' ALT='F1050007.JPG'>F1050007.JPG</a></div></td>
<td><A ID='F1050008.JPG' href='camelstigersoctopussies.php?fileId=F1050008.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001209/F1050008.JPG' ALT='F1050008.JPG'><BR>F1050008.JPG<br>67.93 KB</a><div class='inv'><br><a href='./images/20001209/F1050008.JPG' ALT='F1050008.JPG'>F1050008.JPG</a></div></td>
</tr>
<tr><td><A ID='F1050009.JPG' href='camelstigersoctopussies.php?fileId=F1050009.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001209/F1050009.JPG' ALT='F1050009.JPG'><BR>F1050009.JPG<br>128.13 KB</a><div class='inv'><br><a href='./images/20001209/F1050009.JPG' ALT='F1050009.JPG'>F1050009.JPG</a></div></td>
<td><A ID='F1050011.JPG' href='camelstigersoctopussies.php?fileId=F1050011.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001209/F1050011.JPG' ALT='F1050011.JPG'><BR>F1050011.JPG<br>72.9 KB</a><div class='inv'><br><a href='./images/20001209/F1050011.JPG' ALT='F1050011.JPG'>F1050011.JPG</a></div></td>
<td><A ID='F1050012.JPG' href='camelstigersoctopussies.php?fileId=F1050012.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001209/F1050012.JPG' ALT='F1050012.JPG'><BR>F1050012.JPG<br>83.2 KB</a><div class='inv'><br><a href='./images/20001209/F1050012.JPG' ALT='F1050012.JPG'>F1050012.JPG</a></div></td>
<td><A ID='F1050013.JPG' href='camelstigersoctopussies.php?fileId=F1050013.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001209/F1050013.JPG' ALT='F1050013.JPG'><BR>F1050013.JPG<br>66.86 KB</a><div class='inv'><br><a href='./images/20001209/F1050013.JPG' ALT='F1050013.JPG'>F1050013.JPG</a></div></td>
<td><A ID='F1050014.JPG' href='camelstigersoctopussies.php?fileId=F1050014.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001209/F1050014.JPG' ALT='F1050014.JPG'><BR>F1050014.JPG<br>84.17 KB</a><div class='inv'><br><a href='./images/20001209/F1050014.JPG' ALT='F1050014.JPG'>F1050014.JPG</a></div></td>
</tr>
<tr><td><A ID='F1050015.JPG' href='camelstigersoctopussies.php?fileId=F1050015.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001209/F1050015.JPG' ALT='F1050015.JPG'><BR>F1050015.JPG<br>105.75 KB</a><div class='inv'><br><a href='./images/20001209/F1050015.JPG' ALT='F1050015.JPG'>F1050015.JPG</a></div></td>
<td><A ID='F1050016.JPG' href='camelstigersoctopussies.php?fileId=F1050016.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001209/F1050016.JPG' ALT='F1050016.JPG'><BR>F1050016.JPG<br>86.93 KB</a><div class='inv'><br><a href='./images/20001209/F1050016.JPG' ALT='F1050016.JPG'>F1050016.JPG</a></div></td>
<td><A ID='F1050017.JPG' href='camelstigersoctopussies.php?fileId=F1050017.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001209/F1050017.JPG' ALT='F1050017.JPG'><BR>F1050017.JPG<br>92.43 KB</a><div class='inv'><br><a href='./images/20001209/F1050017.JPG' ALT='F1050017.JPG'>F1050017.JPG</a></div></td>
<td><A ID='F1050019.JPG' href='camelstigersoctopussies.php?fileId=F1050019.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001209/F1050019.JPG' ALT='F1050019.JPG'><BR>F1050019.JPG<br>55.88 KB</a><div class='inv'><br><a href='./images/20001209/F1050019.JPG' ALT='F1050019.JPG'>F1050019.JPG</a></div></td>
<td><A ID='F1050020.JPG' href='camelstigersoctopussies.php?fileId=F1050020.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001209/F1050020.JPG' ALT='F1050020.JPG'><BR>F1050020.JPG<br>124.83 KB</a><div class='inv'><br><a href='./images/20001209/F1050020.JPG' ALT='F1050020.JPG'>F1050020.JPG</a></div></td>
</tr>
<tr><td><A ID='F1050023.JPG' href='camelstigersoctopussies.php?fileId=F1050023.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001209/F1050023.JPG' ALT='F1050023.JPG'><BR>F1050023.JPG<br>156.55 KB</a><div class='inv'><br><a href='./images/20001209/F1050023.JPG' ALT='F1050023.JPG'>F1050023.JPG</a></div></td>
<td><A ID='F1050024.JPG' href='camelstigersoctopussies.php?fileId=F1050024.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001209/F1050024.JPG' ALT='F1050024.JPG'><BR>F1050024.JPG<br>150.2 KB</a><div class='inv'><br><a href='./images/20001209/F1050024.JPG' ALT='F1050024.JPG'>F1050024.JPG</a></div></td>
<td><A ID='F1050025.JPG' href='camelstigersoctopussies.php?fileId=F1050025.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001209/F1050025.JPG' ALT='F1050025.JPG'><BR>F1050025.JPG<br>113.73 KB</a><div class='inv'><br><a href='./images/20001209/F1050025.JPG' ALT='F1050025.JPG'>F1050025.JPG</a></div></td>
<td><A ID='F1050026.JPG' href='camelstigersoctopussies.php?fileId=F1050026.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001209/F1050026.JPG' ALT='F1050026.JPG'><BR>F1050026.JPG<br>112.25 KB</a><div class='inv'><br><a href='./images/20001209/F1050026.JPG' ALT='F1050026.JPG'>F1050026.JPG</a></div></td>
<td><A ID='F1050027.JPG' href='camelstigersoctopussies.php?fileId=F1050027.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001209/F1050027.JPG' ALT='F1050027.JPG'><BR>F1050027.JPG<br>107.67 KB</a><div class='inv'><br><a href='./images/20001209/F1050027.JPG' ALT='F1050027.JPG'>F1050027.JPG</a></div></td>
</tr>
<tr><td><A ID='F1050028.JPG' href='camelstigersoctopussies.php?fileId=F1050028.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001209/F1050028.JPG' ALT='F1050028.JPG'><BR>F1050028.JPG<br>133.46 KB</a><div class='inv'><br><a href='./images/20001209/F1050028.JPG' ALT='F1050028.JPG'>F1050028.JPG</a></div></td>
<td><A ID='F1050029.JPG' href='camelstigersoctopussies.php?fileId=F1050029.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001209/F1050029.JPG' ALT='F1050029.JPG'><BR>F1050029.JPG<br>114.39 KB</a><div class='inv'><br><a href='./images/20001209/F1050029.JPG' ALT='F1050029.JPG'>F1050029.JPG</a></div></td>
<td><A ID='F1050030.JPG' href='camelstigersoctopussies.php?fileId=F1050030.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001209/F1050030.JPG' ALT='F1050030.JPG'><BR>F1050030.JPG<br>108.21 KB</a><div class='inv'><br><a href='./images/20001209/F1050030.JPG' ALT='F1050030.JPG'>F1050030.JPG</a></div></td>
<td><A ID='F1060003.JPG' href='camelstigersoctopussies.php?fileId=F1060003.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001209/F1060003.JPG' ALT='F1060003.JPG'><BR>F1060003.JPG<br>116.82 KB</a><div class='inv'><br><a href='./images/20001209/F1060003.JPG' ALT='F1060003.JPG'>F1060003.JPG</a></div></td>
<td><A ID='F1060009.JPG' href='camelstigersoctopussies.php?fileId=F1060009.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001209/F1060009.JPG' ALT='F1060009.JPG'><BR>F1060009.JPG<br>151.91 KB</a><div class='inv'><br><a href='./images/20001209/F1060009.JPG' ALT='F1060009.JPG'>F1060009.JPG</a></div></td>
</tr>
<tr><td><A ID='F1060011.JPG' href='camelstigersoctopussies.php?fileId=F1060011.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001209/F1060011.JPG' ALT='F1060011.JPG'><BR>F1060011.JPG<br>128.58 KB</a><div class='inv'><br><a href='./images/20001209/F1060011.JPG' ALT='F1060011.JPG'>F1060011.JPG</a></div></td>
<td><A ID='F1060012.JPG' href='camelstigersoctopussies.php?fileId=F1060012.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001209/F1060012.JPG' ALT='F1060012.JPG'><BR>F1060012.JPG<br>161.54 KB</a><div class='inv'><br><a href='./images/20001209/F1060012.JPG' ALT='F1060012.JPG'>F1060012.JPG</a></div></td>
<td><A ID='F1060014.JPG' href='camelstigersoctopussies.php?fileId=F1060014.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001209/F1060014.JPG' ALT='F1060014.JPG'><BR>F1060014.JPG<br>99.43 KB</a><div class='inv'><br><a href='./images/20001209/F1060014.JPG' ALT='F1060014.JPG'>F1060014.JPG</a></div></td>
<td><A ID='F1060015.JPG' href='camelstigersoctopussies.php?fileId=F1060015.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001209/F1060015.JPG' ALT='F1060015.JPG'><BR>F1060015.JPG<br>94.05 KB</a><div class='inv'><br><a href='./images/20001209/F1060015.JPG' ALT='F1060015.JPG'>F1060015.JPG</a></div></td>
<td><A ID='F1060020.JPG' href='camelstigersoctopussies.php?fileId=F1060020.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001209/F1060020.JPG' ALT='F1060020.JPG'><BR>F1060020.JPG<br>94.25 KB</a><div class='inv'><br><a href='./images/20001209/F1060020.JPG' ALT='F1060020.JPG'>F1060020.JPG</a></div></td>
</tr>
<tr><td><A ID='F1060021.JPG' href='camelstigersoctopussies.php?fileId=F1060021.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001209/F1060021.JPG' ALT='F1060021.JPG'><BR>F1060021.JPG<br>109.97 KB</a><div class='inv'><br><a href='./images/20001209/F1060021.JPG' ALT='F1060021.JPG'>F1060021.JPG</a></div></td>
</tr>
</table>	</div>
</div>
</body>
</html>