<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - February 2005 - Q&A letters</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="Q&A letters">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="Q&A letters" href='masterit200501.php'>January 2005</a></li>
<li><div class='activemenu'>February 2005</div></li>
<li><a title="Q&A letters" href='masterit200503.php'>March 2005</a></li>
<li><a title="Q&A letters" href='masterit200504.php'>April 2005</a></li>
<li><a title="Q&A letters" href='masterit200505.php'>May 2005</a></li>
<li><a title="Q&A letters" href='masterit200506.php'>June 2005</a></li>
<li><a title="Q&A letters" href='masterit200507.php'>July 2005</a></li>
<li><a title="Q&A letters" href='masterit200508.php'>August 2005</a></li>
<li><a title="Q&A letters" href='masterit200509.php'>September 2005</a></li>
<li><a title="Q&A letters" href='masterit200510.php'>October 2005</a></li>
<li><a title="Q&A letters" href='masterit200511.php'>November 2005</a></li>
<li><a title="Q&A letters" href='masterit200512.php'>December 2005</a></li>
<li> </li><br><li>Or go back to:</li><li><a title='Q&A/MasterIT letters from 2005' href="masterit2005.php">2005 archive</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>February 2005</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Mark's writing' href="written.php">Professional Writing</a> > <a title='My weekly Q&A column in The Australian' href="masterIT.php">MasterIT</a> > <a title='Q&A/MasterIT letters from 2005' href="masterit2005.php">2005 archive</a> > <a title='Q&A letters' href="masterit200502.php">February 2005</a>
<br><br>		<br>
<h2>15/2/05</h2><br>
<b>I have a few files stored on an old hard drive that I'd like to retrieve. The drive has been retired from active service for a while; it's basically spent the last year or two on a shelf. I connected the drive and to my horror it refuses to spin up - it just makes a buzzing noise for a second. I realise it was foolish to leave files I needed on an old drive, but I didn't exactly expect it to die of neglect. Is there anything I can do?</b><br>
<br>
Data retrieval services are certainly an option here, but unfortunately they don't come cheap (think hundreds or thousands). It all depends on how important the files are to you.<br>
<br>
There is, however, something you can try first.<br>
<br>
Assuming that the drive was in reasonable working order when you took it out of the machine, it's quite likely that all that's happened is that the drive has a case of 'stiction'. This is a condition common of older drives, where the drive heads actually stick to the platter. If this is the case, you're fairly likely to be able to unstick it with a quick twist. Hitting the drive (more percussive maintenance), whilst fun, isn't advisable.<br>
<br>
A PDF on the subject is available at tinyurl.com/3pqk4. If you do get it going, back up everything on it, then ditch it (feel free to harvest the magnets from it first - see tinyurl.com/4bydh for more info).<br>
<br>
<br>
<b>I have an HP iPaq 4150. It works fine with Outlook on my home PC, but at work Lotus Notes is causing problems. Synchronisation is performed using Intellisync, and due to some incompatibility with daylight savings, all recurring meetings on the iPaq are behind by 1 hour. Microsoft is aware of the problem but said it's the vendor's problem. HP is aware of the problem, but as yet they can't provide a fix. Any thoughts on a solution?</b><br>
<br>
Unfortunately, we're all at the mercy of software vendors in a case like this.<br>
<br>
Apart from ditching Lotus Notes, I did have one lateral idea; set your iPaq clock one hour back and see if the meetings are in sync. This is no good for reminders of course (although you could set them an hour in advance), but at least the calendar would be accurate.<br>
<br>
Your only other option would be to export from Lotus into some intermediate application, like Outlook, and then sync on to the iPaq.<br>
<br>
<br>
<h2>22/2/05</h2><br>
<b>My flatmate just bought a new mouse. It came with a little adaptor to go from USB to the round mouse port socket. As he's using the mouse via USB, I was wondering if I can use the adaptor to plug in my USB key into the mouse port. Will that work?</b><br>
<br>
Sorry, not even slightly. It's a good idea in theory, but the PS/2 mouse port is a completely different animal from a USB port. Unfortunately the adaptor just changes over the wiring - the actual electronic smarts for changing port type are in the mouse itself.<br>
<br>
<br>
<b>I keep getting emails from a friend with an attachment called "ms.tnef". I can't seem to open it with Thunderbird. Any ideas?</b><br>
<br>
Just ignore it - it's a rubbish settings file put there by whatever Microsoft mail program your friend uses (probably Outlook). Normally it accompanies rich text emails� both of which are perfectly good reasons to be using plain text in Thunderbird (or Mozilla).<br>
<br>
<br>
<b>I've just upgraded my aging P3 to a shiny new P4, with so called Hyperthreading. As I understand it, this makes Windows think I have two CPUs when I only have one. I'm wondering if this makes any real difference to anything - can it be disabled?</b><br>
<br>
Hyperthreading (HT) can give you a small speed boost, but it's not likely you'd notice in day to day usage. We're talking 5-10% here if you're lucky, and as a rule of thumb it's quite hard to notice any speed difference that small, unless you're a mad overclocker obsessed with running benchmarks.<br>
<br>
It can normally be disabled in the system BIOS, but there's little reason to bother. One may as well have the boost, and if you're not comfortable with playing around in the BIOS it's best to leave it alone.<br>
<br>
The only issue with HT is that very occasionally a program will play up if it's assigned to multiple CPUs, be they virtual or real. In this case, you need to change the task's CPU affinity and tell it to run on only one virtual CPU.<br>
<br>
To do this, pop open the task manager (press control-alt-delete or right click the taskbar and select it from the menu), click the processes tab, then right click on the task in question, and select "set affinity". Note that some tasks (like system processes) cannot have their affinity changed.<br>
<br>
<i><p>Did the information on this page help you? Entertain you? Bore you? <a href="contact.php?subject=MasterIT">Drop me a line</a>.</p>

<p>If you're feeling particularly generous, you can even <a href="buypics.php">click here to send me some dot-com riches</a>. Think of it as online busking.</i></p>
	</div>
</div>
</body>
</html>