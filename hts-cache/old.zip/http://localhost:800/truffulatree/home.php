<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - Home - truffulatree.com.au homepage</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="truffulatree.com.au homepage">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><div class='activemenu'>Home</div></li>
<li> </li><br>
<li><a title="About me" href='about.php'>About</a></li>
<li><a title="Picture galleries" href='pictures.php'>Photography</a></li>
<li><a title="Travel stories and pictures" href='travel.php'>Travelogues</a></li>
<li><a title="Mark's writing" href='written.php'>Professional Writing</a></li>
<li><a title="Programming work I've done" href='programming.php'>Programming</a></li>
<li><a title="Sounds and music" href='music.php'>Music</a></li>
<li><a title="Silly things for your amusement" href='silliness.php'>Silliness</a></li>
<li><a title="Old stuff from my site" href='archive.php'>Archive</a></li>
<li><a title="Contact me" href='contact.php'>Contact</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>Home</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a>
<br>Select a link on the left to continue navigating.<br><br>		<br>
This is the home page of <b>Mark Cocquio</b>.<br>
<br>
A little bit <a href="about.php">about me</a>.<br>
<br>
Why truffulatree? Because I loved The Lorax as a kid, and it seemed a nice sentiment. Truffula trees are puffy and cute too.<br>
<br>
This is not a blog! (But, I suppose, in fairness, <a href="nerdseyeview.php">this kinda was</a>)<br>
<br>
Anyway... have a look around if you haven't been here before.<br>
<br>
<h2>Latest updates:</h2><br>
<br>
<b>October 10</b> - Well! It's been a year. I guess this site is a little bit mothballed now, since I started putting all my pics up on <a href="http://www.flickr.com/strepto42" title="Mark Cocquio's flickr profile" target="_blank">flickr</a>. Why not pop over there and take a look though? There are plenty of pretty pics. In due course I'll get some <a href="travel.php">travelouges</a> up to match the <a href="http://www.flickr.com/photos/strepto42/collections/72157623378870496/" title="Pictures from a trip to Melbourne and back via outback NSW and QLD" target="_blank">pictures from January's Melbourne trip</a> and <a href="http://www.flickr.com/photos/strepto42/collections/72157624468244733/" title="Pictures from a trip to New Zealand's North Island" target="_blank">July's NZ adventure</a>. In the meantime, just amuse yourselves... :)<br>
<br>
<b>September 10</b> - The first <a href="fuzzypolaroidmp3s.php">Fuzzy Polaroid</a> "studio" recording is up! Check out the track - <a href="files/fuzzypolaroid/Studio Recordings/Don't You Wanna Know.mp3">Don't You Wanna Know</a> how it sounds?<br>
<br>
<b>October 09</b> - Seems I've been a bit slack at updating the homepage. Ok then, some latest additions include <a href="jamnight.php">a Jam Night</a>, pics from <a href="cunninghamsgap.php">Cunningham's Gap</a>, pics from an awesome <a href="bigcat.php">dive trip on Big Cat Reality</a>, <a href="birthdayjam.php">pics from another jam (some idiot's birthday)</a>, <a href="fuzzypolaroidpics.php">pictures</a> and <a href="fuzzypolaroidmp3s.php">MP3s</a> from my gigs drumming with <a href="http://www.myspace.com/fuzzypolaroid" target="_blank">Fuzzy Polaroid</a>, and finally - <a href="zombiewalk2009.php">ZOMBIES</a>. There, I think that brings us up to date. :)<br>
<br>
<b>April 09</b> - Ok, more pictures are up! First of all, <a href="allyandben.php">Ben and Alison's wedding</a>. Then we have <a href="annes30th.php">Anne's 30th</a>, and lastly pictures from the creative sabbatical at <a href="possumcreek.php">Possum Creek</a>. Fantastico!<br>
<br>
<b>January 09</b> - Another January update - Evan and Heather's wedding pics are up! <a href="heatherandevan.php">All 365 of them.</a> :)<br>
<br>
<b>January 09</b> - Finally! I feel like I've given birth. Another epic mini-travelouge is up - my trip to the Red Centre back last August. <a href="redcentre.php">Check it out here</a>.<br>
<br>
<b>January 09</b> - Again with the eek. Ah well, I've been busy. Let's see... new image galleries: <a href="bloodyknee.php">My bloody knee</a>, <a href="tyesbirthday.php">Tye's birthday</a>, <a href="lasersocialising.php">fun with a green laser</a>, and <a href="woodford0809.php">this year's Woodford pics</a>.<br>
<br>
<b>July 08</b> - Eek! It's half way through the year! I guess it's been pretty eventful... Anyway, I just finished putting up some new image galleries. First of all, a <a href="lightning.php">spectacular lightning show with moonrise</a>, as seen from basically the front of my old house. Next we have <a href="debearding.php">the scary de-bearding page</a>. Then we have the photos from <a href="michaelandkaren.php">Karen and Michael's wedding</a> - a lovely day for all concerned. Last but not least, my dear cousin Andrew turned 21 the other week, and <a href="andrews21st.php">various party pics can be found here</a>. Oh and I also forgot to mention it at the time, but there are pictures from my <a href="sydneytrip0802.php">trip down to Sydney</a> back in february to peruse too.<br>
<br>
<b>January 08</b> - Harpy New Year once again. Where the buggers go is beyond me, but it seems another one has come along. Oh well. In other news, <a href="woodford0708.php">new pictures from Woodford</a> are up again - enjoy!<br>
<br>
<b>December 07</b> - Wedding photography ahoy - the <a href="guyandalison.php">pictures from Alison and Guy's wedding</a> are up.<br>
<br>
<b>November 07</b> - I finally put up some <a href="0x0021st.php">pictures from my birthday gathering</a> back in September. Talk about slack! Strange musical creations from that night will follow soon.<br>
<br>
<b>August 07</b> - Content shuffle ahoy! I have rearranged the structure of the site, to better reflect the here and now. I've also tweaked the menu structure to make it easier to navigate around the site. Next on the agenda is some serious work on the content itself, an RSS feed, and maybe even a rework of the layout.<br>
<br>
<b>August 07</b> - I have finally uploaded <a href="masterIT.php">all of my old helpdesk columns</a>, that were written for The Australian between January 2003 and July 2007. They've axed it now, but such is the life of a freelancer.<br>
<br>
<b>July 07</b> - I got an email today from another Cocquio! At least, a former one; she's married now. Maria - I am happy to reply, but I don't have your email address - can you send it over? Also, it reminded me that earlier this year I got another email from another long-lost Cocquio. I can't remember her name; (perhaps it was Daniela?) and I lost the email in question when I was reinstalling my computer and I'd forgotten about it until now. So - Cocquios - I'm not being rude by not replying - please send me another message with your addresses and I'll get back to you!<br>
<br>
<b>July 07</b> - My darling sis came up for a visit at the end of June, and we had an excellent time playing with <a href="jezebel.php">Jez</a> and climbing at <a href="kangaroopt1.php">Kangaroo Point</a>.<br>
<br>
<b>June 07</b> - Hurrah! I've finally gotten around to putting up some new content. For your enjoyment we have my latest <a href="outbackNSW.php">travelogue on outback NSW</a>, and a page devoted to the <a href="jezebel.php">super sweet puppy Jezebel</a>. <br>
<br>
<b>January 07</b> - Harpy New Year! It seems this decade is starting to get a bit stale. Scary. Anyway, I just got back from the <a href="http://www.woodfordfolkfestival.com" target="_blank">Woodford Folk Festival</a> - 7 days of sun, rain, dust, amazing music, overpriced food and general craziness. Anyway, <a href="woodford0607.php">the pictures are up</a>, so check 'em out if you care!<br>
<br>
<b>December 06</b> - More new pics - including random visitors to our <a href="backyard.php">back yard</a>, <a href="brisbanepics1.php">Brisbane City CBD</a> and the <a href="greenbridge.php">opening day of the Eleanor Schonell Bridge</a> (which I shall keep calling the much simpler Green Bridge). The last lot includes some infra-red pictures taken at the local graveyard - <a href="greenbridge.php?fileId=IMG_2743.JPG">most</a> <a href="greenbridge.php?fileId=IMG_2753.JPG">atmospheric!</a><br>
<br>
<b>December 06</b> - New pictures! I have a backlog of thing to put up, and of course the whole site is due for a bit of a re-vamp. In the meantime, I've put up a gallery from a recent visit to <a href="lamington.php">Lamington National Park</a>.<br>
<br>
<b>October 06</b> - A hearty welcome to web crawlers from <a href="http://www.dansdata.com" target="_blank">Dansdata</a>. Enjoy yourselves, have a look around. There are still huge holes in my site; it's kinda due for a full rework shortly, including a Bad Optimus II page. Stay tuned.<br>
<br>
I've also amended the site so that the image galleries are cached using the <a href="http://www.coralcdn.org/" target="_blank">Coral Content Netowork</a>. If all the images galleries are broken, simply add "?coral=false" to the URL for a temporary fix. I'll make this a cookie or something later, when I can be bothered. :) Update - I took out the Coral stuff - it isn't needed just yet (we still have plenty of bandwidth available), and it was slowing everything down.<br>
<br>
<b>August 06</b> - Finally got off my slack arse and started putting up my old MasterIT helpdesk columns (exciting huh?). Eventually I'll get them all up - the first year is up <a href="masterit2003.php">here</a>.<br>
<br>
<b>April 06</b> - <a href="bridges.php">Added some pictures</a> from my recent trip to Sydney. It somehow ended up being a study of bridges. :)<br>
<br>
<b>March 06</b> - Well, I'm back from my travels. I'm slowly going to update the site a bit to reflect this. Sometime. Soon.<br>
<br>
<b>Feburary 06</b> - Yay we're running a CSS design now. It looks exactly the same. :)<br>
<br>
<b>August 05</b> - More updates, mostly behind the scene. There is a new image gallery engine running now. Once I get the pictures re-uploaded, it'll display EXIF metadata, like exposure time, ISO speed etc. It's very exciting. I have also added support for inbuilt thumbnails, so in future I won't have to generate separate thumbnails for new images. There is also an page now for you to <a href="buypics.php">buy pictures</a> that are on the site! This will no doubt make me millions.<br>
<br>
<b>August 05</b> - I've done a little bit more shuffling. The WD40 page is now under fun and games. Also, I've created a new section for my writing. Under that I've posted the <a href="india2000.php">old travel emails from my India trip in 2000</a>. If you're enjoying the Nerds Eye View stories and just can't get enough of my ramblings, check it out!<br>
<br>
<b>July 05</b> - I've reorganised the site a bit, as it's size was getting a bit out of hand. If stuff isn't here any more, too bad. :) <a href="nerdseyeview.php">Nerd's Eye View</a> continues of course, and it's pretty much the only active area of the site, so if you're a new visitor, <a href="mp3s.php">check it out (as David Hasselhoff Says)</a>.<br>
<br>
<b>June 05</b> - Pictures from the Rockhampton Peace Convergence are up <a href="peaceconvergence.php">here.</a><br>
<br>
<b>May 05</b> - I've finally gotten round to putting up my travelouges thus far - check 'em out under <a href="nerdseyeview.php">Nerds Eye View</a>. I've also finally uploaded the pictures from when I visited Stephen over easter - check them out <a href="jackovisit.php">here</a><br>
<br>
<br>
Also, some (possibly out of date now) links for your bemusement:<br>
<br>
<a target="_blank" href="http://www.kaozklezmer.com">http://www.kaozklezmer.com</a> - a very funky (well, klezmer) band.<br>
<a target="_blank" href="http://www.casualjim.com">http://www.casualjim.com</a> - a very funky web comic.<br>
<a target="_blank" href="http://www.digi-comic.com">http://www.digi-comic.com</a> - another very funky (in fact, funkier) web comic, occasionally featuring yours truly.<br>
<a target="_blank" href="http://www.swagtravel.com">http://www.swagtravel.com</a> - the author of a very funky CMS created this great travel blog site.<br>
<a target="_blank" href="http://www.dansdata.com">http://www.dansdata.com</a> - very funky hardware reviews and more. Some written by me!<br>
<a target="_blank" href="http://www.johnnormal.com">http://www.johnnormal.com</a> - the co-author (with yours truly) of some very funky <a href="http://www.homeirrigation.com.au" target="_blank">Flash Applications</a>.<br>
<a target="_blank" href="http://www.fromorbit.com">http://www.fromorbit.com</a> - the author of a very funky <a href="http://www.auspcmarket.com.au" target="_blank">PC shopping site</a>.<br>
<a href="http://www.2weeks.com">2weeks.com</a> - If you don't get it, I can't explain it.<br>
<br>
Hosting for this nothing site provided by the lovely folks at <a href="http://www.nocturnal-central.com">Nocturnal Entertainment Australia</a>. Thanks Shams!<br>


	</div>
</div>
</body>
</html>