<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - 16/9/2005 - Things from Above</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="Things from Above">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="Greetings from a Bum" href='greetingsfromabum.php'>29/4/2005</a></li>
<li><a title="Onward" href='onward.php'>2/5/2005</a></li>
<li><a title="It's a tough life (pt 1: Bundaberg, Agnes Water and 1770)" href='itsatoughlife1.php'>17/5/2005</a></li>
<li><a title="It's a tough life (pt 2: Rockhampton, Emu Park and Great Keppel Island)" href='itsatoughlife2.php'>23/5/2005</a></li>
<li><a title="There and Back Again - a Yo-yo's Tale" href='thereandbackagain.php'>18/6/2005</a></li>
<li><a title="Platypi and Grey Nomads" href='platypiandgreynomads.php'>24/6/2005</a></li>
<li><a title="Blowing Bubbles in a Watery Tomb" href='blowingbubbles.php'>1/7/2005</a></li>
<li><a title="Pieces of History" href='piecesofhistory.php'>8/7/2005</a></li>
<li><a title="Walks and Waterfalls" href='walksandwaterfalls.php'>15/7/2005</a></li>
<li><a title="Mission to Tribulation" href='missiontotribulation.php'>22/7/2005</a></li>
<li><a title="Levity, Limestone and Lava" href='levitylimestoneandlava.php'>29/7/2005</a></li>
<li><a title="Into the Never Never" href='intothenevernever.php'>5/8/2005</a></li>
<li><a title="Slowing the pace in Darwin" href='slowingthepaceindarwin.php'>12/8/2005</a></li>
<li><a title="Blistering Barnacles and Leaping Lizards" href='leapinglizards.php'>19/8/2005</a></li>
<li><a title="Kakadu and Litchfield" href='kakadu.php'>26/8/2005</a></li>
<li><a title="Legacies of War" href='legaciesofwar.php'>2/9/2005</a></li>
<li><a title="Go West" href='gowest.php'>10/9/2005</a></li>
<li><div class='activemenu'>16/9/2005</div></li>
<li><a title="The West Coast" href='thewestcoast.php'>23/9/2005</a></li>
<li><a title="Reefs and Red Dust" href='reefsandreddust.php'>30/9/2005</a></li>
<li><a title="The Pilbara" href='pilbara.php'>7/10/2005</a></li>
<li><a title="Paradise with a Headwind" href='paradisewithaheadwind.php'>14/10/2005</a></li>
<li><a title="Down the Coral Coast" href='downthecoralcoast.php'>21/10/2005</a></li>
<li><a title="Pinnacles and Pinnipeds" href='pinnaclesandpinnipeds.php'>28/10/2005</a></li>
<li><a title="A week in Perth" href='perth.php'>4/11/2005</a></li>
<li><a title="The Southwest (from Above and Below)" href='thesouthwest.php'>11/11/2005</a></li>
<li><a title="More Heights and Depths" href='moreheightsanddepths.php'>18/11/2005</a></li>
<li><a title="Across the Nullarbor (and a bit beyond)" href='nullarbor.php'>25/11/2005</a></li>
<li><a title="Double Whammy" href='doublewhammy.php'>9/12/2005</a></li>
<li><a title="Two Cities" href='twocities.php'>19/12/2005</a></li>
<li><a title="Tassie - Part 1" href='tassie1.php'>1/1/2006</a></li>
<li><a title="Tassie - Part 2" href='tassie2.php'>7/1/2006</a></li>
<li><a title="Full Circle" href='fullcircle.php'>26/1/2006</a></li>
<li><a title="The Wrap Up" href='thewrapup.php'>23/3/2006</a></li>
<li> </li><br><li>Or go back to:</li><li><a title='Travelouges and blogs from my trip around Australia' href="nerdseyeview.php">Nerd's Eye View</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>16/9/2005</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Travel stories and pictures' href="travel.php">Travelogues</a> > <a title='Travelouges and blogs from my trip around Australia' href="nerdseyeview.php">Nerd's Eye View</a> > <a title='Things from Above' href="thingsfromabove.php">16/9/2005</a>
<br><br>		


<h1>Things from Above</h1>

<a href="images/maps/Map050916.gif"><img src="images/maps/Map050916_sm.gif" align="right"></a>

<p>Well folks, here we are again. Another week on, and I'm sitting here on another Thursday evening (this text to be finished Friday of course) in the heart of the Kimberley, next to the Wolfe Creek meteorite crater in fact. In front of me, the sun has just set and painted the sky various amazing colours, and behind me the almost-full moon is already fairly high in the sky.</p>

<p>The spot that I'm at is on the edge of the Tanami Desert, and indeed it's pretty dry and barren here. From a survival point of view this can be a bad thing, but from my own insulated point of view it's great, because there are no insects right now, even though it's about 28 degrees. So yeah, it's pretty bloody perfect. :)</p>

<p>This week has been a hodgepodge of laziness and concentrated activity. The first few days I spent in Kununurra, from where I sent the last update. It was pretty hot during the day, which sort of made it hard to get into gear and actually do stuff. "Stuff" being getting out of the hostel, away from the pool, etc.</p>

<p>I did make a few trips around; including one bike ride to explore the town at sunset, and a trip out to Wyndham, a similarly sized town located near the sea.</p>

<p>On the way out there, I stuck my nose up the Gibb River road for a few kms, just to have a peek. Apart from the main highway, this is pretty much the only other road that traverses the Kimberley. It's more than 500kms of dirt, and the sharp stones there have a reputation for carving up tyre walls. Having only one spare, and not much urge to battle potentially deep river crossings, I have decided to have this particular adventure on another journey. As a bumbling gold droid once said, "I'm not going that way, it's much too rocky". But it was nice to have a quick look.</p>

<p>Anyway, Wyndham was fairly interesting, because although the town isn't much to see in itself, there is a nice lookout nearby. I drove up there, and stopped off at the first lookout-type place on the road, thinking it was the main event. And sure, it was a nice view, but not totally spectacular. I drove on up the road a bit though, just for the hell of it, and discovered that the actual lookout was a bit further on. The view was pretty breathtaking - you can see for a looong way in various directions. A lot of the land is tidal floodplain too; it was reminiscent of a satellite photo.</p>

<p>On the way back, I stopped off at the Zebra Rock Gallery to have a looksee. Zebra Rock (or stone, if you like) is unique to the area, and most of it is now underwater in Lake Argyle.</p>

<p>I spent a very pleasant hour perusing the gallery, and feeding the fish down at the lake, including some Archer Fish who were more than happy to spit copious quantities of water at me, although not often when I had the camera ready.</p>

<p>I finished the day watching the sun set, having Devonshire tea on the lawn, with various incongruous animals around me (like Peacocks and a couple of sooky Sausage Dogs).</p>

<p>Getting back to the narrative, I hung around Kununurra until Tuesday, and headed off in the middle of the day. Before heading south towards Broome, I dog-legged back to the Ord River Dam, to check out Lake Argyle.</p>

<p>Lake Argyle was created in the 70s, when the river was dammed, and it's used to irrigate lots of land around the area, where various crops have been tried (and have failed; the trial rice crop was apparently devoured by 400,000 Magpie Geese). Now, among other things, they grow various melons, quite successfully.</p>

<p>The thing about this lake is, it's massive. Bloody massive. Many-times-sydney-harbour-and-Warragamba-massive. Those of you who are bored may like to check it out using Google Earth, or Worldwind (which are satellite map viewing programs for the uninitiated).</p>

<p>Anyway, massiveness aside, you can't actually see most of it from a car. The pictures only show a tiny, tiny amount. Next time I'm in the area I'll do a canoe trip I think.</p>

<p>Following that little detour, I finally headed south. In the end, I spent too much time at the lake, and it got dark on me long before I got to Halls Creek, the next stop on the map.</p>

<p>I hate driving in the dark, as it's dangerous and you tend to kill animals, so I decided to stop on the side of the road, in a truck bay. Conveniently, it was just near the turnoff to the Argyle Diamond Mine, and I took some photos of the distant mine shining in the night.</p>

<p>Unfortunately the mine doesn't offer cheap tours, and you can't just drive in (it's a diamond mine after all), so I decided it wasn't worth spending the cash to take pictures of another hole in the ground. Admittedly though, this is a *massive* hole, much bigger than the Ranger Mine. Finding a picture of said hole on the Internet is left as an exercise for the reader. :)</p>

<p>But on with the story. I was happily settled and watching a movie (laptop car starlight cinema is so decadent), when a massive road train pulled in. I had a chat with the truckie, he was an amiable chap, and apologised for the fact that he'd be using his air conditioner that night (as it was hot). He said it ran off a second, smaller diesel engine (these trucks have everything!). I figured it wouldn't be too loud, but it turned out to be rather like sleeping next to a jackhammer, albeit a small one. Cest la vie.</p>

<p>Anyway we both woke up at the crack of dawn (after a surprisingly good night's sleep on my part; go figure), and he disappeared, but not before I got a great shot of his rig. I also walked down the road to photograph the groves of Boab trees that happened to be there. These are the oddest looking trees; no doubt many of you have seen pictures of them; they look sort of like bottles when they get bigger.</p>

<p>I've now heard a few times the story of these trees, which, interestingly enough, crosses cultures and is replicated in Africa where they also grow (yay for good old plate tectonics - these are an old species). Anyway the legend goes that the trees were arrogant, so God or whoever ripped them out and shoved them back in the ground head first. They lose their leaves during the dry, and so do rather look upside down.</p>

<p>Another interesting thing about them is that they have no rings, so you can't tell the exact age of the trees. Some are estimated to be over 1000 years old though, and the bigger ones are certainly in the hundreds of years range.</p>

<p>So anyway, pictures of Boabs abound. Enjoy.</p>

<p>My next destination was Halls Creek, founded originally as another gold rush town.</p>

<p>There's not a lot around town, but just out of it is a near vertical vein of quartz known as China Wall, so I went out there and wandered around for a bit, with the camera of course.</p>

<p>There were also a couple of nice spots 50kms further down a dirt track, but it was a bit rough for my patience on that particular day. As luck would have it though, I got to see them anyway shortly after...</p>

<p>Halls Creek is a pretty dull town, but it's where they run scenic flights of the Bungles, as well as the Wolfe Creek crater. It was the latter that I was interested in, Mum and Dad having given me a bit of cash for my birthday (thanks!) with which to do a scenic flight.</p>

<p>The road into the crater is 137kms in each direction, so I figured that a flight might be an easier option to get it out of my system. In the end, I didn't think I'd manage to get one, as flights to the crater aren't as popular, and you really need two or more people to make it affordable. But, as luck would have it, a Swiss couple booked a flight the same day, so we all went off together.</p>

<p>The flight was fantastic, in a little Cessna. A helicopter would have been better of course (for photography especially), but once again, such is life. On the way back, we flew over Palm Springs and Sawpit Gorge, the attractions that I mentioned earlier, so I got to see them from the air after all.</p>

<p>In fact, the only downside of the trip was that seeing the crater from the air really made me want to see it from the ground. So it kind of became a foregone conclusion that I would make the long dusty drive.</p>

<p>As luck would have it though, this particular long dusty drive is the best dirt road I've driven in ages. It's like a billiard table compared to most of the other dirt roads I've driven. Most of it is straight, and wide, and you can zip along at 100. There are almost no nasty corrugations with cattle sleeping in them either.</p>

<p>Which brings me to the crater itself. Some vital statistics are; it's 300,000 years old (or so), and it's 50m deeper than the surrounding land. Originally, it would have been much deeper, but it's filled up with sand over the years.</p>

<p>The central bit must fill up a bit during the wet, and then dry out again; as it's a salt pan (hence the whiter colour and different vegetation). The soil there is also much richer, and more clay-y than the sandy surrounds, and it sounds hollow to walk on in places. There's water not far below the surface, even now. It's got a layer of white salt on the surface, but underneath it's black porous clay.</p>

<p>There's quite a bit of wildlife there too (the crater, not the soil), including Red Kangaroos (which spent the day running away from me, so I only ever got pictures of their bums), little Ringtail Dragons, and various birds, including a pair of massive Wedge Tailed Eagles, which managed to elude photography as I didn't have my zoom on me at the time.</p>

<p>I spent the day wandering around and through the crater, absorbing the atmosphere. It was fantastic. I'm actually not a meteorite crater virgin, having visited the one at Lonar in India with Jana a few years ago. That one had a lake and temples full of bats - <a href="backtobloodyreality.php">read about it and see the pictures here</a>.</p>

<p>The Wolfe Creek crater though has a fantastic ambience of its own. It almost feels like its own little ecosystem in there, which of course is ridiculous, but nonetheless you do get a feeling of isolation.</p>

<p>I wandered back in at dawn this morning, and snapped a couple of birds. After that I headed back to the highway, and now I'm in Fitzroy Crossing.</p>

<p>And that's it for the week! Time to start uploading pictures.</p>

<p>By the way, if anyone feels like they know someone who might be interested in my random wafflings, feel free to pass on the details of my site. More hits gives me more nerd credibility you see, and we may as well share the love.</p>

<p>This week's postcards are:</p>
<!-- 
<ul>
<li><a href="?fileId=IMG_8700.JPG">Five Rivers lookout at Wyndham</a></li>
<li><a href="?fileId=IMG_8853.JPG">A shiny road train at dawn</a></li>
<li><a href="?fileId=IMG_8928.JPG">The Wolfe Creek crater from the air</a></li>
<li><a href="?fileId=IMG_9031.JPG">...from the middle...</a></li>
<li><a href="?fileId=IMG_9051.JPG">and from the rim</a></li>
</ul>
 -->
<table width="800">
	<tr>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=IMG_8700.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_8700.JPG' ALT='Five Rivers lookout at Wyndham'><BR>Five Rivers lookout at Wyndham</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=IMG_8853.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_8853.JPG' ALT='A shiny road train at dawn'><BR>A shiny road train at dawn</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=IMG_8928.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_8928.JPG' ALT='The Wolfe Creek crater from the air'><BR>The Wolfe Creek crater from the air</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=IMG_9031.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_9031.JPG' ALT='...from the middle...'><BR>...from the middle...</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=IMG_9051.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_9051.JPG' ALT='and from the rim'><BR>and from the rim</a>
	</td>
	</tr>
</table>

<br><br>
All images in this gallery:<br>
<table width='800'>
<tr>
</tr>
<tr><td><A ID='IMG_8660.JPG' href='thingsfromabove.php?fileId=IMG_8660.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_8660.JPG' ALT='IMG_8660.JPG'><BR>IMG_8660.JPG<br>83.85 KB</a><div class='inv'><br><a href='./images/20050916/IMG_8660.JPG' ALT='IMG_8660.JPG'>IMG_8660.JPG</a></div></td>
<td><A ID='IMG_8667.JPG' href='thingsfromabove.php?fileId=IMG_8667.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_8667.JPG' ALT='IMG_8667.JPG'><BR>IMG_8667.JPG<br>69.41 KB</a><div class='inv'><br><a href='./images/20050916/IMG_8667.JPG' ALT='IMG_8667.JPG'>IMG_8667.JPG</a></div></td>
<td><A ID='IMG_8668.JPG' href='thingsfromabove.php?fileId=IMG_8668.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_8668.JPG' ALT='IMG_8668.JPG'><BR>IMG_8668.JPG<br>47.23 KB</a><div class='inv'><br><a href='./images/20050916/IMG_8668.JPG' ALT='IMG_8668.JPG'>IMG_8668.JPG</a></div></td>
<td><A ID='IMG_8671.JPG' href='thingsfromabove.php?fileId=IMG_8671.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_8671.JPG' ALT='IMG_8671.JPG'><BR>IMG_8671.JPG<br>59.12 KB</a><div class='inv'><br><a href='./images/20050916/IMG_8671.JPG' ALT='IMG_8671.JPG'>IMG_8671.JPG</a></div></td>
<td><A ID='IMG_8673.JPG' href='thingsfromabove.php?fileId=IMG_8673.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_8673.JPG' ALT='IMG_8673.JPG'><BR>IMG_8673.JPG<br>43.8 KB</a><div class='inv'><br><a href='./images/20050916/IMG_8673.JPG' ALT='IMG_8673.JPG'>IMG_8673.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_8674.JPG' href='thingsfromabove.php?fileId=IMG_8674.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_8674.JPG' ALT='IMG_8674.JPG'><BR>IMG_8674.JPG<br>84.04 KB</a><div class='inv'><br><a href='./images/20050916/IMG_8674.JPG' ALT='IMG_8674.JPG'>IMG_8674.JPG</a></div></td>
<td><A ID='IMG_8679.JPG' href='thingsfromabove.php?fileId=IMG_8679.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_8679.JPG' ALT='IMG_8679.JPG'><BR>IMG_8679.JPG<br>57.82 KB</a><div class='inv'><br><a href='./images/20050916/IMG_8679.JPG' ALT='IMG_8679.JPG'>IMG_8679.JPG</a></div></td>
<td><A ID='IMG_8681.JPG' href='thingsfromabove.php?fileId=IMG_8681.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_8681.JPG' ALT='IMG_8681.JPG'><BR>IMG_8681.JPG<br>56.72 KB</a><div class='inv'><br><a href='./images/20050916/IMG_8681.JPG' ALT='IMG_8681.JPG'>IMG_8681.JPG</a></div></td>
<td><A ID='IMG_8683.JPG' href='thingsfromabove.php?fileId=IMG_8683.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_8683.JPG' ALT='IMG_8683.JPG'><BR>IMG_8683.JPG<br>57.39 KB</a><div class='inv'><br><a href='./images/20050916/IMG_8683.JPG' ALT='IMG_8683.JPG'>IMG_8683.JPG</a></div></td>
<td><A ID='IMG_8684.JPG' href='thingsfromabove.php?fileId=IMG_8684.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_8684.JPG' ALT='IMG_8684.JPG'><BR>IMG_8684.JPG<br>68.11 KB</a><div class='inv'><br><a href='./images/20050916/IMG_8684.JPG' ALT='IMG_8684.JPG'>IMG_8684.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_8686.JPG' href='thingsfromabove.php?fileId=IMG_8686.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_8686.JPG' ALT='IMG_8686.JPG'><BR>IMG_8686.JPG<br>67.19 KB</a><div class='inv'><br><a href='./images/20050916/IMG_8686.JPG' ALT='IMG_8686.JPG'>IMG_8686.JPG</a></div></td>
<td><A ID='IMG_8687.JPG' href='thingsfromabove.php?fileId=IMG_8687.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_8687.JPG' ALT='IMG_8687.JPG'><BR>IMG_8687.JPG<br>60.88 KB</a><div class='inv'><br><a href='./images/20050916/IMG_8687.JPG' ALT='IMG_8687.JPG'>IMG_8687.JPG</a></div></td>
<td><A ID='IMG_8688.JPG' href='thingsfromabove.php?fileId=IMG_8688.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_8688.JPG' ALT='IMG_8688.JPG'><BR>IMG_8688.JPG<br>74.56 KB</a><div class='inv'><br><a href='./images/20050916/IMG_8688.JPG' ALT='IMG_8688.JPG'>IMG_8688.JPG</a></div></td>
<td><A ID='IMG_8692.JPG' href='thingsfromabove.php?fileId=IMG_8692.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_8692.JPG' ALT='IMG_8692.JPG'><BR>IMG_8692.JPG<br>71.85 KB</a><div class='inv'><br><a href='./images/20050916/IMG_8692.JPG' ALT='IMG_8692.JPG'>IMG_8692.JPG</a></div></td>
<td><A ID='IMG_8693.JPG' href='thingsfromabove.php?fileId=IMG_8693.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_8693.JPG' ALT='IMG_8693.JPG'><BR>IMG_8693.JPG<br>72.27 KB</a><div class='inv'><br><a href='./images/20050916/IMG_8693.JPG' ALT='IMG_8693.JPG'>IMG_8693.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_8694.JPG' href='thingsfromabove.php?fileId=IMG_8694.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_8694.JPG' ALT='IMG_8694.JPG'><BR>IMG_8694.JPG<br>82.36 KB</a><div class='inv'><br><a href='./images/20050916/IMG_8694.JPG' ALT='IMG_8694.JPG'>IMG_8694.JPG</a></div></td>
<td><A ID='IMG_8696.JPG' href='thingsfromabove.php?fileId=IMG_8696.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_8696.JPG' ALT='IMG_8696.JPG'><BR>IMG_8696.JPG<br>66.12 KB</a><div class='inv'><br><a href='./images/20050916/IMG_8696.JPG' ALT='IMG_8696.JPG'>IMG_8696.JPG</a></div></td>
<td><A ID='IMG_8697.JPG' href='thingsfromabove.php?fileId=IMG_8697.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_8697.JPG' ALT='IMG_8697.JPG'><BR>IMG_8697.JPG<br>52.49 KB</a><div class='inv'><br><a href='./images/20050916/IMG_8697.JPG' ALT='IMG_8697.JPG'>IMG_8697.JPG</a></div></td>
<td><A ID='IMG_8698.JPG' href='thingsfromabove.php?fileId=IMG_8698.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_8698.JPG' ALT='IMG_8698.JPG'><BR>IMG_8698.JPG<br>48.15 KB</a><div class='inv'><br><a href='./images/20050916/IMG_8698.JPG' ALT='IMG_8698.JPG'>IMG_8698.JPG</a></div></td>
<td><A ID='IMG_8699.JPG' href='thingsfromabove.php?fileId=IMG_8699.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_8699.JPG' ALT='IMG_8699.JPG'><BR>IMG_8699.JPG<br>55.43 KB</a><div class='inv'><br><a href='./images/20050916/IMG_8699.JPG' ALT='IMG_8699.JPG'>IMG_8699.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_8700.JPG' href='thingsfromabove.php?fileId=IMG_8700.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_8700.JPG' ALT='IMG_8700.JPG'><BR>IMG_8700.JPG<br>68.17 KB</a><div class='inv'><br><a href='./images/20050916/IMG_8700.JPG' ALT='IMG_8700.JPG'>IMG_8700.JPG</a></div></td>
<td><A ID='IMG_8701.JPG' href='thingsfromabove.php?fileId=IMG_8701.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_8701.JPG' ALT='IMG_8701.JPG'><BR>IMG_8701.JPG<br>51.01 KB</a><div class='inv'><br><a href='./images/20050916/IMG_8701.JPG' ALT='IMG_8701.JPG'>IMG_8701.JPG</a></div></td>
<td><A ID='IMG_8703.JPG' href='thingsfromabove.php?fileId=IMG_8703.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_8703.JPG' ALT='IMG_8703.JPG'><BR>IMG_8703.JPG<br>88.35 KB</a><div class='inv'><br><a href='./images/20050916/IMG_8703.JPG' ALT='IMG_8703.JPG'>IMG_8703.JPG</a></div></td>
<td><A ID='IMG_8704.JPG' href='thingsfromabove.php?fileId=IMG_8704.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_8704.JPG' ALT='IMG_8704.JPG'><BR>IMG_8704.JPG<br>92.64 KB</a><div class='inv'><br><a href='./images/20050916/IMG_8704.JPG' ALT='IMG_8704.JPG'>IMG_8704.JPG</a></div></td>
<td><A ID='IMG_8708.JPG' href='thingsfromabove.php?fileId=IMG_8708.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_8708.JPG' ALT='IMG_8708.JPG'><BR>IMG_8708.JPG<br>76.71 KB</a><div class='inv'><br><a href='./images/20050916/IMG_8708.JPG' ALT='IMG_8708.JPG'>IMG_8708.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_8709.JPG' href='thingsfromabove.php?fileId=IMG_8709.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_8709.JPG' ALT='IMG_8709.JPG'><BR>IMG_8709.JPG<br>75.04 KB</a><div class='inv'><br><a href='./images/20050916/IMG_8709.JPG' ALT='IMG_8709.JPG'>IMG_8709.JPG</a></div></td>
<td><A ID='IMG_8713.JPG' href='thingsfromabove.php?fileId=IMG_8713.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_8713.JPG' ALT='IMG_8713.JPG'><BR>IMG_8713.JPG<br>71.06 KB</a><div class='inv'><br><a href='./images/20050916/IMG_8713.JPG' ALT='IMG_8713.JPG'>IMG_8713.JPG</a></div></td>
<td><A ID='IMG_8714.JPG' href='thingsfromabove.php?fileId=IMG_8714.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_8714.JPG' ALT='IMG_8714.JPG'><BR>IMG_8714.JPG<br>111.65 KB</a><div class='inv'><br><a href='./images/20050916/IMG_8714.JPG' ALT='IMG_8714.JPG'>IMG_8714.JPG</a></div></td>
<td><A ID='IMG_8717.JPG' href='thingsfromabove.php?fileId=IMG_8717.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_8717.JPG' ALT='IMG_8717.JPG'><BR>IMG_8717.JPG<br>48.51 KB</a><div class='inv'><br><a href='./images/20050916/IMG_8717.JPG' ALT='IMG_8717.JPG'>IMG_8717.JPG</a></div></td>
<td><A ID='IMG_8718.JPG' href='thingsfromabove.php?fileId=IMG_8718.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_8718.JPG' ALT='IMG_8718.JPG'><BR>IMG_8718.JPG<br>71.02 KB</a><div class='inv'><br><a href='./images/20050916/IMG_8718.JPG' ALT='IMG_8718.JPG'>IMG_8718.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_8720.JPG' href='thingsfromabove.php?fileId=IMG_8720.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_8720.JPG' ALT='IMG_8720.JPG'><BR>IMG_8720.JPG<br>81.79 KB</a><div class='inv'><br><a href='./images/20050916/IMG_8720.JPG' ALT='IMG_8720.JPG'>IMG_8720.JPG</a></div></td>
<td><A ID='IMG_8721.JPG' href='thingsfromabove.php?fileId=IMG_8721.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_8721.JPG' ALT='IMG_8721.JPG'><BR>IMG_8721.JPG<br>47.51 KB</a><div class='inv'><br><a href='./images/20050916/IMG_8721.JPG' ALT='IMG_8721.JPG'>IMG_8721.JPG</a></div></td>
<td><A ID='IMG_8725.JPG' href='thingsfromabove.php?fileId=IMG_8725.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_8725.JPG' ALT='IMG_8725.JPG'><BR>IMG_8725.JPG<br>55.7 KB</a><div class='inv'><br><a href='./images/20050916/IMG_8725.JPG' ALT='IMG_8725.JPG'>IMG_8725.JPG</a></div></td>
<td><A ID='IMG_8732.JPG' href='thingsfromabove.php?fileId=IMG_8732.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_8732.JPG' ALT='IMG_8732.JPG'><BR>IMG_8732.JPG<br>43.7 KB</a><div class='inv'><br><a href='./images/20050916/IMG_8732.JPG' ALT='IMG_8732.JPG'>IMG_8732.JPG</a></div></td>
<td><A ID='IMG_8733.JPG' href='thingsfromabove.php?fileId=IMG_8733.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_8733.JPG' ALT='IMG_8733.JPG'><BR>IMG_8733.JPG<br>46 KB</a><div class='inv'><br><a href='./images/20050916/IMG_8733.JPG' ALT='IMG_8733.JPG'>IMG_8733.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_8743.JPG' href='thingsfromabove.php?fileId=IMG_8743.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_8743.JPG' ALT='IMG_8743.JPG'><BR>IMG_8743.JPG<br>64.11 KB</a><div class='inv'><br><a href='./images/20050916/IMG_8743.JPG' ALT='IMG_8743.JPG'>IMG_8743.JPG</a></div></td>
<td><A ID='IMG_8748.JPG' href='thingsfromabove.php?fileId=IMG_8748.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_8748.JPG' ALT='IMG_8748.JPG'><BR>IMG_8748.JPG<br>72.57 KB</a><div class='inv'><br><a href='./images/20050916/IMG_8748.JPG' ALT='IMG_8748.JPG'>IMG_8748.JPG</a></div></td>
<td><A ID='IMG_8754.JPG' href='thingsfromabove.php?fileId=IMG_8754.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_8754.JPG' ALT='IMG_8754.JPG'><BR>IMG_8754.JPG<br>40.9 KB</a><div class='inv'><br><a href='./images/20050916/IMG_8754.JPG' ALT='IMG_8754.JPG'>IMG_8754.JPG</a></div></td>
<td><A ID='IMG_8761.JPG' href='thingsfromabove.php?fileId=IMG_8761.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_8761.JPG' ALT='IMG_8761.JPG'><BR>IMG_8761.JPG<br>69.46 KB</a><div class='inv'><br><a href='./images/20050916/IMG_8761.JPG' ALT='IMG_8761.JPG'>IMG_8761.JPG</a></div></td>
<td><A ID='IMG_8769.JPG' href='thingsfromabove.php?fileId=IMG_8769.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_8769.JPG' ALT='IMG_8769.JPG'><BR>IMG_8769.JPG<br>74.05 KB</a><div class='inv'><br><a href='./images/20050916/IMG_8769.JPG' ALT='IMG_8769.JPG'>IMG_8769.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_8773.JPG' href='thingsfromabove.php?fileId=IMG_8773.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_8773.JPG' ALT='IMG_8773.JPG'><BR>IMG_8773.JPG<br>73.78 KB</a><div class='inv'><br><a href='./images/20050916/IMG_8773.JPG' ALT='IMG_8773.JPG'>IMG_8773.JPG</a></div></td>
<td><A ID='IMG_8775.JPG' href='thingsfromabove.php?fileId=IMG_8775.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_8775.JPG' ALT='IMG_8775.JPG'><BR>IMG_8775.JPG<br>81.71 KB</a><div class='inv'><br><a href='./images/20050916/IMG_8775.JPG' ALT='IMG_8775.JPG'>IMG_8775.JPG</a></div></td>
<td><A ID='IMG_8778.JPG' href='thingsfromabove.php?fileId=IMG_8778.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_8778.JPG' ALT='IMG_8778.JPG'><BR>IMG_8778.JPG<br>55.45 KB</a><div class='inv'><br><a href='./images/20050916/IMG_8778.JPG' ALT='IMG_8778.JPG'>IMG_8778.JPG</a></div></td>
<td><A ID='IMG_8781.JPG' href='thingsfromabove.php?fileId=IMG_8781.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_8781.JPG' ALT='IMG_8781.JPG'><BR>IMG_8781.JPG<br>86.19 KB</a><div class='inv'><br><a href='./images/20050916/IMG_8781.JPG' ALT='IMG_8781.JPG'>IMG_8781.JPG</a></div></td>
<td><A ID='IMG_8782.JPG' href='thingsfromabove.php?fileId=IMG_8782.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_8782.JPG' ALT='IMG_8782.JPG'><BR>IMG_8782.JPG<br>86.98 KB</a><div class='inv'><br><a href='./images/20050916/IMG_8782.JPG' ALT='IMG_8782.JPG'>IMG_8782.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_8784.JPG' href='thingsfromabove.php?fileId=IMG_8784.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_8784.JPG' ALT='IMG_8784.JPG'><BR>IMG_8784.JPG<br>67.02 KB</a><div class='inv'><br><a href='./images/20050916/IMG_8784.JPG' ALT='IMG_8784.JPG'>IMG_8784.JPG</a></div></td>
<td><A ID='IMG_8787.JPG' href='thingsfromabove.php?fileId=IMG_8787.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_8787.JPG' ALT='IMG_8787.JPG'><BR>IMG_8787.JPG<br>97.95 KB</a><div class='inv'><br><a href='./images/20050916/IMG_8787.JPG' ALT='IMG_8787.JPG'>IMG_8787.JPG</a></div></td>
<td><A ID='IMG_8790.JPG' href='thingsfromabove.php?fileId=IMG_8790.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_8790.JPG' ALT='IMG_8790.JPG'><BR>IMG_8790.JPG<br>78.77 KB</a><div class='inv'><br><a href='./images/20050916/IMG_8790.JPG' ALT='IMG_8790.JPG'>IMG_8790.JPG</a></div></td>
<td><A ID='IMG_8794.JPG' href='thingsfromabove.php?fileId=IMG_8794.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_8794.JPG' ALT='IMG_8794.JPG'><BR>IMG_8794.JPG<br>82.31 KB</a><div class='inv'><br><a href='./images/20050916/IMG_8794.JPG' ALT='IMG_8794.JPG'>IMG_8794.JPG</a></div></td>
<td><A ID='IMG_8796.JPG' href='thingsfromabove.php?fileId=IMG_8796.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_8796.JPG' ALT='IMG_8796.JPG'><BR>IMG_8796.JPG<br>97.1 KB</a><div class='inv'><br><a href='./images/20050916/IMG_8796.JPG' ALT='IMG_8796.JPG'>IMG_8796.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_8798.JPG' href='thingsfromabove.php?fileId=IMG_8798.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_8798.JPG' ALT='IMG_8798.JPG'><BR>IMG_8798.JPG<br>100.99 KB</a><div class='inv'><br><a href='./images/20050916/IMG_8798.JPG' ALT='IMG_8798.JPG'>IMG_8798.JPG</a></div></td>
<td><A ID='IMG_8814.JPG' href='thingsfromabove.php?fileId=IMG_8814.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_8814.JPG' ALT='IMG_8814.JPG'><BR>IMG_8814.JPG<br>65.18 KB</a><div class='inv'><br><a href='./images/20050916/IMG_8814.JPG' ALT='IMG_8814.JPG'>IMG_8814.JPG</a></div></td>
<td><A ID='IMG_8816.JPG' href='thingsfromabove.php?fileId=IMG_8816.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_8816.JPG' ALT='IMG_8816.JPG'><BR>IMG_8816.JPG<br>93.51 KB</a><div class='inv'><br><a href='./images/20050916/IMG_8816.JPG' ALT='IMG_8816.JPG'>IMG_8816.JPG</a></div></td>
<td><A ID='IMG_8839.JPG' href='thingsfromabove.php?fileId=IMG_8839.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_8839.JPG' ALT='IMG_8839.JPG'><BR>IMG_8839.JPG<br>56.53 KB</a><div class='inv'><br><a href='./images/20050916/IMG_8839.JPG' ALT='IMG_8839.JPG'>IMG_8839.JPG</a></div></td>
<td><A ID='IMG_8846.JPG' href='thingsfromabove.php?fileId=IMG_8846.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_8846.JPG' ALT='IMG_8846.JPG'><BR>IMG_8846.JPG<br>28 KB</a><div class='inv'><br><a href='./images/20050916/IMG_8846.JPG' ALT='IMG_8846.JPG'>IMG_8846.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_8848.JPG' href='thingsfromabove.php?fileId=IMG_8848.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_8848.JPG' ALT='IMG_8848.JPG'><BR>IMG_8848.JPG<br>41.71 KB</a><div class='inv'><br><a href='./images/20050916/IMG_8848.JPG' ALT='IMG_8848.JPG'>IMG_8848.JPG</a></div></td>
<td><A ID='IMG_8851.JPG' href='thingsfromabove.php?fileId=IMG_8851.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_8851.JPG' ALT='IMG_8851.JPG'><BR>IMG_8851.JPG<br>45.3 KB</a><div class='inv'><br><a href='./images/20050916/IMG_8851.JPG' ALT='IMG_8851.JPG'>IMG_8851.JPG</a></div></td>
<td><A ID='IMG_8853.JPG' href='thingsfromabove.php?fileId=IMG_8853.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_8853.JPG' ALT='IMG_8853.JPG'><BR>IMG_8853.JPG<br>56.72 KB</a><div class='inv'><br><a href='./images/20050916/IMG_8853.JPG' ALT='IMG_8853.JPG'>IMG_8853.JPG</a></div></td>
<td><A ID='IMG_8855.JPG' href='thingsfromabove.php?fileId=IMG_8855.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_8855.JPG' ALT='IMG_8855.JPG'><BR>IMG_8855.JPG<br>94.08 KB</a><div class='inv'><br><a href='./images/20050916/IMG_8855.JPG' ALT='IMG_8855.JPG'>IMG_8855.JPG</a></div></td>
<td><A ID='IMG_8860.JPG' href='thingsfromabove.php?fileId=IMG_8860.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_8860.JPG' ALT='IMG_8860.JPG'><BR>IMG_8860.JPG<br>81.56 KB</a><div class='inv'><br><a href='./images/20050916/IMG_8860.JPG' ALT='IMG_8860.JPG'>IMG_8860.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_8863.JPG' href='thingsfromabove.php?fileId=IMG_8863.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_8863.JPG' ALT='IMG_8863.JPG'><BR>IMG_8863.JPG<br>61.12 KB</a><div class='inv'><br><a href='./images/20050916/IMG_8863.JPG' ALT='IMG_8863.JPG'>IMG_8863.JPG</a></div></td>
<td><A ID='IMG_8864.JPG' href='thingsfromabove.php?fileId=IMG_8864.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_8864.JPG' ALT='IMG_8864.JPG'><BR>IMG_8864.JPG<br>45.35 KB</a><div class='inv'><br><a href='./images/20050916/IMG_8864.JPG' ALT='IMG_8864.JPG'>IMG_8864.JPG</a></div></td>
<td><A ID='IMG_8865.JPG' href='thingsfromabove.php?fileId=IMG_8865.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_8865.JPG' ALT='IMG_8865.JPG'><BR>IMG_8865.JPG<br>62.37 KB</a><div class='inv'><br><a href='./images/20050916/IMG_8865.JPG' ALT='IMG_8865.JPG'>IMG_8865.JPG</a></div></td>
<td><A ID='IMG_8866.JPG' href='thingsfromabove.php?fileId=IMG_8866.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_8866.JPG' ALT='IMG_8866.JPG'><BR>IMG_8866.JPG<br>98.35 KB</a><div class='inv'><br><a href='./images/20050916/IMG_8866.JPG' ALT='IMG_8866.JPG'>IMG_8866.JPG</a></div></td>
<td><A ID='IMG_8874.JPG' href='thingsfromabove.php?fileId=IMG_8874.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_8874.JPG' ALT='IMG_8874.JPG'><BR>IMG_8874.JPG<br>29.08 KB</a><div class='inv'><br><a href='./images/20050916/IMG_8874.JPG' ALT='IMG_8874.JPG'>IMG_8874.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_8885.JPG' href='thingsfromabove.php?fileId=IMG_8885.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_8885.JPG' ALT='IMG_8885.JPG'><BR>IMG_8885.JPG<br>98.17 KB</a><div class='inv'><br><a href='./images/20050916/IMG_8885.JPG' ALT='IMG_8885.JPG'>IMG_8885.JPG</a></div></td>
<td><A ID='IMG_8887.JPG' href='thingsfromabove.php?fileId=IMG_8887.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_8887.JPG' ALT='IMG_8887.JPG'><BR>IMG_8887.JPG<br>94.47 KB</a><div class='inv'><br><a href='./images/20050916/IMG_8887.JPG' ALT='IMG_8887.JPG'>IMG_8887.JPG</a></div></td>
<td><A ID='IMG_8889.JPG' href='thingsfromabove.php?fileId=IMG_8889.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_8889.JPG' ALT='IMG_8889.JPG'><BR>IMG_8889.JPG<br>104.04 KB</a><div class='inv'><br><a href='./images/20050916/IMG_8889.JPG' ALT='IMG_8889.JPG'>IMG_8889.JPG</a></div></td>
<td><A ID='IMG_8899.JPG' href='thingsfromabove.php?fileId=IMG_8899.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_8899.JPG' ALT='IMG_8899.JPG'><BR>IMG_8899.JPG<br>78.31 KB</a><div class='inv'><br><a href='./images/20050916/IMG_8899.JPG' ALT='IMG_8899.JPG'>IMG_8899.JPG</a></div></td>
<td><A ID='IMG_8900.JPG' href='thingsfromabove.php?fileId=IMG_8900.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_8900.JPG' ALT='IMG_8900.JPG'><BR>IMG_8900.JPG<br>40.55 KB</a><div class='inv'><br><a href='./images/20050916/IMG_8900.JPG' ALT='IMG_8900.JPG'>IMG_8900.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_8902.JPG' href='thingsfromabove.php?fileId=IMG_8902.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_8902.JPG' ALT='IMG_8902.JPG'><BR>IMG_8902.JPG<br>52.73 KB</a><div class='inv'><br><a href='./images/20050916/IMG_8902.JPG' ALT='IMG_8902.JPG'>IMG_8902.JPG</a></div></td>
<td><A ID='IMG_8904.JPG' href='thingsfromabove.php?fileId=IMG_8904.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_8904.JPG' ALT='IMG_8904.JPG'><BR>IMG_8904.JPG<br>45.68 KB</a><div class='inv'><br><a href='./images/20050916/IMG_8904.JPG' ALT='IMG_8904.JPG'>IMG_8904.JPG</a></div></td>
<td><A ID='IMG_8910.JPG' href='thingsfromabove.php?fileId=IMG_8910.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_8910.JPG' ALT='IMG_8910.JPG'><BR>IMG_8910.JPG<br>49.42 KB</a><div class='inv'><br><a href='./images/20050916/IMG_8910.JPG' ALT='IMG_8910.JPG'>IMG_8910.JPG</a></div></td>
<td><A ID='IMG_8916.JPG' href='thingsfromabove.php?fileId=IMG_8916.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_8916.JPG' ALT='IMG_8916.JPG'><BR>IMG_8916.JPG<br>49.53 KB</a><div class='inv'><br><a href='./images/20050916/IMG_8916.JPG' ALT='IMG_8916.JPG'>IMG_8916.JPG</a></div></td>
<td><A ID='IMG_8923.JPG' href='thingsfromabove.php?fileId=IMG_8923.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_8923.JPG' ALT='IMG_8923.JPG'><BR>IMG_8923.JPG<br>59.07 KB</a><div class='inv'><br><a href='./images/20050916/IMG_8923.JPG' ALT='IMG_8923.JPG'>IMG_8923.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_8928.JPG' href='thingsfromabove.php?fileId=IMG_8928.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_8928.JPG' ALT='IMG_8928.JPG'><BR>IMG_8928.JPG<br>55.82 KB</a><div class='inv'><br><a href='./images/20050916/IMG_8928.JPG' ALT='IMG_8928.JPG'>IMG_8928.JPG</a></div></td>
<td><A ID='IMG_8934.JPG' href='thingsfromabove.php?fileId=IMG_8934.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_8934.JPG' ALT='IMG_8934.JPG'><BR>IMG_8934.JPG<br>62.98 KB</a><div class='inv'><br><a href='./images/20050916/IMG_8934.JPG' ALT='IMG_8934.JPG'>IMG_8934.JPG</a></div></td>
<td><A ID='IMG_8935.JPG' href='thingsfromabove.php?fileId=IMG_8935.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_8935.JPG' ALT='IMG_8935.JPG'><BR>IMG_8935.JPG<br>80.1 KB</a><div class='inv'><br><a href='./images/20050916/IMG_8935.JPG' ALT='IMG_8935.JPG'>IMG_8935.JPG</a></div></td>
<td><A ID='IMG_8937.JPG' href='thingsfromabove.php?fileId=IMG_8937.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_8937.JPG' ALT='IMG_8937.JPG'><BR>IMG_8937.JPG<br>60.87 KB</a><div class='inv'><br><a href='./images/20050916/IMG_8937.JPG' ALT='IMG_8937.JPG'>IMG_8937.JPG</a></div></td>
<td><A ID='IMG_8938.JPG' href='thingsfromabove.php?fileId=IMG_8938.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_8938.JPG' ALT='IMG_8938.JPG'><BR>IMG_8938.JPG<br>70.17 KB</a><div class='inv'><br><a href='./images/20050916/IMG_8938.JPG' ALT='IMG_8938.JPG'>IMG_8938.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_8942.JPG' href='thingsfromabove.php?fileId=IMG_8942.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_8942.JPG' ALT='IMG_8942.JPG'><BR>IMG_8942.JPG<br>54.47 KB</a><div class='inv'><br><a href='./images/20050916/IMG_8942.JPG' ALT='IMG_8942.JPG'>IMG_8942.JPG</a></div></td>
<td><A ID='IMG_8946.JPG' href='thingsfromabove.php?fileId=IMG_8946.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_8946.JPG' ALT='IMG_8946.JPG'><BR>IMG_8946.JPG<br>75.44 KB</a><div class='inv'><br><a href='./images/20050916/IMG_8946.JPG' ALT='IMG_8946.JPG'>IMG_8946.JPG</a></div></td>
<td><A ID='IMG_8953.JPG' href='thingsfromabove.php?fileId=IMG_8953.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_8953.JPG' ALT='IMG_8953.JPG'><BR>IMG_8953.JPG<br>44.57 KB</a><div class='inv'><br><a href='./images/20050916/IMG_8953.JPG' ALT='IMG_8953.JPG'>IMG_8953.JPG</a></div></td>
<td><A ID='IMG_8954.JPG' href='thingsfromabove.php?fileId=IMG_8954.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_8954.JPG' ALT='IMG_8954.JPG'><BR>IMG_8954.JPG<br>47.1 KB</a><div class='inv'><br><a href='./images/20050916/IMG_8954.JPG' ALT='IMG_8954.JPG'>IMG_8954.JPG</a></div></td>
<td><A ID='IMG_8957.JPG' href='thingsfromabove.php?fileId=IMG_8957.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_8957.JPG' ALT='IMG_8957.JPG'><BR>IMG_8957.JPG<br>74.82 KB</a><div class='inv'><br><a href='./images/20050916/IMG_8957.JPG' ALT='IMG_8957.JPG'>IMG_8957.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_8962.JPG' href='thingsfromabove.php?fileId=IMG_8962.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_8962.JPG' ALT='IMG_8962.JPG'><BR>IMG_8962.JPG<br>51.06 KB</a><div class='inv'><br><a href='./images/20050916/IMG_8962.JPG' ALT='IMG_8962.JPG'>IMG_8962.JPG</a></div></td>
<td><A ID='IMG_8964.JPG' href='thingsfromabove.php?fileId=IMG_8964.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_8964.JPG' ALT='IMG_8964.JPG'><BR>IMG_8964.JPG<br>55.57 KB</a><div class='inv'><br><a href='./images/20050916/IMG_8964.JPG' ALT='IMG_8964.JPG'>IMG_8964.JPG</a></div></td>
<td><A ID='IMG_8969.JPG' href='thingsfromabove.php?fileId=IMG_8969.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_8969.JPG' ALT='IMG_8969.JPG'><BR>IMG_8969.JPG<br>57.61 KB</a><div class='inv'><br><a href='./images/20050916/IMG_8969.JPG' ALT='IMG_8969.JPG'>IMG_8969.JPG</a></div></td>
<td><A ID='IMG_8972.JPG' href='thingsfromabove.php?fileId=IMG_8972.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_8972.JPG' ALT='IMG_8972.JPG'><BR>IMG_8972.JPG<br>59.84 KB</a><div class='inv'><br><a href='./images/20050916/IMG_8972.JPG' ALT='IMG_8972.JPG'>IMG_8972.JPG</a></div></td>
<td><A ID='IMG_8977.JPG' href='thingsfromabove.php?fileId=IMG_8977.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_8977.JPG' ALT='IMG_8977.JPG'><BR>IMG_8977.JPG<br>53.22 KB</a><div class='inv'><br><a href='./images/20050916/IMG_8977.JPG' ALT='IMG_8977.JPG'>IMG_8977.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_8982.JPG' href='thingsfromabove.php?fileId=IMG_8982.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_8982.JPG' ALT='IMG_8982.JPG'><BR>IMG_8982.JPG<br>59.23 KB</a><div class='inv'><br><a href='./images/20050916/IMG_8982.JPG' ALT='IMG_8982.JPG'>IMG_8982.JPG</a></div></td>
<td><A ID='IMG_8986.JPG' href='thingsfromabove.php?fileId=IMG_8986.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_8986.JPG' ALT='IMG_8986.JPG'><BR>IMG_8986.JPG<br>68.37 KB</a><div class='inv'><br><a href='./images/20050916/IMG_8986.JPG' ALT='IMG_8986.JPG'>IMG_8986.JPG</a></div></td>
<td><A ID='IMG_8992.JPG' href='thingsfromabove.php?fileId=IMG_8992.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_8992.JPG' ALT='IMG_8992.JPG'><BR>IMG_8992.JPG<br>75.09 KB</a><div class='inv'><br><a href='./images/20050916/IMG_8992.JPG' ALT='IMG_8992.JPG'>IMG_8992.JPG</a></div></td>
<td><A ID='IMG_8998.JPG' href='thingsfromabove.php?fileId=IMG_8998.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_8998.JPG' ALT='IMG_8998.JPG'><BR>IMG_8998.JPG<br>49.65 KB</a><div class='inv'><br><a href='./images/20050916/IMG_8998.JPG' ALT='IMG_8998.JPG'>IMG_8998.JPG</a></div></td>
<td><A ID='IMG_9000.JPG' href='thingsfromabove.php?fileId=IMG_9000.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_9000.JPG' ALT='IMG_9000.JPG'><BR>IMG_9000.JPG<br>41.55 KB</a><div class='inv'><br><a href='./images/20050916/IMG_9000.JPG' ALT='IMG_9000.JPG'>IMG_9000.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_9001.JPG' href='thingsfromabove.php?fileId=IMG_9001.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_9001.JPG' ALT='IMG_9001.JPG'><BR>IMG_9001.JPG<br>56.13 KB</a><div class='inv'><br><a href='./images/20050916/IMG_9001.JPG' ALT='IMG_9001.JPG'>IMG_9001.JPG</a></div></td>
<td><A ID='IMG_9004.JPG' href='thingsfromabove.php?fileId=IMG_9004.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_9004.JPG' ALT='IMG_9004.JPG'><BR>IMG_9004.JPG<br>70.99 KB</a><div class='inv'><br><a href='./images/20050916/IMG_9004.JPG' ALT='IMG_9004.JPG'>IMG_9004.JPG</a></div></td>
<td><A ID='IMG_9009.JPG' href='thingsfromabove.php?fileId=IMG_9009.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_9009.JPG' ALT='IMG_9009.JPG'><BR>IMG_9009.JPG<br>91.24 KB</a><div class='inv'><br><a href='./images/20050916/IMG_9009.JPG' ALT='IMG_9009.JPG'>IMG_9009.JPG</a></div></td>
<td><A ID='IMG_9010.JPG' href='thingsfromabove.php?fileId=IMG_9010.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_9010.JPG' ALT='IMG_9010.JPG'><BR>IMG_9010.JPG<br>97.84 KB</a><div class='inv'><br><a href='./images/20050916/IMG_9010.JPG' ALT='IMG_9010.JPG'>IMG_9010.JPG</a></div></td>
<td><A ID='IMG_9011.JPG' href='thingsfromabove.php?fileId=IMG_9011.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_9011.JPG' ALT='IMG_9011.JPG'><BR>IMG_9011.JPG<br>100.8 KB</a><div class='inv'><br><a href='./images/20050916/IMG_9011.JPG' ALT='IMG_9011.JPG'>IMG_9011.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_9013.JPG' href='thingsfromabove.php?fileId=IMG_9013.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_9013.JPG' ALT='IMG_9013.JPG'><BR>IMG_9013.JPG<br>119.85 KB</a><div class='inv'><br><a href='./images/20050916/IMG_9013.JPG' ALT='IMG_9013.JPG'>IMG_9013.JPG</a></div></td>
<td><A ID='IMG_9022.JPG' href='thingsfromabove.php?fileId=IMG_9022.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_9022.JPG' ALT='IMG_9022.JPG'><BR>IMG_9022.JPG<br>95.15 KB</a><div class='inv'><br><a href='./images/20050916/IMG_9022.JPG' ALT='IMG_9022.JPG'>IMG_9022.JPG</a></div></td>
<td><A ID='IMG_9030.JPG' href='thingsfromabove.php?fileId=IMG_9030.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_9030.JPG' ALT='IMG_9030.JPG'><BR>IMG_9030.JPG<br>114.32 KB</a><div class='inv'><br><a href='./images/20050916/IMG_9030.JPG' ALT='IMG_9030.JPG'>IMG_9030.JPG</a></div></td>
<td><A ID='IMG_9031.JPG' href='thingsfromabove.php?fileId=IMG_9031.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_9031.JPG' ALT='IMG_9031.JPG'><BR>IMG_9031.JPG<br>76.53 KB</a><div class='inv'><br><a href='./images/20050916/IMG_9031.JPG' ALT='IMG_9031.JPG'>IMG_9031.JPG</a></div></td>
<td><A ID='IMG_9032.JPG' href='thingsfromabove.php?fileId=IMG_9032.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_9032.JPG' ALT='IMG_9032.JPG'><BR>IMG_9032.JPG<br>73.35 KB</a><div class='inv'><br><a href='./images/20050916/IMG_9032.JPG' ALT='IMG_9032.JPG'>IMG_9032.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_9047.JPG' href='thingsfromabove.php?fileId=IMG_9047.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_9047.JPG' ALT='IMG_9047.JPG'><BR>IMG_9047.JPG<br>35.12 KB</a><div class='inv'><br><a href='./images/20050916/IMG_9047.JPG' ALT='IMG_9047.JPG'>IMG_9047.JPG</a></div></td>
<td><A ID='IMG_9051.JPG' href='thingsfromabove.php?fileId=IMG_9051.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_9051.JPG' ALT='IMG_9051.JPG'><BR>IMG_9051.JPG<br>97.87 KB</a><div class='inv'><br><a href='./images/20050916/IMG_9051.JPG' ALT='IMG_9051.JPG'>IMG_9051.JPG</a></div></td>
<td><A ID='IMG_9055.JPG' href='thingsfromabove.php?fileId=IMG_9055.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_9055.JPG' ALT='IMG_9055.JPG'><BR>IMG_9055.JPG<br>80.58 KB</a><div class='inv'><br><a href='./images/20050916/IMG_9055.JPG' ALT='IMG_9055.JPG'>IMG_9055.JPG</a></div></td>
<td><A ID='IMG_9060.JPG' href='thingsfromabove.php?fileId=IMG_9060.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_9060.JPG' ALT='IMG_9060.JPG'><BR>IMG_9060.JPG<br>70.37 KB</a><div class='inv'><br><a href='./images/20050916/IMG_9060.JPG' ALT='IMG_9060.JPG'>IMG_9060.JPG</a></div></td>
<td><A ID='IMG_9064.JPG' href='thingsfromabove.php?fileId=IMG_9064.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_9064.JPG' ALT='IMG_9064.JPG'><BR>IMG_9064.JPG<br>80.57 KB</a><div class='inv'><br><a href='./images/20050916/IMG_9064.JPG' ALT='IMG_9064.JPG'>IMG_9064.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_9065.JPG' href='thingsfromabove.php?fileId=IMG_9065.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_9065.JPG' ALT='IMG_9065.JPG'><BR>IMG_9065.JPG<br>99.89 KB</a><div class='inv'><br><a href='./images/20050916/IMG_9065.JPG' ALT='IMG_9065.JPG'>IMG_9065.JPG</a></div></td>
<td><A ID='IMG_9086.JPG' href='thingsfromabove.php?fileId=IMG_9086.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_9086.JPG' ALT='IMG_9086.JPG'><BR>IMG_9086.JPG<br>96.48 KB</a><div class='inv'><br><a href='./images/20050916/IMG_9086.JPG' ALT='IMG_9086.JPG'>IMG_9086.JPG</a></div></td>
<td><A ID='IMG_9098.JPG' href='thingsfromabove.php?fileId=IMG_9098.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_9098.JPG' ALT='IMG_9098.JPG'><BR>IMG_9098.JPG<br>76.46 KB</a><div class='inv'><br><a href='./images/20050916/IMG_9098.JPG' ALT='IMG_9098.JPG'>IMG_9098.JPG</a></div></td>
<td><A ID='IMG_9103.JPG' href='thingsfromabove.php?fileId=IMG_9103.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_9103.JPG' ALT='IMG_9103.JPG'><BR>IMG_9103.JPG<br>65.15 KB</a><div class='inv'><br><a href='./images/20050916/IMG_9103.JPG' ALT='IMG_9103.JPG'>IMG_9103.JPG</a></div></td>
<td><A ID='IMG_9114.JPG' href='thingsfromabove.php?fileId=IMG_9114.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_9114.JPG' ALT='IMG_9114.JPG'><BR>IMG_9114.JPG<br>115.54 KB</a><div class='inv'><br><a href='./images/20050916/IMG_9114.JPG' ALT='IMG_9114.JPG'>IMG_9114.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_9128.JPG' href='thingsfromabove.php?fileId=IMG_9128.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_9128.JPG' ALT='IMG_9128.JPG'><BR>IMG_9128.JPG<br>70.5 KB</a><div class='inv'><br><a href='./images/20050916/IMG_9128.JPG' ALT='IMG_9128.JPG'>IMG_9128.JPG</a></div></td>
<td><A ID='IMG_9136.JPG' href='thingsfromabove.php?fileId=IMG_9136.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_9136.JPG' ALT='IMG_9136.JPG'><BR>IMG_9136.JPG<br>66.19 KB</a><div class='inv'><br><a href='./images/20050916/IMG_9136.JPG' ALT='IMG_9136.JPG'>IMG_9136.JPG</a></div></td>
<td><A ID='IMG_9144.JPG' href='thingsfromabove.php?fileId=IMG_9144.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_9144.JPG' ALT='IMG_9144.JPG'><BR>IMG_9144.JPG<br>56.09 KB</a><div class='inv'><br><a href='./images/20050916/IMG_9144.JPG' ALT='IMG_9144.JPG'>IMG_9144.JPG</a></div></td>
<td><A ID='IMG_9147.JPG' href='thingsfromabove.php?fileId=IMG_9147.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_9147.JPG' ALT='IMG_9147.JPG'><BR>IMG_9147.JPG<br>78.06 KB</a><div class='inv'><br><a href='./images/20050916/IMG_9147.JPG' ALT='IMG_9147.JPG'>IMG_9147.JPG</a></div></td>
<td><A ID='IMG_9153.JPG' href='thingsfromabove.php?fileId=IMG_9153.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_9153.JPG' ALT='IMG_9153.JPG'><BR>IMG_9153.JPG<br>52.36 KB</a><div class='inv'><br><a href='./images/20050916/IMG_9153.JPG' ALT='IMG_9153.JPG'>IMG_9153.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_9163.JPG' href='thingsfromabove.php?fileId=IMG_9163.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_9163.JPG' ALT='IMG_9163.JPG'><BR>IMG_9163.JPG<br>31.69 KB</a><div class='inv'><br><a href='./images/20050916/IMG_9163.JPG' ALT='IMG_9163.JPG'>IMG_9163.JPG</a></div></td>
<td><A ID='IMG_9170.JPG' href='thingsfromabove.php?fileId=IMG_9170.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_9170.JPG' ALT='IMG_9170.JPG'><BR>IMG_9170.JPG<br>48.42 KB</a><div class='inv'><br><a href='./images/20050916/IMG_9170.JPG' ALT='IMG_9170.JPG'>IMG_9170.JPG</a></div></td>
<td><A ID='IMG_9180.JPG' href='thingsfromabove.php?fileId=IMG_9180.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_9180.JPG' ALT='IMG_9180.JPG'><BR>IMG_9180.JPG<br>148.77 KB</a><div class='inv'><br><a href='./images/20050916/IMG_9180.JPG' ALT='IMG_9180.JPG'>IMG_9180.JPG</a></div></td>
<td><A ID='IMG_9186.JPG' href='thingsfromabove.php?fileId=IMG_9186.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_9186.JPG' ALT='IMG_9186.JPG'><BR>IMG_9186.JPG<br>49.93 KB</a><div class='inv'><br><a href='./images/20050916/IMG_9186.JPG' ALT='IMG_9186.JPG'>IMG_9186.JPG</a></div></td>
<td><A ID='IMG_9189.JPG' href='thingsfromabove.php?fileId=IMG_9189.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_9189.JPG' ALT='IMG_9189.JPG'><BR>IMG_9189.JPG<br>79.13 KB</a><div class='inv'><br><a href='./images/20050916/IMG_9189.JPG' ALT='IMG_9189.JPG'>IMG_9189.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_9193.JPG' href='thingsfromabove.php?fileId=IMG_9193.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_9193.JPG' ALT='IMG_9193.JPG'><BR>IMG_9193.JPG<br>98.58 KB</a><div class='inv'><br><a href='./images/20050916/IMG_9193.JPG' ALT='IMG_9193.JPG'>IMG_9193.JPG</a></div></td>
<td><A ID='IMG_9195.JPG' href='thingsfromabove.php?fileId=IMG_9195.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_9195.JPG' ALT='IMG_9195.JPG'><BR>IMG_9195.JPG<br>85.29 KB</a><div class='inv'><br><a href='./images/20050916/IMG_9195.JPG' ALT='IMG_9195.JPG'>IMG_9195.JPG</a></div></td>
<td><A ID='IMG_9197.JPG' href='thingsfromabove.php?fileId=IMG_9197.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_9197.JPG' ALT='IMG_9197.JPG'><BR>IMG_9197.JPG<br>99.53 KB</a><div class='inv'><br><a href='./images/20050916/IMG_9197.JPG' ALT='IMG_9197.JPG'>IMG_9197.JPG</a></div></td>
<td><A ID='IMG_9198.JPG' href='thingsfromabove.php?fileId=IMG_9198.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_9198.JPG' ALT='IMG_9198.JPG'><BR>IMG_9198.JPG<br>94.6 KB</a><div class='inv'><br><a href='./images/20050916/IMG_9198.JPG' ALT='IMG_9198.JPG'>IMG_9198.JPG</a></div></td>
<td><A ID='IMG_9200.JPG' href='thingsfromabove.php?fileId=IMG_9200.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050916/IMG_9200.JPG' ALT='IMG_9200.JPG'><BR>IMG_9200.JPG<br>62.21 KB</a><div class='inv'><br><a href='./images/20050916/IMG_9200.JPG' ALT='IMG_9200.JPG'>IMG_9200.JPG</a></div></td>
</tr>
</table>	</div>
</div>
</body>
</html>