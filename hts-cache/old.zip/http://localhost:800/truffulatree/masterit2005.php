<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - 2005 archive - Q&A/MasterIT letters from 2005</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="Q&A/MasterIT letters from 2005">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="Q&A/MasterIT letters from 2003" href='masterit2003.php'>2003 archive</a></li>
<li><a title="Q&A/MasterIT letters from 2004" href='masterit2004.php'>2004 archive</a></li>
<li><div class='activemenu'>2005 archive</div></li>
<ul>
<li><a title="Q&A letters" href='masterit200501.php'>January 2005</a></li>
<li><a title="Q&A letters" href='masterit200502.php'>February 2005</a></li>
<li><a title="Q&A letters" href='masterit200503.php'>March 2005</a></li>
<li><a title="Q&A letters" href='masterit200504.php'>April 2005</a></li>
<li><a title="Q&A letters" href='masterit200505.php'>May 2005</a></li>
<li><a title="Q&A letters" href='masterit200506.php'>June 2005</a></li>
<li><a title="Q&A letters" href='masterit200507.php'>July 2005</a></li>
<li><a title="Q&A letters" href='masterit200508.php'>August 2005</a></li>
<li><a title="Q&A letters" href='masterit200509.php'>September 2005</a></li>
<li><a title="Q&A letters" href='masterit200510.php'>October 2005</a></li>
<li><a title="Q&A letters" href='masterit200511.php'>November 2005</a></li>
<li><a title="Q&A letters" href='masterit200512.php'>December 2005</a></li>
</ul>
<li><a title="Q&A/MasterIT letters from 2006" href='masterit2006.php'>2006 archive</a></li>
<li><a title="Q&A letters from 2007" href='masterit2007.php'>2007 archive</a></li>
<li> </li><br><li>Or go back to:</li><li><a title='My weekly Q&A column in The Australian' href="masterIT.php">MasterIT</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>2005 archive</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Mark's writing' href="written.php">Professional Writing</a> > <a title='My weekly Q&A column in The Australian' href="masterIT.php">MasterIT</a> > <a title='Q&A/MasterIT letters from 2005' href="masterit2005.php">2005 archive</a>
<br>Select a link on the left to continue navigating.<br><br>		<br>
Select a month to view it's particular columns.<br>
<br><br>
Files available for download:<br>
<ul class="dirlist"></ul><!-- old method
getTheFiles($file);

function getTheFiles($folder) {
	if ($handle = opendir($folder)) {
		while (false !== ($file = readdir($handle))) {
			If ($file!= "." && $file!= ".." and !is_dir($folder."/".$file)) {
				$filesize = round(filesize ($folder."/".$file)/1024,2);
				echo "<tr><td><div align='left'><A href='$corelise$folder/$file'>$file</a></div></td><td><div align='left'>$filesize KB</div></td><tr>\n";
			} else {
			If ($file!= "." && $file!= ".." and is_dir($folder."/".$file)) {
				getTheFiles($file);
			}
		}
		closedir($handle);
	}
} -->
	</div>
</div>
</body>
</html>