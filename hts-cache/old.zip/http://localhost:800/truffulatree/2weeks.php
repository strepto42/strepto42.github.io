<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html> 
<meta http-equiv="refresh" content="0; url='twoweeks'">
</html>
