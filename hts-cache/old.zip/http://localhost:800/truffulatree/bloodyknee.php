<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - Bloody Knee - Image Gallery</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="Image Gallery">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="Pictures of my 28th Birthday party complete with Sparkler Bomb" href='28th.php'>28th Birthday</a></li>
<li><a title="Pictures of my 30th Birthday party" href='30th.php'>30th Birthday</a></li>
<li><a title="Michael Shamgar and Lindsay Halamek's 30th birthday bash photos" href='sl30th.php'>Shams & Linds' 30th</a></li>
<li><a title="Pictures of Andy Marinos's new flat, cat Toby, and Mum Pam Swain" href='andycatandflat.php'>Andy's Cat & Flat</a></li>
<li><a title="Pictures of a visit to Stephen Jackson's Farm" href='jackovisit.php'>Jacko's Farm</a></li>
<li><a title="Pictures taken at the Peace Convergence action in Rockhampton and Yeppoon in June 2005 to protest the joint US Australia military exercises (Operation Talisman Sabre)" href='peaceconvergence.php'>Peace Convergence</a></li>
<li><a title="Sydney trip - April '06" href='bridges.php'>Sydney, April 06</a></li>
<li><a title="Pics of Naima's 28th birthday dinner" href='mim28th.php'>Naima's 28th</a></li>
<li><a title="Brisbane CBD and the Story Bridge" href='brisbanepics1.php'>Brissie by Night 1</a></li>
<li><a title="Lamington National Park" href='lamington.php'>Lamington NP</a></li>
<li><a title="Various creatures and views from our Brisbane back yard" href='backyard.php'>Backyard Creatures</a></li>
<li><a title="Opening day of the Eleanor Schonell (Green) Bridge" href='greenbridge.php'>Green Bridge</a></li>
<li><a title="Pictutres from the 2006 Woodford Folk Festival" href='woodford0607.php'>Woodford 2006-2007</a></li>
<li><a title="One Cute Puppy" href='jezebel.php'>Jezebel</a></li>
<li><a title="Climbing at Kangaroo Point Cliffs" href='kangaroopt1.php'>Heather's Visit</a></li>
<li><a title="0x0021st (33rd) birthday celebrations" href='0x0021st.php'>0x0021st Birthday</a></li>
<li><a title="Nuptial photography" href='guyandalison.php'>Guy and Alison's Wedding</a></li>
<li><a title="Pictures from the 2007 Woodford Folk Festival" href='woodford0708.php'>Woodford 2007-2008</a></li>
<li><a title="Image gallery" href='sydneytrip0802.php'>Sydney & Yacaaba Head</a></li>
<li><a title="An impressive show by nature" href='lightning.php'>Thunderstorm Moonrise</a></li>
<li><a title="Frightening pictures of a shrinking beard" href='debearding.php'>De-bearding</a></li>
<li><a title="More Nuptial Photography" href='michaelandkaren.php'>Michael and Karen's Wedding</a></li>
<li><a title="A night of celebration" href='andrews21st.php'>Andrew's 21st</a></li>
<li><div class='activemenu'>Bloody Knee</div></li>
<li><a title="Image Gallery" href='tyesbirthday.php'>Tye's Birthday</a></li>
<li><a title="Image Gallery" href='lasersocialising.php'>Laser Socialising</a></li>
<li><a title="Image Gallery" href='heatherandevan.php'>Heather and Evan's Wedding</a></li>
<li><a title="Image Gallery" href='woodford0809.php'>Woodford 2008-2009</a></li>
<li><a title="Image Gallery" href='allyandben.php'>Ally and Ben's Wedding</a></li>
<li><a title="Image Gallery" href='annes30th.php'>Anne's 30th</a></li>
<li><a title="Image Gallery" href='possumcreek.php'>Possum Creek</a></li>
<li><a title="Image Gallery" href='jamnight.php'>Jam Night</a></li>
<li><a title="Image Gallery" href='cunninghamsgap.php'>Cunningham's Gap</a></li>
<li><a title="Image Gallery" href='bigcat.php'>Diving on Big Cat</a></li>
<li><a title="Images from my birthday jam" href='birthdayjam.php'>Music, mayhem and merriment</a></li>
<li><a title="Image Gallery" href='fuzzypolaroidpics.php'>Fuzzy Polaroid</a></li>
<li><a title="Image Gallery" href='zombiewalk2009.php'>2009 Zombie Walk</a></li>
<li> </li><br><li>Or go back to:</li><li><a title='Picture galleries' href="pictures.php">Photography</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>Bloody Knee</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Picture galleries' href="pictures.php">Photography</a> > <a title='Image Gallery' href="bloodyknee.php">Bloody Knee</a>
<br><br>		

<p>2008 saw quite a few adventures. One that I don't care to repeat is tearing my <a href="http://en.wikipedia.org/wiki/Anterior_cruciate_ligament" target="_blank">ACL</a> and having to have a <a href="http://en.wikipedia.org/wiki/Anterior_cruciate_ligament_reconstruction" target="_blank">reconstruction</a>. Slightly gruesome pictures tell the story below.</p>
<br><br>
All images in this gallery:<br>
<table width='800'>
<tr>
</tr>
<tr><td><A ID='IMG_7696.JPG' href='bloodyknee.php?fileId=IMG_7696.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20081007/IMG_7696.JPG' ALT='IMG_7696.JPG'><BR>IMG_7696.JPG<br>36.58 KB</a><div class='inv'><br><a href='./images/20081007/IMG_7696.JPG' ALT='IMG_7696.JPG'>IMG_7696.JPG</a></div></td>
<td><A ID='IMG_7709.JPG' href='bloodyknee.php?fileId=IMG_7709.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20081007/IMG_7709.JPG' ALT='IMG_7709.JPG'><BR>IMG_7709.JPG<br>42.77 KB</a><div class='inv'><br><a href='./images/20081007/IMG_7709.JPG' ALT='IMG_7709.JPG'>IMG_7709.JPG</a></div></td>
<td><A ID='IMG_7719.JPG' href='bloodyknee.php?fileId=IMG_7719.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20081007/IMG_7719.JPG' ALT='IMG_7719.JPG'><BR>IMG_7719.JPG<br>42.17 KB</a><div class='inv'><br><a href='./images/20081007/IMG_7719.JPG' ALT='IMG_7719.JPG'>IMG_7719.JPG</a></div></td>
<td><A ID='IMG_7720.JPG' href='bloodyknee.php?fileId=IMG_7720.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20081007/IMG_7720.JPG' ALT='IMG_7720.JPG'><BR>IMG_7720.JPG<br>37.32 KB</a><div class='inv'><br><a href='./images/20081007/IMG_7720.JPG' ALT='IMG_7720.JPG'>IMG_7720.JPG</a></div></td>
<td><A ID='IMG_7721.JPG' href='bloodyknee.php?fileId=IMG_7721.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20081007/IMG_7721.JPG' ALT='IMG_7721.JPG'><BR>IMG_7721.JPG<br>53.82 KB</a><div class='inv'><br><a href='./images/20081007/IMG_7721.JPG' ALT='IMG_7721.JPG'>IMG_7721.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_7723.JPG' href='bloodyknee.php?fileId=IMG_7723.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20081007/IMG_7723.JPG' ALT='IMG_7723.JPG'><BR>IMG_7723.JPG<br>60.23 KB</a><div class='inv'><br><a href='./images/20081007/IMG_7723.JPG' ALT='IMG_7723.JPG'>IMG_7723.JPG</a></div></td>
<td><A ID='IMG_7731.JPG' href='bloodyknee.php?fileId=IMG_7731.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20081007/IMG_7731.JPG' ALT='IMG_7731.JPG'><BR>IMG_7731.JPG<br>42.89 KB</a><div class='inv'><br><a href='./images/20081007/IMG_7731.JPG' ALT='IMG_7731.JPG'>IMG_7731.JPG</a></div></td>
<td><A ID='IMG_7732.JPG' href='bloodyknee.php?fileId=IMG_7732.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20081007/IMG_7732.JPG' ALT='IMG_7732.JPG'><BR>IMG_7732.JPG<br>39.48 KB</a><div class='inv'><br><a href='./images/20081007/IMG_7732.JPG' ALT='IMG_7732.JPG'>IMG_7732.JPG</a></div></td>
<td><A ID='IMG_7742.JPG' href='bloodyknee.php?fileId=IMG_7742.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20081007/IMG_7742.JPG' ALT='IMG_7742.JPG'><BR>IMG_7742.JPG<br>43.62 KB</a><div class='inv'><br><a href='./images/20081007/IMG_7742.JPG' ALT='IMG_7742.JPG'>IMG_7742.JPG</a></div></td>
<td><A ID='IMG_7747.JPG' href='bloodyknee.php?fileId=IMG_7747.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20081007/IMG_7747.JPG' ALT='IMG_7747.JPG'><BR>IMG_7747.JPG<br>49.36 KB</a><div class='inv'><br><a href='./images/20081007/IMG_7747.JPG' ALT='IMG_7747.JPG'>IMG_7747.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_7751.JPG' href='bloodyknee.php?fileId=IMG_7751.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20081007/IMG_7751.JPG' ALT='IMG_7751.JPG'><BR>IMG_7751.JPG<br>41.4 KB</a><div class='inv'><br><a href='./images/20081007/IMG_7751.JPG' ALT='IMG_7751.JPG'>IMG_7751.JPG</a></div></td>
<td><A ID='IMG_7768.JPG' href='bloodyknee.php?fileId=IMG_7768.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20081007/IMG_7768.JPG' ALT='IMG_7768.JPG'><BR>IMG_7768.JPG<br>41.86 KB</a><div class='inv'><br><a href='./images/20081007/IMG_7768.JPG' ALT='IMG_7768.JPG'>IMG_7768.JPG</a></div></td>
<td><A ID='IMG_7769.JPG' href='bloodyknee.php?fileId=IMG_7769.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20081007/IMG_7769.JPG' ALT='IMG_7769.JPG'><BR>IMG_7769.JPG<br>40.69 KB</a><div class='inv'><br><a href='./images/20081007/IMG_7769.JPG' ALT='IMG_7769.JPG'>IMG_7769.JPG</a></div></td>
<td><A ID='IMG_7775.JPG' href='bloodyknee.php?fileId=IMG_7775.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20081007/IMG_7775.JPG' ALT='IMG_7775.JPG'><BR>IMG_7775.JPG<br>38.57 KB</a><div class='inv'><br><a href='./images/20081007/IMG_7775.JPG' ALT='IMG_7775.JPG'>IMG_7775.JPG</a></div></td>
<td><A ID='IMG_7781.JPG' href='bloodyknee.php?fileId=IMG_7781.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20081007/IMG_7781.JPG' ALT='IMG_7781.JPG'><BR>IMG_7781.JPG<br>59.25 KB</a><div class='inv'><br><a href='./images/20081007/IMG_7781.JPG' ALT='IMG_7781.JPG'>IMG_7781.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_7798.JPG' href='bloodyknee.php?fileId=IMG_7798.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20081007/IMG_7798.JPG' ALT='IMG_7798.JPG'><BR>IMG_7798.JPG<br>42.04 KB</a><div class='inv'><br><a href='./images/20081007/IMG_7798.JPG' ALT='IMG_7798.JPG'>IMG_7798.JPG</a></div></td>
<td><A ID='IMG_7822.JPG' href='bloodyknee.php?fileId=IMG_7822.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20081007/IMG_7822.JPG' ALT='IMG_7822.JPG'><BR>IMG_7822.JPG<br>44.07 KB</a><div class='inv'><br><a href='./images/20081007/IMG_7822.JPG' ALT='IMG_7822.JPG'>IMG_7822.JPG</a></div></td>
</tr>
</table>	</div>
</div>
</body>
</html>