<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - March 2006 - Q&A letters</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="Q&A letters">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="Q&A letters" href='masterit200601.php'>January 2006</a></li>
<li><a title="Q&A letters" href='masterit200602.php'>February 2006</a></li>
<li><div class='activemenu'>March 2006</div></li>
<li><a title="Q&A letters" href='masterit200604.php'>April 2006</a></li>
<li><a title="Q&A letters" href='masterit200605.php'>May 2006</a></li>
<li><a title="Q&A letters" href='masterit200606.php'>June 2006</a></li>
<li><a title="Q&A letters" href='masterit200607.php'>July 2006</a></li>
<li><a title="Q&A letters" href='masterit200608.php'>August 2006</a></li>
<li><a title="Q&A letters" href='masterit200609.php'>September 2006</a></li>
<li><a title="Q&A letters" href='masterit200610.php'>October 2006</a></li>
<li><a title="Q&A letters" href='masterit200611.php'>November 2006</a></li>
<li><a title="Q&A letters" href='masterit200612.php'>December 2006</a></li>
<li> </li><br><li>Or go back to:</li><li><a title='Q&A/MasterIT letters from 2006' href="masterit2006.php">2006 archive</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>March 2006</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Mark's writing' href="written.php">Professional Writing</a> > <a title='My weekly Q&A column in The Australian' href="masterIT.php">MasterIT</a> > <a title='Q&A/MasterIT letters from 2006' href="masterit2006.php">2006 archive</a> > <a title='Q&A letters' href="masterit200603.php">March 2006</a>
<br><br>		<br>
<h2>7/3/06</h2><br>
<b>Somehow or other I have inadvertently included all the photos in the "My Pictures" folder into the list of wallpapers available in the "desktop" section of Display Properties (the photos appear in both places). Can you advise as to how I can delete the photos from the "Desktop" list without also doing the same in "My Pictures". Also, how can I delete "Desktop" default pictures that I don't like?</b><br>
<br>
In true Microsoft spirit, there isn't a simple way to prevent windows from automatically including everything from your "My Pictures" folder in it's desktop properties collection.<br>
<br>
The list that appears in the display properties window is actually built from a number of locations. Most of the default files come from the Windows folder itself, but XP will also search and automatically includes every BMP, JPG, GIF, JPE, DIB, PNG and even HTM from the following folders:<br>
<br>
%Systemroot%WebWallpaper<br>
%USERPROFILE%My DocumentsMy Pictures (& sub-folders)<br>
%AppData%MicrosoftInternet Explorer<br>
%ProgramFiles%Plus!Themes (& sub-folders)<br>
<br>
(Incidentally, you can type the paths above directly into the "Start->Run" dialog to bring up their corresponding folders).<br>
<br>
So, if you want to clear a file from the desktop properties list, you have to move it away from all the locations given above.<br>
<br>
Most of the lousier default pictures are in the Windows folder itself, so just move or remove them from there, and they should disappear form the list.<br>
<br>
The only other way to stop Windows checking your My Pictures folder is to manually change the default "My Pictures" folder. You can do this using a utility called "tweakui", which you can find at http://tinyurl.com/h8zs.<br>
<br>
Be careful though; fooling with Windows' magic default system folders is a bit of a risky business, for if you change the wrong one you can end up with a badly broken Windows installation! :)<br>
<br>
Finally, note that any changes you make here won't show up until you log off and log on again, because Windows - displaying the typical MS ingenuity we've come to expect - only builds the Desktop list when you log on.<br>
<br>
<br>
<h2>14/3/06</h2><br>
<b>My laptop's default "sleep" key is function-F4 - right in between function-F3 (mute) and function-F5 (turn down the volume). Inevitably, I hit it by mistake from time to time - a most frustrating experience! Is there any way I can change these default key assignments?</b><br>
<br>
Unfortunately, the answer is probably not. It depends on the particular laptop of course, but most of the time special keyboard functions like those are not managed by Windows itself. Instead, they're handled by the BIOS, which is a bit like your computer's lower brain - it lets the specific physical hardware talk more easily to the operating system.<br>
<br>
The upshot of this though, is that unless your laptop's manufacturer has provided some software to change the key assignments, they're fixed (for all intents and purposes).<br>
<br>
<br>
<b>Months ago you advised to commit to a re-install with caution; I've done just that on both notebooks and did not come to un-passable bridges. I worked systematically from a schedule of prepared names and networks, and took notes along the way of what decisions I had made so that I could always backtrack. Did I miss anything?   How does the OS recognize earlier installed apps?</b><br>
<br>
It sounds like you've been very thorough - which is absolutely the right thing to do.<br>
Writing down critical things like network settings and so on is invaluable for when things go wrong (and even sometimes for when they don't!).<br>
<br>
The only other thing I'd recommend is to make sure you have all the driver disks handy for any customised hardware you have, or at the very least, network and/or modem drivers, so that you can get online and retrieve any others that you might need - as without these you have a chicken-and-egg problem.<br>
<br>
If you're doing a reinstall from scratch, rather than an update/refresh type install, you'll need to reinstall your applications afterwards, as the old files may still be there, but without their appropriate registry settings and DLL files they are unlikely to function.<br>
<br>
Of course, if you're doing an update install, everything should just work, and all your old settings should be preserved.<br>
<br>
Needless to say, the first step in any major operation like is to back up your critical data; as the mantra says, data that is not backed up is not data that you want to keep.<br>
<br>
<br>
<h2>21/3/06</h2><br>
<b>My laptop's default "sleep" key is function-F4 - right in between function-F3 (mute) and function-F5 (turn down the volume). Inevitably, I hit it by mistake from time to time - a most frustrating experience! Is there any way I can change these default key assignments?</b><br>
<br>
Unfortunately, changing the key assignments is probably not possible. It depends on the particular laptop of course, but most of the time special keyboard functions like those are not managed by Windows itself. Instead, they're handled by the BIOS, which is a bit like your computer's lower brain - it lets the specific physical hardware talk more easily to the operating system.<br>
<br>
The upshot of this though, is that unless your laptop's manufacturer has provided some software to change the key assignments, they're fixed (for all intents and purposes).<br>
<br>
The only other solution is to alter the sleep key function in Windows itself. You can do this by going to Power options (from Control Panel), and then selecting "do nothing" or "ask me" for the sleep button action under the Advanced tab.<br>
<br>
<br>
<b>I wish to set English (UK) as the default language for Word documents, and have had no problem achieving this with previous versions of Word. With Word 2003 though, no matter what I do it always kicks back to English (US). I have nothing against Americans and their language, in their place. But that place is not in my Word documents.</b><br>
<br>
I have tried opening modifying the NORMAL.DOT template, to no avail; the language change doesn't stick.<br>
<br>
I have also tried the Change The Default Language Setting from the Microsoft Office Tools in the Start menu, also to no avail. What am I doing wrong?<br>
<br>
Default dictionary issues like this one are a pet peeve of mine, and no doubt in some ways they're responsible for some of the general degradation of written language we see so often these days (long time readers will know of my lamentations regarding apostrophe abuse).<br>
<br>
You've certainly checked in the logical places so far, but perhaps your overall system language settings are (illogically) overriding Office. To check these, go to the Control Panel, and select Regional and Language options. Then Australianise everything in sight, and see if that helps.<br>
<br>
<i><p>Did the information on this page help you? Entertain you? Bore you? <a href="contact.php?subject=MasterIT">Drop me a line</a>.</p>

<p>If you're feeling particularly generous, you can even <a href="buypics.php">click here to send me some dot-com riches</a>. Think of it as online busking.</i></p>
	</div>
</div>
</body>
</html>