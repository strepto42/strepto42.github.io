<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - 16/10/2000 - Greetings from the Other Side</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="Greetings from the Other Side">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><div class='activemenu'>16/10/2000</div></li>
<li><a title="Another quick update from the land of rupees..." href='anotherquickupdate.php'>19/10/2000</a></li>
<li><a title="More Miscellaneous Ramblings from the Teeming Subcontinent" href='subcontinentramblings.php'>25/10/2000</a></li>
<li><a title="Indian Update" href='indianupdate.php'>4/11/2000</a></li>
<li><a title="From the Ganges to the Taj... and beyond" href='gangestotaj.php'>18/11/2000</a></li>
<li><a title="Camels, Tigers, Elephants and Octopussies" href='camelstigersoctopussies.php'>9/12/2000</a></li>
<li><a title="Back to bloody reality" href='backtobloodyreality.php'>14/12/2000</a></li>
<li> </li><br><li>Or go back to:</li><li><a title='Travelouges from my trip through India in 2000' href="india2000.php">India 2000</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>16/10/2000</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Travel stories and pictures' href="travel.php">Travelogues</a> > <a title='Travelouges from my trip through India in 2000' href="india2000.php">India 2000</a> > <a title='Greetings from the Other Side' href="greetingsfromtheotherside.php">16/10/2000</a>
<br><br>		


<h1>Greetings from the Other Side!</h1>

<p>Hello all!</p>

<p>Well, I'm here, finally made it. What a place... the chaos is unbelievable, 
but somehow organised, and people manage. Driving here would be an 
experience; lanes are pretty much optional, people MOSTLY drive on the 
correct side of the road, and beeping your horn at anything and everything 
is the norm, including cows of course, of which there are many.</p>

<p>Not much else to report yet of course; temp here is a balmy 25-30, pollution 
here is unbeliveable, think it'll be better once we get out of Delhi.</p>

<p>Will send more when I have more to send... adios for now!</p>
<br><br>
All images in this gallery:<br>
<table width='800'>
<tr>
</tr>
<tr><td><A ID='F1000003.JPG' href='greetingsfromtheotherside.php?fileId=F1000003.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001016/F1000003.JPG' ALT='F1000003.JPG'><BR>F1000003.JPG<br>61.13 KB</a><div class='inv'><br><a href='./images/20001016/F1000003.JPG' ALT='F1000003.JPG'>F1000003.JPG</a></div></td>
<td><A ID='F1000004.JPG' href='greetingsfromtheotherside.php?fileId=F1000004.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001016/F1000004.JPG' ALT='F1000004.JPG'><BR>F1000004.JPG<br>75.07 KB</a><div class='inv'><br><a href='./images/20001016/F1000004.JPG' ALT='F1000004.JPG'>F1000004.JPG</a></div></td>
<td><A ID='F1000005.JPG' href='greetingsfromtheotherside.php?fileId=F1000005.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001016/F1000005.JPG' ALT='F1000005.JPG'><BR>F1000005.JPG<br>91.88 KB</a><div class='inv'><br><a href='./images/20001016/F1000005.JPG' ALT='F1000005.JPG'>F1000005.JPG</a></div></td>
</tr>
</table>	</div>
</div>
</body>
</html>