<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - January 2003 - Q&A letters</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="Q&A letters">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><div class='activemenu'>January 2003</div></li>
<li><a title="Q&A letters" href='masterit200302.php'>February 2003</a></li>
<li><a title="Q&A letters" href='masterit200303.php'>March 2003</a></li>
<li><a title="Q&A letters" href='masterit200304.php'>April 2003</a></li>
<li><a title="Q&A letters" href='masterit200305.php'>May 2003</a></li>
<li><a title="Q&A letters" href='masterit200306.php'>June 2003</a></li>
<li><a title="Q&A letters" href='masterit200307.php'>July 2003</a></li>
<li><a title="Q&A letters" href='masterit200308.php'>August 2003</a></li>
<li><a title="Q&A letters" href='masterit200309.php'>September 2003</a></li>
<li><a title="Q&A letters" href='masterit200310.php'>October 2003</a></li>
<li><a title="Q&A letters" href='masterit200311.php'>November 2003</a></li>
<li><a title="Q&A letters" href='masterit200312.php'>December 2003</a></li>
<li> </li><br><li>Or go back to:</li><li><a title='Q&A/MasterIT letters from 2003' href="masterit2003.php">2003 archive</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>January 2003</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Mark's writing' href="written.php">Professional Writing</a> > <a title='My weekly Q&A column in The Australian' href="masterIT.php">MasterIT</a> > <a title='Q&A/MasterIT letters from 2003' href="masterit2003.php">2003 archive</a> > <a title='Q&A letters' href="masterit200301.php">January 2003</a>
<br><br>		<br>
<b>How do I arrange my bookmarks & folders of bookmarks in IE? I've gone from v4 to v6 on Win98 and still can't find any way of organising the folders so that they appear in any kind of order other than the order that I've added them.</b><br>
<br>
There are a couple of ways to rearrange the bookmarks in IE6. The easiest way is to fire up IE, open the Favourites menu, and then simply rearrange the folders and favourites by dragging and dropping them. You can also drag links into folders - just hover over the folder name for a second and it will pop open, then drop the link into it. Folders can also be dragged into other folders.<br>
<br>
Note that the Links folder is special - it contains the web sites that are displayed in the Links toolbar. You'll probably want to drop your most frequently visited sites in here.<br>
<br>
If alphabetical order is your thing, life is even easier. Just right click on any link and select "sort by name".<br>
<br>
Note that all these techniques also work on the Start Menu. There is a Microsoft Knowledge Base article on the subject here (<a href="http://support.microsoft.com/default.aspx?scid=KB;en-us;q177482" target="_blank">http://support.microsoft.com/default.aspx?scid=KB;en-us;q177482</a>) which even sports a cute little animation showing you how it's done.<br>
<br>
<br>
<b>I've noticed that my work colleague's screen seems to have a better picture than mine, even though it is the same make and model. Her screen seems somehow more solid and easy on the eyes. Is there some setting I'm missing?</b><br>
<br>
It sounds like your colleague's screen is set to a higher refresh rate than yours. The refresh rate of a screen is how many times per second the picture gets drawn. This makes all non-LCD monitors appear to flicker; it's just that your eyes tend not to notice if they flicker fast enough.<br>
<br>
By default, Windows sets the refresh rate to 60 Hertz - so the picture on the screen redraws 60 times a second. Modern monitors are typically capable of much higher refresh rates, and it's very worthwhile to take advantage of this, especially if you are in front of a screen for long periods of time.<br>
<br>
To change the refresh rate in Windows you'll need to go into the display properties. From here things vary depending on which version of Windows you're using. This Microsoft article (<a href="http://support.microsoft.com/default.aspx?scid=kb;en-us;311403" target="_blank">http://support.microsoft.com/default.aspx?scid=kb;en-us;311403</a>) will show you how it's done in Windows XP. Searching the Microsoft site or Google for "refresh rate" along with your version of Windows will give you the low down how it's done for you.<br>
<br>
<i><p>Did the information on this page help you? Entertain you? Bore you? <a href="contact.php?subject=MasterIT">Drop me a line</a>.</p>

<p>If you're feeling particularly generous, you can even <a href="buypics.php">click here to send me some dot-com riches</a>. Think of it as online busking.</i></p>
	</div>
</div>
</body>
</html>