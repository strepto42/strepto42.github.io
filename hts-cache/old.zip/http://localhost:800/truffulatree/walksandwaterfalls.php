<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - 15/7/2005 - Walks and Waterfalls</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="Walks and Waterfalls">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="Greetings from a Bum" href='greetingsfromabum.php'>29/4/2005</a></li>
<li><a title="Onward" href='onward.php'>2/5/2005</a></li>
<li><a title="It's a tough life (pt 1: Bundaberg, Agnes Water and 1770)" href='itsatoughlife1.php'>17/5/2005</a></li>
<li><a title="It's a tough life (pt 2: Rockhampton, Emu Park and Great Keppel Island)" href='itsatoughlife2.php'>23/5/2005</a></li>
<li><a title="There and Back Again - a Yo-yo's Tale" href='thereandbackagain.php'>18/6/2005</a></li>
<li><a title="Platypi and Grey Nomads" href='platypiandgreynomads.php'>24/6/2005</a></li>
<li><a title="Blowing Bubbles in a Watery Tomb" href='blowingbubbles.php'>1/7/2005</a></li>
<li><a title="Pieces of History" href='piecesofhistory.php'>8/7/2005</a></li>
<li><div class='activemenu'>15/7/2005</div></li>
<li><a title="Mission to Tribulation" href='missiontotribulation.php'>22/7/2005</a></li>
<li><a title="Levity, Limestone and Lava" href='levitylimestoneandlava.php'>29/7/2005</a></li>
<li><a title="Into the Never Never" href='intothenevernever.php'>5/8/2005</a></li>
<li><a title="Slowing the pace in Darwin" href='slowingthepaceindarwin.php'>12/8/2005</a></li>
<li><a title="Blistering Barnacles and Leaping Lizards" href='leapinglizards.php'>19/8/2005</a></li>
<li><a title="Kakadu and Litchfield" href='kakadu.php'>26/8/2005</a></li>
<li><a title="Legacies of War" href='legaciesofwar.php'>2/9/2005</a></li>
<li><a title="Go West" href='gowest.php'>10/9/2005</a></li>
<li><a title="Things from Above" href='thingsfromabove.php'>16/9/2005</a></li>
<li><a title="The West Coast" href='thewestcoast.php'>23/9/2005</a></li>
<li><a title="Reefs and Red Dust" href='reefsandreddust.php'>30/9/2005</a></li>
<li><a title="The Pilbara" href='pilbara.php'>7/10/2005</a></li>
<li><a title="Paradise with a Headwind" href='paradisewithaheadwind.php'>14/10/2005</a></li>
<li><a title="Down the Coral Coast" href='downthecoralcoast.php'>21/10/2005</a></li>
<li><a title="Pinnacles and Pinnipeds" href='pinnaclesandpinnipeds.php'>28/10/2005</a></li>
<li><a title="A week in Perth" href='perth.php'>4/11/2005</a></li>
<li><a title="The Southwest (from Above and Below)" href='thesouthwest.php'>11/11/2005</a></li>
<li><a title="More Heights and Depths" href='moreheightsanddepths.php'>18/11/2005</a></li>
<li><a title="Across the Nullarbor (and a bit beyond)" href='nullarbor.php'>25/11/2005</a></li>
<li><a title="Double Whammy" href='doublewhammy.php'>9/12/2005</a></li>
<li><a title="Two Cities" href='twocities.php'>19/12/2005</a></li>
<li><a title="Tassie - Part 1" href='tassie1.php'>1/1/2006</a></li>
<li><a title="Tassie - Part 2" href='tassie2.php'>7/1/2006</a></li>
<li><a title="Full Circle" href='fullcircle.php'>26/1/2006</a></li>
<li><a title="The Wrap Up" href='thewrapup.php'>23/3/2006</a></li>
<li> </li><br><li>Or go back to:</li><li><a title='Travelouges and blogs from my trip around Australia' href="nerdseyeview.php">Nerd's Eye View</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>15/7/2005</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Travel stories and pictures' href="travel.php">Travelogues</a> > <a title='Travelouges and blogs from my trip around Australia' href="nerdseyeview.php">Nerd's Eye View</a> > <a title='Walks and Waterfalls' href="walksandwaterfalls.php">15/7/2005</a>
<br><br>		


<h1>Walks and Waterfalls</h1>

<a href="images/maps/Map050715.gif"><img src="images/maps/Map050715_sm.gif" align="right"></a>
<p>Well, here I am again, with another week under my belt.</p>

<p>Remember how I said I wasn't going to send round large emails any more?</p>

<p><a href="http://www.imdb.com/title/tt0088944/quotes" target="_blank">I lied...</a></p>

<p>I've had a change of heart - however, I'm happy to maintain two lists, one for people who still like the full email thing, and another for people who'd prefer just the links. If you'd like to be on the latter list (and only get small emails), you have to tell me. By default you'll all remain on the main list.</p>

<p>On with the story. After I left Townsville, I headed off into the "bush" again, West, to the Paluma Range, and in particular the town of Paluma itself.</p>

<p>Unfortunately, things conspired against me on the first afternoon. For starters, it was cloudy up there, and so the brilliant lookout was more of a whiteout. There was also no mobile reception to be had up here (good old Telstra claim to have 98% of the population covered, but they're just plain lying), and I needed to make a call, so I headed down the mountain again, to a camp spot called Big Crystal Creek.</p>

<p>It was actually really nice, and I had a satisfying camera nerd session at sunset, playing with my tripod and various bits of equipment (mind out of the gutter people).</p>

<p>My only complaints were that there were lots of mozzies round, and the hot shower didn't work. But such is life.</p>

<p>The next morning I headed back up to Paluma again, and this time it was a lovely day. I went on a nice, longish (4-5kms) walk through the rainforest to another pretty creek, via another spectacular lookout.</p>

<p>After that, I drove out to Paluma Dam. By then it was all getting a bit late, so I decided to stay there, despite it being a more expensive place to camp (16 bucks, and not even a shower - but hey what can you do? Well, drive for an hour on a twisty windy dirt road at night - sod that).</p>

<p>Anyway, I was rewarded, as it was a nice secluded spot to camp, and just as dusk fell a cloud wandered over the mountain, and I got some really nice photos. It was all very King Arthur actually; Mists of Avalon and all that.</p>
 
<p>The next day I drove down the mountain again, and headed to a spot called Jourama Falls, which was a really nice spot, but not amazing; I think I must be getting a little spoiled for scenery these days. :)</p>

<p>After that little walk I felt like a change of scenery, so I headed to a spot called Lucinda, on the coast, just South of Hinchinbrook Island. Unfortunately I have neither the time, money nor gear to explore Hinchinbrook properly. Some other time though, as it looks amazing.</p>

<p>Lucinda is another little town with nothing much going for it, except that there is a really long jetty for loading sugar there.</p>

<p>When I say long, I mean long. If someone ever tells you to take a long walk off a short pier, this is probably the worst place to go. I read somewhere that it's the longest in the world - 5.7kms or 6 point something, depending on which literature you read.</p>

<p>I had planned to stay there, but the caravan park was packed, and looked a bit foul, so as it wasn't too late in the day I pushed on to my next destination, Wallaman falls.</p>

<p>At 268 metres, these falls are apparently the largest single drop falls in Australia. They're quite impressive, even in the dry season. After staying overnight and experiencing the coldest night of my trip so far (5 degrees or so in the morning), I took some pics from the top, and then headed down to the base of the falls for more photos (and a nice healthy walk back up!).</p>

<p>To give you an idea of the scale, <a href="http://www.truffulatree.com.au/images/20050715/IMG_4393.JPG">this image</a> has 3 people in it. Feel free to do a Where's Wally.</p>

<p>Cardwell turned out to be my next stop on the road after Wallaman. It's a funny little town, not unpleasant, and I stayed there a couple of nights getting my work for the week done, and riding my bike around. Of course I also took the usual pics (including some of the laziest Rhinoceros Beetle in QLD - it moved about 30cm in the time I was there).</p>

<p>I'm in Mission Beach now, which is also nice - the beach is the nicest I've seen in a while, despite the sharks, crocs and deadly jellyfish (ok the latter aren't around at this time of year). From here I'll push on to Atherton and Cape tribulation, before stopping in at Cairns on my way west (I'm nearly done with the east coast!).</p>
<!-- 
<ul>
<li><a href="?fileId=IMG_4315.JPG">Paluma Dam in the mist</a></li>
<li><a href="?fileId=IMG_4324.JPG">Where's the lady of the lake?</a></li>
<li><a href="?fileId=IMG_4365.JPG">It's a LONG pier</a></li>
<li><a href="?fileId=IMG_4398.JPG">Wallaman Falls</a></li>
<li><a href="?fileId=IMG_4505.JPG">The world's laziest beetle</a></li>
</ul>
 -->
<table width="800">
	<tr>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=IMG_4315.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20050715/IMG_4315.JPG' ALT='Paluma Dam in the mist'><BR>Paluma Dam in the mist</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=IMG_4324.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20050715/IMG_4324.JPG' ALT="Where's the lady of the lake?"><BR>Where's the lady of the lake?</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=IMG_4365.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20050715/IMG_4365.JPG' ALT="It's a LONG pier"><BR>It's a LONG pier</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=IMG_4398.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20050715/IMG_4398.JPG' ALT='Wallaman Falls'><BR>Wallaman Falls</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=IMG_4505.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20050715/IMG_4505.JPG' ALT="The world's laziest beetle"><BR>The world's laziest beetle</a>
	</td>
	</tr>
</table>

<p>Till next time... happy travels!</p>

<br><br>
All images in this gallery:<br>
<table width='800'>
<tr>
</tr>
<tr><td><A ID='IMG_4109.JPG' href='walksandwaterfalls.php?fileId=IMG_4109.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050715/IMG_4109.JPG' ALT='IMG_4109.JPG'><BR>IMG_4109.JPG<br>51.26 KB</a><div class='inv'><br><a href='./images/20050715/IMG_4109.JPG' ALT='IMG_4109.JPG'>IMG_4109.JPG</a></div></td>
<td><A ID='IMG_4110.JPG' href='walksandwaterfalls.php?fileId=IMG_4110.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050715/IMG_4110.JPG' ALT='IMG_4110.JPG'><BR>IMG_4110.JPG<br>69.81 KB</a><div class='inv'><br><a href='./images/20050715/IMG_4110.JPG' ALT='IMG_4110.JPG'>IMG_4110.JPG</a></div></td>
<td><A ID='IMG_4115.JPG' href='walksandwaterfalls.php?fileId=IMG_4115.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050715/IMG_4115.JPG' ALT='IMG_4115.JPG'><BR>IMG_4115.JPG<br>64.05 KB</a><div class='inv'><br><a href='./images/20050715/IMG_4115.JPG' ALT='IMG_4115.JPG'>IMG_4115.JPG</a></div></td>
<td><A ID='IMG_4118.JPG' href='walksandwaterfalls.php?fileId=IMG_4118.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050715/IMG_4118.JPG' ALT='IMG_4118.JPG'><BR>IMG_4118.JPG<br>68.12 KB</a><div class='inv'><br><a href='./images/20050715/IMG_4118.JPG' ALT='IMG_4118.JPG'>IMG_4118.JPG</a></div></td>
<td><A ID='IMG_4121.JPG' href='walksandwaterfalls.php?fileId=IMG_4121.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050715/IMG_4121.JPG' ALT='IMG_4121.JPG'><BR>IMG_4121.JPG<br>83.02 KB</a><div class='inv'><br><a href='./images/20050715/IMG_4121.JPG' ALT='IMG_4121.JPG'>IMG_4121.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_4123.JPG' href='walksandwaterfalls.php?fileId=IMG_4123.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050715/IMG_4123.JPG' ALT='IMG_4123.JPG'><BR>IMG_4123.JPG<br>69.9 KB</a><div class='inv'><br><a href='./images/20050715/IMG_4123.JPG' ALT='IMG_4123.JPG'>IMG_4123.JPG</a></div></td>
<td><A ID='IMG_4128.JPG' href='walksandwaterfalls.php?fileId=IMG_4128.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050715/IMG_4128.JPG' ALT='IMG_4128.JPG'><BR>IMG_4128.JPG<br>75.35 KB</a><div class='inv'><br><a href='./images/20050715/IMG_4128.JPG' ALT='IMG_4128.JPG'>IMG_4128.JPG</a></div></td>
<td><A ID='IMG_4132.JPG' href='walksandwaterfalls.php?fileId=IMG_4132.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050715/IMG_4132.JPG' ALT='IMG_4132.JPG'><BR>IMG_4132.JPG<br>67.59 KB</a><div class='inv'><br><a href='./images/20050715/IMG_4132.JPG' ALT='IMG_4132.JPG'>IMG_4132.JPG</a></div></td>
<td><A ID='IMG_4146.JPG' href='walksandwaterfalls.php?fileId=IMG_4146.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050715/IMG_4146.JPG' ALT='IMG_4146.JPG'><BR>IMG_4146.JPG<br>75.74 KB</a><div class='inv'><br><a href='./images/20050715/IMG_4146.JPG' ALT='IMG_4146.JPG'>IMG_4146.JPG</a></div></td>
<td><A ID='IMG_4161.JPG' href='walksandwaterfalls.php?fileId=IMG_4161.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050715/IMG_4161.JPG' ALT='IMG_4161.JPG'><BR>IMG_4161.JPG<br>91.82 KB</a><div class='inv'><br><a href='./images/20050715/IMG_4161.JPG' ALT='IMG_4161.JPG'>IMG_4161.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_4168.JPG' href='walksandwaterfalls.php?fileId=IMG_4168.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050715/IMG_4168.JPG' ALT='IMG_4168.JPG'><BR>IMG_4168.JPG<br>54.54 KB</a><div class='inv'><br><a href='./images/20050715/IMG_4168.JPG' ALT='IMG_4168.JPG'>IMG_4168.JPG</a></div></td>
<td><A ID='IMG_4174.JPG' href='walksandwaterfalls.php?fileId=IMG_4174.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050715/IMG_4174.JPG' ALT='IMG_4174.JPG'><BR>IMG_4174.JPG<br>56.74 KB</a><div class='inv'><br><a href='./images/20050715/IMG_4174.JPG' ALT='IMG_4174.JPG'>IMG_4174.JPG</a></div></td>
<td><A ID='IMG_4175.JPG' href='walksandwaterfalls.php?fileId=IMG_4175.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050715/IMG_4175.JPG' ALT='IMG_4175.JPG'><BR>IMG_4175.JPG<br>116.15 KB</a><div class='inv'><br><a href='./images/20050715/IMG_4175.JPG' ALT='IMG_4175.JPG'>IMG_4175.JPG</a></div></td>
<td><A ID='IMG_4181.JPG' href='walksandwaterfalls.php?fileId=IMG_4181.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050715/IMG_4181.JPG' ALT='IMG_4181.JPG'><BR>IMG_4181.JPG<br>106.06 KB</a><div class='inv'><br><a href='./images/20050715/IMG_4181.JPG' ALT='IMG_4181.JPG'>IMG_4181.JPG</a></div></td>
<td><A ID='IMG_4187.JPG' href='walksandwaterfalls.php?fileId=IMG_4187.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050715/IMG_4187.JPG' ALT='IMG_4187.JPG'><BR>IMG_4187.JPG<br>123.56 KB</a><div class='inv'><br><a href='./images/20050715/IMG_4187.JPG' ALT='IMG_4187.JPG'>IMG_4187.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_4190.JPG' href='walksandwaterfalls.php?fileId=IMG_4190.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050715/IMG_4190.JPG' ALT='IMG_4190.JPG'><BR>IMG_4190.JPG<br>46.84 KB</a><div class='inv'><br><a href='./images/20050715/IMG_4190.JPG' ALT='IMG_4190.JPG'>IMG_4190.JPG</a></div></td>
<td><A ID='IMG_4191.JPG' href='walksandwaterfalls.php?fileId=IMG_4191.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050715/IMG_4191.JPG' ALT='IMG_4191.JPG'><BR>IMG_4191.JPG<br>51.09 KB</a><div class='inv'><br><a href='./images/20050715/IMG_4191.JPG' ALT='IMG_4191.JPG'>IMG_4191.JPG</a></div></td>
<td><A ID='IMG_4247.JPG' href='walksandwaterfalls.php?fileId=IMG_4247.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050715/IMG_4247.JPG' ALT='IMG_4247.JPG'><BR>IMG_4247.JPG<br>117.92 KB</a><div class='inv'><br><a href='./images/20050715/IMG_4247.JPG' ALT='IMG_4247.JPG'>IMG_4247.JPG</a></div></td>
<td><A ID='IMG_4250.JPG' href='walksandwaterfalls.php?fileId=IMG_4250.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050715/IMG_4250.JPG' ALT='IMG_4250.JPG'><BR>IMG_4250.JPG<br>114.48 KB</a><div class='inv'><br><a href='./images/20050715/IMG_4250.JPG' ALT='IMG_4250.JPG'>IMG_4250.JPG</a></div></td>
<td><A ID='IMG_4253.JPG' href='walksandwaterfalls.php?fileId=IMG_4253.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050715/IMG_4253.JPG' ALT='IMG_4253.JPG'><BR>IMG_4253.JPG<br>86.11 KB</a><div class='inv'><br><a href='./images/20050715/IMG_4253.JPG' ALT='IMG_4253.JPG'>IMG_4253.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_4264.JPG' href='walksandwaterfalls.php?fileId=IMG_4264.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050715/IMG_4264.JPG' ALT='IMG_4264.JPG'><BR>IMG_4264.JPG<br>118.62 KB</a><div class='inv'><br><a href='./images/20050715/IMG_4264.JPG' ALT='IMG_4264.JPG'>IMG_4264.JPG</a></div></td>
<td><A ID='IMG_4266.JPG' href='walksandwaterfalls.php?fileId=IMG_4266.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050715/IMG_4266.JPG' ALT='IMG_4266.JPG'><BR>IMG_4266.JPG<br>119.54 KB</a><div class='inv'><br><a href='./images/20050715/IMG_4266.JPG' ALT='IMG_4266.JPG'>IMG_4266.JPG</a></div></td>
<td><A ID='IMG_4268.JPG' href='walksandwaterfalls.php?fileId=IMG_4268.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050715/IMG_4268.JPG' ALT='IMG_4268.JPG'><BR>IMG_4268.JPG<br>70.8 KB</a><div class='inv'><br><a href='./images/20050715/IMG_4268.JPG' ALT='IMG_4268.JPG'>IMG_4268.JPG</a></div></td>
<td><A ID='IMG_4272.JPG' href='walksandwaterfalls.php?fileId=IMG_4272.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050715/IMG_4272.JPG' ALT='IMG_4272.JPG'><BR>IMG_4272.JPG<br>134.22 KB</a><div class='inv'><br><a href='./images/20050715/IMG_4272.JPG' ALT='IMG_4272.JPG'>IMG_4272.JPG</a></div></td>
<td><A ID='IMG_4275.JPG' href='walksandwaterfalls.php?fileId=IMG_4275.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050715/IMG_4275.JPG' ALT='IMG_4275.JPG'><BR>IMG_4275.JPG<br>103.04 KB</a><div class='inv'><br><a href='./images/20050715/IMG_4275.JPG' ALT='IMG_4275.JPG'>IMG_4275.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_4277.JPG' href='walksandwaterfalls.php?fileId=IMG_4277.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050715/IMG_4277.JPG' ALT='IMG_4277.JPG'><BR>IMG_4277.JPG<br>123.77 KB</a><div class='inv'><br><a href='./images/20050715/IMG_4277.JPG' ALT='IMG_4277.JPG'>IMG_4277.JPG</a></div></td>
<td><A ID='IMG_4283.JPG' href='walksandwaterfalls.php?fileId=IMG_4283.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050715/IMG_4283.JPG' ALT='IMG_4283.JPG'><BR>IMG_4283.JPG<br>94.92 KB</a><div class='inv'><br><a href='./images/20050715/IMG_4283.JPG' ALT='IMG_4283.JPG'>IMG_4283.JPG</a></div></td>
<td><A ID='IMG_4293.JPG' href='walksandwaterfalls.php?fileId=IMG_4293.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050715/IMG_4293.JPG' ALT='IMG_4293.JPG'><BR>IMG_4293.JPG<br>67.93 KB</a><div class='inv'><br><a href='./images/20050715/IMG_4293.JPG' ALT='IMG_4293.JPG'>IMG_4293.JPG</a></div></td>
<td><A ID='IMG_4298.JPG' href='walksandwaterfalls.php?fileId=IMG_4298.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050715/IMG_4298.JPG' ALT='IMG_4298.JPG'><BR>IMG_4298.JPG<br>81.54 KB</a><div class='inv'><br><a href='./images/20050715/IMG_4298.JPG' ALT='IMG_4298.JPG'>IMG_4298.JPG</a></div></td>
<td><A ID='IMG_4299.JPG' href='walksandwaterfalls.php?fileId=IMG_4299.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050715/IMG_4299.JPG' ALT='IMG_4299.JPG'><BR>IMG_4299.JPG<br>66.07 KB</a><div class='inv'><br><a href='./images/20050715/IMG_4299.JPG' ALT='IMG_4299.JPG'>IMG_4299.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_4301.JPG' href='walksandwaterfalls.php?fileId=IMG_4301.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050715/IMG_4301.JPG' ALT='IMG_4301.JPG'><BR>IMG_4301.JPG<br>93 KB</a><div class='inv'><br><a href='./images/20050715/IMG_4301.JPG' ALT='IMG_4301.JPG'>IMG_4301.JPG</a></div></td>
<td><A ID='IMG_4304.JPG' href='walksandwaterfalls.php?fileId=IMG_4304.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050715/IMG_4304.JPG' ALT='IMG_4304.JPG'><BR>IMG_4304.JPG<br>30.84 KB</a><div class='inv'><br><a href='./images/20050715/IMG_4304.JPG' ALT='IMG_4304.JPG'>IMG_4304.JPG</a></div></td>
<td><A ID='IMG_4305.JPG' href='walksandwaterfalls.php?fileId=IMG_4305.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050715/IMG_4305.JPG' ALT='IMG_4305.JPG'><BR>IMG_4305.JPG<br>35.61 KB</a><div class='inv'><br><a href='./images/20050715/IMG_4305.JPG' ALT='IMG_4305.JPG'>IMG_4305.JPG</a></div></td>
<td><A ID='IMG_4314.JPG' href='walksandwaterfalls.php?fileId=IMG_4314.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050715/IMG_4314.JPG' ALT='IMG_4314.JPG'><BR>IMG_4314.JPG<br>51.35 KB</a><div class='inv'><br><a href='./images/20050715/IMG_4314.JPG' ALT='IMG_4314.JPG'>IMG_4314.JPG</a></div></td>
<td><A ID='IMG_4315.JPG' href='walksandwaterfalls.php?fileId=IMG_4315.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050715/IMG_4315.JPG' ALT='IMG_4315.JPG'><BR>IMG_4315.JPG<br>35.69 KB</a><div class='inv'><br><a href='./images/20050715/IMG_4315.JPG' ALT='IMG_4315.JPG'>IMG_4315.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_4316.JPG' href='walksandwaterfalls.php?fileId=IMG_4316.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050715/IMG_4316.JPG' ALT='IMG_4316.JPG'><BR>IMG_4316.JPG<br>33.97 KB</a><div class='inv'><br><a href='./images/20050715/IMG_4316.JPG' ALT='IMG_4316.JPG'>IMG_4316.JPG</a></div></td>
<td><A ID='IMG_4317.JPG' href='walksandwaterfalls.php?fileId=IMG_4317.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050715/IMG_4317.JPG' ALT='IMG_4317.JPG'><BR>IMG_4317.JPG<br>41.67 KB</a><div class='inv'><br><a href='./images/20050715/IMG_4317.JPG' ALT='IMG_4317.JPG'>IMG_4317.JPG</a></div></td>
<td><A ID='IMG_4318.JPG' href='walksandwaterfalls.php?fileId=IMG_4318.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050715/IMG_4318.JPG' ALT='IMG_4318.JPG'><BR>IMG_4318.JPG<br>31.56 KB</a><div class='inv'><br><a href='./images/20050715/IMG_4318.JPG' ALT='IMG_4318.JPG'>IMG_4318.JPG</a></div></td>
<td><A ID='IMG_4324.JPG' href='walksandwaterfalls.php?fileId=IMG_4324.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050715/IMG_4324.JPG' ALT='IMG_4324.JPG'><BR>IMG_4324.JPG<br>29.5 KB</a><div class='inv'><br><a href='./images/20050715/IMG_4324.JPG' ALT='IMG_4324.JPG'>IMG_4324.JPG</a></div></td>
<td><A ID='IMG_4325.JPG' href='walksandwaterfalls.php?fileId=IMG_4325.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050715/IMG_4325.JPG' ALT='IMG_4325.JPG'><BR>IMG_4325.JPG<br>29.89 KB</a><div class='inv'><br><a href='./images/20050715/IMG_4325.JPG' ALT='IMG_4325.JPG'>IMG_4325.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_4327.JPG' href='walksandwaterfalls.php?fileId=IMG_4327.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050715/IMG_4327.JPG' ALT='IMG_4327.JPG'><BR>IMG_4327.JPG<br>35.57 KB</a><div class='inv'><br><a href='./images/20050715/IMG_4327.JPG' ALT='IMG_4327.JPG'>IMG_4327.JPG</a></div></td>
<td><A ID='IMG_4330.JPG' href='walksandwaterfalls.php?fileId=IMG_4330.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050715/IMG_4330.JPG' ALT='IMG_4330.JPG'><BR>IMG_4330.JPG<br>114.86 KB</a><div class='inv'><br><a href='./images/20050715/IMG_4330.JPG' ALT='IMG_4330.JPG'>IMG_4330.JPG</a></div></td>
<td><A ID='IMG_4338.JPG' href='walksandwaterfalls.php?fileId=IMG_4338.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050715/IMG_4338.JPG' ALT='IMG_4338.JPG'><BR>IMG_4338.JPG<br>111.74 KB</a><div class='inv'><br><a href='./images/20050715/IMG_4338.JPG' ALT='IMG_4338.JPG'>IMG_4338.JPG</a></div></td>
<td><A ID='IMG_4341.JPG' href='walksandwaterfalls.php?fileId=IMG_4341.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050715/IMG_4341.JPG' ALT='IMG_4341.JPG'><BR>IMG_4341.JPG<br>115.32 KB</a><div class='inv'><br><a href='./images/20050715/IMG_4341.JPG' ALT='IMG_4341.JPG'>IMG_4341.JPG</a></div></td>
<td><A ID='IMG_4342.JPG' href='walksandwaterfalls.php?fileId=IMG_4342.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050715/IMG_4342.JPG' ALT='IMG_4342.JPG'><BR>IMG_4342.JPG<br>124.45 KB</a><div class='inv'><br><a href='./images/20050715/IMG_4342.JPG' ALT='IMG_4342.JPG'>IMG_4342.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_4349.JPG' href='walksandwaterfalls.php?fileId=IMG_4349.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050715/IMG_4349.JPG' ALT='IMG_4349.JPG'><BR>IMG_4349.JPG<br>125.77 KB</a><div class='inv'><br><a href='./images/20050715/IMG_4349.JPG' ALT='IMG_4349.JPG'>IMG_4349.JPG</a></div></td>
<td><A ID='IMG_4350.JPG' href='walksandwaterfalls.php?fileId=IMG_4350.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050715/IMG_4350.JPG' ALT='IMG_4350.JPG'><BR>IMG_4350.JPG<br>127.63 KB</a><div class='inv'><br><a href='./images/20050715/IMG_4350.JPG' ALT='IMG_4350.JPG'>IMG_4350.JPG</a></div></td>
<td><A ID='IMG_4358.JPG' href='walksandwaterfalls.php?fileId=IMG_4358.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050715/IMG_4358.JPG' ALT='IMG_4358.JPG'><BR>IMG_4358.JPG<br>120.11 KB</a><div class='inv'><br><a href='./images/20050715/IMG_4358.JPG' ALT='IMG_4358.JPG'>IMG_4358.JPG</a></div></td>
<td><A ID='IMG_4360.JPG' href='walksandwaterfalls.php?fileId=IMG_4360.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050715/IMG_4360.JPG' ALT='IMG_4360.JPG'><BR>IMG_4360.JPG<br>112.68 KB</a><div class='inv'><br><a href='./images/20050715/IMG_4360.JPG' ALT='IMG_4360.JPG'>IMG_4360.JPG</a></div></td>
<td><A ID='IMG_4362.JPG' href='walksandwaterfalls.php?fileId=IMG_4362.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050715/IMG_4362.JPG' ALT='IMG_4362.JPG'><BR>IMG_4362.JPG<br>81.68 KB</a><div class='inv'><br><a href='./images/20050715/IMG_4362.JPG' ALT='IMG_4362.JPG'>IMG_4362.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_4365.JPG' href='walksandwaterfalls.php?fileId=IMG_4365.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050715/IMG_4365.JPG' ALT='IMG_4365.JPG'><BR>IMG_4365.JPG<br>43.89 KB</a><div class='inv'><br><a href='./images/20050715/IMG_4365.JPG' ALT='IMG_4365.JPG'>IMG_4365.JPG</a></div></td>
<td><A ID='IMG_4366.JPG' href='walksandwaterfalls.php?fileId=IMG_4366.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050715/IMG_4366.JPG' ALT='IMG_4366.JPG'><BR>IMG_4366.JPG<br>43.34 KB</a><div class='inv'><br><a href='./images/20050715/IMG_4366.JPG' ALT='IMG_4366.JPG'>IMG_4366.JPG</a></div></td>
<td><A ID='IMG_4369.JPG' href='walksandwaterfalls.php?fileId=IMG_4369.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050715/IMG_4369.JPG' ALT='IMG_4369.JPG'><BR>IMG_4369.JPG<br>48.08 KB</a><div class='inv'><br><a href='./images/20050715/IMG_4369.JPG' ALT='IMG_4369.JPG'>IMG_4369.JPG</a></div></td>
<td><A ID='IMG_4372.JPG' href='walksandwaterfalls.php?fileId=IMG_4372.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050715/IMG_4372.JPG' ALT='IMG_4372.JPG'><BR>IMG_4372.JPG<br>61.08 KB</a><div class='inv'><br><a href='./images/20050715/IMG_4372.JPG' ALT='IMG_4372.JPG'>IMG_4372.JPG</a></div></td>
<td><A ID='IMG_4375.JPG' href='walksandwaterfalls.php?fileId=IMG_4375.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050715/IMG_4375.JPG' ALT='IMG_4375.JPG'><BR>IMG_4375.JPG<br>60.65 KB</a><div class='inv'><br><a href='./images/20050715/IMG_4375.JPG' ALT='IMG_4375.JPG'>IMG_4375.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_4376.JPG' href='walksandwaterfalls.php?fileId=IMG_4376.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050715/IMG_4376.JPG' ALT='IMG_4376.JPG'><BR>IMG_4376.JPG<br>56.37 KB</a><div class='inv'><br><a href='./images/20050715/IMG_4376.JPG' ALT='IMG_4376.JPG'>IMG_4376.JPG</a></div></td>
<td><A ID='IMG_4377.JPG' href='walksandwaterfalls.php?fileId=IMG_4377.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050715/IMG_4377.JPG' ALT='IMG_4377.JPG'><BR>IMG_4377.JPG<br>61.83 KB</a><div class='inv'><br><a href='./images/20050715/IMG_4377.JPG' ALT='IMG_4377.JPG'>IMG_4377.JPG</a></div></td>
<td><A ID='IMG_4378.JPG' href='walksandwaterfalls.php?fileId=IMG_4378.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050715/IMG_4378.JPG' ALT='IMG_4378.JPG'><BR>IMG_4378.JPG<br>45.25 KB</a><div class='inv'><br><a href='./images/20050715/IMG_4378.JPG' ALT='IMG_4378.JPG'>IMG_4378.JPG</a></div></td>
<td><A ID='IMG_4380.JPG' href='walksandwaterfalls.php?fileId=IMG_4380.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050715/IMG_4380.JPG' ALT='IMG_4380.JPG'><BR>IMG_4380.JPG<br>94.51 KB</a><div class='inv'><br><a href='./images/20050715/IMG_4380.JPG' ALT='IMG_4380.JPG'>IMG_4380.JPG</a></div></td>
<td><A ID='IMG_4386.JPG' href='walksandwaterfalls.php?fileId=IMG_4386.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050715/IMG_4386.JPG' ALT='IMG_4386.JPG'><BR>IMG_4386.JPG<br>74.4 KB</a><div class='inv'><br><a href='./images/20050715/IMG_4386.JPG' ALT='IMG_4386.JPG'>IMG_4386.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_4387.JPG' href='walksandwaterfalls.php?fileId=IMG_4387.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050715/IMG_4387.JPG' ALT='IMG_4387.JPG'><BR>IMG_4387.JPG<br>96.76 KB</a><div class='inv'><br><a href='./images/20050715/IMG_4387.JPG' ALT='IMG_4387.JPG'>IMG_4387.JPG</a></div></td>
<td><A ID='IMG_4388.JPG' href='walksandwaterfalls.php?fileId=IMG_4388.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050715/IMG_4388.JPG' ALT='IMG_4388.JPG'><BR>IMG_4388.JPG<br>120.24 KB</a><div class='inv'><br><a href='./images/20050715/IMG_4388.JPG' ALT='IMG_4388.JPG'>IMG_4388.JPG</a></div></td>
<td><A ID='IMG_4389.JPG' href='walksandwaterfalls.php?fileId=IMG_4389.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050715/IMG_4389.JPG' ALT='IMG_4389.JPG'><BR>IMG_4389.JPG<br>114.91 KB</a><div class='inv'><br><a href='./images/20050715/IMG_4389.JPG' ALT='IMG_4389.JPG'>IMG_4389.JPG</a></div></td>
<td><A ID='IMG_4391.JPG' href='walksandwaterfalls.php?fileId=IMG_4391.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050715/IMG_4391.JPG' ALT='IMG_4391.JPG'><BR>IMG_4391.JPG<br>96.51 KB</a><div class='inv'><br><a href='./images/20050715/IMG_4391.JPG' ALT='IMG_4391.JPG'>IMG_4391.JPG</a></div></td>
<td><A ID='IMG_4393.JPG' href='walksandwaterfalls.php?fileId=IMG_4393.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050715/IMG_4393.JPG' ALT='IMG_4393.JPG'><BR>IMG_4393.JPG<br>114.79 KB</a><div class='inv'><br><a href='./images/20050715/IMG_4393.JPG' ALT='IMG_4393.JPG'>IMG_4393.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_4397.JPG' href='walksandwaterfalls.php?fileId=IMG_4397.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050715/IMG_4397.JPG' ALT='IMG_4397.JPG'><BR>IMG_4397.JPG<br>83.25 KB</a><div class='inv'><br><a href='./images/20050715/IMG_4397.JPG' ALT='IMG_4397.JPG'>IMG_4397.JPG</a></div></td>
<td><A ID='IMG_4398.JPG' href='walksandwaterfalls.php?fileId=IMG_4398.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050715/IMG_4398.JPG' ALT='IMG_4398.JPG'><BR>IMG_4398.JPG<br>92.39 KB</a><div class='inv'><br><a href='./images/20050715/IMG_4398.JPG' ALT='IMG_4398.JPG'>IMG_4398.JPG</a></div></td>
<td><A ID='IMG_4402.JPG' href='walksandwaterfalls.php?fileId=IMG_4402.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050715/IMG_4402.JPG' ALT='IMG_4402.JPG'><BR>IMG_4402.JPG<br>127.71 KB</a><div class='inv'><br><a href='./images/20050715/IMG_4402.JPG' ALT='IMG_4402.JPG'>IMG_4402.JPG</a></div></td>
<td><A ID='IMG_4407.JPG' href='walksandwaterfalls.php?fileId=IMG_4407.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050715/IMG_4407.JPG' ALT='IMG_4407.JPG'><BR>IMG_4407.JPG<br>54.76 KB</a><div class='inv'><br><a href='./images/20050715/IMG_4407.JPG' ALT='IMG_4407.JPG'>IMG_4407.JPG</a></div></td>
<td><A ID='IMG_4412.JPG' href='walksandwaterfalls.php?fileId=IMG_4412.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050715/IMG_4412.JPG' ALT='IMG_4412.JPG'><BR>IMG_4412.JPG<br>101.91 KB</a><div class='inv'><br><a href='./images/20050715/IMG_4412.JPG' ALT='IMG_4412.JPG'>IMG_4412.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_4413.JPG' href='walksandwaterfalls.php?fileId=IMG_4413.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050715/IMG_4413.JPG' ALT='IMG_4413.JPG'><BR>IMG_4413.JPG<br>113.66 KB</a><div class='inv'><br><a href='./images/20050715/IMG_4413.JPG' ALT='IMG_4413.JPG'>IMG_4413.JPG</a></div></td>
<td><A ID='IMG_4418.JPG' href='walksandwaterfalls.php?fileId=IMG_4418.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050715/IMG_4418.JPG' ALT='IMG_4418.JPG'><BR>IMG_4418.JPG<br>77.9 KB</a><div class='inv'><br><a href='./images/20050715/IMG_4418.JPG' ALT='IMG_4418.JPG'>IMG_4418.JPG</a></div></td>
<td><A ID='IMG_4422.JPG' href='walksandwaterfalls.php?fileId=IMG_4422.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050715/IMG_4422.JPG' ALT='IMG_4422.JPG'><BR>IMG_4422.JPG<br>71.29 KB</a><div class='inv'><br><a href='./images/20050715/IMG_4422.JPG' ALT='IMG_4422.JPG'>IMG_4422.JPG</a></div></td>
<td><A ID='IMG_4423.JPG' href='walksandwaterfalls.php?fileId=IMG_4423.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050715/IMG_4423.JPG' ALT='IMG_4423.JPG'><BR>IMG_4423.JPG<br>118.14 KB</a><div class='inv'><br><a href='./images/20050715/IMG_4423.JPG' ALT='IMG_4423.JPG'>IMG_4423.JPG</a></div></td>
<td><A ID='IMG_4424.JPG' href='walksandwaterfalls.php?fileId=IMG_4424.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050715/IMG_4424.JPG' ALT='IMG_4424.JPG'><BR>IMG_4424.JPG<br>70.04 KB</a><div class='inv'><br><a href='./images/20050715/IMG_4424.JPG' ALT='IMG_4424.JPG'>IMG_4424.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_4426.JPG' href='walksandwaterfalls.php?fileId=IMG_4426.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050715/IMG_4426.JPG' ALT='IMG_4426.JPG'><BR>IMG_4426.JPG<br>79.58 KB</a><div class='inv'><br><a href='./images/20050715/IMG_4426.JPG' ALT='IMG_4426.JPG'>IMG_4426.JPG</a></div></td>
<td><A ID='IMG_4430.JPG' href='walksandwaterfalls.php?fileId=IMG_4430.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050715/IMG_4430.JPG' ALT='IMG_4430.JPG'><BR>IMG_4430.JPG<br>97.14 KB</a><div class='inv'><br><a href='./images/20050715/IMG_4430.JPG' ALT='IMG_4430.JPG'>IMG_4430.JPG</a></div></td>
<td><A ID='IMG_4440.JPG' href='walksandwaterfalls.php?fileId=IMG_4440.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050715/IMG_4440.JPG' ALT='IMG_4440.JPG'><BR>IMG_4440.JPG<br>83.36 KB</a><div class='inv'><br><a href='./images/20050715/IMG_4440.JPG' ALT='IMG_4440.JPG'>IMG_4440.JPG</a></div></td>
<td><A ID='IMG_4443.JPG' href='walksandwaterfalls.php?fileId=IMG_4443.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050715/IMG_4443.JPG' ALT='IMG_4443.JPG'><BR>IMG_4443.JPG<br>89.93 KB</a><div class='inv'><br><a href='./images/20050715/IMG_4443.JPG' ALT='IMG_4443.JPG'>IMG_4443.JPG</a></div></td>
<td><A ID='IMG_4444.JPG' href='walksandwaterfalls.php?fileId=IMG_4444.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050715/IMG_4444.JPG' ALT='IMG_4444.JPG'><BR>IMG_4444.JPG<br>85.81 KB</a><div class='inv'><br><a href='./images/20050715/IMG_4444.JPG' ALT='IMG_4444.JPG'>IMG_4444.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_4445.JPG' href='walksandwaterfalls.php?fileId=IMG_4445.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050715/IMG_4445.JPG' ALT='IMG_4445.JPG'><BR>IMG_4445.JPG<br>52.88 KB</a><div class='inv'><br><a href='./images/20050715/IMG_4445.JPG' ALT='IMG_4445.JPG'>IMG_4445.JPG</a></div></td>
<td><A ID='IMG_4450.JPG' href='walksandwaterfalls.php?fileId=IMG_4450.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050715/IMG_4450.JPG' ALT='IMG_4450.JPG'><BR>IMG_4450.JPG<br>82.2 KB</a><div class='inv'><br><a href='./images/20050715/IMG_4450.JPG' ALT='IMG_4450.JPG'>IMG_4450.JPG</a></div></td>
<td><A ID='IMG_4456.JPG' href='walksandwaterfalls.php?fileId=IMG_4456.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050715/IMG_4456.JPG' ALT='IMG_4456.JPG'><BR>IMG_4456.JPG<br>87.67 KB</a><div class='inv'><br><a href='./images/20050715/IMG_4456.JPG' ALT='IMG_4456.JPG'>IMG_4456.JPG</a></div></td>
<td><A ID='IMG_4457.JPG' href='walksandwaterfalls.php?fileId=IMG_4457.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050715/IMG_4457.JPG' ALT='IMG_4457.JPG'><BR>IMG_4457.JPG<br>80.52 KB</a><div class='inv'><br><a href='./images/20050715/IMG_4457.JPG' ALT='IMG_4457.JPG'>IMG_4457.JPG</a></div></td>
<td><A ID='IMG_4462.JPG' href='walksandwaterfalls.php?fileId=IMG_4462.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050715/IMG_4462.JPG' ALT='IMG_4462.JPG'><BR>IMG_4462.JPG<br>71.41 KB</a><div class='inv'><br><a href='./images/20050715/IMG_4462.JPG' ALT='IMG_4462.JPG'>IMG_4462.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_4465.JPG' href='walksandwaterfalls.php?fileId=IMG_4465.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050715/IMG_4465.JPG' ALT='IMG_4465.JPG'><BR>IMG_4465.JPG<br>52.73 KB</a><div class='inv'><br><a href='./images/20050715/IMG_4465.JPG' ALT='IMG_4465.JPG'>IMG_4465.JPG</a></div></td>
<td><A ID='IMG_4466.JPG' href='walksandwaterfalls.php?fileId=IMG_4466.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050715/IMG_4466.JPG' ALT='IMG_4466.JPG'><BR>IMG_4466.JPG<br>54.1 KB</a><div class='inv'><br><a href='./images/20050715/IMG_4466.JPG' ALT='IMG_4466.JPG'>IMG_4466.JPG</a></div></td>
<td><A ID='IMG_4471.JPG' href='walksandwaterfalls.php?fileId=IMG_4471.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050715/IMG_4471.JPG' ALT='IMG_4471.JPG'><BR>IMG_4471.JPG<br>71.85 KB</a><div class='inv'><br><a href='./images/20050715/IMG_4471.JPG' ALT='IMG_4471.JPG'>IMG_4471.JPG</a></div></td>
<td><A ID='IMG_4472.JPG' href='walksandwaterfalls.php?fileId=IMG_4472.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050715/IMG_4472.JPG' ALT='IMG_4472.JPG'><BR>IMG_4472.JPG<br>61.4 KB</a><div class='inv'><br><a href='./images/20050715/IMG_4472.JPG' ALT='IMG_4472.JPG'>IMG_4472.JPG</a></div></td>
<td><A ID='IMG_4485.JPG' href='walksandwaterfalls.php?fileId=IMG_4485.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050715/IMG_4485.JPG' ALT='IMG_4485.JPG'><BR>IMG_4485.JPG<br>39.53 KB</a><div class='inv'><br><a href='./images/20050715/IMG_4485.JPG' ALT='IMG_4485.JPG'>IMG_4485.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_4491.JPG' href='walksandwaterfalls.php?fileId=IMG_4491.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050715/IMG_4491.JPG' ALT='IMG_4491.JPG'><BR>IMG_4491.JPG<br>65.93 KB</a><div class='inv'><br><a href='./images/20050715/IMG_4491.JPG' ALT='IMG_4491.JPG'>IMG_4491.JPG</a></div></td>
<td><A ID='IMG_4496.JPG' href='walksandwaterfalls.php?fileId=IMG_4496.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050715/IMG_4496.JPG' ALT='IMG_4496.JPG'><BR>IMG_4496.JPG<br>37.9 KB</a><div class='inv'><br><a href='./images/20050715/IMG_4496.JPG' ALT='IMG_4496.JPG'>IMG_4496.JPG</a></div></td>
<td><A ID='IMG_4505.JPG' href='walksandwaterfalls.php?fileId=IMG_4505.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050715/IMG_4505.JPG' ALT='IMG_4505.JPG'><BR>IMG_4505.JPG<br>48.81 KB</a><div class='inv'><br><a href='./images/20050715/IMG_4505.JPG' ALT='IMG_4505.JPG'>IMG_4505.JPG</a></div></td>
<td><A ID='IMG_4507.JPG' href='walksandwaterfalls.php?fileId=IMG_4507.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050715/IMG_4507.JPG' ALT='IMG_4507.JPG'><BR>IMG_4507.JPG<br>49.55 KB</a><div class='inv'><br><a href='./images/20050715/IMG_4507.JPG' ALT='IMG_4507.JPG'>IMG_4507.JPG</a></div></td>
<td><A ID='IMG_4509.JPG' href='walksandwaterfalls.php?fileId=IMG_4509.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050715/IMG_4509.JPG' ALT='IMG_4509.JPG'><BR>IMG_4509.JPG<br>71.78 KB</a><div class='inv'><br><a href='./images/20050715/IMG_4509.JPG' ALT='IMG_4509.JPG'>IMG_4509.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_4515.JPG' href='walksandwaterfalls.php?fileId=IMG_4515.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050715/IMG_4515.JPG' ALT='IMG_4515.JPG'><BR>IMG_4515.JPG<br>50.94 KB</a><div class='inv'><br><a href='./images/20050715/IMG_4515.JPG' ALT='IMG_4515.JPG'>IMG_4515.JPG</a></div></td>
<td><A ID='IMG_4517.JPG' href='walksandwaterfalls.php?fileId=IMG_4517.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050715/IMG_4517.JPG' ALT='IMG_4517.JPG'><BR>IMG_4517.JPG<br>55.39 KB</a><div class='inv'><br><a href='./images/20050715/IMG_4517.JPG' ALT='IMG_4517.JPG'>IMG_4517.JPG</a></div></td>
<td><A ID='IMG_4520.JPG' href='walksandwaterfalls.php?fileId=IMG_4520.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050715/IMG_4520.JPG' ALT='IMG_4520.JPG'><BR>IMG_4520.JPG<br>68.73 KB</a><div class='inv'><br><a href='./images/20050715/IMG_4520.JPG' ALT='IMG_4520.JPG'>IMG_4520.JPG</a></div></td>
</tr>
</table>	</div>
</div>
</body>
</html>