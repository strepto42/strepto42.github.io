<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - 21/10/2005 - Down the Coral Coast</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="Down the Coral Coast">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="Greetings from a Bum" href='greetingsfromabum.php'>29/4/2005</a></li>
<li><a title="Onward" href='onward.php'>2/5/2005</a></li>
<li><a title="It's a tough life (pt 1: Bundaberg, Agnes Water and 1770)" href='itsatoughlife1.php'>17/5/2005</a></li>
<li><a title="It's a tough life (pt 2: Rockhampton, Emu Park and Great Keppel Island)" href='itsatoughlife2.php'>23/5/2005</a></li>
<li><a title="There and Back Again - a Yo-yo's Tale" href='thereandbackagain.php'>18/6/2005</a></li>
<li><a title="Platypi and Grey Nomads" href='platypiandgreynomads.php'>24/6/2005</a></li>
<li><a title="Blowing Bubbles in a Watery Tomb" href='blowingbubbles.php'>1/7/2005</a></li>
<li><a title="Pieces of History" href='piecesofhistory.php'>8/7/2005</a></li>
<li><a title="Walks and Waterfalls" href='walksandwaterfalls.php'>15/7/2005</a></li>
<li><a title="Mission to Tribulation" href='missiontotribulation.php'>22/7/2005</a></li>
<li><a title="Levity, Limestone and Lava" href='levitylimestoneandlava.php'>29/7/2005</a></li>
<li><a title="Into the Never Never" href='intothenevernever.php'>5/8/2005</a></li>
<li><a title="Slowing the pace in Darwin" href='slowingthepaceindarwin.php'>12/8/2005</a></li>
<li><a title="Blistering Barnacles and Leaping Lizards" href='leapinglizards.php'>19/8/2005</a></li>
<li><a title="Kakadu and Litchfield" href='kakadu.php'>26/8/2005</a></li>
<li><a title="Legacies of War" href='legaciesofwar.php'>2/9/2005</a></li>
<li><a title="Go West" href='gowest.php'>10/9/2005</a></li>
<li><a title="Things from Above" href='thingsfromabove.php'>16/9/2005</a></li>
<li><a title="The West Coast" href='thewestcoast.php'>23/9/2005</a></li>
<li><a title="Reefs and Red Dust" href='reefsandreddust.php'>30/9/2005</a></li>
<li><a title="The Pilbara" href='pilbara.php'>7/10/2005</a></li>
<li><a title="Paradise with a Headwind" href='paradisewithaheadwind.php'>14/10/2005</a></li>
<li><div class='activemenu'>21/10/2005</div></li>
<li><a title="Pinnacles and Pinnipeds" href='pinnaclesandpinnipeds.php'>28/10/2005</a></li>
<li><a title="A week in Perth" href='perth.php'>4/11/2005</a></li>
<li><a title="The Southwest (from Above and Below)" href='thesouthwest.php'>11/11/2005</a></li>
<li><a title="More Heights and Depths" href='moreheightsanddepths.php'>18/11/2005</a></li>
<li><a title="Across the Nullarbor (and a bit beyond)" href='nullarbor.php'>25/11/2005</a></li>
<li><a title="Double Whammy" href='doublewhammy.php'>9/12/2005</a></li>
<li><a title="Two Cities" href='twocities.php'>19/12/2005</a></li>
<li><a title="Tassie - Part 1" href='tassie1.php'>1/1/2006</a></li>
<li><a title="Tassie - Part 2" href='tassie2.php'>7/1/2006</a></li>
<li><a title="Full Circle" href='fullcircle.php'>26/1/2006</a></li>
<li><a title="The Wrap Up" href='thewrapup.php'>23/3/2006</a></li>
<li> </li><br><li>Or go back to:</li><li><a title='Travelouges and blogs from my trip around Australia' href="nerdseyeview.php">Nerd's Eye View</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>21/10/2005</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Travel stories and pictures' href="travel.php">Travelogues</a> > <a title='Travelouges and blogs from my trip around Australia' href="nerdseyeview.php">Nerd's Eye View</a> > <a title='Down the Coral Coast' href="downthecoralcoast.php">21/10/2005</a>
<br><br>		


<h1>Down the Coral Coast</h1>

<a href="images/maps/Map051021.gif"><img src="images/maps/Map051021_sm.gif" align="right"></a>

<p>Greetings again from far outer WA. Actually, we're finally beginning to get back into so-called civilisation; specifically, the town of Geraldton, less than (a mere) 1000kms from Perth.</p>

<p>After the last update, we stayed in Denham for a few days, and took in the sights, as well as relaxed. Jana has discovered that Doom 3 is installed on my laptop, so we spent a day being decidedly un-travellish and just nerding out. It was actually an overcast day, and one without wind, so we didn't feel so bad, although in a way perhaps we wasted it as the snorkelling might have been ok.</p>

<p>But whatever; it's nice to relax for a bit every now and then when you're on the road.</p>

<p>Denham is a nice little town, quite pleasant and quiet, and while we were there we went for a ride around the area, and checked out Little Lagoon, as well as the 3 power-generating windmills near town, which were very similar to the ones I visited up on the Atherton Tablelands at Windy Hill.</p>

<p>Monkey Mia is also nearby, about 20kms away. This is the famous spot where dolphins have been coming each day to "interact" with humans, and it's basically a resort now. We went there a couple of times, and spent some time walking around, on the beach and through the bush (low scrubby stuff on pretty-looking red dunes).</p>

<p>The wind was up as usual, and so we didn't end up snorkelling, but we did spot plenty of wildlife, like sharks, rays and various birds (including the relatively rare  Thick-billed Grass Wren).</p>

<p>We also went and watched the human-dolphin interaction one morning, which was kinda nice, even if it is somewhat a circus. One definitely gets the impression that the dolphins are quite aware that they're just there for a cheap feed, but they're still lovely animals and it was cool to see them relatively up close.</p>

<p>There are also quite a few resident (and fairly tame) Pelicans at Monkey Mia. I do quite like these birds; not only are they amusingly large (they dwarf small children), they're also quite nice to see in flight, and they have a certain air about them, with their enormous bills and yellow-ringed black beady eyes.</p>

<p>We watched one waddle along and casually relieve a seagull of it's prized dead fish breakfast. The seagull, despite belonging to a group of pretty vocal and often-cantankerous birds, was pretty much lost for words when the enormous lumbering Pelican, outweighing it by about 50 times, strode up and said "yum! I'll take that!". :)</p>

<p>A couple of other wildlife highlights included watching a daddy Emu with 3 chicks come in to have a bath at a freshwater pond, and a group of three baby swallows getting fed by their parents, who kept bringing them insects.</p>

<p>From Denham we headed off down the coast again, via a couple of nice spots, specifically Eagle Bluff, which I really recommend as a lovely camping/snorkelling spot (not that we did either), and Shell Beach, which is pretty much self-describing, and has the same coquina thing happening as Hamelin Bay. Jana had endless fun throwing handfuls of the stuff into the air (actually, I asked her to as a photo set up, with quite amusing results).</p>

<p>Our next destination was Kalbarri, next to the National Park of the same name. We spent a couple of nights in town, as there isn't any camping available in the park for some reason, although of course we still explored the park.</p>

<p>We went for a nice 8km gorge walk (the Loop Walk) and visited a spot called Natural Window. There was plenty of bird life around, and Jana ticked off a few more new birds, which was nice. The feral goat problem there was somewhat less nice - there are rather a lot of them there.</p>

<p>By the way, my +10 fly-repelling hat actually doesn't; it was just a well-timed photo last week. Unfortunately the hordes of flies in this part of the world love me almost as much as Jana (although I think having hairier arms makes a difference). Just thought I'd clarify the situation.</p>

<p>Kalbarri town itself is actually quite nice; it's very laid back. There is a wildflower centre there, and we visited it and had a nice walk and Devonshire Tea. Despite it actually being somewhat towards the end of the wildflower season, there was still a lot of spectacular stuff to see, and so of course endless photos of pretty flowers abound.</p>

<p>To the south of Kalbarri there are a few nice beaches, including a pretty good surf break (from what I hear). After that, the coast turns into spectacular cliffs, and we did another long (although much easier) walk alongside said cliffs.</p>

<p>We saw a few Humpback Whales, and admired the scenery, before riding our bikes back along the road, and heading south out of town to Port Gregory, where we spent an uneventful night.</p>

<p>Port Gregory is very small, but does boast the famous Pink Lake, where beta-carotene-producing algae are harvested for vitamin pills. We forgot about the lake entirely, and drove past it at night, so we didn't notice it until leaving this morning, when of course I had to take a few snaps. It really is rather stridently pink.</p>

<p>That pretty much brings us up to date again. Geraldton, where we are now, is actually the biggest town I've been in since Darwin. It's a little weird being back in humanland, but I'm sure I'll adjust. The scenery and landscape are changing again, as we're heading further out of the tropics and well back into the temperate zone (in fact, we're pretty much level with Brisbane at the moment, and before long we'll be hovering around Sydney's latitude).</p>

<p>So, the adventure continues. By next week I'll have finally revisited my birthplace of Perth. We'll see how cosmic that ends up being.</p>

<p>Selected snaps this week:</p>
<!-- 
<ul>
<li><a href="?fileId=IMG_1096.JPG">So long, and thanks for all the fish</a></li>
<li><a href="?fileId=IMG_1132.JPG">Feeding time three-part harmonies (alternative caption: BER!!!!)</a></li>
<li><a href="?fileId=IMG_1187.JPG">Murchison River, Kalbarri NP</a></li>
<li><a href="?fileId=IMG_1271.JPG">Random wildflowers that I can't recall the name of</a></li>
<li><a href="?fileId=IMG_1328.JPG">"Island" Rock (the tide was out, ok?)</a></li>
</ul>
 -->
<table width="800">
	<tr>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=IMG_1096.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1096.JPG' ALT='So long, and thanks for all the fish'><BR>So long, and thanks for all the fish</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=IMG_1132.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1132.JPG' ALT='Feeding time three-part harmonies (alternative caption: BER!!!!)'><BR>Feeding time three-part harmonies (alternative caption: BER!!!!)</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=IMG_1187.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1187.JPG' ALT='Murchison River, Kalbarri NP'><BR>Murchison River, Kalbarri NP</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=IMG_1271.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1271.JPG' ALT='Random wildflowers that I can't recall the name of'><BR>Random wildflowers that I can't recall the name of</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=IMG_1328.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1328.JPG' ALT='"Island" Rock (the tide was out, ok?)'><BR>"Island" Rock (the tide was out, ok?)</a>
	</td>
	</tr>
</table>

<br><br>
All images in this gallery:<br>
<table width='800'>
<tr>
</tr>
<tr><td><A ID='IMG_0979.JPG' href='downthecoralcoast.php?fileId=IMG_0979.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_0979.JPG' ALT='IMG_0979.JPG'><BR>IMG_0979.JPG<br>59.66 KB</a><div class='inv'><br><a href='./images/20051021/IMG_0979.JPG' ALT='IMG_0979.JPG'>IMG_0979.JPG</a></div></td>
<td><A ID='IMG_0980.JPG' href='downthecoralcoast.php?fileId=IMG_0980.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_0980.JPG' ALT='IMG_0980.JPG'><BR>IMG_0980.JPG<br>79.33 KB</a><div class='inv'><br><a href='./images/20051021/IMG_0980.JPG' ALT='IMG_0980.JPG'>IMG_0980.JPG</a></div></td>
<td><A ID='IMG_0981.JPG' href='downthecoralcoast.php?fileId=IMG_0981.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_0981.JPG' ALT='IMG_0981.JPG'><BR>IMG_0981.JPG<br>78.6 KB</a><div class='inv'><br><a href='./images/20051021/IMG_0981.JPG' ALT='IMG_0981.JPG'>IMG_0981.JPG</a></div></td>
<td><A ID='IMG_0994.JPG' href='downthecoralcoast.php?fileId=IMG_0994.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_0994.JPG' ALT='IMG_0994.JPG'><BR>IMG_0994.JPG<br>31.9 KB</a><div class='inv'><br><a href='./images/20051021/IMG_0994.JPG' ALT='IMG_0994.JPG'>IMG_0994.JPG</a></div></td>
<td><A ID='IMG_0997.JPG' href='downthecoralcoast.php?fileId=IMG_0997.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_0997.JPG' ALT='IMG_0997.JPG'><BR>IMG_0997.JPG<br>40.6 KB</a><div class='inv'><br><a href='./images/20051021/IMG_0997.JPG' ALT='IMG_0997.JPG'>IMG_0997.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_1004.JPG' href='downthecoralcoast.php?fileId=IMG_1004.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1004.JPG' ALT='IMG_1004.JPG'><BR>IMG_1004.JPG<br>41.61 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1004.JPG' ALT='IMG_1004.JPG'>IMG_1004.JPG</a></div></td>
<td><A ID='IMG_1006.JPG' href='downthecoralcoast.php?fileId=IMG_1006.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1006.JPG' ALT='IMG_1006.JPG'><BR>IMG_1006.JPG<br>58.92 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1006.JPG' ALT='IMG_1006.JPG'>IMG_1006.JPG</a></div></td>
<td><A ID='IMG_1007.JPG' href='downthecoralcoast.php?fileId=IMG_1007.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1007.JPG' ALT='IMG_1007.JPG'><BR>IMG_1007.JPG<br>55.17 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1007.JPG' ALT='IMG_1007.JPG'>IMG_1007.JPG</a></div></td>
<td><A ID='IMG_1008.JPG' href='downthecoralcoast.php?fileId=IMG_1008.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1008.JPG' ALT='IMG_1008.JPG'><BR>IMG_1008.JPG<br>37.07 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1008.JPG' ALT='IMG_1008.JPG'>IMG_1008.JPG</a></div></td>
<td><A ID='IMG_1010.JPG' href='downthecoralcoast.php?fileId=IMG_1010.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1010.JPG' ALT='IMG_1010.JPG'><BR>IMG_1010.JPG<br>35.38 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1010.JPG' ALT='IMG_1010.JPG'>IMG_1010.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_1015.JPG' href='downthecoralcoast.php?fileId=IMG_1015.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1015.JPG' ALT='IMG_1015.JPG'><BR>IMG_1015.JPG<br>48.03 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1015.JPG' ALT='IMG_1015.JPG'>IMG_1015.JPG</a></div></td>
<td><A ID='IMG_1017.JPG' href='downthecoralcoast.php?fileId=IMG_1017.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1017.JPG' ALT='IMG_1017.JPG'><BR>IMG_1017.JPG<br>56.57 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1017.JPG' ALT='IMG_1017.JPG'>IMG_1017.JPG</a></div></td>
<td><A ID='IMG_1022.JPG' href='downthecoralcoast.php?fileId=IMG_1022.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1022.JPG' ALT='IMG_1022.JPG'><BR>IMG_1022.JPG<br>35.96 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1022.JPG' ALT='IMG_1022.JPG'>IMG_1022.JPG</a></div></td>
<td><A ID='IMG_1024.JPG' href='downthecoralcoast.php?fileId=IMG_1024.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1024.JPG' ALT='IMG_1024.JPG'><BR>IMG_1024.JPG<br>35.19 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1024.JPG' ALT='IMG_1024.JPG'>IMG_1024.JPG</a></div></td>
<td><A ID='IMG_1025.JPG' href='downthecoralcoast.php?fileId=IMG_1025.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1025.JPG' ALT='IMG_1025.JPG'><BR>IMG_1025.JPG<br>55.69 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1025.JPG' ALT='IMG_1025.JPG'>IMG_1025.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_1028.JPG' href='downthecoralcoast.php?fileId=IMG_1028.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1028.JPG' ALT='IMG_1028.JPG'><BR>IMG_1028.JPG<br>38.66 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1028.JPG' ALT='IMG_1028.JPG'>IMG_1028.JPG</a></div></td>
<td><A ID='IMG_1034.JPG' href='downthecoralcoast.php?fileId=IMG_1034.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1034.JPG' ALT='IMG_1034.JPG'><BR>IMG_1034.JPG<br>51.32 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1034.JPG' ALT='IMG_1034.JPG'>IMG_1034.JPG</a></div></td>
<td><A ID='IMG_1037.JPG' href='downthecoralcoast.php?fileId=IMG_1037.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1037.JPG' ALT='IMG_1037.JPG'><BR>IMG_1037.JPG<br>53.39 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1037.JPG' ALT='IMG_1037.JPG'>IMG_1037.JPG</a></div></td>
<td><A ID='IMG_1052.JPG' href='downthecoralcoast.php?fileId=IMG_1052.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1052.JPG' ALT='IMG_1052.JPG'><BR>IMG_1052.JPG<br>61.65 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1052.JPG' ALT='IMG_1052.JPG'>IMG_1052.JPG</a></div></td>
<td><A ID='IMG_1054.JPG' href='downthecoralcoast.php?fileId=IMG_1054.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1054.JPG' ALT='IMG_1054.JPG'><BR>IMG_1054.JPG<br>57.99 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1054.JPG' ALT='IMG_1054.JPG'>IMG_1054.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_1058.JPG' href='downthecoralcoast.php?fileId=IMG_1058.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1058.JPG' ALT='IMG_1058.JPG'><BR>IMG_1058.JPG<br>48.98 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1058.JPG' ALT='IMG_1058.JPG'>IMG_1058.JPG</a></div></td>
<td><A ID='IMG_1075.JPG' href='downthecoralcoast.php?fileId=IMG_1075.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1075.JPG' ALT='IMG_1075.JPG'><BR>IMG_1075.JPG<br>94.51 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1075.JPG' ALT='IMG_1075.JPG'>IMG_1075.JPG</a></div></td>
<td><A ID='IMG_1077.JPG' href='downthecoralcoast.php?fileId=IMG_1077.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1077.JPG' ALT='IMG_1077.JPG'><BR>IMG_1077.JPG<br>121.18 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1077.JPG' ALT='IMG_1077.JPG'>IMG_1077.JPG</a></div></td>
<td><A ID='IMG_1081.JPG' href='downthecoralcoast.php?fileId=IMG_1081.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1081.JPG' ALT='IMG_1081.JPG'><BR>IMG_1081.JPG<br>109.1 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1081.JPG' ALT='IMG_1081.JPG'>IMG_1081.JPG</a></div></td>
<td><A ID='IMG_1089.JPG' href='downthecoralcoast.php?fileId=IMG_1089.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1089.JPG' ALT='IMG_1089.JPG'><BR>IMG_1089.JPG<br>46.97 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1089.JPG' ALT='IMG_1089.JPG'>IMG_1089.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_1094.JPG' href='downthecoralcoast.php?fileId=IMG_1094.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1094.JPG' ALT='IMG_1094.JPG'><BR>IMG_1094.JPG<br>57.8 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1094.JPG' ALT='IMG_1094.JPG'>IMG_1094.JPG</a></div></td>
<td><A ID='IMG_1096.JPG' href='downthecoralcoast.php?fileId=IMG_1096.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1096.JPG' ALT='IMG_1096.JPG'><BR>IMG_1096.JPG<br>79.69 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1096.JPG' ALT='IMG_1096.JPG'>IMG_1096.JPG</a></div></td>
<td><A ID='IMG_1097.JPG' href='downthecoralcoast.php?fileId=IMG_1097.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1097.JPG' ALT='IMG_1097.JPG'><BR>IMG_1097.JPG<br>58.76 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1097.JPG' ALT='IMG_1097.JPG'>IMG_1097.JPG</a></div></td>
<td><A ID='IMG_1098.JPG' href='downthecoralcoast.php?fileId=IMG_1098.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1098.JPG' ALT='IMG_1098.JPG'><BR>IMG_1098.JPG<br>78.53 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1098.JPG' ALT='IMG_1098.JPG'>IMG_1098.JPG</a></div></td>
<td><A ID='IMG_1100.JPG' href='downthecoralcoast.php?fileId=IMG_1100.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1100.JPG' ALT='IMG_1100.JPG'><BR>IMG_1100.JPG<br>64.76 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1100.JPG' ALT='IMG_1100.JPG'>IMG_1100.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_1103.JPG' href='downthecoralcoast.php?fileId=IMG_1103.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1103.JPG' ALT='IMG_1103.JPG'><BR>IMG_1103.JPG<br>70.24 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1103.JPG' ALT='IMG_1103.JPG'>IMG_1103.JPG</a></div></td>
<td><A ID='IMG_1106.JPG' href='downthecoralcoast.php?fileId=IMG_1106.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1106.JPG' ALT='IMG_1106.JPG'><BR>IMG_1106.JPG<br>93.51 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1106.JPG' ALT='IMG_1106.JPG'>IMG_1106.JPG</a></div></td>
<td><A ID='IMG_1107.JPG' href='downthecoralcoast.php?fileId=IMG_1107.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1107.JPG' ALT='IMG_1107.JPG'><BR>IMG_1107.JPG<br>101.19 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1107.JPG' ALT='IMG_1107.JPG'>IMG_1107.JPG</a></div></td>
<td><A ID='IMG_1108.JPG' href='downthecoralcoast.php?fileId=IMG_1108.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1108.JPG' ALT='IMG_1108.JPG'><BR>IMG_1108.JPG<br>57.18 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1108.JPG' ALT='IMG_1108.JPG'>IMG_1108.JPG</a></div></td>
<td><A ID='IMG_1111.JPG' href='downthecoralcoast.php?fileId=IMG_1111.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1111.JPG' ALT='IMG_1111.JPG'><BR>IMG_1111.JPG<br>94.06 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1111.JPG' ALT='IMG_1111.JPG'>IMG_1111.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_1114.JPG' href='downthecoralcoast.php?fileId=IMG_1114.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1114.JPG' ALT='IMG_1114.JPG'><BR>IMG_1114.JPG<br>97.63 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1114.JPG' ALT='IMG_1114.JPG'>IMG_1114.JPG</a></div></td>
<td><A ID='IMG_1116.JPG' href='downthecoralcoast.php?fileId=IMG_1116.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1116.JPG' ALT='IMG_1116.JPG'><BR>IMG_1116.JPG<br>126.62 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1116.JPG' ALT='IMG_1116.JPG'>IMG_1116.JPG</a></div></td>
<td><A ID='IMG_1121.JPG' href='downthecoralcoast.php?fileId=IMG_1121.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1121.JPG' ALT='IMG_1121.JPG'><BR>IMG_1121.JPG<br>115.96 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1121.JPG' ALT='IMG_1121.JPG'>IMG_1121.JPG</a></div></td>
<td><A ID='IMG_1126.JPG' href='downthecoralcoast.php?fileId=IMG_1126.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1126.JPG' ALT='IMG_1126.JPG'><BR>IMG_1126.JPG<br>56.44 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1126.JPG' ALT='IMG_1126.JPG'>IMG_1126.JPG</a></div></td>
<td><A ID='IMG_1130.JPG' href='downthecoralcoast.php?fileId=IMG_1130.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1130.JPG' ALT='IMG_1130.JPG'><BR>IMG_1130.JPG<br>61.07 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1130.JPG' ALT='IMG_1130.JPG'>IMG_1130.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_1132.JPG' href='downthecoralcoast.php?fileId=IMG_1132.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1132.JPG' ALT='IMG_1132.JPG'><BR>IMG_1132.JPG<br>58.7 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1132.JPG' ALT='IMG_1132.JPG'>IMG_1132.JPG</a></div></td>
<td><A ID='IMG_1133.JPG' href='downthecoralcoast.php?fileId=IMG_1133.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1133.JPG' ALT='IMG_1133.JPG'><BR>IMG_1133.JPG<br>66.06 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1133.JPG' ALT='IMG_1133.JPG'>IMG_1133.JPG</a></div></td>
<td><A ID='IMG_1134.JPG' href='downthecoralcoast.php?fileId=IMG_1134.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1134.JPG' ALT='IMG_1134.JPG'><BR>IMG_1134.JPG<br>59.89 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1134.JPG' ALT='IMG_1134.JPG'>IMG_1134.JPG</a></div></td>
<td><A ID='IMG_1135.JPG' href='downthecoralcoast.php?fileId=IMG_1135.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1135.JPG' ALT='IMG_1135.JPG'><BR>IMG_1135.JPG<br>65.11 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1135.JPG' ALT='IMG_1135.JPG'>IMG_1135.JPG</a></div></td>
<td><A ID='IMG_1138.JPG' href='downthecoralcoast.php?fileId=IMG_1138.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1138.JPG' ALT='IMG_1138.JPG'><BR>IMG_1138.JPG<br>81.79 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1138.JPG' ALT='IMG_1138.JPG'>IMG_1138.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_1139.JPG' href='downthecoralcoast.php?fileId=IMG_1139.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1139.JPG' ALT='IMG_1139.JPG'><BR>IMG_1139.JPG<br>71.3 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1139.JPG' ALT='IMG_1139.JPG'>IMG_1139.JPG</a></div></td>
<td><A ID='IMG_1140.JPG' href='downthecoralcoast.php?fileId=IMG_1140.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1140.JPG' ALT='IMG_1140.JPG'><BR>IMG_1140.JPG<br>57.27 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1140.JPG' ALT='IMG_1140.JPG'>IMG_1140.JPG</a></div></td>
<td><A ID='IMG_1144.JPG' href='downthecoralcoast.php?fileId=IMG_1144.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1144.JPG' ALT='IMG_1144.JPG'><BR>IMG_1144.JPG<br>52.8 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1144.JPG' ALT='IMG_1144.JPG'>IMG_1144.JPG</a></div></td>
<td><A ID='IMG_1151.JPG' href='downthecoralcoast.php?fileId=IMG_1151.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1151.JPG' ALT='IMG_1151.JPG'><BR>IMG_1151.JPG<br>62.95 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1151.JPG' ALT='IMG_1151.JPG'>IMG_1151.JPG</a></div></td>
<td><A ID='IMG_1152.JPG' href='downthecoralcoast.php?fileId=IMG_1152.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1152.JPG' ALT='IMG_1152.JPG'><BR>IMG_1152.JPG<br>102.09 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1152.JPG' ALT='IMG_1152.JPG'>IMG_1152.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_1156.JPG' href='downthecoralcoast.php?fileId=IMG_1156.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1156.JPG' ALT='IMG_1156.JPG'><BR>IMG_1156.JPG<br>76.58 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1156.JPG' ALT='IMG_1156.JPG'>IMG_1156.JPG</a></div></td>
<td><A ID='IMG_1164.JPG' href='downthecoralcoast.php?fileId=IMG_1164.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1164.JPG' ALT='IMG_1164.JPG'><BR>IMG_1164.JPG<br>62.6 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1164.JPG' ALT='IMG_1164.JPG'>IMG_1164.JPG</a></div></td>
<td><A ID='IMG_1165.JPG' href='downthecoralcoast.php?fileId=IMG_1165.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1165.JPG' ALT='IMG_1165.JPG'><BR>IMG_1165.JPG<br>51.65 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1165.JPG' ALT='IMG_1165.JPG'>IMG_1165.JPG</a></div></td>
<td><A ID='IMG_1169.JPG' href='downthecoralcoast.php?fileId=IMG_1169.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1169.JPG' ALT='IMG_1169.JPG'><BR>IMG_1169.JPG<br>31.24 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1169.JPG' ALT='IMG_1169.JPG'>IMG_1169.JPG</a></div></td>
<td><A ID='IMG_1170.JPG' href='downthecoralcoast.php?fileId=IMG_1170.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1170.JPG' ALT='IMG_1170.JPG'><BR>IMG_1170.JPG<br>33.63 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1170.JPG' ALT='IMG_1170.JPG'>IMG_1170.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_1171.JPG' href='downthecoralcoast.php?fileId=IMG_1171.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1171.JPG' ALT='IMG_1171.JPG'><BR>IMG_1171.JPG<br>33.06 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1171.JPG' ALT='IMG_1171.JPG'>IMG_1171.JPG</a></div></td>
<td><A ID='IMG_1172.JPG' href='downthecoralcoast.php?fileId=IMG_1172.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1172.JPG' ALT='IMG_1172.JPG'><BR>IMG_1172.JPG<br>57.83 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1172.JPG' ALT='IMG_1172.JPG'>IMG_1172.JPG</a></div></td>
<td><A ID='IMG_1175.JPG' href='downthecoralcoast.php?fileId=IMG_1175.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1175.JPG' ALT='IMG_1175.JPG'><BR>IMG_1175.JPG<br>82.62 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1175.JPG' ALT='IMG_1175.JPG'>IMG_1175.JPG</a></div></td>
<td><A ID='IMG_1177.JPG' href='downthecoralcoast.php?fileId=IMG_1177.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1177.JPG' ALT='IMG_1177.JPG'><BR>IMG_1177.JPG<br>93.86 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1177.JPG' ALT='IMG_1177.JPG'>IMG_1177.JPG</a></div></td>
<td><A ID='IMG_1178.JPG' href='downthecoralcoast.php?fileId=IMG_1178.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1178.JPG' ALT='IMG_1178.JPG'><BR>IMG_1178.JPG<br>97.81 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1178.JPG' ALT='IMG_1178.JPG'>IMG_1178.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_1179.JPG' href='downthecoralcoast.php?fileId=IMG_1179.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1179.JPG' ALT='IMG_1179.JPG'><BR>IMG_1179.JPG<br>86.95 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1179.JPG' ALT='IMG_1179.JPG'>IMG_1179.JPG</a></div></td>
<td><A ID='IMG_1180.JPG' href='downthecoralcoast.php?fileId=IMG_1180.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1180.JPG' ALT='IMG_1180.JPG'><BR>IMG_1180.JPG<br>102.63 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1180.JPG' ALT='IMG_1180.JPG'>IMG_1180.JPG</a></div></td>
<td><A ID='IMG_1181.JPG' href='downthecoralcoast.php?fileId=IMG_1181.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1181.JPG' ALT='IMG_1181.JPG'><BR>IMG_1181.JPG<br>101.56 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1181.JPG' ALT='IMG_1181.JPG'>IMG_1181.JPG</a></div></td>
<td><A ID='IMG_1186.JPG' href='downthecoralcoast.php?fileId=IMG_1186.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1186.JPG' ALT='IMG_1186.JPG'><BR>IMG_1186.JPG<br>100.69 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1186.JPG' ALT='IMG_1186.JPG'>IMG_1186.JPG</a></div></td>
<td><A ID='IMG_1187.JPG' href='downthecoralcoast.php?fileId=IMG_1187.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1187.JPG' ALT='IMG_1187.JPG'><BR>IMG_1187.JPG<br>103.74 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1187.JPG' ALT='IMG_1187.JPG'>IMG_1187.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_1189.JPG' href='downthecoralcoast.php?fileId=IMG_1189.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1189.JPG' ALT='IMG_1189.JPG'><BR>IMG_1189.JPG<br>113.98 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1189.JPG' ALT='IMG_1189.JPG'>IMG_1189.JPG</a></div></td>
<td><A ID='IMG_1191.JPG' href='downthecoralcoast.php?fileId=IMG_1191.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1191.JPG' ALT='IMG_1191.JPG'><BR>IMG_1191.JPG<br>93.34 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1191.JPG' ALT='IMG_1191.JPG'>IMG_1191.JPG</a></div></td>
<td><A ID='IMG_1192.JPG' href='downthecoralcoast.php?fileId=IMG_1192.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1192.JPG' ALT='IMG_1192.JPG'><BR>IMG_1192.JPG<br>112.4 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1192.JPG' ALT='IMG_1192.JPG'>IMG_1192.JPG</a></div></td>
<td><A ID='IMG_1193.JPG' href='downthecoralcoast.php?fileId=IMG_1193.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1193.JPG' ALT='IMG_1193.JPG'><BR>IMG_1193.JPG<br>164.63 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1193.JPG' ALT='IMG_1193.JPG'>IMG_1193.JPG</a></div></td>
<td><A ID='IMG_1195.JPG' href='downthecoralcoast.php?fileId=IMG_1195.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1195.JPG' ALT='IMG_1195.JPG'><BR>IMG_1195.JPG<br>99.81 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1195.JPG' ALT='IMG_1195.JPG'>IMG_1195.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_1196.JPG' href='downthecoralcoast.php?fileId=IMG_1196.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1196.JPG' ALT='IMG_1196.JPG'><BR>IMG_1196.JPG<br>78.58 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1196.JPG' ALT='IMG_1196.JPG'>IMG_1196.JPG</a></div></td>
<td><A ID='IMG_1208.JPG' href='downthecoralcoast.php?fileId=IMG_1208.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1208.JPG' ALT='IMG_1208.JPG'><BR>IMG_1208.JPG<br>104.05 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1208.JPG' ALT='IMG_1208.JPG'>IMG_1208.JPG</a></div></td>
<td><A ID='IMG_1211.JPG' href='downthecoralcoast.php?fileId=IMG_1211.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1211.JPG' ALT='IMG_1211.JPG'><BR>IMG_1211.JPG<br>124.63 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1211.JPG' ALT='IMG_1211.JPG'>IMG_1211.JPG</a></div></td>
<td><A ID='IMG_1222.JPG' href='downthecoralcoast.php?fileId=IMG_1222.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1222.JPG' ALT='IMG_1222.JPG'><BR>IMG_1222.JPG<br>56.89 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1222.JPG' ALT='IMG_1222.JPG'>IMG_1222.JPG</a></div></td>
<td><A ID='IMG_1224.JPG' href='downthecoralcoast.php?fileId=IMG_1224.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1224.JPG' ALT='IMG_1224.JPG'><BR>IMG_1224.JPG<br>116.03 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1224.JPG' ALT='IMG_1224.JPG'>IMG_1224.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_1229.JPG' href='downthecoralcoast.php?fileId=IMG_1229.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1229.JPG' ALT='IMG_1229.JPG'><BR>IMG_1229.JPG<br>72.39 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1229.JPG' ALT='IMG_1229.JPG'>IMG_1229.JPG</a></div></td>
<td><A ID='IMG_1235.JPG' href='downthecoralcoast.php?fileId=IMG_1235.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1235.JPG' ALT='IMG_1235.JPG'><BR>IMG_1235.JPG<br>77.87 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1235.JPG' ALT='IMG_1235.JPG'>IMG_1235.JPG</a></div></td>
<td><A ID='IMG_1237.JPG' href='downthecoralcoast.php?fileId=IMG_1237.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1237.JPG' ALT='IMG_1237.JPG'><BR>IMG_1237.JPG<br>74.91 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1237.JPG' ALT='IMG_1237.JPG'>IMG_1237.JPG</a></div></td>
<td><A ID='IMG_1239.JPG' href='downthecoralcoast.php?fileId=IMG_1239.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1239.JPG' ALT='IMG_1239.JPG'><BR>IMG_1239.JPG<br>73.47 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1239.JPG' ALT='IMG_1239.JPG'>IMG_1239.JPG</a></div></td>
<td><A ID='IMG_1240.JPG' href='downthecoralcoast.php?fileId=IMG_1240.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1240.JPG' ALT='IMG_1240.JPG'><BR>IMG_1240.JPG<br>91.73 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1240.JPG' ALT='IMG_1240.JPG'>IMG_1240.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_1246.JPG' href='downthecoralcoast.php?fileId=IMG_1246.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1246.JPG' ALT='IMG_1246.JPG'><BR>IMG_1246.JPG<br>56.63 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1246.JPG' ALT='IMG_1246.JPG'>IMG_1246.JPG</a></div></td>
<td><A ID='IMG_1247.JPG' href='downthecoralcoast.php?fileId=IMG_1247.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1247.JPG' ALT='IMG_1247.JPG'><BR>IMG_1247.JPG<br>58.25 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1247.JPG' ALT='IMG_1247.JPG'>IMG_1247.JPG</a></div></td>
<td><A ID='IMG_1249.JPG' href='downthecoralcoast.php?fileId=IMG_1249.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1249.JPG' ALT='IMG_1249.JPG'><BR>IMG_1249.JPG<br>67.71 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1249.JPG' ALT='IMG_1249.JPG'>IMG_1249.JPG</a></div></td>
<td><A ID='IMG_1254.JPG' href='downthecoralcoast.php?fileId=IMG_1254.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1254.JPG' ALT='IMG_1254.JPG'><BR>IMG_1254.JPG<br>105.67 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1254.JPG' ALT='IMG_1254.JPG'>IMG_1254.JPG</a></div></td>
<td><A ID='IMG_1256.JPG' href='downthecoralcoast.php?fileId=IMG_1256.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1256.JPG' ALT='IMG_1256.JPG'><BR>IMG_1256.JPG<br>60.79 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1256.JPG' ALT='IMG_1256.JPG'>IMG_1256.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_1257.JPG' href='downthecoralcoast.php?fileId=IMG_1257.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1257.JPG' ALT='IMG_1257.JPG'><BR>IMG_1257.JPG<br>62.56 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1257.JPG' ALT='IMG_1257.JPG'>IMG_1257.JPG</a></div></td>
<td><A ID='IMG_1259.JPG' href='downthecoralcoast.php?fileId=IMG_1259.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1259.JPG' ALT='IMG_1259.JPG'><BR>IMG_1259.JPG<br>71.34 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1259.JPG' ALT='IMG_1259.JPG'>IMG_1259.JPG</a></div></td>
<td><A ID='IMG_1260.JPG' href='downthecoralcoast.php?fileId=IMG_1260.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1260.JPG' ALT='IMG_1260.JPG'><BR>IMG_1260.JPG<br>136.84 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1260.JPG' ALT='IMG_1260.JPG'>IMG_1260.JPG</a></div></td>
<td><A ID='IMG_1261.JPG' href='downthecoralcoast.php?fileId=IMG_1261.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1261.JPG' ALT='IMG_1261.JPG'><BR>IMG_1261.JPG<br>112.74 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1261.JPG' ALT='IMG_1261.JPG'>IMG_1261.JPG</a></div></td>
<td><A ID='IMG_1263.JPG' href='downthecoralcoast.php?fileId=IMG_1263.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1263.JPG' ALT='IMG_1263.JPG'><BR>IMG_1263.JPG<br>72.21 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1263.JPG' ALT='IMG_1263.JPG'>IMG_1263.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_1264.JPG' href='downthecoralcoast.php?fileId=IMG_1264.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1264.JPG' ALT='IMG_1264.JPG'><BR>IMG_1264.JPG<br>68.83 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1264.JPG' ALT='IMG_1264.JPG'>IMG_1264.JPG</a></div></td>
<td><A ID='IMG_1265.JPG' href='downthecoralcoast.php?fileId=IMG_1265.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1265.JPG' ALT='IMG_1265.JPG'><BR>IMG_1265.JPG<br>74.67 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1265.JPG' ALT='IMG_1265.JPG'>IMG_1265.JPG</a></div></td>
<td><A ID='IMG_1271.JPG' href='downthecoralcoast.php?fileId=IMG_1271.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1271.JPG' ALT='IMG_1271.JPG'><BR>IMG_1271.JPG<br>63.38 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1271.JPG' ALT='IMG_1271.JPG'>IMG_1271.JPG</a></div></td>
<td><A ID='IMG_1272.JPG' href='downthecoralcoast.php?fileId=IMG_1272.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1272.JPG' ALT='IMG_1272.JPG'><BR>IMG_1272.JPG<br>67.79 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1272.JPG' ALT='IMG_1272.JPG'>IMG_1272.JPG</a></div></td>
<td><A ID='IMG_1274.JPG' href='downthecoralcoast.php?fileId=IMG_1274.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1274.JPG' ALT='IMG_1274.JPG'><BR>IMG_1274.JPG<br>135.22 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1274.JPG' ALT='IMG_1274.JPG'>IMG_1274.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_1275.JPG' href='downthecoralcoast.php?fileId=IMG_1275.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1275.JPG' ALT='IMG_1275.JPG'><BR>IMG_1275.JPG<br>72.9 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1275.JPG' ALT='IMG_1275.JPG'>IMG_1275.JPG</a></div></td>
<td><A ID='IMG_1277.JPG' href='downthecoralcoast.php?fileId=IMG_1277.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1277.JPG' ALT='IMG_1277.JPG'><BR>IMG_1277.JPG<br>98.69 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1277.JPG' ALT='IMG_1277.JPG'>IMG_1277.JPG</a></div></td>
<td><A ID='IMG_1279.JPG' href='downthecoralcoast.php?fileId=IMG_1279.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1279.JPG' ALT='IMG_1279.JPG'><BR>IMG_1279.JPG<br>77.17 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1279.JPG' ALT='IMG_1279.JPG'>IMG_1279.JPG</a></div></td>
<td><A ID='IMG_1282.JPG' href='downthecoralcoast.php?fileId=IMG_1282.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1282.JPG' ALT='IMG_1282.JPG'><BR>IMG_1282.JPG<br>64.83 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1282.JPG' ALT='IMG_1282.JPG'>IMG_1282.JPG</a></div></td>
<td><A ID='IMG_1284.JPG' href='downthecoralcoast.php?fileId=IMG_1284.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1284.JPG' ALT='IMG_1284.JPG'><BR>IMG_1284.JPG<br>52.21 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1284.JPG' ALT='IMG_1284.JPG'>IMG_1284.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_1291.JPG' href='downthecoralcoast.php?fileId=IMG_1291.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1291.JPG' ALT='IMG_1291.JPG'><BR>IMG_1291.JPG<br>55.18 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1291.JPG' ALT='IMG_1291.JPG'>IMG_1291.JPG</a></div></td>
<td><A ID='IMG_1296.JPG' href='downthecoralcoast.php?fileId=IMG_1296.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1296.JPG' ALT='IMG_1296.JPG'><BR>IMG_1296.JPG<br>114.21 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1296.JPG' ALT='IMG_1296.JPG'>IMG_1296.JPG</a></div></td>
<td><A ID='IMG_1297.JPG' href='downthecoralcoast.php?fileId=IMG_1297.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1297.JPG' ALT='IMG_1297.JPG'><BR>IMG_1297.JPG<br>84.45 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1297.JPG' ALT='IMG_1297.JPG'>IMG_1297.JPG</a></div></td>
<td><A ID='IMG_1299.JPG' href='downthecoralcoast.php?fileId=IMG_1299.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1299.JPG' ALT='IMG_1299.JPG'><BR>IMG_1299.JPG<br>101.93 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1299.JPG' ALT='IMG_1299.JPG'>IMG_1299.JPG</a></div></td>
<td><A ID='IMG_1301.JPG' href='downthecoralcoast.php?fileId=IMG_1301.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1301.JPG' ALT='IMG_1301.JPG'><BR>IMG_1301.JPG<br>137 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1301.JPG' ALT='IMG_1301.JPG'>IMG_1301.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_1303.JPG' href='downthecoralcoast.php?fileId=IMG_1303.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1303.JPG' ALT='IMG_1303.JPG'><BR>IMG_1303.JPG<br>93.66 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1303.JPG' ALT='IMG_1303.JPG'>IMG_1303.JPG</a></div></td>
<td><A ID='IMG_1306.JPG' href='downthecoralcoast.php?fileId=IMG_1306.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1306.JPG' ALT='IMG_1306.JPG'><BR>IMG_1306.JPG<br>78.79 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1306.JPG' ALT='IMG_1306.JPG'>IMG_1306.JPG</a></div></td>
<td><A ID='IMG_1310.JPG' href='downthecoralcoast.php?fileId=IMG_1310.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1310.JPG' ALT='IMG_1310.JPG'><BR>IMG_1310.JPG<br>85.48 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1310.JPG' ALT='IMG_1310.JPG'>IMG_1310.JPG</a></div></td>
<td><A ID='IMG_1311.JPG' href='downthecoralcoast.php?fileId=IMG_1311.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1311.JPG' ALT='IMG_1311.JPG'><BR>IMG_1311.JPG<br>98.02 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1311.JPG' ALT='IMG_1311.JPG'>IMG_1311.JPG</a></div></td>
<td><A ID='IMG_1315.JPG' href='downthecoralcoast.php?fileId=IMG_1315.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1315.JPG' ALT='IMG_1315.JPG'><BR>IMG_1315.JPG<br>94.75 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1315.JPG' ALT='IMG_1315.JPG'>IMG_1315.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_1317.JPG' href='downthecoralcoast.php?fileId=IMG_1317.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1317.JPG' ALT='IMG_1317.JPG'><BR>IMG_1317.JPG<br>59.91 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1317.JPG' ALT='IMG_1317.JPG'>IMG_1317.JPG</a></div></td>
<td><A ID='IMG_1318.JPG' href='downthecoralcoast.php?fileId=IMG_1318.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1318.JPG' ALT='IMG_1318.JPG'><BR>IMG_1318.JPG<br>62.43 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1318.JPG' ALT='IMG_1318.JPG'>IMG_1318.JPG</a></div></td>
<td><A ID='IMG_1321.JPG' href='downthecoralcoast.php?fileId=IMG_1321.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1321.JPG' ALT='IMG_1321.JPG'><BR>IMG_1321.JPG<br>84 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1321.JPG' ALT='IMG_1321.JPG'>IMG_1321.JPG</a></div></td>
<td><A ID='IMG_1324.JPG' href='downthecoralcoast.php?fileId=IMG_1324.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1324.JPG' ALT='IMG_1324.JPG'><BR>IMG_1324.JPG<br>93.34 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1324.JPG' ALT='IMG_1324.JPG'>IMG_1324.JPG</a></div></td>
<td><A ID='IMG_1326.JPG' href='downthecoralcoast.php?fileId=IMG_1326.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1326.JPG' ALT='IMG_1326.JPG'><BR>IMG_1326.JPG<br>111.15 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1326.JPG' ALT='IMG_1326.JPG'>IMG_1326.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_1327.JPG' href='downthecoralcoast.php?fileId=IMG_1327.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1327.JPG' ALT='IMG_1327.JPG'><BR>IMG_1327.JPG<br>90.56 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1327.JPG' ALT='IMG_1327.JPG'>IMG_1327.JPG</a></div></td>
<td><A ID='IMG_1328.JPG' href='downthecoralcoast.php?fileId=IMG_1328.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1328.JPG' ALT='IMG_1328.JPG'><BR>IMG_1328.JPG<br>90.88 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1328.JPG' ALT='IMG_1328.JPG'>IMG_1328.JPG</a></div></td>
<td><A ID='IMG_1333.JPG' href='downthecoralcoast.php?fileId=IMG_1333.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1333.JPG' ALT='IMG_1333.JPG'><BR>IMG_1333.JPG<br>51.54 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1333.JPG' ALT='IMG_1333.JPG'>IMG_1333.JPG</a></div></td>
<td><A ID='IMG_1336.JPG' href='downthecoralcoast.php?fileId=IMG_1336.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1336.JPG' ALT='IMG_1336.JPG'><BR>IMG_1336.JPG<br>96.46 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1336.JPG' ALT='IMG_1336.JPG'>IMG_1336.JPG</a></div></td>
<td><A ID='IMG_1340.JPG' href='downthecoralcoast.php?fileId=IMG_1340.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1340.JPG' ALT='IMG_1340.JPG'><BR>IMG_1340.JPG<br>71.79 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1340.JPG' ALT='IMG_1340.JPG'>IMG_1340.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_1342.JPG' href='downthecoralcoast.php?fileId=IMG_1342.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1342.JPG' ALT='IMG_1342.JPG'><BR>IMG_1342.JPG<br>85.12 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1342.JPG' ALT='IMG_1342.JPG'>IMG_1342.JPG</a></div></td>
<td><A ID='IMG_1343.JPG' href='downthecoralcoast.php?fileId=IMG_1343.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051021/IMG_1343.JPG' ALT='IMG_1343.JPG'><BR>IMG_1343.JPG<br>65.56 KB</a><div class='inv'><br><a href='./images/20051021/IMG_1343.JPG' ALT='IMG_1343.JPG'>IMG_1343.JPG</a></div></td>
</tr>
</table>	</div>
</div>
</body>
</html>