<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - August 2003 - Q&A letters</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="Q&A letters">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="Q&A letters" href='masterit200301.php'>January 2003</a></li>
<li><a title="Q&A letters" href='masterit200302.php'>February 2003</a></li>
<li><a title="Q&A letters" href='masterit200303.php'>March 2003</a></li>
<li><a title="Q&A letters" href='masterit200304.php'>April 2003</a></li>
<li><a title="Q&A letters" href='masterit200305.php'>May 2003</a></li>
<li><a title="Q&A letters" href='masterit200306.php'>June 2003</a></li>
<li><a title="Q&A letters" href='masterit200307.php'>July 2003</a></li>
<li><div class='activemenu'>August 2003</div></li>
<li><a title="Q&A letters" href='masterit200309.php'>September 2003</a></li>
<li><a title="Q&A letters" href='masterit200310.php'>October 2003</a></li>
<li><a title="Q&A letters" href='masterit200311.php'>November 2003</a></li>
<li><a title="Q&A letters" href='masterit200312.php'>December 2003</a></li>
<li> </li><br><li>Or go back to:</li><li><a title='Q&A/MasterIT letters from 2003' href="masterit2003.php">2003 archive</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>August 2003</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Mark's writing' href="written.php">Professional Writing</a> > <a title='My weekly Q&A column in The Australian' href="masterIT.php">MasterIT</a> > <a title='Q&A/MasterIT letters from 2003' href="masterit2003.php">2003 archive</a> > <a title='Q&A letters' href="masterit200308.php">August 2003</a>
<br><br>		<br>
<h2>5/8/03</h2><br>
<b>I have been using a single computer with dial up modem without problems for years. Recently I networked this with another computer in the house with simple peer to peer cabling. Since then my modem dial up keeps activating itself and trying to establish a connection, sometimes even when I am already on the net. I have tried changing the default parameters in XP to no avail. Is there a solution to this problem?</b><br>
<br>
We'll avoid the temptation to simply reply "yes", and leave it at that. ;)<br>
<br>
By changing the default parameters we assume you mean you've shared the dial-up connection and un-ticked the "establish a connection whenever a computer on my network attempts to access the internet" checkbox.<br>
<br>
The next setting to try is in Network Connections (from the Start menu). Open up the advanced menu and select "dial-up preferences", and make sure that autodial is not enabled.<br>
<br>
You may also have a virus lurking on the network somewhere - make sure you're running up to date anti-virus software on both machines and give them both a full scan.<br>
<br>
<br>
<b>My problem arises from Scanner use - I want to edit & update manuscripts I did in the past with an IBM and a Brother dot matrix printer. Now I want to put all my work in the same font, but my scanner OCR software will not recognise the dot matrix fonts. Can you suggest a way to enlarge the font range which the OCR will recognise?</b><br>
<br>
Some OCR software can be trained for new fonts, however dot matrix printouts are notoriously hard to convert. OCR software also comes in all shapes and sizes, and chances are the package that came with your scanner isn't terribly advanced.<br>
<br>
Some names to chase up are Finereader, Omnipage and Textbridge - they're all commercial unfortunately, but Finereader (<a href="http://www.abbyy.com" target="_blank">www.abbyy.com</a>) has a trial version available, and is considered by some to be the pick of the crop for reading difficult text (like dot matrix output).<br>
<br>
You may also find that you can improve the OCR performance by using a separate program to manipulate the scanned pages into something more readable. Once such package is available at <a href="http://www.tmsinc.com/downloads.html" target="_blank">www.tmsinc.com/downloads.html</a>.<br>
<br>
<br>
<h2>12/8/03</h2><br>
<b>About 6 months ago I created a simple web site of 5 pages, and uploaded it to the internet. However, I find that the site does not show up when I use the common search engines available on the web. Can you please advise any simple measures by which I can improve the site's visibility? I understand it used to be possible to insert some keywords into the HTML source listing, into one of the tags.<br>
<br>
Also, can you suggest any reference sites on the web for simple web development techniques?</b><br>
<br>
It is indeed possible to insert keywords into your code, and this may well improve the way search engines index your site, but the first thing to do is to make sure the search engines actually know your site is there to index.<br>
<br>
If your page isn't linked to from any other public page, and you don't have a domain of your own, chances are none of the search engines have known they needed to look in the first place.<br>
<br>
If this is the case, you'll need to manually submit your site to the search engines. They all have a page with information to help you do this (Google's is <a href="http://www.google.com/webmasters" target="_blank">www.google.com/webmasters</a>).<br>
<br>
Once you're in the queue to be indexed, the next step is to make sure you have good meta information embedded in your pages. This is done using the aforementioned special tags. They're not normally visible to users, but help the search engines categorise your page.<br>
<br>
The most common ones are for keywords and page descriptions respectively.<br>
<br>
The former should contain a list of keywords that apply to your site. In days gone by it was popular to try and improve search engine ranks by adding all sorts of irrelevant keywords.<br>
<br>
These days search engines are cleverer than they used to be and will correlate your keywords with your page's actual content. If there aren't enough matches, your page probably won't get indexed, and repeat offenders may even be blacklisted.<br>
<br>
This is just the tip of the iceberg though; check out <a href="http://www.searchengines.com" target="_blank">www.searchengines.com</a> for a load of information on search engine technologies.<br>
<br>
For web building in general, an excellent resource is <a href="http://www.webmonkey.com" target="_blank">www.webmonkey.com</a> - it has information for all levels of expertise.<br>
<br>
<br>
<h2>19/8/03</h2><br>
<b>I have recently had a major reboot with my computer and as a result lost all my favourites on IE 6.1. Fortunately all my files were backed up - is there a way that I can restore favourites? I have Windows 98SE as my operating system.</b><br>
<br>
Luckily, this is fairly easy. First, you have to find your existing favourites folder. On Win98 it will most likely be in windowsfavorites (note the Yank spelling).<br>
<br>
Then all you need to do is restore your backed up copy of this folder over what's there.<br>
<br>
<br>
<b>Why is spam such a difficult problem to solve? Can you answer the specific question of why it is difficult for the IT industry to devise a program that will reject incoming mail, or send it to a junk mail folder, if the sender is not included in one's own contact list?</b><br>
<br>
Spammers are in that select group of humanity that includes lawyers, politicians, real estate agents & used car salespeople. But unlike members of those groups, there aren't actually any decent spammers in the real world.<br>
<br>
The problem of spam is an ongoing battle; messages which make it to your mailbox are actually only a tiny fraction of what gets sent daily. We're talking billions of messages a day globally.<br>
<br>
It's an arms race; anti-spam filters get a little more effective, spammers find a way past them, and the cycle continues.<br>
<br>
The concept of only allowing messages from people on your contact list (or on a so-called "whitelist") is an old one. Hotmail's "exclusive" option of junk mail filtering does exactly this. There are also various third party solutions available, such as Mailwasher (<a href="http://www.mailwasher.net" target="_blank">www.mailwasher.net</a>).<br>
<br>
Another good solution to the problem is to use a special mail filter called a Bayesian filter. This works by using a statistical approach to words contained in your real email versus words almost never contained in anything but spam.<br>
<br>
The downside to this is that you need to train the filter; the upside is that it is by nature tailored to your own emails, so it's quite hard to defeat.<br>
<br>
Mozilla has this feature built in, and many plug-ins for Outlook are available.<br>
<br>
There is also an in depth article on the problem in general at <a href="http://www.paulgraham.com/spam.html" target="_blank">www.paulgraham.com/spam.html</a>.<br>
<br>
Send queries and the severed heads of spammers to <a href="contact.php">(the masterit contact email address)</a><br>
<br>
<br>
<h2>26/8/03</h2><br>
<b>On one of my computers running Windows 98 I suspect during an Internet session someone has inserted their 'dial up' connection. When I go into the Control Panel's Internet Properties and click on Connections I see another setting inserted under my Default Connection.<br>
<br>
Highlighting this new connection (XXXDIAL) and checking the Dial-up Settings I notice asterisks for a Password and a User Name (zxmhq) inserted. Under Properties there is a phone number (5551212). If this was done surreptitiously I believe this is called 'bundling'.<br>
<br>
If I am right and this is traceable is there a law to have them prosecuted for deflecting trade from my ISP?</b><br>
<br>
What you've got is a borderline virus. There are some programs that do things like this in order to make people unwittingly dial an expensive timed number rather than their normal ISP's.<br>
<br>
On the plus side, these are less likely to work from Australia, but on the minus side if they do happen to get through (usually to another continent) you're in a very smelly creek without a paddle, in the proverbial barbed wire canoe.<br>
<br>
Make sure you've got good (up to date) anti-virus software running, as this sort of thing should be picked up by it.<br>
<br>
It's also a good idea to be careful what you download, and from where. Remember that without a scanner it's possible to get a virus without even downloading anything. All it can take is to view the wrong page. <br>
<br>
In your case it's not really going to be possible to chase it up, but it does raise a good point about software being installed on the sly.<br>
<br>
Some programs will install (or offer to install) extras, ostensibly to improve your internet experience (or some other such balderdash), but in reality they are little spy programs that monitor your browsing habits and send the data back to a central database so that ads can be popped up on your screen.<br>
<br>
Often such Spyware programs go under cute guises, such as Bonzi Buddy, Comet Cursor and Gator.<br>
<br>
Luckily it's possible to get rid of them fairly easily. Probably the best program for doing this is Ad-aware, available for free from <a href="http://www.lavasoft.de" target="_blank">www.lavasoft.de</a>. <br>
<br>
Send queries and the severed testicles of virus authors to <a href="contact.php">(the masterit contact email address)</a><br>
<br>
<i><p>Did the information on this page help you? Entertain you? Bore you? <a href="contact.php?subject=MasterIT">Drop me a line</a>.</p>

<p>If you're feeling particularly generous, you can even <a href="buypics.php">click here to send me some dot-com riches</a>. Think of it as online busking.</i></p>
	</div>
</div>
</body>
</html>