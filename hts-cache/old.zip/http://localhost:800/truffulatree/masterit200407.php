<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - July 2004 - Q&A letters</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="Q&A letters">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="Q&A letters" href='masterit200401.php'>January 2004</a></li>
<li><a title="Q&A letters" href='masterit200402.php'>February 2004</a></li>
<li><a title="Q&A letters" href='masterit200403.php'>March 2004</a></li>
<li><a title="Q&A letters" href='masterit200404.php'>April 2004</a></li>
<li><a title="Q&A letters" href='masterit200405.php'>May 2004</a></li>
<li><a title="Q&A letters" href='masterit200406.php'>June 2004</a></li>
<li><div class='activemenu'>July 2004</div></li>
<li><a title="Q&A letters" href='masterit200408.php'>August 2004</a></li>
<li><a title="Q&A letters" href='masterit200409.php'>September 2004</a></li>
<li><a title="Q&A letters" href='masterit200410.php'>October 2004</a></li>
<li><a title="Q&A letters" href='masterit200411.php'>November 2004</a></li>
<li><a title="Q&A letters" href='masterit200412.php'>December 2004</a></li>
<li> </li><br><li>Or go back to:</li><li><a title='Q&A/MasterIT letters from 2004' href="masterit2004.php">2004 archive</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>July 2004</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Mark's writing' href="written.php">Professional Writing</a> > <a title='My weekly Q&A column in The Australian' href="masterIT.php">MasterIT</a> > <a title='Q&A/MasterIT letters from 2004' href="masterit2004.php">2004 archive</a> > <a title='Q&A letters' href="masterit200407.php">July 2004</a>
<br><br>		<br>
<h2>6/7/04</h2><br>
<b>I have just tried to uninstall some of the programs that I don't use anymore. When I go into the Add or Remove folder in Windows XP I have found well over twenty new 'programs'. That have no size or date used and they all are named like the following: FBBPEPNL or JXXLBGHH, when I go to uninstall them, a box pops up that asks me to type the name of the program to uninstall it. What are these, and can I uninstall them more easily than one at a time?</b><br>
<br>
I'm not actually sure where these come from; they sound like corrupt entires in the registry (which Windows uses to keep track of what appears in Add/Remove). They're probably not malevolent, but an up to date virus scan of your system probably wouldn't hurt.<br>
<br>
You can get rid of the entries easily enough; plenty of third party apps exist to help with this sort of thing. One such app is TweakXP (www.totalidea.com), which lets you tweak a whole heap of useful stuff.<br>
<br>
<br>
<b>When I try to start Internet Explorer I get a message saying it has encountered a problem and needs to close down. We are sorry for the Inconvenience. At other times it gives me the following message "Explorer has performed an illegal operation and will be closed". I have asked a few of my friends about this and they have told me that I need to install Windows 98 again (I have windows 98) on my computer and that will solve the problem. I have tried that but it still gives the above two messages.</b><br>
<br>
Your friends are right to suggest a reinstall of 98 - it's not the most stable of operating systems and unfortunately it can "go bad" after a while. It's odd though that a reinstall doesn't fix the problem.<br>
<br>
If you're not yet using version 6 of IE you should upgrade. It can be found on Microsoft's website at tinyurl.com/3drq. You can find out what version you have by clicking Help->about, although of course that may be challenging if it's crashing all the time.<br>
<br>
If that doesn't help (or you just feel like a change), you might like to try Mozilla/Firefox as a browser. You can find it at mozilla.org.<br>
<br>
<br>
<h2>13/7/04</h2><br>
<b>Dear Master, recently I noticed a new file in the root of my C: drive called "boot.ini". Can I delete it? It's bugging me!</b><br>
<br>
It seems that there are two types of people in the computing world - those who have clean minimalist desktops, and those who have about 300 assorted icons on them (can you guess which camp I'm in?)<br>
<br>
Before we degenerate into an order versus chaos debate (which is only marginally more meaningful than the my-operating-system-is-better-than-yours fracas), I'd recommend against deleting boot.ini, as doing so will stop your system from, well, booting, as the file contains a list of startup partitions. It's normally hidden, but occasionally it de-cloaks, simply to bug people like us.<br>
<br>
Open up a command prompt (Start->Programs->Accessories) and type "attrib +SH boot.ini". This should fix the problem by setting the System and Hidden flags on the file. It'll still be there, but Windows will now hide it from you.<br>
<br>
<br>
<b>I am having problems with my IE home page, as I now have an "about blank" that has attached itself as the home page which is appears to be a page for searching the net. I have often gone into IE properties and deleted cookies, temp files, history, and changed the homepage to my ISP's. I've also gone into Program files, Internet explorer and deleted the application, which disappears for a few seconds then reappears! I run Spybot regularly and Norton Antivirus to no avail. I have no doubt I have a virus but can't find it. Any suggestions?</b><br>
<br>
About:blank shouldn't be hitting the Internet for anything - it's just a placeholder, so you may very well have a virus.<br>
<br>
The question of what's happening is somewhat difficult to explain though, given that you've got anti-virus and anti-spyware solutions running.<br>
<br>
Some viruses, however, are capable of disabling anti-virus software - perhaps running a standalone AV program like Stinger (vil.nai.com/vil/stinger) is a good idea. You can also try a different anti-spyware package if you like, Lavasoft Ad-aware (lavasoft.de) is a good one.<br>
<br>
The re-appearing Internet Explorer is fairly easy to explain. It's being brought back to life by Windows itself, which has a feature that maintains vital files in the event of their modification.<br>
<br>
<br>
<h2>20/7/04</h2><br>
<b>Further to your article in the Australian newspaper July 6, I have installed Firefox and am happy with it. Can you advise how I can add shortcuts to specific WebPages using Firefox on my desktop. I use Windows 2000 Professional.</b><br>
<br>
Yay, a convert! You should be able to simply drag and drop items from your Bookmarks menu to the desktop. You'll also probably want to set Firefox to be your default browser by going to Tools->Options->General, and selecting "Set Firefox As Default Browser".<br>
<br>
<br>
<b>I had a system powered by Windows 95 for several years, and this year bought a new set-up which has Windows XP. My old files are all designated wps, and were created with Microsoft Works. I backed up onto floppy discs, but I have been unable to transfer them to my new hard drive as XP is unable to read them. Is there any way this transfer can be accomplished? I would appreciate any help you can give.</b><br>
<br>
The problem here is that MS Works is a fairly old application, and it's not directly supported by Windows. Microsoft Word took over from it a while ago, and Word's .doc files are much more universally readable, even if you don't have Word itself installed.<br>
<br>
Newer versions of Word should be able to load the .wps files directly - your best bet is to open them and then use Save As to convert them to .doc files.<br>
<br>
If you have an earlier version of Office that doesn't support the files directly, Microsoft has a converter available which you can download from office.microsoft.com/downloads/2002/wp6rtf.aspx<br>
<br>
If you don't have Word at all, your only option is to re-save the originals in Works as .doc files.<br>
<br>
<br>
<b>More on the mystery About:blank home page hijacking:</b><br>
<br>
One fellow writes: "A customer had the same problem. Tried all the usual things, but no luck until I searched the registry. Found a Quicktime startup in HKEY_LOCAL_MACHINE.../.../.../Run. Deleted it and then IE homepage was O.K. <br>
Maybe registry entry was from a previous installation of Quicktime, or spyware had inserted something masquerading as a Quicktime component."<br>
<br>
Another reader mentions that IE can try to hit an About:blank page after being moved from one network to another (as often happens with wireless networks), as it sometimes still retains old network settings. Resetting the network can help in this case.<br>
<br>
<br>
<h2>27/7/04</h2><br>
<b>I currently use Telstra broadband cable for Internet. I can connect the modem to my computer via USB port or Ethernet port. Is there any advantage of one over the other?</b><br>
<br>
If you're using Windows, and the modem works without trouble, not really.<br>
<br>
Ethernet is more universally supported, but provided the modem manufacturer has written a stable driver, you should be fine with USB.<br>
<br>
If you want to hook the modem up via Linux, or an older flavour of Windows, you might run into driver troubles using the USB port, and if you want to hook up to a dedicated router you'll definitely need to use Ethernet.<br>
<br>
<br>
<b>My contract with Telstra is about to expire. I have been told that ADSL is more reliable and offers faster download speeds than cable. Can you comment?</b><br>
<br>
I can't really comment on the reliability of cable as I've never had it, but anecdotally it's supposed to be quite reasonable. ADSL though is certainly very reliable (provided you choose a half decent ISP), more universally available, and it's far less proprietary.<br>
<br>
Speed-wise, cable is actually much faster than DSL on paper, but the speed varies depending on how many people in your neighbourhood "cluster" are using the connection. Cable connections are shared amongst groups of users - several houses on a given street for example - and you can only get full speed if you're the only one using the connection at a given time, and that often means 3am.<br>
<br>
DSL on the other hand gives you full speed in a dedicated connection all to yourself all the time, direct to the exchange, but even the maximum available DSL download speed is less than that of cable.<br>
<br>
Don't get me wrong though - a 1.5Mbps ADSL connection is still most satisfactorily fast (although I wouldn't be a true geek without advocating free 30Mbps fibre connections to everyone's door).<br>
<br>
Probably the main advantage of ADSL is that you don't have to go with either Telstra or Optus, meaning you can actually get a pretty good deal if you shop around. Have a look at broadbandchoice.com.au, and follow the Plan Search link.<br>
<br>
Send queries and free T3 connection offers to <a href="contact.php?subject=MasterIT">(the masterit contact email address)</a><br>
<br>
<i><p>Did the information on this page help you? Entertain you? Bore you? <a href="contact.php?subject=MasterIT">Drop me a line</a>.</p>

<p>If you're feeling particularly generous, you can even <a href="buypics.php">click here to send me some dot-com riches</a>. Think of it as online busking.</i></p>
	</div>
</div>
</body>
</html>