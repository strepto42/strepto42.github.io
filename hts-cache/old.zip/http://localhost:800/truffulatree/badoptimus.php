<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - Bad Optimus - A page dedicated to the worst Optimus Prime outfits on the net</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="A page dedicated to the worst Optimus Prime outfits on the net">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><div class='activemenu'>Bad Optimus</div></li>
<li><a title="WD40 cans going whoosh and Sparkler Bomb videos" href='wd40.php'>WD40</a></li>
<li><a title="2weeks.com internet art concept site" href='2weeks.php'>2weeks.com</a></li>
<li><a title="A pong game featuring Rudi Mueller's head by John Hawkins" href='rudipong.php'>Rudipong</a></li>
<li><a title="The Random Domain Name Game" href='rdng.php'>RDNG</a></li>
<li><a title="Various animations for download" href='anims.php'>Animations</a></li>
<li><a title="Arnold Schwarzenegger and Michael Jackson soundboards" href='soundboards.php'>Soundboards</a></li>
<li> </li><br><li>Or go back to:</li><li><a title='Silly things for your amusement' href="silliness.php">Silliness</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>Bad Optimus</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Silly things for your amusement' href="silliness.php">Silliness</a> > <a title='A page dedicated to the worst Optimus Prime outfits on the net' href="badoptimus.php">Bad Optimus</a>
<br><br>		
<p>This is a page dedicated to the most atrocious Optimus Prime outfits that Google Image Search can find.</p>
<p>It's quite simple really.</p>
<p><img src="images/optimus/Optimus_Prime.png" width="250" height="243" align="middle">This is Optimus Prime.</p>
<p><img src="images/optimus/optimus_kids.gif" width="200" height="243" align="middle">This... Is not.</p>
<p>It's not that I'm putting down the individuals here - it's obvious that a lot 
	of work and love has gone into the creation of these costumes. I'm sure I couldn't whip up 
	anything as good (well, except maybe for Shithouse Ninja Optimus). It's just 
	that, in part, I'm questioning the rationale of doing it in the first place, and being a cranky old bastard at the same time.<br>
	<br>
	Thanks go to Alan for supplying a couple of awesome new Optimii - if you have 
	a new Optimus to contribute, <a href="contact.php">email me</a>.<br>
	<br>
	P.S. - an update: Thanks to all the various folks who have sent in Optimii. I had no idea there were so many out there, but I suppose
	I should have guessed, given the nature of the Internet. Anyway I've been really <s>lazy</s> busy and haven't loaded them up yet.
	But I promise I will. I will also be loading some decent pictures of the <a href="images/optimus/uberoppie1.jpg">UBER</a> 
	<a href="images/optimus/uberoppie2.jpg">OPTIMUS</a> that <a href="http://www.dansdata.com" target="_blank">Daniel</a> very kindly gave me.<br>
	<br>
	P.P.S. - another update: <a href="http://www.digi-comic.com/index.php?comicId=79" target="_blank">One good pisstake deserves another, and my mate Nathan has done just that</a>. Not that I mind - being a character in a webcomic is cool!<br>
	<br>
	P.P.P.S. - I'm pleased to report that this page is now the number one Google hit for "Optumus Prime Costume". I promise to put up the Bad Optimus II Page soon!<br>
	<br>
	P.P.P.P.S. - So, who thinks the Transformers movie is going to suck? My money's on not enough robot destruction and waaay to much human crap. We'll see, hey.<br>
	<br>
	Anyway, on with the freakshow.</p>
<hr>
<table border=0>
<tr><th colspan=2 align=left>Sumo Optimus</th></tr>
<tr>
	<td><img src="images/optimus/optimus2.jpg" width="379" height="569" align="left"></td>
	<td valign=top class="optimus">This is the sort of thing I'm talking about. Some effort has been gone to - but the execution is 
	really quite terrible. He doesn't even have exhaust pipes - even the kid's 
	drawing above has THOSE. The helmet is nicely shaped, but the eye area lets 
	it down, and I'm not sure what those orange spots on his shoulders are, but 
	I think his parrot has been drinking too much prune juice. I'd mention 
	the groinal area too, but it speaks for itself, and there's worse to come in that department.<br>
	<br>
	The overall effect is that of something you'd normally punch, or inflate with 
	air and jump on. I suppose I should assign a point for sheer solidity.<br>
	<br>
	Overall rating:<br>
	<img src="images/optimus/autobot_logo.jpeg" width="60" height="60"><img src="images/optimus/autobot_logo.jpeg" width="60" height="60"><img src="images/optimus/autobot_logo.jpeg" width="60" height="60"></td>
</tr>
</table>
<hr>
<table border=0>
<tr><th colspan=2 align=left>Sexy Bighead Optimus</th></tr>
<tr>
	<td><img src="images/optimus/optimus_awful.jpg" width="252" height="508" align="left"></td>
	<td valign="top" class="optimus">This shambles at least has exhaust pipes. But that's where it's saving graces end 
	really; the head is a trifle large. Apparently this Optimus suffers from an 
	inflated ego.<br>
	<br>
	He also appears to be wearing a miniskirt, which suits his feminine legs and figure. 
	The elbow joints also look a trifle restrictive. I mean, come on, how's he 
	supposed to fight Megatron if he can't even give someone the forks convincingly.<br>
	<br>
	Overall Rating:<br>
	<img src="images/optimus/autobot_logo.jpeg" width="60" height="60"><img src="images/optimus/autobot_logo.jpeg" width="60" height="60"></td>
</tr>
</table>
<hr>
<table border=0>
<tr><th colspan=2 align=left>Latino Optimus</th></tr>
<tr>
	<td><img src="images/optimus/optimus_in_the_beginings_03.jpg" width="520" height="423"></td>
	<td valign=top class="optimus">These next two images form a set. I'm not sure why, but the guy in the Optimus suit 
	reminds me of my cousin, Franz. Eventually Franz will find this page, so let's 
	hope he doesn't kick my arse next time he sees me (which - despite my own Taekwondo 
	endeavours - he would have no trouble doing, having done about 20 years more 
	martial arts training than I have).<br>
	<br>
	Anyway I digress. These costumes are actually quite good. Nice detail, real 
	movable arm joints, actual guns and logos. In fact, I only have three criticisms; 
	1) leave the masks ON guys, 2) Optimus has no wheels, and 3) Megatron is missing 
	his all-important penis-trigger.<br>
	<br>
	Overall Rating:<br>
	<img src="images/optimus/autobot_logo.jpeg" width="60" height="60"><img src="images/optimus/autobot_logo.jpeg" width="60" height="60"><img src="images/optimus/autobot_logo.jpeg" width="60" height="60"><img src="images/optimus/autobot_logo.jpeg" width="60" height="60"></td>
</tr>
<tr><td><img src="images/optimus/optimus_both02.jpg" width="520" height="423"></td></tr>
</table>
<hr>
<table border=0>
<tr><th colspan=2 align=left>Bargearse Optimus</th></tr>
<tr>
	<td><img src="images/optimus/Optimus_Dcp02584.jpg" width="160" height="286"></td>
	<td valign=top class="optimus"><p>At first, I thought these two were separate Optimuses (Optimii?). 
				Then, as I compared the two images, I realised that disturbing 
				truth that they were one and the same. Sure, the costumes are 
				similar, but that gut is unmistakable.<br>
				<br>
				I'm not sure which is the more disturbing image, the first one, 
				with it's sleazy sideways glance and Alfoil-wrapped legs, or the 
				second one with... no mask. You be the judge.</p>
			<p>(Oh, don't forget the silver spray painted toy machine gun either. 
				Very authentic).<br>
				<br>
				Overall rating:<br>
				<img src="images/optimus/autobot_logo.jpeg" width="60" height="60"> 
				<img src="images/optimus/autobot_logo.jpeg" width="60" height="60"> 
				<img src="images/optimus/autobot_logo.jpeg" width="60" height="60"> 
			</p></td>
</tr>
<tr><td><img src="images/optimus/optimus_mingerweek039.jpg" width="174" height="200"></td></tr>
</table>
<hr>
<table border=0>
<tr><th colspan=2 align=left>Rasta Optimus</th></tr>
<tr>
	<td><img src="images/optimus/optimus_smoking.jpg" width="450" height="300"></td>
	    <td valign=top class="optimus">This Optimus knows how to party. He may be missing his 
			exhaust pipes, but that doesn't stop him toking on another sort.<br>
			<br>
			His woman is standing by faithfully. Not sure what her story is, but 
			she could do with a little less foundation. Maybe Optimus likes her 
			that way.<br>
			<br>
			This Optimus digs peace, but don't take his stash, you'll regret it.<br>
			<br>
			Overall rating:<br>
			<img src="images/optimus/autobot_logo.jpeg" width="60" height="60"> 
			<img src="images/optimus/autobot_logo.jpeg" width="60" height="60"> 
			<img src="images/optimus/autobot_logo.jpeg" width="60" height="60"> 
			<img src="images/optimus/autobot_logo.jpeg" width="60" height="60"> 
		</td>
</tr>
</table>
<hr>
<table border=0>
<tr><th colspan=2 align=left>Don't-Fuck-With-Me Optimus</th></tr>
<tr>
	<td><img src="images/optimus/optimus_m5718.jpg" width="640" height="480"></td>
	    <td valign=top class="optimus"><p>This picture tells a story. The balding guy on the right 
				has made a big mistake - he's touching Optimus's nether region. 
				This is not the sort of Optimus you want to do that to. He'll 
				rip off your head and lay some robot cable down your neck.<br>
				<br>
				The security guys on the left can see what's coming - but they're 
				at a loss as to what to do. These guys aren't idiots. Optimus 
				will Kick Their Scrawny Arses if they try anything.<br>
				<br>
				I'm giving this Optimus a rating of 5, lest he kicks MY arse.<br>
				<br>
				Overall rating:<br>
				<img src="images/optimus/autobot_logo.jpeg" width="60" height="60"> 
				<img src="images/optimus/autobot_logo.jpeg" width="60" height="60"> 
				<img src="images/optimus/autobot_logo.jpeg" width="60" height="60"> 
				<img src="images/optimus/autobot_logo.jpeg" width="60" height="60"> 
				<img src="images/optimus/autobot_logo.jpeg" width="60" height="60"> 
			</p>
			</td>
</tr>
</table>
<hr>
<table border=0>
<tr><th colspan=2 align=left>Too-drunk-to-fuck Optimus</th></tr>
<tr>
	<td><img src="images/optimus/optimuscostume.gif"></td>
	    <td valign=top class="optimus"><p>This Optimus is awesome. Not only is he the only Optimus 
				so far to acually have WHEELS, the detailing is supurb. This is 
				what an Optimus costume SHOULD look like!<br>
				<br>
				He also rocks cos he's quite clearly pissed as a fart. Perhaps 
				he's being helped on his unsteady way to the bathroom, or perhaps 
				he's being restrained after taking a disliking to the way that 
				the guy in the Bumblebee costume looked at him.<br>
				<br>
				Either way he is fantastic.<br>
				<br>
				Overall rating:<br>
				<img src="images/optimus/autobot_logo.jpeg" width="60" height="60"> 
				<img src="images/optimus/autobot_logo.jpeg" width="60" height="60"> 
				<img src="images/optimus/autobot_logo.jpeg" width="60" height="60"> 
				<img src="images/optimus/autobot_logo.jpeg" width="60" height="60"> 
				<img src="images/optimus/autobot_logo.jpeg" width="60" height="60"> 
				<img src="images/optimus/autobot_logo.jpeg" width="60" height="60"> 
			</p>
			</td>
</tr>
</table>
<hr>
<table border=0>
<tr><th colspan=2 align=left>Something-feels-damp Optimus</th></tr>
<tr>
	<td><img src="images/optimus/optimus-prime_legpiss.jpg"></td>
	    <td valign=top class="optimus">Sometimes it sucks to be Optimus. Not only do you have 
			to battle Megatron and the various forces of evil, you also have to 
			go to nerd conventions.<br>
			<br>
			Convention Nerds are bad enough when they're behaving, but they're even 
			worse when they decide to piss on your leg.<br>
			<br>
			Who knows why this guy taking a slash on Oppie's leg, perhaps the 
			guy is a staunch Decepticon supporter. Whatever the case, he's about 
			to get backhanded into next year when Optimus realises what the warm 
			wet sensation is on his foot.<br>
			<br>
			(Pretty good costume too, but could do with a bit more detailing).<br>
			<br>
			Update: As various people have pointed out, Something-feels-damp Optimus is one and the same as 
			Don't-fuck-with-me Optimus. I choose to keep them separate, and give them different ratings, just to be a 
			contrary inconsistent bastard.<br>
			<br>
		Overall rating:<br>
		<img src="images/optimus/autobot_logo.jpeg" width="60" height="60"> 
		<img src="images/optimus/autobot_logo.jpeg" width="60" height="60"> 
		<img src="images/optimus/autobot_logo.jpeg" width="60" height="60"> 
		<img src="images/optimus/autobot_logo.jpeg" width="60" height="60"> 
	</td>
</tr>
</table>
<hr>
<table border=0>
<tr><th colspan=2 align=left>Shithouse Ninja Optimus</th></tr>
<tr>
	<td><img src="images/optimus/Optimus-worstPrimeOutfitEver.jpg" width="243" height="450"></td>
	    <td valign=top class="optimus">And lastly, we have this. As the Comic Book Guy from the Simpsons 
			would say, "worst Optimus ever".<br>
			<br>
			I'm not even gonna start on this one. Nothing I write here will be 
			as funny as just looking at the picture. It speaks for itself. The 
			fellow inside this might well be glad his face is covered, but I salute him. He's brought a lot of joy to visitors
			of this page. :)<br>
			<br>
			In fact, I would almost say he's the best Optimus ever!<br>
			<br>
		Overall rating:<br>
		<img src="images/optimus/autobot_logo.jpeg" width="60" height="60"> 
	</td>
</tr>
</table>
<p>So, did you smile? Should an ad appear appropriate to your needs... feel free to investigate. You might want to look around my site too, before you go. <a href="nerdseyeview.php">Click here</a> to read about my epic trip around Australia. Click <a href="pictures.php">here</a> for various other picture galleries.</p>
<p>If you're feeling particularly generous, you can even click on the button below to send me some dot-com riches. Go on, I bet you a dollar that the Transformers movie will be really pretty, but overall it will suck.</p>
<a href="buypics.php"><img src="images/paypal_giveusthem.gif" alt="Give me the cashhhhhh!" title="Give me the cashhhhhh!" border="0"></a>

	</div>
</div>
</body>
</html>