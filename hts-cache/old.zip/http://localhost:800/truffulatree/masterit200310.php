<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - October 2003 - Q&A letters</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="Q&A letters">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="Q&A letters" href='masterit200301.php'>January 2003</a></li>
<li><a title="Q&A letters" href='masterit200302.php'>February 2003</a></li>
<li><a title="Q&A letters" href='masterit200303.php'>March 2003</a></li>
<li><a title="Q&A letters" href='masterit200304.php'>April 2003</a></li>
<li><a title="Q&A letters" href='masterit200305.php'>May 2003</a></li>
<li><a title="Q&A letters" href='masterit200306.php'>June 2003</a></li>
<li><a title="Q&A letters" href='masterit200307.php'>July 2003</a></li>
<li><a title="Q&A letters" href='masterit200308.php'>August 2003</a></li>
<li><a title="Q&A letters" href='masterit200309.php'>September 2003</a></li>
<li><div class='activemenu'>October 2003</div></li>
<li><a title="Q&A letters" href='masterit200311.php'>November 2003</a></li>
<li><a title="Q&A letters" href='masterit200312.php'>December 2003</a></li>
<li> </li><br><li>Or go back to:</li><li><a title='Q&A/MasterIT letters from 2003' href="masterit2003.php">2003 archive</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>October 2003</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Mark's writing' href="written.php">Professional Writing</a> > <a title='My weekly Q&A column in The Australian' href="masterIT.php">MasterIT</a> > <a title='Q&A/MasterIT letters from 2003' href="masterit2003.php">2003 archive</a> > <a title='Q&A letters' href="masterit200310.php">October 2003</a>
<br><br>		<br>
<h2>7/10/03</h2><br>
<b>I am unable to hold voice conversations on the internet with MSN Messenger (I was able to before). The message I get is - The Com Port is not open. I am also unable to receive any faxes and voice messages on my computer. I can however still connect to the internet with my modem.<br>
<br>
Moreover I am unable to record my voice on the voice recorder, however, I can still hear CDs on the computer.</b><br>
<br>
The strange combination of symptoms suggests that your copy of Windows has gotten confused about which audio drivers and modem are installed.<br>
<br>
Some modems can appear as sound devices to Windows - it's possible your system has decided to use one of these drivers for audio instead of the sound card itself. You'll still be able to listen to CD playback as the audio for this goes directly to the sound card, and not through software.<br>
<br>
Check your Multimedia settings in the Control Panel, in particular the default recording and playback audio devices. Failing that, try reinstalling your sound card and modem drivers.<br>
<br>
<br>
<b>I am travelling around Australia using my laptop with Windows XP, and using my CDMA phone as a modem, which works well except that I have a problem in that regularly some program is doing an automatic update. I watch the bytes in & out and have no idea which program is working. It is most frustrating and expensive as it can take up to 40 minutes on the mobile CDMA connection. How can I stop this from happening?</b><br>
<br>
Your best bet here is to install a good firewall program. One good example is Zonealarm (<a href="http://www.zonelabs.com" target="_blank">www.zonelabs.com</a>); the basic version is free easy to set up.<br>
<br>
Once installed it will prompt you whenever a program tries to access the internet, so it should be fairly easy to track down the culprit.<br>
<br>
Having a firewall running is also good general practice these days, what with the likes of the Blaster virus & friends rearing their ugly heads on a regular basis.<br>
<br>
It's considered by some to be overkill for people on dial-up, but it really doesn't hurt, and it's especially important if you have an always-on connection like cable or DSL.<br>
<br>
<br>
<h2>14/10/03</h2><br>
<b>I am running Windows 98 and have encountered a problem in Microsoft Paint. Whenever I enter the program a message appears saying 'This Program has performed an illegal operation and will be shut down. If the problem persists, contact the system vendor'. Then in the details section it says 'MSPAINT caused an invalid page fault in module MFC42.DLL' (complicated and unhelpful numbers follow).</b><br>
<br>
To use a technical term, it sounds like your copy of Windows has gotten a case of bit rot. Windows 95, 98 and ME all suffer from this problem.<br>
<br>
Basically what happens is that when you install applications, certain shared support files required by the application are copied to your hard drive. Unfortunately, sometimes these files already exist (for use by Windows itself), and they get overwritten by an older, incompatible version.<br>
<br>
Unless you're very clever it can be nearly impossible to find the offending file (which in the above case could be - but isn't necessarily - MFC42.DLL), and replace it with a good copy.<br>
<br>
The easiest solution is to reinstall Windows. This is an often-suggested, inelegant way of curing odd problems - the method in the madness might be clearer now.<br>
<br>
It's sufficient to do a "reinstall over the top", rather than a complete fresh install. Just pop in your Windows disc, select "upgrade", and go read a book for the next hour. Your settings and so on will be preserved, but with luck your Windows idiosyncrasies should disappear.<br>
<br>
Windows 2000 and XP don't suffer from this particular form of degradation, as Microsoft came up with a system called Windows File Protection, which works by keeping track of the correct version of important core files, and replacing them if they ever get deleted or overwritten with the wrong version.<br>
<br>
A significant chunk of the much touted stability of newer flavours of Windows is due to this feature, and in fact the only downside to it is that it makes it just that little bit harder to hack your Windows startup screen so that it says "I hate reinstalling Windows just to fix piddling little problems".<br>
<br>
<br>
<h2>21/10/03</h2><br>
<b>As a university researcher and post-graduate lecturer, MS PowerPoint is a standard tool in my profession. The typical class-room hardware configuration is a notebook being viewed as my 'teleprompter' so I can maintain eye contact with the students, and a data projector presenting the same image (the slide show) onto a screen behind me. Is it there a hardware setting or an application option available to be able to view the MS PowerPoint 'notes page' view on the notebook (what the lecturer sees) while the slide show view remains the output to the data projector (what the audience sees)?</b><br>
<br>
There certainly is - it's called Presenter View, and allows you to view your notes, as well as control the presentation more easily, see what's next and so on.<br>
<br>
To enable it, first and foremost you need a machine set up to use multiple monitors. You're using a laptop, but not all laptops are created equal. It'll need to have true multiple monitor support, i.e. the capability to display a different image on the external display to the internal one. Most newer models should handle this without trouble.<br>
<br>
Additionally, you'll need to make sure you're running a version of Windows which supports multiple monitors (98, 2000 and XP all do), and you'll need to make sure that multiple monitor mode is enabled.<br>
<br>
Once your hardware is all set up, you should be able to enable Presenter View from within PowerPoint.<br>
<br>
Check out <a href="http://office.microsoft.com/en-gb/assistance/HA010565471033.aspx" target="_blank">office.microsoft.com/en-gb/assistance/HA010565471033.aspx</a> for the good oil direct from the MShorse's mouth.<br>
<br>
Another good jumping off point for doing this sort of thing can be found at <a href="http://www.rdpslides.com/pptfaq/FAQ00231.htm" target="_blank">www.rdpslides.com/pptfaq/FAQ00231.htm</a>.<br>
<br>
<br>
<b>When I try to log into Telstra webmail  I receive an error message that there is a Javascript error at line 45, object expected. This has only started in the past week.<br>
I have cleared my cache as suggested by Telstra.</b><br>
<br>
There are actually Javascript errors all over the web, and you'll be pleased to hear that there's nothing you can do about them. You might find it helpful to turn off IE's (pretty much useless) error reporting, to stop it pestering you about every little error it encounters.<br>
<br>
To do this, go to tools->internet options->advanced, and untick "display a notification about every script error".<br>
<br>
<br>
<h2>28/10/03</h2><br>
<b>I have just recently purchased a second hand system, as an upgrade from my ageing P2. The new system has an AMD Athlon chip in it, and I noticed straight away that it was much faster than my old one. But I also noticed that it was much louder - turns out that the CPU fan in the new machine is howling away like a hair drier! I was wondering if there is something I can do to shut it up, maybe put it on a slower speed or something?</b><br>
<br>
There are three ways you can go here, well, four if you count doing nothing and investing in ear plugs (or a louder stereo).<br>
<br>
First of all you can replace the CPU cooler fan outright. You'll need to be careful doing this, or get a professional to do it for you, as Athlon chips and sockets are quite a bit more fragile than their Intel counterparts.<br>
<br>
Bear in mind that some CPUs require quite a bit of cooling - you want to make sure you're replacing the cooler with a new model that is still up to the task, or you might have stability problems.<br>
<br>
Second you could wire in a hardware speed control. Countless third party ones are available (just do a Google search for "CPU fan speed control" or ask your favourite local computer retailer). You can even build your own if the propeller on your baseball cap is large and manly.<br>
<br>
The third - and easiest - option is to control the fan speed by software. This is a great solution, but your motherboard has to support it.<br>
<br>
With modern operating systems, the CPU generates much less heat when it's idle, which is most of the time. The idea behind software control is that when things are cooler, your fan gets throttled back, but when the system heats up the fan goes back up to hairdryer speed to do it's job.<br>
<br>
As far as software to do this goes, the leading contender in the software field here is a program called Speedfan. You can find it at <a href="http://www.almico.com" target="_blank">www.almico.com</a>, along with a long list of supported hardware. It takes a bit of setting up, but once done it could be the ideal solution.<br>
<br>
<i><p>Did the information on this page help you? Entertain you? Bore you? <a href="contact.php?subject=MasterIT">Drop me a line</a>.</p>

<p>If you're feeling particularly generous, you can even <a href="buypics.php">click here to send me some dot-com riches</a>. Think of it as online busking.</i></p>
	</div>
</div>
</body>
</html>