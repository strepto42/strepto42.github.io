<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - 18/6/2005 - There and Back Again - a Yo-yo's Tale</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="There and Back Again - a Yo-yo's Tale">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="Greetings from a Bum" href='greetingsfromabum.php'>29/4/2005</a></li>
<li><a title="Onward" href='onward.php'>2/5/2005</a></li>
<li><a title="It's a tough life (pt 1: Bundaberg, Agnes Water and 1770)" href='itsatoughlife1.php'>17/5/2005</a></li>
<li><a title="It's a tough life (pt 2: Rockhampton, Emu Park and Great Keppel Island)" href='itsatoughlife2.php'>23/5/2005</a></li>
<li><div class='activemenu'>18/6/2005</div></li>
<li><a title="Platypi and Grey Nomads" href='platypiandgreynomads.php'>24/6/2005</a></li>
<li><a title="Blowing Bubbles in a Watery Tomb" href='blowingbubbles.php'>1/7/2005</a></li>
<li><a title="Pieces of History" href='piecesofhistory.php'>8/7/2005</a></li>
<li><a title="Walks and Waterfalls" href='walksandwaterfalls.php'>15/7/2005</a></li>
<li><a title="Mission to Tribulation" href='missiontotribulation.php'>22/7/2005</a></li>
<li><a title="Levity, Limestone and Lava" href='levitylimestoneandlava.php'>29/7/2005</a></li>
<li><a title="Into the Never Never" href='intothenevernever.php'>5/8/2005</a></li>
<li><a title="Slowing the pace in Darwin" href='slowingthepaceindarwin.php'>12/8/2005</a></li>
<li><a title="Blistering Barnacles and Leaping Lizards" href='leapinglizards.php'>19/8/2005</a></li>
<li><a title="Kakadu and Litchfield" href='kakadu.php'>26/8/2005</a></li>
<li><a title="Legacies of War" href='legaciesofwar.php'>2/9/2005</a></li>
<li><a title="Go West" href='gowest.php'>10/9/2005</a></li>
<li><a title="Things from Above" href='thingsfromabove.php'>16/9/2005</a></li>
<li><a title="The West Coast" href='thewestcoast.php'>23/9/2005</a></li>
<li><a title="Reefs and Red Dust" href='reefsandreddust.php'>30/9/2005</a></li>
<li><a title="The Pilbara" href='pilbara.php'>7/10/2005</a></li>
<li><a title="Paradise with a Headwind" href='paradisewithaheadwind.php'>14/10/2005</a></li>
<li><a title="Down the Coral Coast" href='downthecoralcoast.php'>21/10/2005</a></li>
<li><a title="Pinnacles and Pinnipeds" href='pinnaclesandpinnipeds.php'>28/10/2005</a></li>
<li><a title="A week in Perth" href='perth.php'>4/11/2005</a></li>
<li><a title="The Southwest (from Above and Below)" href='thesouthwest.php'>11/11/2005</a></li>
<li><a title="More Heights and Depths" href='moreheightsanddepths.php'>18/11/2005</a></li>
<li><a title="Across the Nullarbor (and a bit beyond)" href='nullarbor.php'>25/11/2005</a></li>
<li><a title="Double Whammy" href='doublewhammy.php'>9/12/2005</a></li>
<li><a title="Two Cities" href='twocities.php'>19/12/2005</a></li>
<li><a title="Tassie - Part 1" href='tassie1.php'>1/1/2006</a></li>
<li><a title="Tassie - Part 2" href='tassie2.php'>7/1/2006</a></li>
<li><a title="Full Circle" href='fullcircle.php'>26/1/2006</a></li>
<li><a title="The Wrap Up" href='thewrapup.php'>23/3/2006</a></li>
<li> </li><br><li>Or go back to:</li><li><a title='Travelouges and blogs from my trip around Australia' href="nerdseyeview.php">Nerd's Eye View</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>18/6/2005</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Travel stories and pictures' href="travel.php">Travelogues</a> > <a title='Travelouges and blogs from my trip around Australia' href="nerdseyeview.php">Nerd's Eye View</a> > <a title='There and Back Again - a Yo-yo's Tale' href="thereandbackagain.php">18/6/2005</a>
<br><br>		


<h1>There and Back Again - a Yo-yo's Tale</h1>

<a href="images/maps/Map050618.gif"><img src="images/maps/Map050618_sm.gif" align="right"></a>

<p>Howdy,</p>

<p>Once again, it's been a while between communiques, but I wouldn't get to disrupt everyone's productivity so much if I wrote more frequent, shorter emails. Mind you, people might actually read them if they were shorter � go own, own up to yourselves, those of you who still haven't read the last one!</p>

<p>Taking up the story again, I left Emu Park and headed back down to Brisvegas, on a flying visit for Jana's birthday. I figured before I got too far away it would be nice to drop in.</p>

<p>In the end it was a really relaxing stay. It was nice to be back for a little while without all the stress of packing up and leaving, which was how it was just before I left.</p>

<p>Highlights from the visit included:</p>

<p>- Catching up with various folks at various pubs on various occasions, including my Sis. Such occasions are always nice!</p>

<p>- A party at Jana's place, which had some interesting costumes (we shan't speak of mine here, suffice to say I was the cutest) and terrible music (young folk these days have no idea. Really. ;))</p>

<p>- Backing my car into a pole at John's house, and the associated fun of fixing it, which reinforced my opinion regarding the fact that everything to do with working on cars is always difficult and annoying.</p>

<p>- Getting my bond back (finally) and immediately converting it into more nerd goods;  I now have a GPS and a tripod for the camera, both of which have already proved their worth.</p>

<p>- Seeing the new Star Wars movie. All I can say is "noooooooooo!!!!"</p>

<p>- Getting a real mattress for my car (foam versus air). Much more
manageable.</p>

<p>- Dumping some camping gear I wasn't using, and managing to wedge my bass into the car, so I now have two guitars with me. :)</p>

<p>- Spending time with Jana, yay! :)</p>

<p>All up I stayed in Brissie for a little longer than I expected to, nearly two weeks (<a href="http://www.2weeks.com" target="_blank">http://www.2weeks.com</a>) all up, but it was worth it. When I left, I decided to head back up north via a more inland route. First, I hopped over to Bunya National Park, which is a really nice spot if any Brisbanites want to check it out. It's a bit chilly this time of year though, being up about 1000m. But lovely forest.</p>

<p>From there I headed North inland, to Cania Gorge National Park. It was an interesting drive. Inland Queensland is somewhat different to the coast (who'd have thought it�). There are lots of rolling planes, dry forest and a fair bit of red earth.</p>

<p>I flew through a few little country towns on the way, some of which were little more than a general store and service station (and a pub). Not much to report really, except for discovering the Big Mandarin at Mundubbera (note to potential tourists of large fibreglass fruits: it's not that exciting. Actually, it's completely unexciting).</p>

<p>Cania is a nice spot. There is a dam there (wow) and some nice walks. Unfortunately I didn't have time to go on any, as I had to head off again early in the morning. I stayed in a fairly secluded caravan park, which was full of nice wildlife. There were some very tame birds and wallabies, which were most obliging for some great photos.</p>

<p>From there I headed into to Rockhampton, to meet up with Naima (Jana's sister), who was up there for the Peace Convergence. You might have seen something on the <a href="http://www.abc.net.au/news/australia/qld/capricornia/200506/s1390302.htm" target="_blank">ABC News</a> about people blockading the joint Australia and US military exercises that are being held up there now; well, this was that.</p>

<p>Without getting too political in a travel email� oh bugger it. My basic beef is not with the armed forces per se, but with the government of this country insisting on wanting to be little America.</p>

<p>Inviting the US army here to bomb stuff is not good on many levels � from the political implications in the region, to the nature of the weapons that they say they don't use, but do, being thrown around in Oz (try depleted Uranium for one), to the social implications for the region of having hundreds of jar heads released on R&R.</p>

<p>Aaaanyway.</p>

<p>I wasn't there to tie myself to anything or get arrested. I just wanted to get an on-the-ground view of exactly what happened at something like this. Something not tainted by the mass media. So I hung round and took photos. In the end it was a very enjoyable, and quite different couple of days. I met some interesting people, some quite extreme and some a little different (shall we say), but also plenty of people with their heads screwed on really rather well (if leaning at a somewhat left angle).</p>

<p>I admire these people for what they do � i.e. get off their bums and make people aware of issues, and try to make some positive change happen in the society that we all share. It doesn't really matter what their beliefs are (well it does sometimes, but that's not the point), it matters that they exist at all, because without them governments and corporations would be completely unchecked in their actions.</p>

<p>It's also really rather good to remember that we still live in a country where this stuff is possible without getting, like, shot.</p>

<p>Ok, rant over. I'm sure I can have a lively discussion about all this at some point in the future with many of you! ;)</p>

<p>As far as the actual day of action goes, all up it was good, with no violence on either side. The army trucks which were the target of the blockade never showed up, and they turned out to be parked a few kilometres up the road, waiting, rather than forcing a confrontation.</p>

<p>Eventually, most people left to go to Yeppoon where other stuff was happening, while a few hard core folks stayed to get arrested (a few had also been arrested at an earlier thing that morning too).</p>

<p>The vibe was all quite nice, until everyone got stopped and hassled by the cops on the way out for a "random" breath test and general licence check. It was all a bit unnecessary, and the cops were throwing their weight around for no good reason. Nice work guys. Oh well, at least nobody got beaten up.</p>

<p>Pictures of the event are on my website <a href="peaceconvergence.php">here</a>.</p>

<p>On with the adventures. The next day, I drove back down south to Bundy to hook up with Nathan, an ex workmate who has been overseas for a while.</p>

<p>We played some music and drank into the night, and his folks spoiled me with a real bed and great dinners (including dessert); many thanks to the Spargos for their awesome hospitality.</p>

<p>Nathan and I also went and saw bloody Star Warts again (as he hadn't seen it). A highly amusing nerd critique ensued afterwards � worst redeeming ever! George Lucas should have stuck with Ewoks. And decent script writers.</p>

<p>Anyway it was awesome to catch up. Incidentally, for those of you who don't know, Spargs is the man behind Digi-comic. He would love it if you went there and voted for his comics and clicked his banner ads. :)</p>

<p>From there I headed back up north, to a place called Capricorn Caves, just north of Rockhampton. These are pretty cool � not as spectacular as Jenolan or Wombeyan caves, but it was fun nonetheless to be underground again, as it had been years since I did any caving.</p>

<p>It was nice camping there too � lots of wildlife, including some cute frogs and kangaroos hopping around my car in the evening.</p>

<p>The day after that I headed to Blackdown Tablelands National Park. It's another lovely spot, pretty cool at night (especially without my pants, which I left at Nathan's. See <a href="http://www.digi-comic.com/?comicId=57" target="_blank">http://www.digi-comic.com/?comicId=57</a>). I managed to survive in shorts and lots of tops, in true Peter Jackson style. Took some nice star trail photos, and did some walking the next day.</p>

<p>After that, it was off to Mackay, inland again. Nothing special to see along the way, but I did have a small adventure in that one of my rear tyres decided to say goodbye to this cruel world and started peeling it's skin off alarmingly. Thankfully it wasn't a sudden blowout. I stopped by the road and changed it, with the helpful company of about 70 bush flies.</p>

<p>Now (finally, the present day!) I'm in Mackay, sitting in an ice cream parlour using the Internet (gotta upload all those pictures with a faster connection). There are about 15 four year old kids here having a "princess party". And life goes on.</p>

<p>I hope you are all well and that the universe is being kind to you. Do write and let me know how things are (and where you are, for the fellow travellers).</p>

<p>Now I'm off to have a waffle.</p>

<br><br>
All images in this gallery:<br>
<table width='800'>
<tr>
</tr>
<tr><td><A ID='IMG_3006.JPG' href='thereandbackagain.php?fileId=IMG_3006.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050618/IMG_3006.JPG' ALT='IMG_3006.JPG'><BR>IMG_3006.JPG<br>52.36 KB</a><div class='inv'><br><a href='./images/20050618/IMG_3006.JPG' ALT='IMG_3006.JPG'>IMG_3006.JPG</a></div></td>
<td><A ID='IMG_3007.JPG' href='thereandbackagain.php?fileId=IMG_3007.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050618/IMG_3007.JPG' ALT='IMG_3007.JPG'><BR>IMG_3007.JPG<br>77.44 KB</a><div class='inv'><br><a href='./images/20050618/IMG_3007.JPG' ALT='IMG_3007.JPG'>IMG_3007.JPG</a></div></td>
<td><A ID='IMG_3009.JPG' href='thereandbackagain.php?fileId=IMG_3009.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050618/IMG_3009.JPG' ALT='IMG_3009.JPG'><BR>IMG_3009.JPG<br>48.59 KB</a><div class='inv'><br><a href='./images/20050618/IMG_3009.JPG' ALT='IMG_3009.JPG'>IMG_3009.JPG</a></div></td>
<td><A ID='IMG_3014.JPG' href='thereandbackagain.php?fileId=IMG_3014.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050618/IMG_3014.JPG' ALT='IMG_3014.JPG'><BR>IMG_3014.JPG<br>41.27 KB</a><div class='inv'><br><a href='./images/20050618/IMG_3014.JPG' ALT='IMG_3014.JPG'>IMG_3014.JPG</a></div></td>
<td><A ID='IMG_3017.JPG' href='thereandbackagain.php?fileId=IMG_3017.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050618/IMG_3017.JPG' ALT='IMG_3017.JPG'><BR>IMG_3017.JPG<br>36.57 KB</a><div class='inv'><br><a href='./images/20050618/IMG_3017.JPG' ALT='IMG_3017.JPG'>IMG_3017.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_3023.JPG' href='thereandbackagain.php?fileId=IMG_3023.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050618/IMG_3023.JPG' ALT='IMG_3023.JPG'><BR>IMG_3023.JPG<br>44 KB</a><div class='inv'><br><a href='./images/20050618/IMG_3023.JPG' ALT='IMG_3023.JPG'>IMG_3023.JPG</a></div></td>
<td><A ID='IMG_3032.JPG' href='thereandbackagain.php?fileId=IMG_3032.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050618/IMG_3032.JPG' ALT='IMG_3032.JPG'><BR>IMG_3032.JPG<br>69.24 KB</a><div class='inv'><br><a href='./images/20050618/IMG_3032.JPG' ALT='IMG_3032.JPG'>IMG_3032.JPG</a></div></td>
<td><A ID='IMG_3034.JPG' href='thereandbackagain.php?fileId=IMG_3034.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050618/IMG_3034.JPG' ALT='IMG_3034.JPG'><BR>IMG_3034.JPG<br>66.91 KB</a><div class='inv'><br><a href='./images/20050618/IMG_3034.JPG' ALT='IMG_3034.JPG'>IMG_3034.JPG</a></div></td>
<td><A ID='IMG_3035.JPG' href='thereandbackagain.php?fileId=IMG_3035.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050618/IMG_3035.JPG' ALT='IMG_3035.JPG'><BR>IMG_3035.JPG<br>130.76 KB</a><div class='inv'><br><a href='./images/20050618/IMG_3035.JPG' ALT='IMG_3035.JPG'>IMG_3035.JPG</a></div></td>
<td><A ID='IMG_3037.JPG' href='thereandbackagain.php?fileId=IMG_3037.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050618/IMG_3037.JPG' ALT='IMG_3037.JPG'><BR>IMG_3037.JPG<br>104.39 KB</a><div class='inv'><br><a href='./images/20050618/IMG_3037.JPG' ALT='IMG_3037.JPG'>IMG_3037.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_3040.JPG' href='thereandbackagain.php?fileId=IMG_3040.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050618/IMG_3040.JPG' ALT='IMG_3040.JPG'><BR>IMG_3040.JPG<br>85.03 KB</a><div class='inv'><br><a href='./images/20050618/IMG_3040.JPG' ALT='IMG_3040.JPG'>IMG_3040.JPG</a></div></td>
<td><A ID='IMG_3042.JPG' href='thereandbackagain.php?fileId=IMG_3042.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050618/IMG_3042.JPG' ALT='IMG_3042.JPG'><BR>IMG_3042.JPG<br>76.39 KB</a><div class='inv'><br><a href='./images/20050618/IMG_3042.JPG' ALT='IMG_3042.JPG'>IMG_3042.JPG</a></div></td>
<td><A ID='IMG_3045.JPG' href='thereandbackagain.php?fileId=IMG_3045.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050618/IMG_3045.JPG' ALT='IMG_3045.JPG'><BR>IMG_3045.JPG<br>94.49 KB</a><div class='inv'><br><a href='./images/20050618/IMG_3045.JPG' ALT='IMG_3045.JPG'>IMG_3045.JPG</a></div></td>
<td><A ID='IMG_3047.JPG' href='thereandbackagain.php?fileId=IMG_3047.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050618/IMG_3047.JPG' ALT='IMG_3047.JPG'><BR>IMG_3047.JPG<br>62.51 KB</a><div class='inv'><br><a href='./images/20050618/IMG_3047.JPG' ALT='IMG_3047.JPG'>IMG_3047.JPG</a></div></td>
<td><A ID='IMG_3048.JPG' href='thereandbackagain.php?fileId=IMG_3048.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050618/IMG_3048.JPG' ALT='IMG_3048.JPG'><BR>IMG_3048.JPG<br>87.12 KB</a><div class='inv'><br><a href='./images/20050618/IMG_3048.JPG' ALT='IMG_3048.JPG'>IMG_3048.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_3055.JPG' href='thereandbackagain.php?fileId=IMG_3055.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050618/IMG_3055.JPG' ALT='IMG_3055.JPG'><BR>IMG_3055.JPG<br>87.29 KB</a><div class='inv'><br><a href='./images/20050618/IMG_3055.JPG' ALT='IMG_3055.JPG'>IMG_3055.JPG</a></div></td>
<td><A ID='IMG_3057.JPG' href='thereandbackagain.php?fileId=IMG_3057.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050618/IMG_3057.JPG' ALT='IMG_3057.JPG'><BR>IMG_3057.JPG<br>62.95 KB</a><div class='inv'><br><a href='./images/20050618/IMG_3057.JPG' ALT='IMG_3057.JPG'>IMG_3057.JPG</a></div></td>
<td><A ID='IMG_3061.JPG' href='thereandbackagain.php?fileId=IMG_3061.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050618/IMG_3061.JPG' ALT='IMG_3061.JPG'><BR>IMG_3061.JPG<br>51.67 KB</a><div class='inv'><br><a href='./images/20050618/IMG_3061.JPG' ALT='IMG_3061.JPG'>IMG_3061.JPG</a></div></td>
<td><A ID='IMG_3062.JPG' href='thereandbackagain.php?fileId=IMG_3062.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050618/IMG_3062.JPG' ALT='IMG_3062.JPG'><BR>IMG_3062.JPG<br>75.88 KB</a><div class='inv'><br><a href='./images/20050618/IMG_3062.JPG' ALT='IMG_3062.JPG'>IMG_3062.JPG</a></div></td>
<td><A ID='IMG_3063.JPG' href='thereandbackagain.php?fileId=IMG_3063.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050618/IMG_3063.JPG' ALT='IMG_3063.JPG'><BR>IMG_3063.JPG<br>58.02 KB</a><div class='inv'><br><a href='./images/20050618/IMG_3063.JPG' ALT='IMG_3063.JPG'>IMG_3063.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_3064.JPG' href='thereandbackagain.php?fileId=IMG_3064.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050618/IMG_3064.JPG' ALT='IMG_3064.JPG'><BR>IMG_3064.JPG<br>57.19 KB</a><div class='inv'><br><a href='./images/20050618/IMG_3064.JPG' ALT='IMG_3064.JPG'>IMG_3064.JPG</a></div></td>
<td><A ID='IMG_3066.JPG' href='thereandbackagain.php?fileId=IMG_3066.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050618/IMG_3066.JPG' ALT='IMG_3066.JPG'><BR>IMG_3066.JPG<br>48.68 KB</a><div class='inv'><br><a href='./images/20050618/IMG_3066.JPG' ALT='IMG_3066.JPG'>IMG_3066.JPG</a></div></td>
<td><A ID='IMG_3068.JPG' href='thereandbackagain.php?fileId=IMG_3068.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050618/IMG_3068.JPG' ALT='IMG_3068.JPG'><BR>IMG_3068.JPG<br>46.71 KB</a><div class='inv'><br><a href='./images/20050618/IMG_3068.JPG' ALT='IMG_3068.JPG'>IMG_3068.JPG</a></div></td>
<td><A ID='IMG_3072.JPG' href='thereandbackagain.php?fileId=IMG_3072.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050618/IMG_3072.JPG' ALT='IMG_3072.JPG'><BR>IMG_3072.JPG<br>45.22 KB</a><div class='inv'><br><a href='./images/20050618/IMG_3072.JPG' ALT='IMG_3072.JPG'>IMG_3072.JPG</a></div></td>
<td><A ID='IMG_3075.JPG' href='thereandbackagain.php?fileId=IMG_3075.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050618/IMG_3075.JPG' ALT='IMG_3075.JPG'><BR>IMG_3075.JPG<br>46.44 KB</a><div class='inv'><br><a href='./images/20050618/IMG_3075.JPG' ALT='IMG_3075.JPG'>IMG_3075.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_3078.JPG' href='thereandbackagain.php?fileId=IMG_3078.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050618/IMG_3078.JPG' ALT='IMG_3078.JPG'><BR>IMG_3078.JPG<br>48.04 KB</a><div class='inv'><br><a href='./images/20050618/IMG_3078.JPG' ALT='IMG_3078.JPG'>IMG_3078.JPG</a></div></td>
<td><A ID='IMG_3083.JPG' href='thereandbackagain.php?fileId=IMG_3083.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050618/IMG_3083.JPG' ALT='IMG_3083.JPG'><BR>IMG_3083.JPG<br>100.89 KB</a><div class='inv'><br><a href='./images/20050618/IMG_3083.JPG' ALT='IMG_3083.JPG'>IMG_3083.JPG</a></div></td>
<td><A ID='IMG_3084.JPG' href='thereandbackagain.php?fileId=IMG_3084.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050618/IMG_3084.JPG' ALT='IMG_3084.JPG'><BR>IMG_3084.JPG<br>139.02 KB</a><div class='inv'><br><a href='./images/20050618/IMG_3084.JPG' ALT='IMG_3084.JPG'>IMG_3084.JPG</a></div></td>
<td><A ID='IMG_3093.JPG' href='thereandbackagain.php?fileId=IMG_3093.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050618/IMG_3093.JPG' ALT='IMG_3093.JPG'><BR>IMG_3093.JPG<br>101.16 KB</a><div class='inv'><br><a href='./images/20050618/IMG_3093.JPG' ALT='IMG_3093.JPG'>IMG_3093.JPG</a></div></td>
<td><A ID='IMG_3095.JPG' href='thereandbackagain.php?fileId=IMG_3095.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050618/IMG_3095.JPG' ALT='IMG_3095.JPG'><BR>IMG_3095.JPG<br>60.6 KB</a><div class='inv'><br><a href='./images/20050618/IMG_3095.JPG' ALT='IMG_3095.JPG'>IMG_3095.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_3098.JPG' href='thereandbackagain.php?fileId=IMG_3098.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050618/IMG_3098.JPG' ALT='IMG_3098.JPG'><BR>IMG_3098.JPG<br>120.54 KB</a><div class='inv'><br><a href='./images/20050618/IMG_3098.JPG' ALT='IMG_3098.JPG'>IMG_3098.JPG</a></div></td>
<td><A ID='IMG_3101.JPG' href='thereandbackagain.php?fileId=IMG_3101.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050618/IMG_3101.JPG' ALT='IMG_3101.JPG'><BR>IMG_3101.JPG<br>50.06 KB</a><div class='inv'><br><a href='./images/20050618/IMG_3101.JPG' ALT='IMG_3101.JPG'>IMG_3101.JPG</a></div></td>
<td><A ID='IMG_3137.JPG' href='thereandbackagain.php?fileId=IMG_3137.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050618/IMG_3137.JPG' ALT='IMG_3137.JPG'><BR>IMG_3137.JPG<br>42.16 KB</a><div class='inv'><br><a href='./images/20050618/IMG_3137.JPG' ALT='IMG_3137.JPG'>IMG_3137.JPG</a></div></td>
<td><A ID='IMG_3349.JPG' href='thereandbackagain.php?fileId=IMG_3349.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050618/IMG_3349.JPG' ALT='IMG_3349.JPG'><BR>IMG_3349.JPG<br>59.32 KB</a><div class='inv'><br><a href='./images/20050618/IMG_3349.JPG' ALT='IMG_3349.JPG'>IMG_3349.JPG</a></div></td>
<td><A ID='IMG_3350.JPG' href='thereandbackagain.php?fileId=IMG_3350.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050618/IMG_3350.JPG' ALT='IMG_3350.JPG'><BR>IMG_3350.JPG<br>59.48 KB</a><div class='inv'><br><a href='./images/20050618/IMG_3350.JPG' ALT='IMG_3350.JPG'>IMG_3350.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_3351.JPG' href='thereandbackagain.php?fileId=IMG_3351.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050618/IMG_3351.JPG' ALT='IMG_3351.JPG'><BR>IMG_3351.JPG<br>52.88 KB</a><div class='inv'><br><a href='./images/20050618/IMG_3351.JPG' ALT='IMG_3351.JPG'>IMG_3351.JPG</a></div></td>
<td><A ID='IMG_3352.JPG' href='thereandbackagain.php?fileId=IMG_3352.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050618/IMG_3352.JPG' ALT='IMG_3352.JPG'><BR>IMG_3352.JPG<br>63.56 KB</a><div class='inv'><br><a href='./images/20050618/IMG_3352.JPG' ALT='IMG_3352.JPG'>IMG_3352.JPG</a></div></td>
<td><A ID='IMG_3353.JPG' href='thereandbackagain.php?fileId=IMG_3353.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050618/IMG_3353.JPG' ALT='IMG_3353.JPG'><BR>IMG_3353.JPG<br>61.39 KB</a><div class='inv'><br><a href='./images/20050618/IMG_3353.JPG' ALT='IMG_3353.JPG'>IMG_3353.JPG</a></div></td>
<td><A ID='IMG_3355.JPG' href='thereandbackagain.php?fileId=IMG_3355.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050618/IMG_3355.JPG' ALT='IMG_3355.JPG'><BR>IMG_3355.JPG<br>46.33 KB</a><div class='inv'><br><a href='./images/20050618/IMG_3355.JPG' ALT='IMG_3355.JPG'>IMG_3355.JPG</a></div></td>
<td><A ID='IMG_3356.JPG' href='thereandbackagain.php?fileId=IMG_3356.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050618/IMG_3356.JPG' ALT='IMG_3356.JPG'><BR>IMG_3356.JPG<br>47.48 KB</a><div class='inv'><br><a href='./images/20050618/IMG_3356.JPG' ALT='IMG_3356.JPG'>IMG_3356.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_3358.JPG' href='thereandbackagain.php?fileId=IMG_3358.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050618/IMG_3358.JPG' ALT='IMG_3358.JPG'><BR>IMG_3358.JPG<br>53.39 KB</a><div class='inv'><br><a href='./images/20050618/IMG_3358.JPG' ALT='IMG_3358.JPG'>IMG_3358.JPG</a></div></td>
<td><A ID='IMG_3359.JPG' href='thereandbackagain.php?fileId=IMG_3359.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050618/IMG_3359.JPG' ALT='IMG_3359.JPG'><BR>IMG_3359.JPG<br>131.01 KB</a><div class='inv'><br><a href='./images/20050618/IMG_3359.JPG' ALT='IMG_3359.JPG'>IMG_3359.JPG</a></div></td>
<td><A ID='IMG_3360.JPG' href='thereandbackagain.php?fileId=IMG_3360.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050618/IMG_3360.JPG' ALT='IMG_3360.JPG'><BR>IMG_3360.JPG<br>85.46 KB</a><div class='inv'><br><a href='./images/20050618/IMG_3360.JPG' ALT='IMG_3360.JPG'>IMG_3360.JPG</a></div></td>
<td><A ID='IMG_3361.JPG' href='thereandbackagain.php?fileId=IMG_3361.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050618/IMG_3361.JPG' ALT='IMG_3361.JPG'><BR>IMG_3361.JPG<br>78.7 KB</a><div class='inv'><br><a href='./images/20050618/IMG_3361.JPG' ALT='IMG_3361.JPG'>IMG_3361.JPG</a></div></td>
<td><A ID='IMG_3363.JPG' href='thereandbackagain.php?fileId=IMG_3363.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050618/IMG_3363.JPG' ALT='IMG_3363.JPG'><BR>IMG_3363.JPG<br>74.26 KB</a><div class='inv'><br><a href='./images/20050618/IMG_3363.JPG' ALT='IMG_3363.JPG'>IMG_3363.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_3364.JPG' href='thereandbackagain.php?fileId=IMG_3364.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050618/IMG_3364.JPG' ALT='IMG_3364.JPG'><BR>IMG_3364.JPG<br>42.52 KB</a><div class='inv'><br><a href='./images/20050618/IMG_3364.JPG' ALT='IMG_3364.JPG'>IMG_3364.JPG</a></div></td>
<td><A ID='IMG_3366.JPG' href='thereandbackagain.php?fileId=IMG_3366.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050618/IMG_3366.JPG' ALT='IMG_3366.JPG'><BR>IMG_3366.JPG<br>65.29 KB</a><div class='inv'><br><a href='./images/20050618/IMG_3366.JPG' ALT='IMG_3366.JPG'>IMG_3366.JPG</a></div></td>
<td><A ID='IMG_3367.JPG' href='thereandbackagain.php?fileId=IMG_3367.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050618/IMG_3367.JPG' ALT='IMG_3367.JPG'><BR>IMG_3367.JPG<br>80.13 KB</a><div class='inv'><br><a href='./images/20050618/IMG_3367.JPG' ALT='IMG_3367.JPG'>IMG_3367.JPG</a></div></td>
<td><A ID='IMG_3368.JPG' href='thereandbackagain.php?fileId=IMG_3368.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050618/IMG_3368.JPG' ALT='IMG_3368.JPG'><BR>IMG_3368.JPG<br>93.49 KB</a><div class='inv'><br><a href='./images/20050618/IMG_3368.JPG' ALT='IMG_3368.JPG'>IMG_3368.JPG</a></div></td>
<td><A ID='IMG_3372.JPG' href='thereandbackagain.php?fileId=IMG_3372.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050618/IMG_3372.JPG' ALT='IMG_3372.JPG'><BR>IMG_3372.JPG<br>62.09 KB</a><div class='inv'><br><a href='./images/20050618/IMG_3372.JPG' ALT='IMG_3372.JPG'>IMG_3372.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_3373.JPG' href='thereandbackagain.php?fileId=IMG_3373.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050618/IMG_3373.JPG' ALT='IMG_3373.JPG'><BR>IMG_3373.JPG<br>65.08 KB</a><div class='inv'><br><a href='./images/20050618/IMG_3373.JPG' ALT='IMG_3373.JPG'>IMG_3373.JPG</a></div></td>
<td><A ID='IMG_3374.JPG' href='thereandbackagain.php?fileId=IMG_3374.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050618/IMG_3374.JPG' ALT='IMG_3374.JPG'><BR>IMG_3374.JPG<br>75.64 KB</a><div class='inv'><br><a href='./images/20050618/IMG_3374.JPG' ALT='IMG_3374.JPG'>IMG_3374.JPG</a></div></td>
<td><A ID='IMG_3375.JPG' href='thereandbackagain.php?fileId=IMG_3375.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050618/IMG_3375.JPG' ALT='IMG_3375.JPG'><BR>IMG_3375.JPG<br>74.19 KB</a><div class='inv'><br><a href='./images/20050618/IMG_3375.JPG' ALT='IMG_3375.JPG'>IMG_3375.JPG</a></div></td>
<td><A ID='IMG_3379.JPG' href='thereandbackagain.php?fileId=IMG_3379.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050618/IMG_3379.JPG' ALT='IMG_3379.JPG'><BR>IMG_3379.JPG<br>63.88 KB</a><div class='inv'><br><a href='./images/20050618/IMG_3379.JPG' ALT='IMG_3379.JPG'>IMG_3379.JPG</a></div></td>
<td><A ID='IMG_3380.JPG' href='thereandbackagain.php?fileId=IMG_3380.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050618/IMG_3380.JPG' ALT='IMG_3380.JPG'><BR>IMG_3380.JPG<br>79.67 KB</a><div class='inv'><br><a href='./images/20050618/IMG_3380.JPG' ALT='IMG_3380.JPG'>IMG_3380.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_3385.JPG' href='thereandbackagain.php?fileId=IMG_3385.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050618/IMG_3385.JPG' ALT='IMG_3385.JPG'><BR>IMG_3385.JPG<br>88.72 KB</a><div class='inv'><br><a href='./images/20050618/IMG_3385.JPG' ALT='IMG_3385.JPG'>IMG_3385.JPG</a></div></td>
<td><A ID='IMG_3387.JPG' href='thereandbackagain.php?fileId=IMG_3387.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050618/IMG_3387.JPG' ALT='IMG_3387.JPG'><BR>IMG_3387.JPG<br>65.14 KB</a><div class='inv'><br><a href='./images/20050618/IMG_3387.JPG' ALT='IMG_3387.JPG'>IMG_3387.JPG</a></div></td>
<td><A ID='IMG_3395.JPG' href='thereandbackagain.php?fileId=IMG_3395.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050618/IMG_3395.JPG' ALT='IMG_3395.JPG'><BR>IMG_3395.JPG<br>87.74 KB</a><div class='inv'><br><a href='./images/20050618/IMG_3395.JPG' ALT='IMG_3395.JPG'>IMG_3395.JPG</a></div></td>
<td><A ID='IMG_3401.JPG' href='thereandbackagain.php?fileId=IMG_3401.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050618/IMG_3401.JPG' ALT='IMG_3401.JPG'><BR>IMG_3401.JPG<br>39.5 KB</a><div class='inv'><br><a href='./images/20050618/IMG_3401.JPG' ALT='IMG_3401.JPG'>IMG_3401.JPG</a></div></td>
<td><A ID='IMG_3406.JPG' href='thereandbackagain.php?fileId=IMG_3406.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050618/IMG_3406.JPG' ALT='IMG_3406.JPG'><BR>IMG_3406.JPG<br>98.45 KB</a><div class='inv'><br><a href='./images/20050618/IMG_3406.JPG' ALT='IMG_3406.JPG'>IMG_3406.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_3409.JPG' href='thereandbackagain.php?fileId=IMG_3409.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050618/IMG_3409.JPG' ALT='IMG_3409.JPG'><BR>IMG_3409.JPG<br>62.42 KB</a><div class='inv'><br><a href='./images/20050618/IMG_3409.JPG' ALT='IMG_3409.JPG'>IMG_3409.JPG</a></div></td>
<td><A ID='IMG_3411.JPG' href='thereandbackagain.php?fileId=IMG_3411.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050618/IMG_3411.JPG' ALT='IMG_3411.JPG'><BR>IMG_3411.JPG<br>96.07 KB</a><div class='inv'><br><a href='./images/20050618/IMG_3411.JPG' ALT='IMG_3411.JPG'>IMG_3411.JPG</a></div></td>
<td><A ID='IMG_3434.JPG' href='thereandbackagain.php?fileId=IMG_3434.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050618/IMG_3434.JPG' ALT='IMG_3434.JPG'><BR>IMG_3434.JPG<br>55.48 KB</a><div class='inv'><br><a href='./images/20050618/IMG_3434.JPG' ALT='IMG_3434.JPG'>IMG_3434.JPG</a></div></td>
<td><A ID='IMG_3441.JPG' href='thereandbackagain.php?fileId=IMG_3441.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050618/IMG_3441.JPG' ALT='IMG_3441.JPG'><BR>IMG_3441.JPG<br>59.49 KB</a><div class='inv'><br><a href='./images/20050618/IMG_3441.JPG' ALT='IMG_3441.JPG'>IMG_3441.JPG</a></div></td>
<td><A ID='IMG_3443.JPG' href='thereandbackagain.php?fileId=IMG_3443.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050618/IMG_3443.JPG' ALT='IMG_3443.JPG'><BR>IMG_3443.JPG<br>56.27 KB</a><div class='inv'><br><a href='./images/20050618/IMG_3443.JPG' ALT='IMG_3443.JPG'>IMG_3443.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_3449.JPG' href='thereandbackagain.php?fileId=IMG_3449.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050618/IMG_3449.JPG' ALT='IMG_3449.JPG'><BR>IMG_3449.JPG<br>130.79 KB</a><div class='inv'><br><a href='./images/20050618/IMG_3449.JPG' ALT='IMG_3449.JPG'>IMG_3449.JPG</a></div></td>
<td><A ID='IMG_3451.JPG' href='thereandbackagain.php?fileId=IMG_3451.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050618/IMG_3451.JPG' ALT='IMG_3451.JPG'><BR>IMG_3451.JPG<br>74.24 KB</a><div class='inv'><br><a href='./images/20050618/IMG_3451.JPG' ALT='IMG_3451.JPG'>IMG_3451.JPG</a></div></td>
<td><A ID='IMG_3455.JPG' href='thereandbackagain.php?fileId=IMG_3455.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050618/IMG_3455.JPG' ALT='IMG_3455.JPG'><BR>IMG_3455.JPG<br>117.7 KB</a><div class='inv'><br><a href='./images/20050618/IMG_3455.JPG' ALT='IMG_3455.JPG'>IMG_3455.JPG</a></div></td>
<td><A ID='IMG_3460.JPG' href='thereandbackagain.php?fileId=IMG_3460.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050618/IMG_3460.JPG' ALT='IMG_3460.JPG'><BR>IMG_3460.JPG<br>47.49 KB</a><div class='inv'><br><a href='./images/20050618/IMG_3460.JPG' ALT='IMG_3460.JPG'>IMG_3460.JPG</a></div></td>
<td><A ID='IMG_3465.JPG' href='thereandbackagain.php?fileId=IMG_3465.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050618/IMG_3465.JPG' ALT='IMG_3465.JPG'><BR>IMG_3465.JPG<br>104.27 KB</a><div class='inv'><br><a href='./images/20050618/IMG_3465.JPG' ALT='IMG_3465.JPG'>IMG_3465.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_3466.JPG' href='thereandbackagain.php?fileId=IMG_3466.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050618/IMG_3466.JPG' ALT='IMG_3466.JPG'><BR>IMG_3466.JPG<br>67.18 KB</a><div class='inv'><br><a href='./images/20050618/IMG_3466.JPG' ALT='IMG_3466.JPG'>IMG_3466.JPG</a></div></td>
<td><A ID='IMG_3471.JPG' href='thereandbackagain.php?fileId=IMG_3471.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050618/IMG_3471.JPG' ALT='IMG_3471.JPG'><BR>IMG_3471.JPG<br>73.78 KB</a><div class='inv'><br><a href='./images/20050618/IMG_3471.JPG' ALT='IMG_3471.JPG'>IMG_3471.JPG</a></div></td>
<td><A ID='IMG_3472.JPG' href='thereandbackagain.php?fileId=IMG_3472.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050618/IMG_3472.JPG' ALT='IMG_3472.JPG'><BR>IMG_3472.JPG<br>65.56 KB</a><div class='inv'><br><a href='./images/20050618/IMG_3472.JPG' ALT='IMG_3472.JPG'>IMG_3472.JPG</a></div></td>
<td><A ID='IMG_3482.JPG' href='thereandbackagain.php?fileId=IMG_3482.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050618/IMG_3482.JPG' ALT='IMG_3482.JPG'><BR>IMG_3482.JPG<br>56.82 KB</a><div class='inv'><br><a href='./images/20050618/IMG_3482.JPG' ALT='IMG_3482.JPG'>IMG_3482.JPG</a></div></td>
<td><A ID='IMG_3484.JPG' href='thereandbackagain.php?fileId=IMG_3484.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050618/IMG_3484.JPG' ALT='IMG_3484.JPG'><BR>IMG_3484.JPG<br>118.56 KB</a><div class='inv'><br><a href='./images/20050618/IMG_3484.JPG' ALT='IMG_3484.JPG'>IMG_3484.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_3485.JPG' href='thereandbackagain.php?fileId=IMG_3485.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050618/IMG_3485.JPG' ALT='IMG_3485.JPG'><BR>IMG_3485.JPG<br>90.68 KB</a><div class='inv'><br><a href='./images/20050618/IMG_3485.JPG' ALT='IMG_3485.JPG'>IMG_3485.JPG</a></div></td>
</tr>
</table>	</div>
</div>
</body>
</html>