<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:v="urn:schemas-microsoft-com:vml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - Outback NSW - Warrumbungle, Kings Plains and Bald Rock National Parks</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="Warrumbungle, Kings Plains and Bald Rock National Parks">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://maps.google.com/maps?file=api&amp;v=2&amp;key=ABQIAAAAlaGTdQKzpFhAqFR_JcbA7xRW4RXHGTymU03qqBIMaqzwHnmPjBToKZLfamCKvG6RWS9CNwQTlUDziw" type="text/javascript"></script>

	</head>

<body onload="load();" onunload="GUnload();">
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="Travelouges from my trip through India in 2000" href='india2000.php'>India 2000</a></li>
<li><a title="Travelouges and blogs from my trip around Australia" href='nerdseyeview.php'>Nerd's Eye View</a></li>
<li><div class='activemenu'>Outback NSW</div></li>
<li><a title="Alice Springs and surrounds" href='redcentre.php'>The Red Centre</a></li>
<li> </li><br><li>Or go back to:</li><li><a title='Travel stories and pictures' href="travel.php">Travelogues</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>Outback NSW</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Travel stories and pictures' href="travel.php">Travelogues</a> > <a title='Warrumbungle, Kings Plains and Bald Rock National Parks' href="outbackNSW.php">Outback NSW</a>
<br><br>		


<div id="gmap_div" style="border: 0px none ; margin: 3px; padding: 0px; width: 400px; height: 700px; float: right; vertical-align: text-top;"></div>

<p>Frighteningly, it's been roughly two years since I started my <a href="nerdseyeview.php">Nerds Eye trip around Australia</a>. Time flies at a frightening rate.</p>

<p>Anyway, it was time to crack out the walking shoes and camera (with shiny new super-expensive <a href="http://www.canon.com.au/products/visual/cameras_lenses_accessories/telephoto_zoom_lenses/ef_70-200mm2.8lisusm.aspx" target="_blank">70-200 f/2.8 L glass</a>) and explore a bit of the world that I missed on that trip - outback NSW.</p>

<p>Unfortunately time constraints meant that "exploring the NSW outback" actually translated to "visiting 3 national parks in 3 days", but they were goodies.</p>

<h2>Day 1.</h2>

<p>After leaving from Katoomba in the Blue Mountains, we headed to <a href="http://www.nationalparks.nsw.gov.au/parks.nsf/ParkContent/N0035?Opendocument&ParkKey=N0035&Type=xo" target="_blank">Warrumbungle National Park</a> (not to be confused with the <a href="gowest.php">Bungle Bungle Range</a>, a.k.a. <a href="http://www.environment.gov.au/heritage/worldheritage/sites/purnululu/index.html" target="_blank">Purnululu National Park</a>, which is roughly 2600km away and in a <a href="http://www.australia.gov.au/about-australia-13time" target="_blank">different time zone</a>). After a pleasant day's driving we made it to Coonabarabran just in time for everything to be shut, including the supermarket we'd foolishly banked on for supplies.</p>

<p>As a result the evening's dinner (of the worst kind of instant noodles) was less than grand, but the drive into the park beforehand at dusk, with mobs of Eastern Grey Kangaroos everywhere was, in contrast, lovely.</p>

<p>We got a pretty good night's sleep in the Nerdseyeviewmobile, despite the intense glare of the full moon waking us frequently, and in the morning we set out on the Breadknife and Grand High Tops circuit walk, probably the park's premier attraction.</p>

<p>It is a really lovely walk, and the day was perfect - not hot, and an ultra-blue sky. We spotted quite a few birds and my new lens got a good workout. Daniel had also lent me his 2x teleconverter so I managed to get some extra-zoomy shots too.</p>

<p>The view from the Grand High Tops is quite spectacular, and well worth the climb. It's not too strenuous either if you're used to walking a little, but if you're not feeling like an extra long walk then don't take the long (15km) circuit back to the car park like we did. It turned out to take a wee bit longer than we'd anticipated and, although the extra scenery was quite lovely, it put us a bit behind schedule.</p>

<p>As a result, it got dark on us before we got to the place we'd anticipated spending the night, so we stopped for the night in a little town called Bingara along the way. It was a nice drive though, and at dusk on some back roads we saw a flock of <a href="http://en.wikipedia.org/wiki/Cockatiel" target="_blank">Cockatiels</a> (as nature intened them) and some <a href="intothenevernever.php?fileId=IMG_5628.JPG">Apostlebirds</a> (which I'd already seen but Jana hadn't).</p>

<h2>Day 2.</h2>

<p>We got an early start and headed on, through Inverell, to <a href="http://www.nationalparks.nsw.gov.au/parks.nsf/ParkContent/N0067?Opendocument&ParkKey=N0067&Type=xo" target="_blank">Kings Plains National Park</a>. This lesser known, out of the way spot is actually rather lovely. There's not a lot to do there, but there is one nice walk along Kings Plains Creek, and if you're travelling and want somewhere to stay that isn't crowded it's perfect. There's also permanent water there, so despite the lack of rain the river, whilst not flowing, was a pleasant collection of pools.</p>

<p>Anyway we had lunch there and went for a shortish walk before moving on to our next destination, <a href="http://www.nationalparks.nsw.gov.au/parks.nsf/parkContent/N0001?OpenDocument" target="_blank">Bald Rock National Park</a>.</p>

<p>Unfortunately we hit a snag along the way. We must have hit a pretty sharp rock or a piece of steel in the dirt road, because one of the back tyres popped on us shortly after leaving Kings Plains.</p>

<p>After the obligatory amount of cursing I put the spare on and we limped into Glen Innes for a repair. In true Murphy fashion, the tyre was too ripped up to be patched, so I forked out for a new one, only to discover that there was an issue with the wheel nuts and studs, which meant they couldn't get the spare off without breaking them. Not wanting to spent a night in the fabulous town of Glen Innes, we decided to keep the spare on and risk getting back with it.</p>

<p>(A month on, and it's still on the car, and the brand new tyre hasn't ever touched tarmac - I must get that seen to soon!)</p>

<p>Anyway after the enjoyable experience of standing in the car park of the tyre shop, as trucks loaded with cattle steamed past smelling of urine, we were underway again, and made it to Bald Rock just in time to set up camp and have dinner before it got dark on us.</p>

<p>We also had enough time to go and walk to the base of the rock, which is actually quite an impressively <a href="http://en.wikipedia.org/wiki/Granite_Belt%2C_Queensland" target="_blank">massive piece of granite</a>. In fact, according to the website, at 750 metres long, 500 metres wide and 200 metres high, it's the largest granite rock in Australia.</p>

<h2>Day 3.</h2>

<p>After another moonlit night (alas, no star trail pictures this trip!), we walked to the summit of the rock via the long route, then came down via the shorter, steeper route. It's a fantastic walk, and if you're in the area I totally recommend it. On the way up the track winds through piles of massive granite boulders before opening out up the top with a fantastic view of the national park all around.</p>

<p>Bald Rock National Park is actually right on the border of New South Wales and Queensland, and the park continues across the border under the different name of <a href="http://www.epa.qld.gov.au/projects/park/index.cgi?parkid=111" target="_blank">Girraween National Park</a>. There's no way to drive directly from one half to the other, although I believe you can walk it.</p>

<p>Because of this closeness, we decided to check out Girraween, especially as Jana was after a particular type of bird (Diamond Firetail) that a friend of hers had spotted there. Because we had the car and time constraints though, we decided to drive.</p>

<p>The only problem is, there's not a direct route across the border by car. The main way involves detouring quite a lot through Stanthorpe, but we were armed with a GPS, so we decided to try and find a back way through.</p>

<p>Previously, employing this trust in the GPS and its outdated maps had resulted in a <a href="pinnaclesandpinnipeds.php">jolly cross-country jaunt in Western Australia</a>, and this turned out to be a similar such adventure, only this time there was actually no way through in the end. The roads eventually petered out <a href="?fileId=IMG_5077.JPG">to</a> <a href="?fileId=IMG_5080.JPG">nothing</a>, although, amusingly, there were street signs present at every intersection, despite the two metre high grass growing in all directions.</p>

<p>Eventually we gave up on the back roads and slipped through Stanthorpe, grabbing lunch along the way, and in the afternoon we finally explored some of Girraween National Park. It was quite lovely, and while Jana didn't spot her Firetails we had a nice walk, watched a variety of little birds have their evening bath, and then called it quits and headed for home.</p>

<p>As always, thanks go out to everyone who let me invade their house when I was in Sydney, and especially to Dan for lending me his teleconverter and fisheye lens.</p>

<p>Now, go peruse the endless pictures below. :)</p>

   <script type="text/javascript">
    //<![CDATA[
    function load() {
      if (GBrowserIsCompatible()) {
        var map = new GMap2(document.getElementById("gmap_div"));
		map.setCenter(new GLatLng(-30.61768415,151.00317475), 7, G_HYBRID_MAP);
		map.addControl(new GLargeMapControl());
		map.addControl(new GScaleControl());
		map.addControl(new GMapTypeControl());

		var polyline = new GPolyline([
					new GLatLng(-33.6967635,150.555675),
					new GLatLng(-33.6917424,150.543294),
					new GLatLng(-33.7111616,150.5219865),
					new GLatLng(-33.7167835,150.4977822),
					new GLatLng(-33.732748,150.4872465),
					new GLatLng(-33.7336493,150.4671836),
					new GLatLng(-33.7201953,150.4502964),
					new GLatLng(-33.7279415,150.3893566),
					new GLatLng(-33.7095737,150.3734565),
					new GLatLng(-33.7060118,150.3197265),
					new GLatLng(-33.7115693,150.3138256),
					new GLatLng(-33.7030935,150.2906513),
					new GLatLng(-33.663311,150.2779269),
					new GLatLng(-33.6276054,150.2843213),
					new GLatLng(-33.5954618,150.2635717),
					new GLatLng(-33.5800982,150.2383375),
					new GLatLng(-33.5820079,150.2247548),
					new GLatLng(-33.5359597,150.1567125),
					new GLatLng(-33.5142016,150.1425076),
					new GLatLng(-33.5166049,150.1224875),
					new GLatLng(-33.4799767,150.1364779),
					new GLatLng(-33.4733891,150.1247406),
					new GLatLng(-33.4009051,150.0931334),
					new GLatLng(-33.3951974,150.0799799),
					new GLatLng(-33.3674097,150.0700235),
					new GLatLng(-33.3476472,150.0379014),
					new GLatLng(-33.2609153,150.0385237),
					new GLatLng(-33.1506014,149.9921966),
					new GLatLng(-33.1280065,149.962585),
					new GLatLng(-33.0989313,149.9578428),
					new GLatLng(-33.0659509,149.9352694),
					new GLatLng(-33.0462098,149.9034476),
					new GLatLng(-33.0272841,149.8987055),
					new GLatLng(-33.0178428,149.8716259),
					new GLatLng(-32.9910636,149.8563051),
					new GLatLng(-32.9392862,149.8584938),
					new GLatLng(-32.9080868,149.8377228),
					new GLatLng(-32.8862,149.8067594),
					new GLatLng(-32.8423405,149.804914),
					new GLatLng(-32.8207755,149.8143339),
					new GLatLng(-32.7817011,149.7910953),
					new GLatLng(-32.7771306,149.7705388),
					new GLatLng(-32.7550936,149.7687149),
					new GLatLng(-32.7379274,149.7476435),
					new GLatLng(-32.7241087,149.7532439),
					new GLatLng(-32.6794338,149.6909523),
					new GLatLng(-32.6516891,149.668529),
					new GLatLng(-32.6396728,149.6388531),
					new GLatLng(-32.6007485,149.5968604),
					new GLatLng(-32.5986671,149.5822692),
					new GLatLng(-32.5905561,149.5836425),
					new GLatLng(-32.5541854,149.5451903),
					new GLatLng(-32.4768734,149.5061374),
					new GLatLng(-32.3669672,149.5318007),
					new GLatLng(-32.3406601,149.4797015),
					new GLatLng(-32.2941184,149.4466996),
					new GLatLng(-32.2108412,149.4262934),
					new GLatLng(-32.1605444,149.4371939),
					new GLatLng(-32.0985961,149.4848514),
					new GLatLng(-32.0373344,149.4770622),
					new GLatLng(-32.0357466,149.4909668),
					new GLatLng(-32.0147395,149.5160294),
					new GLatLng(-32.0151043,149.5525503),
					new GLatLng(-31.9775319,149.6092629),
					new GLatLng(-31.9724894,149.6337032),
					new GLatLng(-31.9351101,149.6499467),
					new GLatLng(-31.8989539,149.6865106),
					new GLatLng(-31.8647504,149.6918106),
					new GLatLng(-31.8106556,149.7295117),
					new GLatLng(-31.7882538,149.7132897),
					new GLatLng(-31.7354465,149.7038054),
					new GLatLng(-31.6824245,149.6597958),
					new GLatLng(-31.6542292,149.5991349),
					new GLatLng(-31.5981388,149.5166945),
					new GLatLng(-31.5780973,149.4611621),
					new GLatLng(-31.5888262,149.4102216),
					new GLatLng(-31.5831614,149.3944716),
					new GLatLng(-31.5558672,149.3781424),
					new GLatLng(-31.5357828,149.3804169),
					new GLatLng(-31.5087676,149.359045),
					new GLatLng(-31.4892626,149.3581009),
					new GLatLng(-31.4839196,149.3468571),
					new GLatLng(-31.4262843,149.3249059),
					new GLatLng(-31.4094186,149.3341112),
					new GLatLng(-31.3183522,149.3080616),
					new GLatLng(-31.2722397,149.2767549),
					new GLatLng(-31.2676692,149.2431951),
					new GLatLng(-31.2781191,149.2062235),
					new GLatLng(-31.2578845,149.1186976),
					new GLatLng(-31.2827539,149.0897083),
					new GLatLng(-31.2891912,149.039948),
					new GLatLng(-31.3059711,149.0259147),
					new GLatLng(-31.2772608,148.9905524),
					new GLatLng(-31.2768531,148.9977622),
					new GLatLng(-31.2772608,148.9906383),
					new GLatLng(-31.3325572,148.9962816),
					new GLatLng(-31.3312697,148.9825058),
					new GLatLng(-31.3195109,148.9753389),
					new GLatLng(-31.3057137,148.9946079),
					new GLatLng(-31.2889123,148.995831),
					new GLatLng(-31.3059068,149.0260434),
					new GLatLng(-31.2889552,149.0405273),
					new GLatLng(-31.2826681,149.0897298),
					new GLatLng(-31.2579274,149.1188264),
					new GLatLng(-31.2779903,149.2065454),
					new GLatLng(-31.2676692,149.2432594),
					new GLatLng(-31.2733126,149.2791581),
					new GLatLng(-31.266489,149.2767119),
					new GLatLng(-31.2182736,149.375031),
					new GLatLng(-31.2016654,149.4590807),
					new GLatLng(-31.1150837,149.5663047),
					new GLatLng(-31.1200833,149.7088051),
					new GLatLng(-31.1089683,149.7314644),
					new GLatLng(-31.1166286,149.8045063),
					new GLatLng(-31.0946774,149.8562193),
					new GLatLng(-31.1016297,149.9365783),
					new GLatLng(-31.0105205,150.0844646),
					new GLatLng(-30.9823036,150.1746726),
					new GLatLng(-30.9851146,150.2158284),
					new GLatLng(-30.9749436,150.2527785),
					new GLatLng(-30.8609605,150.3237391),
					new GLatLng(-30.8491158,150.341785),
					new GLatLng(-30.7544875,150.3596163),
					new GLatLng(-30.7162499,150.3862667),
					new GLatLng(-30.7084823,150.4158354),
					new GLatLng(-30.6778836,150.440383),
					new GLatLng(-30.6526923,150.4936838),
					new GLatLng(-30.6206989,150.5152702),
					new GLatLng(-30.5847788,150.4863238),
					new GLatLng(-30.5033684,150.508554),
					new GLatLng(-30.5049133,150.5249262),
					new GLatLng(-30.4348969,150.5831838),
					new GLatLng(-30.4354978,150.5936122),
					new GLatLng(-30.413332,150.6185031),
					new GLatLng(-30.3686357,150.6044269),
					new GLatLng(-30.2448893,150.5895352),
					new GLatLng(-30.2362633,150.5796432),
					new GLatLng(-30.2112007,150.5793428),
					new GLatLng(-30.1928115,150.5898142),
					new GLatLng(-30.1159286,150.5942559),
					new GLatLng(-30.0886989,150.613482),
					new GLatLng(-30.0444961,150.5939341),
					new GLatLng(-29.969995,150.6004357),
					new GLatLng(-29.9311566,150.5818319),
					new GLatLng(-29.8666978,150.5709958),
					new GLatLng(-29.8641014,150.5783558),
					new GLatLng(-29.840498,150.5633569),
					new GLatLng(-29.8099422,150.5614686),
					new GLatLng(-29.801724,150.5702448),
					new GLatLng(-29.8034191,150.5993414),
					new GLatLng(-29.7905231,150.6278801),
					new GLatLng(-29.7970247,150.6585646),
					new GLatLng(-29.7873688,150.7023382),
					new GLatLng(-29.7582936,150.7470345),
					new GLatLng(-29.7291756,150.7668614),
					new GLatLng(-29.7007442,150.8055496),
					new GLatLng(-29.6526575,150.8270073),
					new GLatLng(-29.7099066,150.8885694),
					new GLatLng(-29.7152495,150.9239531),
					new GLatLng(-29.7367716,150.9648728),
					new GLatLng(-29.7318792,150.9797645),
					new GLatLng(-29.7556973,151.0509181),
					new GLatLng(-29.7723055,151.0741138),
					new GLatLng(-29.7743654,151.1101842),
					new GLatLng(-29.7757387,151.1032534),
					new GLatLng(-29.7646022,151.1031032),
					new GLatLng(-29.7640657,151.1223936),
					new GLatLng(-29.7431231,151.1436796),
					new GLatLng(-29.7292829,151.1428428),
					new GLatLng(-29.7007871,151.1763597),
					new GLatLng(-29.7293258,151.1426711),
					new GLatLng(-29.7676706,151.1205053),
					new GLatLng(-29.762435,151.1692572),
					new GLatLng(-29.7500539,151.1772394),
					new GLatLng(-29.736557,151.2109065),
					new GLatLng(-29.7110224,151.2216997),
					new GLatLng(-29.688642,151.2849998),
					new GLatLng(-29.6953368,151.3169074),
					new GLatLng(-29.6743941,151.3701224),
					new GLatLng(-29.6580863,151.3760233),
					new GLatLng(-29.6471643,151.3963866),
					new GLatLng(-29.6507478,151.4058709),
					new GLatLng(-29.6412206,151.4265132),
					new GLatLng(-29.5973611,151.4262557),
					new GLatLng(-29.5994854,151.4042187),
					new GLatLng(-29.5836496,151.3854003),
					new GLatLng(-29.5996141,151.4045191),
					new GLatLng(-29.597404,151.4262772),
					new GLatLng(-29.6308351,151.4204192),
					new GLatLng(-29.6411991,151.4265347),
					new GLatLng(-29.635191,151.4467263),
					new GLatLng(-29.6457481,151.4717031),
					new GLatLng(-29.6379805,151.5664387),
					new GLatLng(-29.6583009,151.5810728),
					new GLatLng(-29.6472073,151.6057277),
					new GLatLng(-29.6573997,151.6143322),
					new GLatLng(-29.6621847,151.6395664),
					new GLatLng(-29.6868396,151.6650367),
					new GLatLng(-29.6882987,151.6866875),
					new GLatLng(-29.7242188,151.7233801),
					new GLatLng(-29.7266436,151.7400956),
					new GLatLng(-29.7334242,151.73913),
					new GLatLng(-29.700079,151.7462754),
					new GLatLng(-29.6626568,151.7759943),
					new GLatLng(-29.6294832,151.8537784),
					new GLatLng(-29.5973611,151.8716311),
					new GLatLng(-29.5581365,151.8598509),
					new GLatLng(-29.4934845,151.8615675),
					new GLatLng(-29.4486165,151.8416548),
					new GLatLng(-29.3653393,151.8987966),
					new GLatLng(-29.3368435,151.8946552),
					new GLatLng(-29.2922544,151.9585347),
					new GLatLng(-29.2321515,152.0070505),
					new GLatLng(-29.2028832,152.0138955),
					new GLatLng(-29.1152072,151.9960427),
					new GLatLng(-29.0455985,152.020762),
					new GLatLng(-29.0089917,152.0540857),
					new GLatLng(-28.9758182,152.0682907),
					new GLatLng(-28.960948,152.0903707),
					new GLatLng(-28.9407134,152.0902419),
					new GLatLng(-28.9238906,152.1043181),
					new GLatLng(-28.850441,152.1036959),
					new GLatLng(-28.8386607,152.0932889),
					new GLatLng(-28.8446045,152.0451593),
					new GLatLng(-28.8529944,152.0512748),
					new GLatLng(-28.8525867,152.0397305),
					new GLatLng(-28.8384891,152.0629907),
					new GLatLng(-28.8386393,152.0935464),
					new GLatLng(-28.7552977,152.0913577),
					new GLatLng(-28.7448692,152.0797276),
					new GLatLng(-28.709507,152.1032453),
					new GLatLng(-28.6874914,152.0840836),
					new GLatLng(-28.6985421,152.0461464),
					new GLatLng(-28.7294626,152.0452237),
					new GLatLng(-28.6994004,152.0474768),
					new GLatLng(-28.6903453,152.0256543),
					new GLatLng(-28.6957526,152.0025873),
					new GLatLng(-28.7101507,152.003746),
					new GLatLng(-28.7093997,151.9971156),
					new GLatLng(-28.7099576,152.0038104),
					new GLatLng(-28.696332,152.0034671),
					new GLatLng(-28.6854959,151.9902921),
					new GLatLng(-28.6852598,151.9602299),
					new GLatLng(-28.6635447,151.9331932),
					new GLatLng(-28.6558628,151.934073),
					new GLatLng(-28.7944365,151.8380928),
					new GLatLng(-28.8591099,151.8595505),
					new GLatLng(-28.8470292,151.9102979),
					new GLatLng(-28.8262582,151.9507456),
					new GLatLng(-28.8280821,151.9736838),
					new GLatLng(-28.8376093,151.9800997),
					new GLatLng(-28.8279963,151.9735765),
					new GLatLng(-28.8264513,151.9502735),
					new GLatLng(-28.8472652,151.9099116),
					new GLatLng(-28.8593245,151.8598294),
					new GLatLng(-28.8264513,151.8540788),
					new GLatLng(-28.8207006,151.8447447),
					new GLatLng(-28.7927628,151.8381786),
					new GLatLng(-28.6815262,151.9193745),
					new GLatLng(-28.6539102,151.9179797),
					new GLatLng(-28.630929,151.9541574),
					new GLatLng(-28.5275245,151.9505525),
					new GLatLng(-28.4961748,151.9674397),
					new GLatLng(-28.4308791,151.9457245),
					new GLatLng(-28.4038639,151.9106197),
					new GLatLng(-28.3843803,151.9110274),
					new GLatLng(-28.3738017,151.9228506),
					new GLatLng(-28.3220029,151.9191813),
					new GLatLng(-28.2895374,151.9392014),
					new GLatLng(-28.2740664,152.0047331),
					new GLatLng(-28.2187915,152.0201612),
					new GLatLng(-28.2202291,152.0341945),
					new GLatLng(-28.1911325,152.0458245),
					new GLatLng(-28.158946,152.0739126),
					new GLatLng(-28.1225967,152.0679045),
					new GLatLng(-28.0785656,152.1587348),
					new GLatLng(-28.0555201,152.2653794),
					new GLatLng(-28.0643392,152.3564458),
					new GLatLng(-28.0483317,152.3899841),
					new GLatLng(-28.0607557,152.4186301),
					new GLatLng(-28.0288696,152.4761796),
					new GLatLng(-28.0195785,152.5178504),
					new GLatLng(-27.9947305,152.5343943),
					new GLatLng(-27.9672217,152.575593),
					new GLatLng(-27.8759837,152.6160836),
					new GLatLng(-27.8197646,152.6169634),
					new GLatLng(-27.7943802,152.6294303),
					new GLatLng(-27.7835655,152.6471329),
					new GLatLng(-27.6897311,152.672689),
					new GLatLng(-27.6579523,152.6952624),
					new GLatLng(-27.6650548,152.7486706),
					new GLatLng(-27.6317525,152.8137517),
					new GLatLng(-27.5960255,152.8370976),
					new GLatLng(-27.6042867,152.8654861),
					new GLatLng(-27.6004672,152.8840685),
					new GLatLng(-27.6089644,152.9003978),
					new GLatLng(-27.6044154,152.9176068),
					new GLatLng(-27.5852108,152.9291511),
					new GLatLng(-27.5564575,153.0078149),
					new GLatLng(-27.501719,153.0310106)
			], "#FFFF00",3,0.8);
			map.addOverlay(polyline);
		} else {
				document.getElementById('gmap_div').style.backgroundColor = '#DDDDDD';
				document.getElementById('gmap_div').innerHTML = 'Sorry, your Google Map cannot be displayed.';
		}
    }

    //]]>
    </script>
<br><br>
All images in this gallery:<br>
<table width='800'>
<tr>
</tr>
<tr><td><A ID='IMG_4636.JPG' href='outbackNSW.php?fileId=IMG_4636.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_4636.JPG' ALT='IMG_4636.JPG'><BR>IMG_4636.JPG<br>50.12 KB</a><div class='inv'><br><a href='./images/20070404/IMG_4636.JPG' ALT='IMG_4636.JPG'>IMG_4636.JPG</a></div></td>
<td><A ID='IMG_4637.JPG' href='outbackNSW.php?fileId=IMG_4637.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_4637.JPG' ALT='IMG_4637.JPG'><BR>IMG_4637.JPG<br>57.19 KB</a><div class='inv'><br><a href='./images/20070404/IMG_4637.JPG' ALT='IMG_4637.JPG'>IMG_4637.JPG</a></div></td>
<td><A ID='IMG_4638.JPG' href='outbackNSW.php?fileId=IMG_4638.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_4638.JPG' ALT='IMG_4638.JPG'><BR>IMG_4638.JPG<br>37.49 KB</a><div class='inv'><br><a href='./images/20070404/IMG_4638.JPG' ALT='IMG_4638.JPG'>IMG_4638.JPG</a></div></td>
<td><A ID='IMG_4641.JPG' href='outbackNSW.php?fileId=IMG_4641.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_4641.JPG' ALT='IMG_4641.JPG'><BR>IMG_4641.JPG<br>79.38 KB</a><div class='inv'><br><a href='./images/20070404/IMG_4641.JPG' ALT='IMG_4641.JPG'>IMG_4641.JPG</a></div></td>
<td><A ID='IMG_4642.JPG' href='outbackNSW.php?fileId=IMG_4642.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_4642.JPG' ALT='IMG_4642.JPG'><BR>IMG_4642.JPG<br>92.51 KB</a><div class='inv'><br><a href='./images/20070404/IMG_4642.JPG' ALT='IMG_4642.JPG'>IMG_4642.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_4645.JPG' href='outbackNSW.php?fileId=IMG_4645.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_4645.JPG' ALT='IMG_4645.JPG'><BR>IMG_4645.JPG<br>67.67 KB</a><div class='inv'><br><a href='./images/20070404/IMG_4645.JPG' ALT='IMG_4645.JPG'>IMG_4645.JPG</a></div></td>
<td><A ID='IMG_4647.JPG' href='outbackNSW.php?fileId=IMG_4647.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_4647.JPG' ALT='IMG_4647.JPG'><BR>IMG_4647.JPG<br>64.61 KB</a><div class='inv'><br><a href='./images/20070404/IMG_4647.JPG' ALT='IMG_4647.JPG'>IMG_4647.JPG</a></div></td>
<td><A ID='IMG_4650.JPG' href='outbackNSW.php?fileId=IMG_4650.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_4650.JPG' ALT='IMG_4650.JPG'><BR>IMG_4650.JPG<br>60.01 KB</a><div class='inv'><br><a href='./images/20070404/IMG_4650.JPG' ALT='IMG_4650.JPG'>IMG_4650.JPG</a></div></td>
<td><A ID='IMG_4655.JPG' href='outbackNSW.php?fileId=IMG_4655.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_4655.JPG' ALT='IMG_4655.JPG'><BR>IMG_4655.JPG<br>28.34 KB</a><div class='inv'><br><a href='./images/20070404/IMG_4655.JPG' ALT='IMG_4655.JPG'>IMG_4655.JPG</a></div></td>
<td><A ID='IMG_4663.JPG' href='outbackNSW.php?fileId=IMG_4663.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_4663.JPG' ALT='Torresian Crow'><BR>Torresian Crow<br>64.67 KB</a><div class='inv'><br><a href='./images/20070404/IMG_4663.JPG' ALT='Torresian Crow'>Torresian Crow</a></div></td>
</tr>
<tr><td><A ID='IMG_4680_crop.JPG' href='outbackNSW.php?fileId=IMG_4680_crop.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_4680_crop.JPG' ALT='Yellow-tufted Honeyeater'><BR>Yellow-tufted Honeyeater<br>71.24 KB</a><div class='inv'><br><a href='./images/20070404/IMG_4680_crop.JPG' ALT='Yellow-tufted Honeyeater'>Yellow-tufted Honeyeater</a></div></td>
<td><A ID='IMG_4681_crop.JPG' href='outbackNSW.php?fileId=IMG_4681_crop.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_4681_crop.JPG' ALT='Yellow-tufted Honeyeater'><BR>Yellow-tufted Honeyeater<br>71.32 KB</a><div class='inv'><br><a href='./images/20070404/IMG_4681_crop.JPG' ALT='Yellow-tufted Honeyeater'>Yellow-tufted Honeyeater</a></div></td>
<td><A ID='IMG_4687_crop.JPG' href='outbackNSW.php?fileId=IMG_4687_crop.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_4687_crop.JPG' ALT='Eastern Yellow Robin'><BR>Eastern Yellow Robin<br>62.52 KB</a><div class='inv'><br><a href='./images/20070404/IMG_4687_crop.JPG' ALT='Eastern Yellow Robin'>Eastern Yellow Robin</a></div></td>
<td><A ID='IMG_4696_crop.JPG' href='outbackNSW.php?fileId=IMG_4696_crop.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_4696_crop.JPG' ALT='Turquoise Parrot'><BR>Turquoise Parrot<br>70.5 KB</a><div class='inv'><br><a href='./images/20070404/IMG_4696_crop.JPG' ALT='Turquoise Parrot'>Turquoise Parrot</a></div></td>
<td><A ID='IMG_4708.JPG' href='outbackNSW.php?fileId=IMG_4708.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_4708.JPG' ALT='IMG_4708.JPG'><BR>IMG_4708.JPG<br>71.87 KB</a><div class='inv'><br><a href='./images/20070404/IMG_4708.JPG' ALT='IMG_4708.JPG'>IMG_4708.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_4715.JPG' href='outbackNSW.php?fileId=IMG_4715.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_4715.JPG' ALT='Brown Treecreeper'><BR>Brown Treecreeper<br>75.21 KB</a><div class='inv'><br><a href='./images/20070404/IMG_4715.JPG' ALT='Brown Treecreeper'>Brown Treecreeper</a></div></td>
<td><A ID='IMG_4722.JPG' href='outbackNSW.php?fileId=IMG_4722.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_4722.JPG' ALT='Eastern Grey Kangaroo'><BR>Eastern Grey Kangaroo<br>95.94 KB</a><div class='inv'><br><a href='./images/20070404/IMG_4722.JPG' ALT='Eastern Grey Kangaroo'>Eastern Grey Kangaroo</a></div></td>
<td><A ID='IMG_4723.JPG' href='outbackNSW.php?fileId=IMG_4723.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_4723.JPG' ALT='Eastern Grey Kangaroo'><BR>Eastern Grey Kangaroo<br>99.12 KB</a><div class='inv'><br><a href='./images/20070404/IMG_4723.JPG' ALT='Eastern Grey Kangaroo'>Eastern Grey Kangaroo</a></div></td>
<td><A ID='IMG_4726.JPG' href='outbackNSW.php?fileId=IMG_4726.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_4726.JPG' ALT='IMG_4726.JPG'><BR>IMG_4726.JPG<br>61.83 KB</a><div class='inv'><br><a href='./images/20070404/IMG_4726.JPG' ALT='IMG_4726.JPG'>IMG_4726.JPG</a></div></td>
<td><A ID='IMG_4731.JPG' href='outbackNSW.php?fileId=IMG_4731.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_4731.JPG' ALT='IMG_4731.JPG'><BR>IMG_4731.JPG<br>62.89 KB</a><div class='inv'><br><a href='./images/20070404/IMG_4731.JPG' ALT='IMG_4731.JPG'>IMG_4731.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_4733.JPG' href='outbackNSW.php?fileId=IMG_4733.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_4733.JPG' ALT='IMG_4733.JPG'><BR>IMG_4733.JPG<br>88.96 KB</a><div class='inv'><br><a href='./images/20070404/IMG_4733.JPG' ALT='IMG_4733.JPG'>IMG_4733.JPG</a></div></td>
<td><A ID='IMG_4734.JPG' href='outbackNSW.php?fileId=IMG_4734.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_4734.JPG' ALT='IMG_4734.JPG'><BR>IMG_4734.JPG<br>123.92 KB</a><div class='inv'><br><a href='./images/20070404/IMG_4734.JPG' ALT='IMG_4734.JPG'>IMG_4734.JPG</a></div></td>
<td><A ID='IMG_4736.JPG' href='outbackNSW.php?fileId=IMG_4736.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_4736.JPG' ALT='IMG_4736.JPG'><BR>IMG_4736.JPG<br>84.76 KB</a><div class='inv'><br><a href='./images/20070404/IMG_4736.JPG' ALT='IMG_4736.JPG'>IMG_4736.JPG</a></div></td>
<td><A ID='IMG_4739_crop.JPG' href='outbackNSW.php?fileId=IMG_4739_crop.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_4739_crop.JPG' ALT='Speckled Warbler'><BR>Speckled Warbler<br>69.05 KB</a><div class='inv'><br><a href='./images/20070404/IMG_4739_crop.JPG' ALT='Speckled Warbler'>Speckled Warbler</a></div></td>
<td><A ID='IMG_4745.JPG' href='outbackNSW.php?fileId=IMG_4745.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_4745.JPG' ALT='The Breadknife, Warrumbungle National Park'><BR>The Breadknife, Warrumbungle National Park<br>127.24 KB</a><div class='inv'><br><a href='./images/20070404/IMG_4745.JPG' ALT='The Breadknife, Warrumbungle National Park'>The Breadknife, Warrumbungle National Park</a></div></td>
</tr>
<tr><td><A ID='IMG_4746.JPG' href='outbackNSW.php?fileId=IMG_4746.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_4746.JPG' ALT='The Breadknife, Warrumbungle National Park'><BR>The Breadknife, Warrumbungle National Park<br>130.85 KB</a><div class='inv'><br><a href='./images/20070404/IMG_4746.JPG' ALT='The Breadknife, Warrumbungle National Park'>The Breadknife, Warrumbungle National Park</a></div></td>
<td><A ID='IMG_4749.JPG' href='outbackNSW.php?fileId=IMG_4749.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_4749.JPG' ALT='IMG_4749.JPG'><BR>IMG_4749.JPG<br>84.42 KB</a><div class='inv'><br><a href='./images/20070404/IMG_4749.JPG' ALT='IMG_4749.JPG'>IMG_4749.JPG</a></div></td>
<td><A ID='IMG_4754.JPG' href='outbackNSW.php?fileId=IMG_4754.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_4754.JPG' ALT='IMG_4754.JPG'><BR>IMG_4754.JPG<br>64.09 KB</a><div class='inv'><br><a href='./images/20070404/IMG_4754.JPG' ALT='IMG_4754.JPG'>IMG_4754.JPG</a></div></td>
<td><A ID='IMG_4756.JPG' href='outbackNSW.php?fileId=IMG_4756.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_4756.JPG' ALT='IMG_4756.JPG'><BR>IMG_4756.JPG<br>119.77 KB</a><div class='inv'><br><a href='./images/20070404/IMG_4756.JPG' ALT='IMG_4756.JPG'>IMG_4756.JPG</a></div></td>
<td><A ID='IMG_4760.JPG' href='outbackNSW.php?fileId=IMG_4760.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_4760.JPG' ALT='Grand High Tops, Warrumbungle National Park'><BR>Grand High Tops, Warrumbungle National Park<br>96.18 KB</a><div class='inv'><br><a href='./images/20070404/IMG_4760.JPG' ALT='Grand High Tops, Warrumbungle National Park'>Grand High Tops, Warrumbungle National Park</a></div></td>
</tr>
<tr><td><A ID='IMG_4761.JPG' href='outbackNSW.php?fileId=IMG_4761.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_4761.JPG' ALT='View from the Grand High Tops, Warrumbungle National Park'><BR>View from the Grand High Tops, Warrumbungle National Park<br>83.48 KB</a><div class='inv'><br><a href='./images/20070404/IMG_4761.JPG' ALT='View from the Grand High Tops, Warrumbungle National Park'>View from the Grand High Tops, Warrumbungle National Park</a></div></td>
<td><A ID='IMG_4762_crop.JPG' href='outbackNSW.php?fileId=IMG_4762_crop.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_4762_crop.JPG' ALT='Wedge-tailed Eagle'><BR>Wedge-tailed Eagle<br>25.85 KB</a><div class='inv'><br><a href='./images/20070404/IMG_4762_crop.JPG' ALT='Wedge-tailed Eagle'>Wedge-tailed Eagle</a></div></td>
<td><A ID='IMG_4767.JPG' href='outbackNSW.php?fileId=IMG_4767.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_4767.JPG' ALT='Pied Currawong'><BR>Pied Currawong<br>36.17 KB</a><div class='inv'><br><a href='./images/20070404/IMG_4767.JPG' ALT='Pied Currawong'>Pied Currawong</a></div></td>
<td><A ID='IMG_4769_crop.JPG' href='outbackNSW.php?fileId=IMG_4769_crop.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_4769_crop.JPG' ALT='Wedge-tailed Eagle'><BR>Wedge-tailed Eagle<br>25.13 KB</a><div class='inv'><br><a href='./images/20070404/IMG_4769_crop.JPG' ALT='Wedge-tailed Eagle'>Wedge-tailed Eagle</a></div></td>
<td><A ID='IMG_4772.JPG' href='outbackNSW.php?fileId=IMG_4772.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_4772.JPG' ALT='IMG_4772.JPG'><BR>IMG_4772.JPG<br>87.86 KB</a><div class='inv'><br><a href='./images/20070404/IMG_4772.JPG' ALT='IMG_4772.JPG'>IMG_4772.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_4773.JPG' href='outbackNSW.php?fileId=IMG_4773.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_4773.JPG' ALT='View from the Grand High Tops, Warrumbungle National Park'><BR>View from the Grand High Tops, Warrumbungle National Park<br>72.09 KB</a><div class='inv'><br><a href='./images/20070404/IMG_4773.JPG' ALT='View from the Grand High Tops, Warrumbungle National Park'>View from the Grand High Tops, Warrumbungle National Park</a></div></td>
<td><A ID='IMG_4774.JPG' href='outbackNSW.php?fileId=IMG_4774.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_4774.JPG' ALT='Grand High Tops, Warrumbungle National Park'><BR>Grand High Tops, Warrumbungle National Park<br>68.19 KB</a><div class='inv'><br><a href='./images/20070404/IMG_4774.JPG' ALT='Grand High Tops, Warrumbungle National Park'>Grand High Tops, Warrumbungle National Park</a></div></td>
<td><A ID='IMG_4775.JPG' href='outbackNSW.php?fileId=IMG_4775.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_4775.JPG' ALT='Grand High Tops, Warrumbungle National Park'><BR>Grand High Tops, Warrumbungle National Park<br>75.24 KB</a><div class='inv'><br><a href='./images/20070404/IMG_4775.JPG' ALT='Grand High Tops, Warrumbungle National Park'>Grand High Tops, Warrumbungle National Park</a></div></td>
<td><A ID='IMG_4776.JPG' href='outbackNSW.php?fileId=IMG_4776.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_4776.JPG' ALT='Grand High Tops, Warrumbungle National Park'><BR>Grand High Tops, Warrumbungle National Park<br>76.99 KB</a><div class='inv'><br><a href='./images/20070404/IMG_4776.JPG' ALT='Grand High Tops, Warrumbungle National Park'>Grand High Tops, Warrumbungle National Park</a></div></td>
<td><A ID='IMG_4777.JPG' href='outbackNSW.php?fileId=IMG_4777.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_4777.JPG' ALT='Grand High Tops, Warrumbungle National Park'><BR>Grand High Tops, Warrumbungle National Park<br>73.33 KB</a><div class='inv'><br><a href='./images/20070404/IMG_4777.JPG' ALT='Grand High Tops, Warrumbungle National Park'>Grand High Tops, Warrumbungle National Park</a></div></td>
</tr>
<tr><td><A ID='IMG_4782.JPG' href='outbackNSW.php?fileId=IMG_4782.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_4782.JPG' ALT='Grand High Tops, Warrumbungle National Park'><BR>Grand High Tops, Warrumbungle National Park<br>84.74 KB</a><div class='inv'><br><a href='./images/20070404/IMG_4782.JPG' ALT='Grand High Tops, Warrumbungle National Park'>Grand High Tops, Warrumbungle National Park</a></div></td>
<td><A ID='IMG_4783.JPG' href='outbackNSW.php?fileId=IMG_4783.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_4783.JPG' ALT='Grand High Tops, Warrumbungle National Park'><BR>Grand High Tops, Warrumbungle National Park<br>54.11 KB</a><div class='inv'><br><a href='./images/20070404/IMG_4783.JPG' ALT='Grand High Tops, Warrumbungle National Park'>Grand High Tops, Warrumbungle National Park</a></div></td>
<td><A ID='IMG_4788.JPG' href='outbackNSW.php?fileId=IMG_4788.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_4788.JPG' ALT='Grand High Tops, Warrumbungle National Park'><BR>Grand High Tops, Warrumbungle National Park<br>59.39 KB</a><div class='inv'><br><a href='./images/20070404/IMG_4788.JPG' ALT='Grand High Tops, Warrumbungle National Park'>Grand High Tops, Warrumbungle National Park</a></div></td>
<td><A ID='IMG_4789.JPG' href='outbackNSW.php?fileId=IMG_4789.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_4789.JPG' ALT='View from the Grand High Tops, Warrumbungle National Park'><BR>View from the Grand High Tops, Warrumbungle National Park<br>89.53 KB</a><div class='inv'><br><a href='./images/20070404/IMG_4789.JPG' ALT='View from the Grand High Tops, Warrumbungle National Park'>View from the Grand High Tops, Warrumbungle National Park</a></div></td>
<td><A ID='IMG_4790.JPG' href='outbackNSW.php?fileId=IMG_4790.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_4790.JPG' ALT='View from the Grand High Tops, Warrumbungle National Park'><BR>View from the Grand High Tops, Warrumbungle National Park<br>80.65 KB</a><div class='inv'><br><a href='./images/20070404/IMG_4790.JPG' ALT='View from the Grand High Tops, Warrumbungle National Park'>View from the Grand High Tops, Warrumbungle National Park</a></div></td>
</tr>
<tr><td><A ID='IMG_4792.JPG' href='outbackNSW.php?fileId=IMG_4792.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_4792.JPG' ALT='IMG_4792.JPG'><BR>IMG_4792.JPG<br>108.83 KB</a><div class='inv'><br><a href='./images/20070404/IMG_4792.JPG' ALT='IMG_4792.JPG'>IMG_4792.JPG</a></div></td>
<td><A ID='IMG_4799.JPG' href='outbackNSW.php?fileId=IMG_4799.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_4799.JPG' ALT='Bluff Mountain, Warrumbungle National Park'><BR>Bluff Mountain, Warrumbungle National Park<br>96.99 KB</a><div class='inv'><br><a href='./images/20070404/IMG_4799.JPG' ALT='Bluff Mountain, Warrumbungle National Park'>Bluff Mountain, Warrumbungle National Park</a></div></td>
<td><A ID='IMG_4801.JPG' href='outbackNSW.php?fileId=IMG_4801.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_4801.JPG' ALT='Bluff Mountain, Warrumbungle National Park'><BR>Bluff Mountain, Warrumbungle National Park<br>118.67 KB</a><div class='inv'><br><a href='./images/20070404/IMG_4801.JPG' ALT='Bluff Mountain, Warrumbungle National Park'>Bluff Mountain, Warrumbungle National Park</a></div></td>
<td><A ID='IMG_4802_crop.JPG' href='outbackNSW.php?fileId=IMG_4802_crop.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_4802_crop.JPG' ALT='Common Bronzewing'><BR>Common Bronzewing<br>67.13 KB</a><div class='inv'><br><a href='./images/20070404/IMG_4802_crop.JPG' ALT='Common Bronzewing'>Common Bronzewing</a></div></td>
<td><A ID='IMG_4803.JPG' href='outbackNSW.php?fileId=IMG_4803.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_4803.JPG' ALT='With Circular Polariser'><BR>With Circular Polariser<br>43.49 KB</a><div class='inv'><br><a href='./images/20070404/IMG_4803.JPG' ALT='With Circular Polariser'>With Circular Polariser</a></div></td>
</tr>
<tr><td><A ID='IMG_4804.JPG' href='outbackNSW.php?fileId=IMG_4804.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_4804.JPG' ALT='Without Circular Polariser'><BR>Without Circular Polariser<br>51.31 KB</a><div class='inv'><br><a href='./images/20070404/IMG_4804.JPG' ALT='Without Circular Polariser'>Without Circular Polariser</a></div></td>
<td><A ID='IMG_4805.JPG' href='outbackNSW.php?fileId=IMG_4805.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_4805.JPG' ALT='Bluff Mountain, Warrumbungle National Park'><BR>Bluff Mountain, Warrumbungle National Park<br>86.87 KB</a><div class='inv'><br><a href='./images/20070404/IMG_4805.JPG' ALT='Bluff Mountain, Warrumbungle National Park'>Bluff Mountain, Warrumbungle National Park</a></div></td>
<td><A ID='IMG_4806.JPG' href='outbackNSW.php?fileId=IMG_4806.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_4806.JPG' ALT='Bluff Mountain, Warrumbungle National Park'><BR>Bluff Mountain, Warrumbungle National Park<br>105.44 KB</a><div class='inv'><br><a href='./images/20070404/IMG_4806.JPG' ALT='Bluff Mountain, Warrumbungle National Park'>Bluff Mountain, Warrumbungle National Park</a></div></td>
<td><A ID='IMG_4809.JPG' href='outbackNSW.php?fileId=IMG_4809.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_4809.JPG' ALT='Point Wilderness'><BR>Point Wilderness<br>74.11 KB</a><div class='inv'><br><a href='./images/20070404/IMG_4809.JPG' ALT='Point Wilderness'>Point Wilderness</a></div></td>
<td><A ID='IMG_4810.JPG' href='outbackNSW.php?fileId=IMG_4810.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_4810.JPG' ALT='Point Wilderness'><BR>Point Wilderness<br>98.86 KB</a><div class='inv'><br><a href='./images/20070404/IMG_4810.JPG' ALT='Point Wilderness'>Point Wilderness</a></div></td>
</tr>
<tr><td><A ID='IMG_4814.JPG' href='outbackNSW.php?fileId=IMG_4814.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_4814.JPG' ALT='IMG_4814.JPG'><BR>IMG_4814.JPG<br>109.15 KB</a><div class='inv'><br><a href='./images/20070404/IMG_4814.JPG' ALT='IMG_4814.JPG'>IMG_4814.JPG</a></div></td>
<td><A ID='IMG_4818.JPG' href='outbackNSW.php?fileId=IMG_4818.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_4818.JPG' ALT='IMG_4818.JPG'><BR>IMG_4818.JPG<br>51.12 KB</a><div class='inv'><br><a href='./images/20070404/IMG_4818.JPG' ALT='IMG_4818.JPG'>IMG_4818.JPG</a></div></td>
<td><A ID='IMG_4829.JPG' href='outbackNSW.php?fileId=IMG_4829.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_4829.JPG' ALT='Cockatiels'><BR>Cockatiels<br>89.23 KB</a><div class='inv'><br><a href='./images/20070404/IMG_4829.JPG' ALT='Cockatiels'>Cockatiels</a></div></td>
<td><A ID='IMG_4832_crop.JPG' href='outbackNSW.php?fileId=IMG_4832_crop.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_4832_crop.JPG' ALT='Red-rumped Parrots'><BR>Red-rumped Parrots<br>76.47 KB</a><div class='inv'><br><a href='./images/20070404/IMG_4832_crop.JPG' ALT='Red-rumped Parrots'>Red-rumped Parrots</a></div></td>
<td><A ID='IMG_4835.JPG' href='outbackNSW.php?fileId=IMG_4835.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_4835.JPG' ALT='Cockatiels'><BR>Cockatiels<br>98.54 KB</a><div class='inv'><br><a href='./images/20070404/IMG_4835.JPG' ALT='Cockatiels'>Cockatiels</a></div></td>
</tr>
<tr><td><A ID='IMG_4844.JPG' href='outbackNSW.php?fileId=IMG_4844.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_4844.JPG' ALT='Cockatiels'><BR>Cockatiels<br>46.7 KB</a><div class='inv'><br><a href='./images/20070404/IMG_4844.JPG' ALT='Cockatiels'>Cockatiels</a></div></td>
<td><A ID='IMG_4851.JPG' href='outbackNSW.php?fileId=IMG_4851.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_4851.JPG' ALT='IMG_4851.JPG'><BR>IMG_4851.JPG<br>32.1 KB</a><div class='inv'><br><a href='./images/20070404/IMG_4851.JPG' ALT='IMG_4851.JPG'>IMG_4851.JPG</a></div></td>
<td><A ID='IMG_4859_crop.JPG' href='outbackNSW.php?fileId=IMG_4859_crop.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_4859_crop.JPG' ALT='Restless Flycatcher'><BR>Restless Flycatcher<br>64.57 KB</a><div class='inv'><br><a href='./images/20070404/IMG_4859_crop.JPG' ALT='Restless Flycatcher'>Restless Flycatcher</a></div></td>
<td><A ID='IMG_4860_crop.JPG' href='outbackNSW.php?fileId=IMG_4860_crop.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_4860_crop.JPG' ALT='Restless Flycatcher'><BR>Restless Flycatcher<br>41.65 KB</a><div class='inv'><br><a href='./images/20070404/IMG_4860_crop.JPG' ALT='Restless Flycatcher'>Restless Flycatcher</a></div></td>
<td><A ID='IMG_4869_crop.JPG' href='outbackNSW.php?fileId=IMG_4869_crop.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_4869_crop.JPG' ALT='Scarlet Robin'><BR>Scarlet Robin<br>81.34 KB</a><div class='inv'><br><a href='./images/20070404/IMG_4869_crop.JPG' ALT='Scarlet Robin'>Scarlet Robin</a></div></td>
</tr>
<tr><td><A ID='IMG_4878.JPG' href='outbackNSW.php?fileId=IMG_4878.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_4878.JPG' ALT='IMG_4878.JPG'><BR>IMG_4878.JPG<br>102.4 KB</a><div class='inv'><br><a href='./images/20070404/IMG_4878.JPG' ALT='IMG_4878.JPG'>IMG_4878.JPG</a></div></td>
<td><A ID='IMG_4882.JPG' href='outbackNSW.php?fileId=IMG_4882.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_4882.JPG' ALT='IMG_4882.JPG'><BR>IMG_4882.JPG<br>98.57 KB</a><div class='inv'><br><a href='./images/20070404/IMG_4882.JPG' ALT='IMG_4882.JPG'>IMG_4882.JPG</a></div></td>
<td><A ID='IMG_4889.JPG' href='outbackNSW.php?fileId=IMG_4889.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_4889.JPG' ALT='Kings Plains National Park'><BR>Kings Plains National Park<br>93.97 KB</a><div class='inv'><br><a href='./images/20070404/IMG_4889.JPG' ALT='Kings Plains National Park'>Kings Plains National Park</a></div></td>
<td><A ID='IMG_4891.JPG' href='outbackNSW.php?fileId=IMG_4891.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_4891.JPG' ALT='Kings Plains National Park'><BR>Kings Plains National Park<br>122.3 KB</a><div class='inv'><br><a href='./images/20070404/IMG_4891.JPG' ALT='Kings Plains National Park'>Kings Plains National Park</a></div></td>
<td><A ID='IMG_4893.JPG' href='outbackNSW.php?fileId=IMG_4893.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_4893.JPG' ALT='Kings Plains National Park'><BR>Kings Plains National Park<br>97.22 KB</a><div class='inv'><br><a href='./images/20070404/IMG_4893.JPG' ALT='Kings Plains National Park'>Kings Plains National Park</a></div></td>
</tr>
<tr><td><A ID='IMG_4897.JPG' href='outbackNSW.php?fileId=IMG_4897.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_4897.JPG' ALT='Kings Plains National Park'><BR>Kings Plains National Park<br>100.87 KB</a><div class='inv'><br><a href='./images/20070404/IMG_4897.JPG' ALT='Kings Plains National Park'>Kings Plains National Park</a></div></td>
<td><A ID='IMG_4898.JPG' href='outbackNSW.php?fileId=IMG_4898.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_4898.JPG' ALT='Kings Plains National Park'><BR>Kings Plains National Park<br>101.41 KB</a><div class='inv'><br><a href='./images/20070404/IMG_4898.JPG' ALT='Kings Plains National Park'>Kings Plains National Park</a></div></td>
<td><A ID='IMG_4900.JPG' href='outbackNSW.php?fileId=IMG_4900.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_4900.JPG' ALT='Kings Plains National Park'><BR>Kings Plains National Park<br>106.75 KB</a><div class='inv'><br><a href='./images/20070404/IMG_4900.JPG' ALT='Kings Plains National Park'>Kings Plains National Park</a></div></td>
<td><A ID='IMG_4909.JPG' href='outbackNSW.php?fileId=IMG_4909.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_4909.JPG' ALT='Kings Plains National Park'><BR>Kings Plains National Park<br>89.67 KB</a><div class='inv'><br><a href='./images/20070404/IMG_4909.JPG' ALT='Kings Plains National Park'>Kings Plains National Park</a></div></td>
<td><A ID='IMG_4911.JPG' href='outbackNSW.php?fileId=IMG_4911.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_4911.JPG' ALT='Kings Plains National Park'><BR>Kings Plains National Park<br>93.07 KB</a><div class='inv'><br><a href='./images/20070404/IMG_4911.JPG' ALT='Kings Plains National Park'>Kings Plains National Park</a></div></td>
</tr>
<tr><td><A ID='IMG_4931.JPG' href='outbackNSW.php?fileId=IMG_4931.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_4931.JPG' ALT='Yellow-tufted Honeyeater'><BR>Yellow-tufted Honeyeater<br>71.58 KB</a><div class='inv'><br><a href='./images/20070404/IMG_4931.JPG' ALT='Yellow-tufted Honeyeater'>Yellow-tufted Honeyeater</a></div></td>
<td><A ID='IMG_4935.JPG' href='outbackNSW.php?fileId=IMG_4935.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_4935.JPG' ALT='Eastern Yellow Robin'><BR>Eastern Yellow Robin<br>80.74 KB</a><div class='inv'><br><a href='./images/20070404/IMG_4935.JPG' ALT='Eastern Yellow Robin'>Eastern Yellow Robin</a></div></td>
<td><A ID='IMG_4942.JPG' href='outbackNSW.php?fileId=IMG_4942.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_4942.JPG' ALT='Eastern Yellow Robin'><BR>Eastern Yellow Robin<br>71.7 KB</a><div class='inv'><br><a href='./images/20070404/IMG_4942.JPG' ALT='Eastern Yellow Robin'>Eastern Yellow Robin</a></div></td>
<td><A ID='IMG_4943.JPG' href='outbackNSW.php?fileId=IMG_4943.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_4943.JPG' ALT='Wonga Pigeon'><BR>Wonga Pigeon<br>74.03 KB</a><div class='inv'><br><a href='./images/20070404/IMG_4943.JPG' ALT='Wonga Pigeon'>Wonga Pigeon</a></div></td>
<td><A ID='IMG_4956.JPG' href='outbackNSW.php?fileId=IMG_4956.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_4956.JPG' ALT='IMG_4956.JPG'><BR>IMG_4956.JPG<br>66.71 KB</a><div class='inv'><br><a href='./images/20070404/IMG_4956.JPG' ALT='IMG_4956.JPG'>IMG_4956.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_4960.JPG' href='outbackNSW.php?fileId=IMG_4960.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_4960.JPG' ALT='Bald Rock'><BR>Bald Rock<br>88.04 KB</a><div class='inv'><br><a href='./images/20070404/IMG_4960.JPG' ALT='Bald Rock'>Bald Rock</a></div></td>
<td><A ID='IMG_4974.JPG' href='outbackNSW.php?fileId=IMG_4974.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_4974.JPG' ALT='Laughing Kookaburra'><BR>Laughing Kookaburra<br>65.72 KB</a><div class='inv'><br><a href='./images/20070404/IMG_4974.JPG' ALT='Laughing Kookaburra'>Laughing Kookaburra</a></div></td>
<td><A ID='IMG_4975.JPG' href='outbackNSW.php?fileId=IMG_4975.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_4975.JPG' ALT='Pied Currawong'><BR>Pied Currawong<br>39.99 KB</a><div class='inv'><br><a href='./images/20070404/IMG_4975.JPG' ALT='Pied Currawong'>Pied Currawong</a></div></td>
<td><A ID='IMG_4983_crop.JPG' href='outbackNSW.php?fileId=IMG_4983_crop.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_4983_crop.JPG' ALT='Male Scarlet Robin'><BR>Male Scarlet Robin<br>40.97 KB</a><div class='inv'><br><a href='./images/20070404/IMG_4983_crop.JPG' ALT='Male Scarlet Robin'>Male Scarlet Robin</a></div></td>
<td><A ID='IMG_4986_crop.JPG' href='outbackNSW.php?fileId=IMG_4986_crop.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_4986_crop.JPG' ALT='Female Scarlet Robin'><BR>Female Scarlet Robin<br>49.02 KB</a><div class='inv'><br><a href='./images/20070404/IMG_4986_crop.JPG' ALT='Female Scarlet Robin'>Female Scarlet Robin</a></div></td>
</tr>
<tr><td><A ID='IMG_4991.JPG' href='outbackNSW.php?fileId=IMG_4991.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_4991.JPG' ALT='IMG_4991.JPG'><BR>IMG_4991.JPG<br>59.56 KB</a><div class='inv'><br><a href='./images/20070404/IMG_4991.JPG' ALT='IMG_4991.JPG'>IMG_4991.JPG</a></div></td>
<td><A ID='IMG_4992.JPG' href='outbackNSW.php?fileId=IMG_4992.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_4992.JPG' ALT='Bald Rock National Park'><BR>Bald Rock National Park<br>129.11 KB</a><div class='inv'><br><a href='./images/20070404/IMG_4992.JPG' ALT='Bald Rock National Park'>Bald Rock National Park</a></div></td>
<td><A ID='IMG_4993.JPG' href='outbackNSW.php?fileId=IMG_4993.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_4993.JPG' ALT='Bald Rock National Park'><BR>Bald Rock National Park<br>125.91 KB</a><div class='inv'><br><a href='./images/20070404/IMG_4993.JPG' ALT='Bald Rock National Park'>Bald Rock National Park</a></div></td>
<td><A ID='IMG_4995.JPG' href='outbackNSW.php?fileId=IMG_4995.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_4995.JPG' ALT='Bald Rock'><BR>Bald Rock<br>93.33 KB</a><div class='inv'><br><a href='./images/20070404/IMG_4995.JPG' ALT='Bald Rock'>Bald Rock</a></div></td>
<td><A ID='IMG_5001.JPG' href='outbackNSW.php?fileId=IMG_5001.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_5001.JPG' ALT='Bald Rock'><BR>Bald Rock<br>87.96 KB</a><div class='inv'><br><a href='./images/20070404/IMG_5001.JPG' ALT='Bald Rock'>Bald Rock</a></div></td>
</tr>
<tr><td><A ID='IMG_5002.JPG' href='outbackNSW.php?fileId=IMG_5002.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_5002.JPG' ALT='Bald Rock'><BR>Bald Rock<br>111.76 KB</a><div class='inv'><br><a href='./images/20070404/IMG_5002.JPG' ALT='Bald Rock'>Bald Rock</a></div></td>
<td><A ID='IMG_5008.JPG' href='outbackNSW.php?fileId=IMG_5008.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_5008.JPG' ALT='Bald Rock'><BR>Bald Rock<br>82.77 KB</a><div class='inv'><br><a href='./images/20070404/IMG_5008.JPG' ALT='Bald Rock'>Bald Rock</a></div></td>
<td><A ID='IMG_5009.JPG' href='outbackNSW.php?fileId=IMG_5009.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_5009.JPG' ALT='Bald Rock'><BR>Bald Rock<br>97.7 KB</a><div class='inv'><br><a href='./images/20070404/IMG_5009.JPG' ALT='Bald Rock'>Bald Rock</a></div></td>
<td><A ID='IMG_5012.JPG' href='outbackNSW.php?fileId=IMG_5012.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_5012.JPG' ALT='Bald Rock'><BR>Bald Rock<br>102.86 KB</a><div class='inv'><br><a href='./images/20070404/IMG_5012.JPG' ALT='Bald Rock'>Bald Rock</a></div></td>
<td><A ID='IMG_5013.JPG' href='outbackNSW.php?fileId=IMG_5013.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_5013.JPG' ALT='Bald Rock'><BR>Bald Rock<br>93.42 KB</a><div class='inv'><br><a href='./images/20070404/IMG_5013.JPG' ALT='Bald Rock'>Bald Rock</a></div></td>
</tr>
<tr><td><A ID='IMG_5014.JPG' href='outbackNSW.php?fileId=IMG_5014.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_5014.JPG' ALT='Bald Rock'><BR>Bald Rock<br>90.63 KB</a><div class='inv'><br><a href='./images/20070404/IMG_5014.JPG' ALT='Bald Rock'>Bald Rock</a></div></td>
<td><A ID='IMG_5015.JPG' href='outbackNSW.php?fileId=IMG_5015.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_5015.JPG' ALT='Bald Rock'><BR>Bald Rock<br>109.03 KB</a><div class='inv'><br><a href='./images/20070404/IMG_5015.JPG' ALT='Bald Rock'>Bald Rock</a></div></td>
<td><A ID='IMG_5017.JPG' href='outbackNSW.php?fileId=IMG_5017.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_5017.JPG' ALT='Bald Rock'><BR>Bald Rock<br>116.06 KB</a><div class='inv'><br><a href='./images/20070404/IMG_5017.JPG' ALT='Bald Rock'>Bald Rock</a></div></td>
<td><A ID='IMG_5021.JPG' href='outbackNSW.php?fileId=IMG_5021.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_5021.JPG' ALT='Bald Rock'><BR>Bald Rock<br>85.28 KB</a><div class='inv'><br><a href='./images/20070404/IMG_5021.JPG' ALT='Bald Rock'>Bald Rock</a></div></td>
<td><A ID='IMG_5022.JPG' href='outbackNSW.php?fileId=IMG_5022.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_5022.JPG' ALT='Bald Rock'><BR>Bald Rock<br>80.51 KB</a><div class='inv'><br><a href='./images/20070404/IMG_5022.JPG' ALT='Bald Rock'>Bald Rock</a></div></td>
</tr>
<tr><td><A ID='IMG_5023.JPG' href='outbackNSW.php?fileId=IMG_5023.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_5023.JPG' ALT='Bald Rock'><BR>Bald Rock<br>69.33 KB</a><div class='inv'><br><a href='./images/20070404/IMG_5023.JPG' ALT='Bald Rock'>Bald Rock</a></div></td>
<td><A ID='IMG_5024.JPG' href='outbackNSW.php?fileId=IMG_5024.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_5024.JPG' ALT='Bald Rock'><BR>Bald Rock<br>71.82 KB</a><div class='inv'><br><a href='./images/20070404/IMG_5024.JPG' ALT='Bald Rock'>Bald Rock</a></div></td>
<td><A ID='IMG_5025.JPG' href='outbackNSW.php?fileId=IMG_5025.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_5025.JPG' ALT='Bald Rock'><BR>Bald Rock<br>76.08 KB</a><div class='inv'><br><a href='./images/20070404/IMG_5025.JPG' ALT='Bald Rock'>Bald Rock</a></div></td>
<td><A ID='IMG_5032.JPG' href='outbackNSW.php?fileId=IMG_5032.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_5032.JPG' ALT='Bald Rock'><BR>Bald Rock<br>88.36 KB</a><div class='inv'><br><a href='./images/20070404/IMG_5032.JPG' ALT='Bald Rock'>Bald Rock</a></div></td>
<td><A ID='IMG_5039.JPG' href='outbackNSW.php?fileId=IMG_5039.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_5039.JPG' ALT='Bald Rock'><BR>Bald Rock<br>84.05 KB</a><div class='inv'><br><a href='./images/20070404/IMG_5039.JPG' ALT='Bald Rock'>Bald Rock</a></div></td>
</tr>
<tr><td><A ID='IMG_5040.JPG' href='outbackNSW.php?fileId=IMG_5040.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_5040.JPG' ALT='Bald Rock'><BR>Bald Rock<br>77.46 KB</a><div class='inv'><br><a href='./images/20070404/IMG_5040.JPG' ALT='Bald Rock'>Bald Rock</a></div></td>
<td><A ID='IMG_5041.JPG' href='outbackNSW.php?fileId=IMG_5041.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_5041.JPG' ALT='Bald Rock'><BR>Bald Rock<br>80.5 KB</a><div class='inv'><br><a href='./images/20070404/IMG_5041.JPG' ALT='Bald Rock'>Bald Rock</a></div></td>
<td><A ID='IMG_5042.JPG' href='outbackNSW.php?fileId=IMG_5042.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_5042.JPG' ALT='Bald Rock'><BR>Bald Rock<br>79.99 KB</a><div class='inv'><br><a href='./images/20070404/IMG_5042.JPG' ALT='Bald Rock'>Bald Rock</a></div></td>
<td><A ID='IMG_5043.JPG' href='outbackNSW.php?fileId=IMG_5043.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_5043.JPG' ALT='Bald Rock'><BR>Bald Rock<br>76.09 KB</a><div class='inv'><br><a href='./images/20070404/IMG_5043.JPG' ALT='Bald Rock'>Bald Rock</a></div></td>
<td><A ID='IMG_5045.JPG' href='outbackNSW.php?fileId=IMG_5045.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_5045.JPG' ALT='Bald Rock'><BR>Bald Rock<br>75.32 KB</a><div class='inv'><br><a href='./images/20070404/IMG_5045.JPG' ALT='Bald Rock'>Bald Rock</a></div></td>
</tr>
<tr><td><A ID='IMG_5046.JPG' href='outbackNSW.php?fileId=IMG_5046.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_5046.JPG' ALT='Bald Rock'><BR>Bald Rock<br>101 KB</a><div class='inv'><br><a href='./images/20070404/IMG_5046.JPG' ALT='Bald Rock'>Bald Rock</a></div></td>
<td><A ID='IMG_5048.JPG' href='outbackNSW.php?fileId=IMG_5048.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_5048.JPG' ALT='Bald Rock'><BR>Bald Rock<br>97.47 KB</a><div class='inv'><br><a href='./images/20070404/IMG_5048.JPG' ALT='Bald Rock'>Bald Rock</a></div></td>
<td><A ID='IMG_5049.JPG' href='outbackNSW.php?fileId=IMG_5049.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_5049.JPG' ALT='Bald Rock'><BR>Bald Rock<br>95.92 KB</a><div class='inv'><br><a href='./images/20070404/IMG_5049.JPG' ALT='Bald Rock'>Bald Rock</a></div></td>
<td><A ID='IMG_5050.JPG' href='outbackNSW.php?fileId=IMG_5050.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_5050.JPG' ALT='Bald Rock'><BR>Bald Rock<br>119.25 KB</a><div class='inv'><br><a href='./images/20070404/IMG_5050.JPG' ALT='Bald Rock'>Bald Rock</a></div></td>
<td><A ID='IMG_5052.JPG' href='outbackNSW.php?fileId=IMG_5052.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_5052.JPG' ALT='Bald Rock'><BR>Bald Rock<br>61.06 KB</a><div class='inv'><br><a href='./images/20070404/IMG_5052.JPG' ALT='Bald Rock'>Bald Rock</a></div></td>
</tr>
<tr><td><A ID='IMG_5055.JPG' href='outbackNSW.php?fileId=IMG_5055.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_5055.JPG' ALT='Bald Rock'><BR>Bald Rock<br>76.4 KB</a><div class='inv'><br><a href='./images/20070404/IMG_5055.JPG' ALT='Bald Rock'>Bald Rock</a></div></td>
<td><A ID='IMG_5057.JPG' href='outbackNSW.php?fileId=IMG_5057.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_5057.JPG' ALT='Bald Rock'><BR>Bald Rock<br>90.22 KB</a><div class='inv'><br><a href='./images/20070404/IMG_5057.JPG' ALT='Bald Rock'>Bald Rock</a></div></td>
<td><A ID='IMG_5058.JPG' href='outbackNSW.php?fileId=IMG_5058.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_5058.JPG' ALT='Bald Rock'><BR>Bald Rock<br>94.09 KB</a><div class='inv'><br><a href='./images/20070404/IMG_5058.JPG' ALT='Bald Rock'>Bald Rock</a></div></td>
<td><A ID='IMG_5060.JPG' href='outbackNSW.php?fileId=IMG_5060.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_5060.JPG' ALT='Bald Rock'><BR>Bald Rock<br>90.17 KB</a><div class='inv'><br><a href='./images/20070404/IMG_5060.JPG' ALT='Bald Rock'>Bald Rock</a></div></td>
<td><A ID='IMG_5061.JPG' href='outbackNSW.php?fileId=IMG_5061.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_5061.JPG' ALT='Bald Rock'><BR>Bald Rock<br>69.42 KB</a><div class='inv'><br><a href='./images/20070404/IMG_5061.JPG' ALT='Bald Rock'>Bald Rock</a></div></td>
</tr>
<tr><td><A ID='IMG_5062.JPG' href='outbackNSW.php?fileId=IMG_5062.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_5062.JPG' ALT='Bald Rock National Park'><BR>Bald Rock National Park<br>131.36 KB</a><div class='inv'><br><a href='./images/20070404/IMG_5062.JPG' ALT='Bald Rock National Park'>Bald Rock National Park</a></div></td>
<td><A ID='IMG_5063.JPG' href='outbackNSW.php?fileId=IMG_5063.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_5063.JPG' ALT='Female Banks' Brown Butterfly'><BR>Female Banks' Brown Butterfly<br>96.44 KB</a><div class='inv'><br><a href='./images/20070404/IMG_5063.JPG' ALT='Female Banks' Brown Butterfly'>Female Banks' Brown Butterfly</a></div></td>
<td><A ID='IMG_5069.JPG' href='outbackNSW.php?fileId=IMG_5069.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_5069.JPG' ALT='Female Satin Bowerbird'><BR>Female Satin Bowerbird<br>70.28 KB</a><div class='inv'><br><a href='./images/20070404/IMG_5069.JPG' ALT='Female Satin Bowerbird'>Female Satin Bowerbird</a></div></td>
<td><A ID='IMG_5070.JPG' href='outbackNSW.php?fileId=IMG_5070.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_5070.JPG' ALT='Pied Currawong'><BR>Pied Currawong<br>71.53 KB</a><div class='inv'><br><a href='./images/20070404/IMG_5070.JPG' ALT='Pied Currawong'>Pied Currawong</a></div></td>
<td><A ID='IMG_5074.JPG' href='outbackNSW.php?fileId=IMG_5074.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_5074.JPG' ALT='Pied Currawong'><BR>Pied Currawong<br>48.87 KB</a><div class='inv'><br><a href='./images/20070404/IMG_5074.JPG' ALT='Pied Currawong'>Pied Currawong</a></div></td>
</tr>
<tr><td><A ID='IMG_5077.JPG' href='outbackNSW.php?fileId=IMG_5077.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_5077.JPG' ALT='Road to Nowhere'><BR>Road to Nowhere<br>104.9 KB</a><div class='inv'><br><a href='./images/20070404/IMG_5077.JPG' ALT='Road to Nowhere'>Road to Nowhere</a></div></td>
<td><A ID='IMG_5080.JPG' href='outbackNSW.php?fileId=IMG_5080.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_5080.JPG' ALT='Ironic Road to Nowhere'><BR>Ironic Road to Nowhere<br>100.8 KB</a><div class='inv'><br><a href='./images/20070404/IMG_5080.JPG' ALT='Ironic Road to Nowhere'>Ironic Road to Nowhere</a></div></td>
<td><A ID='IMG_5088.JPG' href='outbackNSW.php?fileId=IMG_5088.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_5088.JPG' ALT='IMG_5088.JPG'><BR>IMG_5088.JPG<br>79.41 KB</a><div class='inv'><br><a href='./images/20070404/IMG_5088.JPG' ALT='IMG_5088.JPG'>IMG_5088.JPG</a></div></td>
<td><A ID='IMG_5093.JPG' href='outbackNSW.php?fileId=IMG_5093.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_5093.JPG' ALT='Dr Roberts Waterhole, Girraween National Park'><BR>Dr Roberts Waterhole, Girraween National Park<br>97.51 KB</a><div class='inv'><br><a href='./images/20070404/IMG_5093.JPG' ALT='Dr Roberts Waterhole, Girraween National Park'>Dr Roberts Waterhole, Girraween National Park</a></div></td>
<td><A ID='IMG_5097.JPG' href='outbackNSW.php?fileId=IMG_5097.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_5097.JPG' ALT='Girraween National Park'><BR>Girraween National Park<br>93.78 KB</a><div class='inv'><br><a href='./images/20070404/IMG_5097.JPG' ALT='Girraween National Park'>Girraween National Park</a></div></td>
</tr>
<tr><td><A ID='IMG_5102_crop.JPG' href='outbackNSW.php?fileId=IMG_5102_crop.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_5102_crop.JPG' ALT='Grey Fantail'><BR>Grey Fantail<br>47.13 KB</a><div class='inv'><br><a href='./images/20070404/IMG_5102_crop.JPG' ALT='Grey Fantail'>Grey Fantail</a></div></td>
<td><A ID='IMG_5103.JPG' href='outbackNSW.php?fileId=IMG_5103.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_5103.JPG' ALT='Grey Fantail'><BR>Grey Fantail<br>58.2 KB</a><div class='inv'><br><a href='./images/20070404/IMG_5103.JPG' ALT='Grey Fantail'>Grey Fantail</a></div></td>
<td><A ID='IMG_5107.JPG' href='outbackNSW.php?fileId=IMG_5107.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_5107.JPG' ALT='Underground Creek, Girraween National Park'><BR>Underground Creek, Girraween National Park<br>92.85 KB</a><div class='inv'><br><a href='./images/20070404/IMG_5107.JPG' ALT='Underground Creek, Girraween National Park'>Underground Creek, Girraween National Park</a></div></td>
<td><A ID='IMG_5108.JPG' href='outbackNSW.php?fileId=IMG_5108.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_5108.JPG' ALT='Underground Creek, Girraween National Park'><BR>Underground Creek, Girraween National Park<br>98.85 KB</a><div class='inv'><br><a href='./images/20070404/IMG_5108.JPG' ALT='Underground Creek, Girraween National Park'>Underground Creek, Girraween National Park</a></div></td>
<td><A ID='IMG_5113.JPG' href='outbackNSW.php?fileId=IMG_5113.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_5113.JPG' ALT='Underground Creek, Girraween National Park'><BR>Underground Creek, Girraween National Park<br>102.66 KB</a><div class='inv'><br><a href='./images/20070404/IMG_5113.JPG' ALT='Underground Creek, Girraween National Park'>Underground Creek, Girraween National Park</a></div></td>
</tr>
<tr><td><A ID='IMG_5120.JPG' href='outbackNSW.php?fileId=IMG_5120.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_5120.JPG' ALT='Afternoon bath time, Underground Creek, Girraween National Park'><BR>Afternoon bath time, Underground Creek, Girraween National Park<br>87.08 KB</a><div class='inv'><br><a href='./images/20070404/IMG_5120.JPG' ALT='Afternoon bath time, Underground Creek, Girraween National Park'>Afternoon bath time, Underground Creek, Girraween National Park</a></div></td>
<td><A ID='IMG_5130.JPG' href='outbackNSW.php?fileId=IMG_5130.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20070404/IMG_5130.JPG' ALT='Heading home'><BR>Heading home<br>38.02 KB</a><div class='inv'><br><a href='./images/20070404/IMG_5130.JPG' ALT='Heading home'>Heading home</a></div></td>
</tr>
</table>	</div>
</div>
</body>
</html>