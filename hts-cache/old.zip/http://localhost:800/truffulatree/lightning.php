<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - Thunderstorm Moonrise - An impressive show by nature</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="An impressive show by nature">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="Pictures of my 28th Birthday party complete with Sparkler Bomb" href='28th.php'>28th Birthday</a></li>
<li><a title="Pictures of my 30th Birthday party" href='30th.php'>30th Birthday</a></li>
<li><a title="Michael Shamgar and Lindsay Halamek's 30th birthday bash photos" href='sl30th.php'>Shams & Linds' 30th</a></li>
<li><a title="Pictures of Andy Marinos's new flat, cat Toby, and Mum Pam Swain" href='andycatandflat.php'>Andy's Cat & Flat</a></li>
<li><a title="Pictures of a visit to Stephen Jackson's Farm" href='jackovisit.php'>Jacko's Farm</a></li>
<li><a title="Pictures taken at the Peace Convergence action in Rockhampton and Yeppoon in June 2005 to protest the joint US Australia military exercises (Operation Talisman Sabre)" href='peaceconvergence.php'>Peace Convergence</a></li>
<li><a title="Sydney trip - April '06" href='bridges.php'>Sydney, April 06</a></li>
<li><a title="Pics of Naima's 28th birthday dinner" href='mim28th.php'>Naima's 28th</a></li>
<li><a title="Brisbane CBD and the Story Bridge" href='brisbanepics1.php'>Brissie by Night 1</a></li>
<li><a title="Lamington National Park" href='lamington.php'>Lamington NP</a></li>
<li><a title="Various creatures and views from our Brisbane back yard" href='backyard.php'>Backyard Creatures</a></li>
<li><a title="Opening day of the Eleanor Schonell (Green) Bridge" href='greenbridge.php'>Green Bridge</a></li>
<li><a title="Pictutres from the 2006 Woodford Folk Festival" href='woodford0607.php'>Woodford 2006-2007</a></li>
<li><a title="One Cute Puppy" href='jezebel.php'>Jezebel</a></li>
<li><a title="Climbing at Kangaroo Point Cliffs" href='kangaroopt1.php'>Heather's Visit</a></li>
<li><a title="0x0021st (33rd) birthday celebrations" href='0x0021st.php'>0x0021st Birthday</a></li>
<li><a title="Nuptial photography" href='guyandalison.php'>Guy and Alison's Wedding</a></li>
<li><a title="Pictures from the 2007 Woodford Folk Festival" href='woodford0708.php'>Woodford 2007-2008</a></li>
<li><a title="Image gallery" href='sydneytrip0802.php'>Sydney & Yacaaba Head</a></li>
<li><div class='activemenu'>Thunderstorm Moonrise</div></li>
<li><a title="Frightening pictures of a shrinking beard" href='debearding.php'>De-bearding</a></li>
<li><a title="More Nuptial Photography" href='michaelandkaren.php'>Michael and Karen's Wedding</a></li>
<li><a title="A night of celebration" href='andrews21st.php'>Andrew's 21st</a></li>
<li><a title="Image Gallery" href='bloodyknee.php'>Bloody Knee</a></li>
<li><a title="Image Gallery" href='tyesbirthday.php'>Tye's Birthday</a></li>
<li><a title="Image Gallery" href='lasersocialising.php'>Laser Socialising</a></li>
<li><a title="Image Gallery" href='heatherandevan.php'>Heather and Evan's Wedding</a></li>
<li><a title="Image Gallery" href='woodford0809.php'>Woodford 2008-2009</a></li>
<li><a title="Image Gallery" href='allyandben.php'>Ally and Ben's Wedding</a></li>
<li><a title="Image Gallery" href='annes30th.php'>Anne's 30th</a></li>
<li><a title="Image Gallery" href='possumcreek.php'>Possum Creek</a></li>
<li><a title="Image Gallery" href='jamnight.php'>Jam Night</a></li>
<li><a title="Image Gallery" href='cunninghamsgap.php'>Cunningham's Gap</a></li>
<li><a title="Image Gallery" href='bigcat.php'>Diving on Big Cat</a></li>
<li><a title="Images from my birthday jam" href='birthdayjam.php'>Music, mayhem and merriment</a></li>
<li><a title="Image Gallery" href='fuzzypolaroidpics.php'>Fuzzy Polaroid</a></li>
<li><a title="Image Gallery" href='zombiewalk2009.php'>2009 Zombie Walk</a></li>
<li> </li><br><li>Or go back to:</li><li><a title='Picture galleries' href="pictures.php">Photography</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>Thunderstorm Moonrise</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Picture galleries' href="pictures.php">Photography</a> > <a title='An impressive show by nature' href="lightning.php">Thunderstorm Moonrise</a>
<br><br>		

<p>Lightning Crashes - at least, if you're close enough to hear it. This lovely storm was about 80km away out over the sea, so I didn't hear a thing, but it was a pretty bloody spectacular light show.</p>

<p>The moon rising above the clouds was the icing on the cake. I love it when nature turns on this sort of spectacle, and I especially love it when I have a perfect view from 20m down my street. :)</p>
<br><br>
All images in this gallery:<br>
<table width='800'>
<tr>
</tr>
<tr><td><A ID='IMG_3356.JPG' href='lightning.php?fileId=IMG_3356.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080424/IMG_3356.JPG' ALT='IMG_3356.JPG'><BR>IMG_3356.JPG<br>30.2 KB</a><div class='inv'><br><a href='./images/20080424/IMG_3356.JPG' ALT='IMG_3356.JPG'>IMG_3356.JPG</a></div></td>
<td><A ID='IMG_3358.JPG' href='lightning.php?fileId=IMG_3358.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080424/IMG_3358.JPG' ALT='IMG_3358.JPG'><BR>IMG_3358.JPG<br>31.71 KB</a><div class='inv'><br><a href='./images/20080424/IMG_3358.JPG' ALT='IMG_3358.JPG'>IMG_3358.JPG</a></div></td>
<td><A ID='IMG_3362.JPG' href='lightning.php?fileId=IMG_3362.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080424/IMG_3362.JPG' ALT='IMG_3362.JPG'><BR>IMG_3362.JPG<br>38 KB</a><div class='inv'><br><a href='./images/20080424/IMG_3362.JPG' ALT='IMG_3362.JPG'>IMG_3362.JPG</a></div></td>
<td><A ID='IMG_3363.JPG' href='lightning.php?fileId=IMG_3363.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080424/IMG_3363.JPG' ALT='IMG_3363.JPG'><BR>IMG_3363.JPG<br>33.35 KB</a><div class='inv'><br><a href='./images/20080424/IMG_3363.JPG' ALT='IMG_3363.JPG'>IMG_3363.JPG</a></div></td>
<td><A ID='IMG_3366.JPG' href='lightning.php?fileId=IMG_3366.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080424/IMG_3366.JPG' ALT='IMG_3366.JPG'><BR>IMG_3366.JPG<br>32.2 KB</a><div class='inv'><br><a href='./images/20080424/IMG_3366.JPG' ALT='IMG_3366.JPG'>IMG_3366.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_3370.JPG' href='lightning.php?fileId=IMG_3370.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080424/IMG_3370.JPG' ALT='IMG_3370.JPG'><BR>IMG_3370.JPG<br>36.1 KB</a><div class='inv'><br><a href='./images/20080424/IMG_3370.JPG' ALT='IMG_3370.JPG'>IMG_3370.JPG</a></div></td>
<td><A ID='IMG_3371.JPG' href='lightning.php?fileId=IMG_3371.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080424/IMG_3371.JPG' ALT='IMG_3371.JPG'><BR>IMG_3371.JPG<br>38.1 KB</a><div class='inv'><br><a href='./images/20080424/IMG_3371.JPG' ALT='IMG_3371.JPG'>IMG_3371.JPG</a></div></td>
<td><A ID='IMG_3373.JPG' href='lightning.php?fileId=IMG_3373.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080424/IMG_3373.JPG' ALT='IMG_3373.JPG'><BR>IMG_3373.JPG<br>32.94 KB</a><div class='inv'><br><a href='./images/20080424/IMG_3373.JPG' ALT='IMG_3373.JPG'>IMG_3373.JPG</a></div></td>
<td><A ID='IMG_3374.JPG' href='lightning.php?fileId=IMG_3374.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080424/IMG_3374.JPG' ALT='IMG_3374.JPG'><BR>IMG_3374.JPG<br>32.24 KB</a><div class='inv'><br><a href='./images/20080424/IMG_3374.JPG' ALT='IMG_3374.JPG'>IMG_3374.JPG</a></div></td>
<td><A ID='IMG_3375.JPG' href='lightning.php?fileId=IMG_3375.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080424/IMG_3375.JPG' ALT='IMG_3375.JPG'><BR>IMG_3375.JPG<br>31.01 KB</a><div class='inv'><br><a href='./images/20080424/IMG_3375.JPG' ALT='IMG_3375.JPG'>IMG_3375.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_3376.JPG' href='lightning.php?fileId=IMG_3376.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080424/IMG_3376.JPG' ALT='IMG_3376.JPG'><BR>IMG_3376.JPG<br>30.21 KB</a><div class='inv'><br><a href='./images/20080424/IMG_3376.JPG' ALT='IMG_3376.JPG'>IMG_3376.JPG</a></div></td>
<td><A ID='IMG_3378.JPG' href='lightning.php?fileId=IMG_3378.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080424/IMG_3378.JPG' ALT='IMG_3378.JPG'><BR>IMG_3378.JPG<br>36.31 KB</a><div class='inv'><br><a href='./images/20080424/IMG_3378.JPG' ALT='IMG_3378.JPG'>IMG_3378.JPG</a></div></td>
<td><A ID='IMG_3379.JPG' href='lightning.php?fileId=IMG_3379.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080424/IMG_3379.JPG' ALT='IMG_3379.JPG'><BR>IMG_3379.JPG<br>36.08 KB</a><div class='inv'><br><a href='./images/20080424/IMG_3379.JPG' ALT='IMG_3379.JPG'>IMG_3379.JPG</a></div></td>
<td><A ID='IMG_3380.JPG' href='lightning.php?fileId=IMG_3380.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080424/IMG_3380.JPG' ALT='IMG_3380.JPG'><BR>IMG_3380.JPG<br>27.77 KB</a><div class='inv'><br><a href='./images/20080424/IMG_3380.JPG' ALT='IMG_3380.JPG'>IMG_3380.JPG</a></div></td>
<td><A ID='IMG_3384.JPG' href='lightning.php?fileId=IMG_3384.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080424/IMG_3384.JPG' ALT='IMG_3384.JPG'><BR>IMG_3384.JPG<br>33.88 KB</a><div class='inv'><br><a href='./images/20080424/IMG_3384.JPG' ALT='IMG_3384.JPG'>IMG_3384.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_3388.JPG' href='lightning.php?fileId=IMG_3388.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080424/IMG_3388.JPG' ALT='IMG_3388.JPG'><BR>IMG_3388.JPG<br>42.66 KB</a><div class='inv'><br><a href='./images/20080424/IMG_3388.JPG' ALT='IMG_3388.JPG'>IMG_3388.JPG</a></div></td>
<td><A ID='IMG_3389.JPG' href='lightning.php?fileId=IMG_3389.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080424/IMG_3389.JPG' ALT='IMG_3389.JPG'><BR>IMG_3389.JPG<br>53.04 KB</a><div class='inv'><br><a href='./images/20080424/IMG_3389.JPG' ALT='IMG_3389.JPG'>IMG_3389.JPG</a></div></td>
<td><A ID='IMG_3390.JPG' href='lightning.php?fileId=IMG_3390.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080424/IMG_3390.JPG' ALT='IMG_3390.JPG'><BR>IMG_3390.JPG<br>56.75 KB</a><div class='inv'><br><a href='./images/20080424/IMG_3390.JPG' ALT='IMG_3390.JPG'>IMG_3390.JPG</a></div></td>
<td><A ID='IMG_3391.JPG' href='lightning.php?fileId=IMG_3391.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080424/IMG_3391.JPG' ALT='IMG_3391.JPG'><BR>IMG_3391.JPG<br>55.85 KB</a><div class='inv'><br><a href='./images/20080424/IMG_3391.JPG' ALT='IMG_3391.JPG'>IMG_3391.JPG</a></div></td>
<td><A ID='IMG_3392.JPG' href='lightning.php?fileId=IMG_3392.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080424/IMG_3392.JPG' ALT='IMG_3392.JPG'><BR>IMG_3392.JPG<br>57.46 KB</a><div class='inv'><br><a href='./images/20080424/IMG_3392.JPG' ALT='IMG_3392.JPG'>IMG_3392.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_3393.JPG' href='lightning.php?fileId=IMG_3393.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080424/IMG_3393.JPG' ALT='IMG_3393.JPG'><BR>IMG_3393.JPG<br>55.49 KB</a><div class='inv'><br><a href='./images/20080424/IMG_3393.JPG' ALT='IMG_3393.JPG'>IMG_3393.JPG</a></div></td>
<td><A ID='IMG_3394.JPG' href='lightning.php?fileId=IMG_3394.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080424/IMG_3394.JPG' ALT='IMG_3394.JPG'><BR>IMG_3394.JPG<br>54.21 KB</a><div class='inv'><br><a href='./images/20080424/IMG_3394.JPG' ALT='IMG_3394.JPG'>IMG_3394.JPG</a></div></td>
<td><A ID='IMG_3395.JPG' href='lightning.php?fileId=IMG_3395.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080424/IMG_3395.JPG' ALT='IMG_3395.JPG'><BR>IMG_3395.JPG<br>54.34 KB</a><div class='inv'><br><a href='./images/20080424/IMG_3395.JPG' ALT='IMG_3395.JPG'>IMG_3395.JPG</a></div></td>
<td><A ID='IMG_3397.JPG' href='lightning.php?fileId=IMG_3397.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080424/IMG_3397.JPG' ALT='IMG_3397.JPG'><BR>IMG_3397.JPG<br>62.84 KB</a><div class='inv'><br><a href='./images/20080424/IMG_3397.JPG' ALT='IMG_3397.JPG'>IMG_3397.JPG</a></div></td>
<td><A ID='IMG_3398.JPG' href='lightning.php?fileId=IMG_3398.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080424/IMG_3398.JPG' ALT='IMG_3398.JPG'><BR>IMG_3398.JPG<br>63.35 KB</a><div class='inv'><br><a href='./images/20080424/IMG_3398.JPG' ALT='IMG_3398.JPG'>IMG_3398.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_3399.JPG' href='lightning.php?fileId=IMG_3399.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080424/IMG_3399.JPG' ALT='IMG_3399.JPG'><BR>IMG_3399.JPG<br>61.23 KB</a><div class='inv'><br><a href='./images/20080424/IMG_3399.JPG' ALT='IMG_3399.JPG'>IMG_3399.JPG</a></div></td>
<td><A ID='IMG_3401.JPG' href='lightning.php?fileId=IMG_3401.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080424/IMG_3401.JPG' ALT='IMG_3401.JPG'><BR>IMG_3401.JPG<br>46.15 KB</a><div class='inv'><br><a href='./images/20080424/IMG_3401.JPG' ALT='IMG_3401.JPG'>IMG_3401.JPG</a></div></td>
<td><A ID='IMG_3402.JPG' href='lightning.php?fileId=IMG_3402.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080424/IMG_3402.JPG' ALT='IMG_3402.JPG'><BR>IMG_3402.JPG<br>49.86 KB</a><div class='inv'><br><a href='./images/20080424/IMG_3402.JPG' ALT='IMG_3402.JPG'>IMG_3402.JPG</a></div></td>
<td><A ID='IMG_3403.JPG' href='lightning.php?fileId=IMG_3403.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080424/IMG_3403.JPG' ALT='IMG_3403.JPG'><BR>IMG_3403.JPG<br>33.9 KB</a><div class='inv'><br><a href='./images/20080424/IMG_3403.JPG' ALT='IMG_3403.JPG'>IMG_3403.JPG</a></div></td>
<td><A ID='IMG_3405.JPG' href='lightning.php?fileId=IMG_3405.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080424/IMG_3405.JPG' ALT='IMG_3405.JPG'><BR>IMG_3405.JPG<br>37.73 KB</a><div class='inv'><br><a href='./images/20080424/IMG_3405.JPG' ALT='IMG_3405.JPG'>IMG_3405.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_3406.JPG' href='lightning.php?fileId=IMG_3406.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080424/IMG_3406.JPG' ALT='IMG_3406.JPG'><BR>IMG_3406.JPG<br>45.23 KB</a><div class='inv'><br><a href='./images/20080424/IMG_3406.JPG' ALT='IMG_3406.JPG'>IMG_3406.JPG</a></div></td>
<td><A ID='IMG_3408.JPG' href='lightning.php?fileId=IMG_3408.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080424/IMG_3408.JPG' ALT='IMG_3408.JPG'><BR>IMG_3408.JPG<br>48.53 KB</a><div class='inv'><br><a href='./images/20080424/IMG_3408.JPG' ALT='IMG_3408.JPG'>IMG_3408.JPG</a></div></td>
<td><A ID='IMG_3409.JPG' href='lightning.php?fileId=IMG_3409.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080424/IMG_3409.JPG' ALT='IMG_3409.JPG'><BR>IMG_3409.JPG<br>60.32 KB</a><div class='inv'><br><a href='./images/20080424/IMG_3409.JPG' ALT='IMG_3409.JPG'>IMG_3409.JPG</a></div></td>
</tr>
</table>	</div>
</div>
</body>
</html>