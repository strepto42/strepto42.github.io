<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - 28/10/2005 - Pinnacles and Pinnipeds</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="Pinnacles and Pinnipeds">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="Greetings from a Bum" href='greetingsfromabum.php'>29/4/2005</a></li>
<li><a title="Onward" href='onward.php'>2/5/2005</a></li>
<li><a title="It's a tough life (pt 1: Bundaberg, Agnes Water and 1770)" href='itsatoughlife1.php'>17/5/2005</a></li>
<li><a title="It's a tough life (pt 2: Rockhampton, Emu Park and Great Keppel Island)" href='itsatoughlife2.php'>23/5/2005</a></li>
<li><a title="There and Back Again - a Yo-yo's Tale" href='thereandbackagain.php'>18/6/2005</a></li>
<li><a title="Platypi and Grey Nomads" href='platypiandgreynomads.php'>24/6/2005</a></li>
<li><a title="Blowing Bubbles in a Watery Tomb" href='blowingbubbles.php'>1/7/2005</a></li>
<li><a title="Pieces of History" href='piecesofhistory.php'>8/7/2005</a></li>
<li><a title="Walks and Waterfalls" href='walksandwaterfalls.php'>15/7/2005</a></li>
<li><a title="Mission to Tribulation" href='missiontotribulation.php'>22/7/2005</a></li>
<li><a title="Levity, Limestone and Lava" href='levitylimestoneandlava.php'>29/7/2005</a></li>
<li><a title="Into the Never Never" href='intothenevernever.php'>5/8/2005</a></li>
<li><a title="Slowing the pace in Darwin" href='slowingthepaceindarwin.php'>12/8/2005</a></li>
<li><a title="Blistering Barnacles and Leaping Lizards" href='leapinglizards.php'>19/8/2005</a></li>
<li><a title="Kakadu and Litchfield" href='kakadu.php'>26/8/2005</a></li>
<li><a title="Legacies of War" href='legaciesofwar.php'>2/9/2005</a></li>
<li><a title="Go West" href='gowest.php'>10/9/2005</a></li>
<li><a title="Things from Above" href='thingsfromabove.php'>16/9/2005</a></li>
<li><a title="The West Coast" href='thewestcoast.php'>23/9/2005</a></li>
<li><a title="Reefs and Red Dust" href='reefsandreddust.php'>30/9/2005</a></li>
<li><a title="The Pilbara" href='pilbara.php'>7/10/2005</a></li>
<li><a title="Paradise with a Headwind" href='paradisewithaheadwind.php'>14/10/2005</a></li>
<li><a title="Down the Coral Coast" href='downthecoralcoast.php'>21/10/2005</a></li>
<li><div class='activemenu'>28/10/2005</div></li>
<li><a title="A week in Perth" href='perth.php'>4/11/2005</a></li>
<li><a title="The Southwest (from Above and Below)" href='thesouthwest.php'>11/11/2005</a></li>
<li><a title="More Heights and Depths" href='moreheightsanddepths.php'>18/11/2005</a></li>
<li><a title="Across the Nullarbor (and a bit beyond)" href='nullarbor.php'>25/11/2005</a></li>
<li><a title="Double Whammy" href='doublewhammy.php'>9/12/2005</a></li>
<li><a title="Two Cities" href='twocities.php'>19/12/2005</a></li>
<li><a title="Tassie - Part 1" href='tassie1.php'>1/1/2006</a></li>
<li><a title="Tassie - Part 2" href='tassie2.php'>7/1/2006</a></li>
<li><a title="Full Circle" href='fullcircle.php'>26/1/2006</a></li>
<li><a title="The Wrap Up" href='thewrapup.php'>23/3/2006</a></li>
<li> </li><br><li>Or go back to:</li><li><a title='Travelouges and blogs from my trip around Australia' href="nerdseyeview.php">Nerd's Eye View</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>28/10/2005</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Travel stories and pictures' href="travel.php">Travelogues</a> > <a title='Travelouges and blogs from my trip around Australia' href="nerdseyeview.php">Nerd's Eye View</a> > <a title='Pinnacles and Pinnipeds' href="pinnaclesandpinnipeds.php">28/10/2005</a>
<br><br>		


<h1>Pinnacles and Pinnipeds</h1>

<a href="images/maps/Map051028.gif"><img src="images/maps/Map051028_sm.gif" align="right"></a>

<p>Well, it seems that I was wrong - we haven't made it to Perth yet, due to a few distractions on the way. We are, however, a mere 80 or so kilometres from it now, and will get there tomorrow.</p>

<p>In the meantime though, we've been far from idle. Last week's update saw us in Geraldton, and we stayed there for a couple of nights in total. I had wanted to do some diving (there is a good wreck there), but the wind put a stop to that. So we spent a day doing the usual shopping and cruising around the tourist spots on our bikes.</p>

<p>First up was the museum, where they have some good displays, including one section devoted to the various famous shipwrecks (the Batavia and the Zuytdorp) that have happened in the area (dating back to the 1600s and Dutch traders).</p>

<p>After that we checked out the HMAS Sydney memorial, which stands atop a hill overlooking town, as a monument to the ship that went down with all hands back in WWII (they still don't know exactly where).</p>

<p>We also payed a visit to the local tourist office, and picked up a prize find - a book detailing free (and near free) camping areas in southern WA. It's already paid for itself a couple of times over, and we're discovering some lovely spots that we might have otherwise missed, as well as saving a bit of money.</p>

<p>We tried it out pretty much straight away, and headed to a nice secluded spot not far out of town. On the way we stopped briefly at the historic town of Greenough. We also passed a brand spanking new wind farm, with about 50 large-bladed turbines (most of which weren't running, I think they're still plugging them in). It was rather impressive, and significantly bigger than the <a href="missiontotribulation.php">one near Atherton</a>.</p>

<p>Our free camping spot turned out to be quite lovely, but the flies there were particularly plentiful, and harassed the hell out of us, so we moved to another free spot further down the coast near Dongara, which was somewhat less picturesque, but was significantly less infested with dipterans, and served our purposes just fine.</p>

<p>From there we went and had brekkie and an amble around the very pleasant Dongara, and then we pushed on, through Port Denison (pretty much the same place) to another cheapo camping spot we'd found in our new book, on the shores of Lake Indoon.</p>

<p>It was at this pleasant spot that I finally experienced something I'd not seen properly since the east coast - rain. A fair quantity of it, in fact (my car is now significantly cleaner). There wasn't much to do but sit in the car reading, so that is what we did.</p>

<p>The next day was nicer, and in fact since then we've had nice weather - generally a mix of some cloud and some sunshine. The air is quite cool now, surprisingly so at times, and it's making a very pleasant change after the relentless and monotonous heat of the top end.</p>

<p>We headed south again, to another little coastal town called Jurien Bay. It turned out to be a fairly nice spot, but we pushed on the next day, in the general direction of Cervantes, and the famous Pinnacles. As things turned out we would return to Jurien - but more about that in a minute.</p>

<p>The original plan was to stay in another freebie rest area, which we got to and checked out, but it was early in the day so we headed off to the Pinnacles.</p>

<p>On the way we stopped off at a couple of really picturesque little bays, and wandered around a bit, taking photos of seaweed and so on. I think I've said this before, but it really is a tough life sometimes.</p>

<p>The Pinnacles themselves are pillars of calcified rock that have grown underground over a period of time. Later, they've been exposed by the prevailing southerlies in the area, leaving a spectacular landscape of rocky spires (of various shapes and sizes) poking up out of the yellow sand dunes.</p>

<p>Apparently, Dutch sailors thought they were the remains of an ancient, ruined city when they first sighted them from far out to sea (and couldn't get any closer due to the reefs). They're certainly one of my favourite places to date, although we got really quite lucky with the weather. Basically it was one of those days with heavy grey cloud on one side of the sky, and sunlight on the other. It made for some dramatic vistas.</p>

<p>The Pinnacles desert area has a 3.5km track that you can drive your vehicle around, with parking in various bays. You can walk anywhere, which is also nice. Of course you can't climb the rocks, but you wouldn't want to.</p>

<p>Anyway, we parked the car and did the loop on our bikes, as the sandy track was quite compacted and made for fine riding. It was definitely the way to go to explore this very atmospheric landscape. We took our time, and of course the photos are plentiful.</p>

<p>One quite tall pinnacle had little bird squawking noises coming from a crevice up towards it's top, so I tippie-toed with the camera and took a blind shot downwards into it. The shot revealed a rather cute trio of baby birds - we're still trying to work out exactly what they are (probably a raptor of some sort).</p>

<p>Earlier in the day, I'd made enquiries about diving with a mob in Jurien Bay. They didn't have anything going, but they did ring me back to let me know that there was a Sea Lion snorkelling trip happening on Thursday (the next day).</p>

<p>Jana and I conferred about it, and managed to wrangle (well, they offered actually) free wetsuit hire out of them, so it became affordable, and we decided to do it.</p>

<p>As a result, we headed back up the coast to Jurien, but instead of staying in the caravan park, we fired up the free camping book again and stayed in a nice spot just north of the town, called Sandy Bay (I think).</p>

<p>The next morning, a rainbow heralded nice weather, and we headed out to where the Sea Lions were (an islet off the coast), along with a Dutch couple.</p>

<p>We had quite a good time bobbing around, and a few of the natives came out to play. By and large though, they weren't that interested. We were perfectly happy though; wild animals are wild animals, and I was happy that we got to have a swim around some (rather cute) Sea Lions, even if it was a bit brief.</p>

<p>We stayed in the water for some time, while the young fellow Sam, who was along to help, swam out to the island and tried to entice some more Sea Lions to come and play by splashing around and carrying on in general. He really did try very hard and eventually a couple more came over.</p>

<p>In the meantime, we made our own fun clowning around in our 5mm semi-dry wetsuits (which are exceedingly buoyant). All in all, it was a great experience. Sea Lions are extremely cute, and quite playful.</p>

<p>In the arvo, we drove on, back in the general direction of Perth. Our first freebie camp spot wasn't so crash hot, so we found another, all to ourselves.</p>

<p>Our last couple of destinations before Perth are inland a little bit (but still on the way). First up this morning was a trip to New Norcia, a monastery/town that was established back in the 1800s as a mission. To get there, we headed cross-country, onto some dirt roads that appeared in both my book of maps, and the GPS.</p>

<p>It turned out to be quite a pleasant jaunt through the countryside. The road ended up going through various paddocks of cereal and pea crops, and we saw a fair bit of wildlife, including quite a few of the strange-looking Bobtail lizards.</p>

<p>At one point though the road became rather sandy and things got a bit hairy. I got to have a high-adrenaline moment gunning it down and up a hill, dodging obstacles (like fence posts and stumps) without getting bogged. It seems my <a href="onward.php">beach adventures way back when</a> have stood me in good stead though, and we made it through to New Norcia without having to ever use the phrase "bogged in the middle of bloody nowhere with a mad, mad woman!!".</p>

<p>New Norcia itself is quite quaint. We pedalled around for a bit and I took pictures. There were monks. Not much else to say really.</p>

<p>From there the original plan was to get to Perth via Toodyay. We made it as far as the latter, and have decided to just hang here for the night. There is a jazz festival on here this weekend, so we'll probably check that out tomorrow morning, before heading to the big smoke in the arvo.</p>

<p>This week's selections:</p>

<!-- <ul>
<li><a href="?fileId=IMG_1519.JPG">The beach at Jurien Bay</a></li>
<li><a href="?fileId=IMG_1600.JPG">Pedal power at the Pinnacles</a></li>
<li><a href="?fileId=IMG_1604.JPG">Pinnacles revisited</a></li>
<li><a href="?fileId=IMG_1662.JPG">Snorkelmasters at work</a></li>
<li><a href="?fileId=IMG_1754.JPG">New Norcia architecture</a></li>
</ul> -->

<table width="800">
	<tr>
	<td ALIGN=CENTER VALIGN=top>
		<A href='pinnaclesandpinnipeds.php?fileId=IMG_1519.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1519.JPG' ALT='The beach at Jurien Bay'><BR>The beach at Jurien Bay</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='pinnaclesandpinnipeds.php?fileId=IMG_1600.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1600.JPG' ALT='Pedal power at the Pinnacles'><BR>Pedal power at the Pinnacles</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='pinnaclesandpinnipeds.php?fileId=IMG_1604.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1604.JPG' ALT='Pinnacles revisited'><BR>Pinnacles revisited</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='pinnaclesandpinnipeds.php?fileId=IMG_1662.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1662.JPG' ALT='Snorkelmasters at work'><BR>Snorkelmasters at work</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='pinnaclesandpinnipeds.php?fileId=IMG_1754.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1754.JPG' ALT='New Norcia architecture'><BR>New Norcia architecture</a>
	</td></tr>
</table>

<br><br>
All images in this gallery:<br>
<table width='800'>
<tr>
</tr>
<tr><td><A ID='IMG_1350.JPG' href='pinnaclesandpinnipeds.php?fileId=IMG_1350.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1350.JPG' ALT='IMG_1350.JPG'><BR>IMG_1350.JPG<br>53.69 KB</a><div class='inv'><br><a href='./images/20051028/IMG_1350.JPG' ALT='IMG_1350.JPG'>IMG_1350.JPG</a></div></td>
<td><A ID='IMG_1352.JPG' href='pinnaclesandpinnipeds.php?fileId=IMG_1352.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1352.JPG' ALT='IMG_1352.JPG'><BR>IMG_1352.JPG<br>54.12 KB</a><div class='inv'><br><a href='./images/20051028/IMG_1352.JPG' ALT='IMG_1352.JPG'>IMG_1352.JPG</a></div></td>
<td><A ID='IMG_1353.JPG' href='pinnaclesandpinnipeds.php?fileId=IMG_1353.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1353.JPG' ALT='IMG_1353.JPG'><BR>IMG_1353.JPG<br>40.16 KB</a><div class='inv'><br><a href='./images/20051028/IMG_1353.JPG' ALT='IMG_1353.JPG'>IMG_1353.JPG</a></div></td>
<td><A ID='IMG_1354.JPG' href='pinnaclesandpinnipeds.php?fileId=IMG_1354.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1354.JPG' ALT='IMG_1354.JPG'><BR>IMG_1354.JPG<br>59.34 KB</a><div class='inv'><br><a href='./images/20051028/IMG_1354.JPG' ALT='IMG_1354.JPG'>IMG_1354.JPG</a></div></td>
<td><A ID='IMG_1355.JPG' href='pinnaclesandpinnipeds.php?fileId=IMG_1355.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1355.JPG' ALT='IMG_1355.JPG'><BR>IMG_1355.JPG<br>61.75 KB</a><div class='inv'><br><a href='./images/20051028/IMG_1355.JPG' ALT='IMG_1355.JPG'>IMG_1355.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_1356.JPG' href='pinnaclesandpinnipeds.php?fileId=IMG_1356.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1356.JPG' ALT='IMG_1356.JPG'><BR>IMG_1356.JPG<br>41.39 KB</a><div class='inv'><br><a href='./images/20051028/IMG_1356.JPG' ALT='IMG_1356.JPG'>IMG_1356.JPG</a></div></td>
<td><A ID='IMG_1358.JPG' href='pinnaclesandpinnipeds.php?fileId=IMG_1358.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1358.JPG' ALT='IMG_1358.JPG'><BR>IMG_1358.JPG<br>55.38 KB</a><div class='inv'><br><a href='./images/20051028/IMG_1358.JPG' ALT='IMG_1358.JPG'>IMG_1358.JPG</a></div></td>
<td><A ID='IMG_1362.JPG' href='pinnaclesandpinnipeds.php?fileId=IMG_1362.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1362.JPG' ALT='IMG_1362.JPG'><BR>IMG_1362.JPG<br>47.87 KB</a><div class='inv'><br><a href='./images/20051028/IMG_1362.JPG' ALT='IMG_1362.JPG'>IMG_1362.JPG</a></div></td>
<td><A ID='IMG_1364.JPG' href='pinnaclesandpinnipeds.php?fileId=IMG_1364.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1364.JPG' ALT='IMG_1364.JPG'><BR>IMG_1364.JPG<br>83.07 KB</a><div class='inv'><br><a href='./images/20051028/IMG_1364.JPG' ALT='IMG_1364.JPG'>IMG_1364.JPG</a></div></td>
<td><A ID='IMG_1366.JPG' href='pinnaclesandpinnipeds.php?fileId=IMG_1366.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1366.JPG' ALT='IMG_1366.JPG'><BR>IMG_1366.JPG<br>30.29 KB</a><div class='inv'><br><a href='./images/20051028/IMG_1366.JPG' ALT='IMG_1366.JPG'>IMG_1366.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_1368.JPG' href='pinnaclesandpinnipeds.php?fileId=IMG_1368.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1368.JPG' ALT='IMG_1368.JPG'><BR>IMG_1368.JPG<br>41.5 KB</a><div class='inv'><br><a href='./images/20051028/IMG_1368.JPG' ALT='IMG_1368.JPG'>IMG_1368.JPG</a></div></td>
<td><A ID='IMG_1369.JPG' href='pinnaclesandpinnipeds.php?fileId=IMG_1369.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1369.JPG' ALT='IMG_1369.JPG'><BR>IMG_1369.JPG<br>76.9 KB</a><div class='inv'><br><a href='./images/20051028/IMG_1369.JPG' ALT='IMG_1369.JPG'>IMG_1369.JPG</a></div></td>
<td><A ID='IMG_1372.JPG' href='pinnaclesandpinnipeds.php?fileId=IMG_1372.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1372.JPG' ALT='IMG_1372.JPG'><BR>IMG_1372.JPG<br>72.04 KB</a><div class='inv'><br><a href='./images/20051028/IMG_1372.JPG' ALT='IMG_1372.JPG'>IMG_1372.JPG</a></div></td>
<td><A ID='IMG_1374.JPG' href='pinnaclesandpinnipeds.php?fileId=IMG_1374.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1374.JPG' ALT='IMG_1374.JPG'><BR>IMG_1374.JPG<br>54.61 KB</a><div class='inv'><br><a href='./images/20051028/IMG_1374.JPG' ALT='IMG_1374.JPG'>IMG_1374.JPG</a></div></td>
<td><A ID='IMG_1375.JPG' href='pinnaclesandpinnipeds.php?fileId=IMG_1375.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1375.JPG' ALT='IMG_1375.JPG'><BR>IMG_1375.JPG<br>60.42 KB</a><div class='inv'><br><a href='./images/20051028/IMG_1375.JPG' ALT='IMG_1375.JPG'>IMG_1375.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_1379.JPG' href='pinnaclesandpinnipeds.php?fileId=IMG_1379.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1379.JPG' ALT='IMG_1379.JPG'><BR>IMG_1379.JPG<br>88.58 KB</a><div class='inv'><br><a href='./images/20051028/IMG_1379.JPG' ALT='IMG_1379.JPG'>IMG_1379.JPG</a></div></td>
<td><A ID='IMG_1381.JPG' href='pinnaclesandpinnipeds.php?fileId=IMG_1381.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1381.JPG' ALT='IMG_1381.JPG'><BR>IMG_1381.JPG<br>94.42 KB</a><div class='inv'><br><a href='./images/20051028/IMG_1381.JPG' ALT='IMG_1381.JPG'>IMG_1381.JPG</a></div></td>
<td><A ID='IMG_1383.JPG' href='pinnaclesandpinnipeds.php?fileId=IMG_1383.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1383.JPG' ALT='IMG_1383.JPG'><BR>IMG_1383.JPG<br>45.24 KB</a><div class='inv'><br><a href='./images/20051028/IMG_1383.JPG' ALT='IMG_1383.JPG'>IMG_1383.JPG</a></div></td>
<td><A ID='IMG_1387.JPG' href='pinnaclesandpinnipeds.php?fileId=IMG_1387.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1387.JPG' ALT='IMG_1387.JPG'><BR>IMG_1387.JPG<br>32.29 KB</a><div class='inv'><br><a href='./images/20051028/IMG_1387.JPG' ALT='IMG_1387.JPG'>IMG_1387.JPG</a></div></td>
<td><A ID='IMG_1389.JPG' href='pinnaclesandpinnipeds.php?fileId=IMG_1389.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1389.JPG' ALT='IMG_1389.JPG'><BR>IMG_1389.JPG<br>103.46 KB</a><div class='inv'><br><a href='./images/20051028/IMG_1389.JPG' ALT='IMG_1389.JPG'>IMG_1389.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_1391.JPG' href='pinnaclesandpinnipeds.php?fileId=IMG_1391.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1391.JPG' ALT='IMG_1391.JPG'><BR>IMG_1391.JPG<br>62.6 KB</a><div class='inv'><br><a href='./images/20051028/IMG_1391.JPG' ALT='IMG_1391.JPG'>IMG_1391.JPG</a></div></td>
<td><A ID='IMG_1400.JPG' href='pinnaclesandpinnipeds.php?fileId=IMG_1400.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1400.JPG' ALT='IMG_1400.JPG'><BR>IMG_1400.JPG<br>69.4 KB</a><div class='inv'><br><a href='./images/20051028/IMG_1400.JPG' ALT='IMG_1400.JPG'>IMG_1400.JPG</a></div></td>
<td><A ID='IMG_1401.JPG' href='pinnaclesandpinnipeds.php?fileId=IMG_1401.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1401.JPG' ALT='IMG_1401.JPG'><BR>IMG_1401.JPG<br>69.93 KB</a><div class='inv'><br><a href='./images/20051028/IMG_1401.JPG' ALT='IMG_1401.JPG'>IMG_1401.JPG</a></div></td>
<td><A ID='IMG_1409.JPG' href='pinnaclesandpinnipeds.php?fileId=IMG_1409.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1409.JPG' ALT='IMG_1409.JPG'><BR>IMG_1409.JPG<br>36.68 KB</a><div class='inv'><br><a href='./images/20051028/IMG_1409.JPG' ALT='IMG_1409.JPG'>IMG_1409.JPG</a></div></td>
<td><A ID='IMG_1412.JPG' href='pinnaclesandpinnipeds.php?fileId=IMG_1412.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1412.JPG' ALT='IMG_1412.JPG'><BR>IMG_1412.JPG<br>119.08 KB</a><div class='inv'><br><a href='./images/20051028/IMG_1412.JPG' ALT='IMG_1412.JPG'>IMG_1412.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_1415.JPG' href='pinnaclesandpinnipeds.php?fileId=IMG_1415.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1415.JPG' ALT='IMG_1415.JPG'><BR>IMG_1415.JPG<br>114.02 KB</a><div class='inv'><br><a href='./images/20051028/IMG_1415.JPG' ALT='IMG_1415.JPG'>IMG_1415.JPG</a></div></td>
<td><A ID='IMG_1420.JPG' href='pinnaclesandpinnipeds.php?fileId=IMG_1420.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1420.JPG' ALT='IMG_1420.JPG'><BR>IMG_1420.JPG<br>145.91 KB</a><div class='inv'><br><a href='./images/20051028/IMG_1420.JPG' ALT='IMG_1420.JPG'>IMG_1420.JPG</a></div></td>
<td><A ID='IMG_1426.JPG' href='pinnaclesandpinnipeds.php?fileId=IMG_1426.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1426.JPG' ALT='IMG_1426.JPG'><BR>IMG_1426.JPG<br>92.11 KB</a><div class='inv'><br><a href='./images/20051028/IMG_1426.JPG' ALT='IMG_1426.JPG'>IMG_1426.JPG</a></div></td>
<td><A ID='IMG_1430.JPG' href='pinnaclesandpinnipeds.php?fileId=IMG_1430.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1430.JPG' ALT='IMG_1430.JPG'><BR>IMG_1430.JPG<br>80.84 KB</a><div class='inv'><br><a href='./images/20051028/IMG_1430.JPG' ALT='IMG_1430.JPG'>IMG_1430.JPG</a></div></td>
<td><A ID='IMG_1437.JPG' href='pinnaclesandpinnipeds.php?fileId=IMG_1437.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1437.JPG' ALT='IMG_1437.JPG'><BR>IMG_1437.JPG<br>45.99 KB</a><div class='inv'><br><a href='./images/20051028/IMG_1437.JPG' ALT='IMG_1437.JPG'>IMG_1437.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_1501.JPG' href='pinnaclesandpinnipeds.php?fileId=IMG_1501.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1501.JPG' ALT='IMG_1501.JPG'><BR>IMG_1501.JPG<br>121.22 KB</a><div class='inv'><br><a href='./images/20051028/IMG_1501.JPG' ALT='IMG_1501.JPG'>IMG_1501.JPG</a></div></td>
<td><A ID='IMG_1503.JPG' href='pinnaclesandpinnipeds.php?fileId=IMG_1503.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1503.JPG' ALT='IMG_1503.JPG'><BR>IMG_1503.JPG<br>66.37 KB</a><div class='inv'><br><a href='./images/20051028/IMG_1503.JPG' ALT='IMG_1503.JPG'>IMG_1503.JPG</a></div></td>
<td><A ID='IMG_1507.JPG' href='pinnaclesandpinnipeds.php?fileId=IMG_1507.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1507.JPG' ALT='IMG_1507.JPG'><BR>IMG_1507.JPG<br>73.88 KB</a><div class='inv'><br><a href='./images/20051028/IMG_1507.JPG' ALT='IMG_1507.JPG'>IMG_1507.JPG</a></div></td>
<td><A ID='IMG_1509.JPG' href='pinnaclesandpinnipeds.php?fileId=IMG_1509.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1509.JPG' ALT='IMG_1509.JPG'><BR>IMG_1509.JPG<br>77.11 KB</a><div class='inv'><br><a href='./images/20051028/IMG_1509.JPG' ALT='IMG_1509.JPG'>IMG_1509.JPG</a></div></td>
<td><A ID='IMG_1510.JPG' href='pinnaclesandpinnipeds.php?fileId=IMG_1510.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1510.JPG' ALT='IMG_1510.JPG'><BR>IMG_1510.JPG<br>99.86 KB</a><div class='inv'><br><a href='./images/20051028/IMG_1510.JPG' ALT='IMG_1510.JPG'>IMG_1510.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_1516.JPG' href='pinnaclesandpinnipeds.php?fileId=IMG_1516.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1516.JPG' ALT='IMG_1516.JPG'><BR>IMG_1516.JPG<br>89.04 KB</a><div class='inv'><br><a href='./images/20051028/IMG_1516.JPG' ALT='IMG_1516.JPG'>IMG_1516.JPG</a></div></td>
<td><A ID='IMG_1517.JPG' href='pinnaclesandpinnipeds.php?fileId=IMG_1517.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1517.JPG' ALT='IMG_1517.JPG'><BR>IMG_1517.JPG<br>129.44 KB</a><div class='inv'><br><a href='./images/20051028/IMG_1517.JPG' ALT='IMG_1517.JPG'>IMG_1517.JPG</a></div></td>
<td><A ID='IMG_1519.JPG' href='pinnaclesandpinnipeds.php?fileId=IMG_1519.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1519.JPG' ALT='IMG_1519.JPG'><BR>IMG_1519.JPG<br>72.21 KB</a><div class='inv'><br><a href='./images/20051028/IMG_1519.JPG' ALT='IMG_1519.JPG'>IMG_1519.JPG</a></div></td>
<td><A ID='IMG_1520.JPG' href='pinnaclesandpinnipeds.php?fileId=IMG_1520.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1520.JPG' ALT='IMG_1520.JPG'><BR>IMG_1520.JPG<br>61.8 KB</a><div class='inv'><br><a href='./images/20051028/IMG_1520.JPG' ALT='IMG_1520.JPG'>IMG_1520.JPG</a></div></td>
<td><A ID='IMG_1523.JPG' href='pinnaclesandpinnipeds.php?fileId=IMG_1523.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1523.JPG' ALT='IMG_1523.JPG'><BR>IMG_1523.JPG<br>47.47 KB</a><div class='inv'><br><a href='./images/20051028/IMG_1523.JPG' ALT='IMG_1523.JPG'>IMG_1523.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_1535.JPG' href='pinnaclesandpinnipeds.php?fileId=IMG_1535.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1535.JPG' ALT='IMG_1535.JPG'><BR>IMG_1535.JPG<br>105.21 KB</a><div class='inv'><br><a href='./images/20051028/IMG_1535.JPG' ALT='IMG_1535.JPG'>IMG_1535.JPG</a></div></td>
<td><A ID='IMG_1540.JPG' href='pinnaclesandpinnipeds.php?fileId=IMG_1540.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1540.JPG' ALT='IMG_1540.JPG'><BR>IMG_1540.JPG<br>73.83 KB</a><div class='inv'><br><a href='./images/20051028/IMG_1540.JPG' ALT='IMG_1540.JPG'>IMG_1540.JPG</a></div></td>
<td><A ID='IMG_1544.JPG' href='pinnaclesandpinnipeds.php?fileId=IMG_1544.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1544.JPG' ALT='IMG_1544.JPG'><BR>IMG_1544.JPG<br>70.84 KB</a><div class='inv'><br><a href='./images/20051028/IMG_1544.JPG' ALT='IMG_1544.JPG'>IMG_1544.JPG</a></div></td>
<td><A ID='IMG_1546.JPG' href='pinnaclesandpinnipeds.php?fileId=IMG_1546.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1546.JPG' ALT='IMG_1546.JPG'><BR>IMG_1546.JPG<br>61.57 KB</a><div class='inv'><br><a href='./images/20051028/IMG_1546.JPG' ALT='IMG_1546.JPG'>IMG_1546.JPG</a></div></td>
<td><A ID='IMG_1547.JPG' href='pinnaclesandpinnipeds.php?fileId=IMG_1547.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1547.JPG' ALT='IMG_1547.JPG'><BR>IMG_1547.JPG<br>62.24 KB</a><div class='inv'><br><a href='./images/20051028/IMG_1547.JPG' ALT='IMG_1547.JPG'>IMG_1547.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_1550.JPG' href='pinnaclesandpinnipeds.php?fileId=IMG_1550.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1550.JPG' ALT='IMG_1550.JPG'><BR>IMG_1550.JPG<br>54.45 KB</a><div class='inv'><br><a href='./images/20051028/IMG_1550.JPG' ALT='IMG_1550.JPG'>IMG_1550.JPG</a></div></td>
<td><A ID='IMG_1551.JPG' href='pinnaclesandpinnipeds.php?fileId=IMG_1551.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1551.JPG' ALT='IMG_1551.JPG'><BR>IMG_1551.JPG<br>67.73 KB</a><div class='inv'><br><a href='./images/20051028/IMG_1551.JPG' ALT='IMG_1551.JPG'>IMG_1551.JPG</a></div></td>
<td><A ID='IMG_1553.JPG' href='pinnaclesandpinnipeds.php?fileId=IMG_1553.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1553.JPG' ALT='IMG_1553.JPG'><BR>IMG_1553.JPG<br>52.8 KB</a><div class='inv'><br><a href='./images/20051028/IMG_1553.JPG' ALT='IMG_1553.JPG'>IMG_1553.JPG</a></div></td>
<td><A ID='IMG_1556.JPG' href='pinnaclesandpinnipeds.php?fileId=IMG_1556.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1556.JPG' ALT='IMG_1556.JPG'><BR>IMG_1556.JPG<br>57.38 KB</a><div class='inv'><br><a href='./images/20051028/IMG_1556.JPG' ALT='IMG_1556.JPG'>IMG_1556.JPG</a></div></td>
<td><A ID='IMG_1557.JPG' href='pinnaclesandpinnipeds.php?fileId=IMG_1557.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1557.JPG' ALT='IMG_1557.JPG'><BR>IMG_1557.JPG<br>56.85 KB</a><div class='inv'><br><a href='./images/20051028/IMG_1557.JPG' ALT='IMG_1557.JPG'>IMG_1557.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_1559.JPG' href='pinnaclesandpinnipeds.php?fileId=IMG_1559.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1559.JPG' ALT='IMG_1559.JPG'><BR>IMG_1559.JPG<br>59.8 KB</a><div class='inv'><br><a href='./images/20051028/IMG_1559.JPG' ALT='IMG_1559.JPG'>IMG_1559.JPG</a></div></td>
<td><A ID='IMG_1562.JPG' href='pinnaclesandpinnipeds.php?fileId=IMG_1562.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1562.JPG' ALT='IMG_1562.JPG'><BR>IMG_1562.JPG<br>62.38 KB</a><div class='inv'><br><a href='./images/20051028/IMG_1562.JPG' ALT='IMG_1562.JPG'>IMG_1562.JPG</a></div></td>
<td><A ID='IMG_1566.JPG' href='pinnaclesandpinnipeds.php?fileId=IMG_1566.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1566.JPG' ALT='IMG_1566.JPG'><BR>IMG_1566.JPG<br>56.56 KB</a><div class='inv'><br><a href='./images/20051028/IMG_1566.JPG' ALT='IMG_1566.JPG'>IMG_1566.JPG</a></div></td>
<td><A ID='IMG_1567.JPG' href='pinnaclesandpinnipeds.php?fileId=IMG_1567.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1567.JPG' ALT='IMG_1567.JPG'><BR>IMG_1567.JPG<br>58.37 KB</a><div class='inv'><br><a href='./images/20051028/IMG_1567.JPG' ALT='IMG_1567.JPG'>IMG_1567.JPG</a></div></td>
<td><A ID='IMG_1568.JPG' href='pinnaclesandpinnipeds.php?fileId=IMG_1568.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1568.JPG' ALT='IMG_1568.JPG'><BR>IMG_1568.JPG<br>57.25 KB</a><div class='inv'><br><a href='./images/20051028/IMG_1568.JPG' ALT='IMG_1568.JPG'>IMG_1568.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_1572.JPG' href='pinnaclesandpinnipeds.php?fileId=IMG_1572.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1572.JPG' ALT='IMG_1572.JPG'><BR>IMG_1572.JPG<br>122.12 KB</a><div class='inv'><br><a href='./images/20051028/IMG_1572.JPG' ALT='IMG_1572.JPG'>IMG_1572.JPG</a></div></td>
<td><A ID='IMG_1573.JPG' href='pinnaclesandpinnipeds.php?fileId=IMG_1573.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1573.JPG' ALT='IMG_1573.JPG'><BR>IMG_1573.JPG<br>49.59 KB</a><div class='inv'><br><a href='./images/20051028/IMG_1573.JPG' ALT='IMG_1573.JPG'>IMG_1573.JPG</a></div></td>
<td><A ID='IMG_1577.JPG' href='pinnaclesandpinnipeds.php?fileId=IMG_1577.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1577.JPG' ALT='IMG_1577.JPG'><BR>IMG_1577.JPG<br>62.35 KB</a><div class='inv'><br><a href='./images/20051028/IMG_1577.JPG' ALT='IMG_1577.JPG'>IMG_1577.JPG</a></div></td>
<td><A ID='IMG_1583.JPG' href='pinnaclesandpinnipeds.php?fileId=IMG_1583.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1583.JPG' ALT='IMG_1583.JPG'><BR>IMG_1583.JPG<br>49.36 KB</a><div class='inv'><br><a href='./images/20051028/IMG_1583.JPG' ALT='IMG_1583.JPG'>IMG_1583.JPG</a></div></td>
<td><A ID='IMG_1586.JPG' href='pinnaclesandpinnipeds.php?fileId=IMG_1586.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1586.JPG' ALT='IMG_1586.JPG'><BR>IMG_1586.JPG<br>64.58 KB</a><div class='inv'><br><a href='./images/20051028/IMG_1586.JPG' ALT='IMG_1586.JPG'>IMG_1586.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_1590.JPG' href='pinnaclesandpinnipeds.php?fileId=IMG_1590.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1590.JPG' ALT='IMG_1590.JPG'><BR>IMG_1590.JPG<br>66.63 KB</a><div class='inv'><br><a href='./images/20051028/IMG_1590.JPG' ALT='IMG_1590.JPG'>IMG_1590.JPG</a></div></td>
<td><A ID='IMG_1591.JPG' href='pinnaclesandpinnipeds.php?fileId=IMG_1591.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1591.JPG' ALT='IMG_1591.JPG'><BR>IMG_1591.JPG<br>80.21 KB</a><div class='inv'><br><a href='./images/20051028/IMG_1591.JPG' ALT='IMG_1591.JPG'>IMG_1591.JPG</a></div></td>
<td><A ID='IMG_1595.JPG' href='pinnaclesandpinnipeds.php?fileId=IMG_1595.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1595.JPG' ALT='IMG_1595.JPG'><BR>IMG_1595.JPG<br>57.13 KB</a><div class='inv'><br><a href='./images/20051028/IMG_1595.JPG' ALT='IMG_1595.JPG'>IMG_1595.JPG</a></div></td>
<td><A ID='IMG_1597.JPG' href='pinnaclesandpinnipeds.php?fileId=IMG_1597.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1597.JPG' ALT='IMG_1597.JPG'><BR>IMG_1597.JPG<br>54.52 KB</a><div class='inv'><br><a href='./images/20051028/IMG_1597.JPG' ALT='IMG_1597.JPG'>IMG_1597.JPG</a></div></td>
<td><A ID='IMG_1600.JPG' href='pinnaclesandpinnipeds.php?fileId=IMG_1600.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1600.JPG' ALT='IMG_1600.JPG'><BR>IMG_1600.JPG<br>63.62 KB</a><div class='inv'><br><a href='./images/20051028/IMG_1600.JPG' ALT='IMG_1600.JPG'>IMG_1600.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_1601.JPG' href='pinnaclesandpinnipeds.php?fileId=IMG_1601.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1601.JPG' ALT='IMG_1601.JPG'><BR>IMG_1601.JPG<br>59.59 KB</a><div class='inv'><br><a href='./images/20051028/IMG_1601.JPG' ALT='IMG_1601.JPG'>IMG_1601.JPG</a></div></td>
<td><A ID='IMG_1602.JPG' href='pinnaclesandpinnipeds.php?fileId=IMG_1602.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1602.JPG' ALT='IMG_1602.JPG'><BR>IMG_1602.JPG<br>66.68 KB</a><div class='inv'><br><a href='./images/20051028/IMG_1602.JPG' ALT='IMG_1602.JPG'>IMG_1602.JPG</a></div></td>
<td><A ID='IMG_1603.JPG' href='pinnaclesandpinnipeds.php?fileId=IMG_1603.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1603.JPG' ALT='IMG_1603.JPG'><BR>IMG_1603.JPG<br>43.33 KB</a><div class='inv'><br><a href='./images/20051028/IMG_1603.JPG' ALT='IMG_1603.JPG'>IMG_1603.JPG</a></div></td>
<td><A ID='IMG_1604.JPG' href='pinnaclesandpinnipeds.php?fileId=IMG_1604.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1604.JPG' ALT='IMG_1604.JPG'><BR>IMG_1604.JPG<br>46.14 KB</a><div class='inv'><br><a href='./images/20051028/IMG_1604.JPG' ALT='IMG_1604.JPG'>IMG_1604.JPG</a></div></td>
<td><A ID='IMG_1614.JPG' href='pinnaclesandpinnipeds.php?fileId=IMG_1614.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1614.JPG' ALT='IMG_1614.JPG'><BR>IMG_1614.JPG<br>64.5 KB</a><div class='inv'><br><a href='./images/20051028/IMG_1614.JPG' ALT='IMG_1614.JPG'>IMG_1614.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_1616.JPG' href='pinnaclesandpinnipeds.php?fileId=IMG_1616.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1616.JPG' ALT='IMG_1616.JPG'><BR>IMG_1616.JPG<br>74.06 KB</a><div class='inv'><br><a href='./images/20051028/IMG_1616.JPG' ALT='IMG_1616.JPG'>IMG_1616.JPG</a></div></td>
<td><A ID='IMG_1618.JPG' href='pinnaclesandpinnipeds.php?fileId=IMG_1618.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1618.JPG' ALT='IMG_1618.JPG'><BR>IMG_1618.JPG<br>41.18 KB</a><div class='inv'><br><a href='./images/20051028/IMG_1618.JPG' ALT='IMG_1618.JPG'>IMG_1618.JPG</a></div></td>
<td><A ID='IMG_1621.JPG' href='pinnaclesandpinnipeds.php?fileId=IMG_1621.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1621.JPG' ALT='IMG_1621.JPG'><BR>IMG_1621.JPG<br>58.18 KB</a><div class='inv'><br><a href='./images/20051028/IMG_1621.JPG' ALT='IMG_1621.JPG'>IMG_1621.JPG</a></div></td>
<td><A ID='IMG_1628.JPG' href='pinnaclesandpinnipeds.php?fileId=IMG_1628.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1628.JPG' ALT='IMG_1628.JPG'><BR>IMG_1628.JPG<br>75.93 KB</a><div class='inv'><br><a href='./images/20051028/IMG_1628.JPG' ALT='IMG_1628.JPG'>IMG_1628.JPG</a></div></td>
<td><A ID='IMG_1631.JPG' href='pinnaclesandpinnipeds.php?fileId=IMG_1631.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1631.JPG' ALT='IMG_1631.JPG'><BR>IMG_1631.JPG<br>81.18 KB</a><div class='inv'><br><a href='./images/20051028/IMG_1631.JPG' ALT='IMG_1631.JPG'>IMG_1631.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_1634.JPG' href='pinnaclesandpinnipeds.php?fileId=IMG_1634.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1634.JPG' ALT='IMG_1634.JPG'><BR>IMG_1634.JPG<br>49.16 KB</a><div class='inv'><br><a href='./images/20051028/IMG_1634.JPG' ALT='IMG_1634.JPG'>IMG_1634.JPG</a></div></td>
<td><A ID='IMG_1639.JPG' href='pinnaclesandpinnipeds.php?fileId=IMG_1639.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1639.JPG' ALT='IMG_1639.JPG'><BR>IMG_1639.JPG<br>79.66 KB</a><div class='inv'><br><a href='./images/20051028/IMG_1639.JPG' ALT='IMG_1639.JPG'>IMG_1639.JPG</a></div></td>
<td><A ID='IMG_1643.JPG' href='pinnaclesandpinnipeds.php?fileId=IMG_1643.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1643.JPG' ALT='IMG_1643.JPG'><BR>IMG_1643.JPG<br>53.3 KB</a><div class='inv'><br><a href='./images/20051028/IMG_1643.JPG' ALT='IMG_1643.JPG'>IMG_1643.JPG</a></div></td>
<td><A ID='IMG_1655.JPG' href='pinnaclesandpinnipeds.php?fileId=IMG_1655.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1655.JPG' ALT='IMG_1655.JPG'><BR>IMG_1655.JPG<br>54.2 KB</a><div class='inv'><br><a href='./images/20051028/IMG_1655.JPG' ALT='IMG_1655.JPG'>IMG_1655.JPG</a></div></td>
<td><A ID='IMG_1660.JPG' href='pinnaclesandpinnipeds.php?fileId=IMG_1660.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1660.JPG' ALT='IMG_1660.JPG'><BR>IMG_1660.JPG<br>66.39 KB</a><div class='inv'><br><a href='./images/20051028/IMG_1660.JPG' ALT='IMG_1660.JPG'>IMG_1660.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_1662.JPG' href='pinnaclesandpinnipeds.php?fileId=IMG_1662.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1662.JPG' ALT='IMG_1662.JPG'><BR>IMG_1662.JPG<br>64.47 KB</a><div class='inv'><br><a href='./images/20051028/IMG_1662.JPG' ALT='IMG_1662.JPG'>IMG_1662.JPG</a></div></td>
<td><A ID='IMG_1669.JPG' href='pinnaclesandpinnipeds.php?fileId=IMG_1669.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1669.JPG' ALT='IMG_1669.JPG'><BR>IMG_1669.JPG<br>70.11 KB</a><div class='inv'><br><a href='./images/20051028/IMG_1669.JPG' ALT='IMG_1669.JPG'>IMG_1669.JPG</a></div></td>
<td><A ID='IMG_1674.JPG' href='pinnaclesandpinnipeds.php?fileId=IMG_1674.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1674.JPG' ALT='IMG_1674.JPG'><BR>IMG_1674.JPG<br>67.48 KB</a><div class='inv'><br><a href='./images/20051028/IMG_1674.JPG' ALT='IMG_1674.JPG'>IMG_1674.JPG</a></div></td>
<td><A ID='IMG_1676.JPG' href='pinnaclesandpinnipeds.php?fileId=IMG_1676.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1676.JPG' ALT='IMG_1676.JPG'><BR>IMG_1676.JPG<br>69.47 KB</a><div class='inv'><br><a href='./images/20051028/IMG_1676.JPG' ALT='IMG_1676.JPG'>IMG_1676.JPG</a></div></td>
<td><A ID='IMG_1677.JPG' href='pinnaclesandpinnipeds.php?fileId=IMG_1677.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1677.JPG' ALT='IMG_1677.JPG'><BR>IMG_1677.JPG<br>67.87 KB</a><div class='inv'><br><a href='./images/20051028/IMG_1677.JPG' ALT='IMG_1677.JPG'>IMG_1677.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_1679.JPG' href='pinnaclesandpinnipeds.php?fileId=IMG_1679.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1679.JPG' ALT='IMG_1679.JPG'><BR>IMG_1679.JPG<br>70.05 KB</a><div class='inv'><br><a href='./images/20051028/IMG_1679.JPG' ALT='IMG_1679.JPG'>IMG_1679.JPG</a></div></td>
<td><A ID='IMG_1680.JPG' href='pinnaclesandpinnipeds.php?fileId=IMG_1680.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1680.JPG' ALT='IMG_1680.JPG'><BR>IMG_1680.JPG<br>51.17 KB</a><div class='inv'><br><a href='./images/20051028/IMG_1680.JPG' ALT='IMG_1680.JPG'>IMG_1680.JPG</a></div></td>
<td><A ID='IMG_1684.JPG' href='pinnaclesandpinnipeds.php?fileId=IMG_1684.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1684.JPG' ALT='IMG_1684.JPG'><BR>IMG_1684.JPG<br>75.91 KB</a><div class='inv'><br><a href='./images/20051028/IMG_1684.JPG' ALT='IMG_1684.JPG'>IMG_1684.JPG</a></div></td>
<td><A ID='IMG_1685.JPG' href='pinnaclesandpinnipeds.php?fileId=IMG_1685.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1685.JPG' ALT='IMG_1685.JPG'><BR>IMG_1685.JPG<br>86.61 KB</a><div class='inv'><br><a href='./images/20051028/IMG_1685.JPG' ALT='IMG_1685.JPG'>IMG_1685.JPG</a></div></td>
<td><A ID='IMG_1714.JPG' href='pinnaclesandpinnipeds.php?fileId=IMG_1714.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1714.JPG' ALT='IMG_1714.JPG'><BR>IMG_1714.JPG<br>82 KB</a><div class='inv'><br><a href='./images/20051028/IMG_1714.JPG' ALT='IMG_1714.JPG'>IMG_1714.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_1721.JPG' href='pinnaclesandpinnipeds.php?fileId=IMG_1721.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1721.JPG' ALT='IMG_1721.JPG'><BR>IMG_1721.JPG<br>69.77 KB</a><div class='inv'><br><a href='./images/20051028/IMG_1721.JPG' ALT='IMG_1721.JPG'>IMG_1721.JPG</a></div></td>
<td><A ID='IMG_1725.JPG' href='pinnaclesandpinnipeds.php?fileId=IMG_1725.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1725.JPG' ALT='IMG_1725.JPG'><BR>IMG_1725.JPG<br>56.7 KB</a><div class='inv'><br><a href='./images/20051028/IMG_1725.JPG' ALT='IMG_1725.JPG'>IMG_1725.JPG</a></div></td>
<td><A ID='IMG_1729.JPG' href='pinnaclesandpinnipeds.php?fileId=IMG_1729.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1729.JPG' ALT='IMG_1729.JPG'><BR>IMG_1729.JPG<br>89.7 KB</a><div class='inv'><br><a href='./images/20051028/IMG_1729.JPG' ALT='IMG_1729.JPG'>IMG_1729.JPG</a></div></td>
<td><A ID='IMG_1731.JPG' href='pinnaclesandpinnipeds.php?fileId=IMG_1731.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1731.JPG' ALT='IMG_1731.JPG'><BR>IMG_1731.JPG<br>59.09 KB</a><div class='inv'><br><a href='./images/20051028/IMG_1731.JPG' ALT='IMG_1731.JPG'>IMG_1731.JPG</a></div></td>
<td><A ID='IMG_1735.JPG' href='pinnaclesandpinnipeds.php?fileId=IMG_1735.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1735.JPG' ALT='IMG_1735.JPG'><BR>IMG_1735.JPG<br>115.99 KB</a><div class='inv'><br><a href='./images/20051028/IMG_1735.JPG' ALT='IMG_1735.JPG'>IMG_1735.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_1737.JPG' href='pinnaclesandpinnipeds.php?fileId=IMG_1737.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1737.JPG' ALT='IMG_1737.JPG'><BR>IMG_1737.JPG<br>124.09 KB</a><div class='inv'><br><a href='./images/20051028/IMG_1737.JPG' ALT='IMG_1737.JPG'>IMG_1737.JPG</a></div></td>
<td><A ID='IMG_1739.JPG' href='pinnaclesandpinnipeds.php?fileId=IMG_1739.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1739.JPG' ALT='IMG_1739.JPG'><BR>IMG_1739.JPG<br>87.78 KB</a><div class='inv'><br><a href='./images/20051028/IMG_1739.JPG' ALT='IMG_1739.JPG'>IMG_1739.JPG</a></div></td>
<td><A ID='IMG_1741.JPG' href='pinnaclesandpinnipeds.php?fileId=IMG_1741.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1741.JPG' ALT='IMG_1741.JPG'><BR>IMG_1741.JPG<br>70.05 KB</a><div class='inv'><br><a href='./images/20051028/IMG_1741.JPG' ALT='IMG_1741.JPG'>IMG_1741.JPG</a></div></td>
<td><A ID='IMG_1742.JPG' href='pinnaclesandpinnipeds.php?fileId=IMG_1742.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1742.JPG' ALT='IMG_1742.JPG'><BR>IMG_1742.JPG<br>77.52 KB</a><div class='inv'><br><a href='./images/20051028/IMG_1742.JPG' ALT='IMG_1742.JPG'>IMG_1742.JPG</a></div></td>
<td><A ID='IMG_1743.JPG' href='pinnaclesandpinnipeds.php?fileId=IMG_1743.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1743.JPG' ALT='IMG_1743.JPG'><BR>IMG_1743.JPG<br>122.27 KB</a><div class='inv'><br><a href='./images/20051028/IMG_1743.JPG' ALT='IMG_1743.JPG'>IMG_1743.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_1744.JPG' href='pinnaclesandpinnipeds.php?fileId=IMG_1744.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1744.JPG' ALT='IMG_1744.JPG'><BR>IMG_1744.JPG<br>101.56 KB</a><div class='inv'><br><a href='./images/20051028/IMG_1744.JPG' ALT='IMG_1744.JPG'>IMG_1744.JPG</a></div></td>
<td><A ID='IMG_1748.JPG' href='pinnaclesandpinnipeds.php?fileId=IMG_1748.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1748.JPG' ALT='IMG_1748.JPG'><BR>IMG_1748.JPG<br>77.55 KB</a><div class='inv'><br><a href='./images/20051028/IMG_1748.JPG' ALT='IMG_1748.JPG'>IMG_1748.JPG</a></div></td>
<td><A ID='IMG_1750.JPG' href='pinnaclesandpinnipeds.php?fileId=IMG_1750.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1750.JPG' ALT='IMG_1750.JPG'><BR>IMG_1750.JPG<br>64.05 KB</a><div class='inv'><br><a href='./images/20051028/IMG_1750.JPG' ALT='IMG_1750.JPG'>IMG_1750.JPG</a></div></td>
<td><A ID='IMG_1751.JPG' href='pinnaclesandpinnipeds.php?fileId=IMG_1751.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1751.JPG' ALT='IMG_1751.JPG'><BR>IMG_1751.JPG<br>46.59 KB</a><div class='inv'><br><a href='./images/20051028/IMG_1751.JPG' ALT='IMG_1751.JPG'>IMG_1751.JPG</a></div></td>
<td><A ID='IMG_1752.JPG' href='pinnaclesandpinnipeds.php?fileId=IMG_1752.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1752.JPG' ALT='IMG_1752.JPG'><BR>IMG_1752.JPG<br>83.22 KB</a><div class='inv'><br><a href='./images/20051028/IMG_1752.JPG' ALT='IMG_1752.JPG'>IMG_1752.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_1754.JPG' href='pinnaclesandpinnipeds.php?fileId=IMG_1754.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1754.JPG' ALT='IMG_1754.JPG'><BR>IMG_1754.JPG<br>70.43 KB</a><div class='inv'><br><a href='./images/20051028/IMG_1754.JPG' ALT='IMG_1754.JPG'>IMG_1754.JPG</a></div></td>
<td><A ID='IMG_1757.JPG' href='pinnaclesandpinnipeds.php?fileId=IMG_1757.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1757.JPG' ALT='IMG_1757.JPG'><BR>IMG_1757.JPG<br>98.54 KB</a><div class='inv'><br><a href='./images/20051028/IMG_1757.JPG' ALT='IMG_1757.JPG'>IMG_1757.JPG</a></div></td>
<td><A ID='IMG_1758.JPG' href='pinnaclesandpinnipeds.php?fileId=IMG_1758.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1758.JPG' ALT='IMG_1758.JPG'><BR>IMG_1758.JPG<br>94.08 KB</a><div class='inv'><br><a href='./images/20051028/IMG_1758.JPG' ALT='IMG_1758.JPG'>IMG_1758.JPG</a></div></td>
<td><A ID='IMG_1760.JPG' href='pinnaclesandpinnipeds.php?fileId=IMG_1760.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051028/IMG_1760.JPG' ALT='IMG_1760.JPG'><BR>IMG_1760.JPG<br>62.03 KB</a><div class='inv'><br><a href='./images/20051028/IMG_1760.JPG' ALT='IMG_1760.JPG'>IMG_1760.JPG</a></div></td>
</tr>
</table>	</div>
</div>
</body>
</html>