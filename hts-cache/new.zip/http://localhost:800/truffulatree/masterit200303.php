<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - March 2003 - Q&A letters</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="Q&A letters">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="Q&A letters" href='masterit200301.php'>January 2003</a></li>
<li><a title="Q&A letters" href='masterit200302.php'>February 2003</a></li>
<li><div class='activemenu'>March 2003</div></li>
<li><a title="Q&A letters" href='masterit200304.php'>April 2003</a></li>
<li><a title="Q&A letters" href='masterit200305.php'>May 2003</a></li>
<li><a title="Q&A letters" href='masterit200306.php'>June 2003</a></li>
<li><a title="Q&A letters" href='masterit200307.php'>July 2003</a></li>
<li><a title="Q&A letters" href='masterit200308.php'>August 2003</a></li>
<li><a title="Q&A letters" href='masterit200309.php'>September 2003</a></li>
<li><a title="Q&A letters" href='masterit200310.php'>October 2003</a></li>
<li><a title="Q&A letters" href='masterit200311.php'>November 2003</a></li>
<li><a title="Q&A letters" href='masterit200312.php'>December 2003</a></li>
<li> </li><br><li>Or go back to:</li><li><a title='Q&A/MasterIT letters from 2003' href="masterit2003.php">2003 archive</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>March 2003</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Mark's writing' href="written.php">Professional Writing</a> > <a title='My weekly Q&A column in The Australian' href="masterIT.php">MasterIT</a> > <a title='Q&A/MasterIT letters from 2003' href="masterit2003.php">2003 archive</a> > <a title='Q&A letters' href="masterit200303.php">March 2003</a>
<br><br>		<br>
<h2>11/3/03</h2><br>
<b>I was recently using my PC when my APC brand UPS decided to go crazy and cut all power. My PC now crashes on startup just after the "Loading Windows XP" screen with a message stating "Stop: c0000218 {Registry File Failure} The registry cannot load the hive (file): \SystemRoot\System32\Config\SOFTWARE or its log or alternate". What happened? Please help! My thesis is on this PC!</b><br>
<br>
Ouch, sounds nasty. The worst case scenario is that you may be looking at a complete reinstall of Windows. On the plus side though it's very likely your uni files are still intact.<br>
<br>
What most likely happened is that when your UPS cut the power, Windows was in the process of writing to the registry, and it has been corrupted.<br>
<br>
The first thing to recommend here is to ditch your UPS for another model. If you can't trust it to maintain power it's not much use!<br>
<br>
Secondly, have a minor slap on the wrist for (we assume) not having vital files backed up! Even something as simple as emailing your thesis to a friend every day can save you a lot of heartache.<br>
<br>
As far as fixing the problem goes, try this. It gets a little involved but if you take it step by step it should be fairly easy.<br>
<br>
First, you'll need to boot from your original XP installation disc. After it finishes loading, press "R" to activate the System Recovery Console.<br>
<br>
For help getting this far you can also refer to <a href="support.microsoft.com/default.aspx?scid=kb;en-us;q307654" target="_blank">support.microsoft.com/default.aspx?scid=kb;en-us;q307654</a><br>
<br>
Once at the recovery console prompt (most likely C:) type the following commands:<br>
<br>
cd windowssystem32config<br>
ren software software.bad<br>
copy windowsepairsoftware software<br>
exit<br>
<br>
Your PC will restart, and should not crash. Don't be alarmed if everything looks wrong and you get some minor error messages, the main thing here is that we are back into Windows.<br>
<br>
Next, run "System Restore", located in Start->Programs->Accessories->System Tools. Follow the instructions on the screen, it's fairly straightforward. Try to pick the most recent date before the problem happened.<br>
<br>
Finally, reboot and cross your fingers!<br>
<br>
If you still have problems, a fresh copy of Windows is needed. But first grab a friendly geek to help you get your files - they are almost certainly still there and intact.<br>
<br>
<br>
<h2>18/3/03</h2><br>
<b>My IE keeps crashing all the time. It used to be fine but now it crashes each time after 15 minutes or so. Got any advice? </b><br>
<br>
First, make sure you are up to date with the latest version of IE, and all the patches required. IE6 SP1 is the latest offering from Microsoft, and can be found at <a href="http://www.microsoft.com/ie" target="_blank">www.microsoft.com/ie</a>.<br>
<br>
If that doesn't help, you may need to reinstall Windows (the old favourite). Another option is to give a different browser a go.<br>
<br>
Mozilla (<a href="http://www.mozilla.org" target="_blank">www.mozilla.org</a>) is a good place to start; it is a very stable browser, available not only for Windows but Macs and Linux too. It is also the browser that Netscape 6 and 7 are built on, but it comes with somewhat less baggage than the aforementioned behemoth.<br>
<br>
It has a bunch of features that IE lacks, including the ability to block certain images and popup windows (in other words, ads).<br>
<br>
The browser also has a feature called "tabbed browsing" which lets you have several web pages open in a single window, and is a must for anyone who loves opening 50 sites at once.<br>
<br>
Additionally, Mozilla comes with a very decent mail & newsgroup reader. The latest beta version even supports a degree of automatic junk mail filtering. <br>
<br>
<br>
<b>More on Mac-PC networking</b><br>
We've also had some feedback from readers regarding the MasterIT column that dealt with networking that-which-is-beige to that-which-is-chrome. It seems we were stuck back in the last century with the technology!<br>
<br>
Macs running OS9 do require the Dave software to network with PCs, however Macs with OS X 10.1 and above can talk to PC networks without any trouble at all.<br>
<br>
From the Finder, select the Connect to Server option in the Go menu. From here you can browse the network and select the PC and share you wish to connect to, it's that easy.<br>
<br>
Users running OS X 10.2 can also share their files on a PC network in a similar way. See the following two links for more information:<br>
<br>
<a href="docs.info.apple.com/article.html?artnum=106471" target="_blank">docs.info.apple.com/article.html?artnum=106471</a> (for connecting to a PC)<br>
<a href="docs.info.apple.com/article.html?artnum=107083" target="_blank">docs.info.apple.com/article.html?artnum=107083</a> (for sharing files with a PC)<br>
<br>
<br>
<h2>25/3/03</h2><br>
<b>I'm thinking of purchasing a DVD drive for my PC, and I was wondering what the deal is with watching movies. Do I need any special software? My video card also has a TV out - I'd like to find out about using it as well. I'm using XP.</b><br>
<br>
It's no problem at all playing back DVD movies on computer.<br>
<br>
You'll need some DVD playback software, but most DVD drives these days come bundled with it.<br>
<br>
PowerDVD is a common package, and is a very decent program - it's quite configurable and will even let you utilise surround sound (provided your sound card supports it).<br>
<br>
Using your video card's TV-out with XP is also pretty easy. Exactly how you go about it depends on which brand of video card you have; the settings are generally tucked away in the advanced section of the Display Properties.<br>
<br>
If you have an Nvidia brand card, you might also want to check out TVTool (<a href="http://www.tvtool.com" target="_blank">www.tvtool.com</a>) - it's not free, but gives you a lot more options for TV output than the standard drivers allow, like support for widescreen output and flicker reduction.<br>
<br>
<br>
<b>I've had cable internet connected for some time, but now I'd like to share it with my flatmates. What are the options? One friend said we'll need a router costing several hundred dollars but I've also heard it can be done more cheaply with just a PC running Windows.</b><br>
<br>
Strictly speaking you don't need a router to share a cable connection. But it will make life a lot easier, and you won't need to leave your PC on all the time.<br>
<br>
Most internet sharing devices are very simple to get going as well, and they double as pretty good firewalls.<br>
<br>
Either way, first you'll need to set up a network connecting all the PCs that will want access, which is a whole other topic.<br>
<br>
Assuming you have a working network already and don't want to invest in a router, things get a little more complex.<br>
<br>
Rather than go into detail here, check out <a href="http://www.ozcableguy.com" target="_blank">www.ozcableguy.com</a> (a great resource for Australian broadband), specifically the cable guides. There are a few different ones for various types of Windows.<br>
<br>
<i><p>Did the information on this page help you? Entertain you? Bore you? <a href="contact.php?subject=MasterIT">Drop me a line</a>.</p>

<p>If you're feeling particularly generous, you can even <a href="buypics.php">click here to send me some dot-com riches</a>. Think of it as online busking.</i></p>
	</div>
</div>
</body>
</html>