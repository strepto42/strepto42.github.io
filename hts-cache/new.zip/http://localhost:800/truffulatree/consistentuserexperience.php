<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - CUE - MP3s from the CUE (Consistent User Experience - Mark Cocquio, Nathan Spargo and Wade Kuhn), including Monkey Magic and a really bad Gandhara cover</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="MP3s from the CUE (Consistent User Experience - Mark Cocquio, Nathan Spargo and Wade Kuhn), including Monkey Magic and a really bad Gandhara cover">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="Baker's Dozen MP3s (Mark Cocquio, Lindsay Halamek, Guy Bunn and he who must not be named)" href='bakersdozen.php'>Baker's Dozen</a></li>
<li><div class='activemenu'>CUE</div></li>
<li><a title="MP3s from Fuzzy Polaroid's gigs at the Step Inn and Second Degree Bar" href='fuzzypolaroidmp3s.php'>Fuzzy Polaroid</a></li>
<li> </li><br><li>Or go back to:</li><li><a title='Sounds and music' href="music.php">Music</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>CUE</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Sounds and music' href="music.php">Music</a> > <a title='MP3s from the CUE (Consistent User Experience - Mark Cocquio, Nathan Spargo and Wade Kuhn), including Monkey Magic and a really bad Gandhara cover' href="consistentuserexperience.php">CUE</a>
<br><br>		<br>
Herein lies some random music created by yours truly (on bass) and a couple of mates, <a href="http://www.wadekuhn.com" target="_blank">Wade</a> and <a href="http://www.digi-comic.com" target="_blank">Nathan</a>. We had fun letting off steam and jamming on a regular basis. Hence, the CUE (or, Consistent User Experience) was born.<br>
<br>
A note - if you came here after doing a search for "Gandhara mp3" or something like that, you might like to know that the version on this page isn't the original (duh) - it's a shitty cover. No, we hadn't rehearsed it. I think it has it's moments, but not many of them.<br>
<br>
If you'd like to sample some of the other mp3s here, I can recommend tracks 1 and 2 (particularly track 2). Also made up on the spot, they have a certain groove to them which I quite like, even if the sound quality is reminiscent of skeletons fucking in a biscuit tin, and we're all playing wrong notes and losing the beat from time to time. Tracks 5, 7 and 9 are also impromptu jams.<br>
<br>
Track 3 is indeed a cover of the Monkey Magic theme. I quite like it, even if it lacks vocals.<br>
<br>
Track 4 is the bad Gandhara cover. Track 6 is an even worse Rage Against the Machine effort. I claim no responsibility - I can actually play that song start to finish on bass. I was just let down by my band (and I can be snobbish cos it's MY website dammit!), who didn't know the structure of the song. Feh.<br>
<br>
Finally, the last track may be familiar to Goodies fans.<br>
<br>
Update - Nathan has created a jokey Myspace page for the <a href="http://www.myspace.com/consistentuserexperience" title="Consistent User Experience" target="_blank">CUE</a>. We will use it as a dumping ground for all of our musical exploits. Click on the link to view it.<br>
<br>
Feel free to <a href="contact.php">email me</a> and tell me what you think.<br>
<br>
So, without further ado, I give you the debut album from the CUE.<br>
<br>
<img src="images/cueCover.jpg" alt="the Consistent User Experience Album Cover"><br>
<br><br>
Files available for download:<br>
<ul class="dirlist"><li><a href="./files/cue/01 - Opening Jam.mp3">01 - Opening Jam.mp3</a></li><li><a href="./files/cue/02 - Lap 17.mp3">02 - Lap 17.mp3</a></li><li><a href="./files/cue/03 - Monkey Magic.mp3">03 - Monkey Magic.mp3</a></li><li><a href="./files/cue/04 - Gandhara.mp3">04 - Gandhara.mp3</a></li><li><a href="./files/cue/05 - Pharoah's Polka.mp3">05 - Pharoah's Polka.mp3</a></li><li><a href="./files/cue/06 - Bullet in the Head.mp3">06 - Bullet in the Head.mp3</a></li><li><a href="./files/cue/07 - Yeah.mp3">07 - Yeah.mp3</a></li><li><a href="./files/cue/08 - Miss You.mp3">08 - Miss You.mp3</a></li><li><a href="./files/cue/09 - Swinging Blues.mp3">09 - Swinging Blues.mp3</a></li><li><a href="./files/cue/10 - Run.mp3">10 - Run.mp3</a></li></ul><!-- old method
getTheFiles($file);

function getTheFiles($folder) {
	if ($handle = opendir($folder)) {
		while (false !== ($file = readdir($handle))) {
			If ($file!= "." && $file!= ".." and !is_dir($folder."/".$file)) {
				$filesize = round(filesize ($folder."/".$file)/1024,2);
				echo "<tr><td><div align='left'><A href='$corelise$folder/$file'>$file</a></div></td><td><div align='left'>$filesize KB</div></td><tr>\n";
			} else {
			If ($file!= "." && $file!= ".." and is_dir($folder."/".$file)) {
				getTheFiles($file);
			}
		}
		closedir($handle);
	}
} -->
	</div>
</div>
</body>
</html>