<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - 26/1/2006 - Full Circle</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="Full Circle">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="Greetings from a Bum" href='greetingsfromabum.php'>29/4/2005</a></li>
<li><a title="Onward" href='onward.php'>2/5/2005</a></li>
<li><a title="It's a tough life (pt 1: Bundaberg, Agnes Water and 1770)" href='itsatoughlife1.php'>17/5/2005</a></li>
<li><a title="It's a tough life (pt 2: Rockhampton, Emu Park and Great Keppel Island)" href='itsatoughlife2.php'>23/5/2005</a></li>
<li><a title="There and Back Again - a Yo-yo's Tale" href='thereandbackagain.php'>18/6/2005</a></li>
<li><a title="Platypi and Grey Nomads" href='platypiandgreynomads.php'>24/6/2005</a></li>
<li><a title="Blowing Bubbles in a Watery Tomb" href='blowingbubbles.php'>1/7/2005</a></li>
<li><a title="Pieces of History" href='piecesofhistory.php'>8/7/2005</a></li>
<li><a title="Walks and Waterfalls" href='walksandwaterfalls.php'>15/7/2005</a></li>
<li><a title="Mission to Tribulation" href='missiontotribulation.php'>22/7/2005</a></li>
<li><a title="Levity, Limestone and Lava" href='levitylimestoneandlava.php'>29/7/2005</a></li>
<li><a title="Into the Never Never" href='intothenevernever.php'>5/8/2005</a></li>
<li><a title="Slowing the pace in Darwin" href='slowingthepaceindarwin.php'>12/8/2005</a></li>
<li><a title="Blistering Barnacles and Leaping Lizards" href='leapinglizards.php'>19/8/2005</a></li>
<li><a title="Kakadu and Litchfield" href='kakadu.php'>26/8/2005</a></li>
<li><a title="Legacies of War" href='legaciesofwar.php'>2/9/2005</a></li>
<li><a title="Go West" href='gowest.php'>10/9/2005</a></li>
<li><a title="Things from Above" href='thingsfromabove.php'>16/9/2005</a></li>
<li><a title="The West Coast" href='thewestcoast.php'>23/9/2005</a></li>
<li><a title="Reefs and Red Dust" href='reefsandreddust.php'>30/9/2005</a></li>
<li><a title="The Pilbara" href='pilbara.php'>7/10/2005</a></li>
<li><a title="Paradise with a Headwind" href='paradisewithaheadwind.php'>14/10/2005</a></li>
<li><a title="Down the Coral Coast" href='downthecoralcoast.php'>21/10/2005</a></li>
<li><a title="Pinnacles and Pinnipeds" href='pinnaclesandpinnipeds.php'>28/10/2005</a></li>
<li><a title="A week in Perth" href='perth.php'>4/11/2005</a></li>
<li><a title="The Southwest (from Above and Below)" href='thesouthwest.php'>11/11/2005</a></li>
<li><a title="More Heights and Depths" href='moreheightsanddepths.php'>18/11/2005</a></li>
<li><a title="Across the Nullarbor (and a bit beyond)" href='nullarbor.php'>25/11/2005</a></li>
<li><a title="Double Whammy" href='doublewhammy.php'>9/12/2005</a></li>
<li><a title="Two Cities" href='twocities.php'>19/12/2005</a></li>
<li><a title="Tassie - Part 1" href='tassie1.php'>1/1/2006</a></li>
<li><a title="Tassie - Part 2" href='tassie2.php'>7/1/2006</a></li>
<li><div class='activemenu'>26/1/2006</div></li>
<li><a title="The Wrap Up" href='thewrapup.php'>23/3/2006</a></li>
<li> </li><br><li>Or go back to:</li><li><a title='Travelouges and blogs from my trip around Australia' href="nerdseyeview.php">Nerd's Eye View</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>26/1/2006</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Travel stories and pictures' href="travel.php">Travelogues</a> > <a title='Travelouges and blogs from my trip around Australia' href="nerdseyeview.php">Nerd's Eye View</a> > <a title='Full Circle' href="fullcircle.php">26/1/2006</a>
<br><br>		


<h1>Full Circle</h1>

<a href="images/maps/Map060126.gif"><img src="images/maps/Map060126_sm.gif" align="right"></a>

<p>Hi all, here I am again, with the penultimate instalment of Nerd's Eye View! In the past couple of weeks we've driven more than 2700kms, and travelled 1700kms as the crow flies, and I'm now back in Brisvegas, at the end of my country-wide loop.</p>

<p>Despite the enormous number of Ks we've clocked up, much of the time has been spent relaxing rather than adventuring. But before we get to that I should rewind back to where I last left off - on a big-arse boat from Devonport to Melbourne.</p>

<p>The rest of the Bass Strait journey was entirely uneventful, and we made it in to Melbourne in the early evening. My mate Shams, and Jana's sister Hildy were both out of town, so we didn't hang around, electing instead to push north as far as I could comfortably manage. In the end, we made it as far as Seymour, on the Hume Highway, and crashed for the night in a cute half-caravan-half-cabin.</p>

<p>The next day we headed north again to Wodonga on the NSW border, but rather than drive directly to Canberra and Sydney we decided to have one more adventure and check out the Snowy Mountains, including Thredbo and Mt Kosciusko.</p>

<p>It was a very pleasant drive up through the hills, and of course we escaped the impending heat for one last night. After camping for free with every man and his dog near the Thredbo River we went for a short walk and then headed to Thredbo itself to catch the chairlift up the mountain.</p>

<p>Up on top we walked to the Kosciusko lookout, and decided that the extra 9kms to the summit of Australia's highest mountain and back weren't particularly worth it - especially as it's basically just a hill on top of a plateau.</p>

<p>Lazy - sure. But we spent the time we saved checking out a patch of grubby perennial snow that somehow manages to survive the summer heat. Interestingly, there are a few of these patches, and they're in the same spots each year (as best I can tell from the photographs of the area). I'm pretty sure that I visited the same grubby patch of snow when I was a kid on a family holiday once.</p>

<p>All in all it was a lovely day; the area is quite beautiful in summer, and the ski resort town of Thredbo was eerily deserted for the most part (even if the camping grounds weren't).</p>

<p>Next it was back in the car, and a drive via Jindabyne and Cooma to Canberra, where my sister Heather put us up for the night. I went for a bike ride the next day (in balmy thirty-something degree heat) and took a few snaps of the area, including Parliament House. Little Johnny wasn't in attendance of course; he probably had a cricket match to attend, or a U.S posterior that needed oral attention.</p>

<p>Then we headed to Sydney, breaking the monotonous (yet mercifully relatively short) drive with a stop over in Goulburn to check out the Big Merino. This towering, evil-eyed fibreglass sheep is, in my opinion, the finest of Australia's "big" monstrosities  (many of which are just plain pissy to be honest). You can climb up inside too, and peer out it's eyes, and we did this, braving the stifling heat within - I reckon it was easily in the 50s up the top.</p>

<p>Which brings us to Sydney - I managed to catch up with many of you of course, so I shan't go on too much about that. Suffice to say it was great to see everyone on the various occasions. Thanks go to my folks and Jacquie for putting us up.</p>

<p>After Sydney we drove up to Katoomba in the Blue Mountains, and caught up with more good people who gave us free accommodation, free food and plenty of tasty beverages. Once again, thanks go out to Daniel and Anne, and Alan and Annie.</p>

<p>The Blue Mountains turned on a lovely display of fog and rain for all bar one day, but we didn't actually mind. We visited the obligatory tourist stops of Wentworth Falls and the Three Sisters at Echo Point. Daniel lent me his fisheye lens too which was kinda fun; I must get one at some stage.</p>

<p>Anyway, we hit the road again after a few days, and drove up to Jana's Mum's place near Lismore, stopping off overnight at Port Macquarie. My adventures there consisted of visiting Stephen (an ex-workmate), where a nice cuppa and bikkies ensued, and just generally lazing about. Thanks heaps of course too, to Annette and Pietro for yet more free accommodation.</p>

<p>And then, yesterday, I completed the circle on my own. Jana is staying with her Mum and will join me in a few days. I'll finish up Nerd's Eye View with a general wrap-up email in due course, so this isn't quite goodbye yet - but we best all brace ourselves! The real world beckons...</p>

<p>The final crop's picks are:</p>

<table width="800">
	<tr>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=IMG_6134.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6134.JPG' ALT='The boring boardwalk to Mt Kosciusko'><BR>The boring boardwalk to Mt Kosciusko</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=IMG_6316.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6316.JPG' ALT='The hill that is Parliament House, Canberra'><BR>The hill that is Parliament House, Canberra</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=IMG_6414.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6414.JPG' ALT='Sydney City from Valencia St Wharf'><BR>Sydney City from Valencia St Wharf</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=IMG_6654.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6654.JPG' ALT='Wentworth Falls in the midst of mist'><BR>Wentworth Falls in the midst of mist</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=IMG_6697.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6697.JPG' ALT='Three Shadowy Sisters'><BR>Three Shadowy Sisters</a>
	</td>
	</tr>
</table>

<br><br>
All images in this gallery:<br>
<table width='800'>
<tr>
</tr>
<tr><td><A ID='IMG_6078.JPG' href='fullcircle.php?fileId=IMG_6078.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6078.JPG' ALT='IMG_6078.JPG'><BR>IMG_6078.JPG<br>67.12 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6078.JPG' ALT='IMG_6078.JPG'>IMG_6078.JPG</a></div></td>
<td><A ID='IMG_6080.JPG' href='fullcircle.php?fileId=IMG_6080.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6080.JPG' ALT='IMG_6080.JPG'><BR>IMG_6080.JPG<br>71.86 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6080.JPG' ALT='IMG_6080.JPG'>IMG_6080.JPG</a></div></td>
<td><A ID='IMG_6081.JPG' href='fullcircle.php?fileId=IMG_6081.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6081.JPG' ALT='IMG_6081.JPG'><BR>IMG_6081.JPG<br>66.23 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6081.JPG' ALT='IMG_6081.JPG'>IMG_6081.JPG</a></div></td>
<td><A ID='IMG_6082.JPG' href='fullcircle.php?fileId=IMG_6082.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6082.JPG' ALT='IMG_6082.JPG'><BR>IMG_6082.JPG<br>91.46 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6082.JPG' ALT='IMG_6082.JPG'>IMG_6082.JPG</a></div></td>
<td><A ID='IMG_6083.JPG' href='fullcircle.php?fileId=IMG_6083.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6083.JPG' ALT='IMG_6083.JPG'><BR>IMG_6083.JPG<br>88.68 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6083.JPG' ALT='IMG_6083.JPG'>IMG_6083.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_6084.JPG' href='fullcircle.php?fileId=IMG_6084.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6084.JPG' ALT='IMG_6084.JPG'><BR>IMG_6084.JPG<br>105.47 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6084.JPG' ALT='IMG_6084.JPG'>IMG_6084.JPG</a></div></td>
<td><A ID='IMG_6085.JPG' href='fullcircle.php?fileId=IMG_6085.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6085.JPG' ALT='IMG_6085.JPG'><BR>IMG_6085.JPG<br>83.49 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6085.JPG' ALT='IMG_6085.JPG'>IMG_6085.JPG</a></div></td>
<td><A ID='IMG_6087.JPG' href='fullcircle.php?fileId=IMG_6087.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6087.JPG' ALT='IMG_6087.JPG'><BR>IMG_6087.JPG<br>71.69 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6087.JPG' ALT='IMG_6087.JPG'>IMG_6087.JPG</a></div></td>
<td><A ID='IMG_6092.JPG' href='fullcircle.php?fileId=IMG_6092.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6092.JPG' ALT='IMG_6092.JPG'><BR>IMG_6092.JPG<br>76.82 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6092.JPG' ALT='IMG_6092.JPG'>IMG_6092.JPG</a></div></td>
<td><A ID='IMG_6094.JPG' href='fullcircle.php?fileId=IMG_6094.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6094.JPG' ALT='IMG_6094.JPG'><BR>IMG_6094.JPG<br>48.92 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6094.JPG' ALT='IMG_6094.JPG'>IMG_6094.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_6098.JPG' href='fullcircle.php?fileId=IMG_6098.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6098.JPG' ALT='IMG_6098.JPG'><BR>IMG_6098.JPG<br>60.46 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6098.JPG' ALT='IMG_6098.JPG'>IMG_6098.JPG</a></div></td>
<td><A ID='IMG_6099.JPG' href='fullcircle.php?fileId=IMG_6099.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6099.JPG' ALT='IMG_6099.JPG'><BR>IMG_6099.JPG<br>67.49 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6099.JPG' ALT='IMG_6099.JPG'>IMG_6099.JPG</a></div></td>
<td><A ID='IMG_6101.JPG' href='fullcircle.php?fileId=IMG_6101.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6101.JPG' ALT='IMG_6101.JPG'><BR>IMG_6101.JPG<br>81.81 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6101.JPG' ALT='IMG_6101.JPG'>IMG_6101.JPG</a></div></td>
<td><A ID='IMG_6102.JPG' href='fullcircle.php?fileId=IMG_6102.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6102.JPG' ALT='IMG_6102.JPG'><BR>IMG_6102.JPG<br>80.48 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6102.JPG' ALT='IMG_6102.JPG'>IMG_6102.JPG</a></div></td>
<td><A ID='IMG_6105.JPG' href='fullcircle.php?fileId=IMG_6105.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6105.JPG' ALT='IMG_6105.JPG'><BR>IMG_6105.JPG<br>111.29 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6105.JPG' ALT='IMG_6105.JPG'>IMG_6105.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_6106.JPG' href='fullcircle.php?fileId=IMG_6106.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6106.JPG' ALT='IMG_6106.JPG'><BR>IMG_6106.JPG<br>96 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6106.JPG' ALT='IMG_6106.JPG'>IMG_6106.JPG</a></div></td>
<td><A ID='IMG_6112.JPG' href='fullcircle.php?fileId=IMG_6112.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6112.JPG' ALT='IMG_6112.JPG'><BR>IMG_6112.JPG<br>78.15 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6112.JPG' ALT='IMG_6112.JPG'>IMG_6112.JPG</a></div></td>
<td><A ID='IMG_6113.JPG' href='fullcircle.php?fileId=IMG_6113.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6113.JPG' ALT='IMG_6113.JPG'><BR>IMG_6113.JPG<br>68.52 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6113.JPG' ALT='IMG_6113.JPG'>IMG_6113.JPG</a></div></td>
<td><A ID='IMG_6118.JPG' href='fullcircle.php?fileId=IMG_6118.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6118.JPG' ALT='IMG_6118.JPG'><BR>IMG_6118.JPG<br>84.4 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6118.JPG' ALT='IMG_6118.JPG'>IMG_6118.JPG</a></div></td>
<td><A ID='IMG_6122.JPG' href='fullcircle.php?fileId=IMG_6122.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6122.JPG' ALT='IMG_6122.JPG'><BR>IMG_6122.JPG<br>38.07 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6122.JPG' ALT='IMG_6122.JPG'>IMG_6122.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_6127.JPG' href='fullcircle.php?fileId=IMG_6127.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6127.JPG' ALT='IMG_6127.JPG'><BR>IMG_6127.JPG<br>65.83 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6127.JPG' ALT='IMG_6127.JPG'>IMG_6127.JPG</a></div></td>
<td><A ID='IMG_6134.JPG' href='fullcircle.php?fileId=IMG_6134.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6134.JPG' ALT='IMG_6134.JPG'><BR>IMG_6134.JPG<br>65.5 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6134.JPG' ALT='IMG_6134.JPG'>IMG_6134.JPG</a></div></td>
<td><A ID='IMG_6136.JPG' href='fullcircle.php?fileId=IMG_6136.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6136.JPG' ALT='IMG_6136.JPG'><BR>IMG_6136.JPG<br>53.32 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6136.JPG' ALT='IMG_6136.JPG'>IMG_6136.JPG</a></div></td>
<td><A ID='IMG_6137.JPG' href='fullcircle.php?fileId=IMG_6137.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6137.JPG' ALT='IMG_6137.JPG'><BR>IMG_6137.JPG<br>75.93 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6137.JPG' ALT='IMG_6137.JPG'>IMG_6137.JPG</a></div></td>
<td><A ID='IMG_6138.JPG' href='fullcircle.php?fileId=IMG_6138.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6138.JPG' ALT='IMG_6138.JPG'><BR>IMG_6138.JPG<br>68.21 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6138.JPG' ALT='IMG_6138.JPG'>IMG_6138.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_6139.JPG' href='fullcircle.php?fileId=IMG_6139.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6139.JPG' ALT='IMG_6139.JPG'><BR>IMG_6139.JPG<br>94.89 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6139.JPG' ALT='IMG_6139.JPG'>IMG_6139.JPG</a></div></td>
<td><A ID='IMG_6141.JPG' href='fullcircle.php?fileId=IMG_6141.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6141.JPG' ALT='IMG_6141.JPG'><BR>IMG_6141.JPG<br>65.64 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6141.JPG' ALT='IMG_6141.JPG'>IMG_6141.JPG</a></div></td>
<td><A ID='IMG_6142.JPG' href='fullcircle.php?fileId=IMG_6142.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6142.JPG' ALT='IMG_6142.JPG'><BR>IMG_6142.JPG<br>72.52 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6142.JPG' ALT='IMG_6142.JPG'>IMG_6142.JPG</a></div></td>
<td><A ID='IMG_6145.JPG' href='fullcircle.php?fileId=IMG_6145.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6145.JPG' ALT='IMG_6145.JPG'><BR>IMG_6145.JPG<br>77.6 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6145.JPG' ALT='IMG_6145.JPG'>IMG_6145.JPG</a></div></td>
<td><A ID='IMG_6147.JPG' href='fullcircle.php?fileId=IMG_6147.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6147.JPG' ALT='IMG_6147.JPG'><BR>IMG_6147.JPG<br>50.9 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6147.JPG' ALT='IMG_6147.JPG'>IMG_6147.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_6149.JPG' href='fullcircle.php?fileId=IMG_6149.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6149.JPG' ALT='IMG_6149.JPG'><BR>IMG_6149.JPG<br>46.86 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6149.JPG' ALT='IMG_6149.JPG'>IMG_6149.JPG</a></div></td>
<td><A ID='IMG_6152.JPG' href='fullcircle.php?fileId=IMG_6152.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6152.JPG' ALT='IMG_6152.JPG'><BR>IMG_6152.JPG<br>65.98 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6152.JPG' ALT='IMG_6152.JPG'>IMG_6152.JPG</a></div></td>
<td><A ID='IMG_6153.JPG' href='fullcircle.php?fileId=IMG_6153.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6153.JPG' ALT='IMG_6153.JPG'><BR>IMG_6153.JPG<br>85.11 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6153.JPG' ALT='IMG_6153.JPG'>IMG_6153.JPG</a></div></td>
<td><A ID='IMG_6154.JPG' href='fullcircle.php?fileId=IMG_6154.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6154.JPG' ALT='IMG_6154.JPG'><BR>IMG_6154.JPG<br>40.75 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6154.JPG' ALT='IMG_6154.JPG'>IMG_6154.JPG</a></div></td>
<td><A ID='IMG_6156.JPG' href='fullcircle.php?fileId=IMG_6156.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6156.JPG' ALT='IMG_6156.JPG'><BR>IMG_6156.JPG<br>69.43 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6156.JPG' ALT='IMG_6156.JPG'>IMG_6156.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_6165.JPG' href='fullcircle.php?fileId=IMG_6165.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6165.JPG' ALT='IMG_6165.JPG'><BR>IMG_6165.JPG<br>81.51 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6165.JPG' ALT='IMG_6165.JPG'>IMG_6165.JPG</a></div></td>
<td><A ID='IMG_6166.JPG' href='fullcircle.php?fileId=IMG_6166.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6166.JPG' ALT='IMG_6166.JPG'><BR>IMG_6166.JPG<br>87.16 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6166.JPG' ALT='IMG_6166.JPG'>IMG_6166.JPG</a></div></td>
<td><A ID='IMG_6168.JPG' href='fullcircle.php?fileId=IMG_6168.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6168.JPG' ALT='IMG_6168.JPG'><BR>IMG_6168.JPG<br>90.92 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6168.JPG' ALT='IMG_6168.JPG'>IMG_6168.JPG</a></div></td>
<td><A ID='IMG_6170.JPG' href='fullcircle.php?fileId=IMG_6170.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6170.JPG' ALT='IMG_6170.JPG'><BR>IMG_6170.JPG<br>86.86 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6170.JPG' ALT='IMG_6170.JPG'>IMG_6170.JPG</a></div></td>
<td><A ID='IMG_6172.JPG' href='fullcircle.php?fileId=IMG_6172.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6172.JPG' ALT='IMG_6172.JPG'><BR>IMG_6172.JPG<br>114.95 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6172.JPG' ALT='IMG_6172.JPG'>IMG_6172.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_6178.JPG' href='fullcircle.php?fileId=IMG_6178.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6178.JPG' ALT='IMG_6178.JPG'><BR>IMG_6178.JPG<br>85.07 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6178.JPG' ALT='IMG_6178.JPG'>IMG_6178.JPG</a></div></td>
<td><A ID='IMG_6185.JPG' href='fullcircle.php?fileId=IMG_6185.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6185.JPG' ALT='IMG_6185.JPG'><BR>IMG_6185.JPG<br>51.4 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6185.JPG' ALT='IMG_6185.JPG'>IMG_6185.JPG</a></div></td>
<td><A ID='IMG_6187.JPG' href='fullcircle.php?fileId=IMG_6187.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6187.JPG' ALT='IMG_6187.JPG'><BR>IMG_6187.JPG<br>54.09 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6187.JPG' ALT='IMG_6187.JPG'>IMG_6187.JPG</a></div></td>
<td><A ID='IMG_6191.JPG' href='fullcircle.php?fileId=IMG_6191.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6191.JPG' ALT='IMG_6191.JPG'><BR>IMG_6191.JPG<br>42.73 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6191.JPG' ALT='IMG_6191.JPG'>IMG_6191.JPG</a></div></td>
<td><A ID='IMG_6194.JPG' href='fullcircle.php?fileId=IMG_6194.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6194.JPG' ALT='IMG_6194.JPG'><BR>IMG_6194.JPG<br>47.09 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6194.JPG' ALT='IMG_6194.JPG'>IMG_6194.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_6197.JPG' href='fullcircle.php?fileId=IMG_6197.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6197.JPG' ALT='IMG_6197.JPG'><BR>IMG_6197.JPG<br>49.18 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6197.JPG' ALT='IMG_6197.JPG'>IMG_6197.JPG</a></div></td>
<td><A ID='IMG_6244.JPG' href='fullcircle.php?fileId=IMG_6244.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6244.JPG' ALT='IMG_6244.JPG'><BR>IMG_6244.JPG<br>48.38 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6244.JPG' ALT='IMG_6244.JPG'>IMG_6244.JPG</a></div></td>
<td><A ID='IMG_6277.JPG' href='fullcircle.php?fileId=IMG_6277.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6277.JPG' ALT='IMG_6277.JPG'><BR>IMG_6277.JPG<br>44.01 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6277.JPG' ALT='IMG_6277.JPG'>IMG_6277.JPG</a></div></td>
<td><A ID='IMG_6302.JPG' href='fullcircle.php?fileId=IMG_6302.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6302.JPG' ALT='IMG_6302.JPG'><BR>IMG_6302.JPG<br>61.29 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6302.JPG' ALT='IMG_6302.JPG'>IMG_6302.JPG</a></div></td>
<td><A ID='IMG_6303.JPG' href='fullcircle.php?fileId=IMG_6303.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6303.JPG' ALT='IMG_6303.JPG'><BR>IMG_6303.JPG<br>56.61 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6303.JPG' ALT='IMG_6303.JPG'>IMG_6303.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_6306.JPG' href='fullcircle.php?fileId=IMG_6306.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6306.JPG' ALT='IMG_6306.JPG'><BR>IMG_6306.JPG<br>53 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6306.JPG' ALT='IMG_6306.JPG'>IMG_6306.JPG</a></div></td>
<td><A ID='IMG_6310.JPG' href='fullcircle.php?fileId=IMG_6310.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6310.JPG' ALT='IMG_6310.JPG'><BR>IMG_6310.JPG<br>44.11 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6310.JPG' ALT='IMG_6310.JPG'>IMG_6310.JPG</a></div></td>
<td><A ID='IMG_6313.JPG' href='fullcircle.php?fileId=IMG_6313.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6313.JPG' ALT='IMG_6313.JPG'><BR>IMG_6313.JPG<br>42.99 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6313.JPG' ALT='IMG_6313.JPG'>IMG_6313.JPG</a></div></td>
<td><A ID='IMG_6314.JPG' href='fullcircle.php?fileId=IMG_6314.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6314.JPG' ALT='IMG_6314.JPG'><BR>IMG_6314.JPG<br>63.58 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6314.JPG' ALT='IMG_6314.JPG'>IMG_6314.JPG</a></div></td>
<td><A ID='IMG_6315.JPG' href='fullcircle.php?fileId=IMG_6315.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6315.JPG' ALT='IMG_6315.JPG'><BR>IMG_6315.JPG<br>82.06 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6315.JPG' ALT='IMG_6315.JPG'>IMG_6315.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_6316.JPG' href='fullcircle.php?fileId=IMG_6316.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6316.JPG' ALT='IMG_6316.JPG'><BR>IMG_6316.JPG<br>41.76 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6316.JPG' ALT='IMG_6316.JPG'>IMG_6316.JPG</a></div></td>
<td><A ID='IMG_6318.JPG' href='fullcircle.php?fileId=IMG_6318.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6318.JPG' ALT='IMG_6318.JPG'><BR>IMG_6318.JPG<br>68.72 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6318.JPG' ALT='IMG_6318.JPG'>IMG_6318.JPG</a></div></td>
<td><A ID='IMG_6319.JPG' href='fullcircle.php?fileId=IMG_6319.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6319.JPG' ALT='IMG_6319.JPG'><BR>IMG_6319.JPG<br>53.16 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6319.JPG' ALT='IMG_6319.JPG'>IMG_6319.JPG</a></div></td>
<td><A ID='IMG_6321.JPG' href='fullcircle.php?fileId=IMG_6321.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6321.JPG' ALT='IMG_6321.JPG'><BR>IMG_6321.JPG<br>32.73 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6321.JPG' ALT='IMG_6321.JPG'>IMG_6321.JPG</a></div></td>
<td><A ID='IMG_6323.JPG' href='fullcircle.php?fileId=IMG_6323.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6323.JPG' ALT='IMG_6323.JPG'><BR>IMG_6323.JPG<br>36.8 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6323.JPG' ALT='IMG_6323.JPG'>IMG_6323.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_6331.JPG' href='fullcircle.php?fileId=IMG_6331.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6331.JPG' ALT='IMG_6331.JPG'><BR>IMG_6331.JPG<br>56.27 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6331.JPG' ALT='IMG_6331.JPG'>IMG_6331.JPG</a></div></td>
<td><A ID='IMG_6333.JPG' href='fullcircle.php?fileId=IMG_6333.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6333.JPG' ALT='IMG_6333.JPG'><BR>IMG_6333.JPG<br>79.44 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6333.JPG' ALT='IMG_6333.JPG'>IMG_6333.JPG</a></div></td>
<td><A ID='IMG_6334.JPG' href='fullcircle.php?fileId=IMG_6334.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6334.JPG' ALT='IMG_6334.JPG'><BR>IMG_6334.JPG<br>88.67 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6334.JPG' ALT='IMG_6334.JPG'>IMG_6334.JPG</a></div></td>
<td><A ID='IMG_6343.JPG' href='fullcircle.php?fileId=IMG_6343.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6343.JPG' ALT='IMG_6343.JPG'><BR>IMG_6343.JPG<br>56.13 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6343.JPG' ALT='IMG_6343.JPG'>IMG_6343.JPG</a></div></td>
<td><A ID='IMG_6344.JPG' href='fullcircle.php?fileId=IMG_6344.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6344.JPG' ALT='IMG_6344.JPG'><BR>IMG_6344.JPG<br>58.91 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6344.JPG' ALT='IMG_6344.JPG'>IMG_6344.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_6346.JPG' href='fullcircle.php?fileId=IMG_6346.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6346.JPG' ALT='IMG_6346.JPG'><BR>IMG_6346.JPG<br>60.59 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6346.JPG' ALT='IMG_6346.JPG'>IMG_6346.JPG</a></div></td>
<td><A ID='IMG_6347.JPG' href='fullcircle.php?fileId=IMG_6347.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6347.JPG' ALT='IMG_6347.JPG'><BR>IMG_6347.JPG<br>68.4 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6347.JPG' ALT='IMG_6347.JPG'>IMG_6347.JPG</a></div></td>
<td><A ID='IMG_6349.JPG' href='fullcircle.php?fileId=IMG_6349.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6349.JPG' ALT='IMG_6349.JPG'><BR>IMG_6349.JPG<br>75.43 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6349.JPG' ALT='IMG_6349.JPG'>IMG_6349.JPG</a></div></td>
<td><A ID='IMG_6350.JPG' href='fullcircle.php?fileId=IMG_6350.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6350.JPG' ALT='IMG_6350.JPG'><BR>IMG_6350.JPG<br>71.85 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6350.JPG' ALT='IMG_6350.JPG'>IMG_6350.JPG</a></div></td>
<td><A ID='IMG_6352.JPG' href='fullcircle.php?fileId=IMG_6352.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6352.JPG' ALT='IMG_6352.JPG'><BR>IMG_6352.JPG<br>46.26 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6352.JPG' ALT='IMG_6352.JPG'>IMG_6352.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_6355.JPG' href='fullcircle.php?fileId=IMG_6355.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6355.JPG' ALT='IMG_6355.JPG'><BR>IMG_6355.JPG<br>93.66 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6355.JPG' ALT='IMG_6355.JPG'>IMG_6355.JPG</a></div></td>
<td><A ID='IMG_6358.JPG' href='fullcircle.php?fileId=IMG_6358.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6358.JPG' ALT='IMG_6358.JPG'><BR>IMG_6358.JPG<br>85.98 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6358.JPG' ALT='IMG_6358.JPG'>IMG_6358.JPG</a></div></td>
<td><A ID='IMG_6360.JPG' href='fullcircle.php?fileId=IMG_6360.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6360.JPG' ALT='IMG_6360.JPG'><BR>IMG_6360.JPG<br>112.89 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6360.JPG' ALT='IMG_6360.JPG'>IMG_6360.JPG</a></div></td>
<td><A ID='IMG_6361.JPG' href='fullcircle.php?fileId=IMG_6361.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6361.JPG' ALT='IMG_6361.JPG'><BR>IMG_6361.JPG<br>115.8 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6361.JPG' ALT='IMG_6361.JPG'>IMG_6361.JPG</a></div></td>
<td><A ID='IMG_6367.JPG' href='fullcircle.php?fileId=IMG_6367.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6367.JPG' ALT='IMG_6367.JPG'><BR>IMG_6367.JPG<br>115.45 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6367.JPG' ALT='IMG_6367.JPG'>IMG_6367.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_6403.JPG' href='fullcircle.php?fileId=IMG_6403.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6403.JPG' ALT='IMG_6403.JPG'><BR>IMG_6403.JPG<br>64.11 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6403.JPG' ALT='IMG_6403.JPG'>IMG_6403.JPG</a></div></td>
<td><A ID='IMG_6408.JPG' href='fullcircle.php?fileId=IMG_6408.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6408.JPG' ALT='IMG_6408.JPG'><BR>IMG_6408.JPG<br>86.91 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6408.JPG' ALT='IMG_6408.JPG'>IMG_6408.JPG</a></div></td>
<td><A ID='IMG_6411.JPG' href='fullcircle.php?fileId=IMG_6411.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6411.JPG' ALT='IMG_6411.JPG'><BR>IMG_6411.JPG<br>100.92 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6411.JPG' ALT='IMG_6411.JPG'>IMG_6411.JPG</a></div></td>
<td><A ID='IMG_6413.JPG' href='fullcircle.php?fileId=IMG_6413.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6413.JPG' ALT='IMG_6413.JPG'><BR>IMG_6413.JPG<br>70.96 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6413.JPG' ALT='IMG_6413.JPG'>IMG_6413.JPG</a></div></td>
<td><A ID='IMG_6414.JPG' href='fullcircle.php?fileId=IMG_6414.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6414.JPG' ALT='IMG_6414.JPG'><BR>IMG_6414.JPG<br>56.54 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6414.JPG' ALT='IMG_6414.JPG'>IMG_6414.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_6415.JPG' href='fullcircle.php?fileId=IMG_6415.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6415.JPG' ALT='IMG_6415.JPG'><BR>IMG_6415.JPG<br>52.05 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6415.JPG' ALT='IMG_6415.JPG'>IMG_6415.JPG</a></div></td>
<td><A ID='IMG_6416.JPG' href='fullcircle.php?fileId=IMG_6416.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6416.JPG' ALT='IMG_6416.JPG'><BR>IMG_6416.JPG<br>55.73 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6416.JPG' ALT='IMG_6416.JPG'>IMG_6416.JPG</a></div></td>
<td><A ID='IMG_6419.JPG' href='fullcircle.php?fileId=IMG_6419.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6419.JPG' ALT='IMG_6419.JPG'><BR>IMG_6419.JPG<br>38.7 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6419.JPG' ALT='IMG_6419.JPG'>IMG_6419.JPG</a></div></td>
<td><A ID='IMG_6423.JPG' href='fullcircle.php?fileId=IMG_6423.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6423.JPG' ALT='IMG_6423.JPG'><BR>IMG_6423.JPG<br>44.52 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6423.JPG' ALT='IMG_6423.JPG'>IMG_6423.JPG</a></div></td>
<td><A ID='IMG_6424.JPG' href='fullcircle.php?fileId=IMG_6424.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6424.JPG' ALT='IMG_6424.JPG'><BR>IMG_6424.JPG<br>42.71 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6424.JPG' ALT='IMG_6424.JPG'>IMG_6424.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_6429.JPG' href='fullcircle.php?fileId=IMG_6429.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6429.JPG' ALT='IMG_6429.JPG'><BR>IMG_6429.JPG<br>46.87 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6429.JPG' ALT='IMG_6429.JPG'>IMG_6429.JPG</a></div></td>
<td><A ID='IMG_6432.JPG' href='fullcircle.php?fileId=IMG_6432.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6432.JPG' ALT='IMG_6432.JPG'><BR>IMG_6432.JPG<br>44.01 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6432.JPG' ALT='IMG_6432.JPG'>IMG_6432.JPG</a></div></td>
<td><A ID='IMG_6444.JPG' href='fullcircle.php?fileId=IMG_6444.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6444.JPG' ALT='IMG_6444.JPG'><BR>IMG_6444.JPG<br>55.32 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6444.JPG' ALT='IMG_6444.JPG'>IMG_6444.JPG</a></div></td>
<td><A ID='IMG_6446.JPG' href='fullcircle.php?fileId=IMG_6446.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6446.JPG' ALT='IMG_6446.JPG'><BR>IMG_6446.JPG<br>42.08 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6446.JPG' ALT='IMG_6446.JPG'>IMG_6446.JPG</a></div></td>
<td><A ID='IMG_6451.JPG' href='fullcircle.php?fileId=IMG_6451.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6451.JPG' ALT='IMG_6451.JPG'><BR>IMG_6451.JPG<br>52.45 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6451.JPG' ALT='IMG_6451.JPG'>IMG_6451.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_6452.JPG' href='fullcircle.php?fileId=IMG_6452.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6452.JPG' ALT='IMG_6452.JPG'><BR>IMG_6452.JPG<br>41.41 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6452.JPG' ALT='IMG_6452.JPG'>IMG_6452.JPG</a></div></td>
<td><A ID='IMG_6464.JPG' href='fullcircle.php?fileId=IMG_6464.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6464.JPG' ALT='IMG_6464.JPG'><BR>IMG_6464.JPG<br>46.42 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6464.JPG' ALT='IMG_6464.JPG'>IMG_6464.JPG</a></div></td>
<td><A ID='IMG_6468.JPG' href='fullcircle.php?fileId=IMG_6468.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6468.JPG' ALT='IMG_6468.JPG'><BR>IMG_6468.JPG<br>40.97 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6468.JPG' ALT='IMG_6468.JPG'>IMG_6468.JPG</a></div></td>
<td><A ID='IMG_6500.JPG' href='fullcircle.php?fileId=IMG_6500.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6500.JPG' ALT='IMG_6500.JPG'><BR>IMG_6500.JPG<br>66.09 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6500.JPG' ALT='IMG_6500.JPG'>IMG_6500.JPG</a></div></td>
<td><A ID='IMG_6534.JPG' href='fullcircle.php?fileId=IMG_6534.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6534.JPG' ALT='IMG_6534.JPG'><BR>IMG_6534.JPG<br>43.33 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6534.JPG' ALT='IMG_6534.JPG'>IMG_6534.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_6536.JPG' href='fullcircle.php?fileId=IMG_6536.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6536.JPG' ALT='IMG_6536.JPG'><BR>IMG_6536.JPG<br>54.47 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6536.JPG' ALT='IMG_6536.JPG'>IMG_6536.JPG</a></div></td>
<td><A ID='IMG_6546.JPG' href='fullcircle.php?fileId=IMG_6546.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6546.JPG' ALT='IMG_6546.JPG'><BR>IMG_6546.JPG<br>54.38 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6546.JPG' ALT='IMG_6546.JPG'>IMG_6546.JPG</a></div></td>
<td><A ID='IMG_6556.JPG' href='fullcircle.php?fileId=IMG_6556.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6556.JPG' ALT='IMG_6556.JPG'><BR>IMG_6556.JPG<br>51.72 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6556.JPG' ALT='IMG_6556.JPG'>IMG_6556.JPG</a></div></td>
<td><A ID='IMG_6570.JPG' href='fullcircle.php?fileId=IMG_6570.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6570.JPG' ALT='IMG_6570.JPG'><BR>IMG_6570.JPG<br>48.19 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6570.JPG' ALT='IMG_6570.JPG'>IMG_6570.JPG</a></div></td>
<td><A ID='IMG_6575.JPG' href='fullcircle.php?fileId=IMG_6575.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6575.JPG' ALT='IMG_6575.JPG'><BR>IMG_6575.JPG<br>47.5 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6575.JPG' ALT='IMG_6575.JPG'>IMG_6575.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_6581.JPG' href='fullcircle.php?fileId=IMG_6581.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6581.JPG' ALT='IMG_6581.JPG'><BR>IMG_6581.JPG<br>42.8 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6581.JPG' ALT='IMG_6581.JPG'>IMG_6581.JPG</a></div></td>
<td><A ID='IMG_6588.JPG' href='fullcircle.php?fileId=IMG_6588.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6588.JPG' ALT='IMG_6588.JPG'><BR>IMG_6588.JPG<br>50.07 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6588.JPG' ALT='IMG_6588.JPG'>IMG_6588.JPG</a></div></td>
<td><A ID='IMG_6605.JPG' href='fullcircle.php?fileId=IMG_6605.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6605.JPG' ALT='IMG_6605.JPG'><BR>IMG_6605.JPG<br>33.08 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6605.JPG' ALT='IMG_6605.JPG'>IMG_6605.JPG</a></div></td>
<td><A ID='IMG_6624.JPG' href='fullcircle.php?fileId=IMG_6624.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6624.JPG' ALT='IMG_6624.JPG'><BR>IMG_6624.JPG<br>46.04 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6624.JPG' ALT='IMG_6624.JPG'>IMG_6624.JPG</a></div></td>
<td><A ID='IMG_6636.JPG' href='fullcircle.php?fileId=IMG_6636.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6636.JPG' ALT='IMG_6636.JPG'><BR>IMG_6636.JPG<br>38.68 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6636.JPG' ALT='IMG_6636.JPG'>IMG_6636.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_6645.JPG' href='fullcircle.php?fileId=IMG_6645.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6645.JPG' ALT='IMG_6645.JPG'><BR>IMG_6645.JPG<br>48.75 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6645.JPG' ALT='IMG_6645.JPG'>IMG_6645.JPG</a></div></td>
<td><A ID='IMG_6647.JPG' href='fullcircle.php?fileId=IMG_6647.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6647.JPG' ALT='IMG_6647.JPG'><BR>IMG_6647.JPG<br>41.49 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6647.JPG' ALT='IMG_6647.JPG'>IMG_6647.JPG</a></div></td>
<td><A ID='IMG_6651.JPG' href='fullcircle.php?fileId=IMG_6651.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6651.JPG' ALT='IMG_6651.JPG'><BR>IMG_6651.JPG<br>35.5 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6651.JPG' ALT='IMG_6651.JPG'>IMG_6651.JPG</a></div></td>
<td><A ID='IMG_6654.JPG' href='fullcircle.php?fileId=IMG_6654.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6654.JPG' ALT='IMG_6654.JPG'><BR>IMG_6654.JPG<br>60.26 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6654.JPG' ALT='IMG_6654.JPG'>IMG_6654.JPG</a></div></td>
<td><A ID='IMG_6661.JPG' href='fullcircle.php?fileId=IMG_6661.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6661.JPG' ALT='IMG_6661.JPG'><BR>IMG_6661.JPG<br>58.41 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6661.JPG' ALT='IMG_6661.JPG'>IMG_6661.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_6666.JPG' href='fullcircle.php?fileId=IMG_6666.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6666.JPG' ALT='IMG_6666.JPG'><BR>IMG_6666.JPG<br>89.83 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6666.JPG' ALT='IMG_6666.JPG'>IMG_6666.JPG</a></div></td>
<td><A ID='IMG_6671.JPG' href='fullcircle.php?fileId=IMG_6671.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6671.JPG' ALT='IMG_6671.JPG'><BR>IMG_6671.JPG<br>56.38 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6671.JPG' ALT='IMG_6671.JPG'>IMG_6671.JPG</a></div></td>
<td><A ID='IMG_6675.JPG' href='fullcircle.php?fileId=IMG_6675.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6675.JPG' ALT='IMG_6675.JPG'><BR>IMG_6675.JPG<br>38.32 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6675.JPG' ALT='IMG_6675.JPG'>IMG_6675.JPG</a></div></td>
<td><A ID='IMG_6676.JPG' href='fullcircle.php?fileId=IMG_6676.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6676.JPG' ALT='IMG_6676.JPG'><BR>IMG_6676.JPG<br>81.06 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6676.JPG' ALT='IMG_6676.JPG'>IMG_6676.JPG</a></div></td>
<td><A ID='IMG_6684.JPG' href='fullcircle.php?fileId=IMG_6684.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6684.JPG' ALT='IMG_6684.JPG'><BR>IMG_6684.JPG<br>67.22 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6684.JPG' ALT='IMG_6684.JPG'>IMG_6684.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_6685.JPG' href='fullcircle.php?fileId=IMG_6685.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6685.JPG' ALT='IMG_6685.JPG'><BR>IMG_6685.JPG<br>58.76 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6685.JPG' ALT='IMG_6685.JPG'>IMG_6685.JPG</a></div></td>
<td><A ID='IMG_6687.JPG' href='fullcircle.php?fileId=IMG_6687.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6687.JPG' ALT='IMG_6687.JPG'><BR>IMG_6687.JPG<br>97.95 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6687.JPG' ALT='IMG_6687.JPG'>IMG_6687.JPG</a></div></td>
<td><A ID='IMG_6696.JPG' href='fullcircle.php?fileId=IMG_6696.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6696.JPG' ALT='IMG_6696.JPG'><BR>IMG_6696.JPG<br>82.22 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6696.JPG' ALT='IMG_6696.JPG'>IMG_6696.JPG</a></div></td>
<td><A ID='IMG_6697.JPG' href='fullcircle.php?fileId=IMG_6697.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6697.JPG' ALT='IMG_6697.JPG'><BR>IMG_6697.JPG<br>57.91 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6697.JPG' ALT='IMG_6697.JPG'>IMG_6697.JPG</a></div></td>
<td><A ID='IMG_6702.JPG' href='fullcircle.php?fileId=IMG_6702.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6702.JPG' ALT='IMG_6702.JPG'><BR>IMG_6702.JPG<br>70.63 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6702.JPG' ALT='IMG_6702.JPG'>IMG_6702.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_6703.JPG' href='fullcircle.php?fileId=IMG_6703.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6703.JPG' ALT='IMG_6703.JPG'><BR>IMG_6703.JPG<br>87.45 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6703.JPG' ALT='IMG_6703.JPG'>IMG_6703.JPG</a></div></td>
<td><A ID='IMG_6711.JPG' href='fullcircle.php?fileId=IMG_6711.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6711.JPG' ALT='IMG_6711.JPG'><BR>IMG_6711.JPG<br>96.06 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6711.JPG' ALT='IMG_6711.JPG'>IMG_6711.JPG</a></div></td>
<td><A ID='IMG_6713.JPG' href='fullcircle.php?fileId=IMG_6713.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6713.JPG' ALT='IMG_6713.JPG'><BR>IMG_6713.JPG<br>45.12 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6713.JPG' ALT='IMG_6713.JPG'>IMG_6713.JPG</a></div></td>
<td><A ID='IMG_6715.JPG' href='fullcircle.php?fileId=IMG_6715.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6715.JPG' ALT='IMG_6715.JPG'><BR>IMG_6715.JPG<br>70.31 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6715.JPG' ALT='IMG_6715.JPG'>IMG_6715.JPG</a></div></td>
<td><A ID='IMG_6716.JPG' href='fullcircle.php?fileId=IMG_6716.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6716.JPG' ALT='IMG_6716.JPG'><BR>IMG_6716.JPG<br>45.64 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6716.JPG' ALT='IMG_6716.JPG'>IMG_6716.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_6719.JPG' href='fullcircle.php?fileId=IMG_6719.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6719.JPG' ALT='IMG_6719.JPG'><BR>IMG_6719.JPG<br>65.53 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6719.JPG' ALT='IMG_6719.JPG'>IMG_6719.JPG</a></div></td>
<td><A ID='IMG_6725.JPG' href='fullcircle.php?fileId=IMG_6725.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6725.JPG' ALT='IMG_6725.JPG'><BR>IMG_6725.JPG<br>64.75 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6725.JPG' ALT='IMG_6725.JPG'>IMG_6725.JPG</a></div></td>
<td><A ID='IMG_6734.JPG' href='fullcircle.php?fileId=IMG_6734.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6734.JPG' ALT='IMG_6734.JPG'><BR>IMG_6734.JPG<br>60.38 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6734.JPG' ALT='IMG_6734.JPG'>IMG_6734.JPG</a></div></td>
<td><A ID='IMG_6752.JPG' href='fullcircle.php?fileId=IMG_6752.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6752.JPG' ALT='IMG_6752.JPG'><BR>IMG_6752.JPG<br>78.95 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6752.JPG' ALT='IMG_6752.JPG'>IMG_6752.JPG</a></div></td>
<td><A ID='IMG_6756.JPG' href='fullcircle.php?fileId=IMG_6756.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6756.JPG' ALT='IMG_6756.JPG'><BR>IMG_6756.JPG<br>64.71 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6756.JPG' ALT='IMG_6756.JPG'>IMG_6756.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_6770.JPG' href='fullcircle.php?fileId=IMG_6770.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6770.JPG' ALT='IMG_6770.JPG'><BR>IMG_6770.JPG<br>35.97 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6770.JPG' ALT='IMG_6770.JPG'>IMG_6770.JPG</a></div></td>
<td><A ID='IMG_6772.JPG' href='fullcircle.php?fileId=IMG_6772.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6772.JPG' ALT='IMG_6772.JPG'><BR>IMG_6772.JPG<br>38.62 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6772.JPG' ALT='IMG_6772.JPG'>IMG_6772.JPG</a></div></td>
<td><A ID='IMG_6792.JPG' href='fullcircle.php?fileId=IMG_6792.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6792.JPG' ALT='IMG_6792.JPG'><BR>IMG_6792.JPG<br>57.11 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6792.JPG' ALT='IMG_6792.JPG'>IMG_6792.JPG</a></div></td>
<td><A ID='IMG_6796.JPG' href='fullcircle.php?fileId=IMG_6796.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6796.JPG' ALT='IMG_6796.JPG'><BR>IMG_6796.JPG<br>66.26 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6796.JPG' ALT='IMG_6796.JPG'>IMG_6796.JPG</a></div></td>
<td><A ID='IMG_6817.JPG' href='fullcircle.php?fileId=IMG_6817.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6817.JPG' ALT='IMG_6817.JPG'><BR>IMG_6817.JPG<br>66.17 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6817.JPG' ALT='IMG_6817.JPG'>IMG_6817.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_6819.JPG' href='fullcircle.php?fileId=IMG_6819.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6819.JPG' ALT='IMG_6819.JPG'><BR>IMG_6819.JPG<br>48.48 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6819.JPG' ALT='IMG_6819.JPG'>IMG_6819.JPG</a></div></td>
<td><A ID='IMG_6822.JPG' href='fullcircle.php?fileId=IMG_6822.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6822.JPG' ALT='IMG_6822.JPG'><BR>IMG_6822.JPG<br>44.41 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6822.JPG' ALT='IMG_6822.JPG'>IMG_6822.JPG</a></div></td>
<td><A ID='IMG_6827.JPG' href='fullcircle.php?fileId=IMG_6827.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6827.JPG' ALT='IMG_6827.JPG'><BR>IMG_6827.JPG<br>41.31 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6827.JPG' ALT='IMG_6827.JPG'>IMG_6827.JPG</a></div></td>
<td><A ID='IMG_6832.JPG' href='fullcircle.php?fileId=IMG_6832.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6832.JPG' ALT='IMG_6832.JPG'><BR>IMG_6832.JPG<br>36.43 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6832.JPG' ALT='IMG_6832.JPG'>IMG_6832.JPG</a></div></td>
<td><A ID='IMG_6849.JPG' href='fullcircle.php?fileId=IMG_6849.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6849.JPG' ALT='IMG_6849.JPG'><BR>IMG_6849.JPG<br>117.21 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6849.JPG' ALT='IMG_6849.JPG'>IMG_6849.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_6850.JPG' href='fullcircle.php?fileId=IMG_6850.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6850.JPG' ALT='IMG_6850.JPG'><BR>IMG_6850.JPG<br>43.41 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6850.JPG' ALT='IMG_6850.JPG'>IMG_6850.JPG</a></div></td>
<td><A ID='IMG_6851.JPG' href='fullcircle.php?fileId=IMG_6851.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6851.JPG' ALT='IMG_6851.JPG'><BR>IMG_6851.JPG<br>90.09 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6851.JPG' ALT='IMG_6851.JPG'>IMG_6851.JPG</a></div></td>
<td><A ID='IMG_6873.JPG' href='fullcircle.php?fileId=IMG_6873.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060126/IMG_6873.JPG' ALT='IMG_6873.JPG'><BR>IMG_6873.JPG<br>93.4 KB</a><div class='inv'><br><a href='./images/20060126/IMG_6873.JPG' ALT='IMG_6873.JPG'>IMG_6873.JPG</a></div></td>
</tr>
</table>	</div>
</div>
</body>
</html>