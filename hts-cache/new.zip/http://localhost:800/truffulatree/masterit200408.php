<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - August 2004 - Q&A letters</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="Q&A letters">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="Q&A letters" href='masterit200401.php'>January 2004</a></li>
<li><a title="Q&A letters" href='masterit200402.php'>February 2004</a></li>
<li><a title="Q&A letters" href='masterit200403.php'>March 2004</a></li>
<li><a title="Q&A letters" href='masterit200404.php'>April 2004</a></li>
<li><a title="Q&A letters" href='masterit200405.php'>May 2004</a></li>
<li><a title="Q&A letters" href='masterit200406.php'>June 2004</a></li>
<li><a title="Q&A letters" href='masterit200407.php'>July 2004</a></li>
<li><div class='activemenu'>August 2004</div></li>
<li><a title="Q&A letters" href='masterit200409.php'>September 2004</a></li>
<li><a title="Q&A letters" href='masterit200410.php'>October 2004</a></li>
<li><a title="Q&A letters" href='masterit200411.php'>November 2004</a></li>
<li><a title="Q&A letters" href='masterit200412.php'>December 2004</a></li>
<li> </li><br><li>Or go back to:</li><li><a title='Q&A/MasterIT letters from 2004' href="masterit2004.php">2004 archive</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>August 2004</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Mark's writing' href="written.php">Professional Writing</a> > <a title='My weekly Q&A column in The Australian' href="masterIT.php">MasterIT</a> > <a title='Q&A/MasterIT letters from 2004' href="masterit2004.php">2004 archive</a> > <a title='Q&A letters' href="masterit200408.php">August 2004</a>
<br><br>		<br>
<h2>3/8/04</h2><br>
<b>I have a new PC; a beautiful IBM Thinkcentre. I like very much how the computer looks (as a computer; not as a food processor), and love its speed; however, I am not happy with how it's been set up. I would like to reformat the hard drive install only the software that I intend to use. I wonder whether or not the process is going to be easy. Is there a guide on how to reinstall XP? Which not-so-obvious drivers will I have to install and where can I find them? I would like to get rid of all the redundant directories that refer to multiple users, since I am the only one and I find it wasteful and confusing to have "Administrator", "All Users", "Owner", and "<my name>" folders. If this is not an installer option, which branches of the file system might I prune (without ruining anything)?</b><br>
<br>
Searching Google for "XP installation guide" returns hundreds of results (of course) - but have a wade through various ones until you get a feel for what will be involved. Some are obviously going to be more technical than others; don't worry too much about super advanced setups, dual booting with Linux and so on, you just want something simple and basic.<br>
<br>
Bear in mind that it's also likely your Thinkcentre, being a brand name PC, comes with a customised Windows install. It'll may have a slightly different installation procedure to the generic ones you'll find on the 'net. You should also have a CD that contains any brand-specific drivers you might need; if you ever lose that the IBM website should also have them somewhere.<br>
<br>
As far as extra users go, there's not much you can do. You'll always have files for Administrator, All Users and a few others (which may be hidden).<br>
<br>
Windows comes with a lot of superfluous window dressing (no pun intended), and it puts folders and files all over the shop. When I first moved to PCs (from an Amiga) I found this intensely irritating, but I've just learned to live with it. Let Windows put it's guts where it wants to, and create your own ordered fantasy world of folders elsewhere.<br>
<br>
Finally, if you can arrange it, having a geek on hand when you reinstall is sure to be a good thing.<br>
<br>
<br>
<h2>10/8/04</h2><br>
<b>I have a slightly different technical question for you - what on earth is the Scroll Lock key for? I mean, apart from turning on and off the little light.</b><br>
<br>
The short answer: Not much.<br>
<br>
The slightly longer answer: The scroll lock key is a bit of a vestigial "wisdom tooth" on the keyboard (although in all fairness it doesn't tend to cause nearly as much pain and fun as the real things do). It's even more useless than the Caps Lock key (which is really only useful for yelling at people on Usenet, and irritating us by aCCIDENTALLY gETTING sWITCHED oN).<br>
<br>
Way back when computer screens were small and green, the scroll lock key would have been used to scroll the screen's contents without moving the cursor. You can actually still use it in this way in Excel� which is just about the only thing you'll ever do with it. These days, it's basically just along for the ride.<br>
<br>
<br>
<b>I have a Lexmark X1185 printer. It installed fine and does all I need for printing/copying/scanning. However it modified my Windows XP Pro system in an annoying way. Prior to install, Win XP shut down fast in 6 seconds. It now takes 30! I uninstalled. Back to 6 seconds. I downloaded the latest driver, did all the right things - disabling anti-virus, using Msconfig to stop it starting etc plus all suggestions from Lexmark. No good - still 30 seconds. Any ideas?</b><br>
<br>
Well, the Master has searched, but unfortunately I can't come up with a specific solution.<br>
<br>
What's probably happening is that there is a service associated with the print driver that isn't shutting down properly.<br>
<br>
Windows services are just background programs that get started with Windows, or when particular things happen, and when you shut down Windows, it signals them to quit, and then waits a certain amount of time for that to happen. Sounds like the Lexmark driver isn't dying particularly quickly.<br>
<br>
Unfortunately there's not much one can to do get around it, except hope for a new driver release that fixes the problem, as the service is probably part of the print driver...<br>
<br>
If any readers (or even Lexmark) have suggestions, please feel free to shoot them over. An elephant stamp awaits you.<br>
<br>
<br>
<h2>17/8/04</h2><br>
<b>I've just installed Doom 3 on my shiny new (as of a few months ago) laptop, and it's running pretty slowly, even with the quality settings set to "low". My mate reckons it's probably more the video card than the CPU that is causing the bottleneck, and it got me wondering - is it possible to upgrade the video card/chip in a laptop, like you can upgrade the hard drive?</b><br>
<br>
Ah yes, Doom 3, I know it well. This fantastically pretty and dark (both visually and content-wise) game is responsible for the apparent disappearance of many geeks (and not-so-geeks) from the face of the earth lately.<br>
<br>
It's already been responsible for me forgetting three separate things this week (including little things like paying my rent and eating). At least, that's my excuse, your honour.<br>
<br>
Unfortunately the answer to your question is "no"; it's not possible up upgrade any part of your laptop apart from the RAM and hard drive (which are fairly standard and modular components). Everything else in a laptop is generally completely custom, and has to be for space/weight/premature obsolescence reasons.<br>
<br>
All may not be lost though - you can try and lower the resolution of the game beyond the standard lowest option of 640x480, by manually editing the configuration file.<br>
<br>
Open up Doom3/base/DoomConfig.cfg in Notepad, then find the lines:<br>
<br>
seta r_customHeight "486"<br>
seta r_customWidth "720"<br>
<br>
and set the values to your custom resolution (eg horridly crunchy 320x200). Finally, change the value in the line "seta r_mode�" to be -1, in order to activate the custom resolution.<br>
<br>
There is also an extensive Doom 3 tweaking guide at www.tweakguides.com/Doom3_5.html.<br>
<br>
Happy slaying!<br>
<br>
<br>
<b>More on the Lexmark printer driver slow shutdown problem</b><br>
<br>
As promised, an Elephant Stamp goes to Andrew Woolman, who confirms the slow shutdown is due to a Lexmark driver service, and writes:<br>
<br>
"From my experience this is caused by one of the Lexmark services not shutting down correctly (as you mentioned). I've seen it cause all sorts of problems. My suggestion is to stop them one at a time and see how it affects shutdown times, then disable the offending one. They all start with Lex... i.e. LexMvService.exe. They don't seem to be required most of the time anyway."<br>
<br>
<br>
<h2>24/8/04</h2><br>
<b>How much space should Windows XP, with all the updates, take up on the hard drive? And if I may get two for one - in the Temp Folder I have about 3GB of stuff that seems to have accumulated there. Can this be safely dumped/deleted?</b><br>
<br>
The short answer to the first question: "A lot".<br>
<br>
Officially, Microsoft's own requirements for XP pro state "1.5 gigabytes (GB) of available hard disk space*" - the little asterisk being for a footnote that I can't find, but which I would imagine reads something like "your mileage may (and will) vary".<br>
<br>
My own install is somewhat elephantine now - 2.89 gigabytes just for the Windows folder. And it grows with time; depending on what drivers and programs you install. Thankfully hard disk space is super cheap these days, so it tends not to be a terrible problem.<br>
<br>
In response to your other query (yes you may get two for one), the stuff in your temp folder can indeed be dumped.<br>
<br>
For baffled readers, the temp folder is hidden away within Documents and Settings -> Local Settings, and contains temporary files (of course) used by various programs. The problem is that poorly coded applications sometimes leave files there without cleaning up (I'm looking at YOU Winamp and ICQ), leading to a ton of rubbish that just takes up disk space.<br>
<br>
It's fairly safe to remove everything in the temp folder - provided you quit all running applications first - but if you're worried about inadvertently deleting something valuable, you can use the Disk Cleanup Wizard to do it automatically for you.<br>
<br>
It's accessible from Program Files->Accessories->System Tools, and will clean out the temp folder as well as some other places where useless files accumulate. If you're using NTFS, it can even compress old files using Windows' built in compression.<br>
<br>
This last option is probably best not used though - Windows decides which files to compress based on their usage, and it's not always a good idea to do this, as whilst you will get back quite a lot of disk space, you can also adversely impact the overall performance of your PC.<br>
<br>
NTFS compression can be quite useful though, for specific types of files/folders, with specific usage patterns. A good article on the subject can be found at tutorials.freeskills.com/read/id/485<br>
<br>
<br>
<h2>31/8/04</h2><br>
<b>When I type in an email address and my computer is familiar with it, the computer gives its suggestions for quicker access, but on occasion I may have typed in the wrong address or someone has changed their address, I no longer want the computer to remember these addresses. How do I go about deleting these incorrect addresses? Please can you help me as this is driving me crazy.</b><br>
<br>
The psychiatric association haven't been paying their kickbacks lately, so I think I can help.<br>
<br>
The methods vary depending on which email program you are using, but it should be fairly easy to fix the problem.<br>
<br>
Mozilla, Thunderbird and Netscape 7 have a feature to automatically remember new addresses, plus addresses of people who's messages you've received, which you can  find in the Window->Address book menu. There you'll see your standard address book, plus Collected Addresses, which contains the automatic entries.<br>
<br>
Outlook and Outlook express also have an address book, which ties in with the Windows address book, and this is one place where the guilty addresses are may be stored. In OE, go to Tool->Address book and you should be able to maintain the addresses therein.<br>
<br>
Newer versions of Outlook also have a separate system for remembering just about every address you've typed. It works a lot like IE's auto-complete feature for website logins and passwords - a dropdown box appears with several options to choose from when you start typing.<br>
<br>
Getting rid of individual addresses is easy, just use the up/down arrow keys and press delete over the offending entry (this also works for IE's auto-complete, incidentally).<br>
<br>
If you want to clean out Outlook's memory en masse, you can do so by deleting the .nk2 file that stores the collected addresses. The location of this file varies, so the easiest way is to track it down with a file search.<br>
<br>
Go to the Start menu, select search (for files and folders), then enter *.nk2 in the search field. When you get the result(s) in the right hand pane you can just highlight and delete the files (or cut and paste them to another location, in order to keep them as a backup). Outlook will automatically create a new .nk2 file next time it's run.<br>
<br>
<i><p>Did the information on this page help you? Entertain you? Bore you? <a href="contact.php?subject=MasterIT">Drop me a line</a>.</p>

<p>If you're feeling particularly generous, you can even <a href="buypics.php">click here to send me some dot-com riches</a>. Think of it as online busking.</i></p>
	</div>
</div>
</body>
</html>