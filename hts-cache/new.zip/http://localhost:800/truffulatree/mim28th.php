<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - Naima's 28th - Pics of Naima's 28th birthday dinner</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="Pics of Naima's 28th birthday dinner">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="Pictures of my 28th Birthday party complete with Sparkler Bomb" href='28th.php'>28th Birthday</a></li>
<li><a title="Pictures of my 30th Birthday party" href='30th.php'>30th Birthday</a></li>
<li><a title="Michael Shamgar and Lindsay Halamek's 30th birthday bash photos" href='sl30th.php'>Shams & Linds' 30th</a></li>
<li><a title="Pictures of Andy Marinos's new flat, cat Toby, and Mum Pam Swain" href='andycatandflat.php'>Andy's Cat & Flat</a></li>
<li><a title="Pictures of a visit to Stephen Jackson's Farm" href='jackovisit.php'>Jacko's Farm</a></li>
<li><a title="Pictures taken at the Peace Convergence action in Rockhampton and Yeppoon in June 2005 to protest the joint US Australia military exercises (Operation Talisman Sabre)" href='peaceconvergence.php'>Peace Convergence</a></li>
<li><a title="Sydney trip - April '06" href='bridges.php'>Sydney, April 06</a></li>
<li><div class='activemenu'>Naima's 28th</div></li>
<li><a title="Brisbane CBD and the Story Bridge" href='brisbanepics1.php'>Brissie by Night 1</a></li>
<li><a title="Lamington National Park" href='lamington.php'>Lamington NP</a></li>
<li><a title="Various creatures and views from our Brisbane back yard" href='backyard.php'>Backyard Creatures</a></li>
<li><a title="Opening day of the Eleanor Schonell (Green) Bridge" href='greenbridge.php'>Green Bridge</a></li>
<li><a title="Pictutres from the 2006 Woodford Folk Festival" href='woodford0607.php'>Woodford 2006-2007</a></li>
<li><a title="One Cute Puppy" href='jezebel.php'>Jezebel</a></li>
<li><a title="Climbing at Kangaroo Point Cliffs" href='kangaroopt1.php'>Heather's Visit</a></li>
<li><a title="0x0021st (33rd) birthday celebrations" href='0x0021st.php'>0x0021st Birthday</a></li>
<li><a title="Nuptial photography" href='guyandalison.php'>Guy and Alison's Wedding</a></li>
<li><a title="Pictures from the 2007 Woodford Folk Festival" href='woodford0708.php'>Woodford 2007-2008</a></li>
<li><a title="Image gallery" href='sydneytrip0802.php'>Sydney & Yacaaba Head</a></li>
<li><a title="An impressive show by nature" href='lightning.php'>Thunderstorm Moonrise</a></li>
<li><a title="Frightening pictures of a shrinking beard" href='debearding.php'>De-bearding</a></li>
<li><a title="More Nuptial Photography" href='michaelandkaren.php'>Michael and Karen's Wedding</a></li>
<li><a title="A night of celebration" href='andrews21st.php'>Andrew's 21st</a></li>
<li><a title="Image Gallery" href='bloodyknee.php'>Bloody Knee</a></li>
<li><a title="Image Gallery" href='tyesbirthday.php'>Tye's Birthday</a></li>
<li><a title="Image Gallery" href='lasersocialising.php'>Laser Socialising</a></li>
<li><a title="Image Gallery" href='heatherandevan.php'>Heather and Evan's Wedding</a></li>
<li><a title="Image Gallery" href='woodford0809.php'>Woodford 2008-2009</a></li>
<li><a title="Image Gallery" href='allyandben.php'>Ally and Ben's Wedding</a></li>
<li><a title="Image Gallery" href='annes30th.php'>Anne's 30th</a></li>
<li><a title="Image Gallery" href='possumcreek.php'>Possum Creek</a></li>
<li><a title="Image Gallery" href='jamnight.php'>Jam Night</a></li>
<li><a title="Image Gallery" href='cunninghamsgap.php'>Cunningham's Gap</a></li>
<li><a title="Image Gallery" href='bigcat.php'>Diving on Big Cat</a></li>
<li><a title="Images from my birthday jam" href='birthdayjam.php'>Music, mayhem and merriment</a></li>
<li><a title="Image Gallery" href='fuzzypolaroidpics.php'>Fuzzy Polaroid</a></li>
<li><a title="Image Gallery" href='zombiewalk2009.php'>2009 Zombie Walk</a></li>
<li> </li><br><li>Or go back to:</li><li><a title='Picture galleries' href="pictures.php">Photography</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>Naima's 28th</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Picture galleries' href="pictures.php">Photography</a> > <a title='Pics of Naima's 28th birthday dinner' href="mim28th.php">Naima's 28th</a>
<br><br>		


<h1>Naima's 28th birthday dinner</h1>

<p>Mim has quickly grown to 28 (happy birthday!) and so a dinner and drinks were called for. Much merriment took place afterwards, including an impromteau organ jam including such favourites as The Girl From Ipanema, and an air guitar session to accompany some classic Bodycount. The pictures speak for themselves.</p>
<br><br>
All images in this gallery:<br>
<table width='800'>
<tr>
</tr>
<tr><td><A ID='IMG_9385.JPG' href='mim28th.php?fileId=IMG_9385.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060610/IMG_9385.JPG' ALT='IMG_9385.JPG'><BR>IMG_9385.JPG<br>66.71 KB</a><div class='inv'><br><a href='./images/20060610/IMG_9385.JPG' ALT='IMG_9385.JPG'>IMG_9385.JPG</a></div></td>
<td><A ID='IMG_9387.JPG' href='mim28th.php?fileId=IMG_9387.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060610/IMG_9387.JPG' ALT='IMG_9387.JPG'><BR>IMG_9387.JPG<br>94.34 KB</a><div class='inv'><br><a href='./images/20060610/IMG_9387.JPG' ALT='IMG_9387.JPG'>IMG_9387.JPG</a></div></td>
<td><A ID='IMG_9388.JPG' href='mim28th.php?fileId=IMG_9388.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060610/IMG_9388.JPG' ALT='IMG_9388.JPG'><BR>IMG_9388.JPG<br>52.98 KB</a><div class='inv'><br><a href='./images/20060610/IMG_9388.JPG' ALT='IMG_9388.JPG'>IMG_9388.JPG</a></div></td>
<td><A ID='IMG_9389.JPG' href='mim28th.php?fileId=IMG_9389.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060610/IMG_9389.JPG' ALT='IMG_9389.JPG'><BR>IMG_9389.JPG<br>71 KB</a><div class='inv'><br><a href='./images/20060610/IMG_9389.JPG' ALT='IMG_9389.JPG'>IMG_9389.JPG</a></div></td>
<td><A ID='IMG_9391.JPG' href='mim28th.php?fileId=IMG_9391.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060610/IMG_9391.JPG' ALT='IMG_9391.JPG'><BR>IMG_9391.JPG<br>42.68 KB</a><div class='inv'><br><a href='./images/20060610/IMG_9391.JPG' ALT='IMG_9391.JPG'>IMG_9391.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_9393.JPG' href='mim28th.php?fileId=IMG_9393.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060610/IMG_9393.JPG' ALT='IMG_9393.JPG'><BR>IMG_9393.JPG<br>45.1 KB</a><div class='inv'><br><a href='./images/20060610/IMG_9393.JPG' ALT='IMG_9393.JPG'>IMG_9393.JPG</a></div></td>
<td><A ID='IMG_9395.JPG' href='mim28th.php?fileId=IMG_9395.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060610/IMG_9395.JPG' ALT='IMG_9395.JPG'><BR>IMG_9395.JPG<br>43.04 KB</a><div class='inv'><br><a href='./images/20060610/IMG_9395.JPG' ALT='IMG_9395.JPG'>IMG_9395.JPG</a></div></td>
<td><A ID='IMG_9397.JPG' href='mim28th.php?fileId=IMG_9397.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060610/IMG_9397.JPG' ALT='IMG_9397.JPG'><BR>IMG_9397.JPG<br>46.09 KB</a><div class='inv'><br><a href='./images/20060610/IMG_9397.JPG' ALT='IMG_9397.JPG'>IMG_9397.JPG</a></div></td>
<td><A ID='IMG_9399.JPG' href='mim28th.php?fileId=IMG_9399.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060610/IMG_9399.JPG' ALT='IMG_9399.JPG'><BR>IMG_9399.JPG<br>49.57 KB</a><div class='inv'><br><a href='./images/20060610/IMG_9399.JPG' ALT='IMG_9399.JPG'>IMG_9399.JPG</a></div></td>
<td><A ID='IMG_9400.JPG' href='mim28th.php?fileId=IMG_9400.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060610/IMG_9400.JPG' ALT='IMG_9400.JPG'><BR>IMG_9400.JPG<br>38.94 KB</a><div class='inv'><br><a href='./images/20060610/IMG_9400.JPG' ALT='IMG_9400.JPG'>IMG_9400.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_9403.JPG' href='mim28th.php?fileId=IMG_9403.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060610/IMG_9403.JPG' ALT='IMG_9403.JPG'><BR>IMG_9403.JPG<br>53.82 KB</a><div class='inv'><br><a href='./images/20060610/IMG_9403.JPG' ALT='IMG_9403.JPG'>IMG_9403.JPG</a></div></td>
<td><A ID='IMG_9405.JPG' href='mim28th.php?fileId=IMG_9405.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060610/IMG_9405.JPG' ALT='IMG_9405.JPG'><BR>IMG_9405.JPG<br>50.14 KB</a><div class='inv'><br><a href='./images/20060610/IMG_9405.JPG' ALT='IMG_9405.JPG'>IMG_9405.JPG</a></div></td>
<td><A ID='IMG_9406.JPG' href='mim28th.php?fileId=IMG_9406.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060610/IMG_9406.JPG' ALT='IMG_9406.JPG'><BR>IMG_9406.JPG<br>41.77 KB</a><div class='inv'><br><a href='./images/20060610/IMG_9406.JPG' ALT='IMG_9406.JPG'>IMG_9406.JPG</a></div></td>
<td><A ID='IMG_9408.JPG' href='mim28th.php?fileId=IMG_9408.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060610/IMG_9408.JPG' ALT='IMG_9408.JPG'><BR>IMG_9408.JPG<br>38.81 KB</a><div class='inv'><br><a href='./images/20060610/IMG_9408.JPG' ALT='IMG_9408.JPG'>IMG_9408.JPG</a></div></td>
<td><A ID='IMG_9410.JPG' href='mim28th.php?fileId=IMG_9410.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060610/IMG_9410.JPG' ALT='IMG_9410.JPG'><BR>IMG_9410.JPG<br>35.07 KB</a><div class='inv'><br><a href='./images/20060610/IMG_9410.JPG' ALT='IMG_9410.JPG'>IMG_9410.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_9411.JPG' href='mim28th.php?fileId=IMG_9411.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060610/IMG_9411.JPG' ALT='IMG_9411.JPG'><BR>IMG_9411.JPG<br>51.28 KB</a><div class='inv'><br><a href='./images/20060610/IMG_9411.JPG' ALT='IMG_9411.JPG'>IMG_9411.JPG</a></div></td>
<td><A ID='IMG_9414.JPG' href='mim28th.php?fileId=IMG_9414.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060610/IMG_9414.JPG' ALT='IMG_9414.JPG'><BR>IMG_9414.JPG<br>38.62 KB</a><div class='inv'><br><a href='./images/20060610/IMG_9414.JPG' ALT='IMG_9414.JPG'>IMG_9414.JPG</a></div></td>
<td><A ID='IMG_9416.JPG' href='mim28th.php?fileId=IMG_9416.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060610/IMG_9416.JPG' ALT='IMG_9416.JPG'><BR>IMG_9416.JPG<br>48.12 KB</a><div class='inv'><br><a href='./images/20060610/IMG_9416.JPG' ALT='IMG_9416.JPG'>IMG_9416.JPG</a></div></td>
<td><A ID='IMG_9417.JPG' href='mim28th.php?fileId=IMG_9417.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060610/IMG_9417.JPG' ALT='IMG_9417.JPG'><BR>IMG_9417.JPG<br>46.73 KB</a><div class='inv'><br><a href='./images/20060610/IMG_9417.JPG' ALT='IMG_9417.JPG'>IMG_9417.JPG</a></div></td>
<td><A ID='IMG_9418.JPG' href='mim28th.php?fileId=IMG_9418.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060610/IMG_9418.JPG' ALT='IMG_9418.JPG'><BR>IMG_9418.JPG<br>52.07 KB</a><div class='inv'><br><a href='./images/20060610/IMG_9418.JPG' ALT='IMG_9418.JPG'>IMG_9418.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_9420.JPG' href='mim28th.php?fileId=IMG_9420.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060610/IMG_9420.JPG' ALT='IMG_9420.JPG'><BR>IMG_9420.JPG<br>47.04 KB</a><div class='inv'><br><a href='./images/20060610/IMG_9420.JPG' ALT='IMG_9420.JPG'>IMG_9420.JPG</a></div></td>
<td><A ID='IMG_9422.JPG' href='mim28th.php?fileId=IMG_9422.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060610/IMG_9422.JPG' ALT='IMG_9422.JPG'><BR>IMG_9422.JPG<br>49 KB</a><div class='inv'><br><a href='./images/20060610/IMG_9422.JPG' ALT='IMG_9422.JPG'>IMG_9422.JPG</a></div></td>
<td><A ID='IMG_9423.JPG' href='mim28th.php?fileId=IMG_9423.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060610/IMG_9423.JPG' ALT='IMG_9423.JPG'><BR>IMG_9423.JPG<br>49.61 KB</a><div class='inv'><br><a href='./images/20060610/IMG_9423.JPG' ALT='IMG_9423.JPG'>IMG_9423.JPG</a></div></td>
<td><A ID='IMG_9424.JPG' href='mim28th.php?fileId=IMG_9424.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060610/IMG_9424.JPG' ALT='IMG_9424.JPG'><BR>IMG_9424.JPG<br>35.47 KB</a><div class='inv'><br><a href='./images/20060610/IMG_9424.JPG' ALT='IMG_9424.JPG'>IMG_9424.JPG</a></div></td>
<td><A ID='IMG_9426.JPG' href='mim28th.php?fileId=IMG_9426.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060610/IMG_9426.JPG' ALT='IMG_9426.JPG'><BR>IMG_9426.JPG<br>93.96 KB</a><div class='inv'><br><a href='./images/20060610/IMG_9426.JPG' ALT='IMG_9426.JPG'>IMG_9426.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_9429.JPG' href='mim28th.php?fileId=IMG_9429.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060610/IMG_9429.JPG' ALT='IMG_9429.JPG'><BR>IMG_9429.JPG<br>91.43 KB</a><div class='inv'><br><a href='./images/20060610/IMG_9429.JPG' ALT='IMG_9429.JPG'>IMG_9429.JPG</a></div></td>
<td><A ID='IMG_9432.JPG' href='mim28th.php?fileId=IMG_9432.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060610/IMG_9432.JPG' ALT='IMG_9432.JPG'><BR>IMG_9432.JPG<br>54.26 KB</a><div class='inv'><br><a href='./images/20060610/IMG_9432.JPG' ALT='IMG_9432.JPG'>IMG_9432.JPG</a></div></td>
<td><A ID='IMG_9434.JPG' href='mim28th.php?fileId=IMG_9434.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060610/IMG_9434.JPG' ALT='IMG_9434.JPG'><BR>IMG_9434.JPG<br>80.37 KB</a><div class='inv'><br><a href='./images/20060610/IMG_9434.JPG' ALT='IMG_9434.JPG'>IMG_9434.JPG</a></div></td>
<td><A ID='IMG_9438.JPG' href='mim28th.php?fileId=IMG_9438.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060610/IMG_9438.JPG' ALT='IMG_9438.JPG'><BR>IMG_9438.JPG<br>85.93 KB</a><div class='inv'><br><a href='./images/20060610/IMG_9438.JPG' ALT='IMG_9438.JPG'>IMG_9438.JPG</a></div></td>
<td><A ID='IMG_9441.JPG' href='mim28th.php?fileId=IMG_9441.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060610/IMG_9441.JPG' ALT='IMG_9441.JPG'><BR>IMG_9441.JPG<br>69.49 KB</a><div class='inv'><br><a href='./images/20060610/IMG_9441.JPG' ALT='IMG_9441.JPG'>IMG_9441.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_9446.JPG' href='mim28th.php?fileId=IMG_9446.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060610/IMG_9446.JPG' ALT='IMG_9446.JPG'><BR>IMG_9446.JPG<br>65.17 KB</a><div class='inv'><br><a href='./images/20060610/IMG_9446.JPG' ALT='IMG_9446.JPG'>IMG_9446.JPG</a></div></td>
<td><A ID='IMG_9447.JPG' href='mim28th.php?fileId=IMG_9447.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060610/IMG_9447.JPG' ALT='IMG_9447.JPG'><BR>IMG_9447.JPG<br>65.43 KB</a><div class='inv'><br><a href='./images/20060610/IMG_9447.JPG' ALT='IMG_9447.JPG'>IMG_9447.JPG</a></div></td>
<td><A ID='IMG_9448.JPG' href='mim28th.php?fileId=IMG_9448.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060610/IMG_9448.JPG' ALT='IMG_9448.JPG'><BR>IMG_9448.JPG<br>70.91 KB</a><div class='inv'><br><a href='./images/20060610/IMG_9448.JPG' ALT='IMG_9448.JPG'>IMG_9448.JPG</a></div></td>
<td><A ID='IMG_9449.JPG' href='mim28th.php?fileId=IMG_9449.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060610/IMG_9449.JPG' ALT='IMG_9449.JPG'><BR>IMG_9449.JPG<br>69.3 KB</a><div class='inv'><br><a href='./images/20060610/IMG_9449.JPG' ALT='IMG_9449.JPG'>IMG_9449.JPG</a></div></td>
<td><A ID='IMG_9450.JPG' href='mim28th.php?fileId=IMG_9450.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060610/IMG_9450.JPG' ALT='IMG_9450.JPG'><BR>IMG_9450.JPG<br>59.03 KB</a><div class='inv'><br><a href='./images/20060610/IMG_9450.JPG' ALT='IMG_9450.JPG'>IMG_9450.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_9457.JPG' href='mim28th.php?fileId=IMG_9457.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060610/IMG_9457.JPG' ALT='IMG_9457.JPG'><BR>IMG_9457.JPG<br>70.82 KB</a><div class='inv'><br><a href='./images/20060610/IMG_9457.JPG' ALT='IMG_9457.JPG'>IMG_9457.JPG</a></div></td>
<td><A ID='IMG_9458.JPG' href='mim28th.php?fileId=IMG_9458.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060610/IMG_9458.JPG' ALT='IMG_9458.JPG'><BR>IMG_9458.JPG<br>63.11 KB</a><div class='inv'><br><a href='./images/20060610/IMG_9458.JPG' ALT='IMG_9458.JPG'>IMG_9458.JPG</a></div></td>
<td><A ID='IMG_9463.JPG' href='mim28th.php?fileId=IMG_9463.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060610/IMG_9463.JPG' ALT='IMG_9463.JPG'><BR>IMG_9463.JPG<br>64.57 KB</a><div class='inv'><br><a href='./images/20060610/IMG_9463.JPG' ALT='IMG_9463.JPG'>IMG_9463.JPG</a></div></td>
<td><A ID='IMG_9471.JPG' href='mim28th.php?fileId=IMG_9471.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060610/IMG_9471.JPG' ALT='IMG_9471.JPG'><BR>IMG_9471.JPG<br>65.41 KB</a><div class='inv'><br><a href='./images/20060610/IMG_9471.JPG' ALT='IMG_9471.JPG'>IMG_9471.JPG</a></div></td>
<td><A ID='IMG_9473.JPG' href='mim28th.php?fileId=IMG_9473.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060610/IMG_9473.JPG' ALT='IMG_9473.JPG'><BR>IMG_9473.JPG<br>47.24 KB</a><div class='inv'><br><a href='./images/20060610/IMG_9473.JPG' ALT='IMG_9473.JPG'>IMG_9473.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_9475.JPG' href='mim28th.php?fileId=IMG_9475.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060610/IMG_9475.JPG' ALT='IMG_9475.JPG'><BR>IMG_9475.JPG<br>52.25 KB</a><div class='inv'><br><a href='./images/20060610/IMG_9475.JPG' ALT='IMG_9475.JPG'>IMG_9475.JPG</a></div></td>
<td><A ID='IMG_9477.JPG' href='mim28th.php?fileId=IMG_9477.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060610/IMG_9477.JPG' ALT='IMG_9477.JPG'><BR>IMG_9477.JPG<br>60.15 KB</a><div class='inv'><br><a href='./images/20060610/IMG_9477.JPG' ALT='IMG_9477.JPG'>IMG_9477.JPG</a></div></td>
<td><A ID='IMG_9478.JPG' href='mim28th.php?fileId=IMG_9478.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060610/IMG_9478.JPG' ALT='IMG_9478.JPG'><BR>IMG_9478.JPG<br>70.18 KB</a><div class='inv'><br><a href='./images/20060610/IMG_9478.JPG' ALT='IMG_9478.JPG'>IMG_9478.JPG</a></div></td>
<td><A ID='IMG_9479.JPG' href='mim28th.php?fileId=IMG_9479.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060610/IMG_9479.JPG' ALT='IMG_9479.JPG'><BR>IMG_9479.JPG<br>74.86 KB</a><div class='inv'><br><a href='./images/20060610/IMG_9479.JPG' ALT='IMG_9479.JPG'>IMG_9479.JPG</a></div></td>
<td><A ID='IMG_9480.JPG' href='mim28th.php?fileId=IMG_9480.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060610/IMG_9480.JPG' ALT='IMG_9480.JPG'><BR>IMG_9480.JPG<br>67 KB</a><div class='inv'><br><a href='./images/20060610/IMG_9480.JPG' ALT='IMG_9480.JPG'>IMG_9480.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_9483.JPG' href='mim28th.php?fileId=IMG_9483.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060610/IMG_9483.JPG' ALT='IMG_9483.JPG'><BR>IMG_9483.JPG<br>64.44 KB</a><div class='inv'><br><a href='./images/20060610/IMG_9483.JPG' ALT='IMG_9483.JPG'>IMG_9483.JPG</a></div></td>
<td><A ID='IMG_9484.JPG' href='mim28th.php?fileId=IMG_9484.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060610/IMG_9484.JPG' ALT='IMG_9484.JPG'><BR>IMG_9484.JPG<br>58.56 KB</a><div class='inv'><br><a href='./images/20060610/IMG_9484.JPG' ALT='IMG_9484.JPG'>IMG_9484.JPG</a></div></td>
<td><A ID='IMG_9496.JPG' href='mim28th.php?fileId=IMG_9496.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060610/IMG_9496.JPG' ALT='IMG_9496.JPG'><BR>IMG_9496.JPG<br>69.18 KB</a><div class='inv'><br><a href='./images/20060610/IMG_9496.JPG' ALT='IMG_9496.JPG'>IMG_9496.JPG</a></div></td>
<td><A ID='IMG_9500.JPG' href='mim28th.php?fileId=IMG_9500.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060610/IMG_9500.JPG' ALT='IMG_9500.JPG'><BR>IMG_9500.JPG<br>64.79 KB</a><div class='inv'><br><a href='./images/20060610/IMG_9500.JPG' ALT='IMG_9500.JPG'>IMG_9500.JPG</a></div></td>
<td><A ID='IMG_9502.JPG' href='mim28th.php?fileId=IMG_9502.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060610/IMG_9502.JPG' ALT='IMG_9502.JPG'><BR>IMG_9502.JPG<br>65.59 KB</a><div class='inv'><br><a href='./images/20060610/IMG_9502.JPG' ALT='IMG_9502.JPG'>IMG_9502.JPG</a></div></td>
</tr>
</table>	</div>
</div>
</body>
</html>