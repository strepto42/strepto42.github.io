<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - Contact - Contact me</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="Contact me">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="truffulatree.com.au homepage" href="home.php">Home</a></li>
<li> </li><br>
<li><a title="About me" href='about.php'>About</a></li>
<li><a title="Picture galleries" href='pictures.php'>Photography</a></li>
<li><a title="Travel stories and pictures" href='travel.php'>Travelogues</a></li>
<li><a title="Mark's writing" href='written.php'>Professional Writing</a></li>
<li><a title="Programming work I've done" href='programming.php'>Programming</a></li>
<li><a title="Sounds and music" href='music.php'>Music</a></li>
<li><a title="Silly things for your amusement" href='silliness.php'>Silliness</a></li>
<li><a title="Old stuff from my site" href='archive.php'>Archive</a></li>
<li><div class='activemenu'>Contact</div></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>Contact</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Contact me' href="contact.php">Contact</a>
<br><br>		
Gone are the days of the mailto: link I'm afraid. You can thank the bottom-feeding, scum-sucking spammer community for that.<br>
<br>
You'll have to use the form below. Go on then, hop to it...<br>
<br>
<form name="contactform" action="../../cgi-bin/FormMail.pl" name="Join" method="post">
	<input type="hidden" name="redirect" value="http://www.truffulatree.com.au/home.php" />
	<table>
	<tr><td><div align="left">What is your name?</div></td><td><div align="left"><input type="text" name="realname" size="60"></div></td></tr>
	<tr><td><div align="left">What is your quest?</div></td><td><div align="left"><input type="text" name="subject" size="60" value="I seek the holy grail"></div></td></tr>
	<tr><td><div align="left">What is your Email address?<br>(for a reply, no I will not spam you)</div></td><td><div align="left"><input type="text" size="60" name="email"></div></td></tr>
	<tr><td><div align="left">What is your message?</div></td><td><div align="left"><textarea name="comments" cols="60" rows="8">Mate, I love you. You're so cool. Etc.</textarea></div></td></tr>
	<tr><td>&nbsp;</td><td><div align="left"><input type="submit" name="submit"></div></td></tr>
	</table>
</form>
<script language="javascript">
if (typeof(subject) != "undefined" ) {
	document.contactform.subject.value=subject;
}
</script>
	</div>
</div>
</body>
</html>