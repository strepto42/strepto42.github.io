<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - March 2004 - Q&A letters</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="Q&A letters">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="Q&A letters" href='masterit200401.php'>January 2004</a></li>
<li><a title="Q&A letters" href='masterit200402.php'>February 2004</a></li>
<li><div class='activemenu'>March 2004</div></li>
<li><a title="Q&A letters" href='masterit200404.php'>April 2004</a></li>
<li><a title="Q&A letters" href='masterit200405.php'>May 2004</a></li>
<li><a title="Q&A letters" href='masterit200406.php'>June 2004</a></li>
<li><a title="Q&A letters" href='masterit200407.php'>July 2004</a></li>
<li><a title="Q&A letters" href='masterit200408.php'>August 2004</a></li>
<li><a title="Q&A letters" href='masterit200409.php'>September 2004</a></li>
<li><a title="Q&A letters" href='masterit200410.php'>October 2004</a></li>
<li><a title="Q&A letters" href='masterit200411.php'>November 2004</a></li>
<li><a title="Q&A letters" href='masterit200412.php'>December 2004</a></li>
<li> </li><br><li>Or go back to:</li><li><a title='Q&A/MasterIT letters from 2004' href="masterit2004.php">2004 archive</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>March 2004</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Mark's writing' href="written.php">Professional Writing</a> > <a title='My weekly Q&A column in The Australian' href="masterIT.php">MasterIT</a> > <a title='Q&A/MasterIT letters from 2004' href="masterit2004.php">2004 archive</a> > <a title='Q&A letters' href="masterit200403.php">March 2004</a>
<br><br>		<br>
<h2>2/3/04</h2><br>
<b>O Master, a couple of years ago I bought a CD burner to make copies of my music and so on (of course all perfectly legal). It was always quite simple to create copies. Now I'd like to invest in a DVD burner for a similar purpose - however I find that it's not as simple! There are two formats, "DVD+R" and "DVD-R", as well as the fact that most DVD movies take up about 6-8Gb, yet blank DVDs only hold about 4.7Gb. Can you please give me the good oil on the subject?</b><br>
<br>
There are indeed more worms in the DVD burning can than the CD burning one. First of all we have the plus/minus format war.<br>
<br>
DVD-R came out first, and is generally considered to be more compatible with standalone DVD readers, in particular older ones. DVD+R is newer and technically superior (you can burn multisession discs with it), but may not be as compatible for playback. DVD+R discs also tend to have faster burning speeds, but this ultimately depends on the media and the burner.<br>
<br>
There are also rewritable versions of both sorts of disc available, DVD-RW and DVD+RW. There's also an older (and different again) format called DVD-RAM, but you're unlikely to bump into it much any more; we mention it only for the sake of adding an annoying extra acronym to the mouthful.<br>
<br>
The good news is that nowadays you can get combo burners which do all of the above (barring DVD-RAM), as well as CDs. Models are available from Sony, Liteon and the Rolls Royce of optical drive manufacturing, Plextor, to name a few.<br>
<br>
Regarding the other issue of disc size, this is caused by the fact that most pressed DVDs are double layer, and therefore have twice the capacity. Unfortunately dual layer DVD writers aren't yet available, although they're rumoured to be hitting the shelves sometime this year (at no doubt a premium price).<br>
<br>
The only workaround at the moment is to use multiple discs, or trim/re-encode the content of the DVD. Software is available to help with this, however it'll still require a bit of a learning curve. Check out the FAQ at www.dvddemystified.com.<br>
<br>
<br>
<h2>9/3/04</h2><br>
<b>When trying to power up my PC the following message appears: NTLDR is missing, Boot Failure, Insert Disk in A etc. I was running Windows 98. How do I fix it please?</b><br>
<br>
This is a strange message to have appear if you're running Windows 98; ntldr is a boot file for the NT flavours of Windows (NT, 2000 and XP), and it shouldn't be there unless you're running a dual boot system or something exotic. Assuming this isn't the case, you may have acquired a boot virus.<br>
<br>
At any rate, it's a little hard to offer advice without knowing more, so we'll stick with the time honoured classic - reinstall Windows. This will rewrite your boot sector and files, as well as freshening up your Windows installation.<br>
<br>
Simply boot off the Win98 CD, and select the option to upgrade rather than installing a brand new copy.<br>
<br>
<br>
<b>I'm looking at getting an external hard drive box to use for backups, as it's basically the cheapest way to store the enormous amounts of data I seem to have these days. I was wondering which is better out of Firewire or USB for the connection.</b><br>
<br>
First of all, when we're talking USB, we'll assume you mean USB 2.0, the newer, faster type of USB connection. At 12Mbits/sec USB 1.1 is going to be painfully slow for backing up large amounts of data (think many hours), whereas USB 2.0 is theoretically 40 times faster, at 480Mbits/sec.<br>
<br>
Firewire, also romantically known as IEEE1394, has a slower theoretical top speed of 400Mbits/sec, so on paper USB would appear to be the way to go.<br>
<br>
In the real world, the speed difference is negligible. Controller overheads, both in the computer and in the external box lower the throughput and you'll probably not be able to tell the difference.<br>
<br>
Firewire has been around for longer and is more advanced, and is therefore somewhat geekily cooler (eg some Firewire devices can be plugged into each other). However, it's less commonly found on older PCs (but is quite common on Macs).<br>
<br>
Ultimately the best choice will be the one that is supported by the largest number of computers you're likely to hook your backup box to.<br>
<br>
<br>
<h2>16/3/04</h2><br>
<b>Dear Masterful one, I recently received an email with the subject "you cannot hide yourself! (see photo)". I opened this email and there was an attachment - "important.zip 34 KB". On the strong (OK, horrified) advice of my teenagers, I did not open the attachment. They were of the opinion that it was far too big to be a photo and was probably a virus. They also rapped me on my metaphorical knuckles for opening the message part. Do I deserve their censure? Do you have a set of rules for deciding which emails are dangerous?</b><br>
<br>
Yep, that's a virus, a variant of the Netsky worm to be exact. Opening this particular email shouldn't have done any harm, but it is possible for some viruses to infect you just by opening the email. It depends on which mail program you use (Outlook can be vulnerable), and which security patches you have applied.<br>
<br>
As far as size goes, 34KB is a perfectly reasonable size for a photo - albeit a small one; often they're larger.<br>
<br>
Generally speaking, if an email looks strange, and/or has odd subject line (and/or content), it should be viewed with suspicion, even if it comes from a known source. Many viruses use real addresses when they fake their "from" field.<br>
<br>
Finally, be on the look out for strange attachments. Common tricks include naming files "picture.jpg.exe" and so on. Attachments ending in .PIF, .VBS and .SCR are particularly likely to be malevolent and should be shot on sight.<br>
<br>
At the end of the day, common sense and a good virus scanner are your best defence.<br>
<br>
<br>
<b>More on USB 2.0 vs. Firewire</b><br>
<br>
We've had a gentle reader point out that last in week's comparison between USB 2.0 and Firewire, speed difference does depend a lot on the platform and hardware you're dealing with, and Firewire does often beat USB when you're using a good controller.  (Mac controllers are sometimes speedier than PC ones, and speed of the peripheral is also a factor).<br>
<br>
An elderly but still relevant set of lies-ahem-benchmarks can be found at <a href="http://www.tomshardware.com/mobile/02q3/020827/index.html" target="_blank">www.tomshardware.com/mobile/02q3/020827/index.html</a><br>
<br>
There is also the newer Firewire 800 standard in the works, offering double the speed, which will spank the pants of USB, but it's not very common yet in the PC world.<br>
<br>
<br>
<h2>23/3/04</h2><br>
<b>Dear IT Master, I need your help again! This time it is regarding uninstalling files under Windows XP. Often I install software comprising many files. For example, programs I download from the Internet, or others that I get from magazines and I feel keen to try. The products don't always have an "Uninstall" option, and I have noticed that, apart from copying files to the directory of my choice (let us call it "MyDir"), dozens of files are sent, silently, to the Windows directory (and, who knows into which other ones!). When I want to remove fully, what should I do regarding what is not under MyDir?</b><br>
<br>
Unfortunately, it's often impossible to completely remove the detritus left behind by a badly designed installer. You'll end up with DLLs, various custom controls and support files floating around in your system folder somewhere, and even if you get rid of those, chances are your registry will retain a bunch of extra entires. It's all part of the Windows Experience.<br>
<br>
At this point it's very tempting to wax lyrical about the good old days, when computers were REAL computers (8 or 16-bit), and copying a program was as simple as copying the folder that contained it (the Linux and Mac crowd can pull their heads in about now, while better for this stuff they're still not perfect systems either).<br>
<br>
The painful transition (and indeed, ongoing pain) from those cleaner days and operating systems to the joy of Windows is at least made easier by a couple of comforting facts.<br>
<br>
Firstly, hard drive space is so cheap these days that it doesn't matter if there are 15,000 files - comprising 2 gig! - in the Windows folder, and secondly that Windows XP does at least keep it's own DLLs clean, preventing installers from stomping their own ancient versions over the current ones.<br>
<br>
And let's not forget the fact that modern computers outperform those older, cleaner ones by orders of magnitude, while still being cheaper. Think of it as a comfortable yet cheesy mansion that slowly fills up with junk. Every now and then you might have to burn it down and build another one, but it's a small price to pay.<br>
<br>
Send queries and jerrycans of naptha to <a href="contact.php?subject=MasterIT">(the masterit contact email address)</a><br>
<br>
<br>
<h2>30/3/04</h2><br>
<b>Sorry if this is a dumb question, but is Broadband Internet limited to just PCs or Macs? What I mean is, is one particular ISP going to meet my needs if I have both types of computer? How about DSL? Is it even worth it?</b><br>
<br>
DSL is just another type of Broadband Internet - the term pretty much covers anything faster than a traditional dialup connection (although lower speed IDSN and DSL connections could be argued to be little better, speed-wise).<br>
<br>
DSL (which, romantically, stands for Digital Subscriber Line) is available in various flavours, the most common of which is ADSL. The A stands for asymmetric, meaning that your send and receive speeds are not the same (sending is typically slower, but the majority of data transferred for a home connection is incoming so this doesn't matter so much).<br>
<br>
As far as platform dependence goes, the Internet connection itself doesn't restrict you to any one set of hardware; a pipe onto the Internet is just a pipe, although of course if you ask any geek some (bigger) pipes are more equal than others.<br>
<br>
You may, however, find that some ISPs are not prepared to support certain platforms that they deem to be "non-standard"; things like Linux or even Macs in some cases. Check their support policy before you sign up or you may end up having to support yourself.<br>
<br>
As far as the question of worth goes, it's really up to the individual to decide. Entry level broadband is far, far cheaper than it used to be, but it's still not exactly cheap. Then again, it used to be far, far too expensive (and certain unnamed large telcos haven't exactly helped the situation over the years).<br>
<br>
The key advantages of broadband are: it's always connected (with no tied up phone lines) and it's fast. Think about it. Google on tap.<br>
<br>
No wait, you'll put the Master out of a job.<br>
<br>
Seriously, if you do want to get connected, be careful of very cheap entry level plans. They can hit you with big excess usage charges if you go over a monthly download limit, which you can do within hours on broadband.<br>
<br>
A good site to check out when looking for an ISP is <a href="http://www.broadbandchoice.com.au" target="_blank">www.broadbandchoice.com.au</a>.<br>
<br>
<i><p>Did the information on this page help you? Entertain you? Bore you? <a href="contact.php?subject=MasterIT">Drop me a line</a>.</p>

<p>If you're feeling particularly generous, you can even <a href="buypics.php">click here to send me some dot-com riches</a>. Think of it as online busking.</i></p>
	</div>
</div>
</body>
</html>