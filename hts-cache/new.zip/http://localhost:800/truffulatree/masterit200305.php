<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - May 2003 - Q&A letters</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="Q&A letters">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="Q&A letters" href='masterit200301.php'>January 2003</a></li>
<li><a title="Q&A letters" href='masterit200302.php'>February 2003</a></li>
<li><a title="Q&A letters" href='masterit200303.php'>March 2003</a></li>
<li><a title="Q&A letters" href='masterit200304.php'>April 2003</a></li>
<li><div class='activemenu'>May 2003</div></li>
<li><a title="Q&A letters" href='masterit200306.php'>June 2003</a></li>
<li><a title="Q&A letters" href='masterit200307.php'>July 2003</a></li>
<li><a title="Q&A letters" href='masterit200308.php'>August 2003</a></li>
<li><a title="Q&A letters" href='masterit200309.php'>September 2003</a></li>
<li><a title="Q&A letters" href='masterit200310.php'>October 2003</a></li>
<li><a title="Q&A letters" href='masterit200311.php'>November 2003</a></li>
<li><a title="Q&A letters" href='masterit200312.php'>December 2003</a></li>
<li> </li><br><li>Or go back to:</li><li><a title='Q&A/MasterIT letters from 2003' href="masterit2003.php">2003 archive</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>May 2003</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Mark's writing' href="written.php">Professional Writing</a> > <a title='My weekly Q&A column in The Australian' href="masterIT.php">MasterIT</a> > <a title='Q&A/MasterIT letters from 2003' href="masterit2003.php">2003 archive</a> > <a title='Q&A letters' href="masterit200305.php">May 2003</a>
<br><br>		<br>
<h2>6/5/03</h2><br>
<b>I have burned a CD with files on it in MS Word, MS Excel and HTML. The CD contains our Business System procedures & forms. Is there a way I can 'timestamp' the CD whereas say after 3 months the information on the CD can no longer be read/accessed? This way we can protect/limit intellectual property being taken away.</b><br>
<br>
It's a nice idea, but unfortunately it's not possible to do this - nor is it feasible - for a number of reasons.<br>
<br>
Basically, once the data is out of your hands it becomes impossible to control.<br>
<br>
CD filesystems don't allow for expired content - but even if they did, CDs are a write-once medium, meaning that once burnt, the data can't be changed (with the exception of rewritable CDs of course).<br>
<br>
Multi-session CDs give the impression that you can delete files from them, but the data is still there - the files just get removed from the CD's table of contents, and it's actually quite easy to read them.<br>
<br>
Another thought that might come to mind is using custom software with a date-based system to restrict access. This sounds great until you realise it's trivially simple to change your computer's date as needed.<br>
<br>
At the end of the day, the data has to appear on screen at some stage, and as soon as it  does someone can capture it.<br>
<br>
<br>
<b>A week or so ago my Netscape Communicator had some problems that were eventually sorted out by Ozemail, but since then every time I send an email I am asked for the "Password for mail user username@ozemail.com.au@smtp.ozemail.com.au", and there is no "remember password" box to tick. Is there a way to tell the dumb machine what the password is?</b><br>
<br>
It actually sounds less like a password problem, and more like the username for outgoing mail is incorrect. Try changing the outgoing user name in the email preferences from "username@ozemail.com.au" to just "username". If that fails, try leaving it completely blank.<br>
<br>
If you're using Netscape 4, the setting will be in with all the other mail settings in the Edit->Preferences menu. For Netscape 6 and above look in Edit->Mail & Newsgroup Account Settings.<br>
<br>
<br>
<h2>13/5/03</h2><br>
<b>I've just picked up a second hand internal ZIP-100 drive. Is it possible to boot off a ZIP like you can with floppy disks?</b><br>
<br>
In your case, it should be, provided the your motherboard's BIOS supports it. Check the configuration to see if you can set up the ZIP drive as a boot device.<br>
<br>
You'll also need a bootable ZIP disk. You can make a DOS boot disk by copying all the files from a Win9x/ME boot floppy onto a blank ZIP. Make sure you get all the hidden system files; you may wish to use pop open a DOS window and use XCOPY.<br>
<br>
It's also possible to create bootable ZIP disks for various other operating systems; have a look on Google for more information.<br>
<br>
Of course, if none of that made sense, go with MasterIT's fallback option - bribe a geek and get them to do it. Offering caffeine and/or alcohol where appropriate may help.<br>
<br>
<br>
<b>Last year I bought a new PC with Works installed and now I have bought a notebook and wish to use the same software. What is the most economical way of getting the software on to the notebook?</b><br>
<br>
Well the obvious answer here is to just install it using the disc that came with the PC, but we're guessing that you don't have one, and that this is the problem.<br>
<br>
If we assume that the preinstalled copy of Works is legal, the best idea is to get in touch with the place where you purchased the PC, and ask them nicely for a replacement install disc.<br>
<br>
They should be able to furnish you with one, after all, you paid for the software with the PC.<br>
<br>
However, if the place doesn't exist any more, or they're a corner-cutting wretched hive of scum and villainy sporting a skull-and-crossbones flag, you may find yourself somewhat out of luck.<br>
<br>
Legalities aside, the effort involved in copying across a big application like Works really isn't worth it. You might have to bite the bullet and fork out for a copy.<br>
<br>
Alternatives to commercial software do exist though - check out www.openoffice.org. You may find that you don't need to worry about Works any more at all.<br>
<br>
<br>
<h2>20/5/03</h2><br>
<b>I have an HP DeskJet 930C that continues to return an error message saying that the colour cartridge is incorrectly fitted and that I should remove it and put it back in. This I have done on several occasions. I have also replaced the original offending cartridge. I still get the error message although it does not prevent the printer from printing the document as long as I do not respond the error. When the print is finished the error message disappears until I send another item to print. Do you have any information about how this could be happening and what I could do to solve the problem, apart from purchasing another printer?</b><br>
<br>
The worst case scenario is that something has gone wrong inside the printer, like for example an electrical connection, and that you'll need to get it serviced and/or replaced.<br>
<br>
Fortunately there are a couple of things you can try before having to resort to such drastic measures.<br>
<br>
It's quite possible that the electrical contacts that connect the cartridge and the printer are dirty; you'll want to check that they are clean.<br>
<br>
HP have a pretty page with pictures to guide you though this at <a href="http://www.hp.com/cposupport/printers/support_doc/bpa00299.html" target="_blank">www.hp.com/cposupport/printers/support_doc/bpa00299.html</a>.<br>
<br>
It's also possible that your printer still has a bee in its bonnet about a problem cartridge you're no longer using. In this case you can try doing a so-called hard reset of the printer.<br>
<br>
Information on doing this, as well as some more info another possible cause can be found at <a href="http://www.hp.com/cposupport/printers/support_doc/bpa02060.html" target="_blank">www.hp.com/cposupport/printers/support_doc/bpa02060.html</a><br>
<br>
<br>
<b>My office is full of comedians and I've just returned from holidays to discover that my Start button is up the top of the screen and all my text is green. Hilarious. Any and all advice appreciated� Oh I'm using XP.</b><br>
<br>
You should be able to change your text colour back fairly easily within the Appearance tab of the Display Properties. Click on Advanced and have a play around.<br>
<br>
Getting your taskbar back down the bottom should be as simple as dragging it, although with XP you might have to right click on it first and deselect "Lock the Taskbar" if it's ticked.<br>
<br>
And be thankful they didn't change your sounds. ;)<br>
<br>
<br>
<h2>27/5/03</h2><br>
<b>I have a problem with my mouse. It just hangs all the time. It does it in all applications and does it at the worst possible time. It is also getting more frequent. The only way to unfreeze it is to restart. This cures the problem for a time.<br>
<br>
It is a Microsoft Explorer optical mouse. I'm using XP Home. I reinstalled the original driver with no effect. I went to the Microsoft support site and downloaded and reinstalled an updated driver, also to no effect. The mouse software says the device is operating normally. I went to Microsoft and updated windows. I updated my virus definitions and ran a scan.<br>
<br>
It is strange because it just started happening. I had not updated anything or installed new software. Has Window gone bad? Do I need to start again and reinstall Windows?</b><br>
<br>
If the mouse freezes, but the computer still continues to work, you might have a faulty mouse or motherboard. It could also be a software problem, but it seems unlikely given that you've covered the appropriate bases there.<br>
<br>
One thing you could try just for the hell of it is to run the mouse off a different port. Many modern mouses can be connected to either the PS2 port, or to a USB port.<br>
<br>
Try the mouse in whichever port it's not in now. Failing that, try a different mouse altogether.<br>
<br>
If, on the other hand, your entire computer freezes solid along with the mouse cursor, the problem is more serious.<br>
<br>
The way to tell if a PC is frozen like this is just to hit the Caps Lock key a couple of times; if the little light on your keyboard doesn't flash then you're in deadlock land.<br>
<br>
Anyway, if this is what's happening it's most likely a hardware fault, as XP tends to be pretty stable.<br>
<br>
Often it can be caused by a component overheating. You might find your CPU cooler is loose or choked with dust.<br>
<br>
Unfortunately there's no magic bullet here;  intermittent hardware problems notoriously hard to track down. You might find investing in professional help is worth the stress you'll save, not to mention the money that would have gone into the swear jar.<br>
<br>
<i><p>Did the information on this page help you? Entertain you? Bore you? <a href="contact.php?subject=MasterIT">Drop me a line</a>.</p>

<p>If you're feeling particularly generous, you can even <a href="buypics.php">click here to send me some dot-com riches</a>. Think of it as online busking.</i></p>
	</div>
</div>
</body>
</html>