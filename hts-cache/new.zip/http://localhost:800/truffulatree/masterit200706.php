<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - June 2007 - Q&A letters</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="Q&A letters">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="Q&A letters" href='masterit200701.php'>January 2007</a></li>
<li><a title="Q&A letters" href='masterit200702.php'>February 2007</a></li>
<li><a title="Q&A letters" href='masterit200703.php'>March 2007</a></li>
<li><a title="Q&A letters" href='masterit200704.php'>April 2007</a></li>
<li><a title="Q&A letters" href='masterit200705.php'>May 2007</a></li>
<li><div class='activemenu'>June 2007</div></li>
<li><a title="Q&A letters" href='masterit200707.php'>July 2007</a></li>
<li> </li><br><li>Or go back to:</li><li><a title='Q&A letters from 2007' href="masterit2007.php">2007 archive</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>June 2007</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Mark's writing' href="written.php">Professional Writing</a> > <a title='My weekly Q&A column in The Australian' href="masterIT.php">MasterIT</a> > <a title='Q&A letters from 2007' href="masterit2007.php">2007 archive</a> > <a title='Q&A letters' href="masterit200706.php">June 2007</a>
<br><br>		<br>
<h2>5/6/07</h2><br>
<b>I use Excel 2003. Lately its reaction time has slowed right down. After typing a few characters I have to wait for it to catch up. And file selection (which one to open) is noticeably slow, too. Can you help?</b><br>
<br>
It could be a few different things. Have you recently installed any new hardware or software? Sometimes programs can interfere with the input routines of others.<br>
<br>
For example, if you install and enable the Microsoft speech recognition software it can slow your PC down enormously if it is running in the background. Sometimes it will sit there trying to make sense of the noises that are coming from the microphone - noises like typing - and of course not produce any output.<br>
<br>
The problem is that when it does this it tends to use all the available CPU power, and the system can slow down.<br>
<br>
You can check your CPU usage by right clicking on the taskbar and selecting Task Manager. Click on the Process tab and see if any one task is using 100% of the CPU (or 50% in the case of multiple processor/hyperthreading machines). If there is a program doing this, and it's not Excel, then it is very likely to be the culprit.<br>
<br>
<br>
<h2>12/6/07</h2><br>
<b>I wonder if you could help me solve a minor problem I have with My Zone Alarm Security Alerts. I am running a 2.8G PC with Windows XP Home and the Zone Alarm Security Suite 7.0.337.0. When I get a Security Alert Repeat Program dialog box, even though I tick the "Remember this Setting" and select an Allow or Delete option, it never seems to remember the setting.</b><br>
<br>
Apparently Zonealarm's internal settings have gotten corrupted. To fix it, you'll have to reboot into safe mode and remove the Zonealarm database.<br>
<br>
Unfortunately, this will reset the firewall and you'll have to re-train it, but it is the only way to fix the problem.<br>
<br>
Two pages on the subject, with detailed instructions are tinyurl.com/2yd389 and tinyurl.com/2thrl2.<br>
<br>
<br>
<b>Do I need to defragment my USB thumb drive? XP's defrag recommends that I do, but my friend said it would make little difference.</b><br>
<br>
Technically, your friend is slightly wrong. It won't make little difference - it will make no difference at all, and in fact it will even reduce the life of your USB key by a miniscule amount with the wear and tear.<br>
<br>
Defragmentation is something we do to hard drives because they have moving parts. Inside, they have a spinning platter (or platters) of metal or glass, and mechanical 'heads' that move over the platter, reading from (or writing to) the surface as it spins.<br>
<br>
Ideally, when a file is stored on the disk, it should have all it's data in one long 'stripe'. When this is the case, the head doesn't have to move much (or at all) to read it.<br>
<br>
However, sometimes the file is bigger than the available bit of stripe, and so half the data is stored in one place on the platter, and half in another. The computer is fine with this, but the head has to physically move in order to read it all, and this takes time.<br>
<br>
When you have large numbers of files split up like this, hard drive access can really slow down. By defragmenting, the computer tries to reorganise the data on the disk, so that more of the files 'join up' into one continuous area of data on the disk.<br>
<br>
USB flash drives, on the other hand, use solid state memory with no moving parts at all. Reading from different locations takes exactly the same amount of time, so degragmenting won't speed anything up.<br>
<br>
<br>
<h2>19/6/07</h2><br>
I have 2GB of RAM. When I try to use the assortment of various picture viewers on my PC for a large scanned map in TIFF format, I cannot save the file into other formats (sometimes getting an error message - insufficient memory). I have MS Speech recognition installed (anyway it appears on the task bar). When I use the Task Manager I find that the program ccSvHst.exe seems to hog nearly 100% of the memory. Can you please tell me what this program is? Do I need it? If I disable it (how) would there be any problems?<br>
<br>
You seem to have a few different, unrelated issues here.<br>
<br>
The first problem, with saving the TIFF file into another format, could be due to some corrupt data in the image itself, or it could just be due to the size of the image.<br>
<br>
Some image formats (like JPEG) don't cope with massive images (above a certain number of pixels) very well.<br>
<br>
"Insufficient memory" messages generally refer to the specific program which is trying to save the image - in some cases a poorly designed program fails to allocate enough memory to itself, and so it can run out, even if your PC has plenty to spare.<br>
<br>
I've had good results using a program called Acdsee (http://www.acdsee.com) over the years. It's fairly expensive, but is feature-rich. They have a free trial available for download, which will let you at least try to convert the picture.<br>
<br>
The ccScHst.exe file is apparently part of Norton antivirus/security, and nothing to do with the speech recognition software (the program in question there is generally called sapisvr.exe).<br>
<br>
It shouldn't use 100% of the CPU constantly though, and if it is, you might have a problem with your antivirus software, or even a virus infection. Try reinstalling it, and make sure you have all the latest patches installed for it, and for Windows.<br>
<br>
Failing a good result there, uninstall Norton's completely, and try a different antivirus program, like AVG (which is free) and see if you have more luck.<br>
<br>
<br>
<h2>26/6/07</h2><br>
<b>Regarding your answer on the defrag of a USB drive from a couple of weeks ago, I understand your point about no moving parts, but wouldn't there still be a very small overhead in processing the chaining pointers in a heavily fragmented file? Reading a defragmented file would simply involve reading contiguous bytes until EOF, whereas a fragmented file would have extra information in the form of pointers to other memory locations.</b><br>
<br>
You're right, assuming that the way the operating system accesses the files is more efficiently coded when it comes to contiguous files (which is probable, but not a certainty, given some of Microsoft's other ingenious code practices).<br>
<br>
Regardless though, the extra CPU overhead would be miniscule compared to the latency of the drive itself.<br>
<br>
Modern hard drives have a latency of around 13ms; flash drives are typically as low as 1ms (or lower). This is a tiny figure, but given that modern processors can handle something in the order of ten to twenty MILLION instructions during this period of time, a few thousand extra CPU cycles aren't going to make a huge dent.<br>
<br>
Good point, though!<br>
<br>
<i><p>Did the information on this page help you? Entertain you? Bore you? <a href="contact.php?subject=MasterIT">Drop me a line</a>.</p>

<p>If you're feeling particularly generous, you can even <a href="buypics.php">click here to send me some dot-com riches</a>. Think of it as online busking.</i></p>
	</div>
</div>
</body>
</html>