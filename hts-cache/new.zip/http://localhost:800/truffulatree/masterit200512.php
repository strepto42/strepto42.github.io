<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - December 2005 - Q&A letters</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="Q&A letters">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="Q&A letters" href='masterit200501.php'>January 2005</a></li>
<li><a title="Q&A letters" href='masterit200502.php'>February 2005</a></li>
<li><a title="Q&A letters" href='masterit200503.php'>March 2005</a></li>
<li><a title="Q&A letters" href='masterit200504.php'>April 2005</a></li>
<li><a title="Q&A letters" href='masterit200505.php'>May 2005</a></li>
<li><a title="Q&A letters" href='masterit200506.php'>June 2005</a></li>
<li><a title="Q&A letters" href='masterit200507.php'>July 2005</a></li>
<li><a title="Q&A letters" href='masterit200508.php'>August 2005</a></li>
<li><a title="Q&A letters" href='masterit200509.php'>September 2005</a></li>
<li><a title="Q&A letters" href='masterit200510.php'>October 2005</a></li>
<li><a title="Q&A letters" href='masterit200511.php'>November 2005</a></li>
<li><div class='activemenu'>December 2005</div></li>
<li> </li><br><li>Or go back to:</li><li><a title='Q&A/MasterIT letters from 2005' href="masterit2005.php">2005 archive</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>December 2005</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Mark's writing' href="written.php">Professional Writing</a> > <a title='My weekly Q&A column in The Australian' href="masterIT.php">MasterIT</a> > <a title='Q&A/MasterIT letters from 2005' href="masterit2005.php">2005 archive</a> > <a title='Q&A letters' href="masterit200512.php">December 2005</a>
<br><br>		<br>
<h2>6/12/05</h2><br>
<b>A couple of quick, slightly dumb questions (pity a person new to technology!). Firstly, one of spelling - just wondering if it's disk or disc? I see both used in IT literature!</b><br>
<br>
It depends what you're referring to. Originally, way back when, computer speak swapped back and forth until settling on "disk", hence hard and floppy disks, disk crashes and so on.<br>
<br>
Later on, optical media crept into the computer domain with the advent of CD-ROM. The D in CD was christened by the recording industry, who'd been jockeying "discs" for years, so that particular D is a c-job.<br>
<br>
<br>
<b>Secondly, I'd also love to know why floppy disks are called floppy (and similarly, hard for hard)!</b><br>
<br>
This old chestnut is becoming rarer as floppy disks slowly go the way of the vacuum tube (and not before time, unreliable horrid things that they are).<br>
<br>
The answer is simple to demonstrate. Take a floppy that you aren't very fond of any more, and crack it open. The disk inside is made from flexible, floppy plastic; the hard plastic casing is just there to protect the disk inside. In days gone by, floppies came in larger physical sizes (up to 8 inches), and these larger disks were indeed somewhat floppy on the outside too. You could bend them (although it wasn't recommended) quite a bit.<br>
<br>
Hard disks are a different animal. If you've seen one "naked" outside of your computer, it's just a rectangular metal brick. Inside though, there is a rigid metal (or sometimes even glass these days) disk, or series of stacked disks (referred to as platters). These are quite hard, and will ring like bells if you tap them.<br>
<br>
It's sensible to note at this point that tapping hard disk platters is generally a bad thing to be doing to any disk you happen to like, for opening up a hard disk drive will quite effectively end it's useful life. <br>
<br>
They're sealed to keep out dust, and once opened (outside of a clean room) you can pretty much kiss them - and any data on them - goodbye. So, if you're inquisitive, stick to dismantling disks that are already on the cactus list.<br>
<br>
If you have such a disk though, pulling it apart can be quite fun and educational, not to mention destructively therapeutic. It'll also give you the opportunity to remove and marvel at the rather frighteningly strong magnets that all modern disks contain.<br>
<br>
These rare earth magnets made excellent fridge magnets, especially if you like sticking entire magazines or newspapers to your whitegoods.<br>
<br>
<br>
<h2>13/12/05</h2><br>
<b>I am new to computers, and I read your Q&amp;A column closely each week. A couple of weeks ago, I was intrigued by your phrase "if your internet security settings aren't locked down tightly, and you are using Internet Explorer instead of Mozilla". Could you tell me what constitutes "locked down tightly", and why would Mozilla be more secure?</b><br>
<br>
If you go into the IE properties, you'll notice the "security" tab. In here, you can specify security levels for various zones, which is basically a fancy term for dividing up the sites you visit into groups - most of which fall under "Internet" by default.<br>
<br>
For each zone, you can specify a generic security level (a collection of preset rules), or a custom level, which lets you configure each rule individually.<br>
<br>
These rules all relate to the content your browser is allowed to receive and execute on your computer, as well as how it's allowed to behave when it does this (as web pages can try to do sneaky things behind your back).<br>
<br>
Generally speaking, they allow or disallow certain behaviours that could be used for malicious purposes (like receiving and running a virus without your knowledge, just by visiting a website).<br>
<br>
Microsoft's defaults are pretty secure, although people disagree on exactly what constitutes adequate security and/or privacy.<br>
<br>
For example, some people think allowing cookies is dangerous, when in fact it's not (although it can, at worst, potentially present small privacy issues).<br>
<br>
Mozilla is intrinsically more secure, as it adheres to web standards more rigidly, and tends to have less of the security "holes" that are found regularly in IE. It also doesn't support certain Microsoft proprietary scripting languages (which also tend to have holes), so it scores there too.<br>
<br>
The thing is, "less" still means "some". As the saying goes, it's impossible to have a completely secure system, unless it's sitting in the corner of a locked room, unplugged from the Internet and switched off. Common sense, the latest security patches from Windows Update, and a good virus scanner are your best defence at the end of the day.<br>
<br>
<br>
<b>Please tell me how to stop people sending me stupid attachments with xmas messages and all that nonsense. Bah humbug.</b><br>
<br>
Every year it happens... If the sender is close by, a swift rap to the forehead with a teaspoon often explains your point of view. International senders can be more problematic. My preferred response involves a snippet from a rather rude anti-Christmas song, but I am, after all, a grumpy bugger.<br>
<br>
Seasons greetings, and thank you to everyone who's written this year!<br>
<br>
<i><p>Did the information on this page help you? Entertain you? Bore you? <a href="contact.php?subject=MasterIT">Drop me a line</a>.</p>

<p>If you're feeling particularly generous, you can even <a href="buypics.php">click here to send me some dot-com riches</a>. Think of it as online busking.</i></p>
	</div>
</div>
</body>
</html>