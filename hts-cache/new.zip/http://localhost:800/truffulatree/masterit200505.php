<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - May 2005 - Q&A letters</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="Q&A letters">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="Q&A letters" href='masterit200501.php'>January 2005</a></li>
<li><a title="Q&A letters" href='masterit200502.php'>February 2005</a></li>
<li><a title="Q&A letters" href='masterit200503.php'>March 2005</a></li>
<li><a title="Q&A letters" href='masterit200504.php'>April 2005</a></li>
<li><div class='activemenu'>May 2005</div></li>
<li><a title="Q&A letters" href='masterit200506.php'>June 2005</a></li>
<li><a title="Q&A letters" href='masterit200507.php'>July 2005</a></li>
<li><a title="Q&A letters" href='masterit200508.php'>August 2005</a></li>
<li><a title="Q&A letters" href='masterit200509.php'>September 2005</a></li>
<li><a title="Q&A letters" href='masterit200510.php'>October 2005</a></li>
<li><a title="Q&A letters" href='masterit200511.php'>November 2005</a></li>
<li><a title="Q&A letters" href='masterit200512.php'>December 2005</a></li>
<li> </li><br><li>Or go back to:</li><li><a title='Q&A/MasterIT letters from 2005' href="masterit2005.php">2005 archive</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>May 2005</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Mark's writing' href="written.php">Professional Writing</a> > <a title='My weekly Q&A column in The Australian' href="masterIT.php">MasterIT</a> > <a title='Q&A/MasterIT letters from 2005' href="masterit2005.php">2005 archive</a> > <a title='Q&A letters' href="masterit200505.php">May 2005</a>
<br><br>		<br>
<h2>3/5/05</h2><br>
<b>Hi Mark, I am a senior citizen, trying to get to grips with the marvels of the computer world. I am on dialup and  receive many unwanted E-mails, which clog up my Inbox and often exceed my mailbox allowance. They take forever to download as well. On my Server Home page I can access webmail, and delete mail that I don't want before receiving it. Unfortunately, the system went wrong, and although my incoming mail shows up in webmail, on my computer the inbox is empty. When I log on to webmail, however, there are new messages coming in. My Server tells me there is a fault in my computer, yet when I talk to the people from whom I bought the computer, they say the fault lies with the Server's equipment. So I am the meat in the sandwich and don't know what to do next.</b><br>
<br>
It's good to see buck-passing is alive and well in the industry.<br>
<br>
It sounds like you have two different problems. One is the unwanted emails, A.K.A. good old Spam. A program called Mailwasher (http://www.mailwasher.net) can help with this. It works a bit like the webmail, in that you can preview emails without downloading them, and delete them if need be.<br>
<br>
It will automatically flag spam, and maintain so-called black and white lists of senders, so you can prevent legitimate mail from being binned with extreme prejudice.<br>
<br>
The second issue of your empty inbox sounds like it's probably a simple configuration issue within your local email program. Your ISP (the people you connect with) should be able to help you fix this.<br>
<br>
<br>
<b>We recently upgraded to Windows XP, and now I find I cannot use Publisher files from Office 2000. As I still have access to my files (with graphics) on my old computer, I had expected to be able to transfer these files. As, in theory, I still own the Publisher program, why can't I use it?  How do I transfer it?</b><br>
<br>
I presume you can't open the files on your new PC as Publisher (the program itself) isn't installed. If this is the case all you need to do is find your original Office installation CD and set it up on the new PC. You will need the CD though - unfortunately it's not possible to copy the installed program files.<br>
<br>
Do let me know if I'm stating the obvious, or missing something!<br>
<br>
<br>
<h2>10/5/05</h2><br>
<b>I'm thinking of travelling around Australia with a laptop, and I was wondering what my best option for Internet access will be. I'm assuming I'll be stuck on dial-up - I know some of the bigger ISPs have special numbers that I can use from anywhere in the country. Do you think this is the right way to go? Or are there other options?</b><br>
<br>
The dialup option sounds good, but it'll only work for you if you're staying in places with freely available phone lines. Hostels won't have these - hotels and motels generally do, but they're often restricted lines, meaning that your magic dial-anywhere-for-a-local-call number probably won't work. Back to square one.<br>
<br>
If you have a GSM phone and Bluetooth, you can use the combination for internet access on your laptop using GPRS - however the costs are astronomical. For example, for casual data use, Telstra currently charge a ridiculous 2.2 cents per KILOBYTE. You can purchase pre-paid data packs, but the cost is still unfeasibly high (1-2 cents/kb).<br>
<br>
For cost, and in terms of Australia-wide connectivity, CDMA is your best bet. Unfortunately you'll need to get some special hardware, or have a compatible handset. You'll then need to arrange an appropriate wireless broadband plan for your needs. See http://tinyurl.com/e4q4w for Telstra's offerings in this department.<br>
<br>
There is also satellite - however once again you're looking at big dollars to set up and operate, and of course you need some sort of vehicle to power it all - lugging round that gear in a backpack isn't exactly an option, unless your last name is Hulk.<br>
<br>
So apart from the above, you'll be restricted to coughing up and hooking up at Internet Cafes. You're looking at $5-10 an hour at most net cafes, so you might want to work offline as much as possible and just hop on for a quick send/receive.<br>
<br>
One final option, if you're a bit of a hacker, is to find someone who hasn't secured their wireless access point, and leech off them. Find yourself a well-to-do suburb and walk or drive around, you'll be surprised how many people don't bother or know how to put basic security on their networks.<br>
<br>
This is, of course, somewhat impolite, no doubt illegal, and completely unreliable as a means of regular access, but hey, if people can't put basic security on their wireless networks, perhaps they deserve a little geek wake up call. Just be kind and don't use ALL their monthly allowance.<br>
<br>
<br>
<h2>17/5/05</h2><br>
<b>I blamed the age of my monitor for blurring so badly that the print was almost unreadable. A friend gave me a much newer monitor which was a revelation - for a month. Perhaps I threw out a perfectly innocent monitor. What might be the problem, and is it likely to be expensive to fix?  It is used only for emails and an occasional browse on the net. I would be grateful for any suggestions.</b><br>
<br>
Old monitors are a bit of a mixed bag - they can be fine, or go bad quick quickly. Not all monitors are created equal; old expensive brands are often still better than brand new cheapos.<br>
<br>
I recall an old article on monitors from years ago, which stated that they all work by magic. Good monitors have strong magic, and bad ones weak magic. And of course the magic leaks out over time.<br>
<br>
Back in the real world, the blurriness is almost always due to the focus of the electron guns going out of alignment, often due to various electronic components inside drifting from their original specifications with age. The focus can change with temperature too - I had an old monitor that was blurry when cold, but once it had been on for a while it was fine.<br>
<br>
There is actually an adjustment inside the monitor for fixing the focus, however it's definitely not something you'll want to fool with yourself, due to the high voltages floating around. Poking around inside PC cases is fine, but monitors can very easily turn you into a crispy critter.<br>
<br>
An electronic service place will be able to adjust the focus, but the economy of the project might not make it worth it. New monitors are really cheap these days - and decent second hand 19 and 17 inch screens can be had for as little as $100. An electronic repair shop might even have a few reconditioned units floating around, which they might be able to sell you if they can't resurrect the picture on your current screen.<br>
<br>
Of course, if you want to, you can go upmarket. A new LCD flat screen will set you back $500 onwards.<br>
<br>
<br>
<h2>24/5/05</h2><br>
<b>When I copy text from Word, and paste into Word or even this programme Thunderbird, the text pasted has a line through it and the text is light grey. Where can I go to undo this default setting? The problem only recently appeared, probably after reinstalling Office 2002.</b><br>
<br>
This is a common problem, caused by Microsoft Word being overly clever about cutting and pasting. It copies the style information along with the actual text - something which is quite irritating 90% of the time. It can also get confused easily, hence the crossed out text.<br>
<br>
Thankfully, there is a way round it; in Word, under the edit menu, is an option called "paste special". Select that instead of normal pasting and then select "unformatted text". It should come across normally.<br>
<br>
One of the most helpful things that I've ever discovered during the course of writing the column, is that you can program your own keyboard shortcuts into Word, and automate the above.<br>
<br>
To do it, go into Word, then press Ctrl-Alt and plus on the numeric pad at the same time. The cursor should turn into an odd looking thing (technical term). Then go to the edit menu and select "paste special" (for example only - one can actually select any menu and create a keyboard shortcut to it).<br>
<br>
Now press the new shortcut key (I have set up Alt-V to paste special) and then click assign.<br>
<br>
From now on you should be able to paste plain text fairly easily using Alt-V.<br>
<br>
<br>
<b>I recently discovered that you can use Windows-M to minimise everything, and Windows-E to open Explorer; so it got me thinking, is there an easy way to define a keyboard shortcut for a program of my choice? For example, I use the calculator and Word a lot.</b><br>
<br>
There is indeed. First up you need a shortcut to the program. The Start menu is actually composed entirely of shortcuts - so all you have to do is go into the properties for the particular program by right clicking on it's icon and selecting properties.<br>
<br>
Now under the Shortcut tab you should have a box called Shortcut Key with "none" in it. Simply click this box, and press the key combination you want to use for that program.<br>
<br>
It's advisable to use some modifiers, like control and alt, or you'll open things when you don't want to. I find Ctrl-Alt-C works well for the calculator. Similarly, Ctrl-Alt-W for Word would be nice and intuitive.<br>
<br>
<br>
<h2>31/5/05</h2><br>
<b>My computer has suddenly decided it cannot locate the CD Rom. No matter what CD I put in, it says "Cannot locate the CD Rom" and "Please insert the correct CD Rom and restart the application". I did try Start, Run, Browse D: whilst a CD was in there. It announced "D: is not accessible. The device is not ready".</b><br>
<br>
It could be a software glitch, but it's much more probable that your CD drive has kicked the bucket. Unfortunately, they're known to just stop working after a while; sometimes due to dust building up on the lens inside, or the laser drifting out of alignment over time.<br>
<br>
Whilst it's possible to revive a drive in both these situations, it's rarely worthwhile, as the effort and expense (it's often quite hard to track these things down and fix them economically) make simply getting a new drive a more attractive alternative; there's never been a better excuse to get yourself a shiny new DVD or CD burner.<br>
<br>
Your best bet is to get a hardware specialist to have a look at your machine; they should be able to swap the CD drive for another one, which will let you know if the problem is in the hardware itself, or if it's just a software glitch.<br>
<br>
<br>
<b>I am using Windows XP and Incredimail, but the problem also existed when I was using Outlook Express. When I delete an item from my inbox, it goes into the deleted items box, but when I try to permanently delete it from there, although I follow the steps, it pops up back in my inbox the next time I open the computer. Of course this means a very cluttered mailbox and lots of frustration, so I'd appreciate a possible solution.</b><br>
<br>
The problem is due to the mail being left on the server. There is actually an option in all email programs to do this, and when selected, the mail program just downloads a copy of any new mail, rather than moving the mail to your inbox.<br>
<br>
It's smart enough to know which messages have already been downloaded, so you only get one copy, but once you remove them permanently from the deleted items folder, I suppose it forgets, and you do get a new copy all over again.<br>
<br>
Check the mail account settings for such an option - and make sure it's not selected. I don't know where it is with Incredimail, however from memory the website has a good guide. For Outlook Express, it's in the advanced mail account settings.<br>
<br>
<i><p>Did the information on this page help you? Entertain you? Bore you? <a href="contact.php?subject=MasterIT">Drop me a line</a>.</p>

<p>If you're feeling particularly generous, you can even <a href="buypics.php">click here to send me some dot-com riches</a>. Think of it as online busking.</i></p>
	</div>
</div>
</body>
</html>