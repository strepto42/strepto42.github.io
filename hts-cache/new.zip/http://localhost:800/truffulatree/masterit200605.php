<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - May 2006 - Q&A letters</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="Q&A letters">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="Q&A letters" href='masterit200601.php'>January 2006</a></li>
<li><a title="Q&A letters" href='masterit200602.php'>February 2006</a></li>
<li><a title="Q&A letters" href='masterit200603.php'>March 2006</a></li>
<li><a title="Q&A letters" href='masterit200604.php'>April 2006</a></li>
<li><div class='activemenu'>May 2006</div></li>
<li><a title="Q&A letters" href='masterit200606.php'>June 2006</a></li>
<li><a title="Q&A letters" href='masterit200607.php'>July 2006</a></li>
<li><a title="Q&A letters" href='masterit200608.php'>August 2006</a></li>
<li><a title="Q&A letters" href='masterit200609.php'>September 2006</a></li>
<li><a title="Q&A letters" href='masterit200610.php'>October 2006</a></li>
<li><a title="Q&A letters" href='masterit200611.php'>November 2006</a></li>
<li><a title="Q&A letters" href='masterit200612.php'>December 2006</a></li>
<li> </li><br><li>Or go back to:</li><li><a title='Q&A/MasterIT letters from 2006' href="masterit2006.php">2006 archive</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>May 2006</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Mark's writing' href="written.php">Professional Writing</a> > <a title='My weekly Q&A column in The Australian' href="masterIT.php">MasterIT</a> > <a title='Q&A/MasterIT letters from 2006' href="masterit2006.php">2006 archive</a> > <a title='Q&A letters' href="masterit200605.php">May 2006</a>
<br><br>		<br>
<h2>2/5/06</h2><br>
<b>I have a laptop, and a standalone PC running XP, which is connected to the Internet via a standard ADSL modem. The PC's Ethernet port it used up by the modem, so I can't use it to hook up to the laptop, however, both PC and laptop have Firewire connections, and I've successfully used these to network the two for file sharing. The only problem is that the laptop cannot access the Internet. Is there some way I can share the 'net connection without investing in new hardware?</b><br>
<br>
Yes, there are two ways you can set this up, both of which are equally easy, although of course your PC will need to be switched on and booted for sharing to work.<br>
<br>
First of all, you can use XP's built-in Internet connection sharing facility. Open up your network connections settings (most easily done by right clicking on "my network places" and selecting "properties").<br>
<br>
Now, work out which of the connections is the Internet connection. It may appear simply as the local area connection, or it may have a dedicated icon of it's own, depending on your modem. Next, right click on it, select properties, and click on the Advanced tab.<br>
<br>
Now should see a section called Internet Connection Sharing (ICS) - tick the "allow other users to connect..." box, select the Firewire network connection in the drop down box, click OK, and restart the laptop. You should be in business.<br>
<br>
An alternative way to share the connection is to use XP's network bridge function. Similarly to above, go to the network connection settings, but this time select both the Internet connection, AND the Firewire connection (by holding down the Ctrl key as you click). Now right click, and select "bridge connections" instead of properties. A new item will appear called "network bridge", and you should be up and running.<br>
<br>
The difference between setting up a bridge and using ICS is largely technical, but basically, the bridge function effectively "joins" the Ethernet network to the firewire network in a more complete way, whilst ICS just acts as a proxy. In your particular case, either method will probably be quite suitable, but people using dial-up will need to use ICS, as a dial-up connection cannot be bridged.<br>
<br>
You can find more information on both ICS and network bridging at http://tinyurl.com/dhz0.<br>
<br>
<br>
<h2>16/5/06</h2><br>
<b>Using Hotmail with IE, I can receive emails with embedded pictures within the text, and with varying font styles, however when I forward such emails I lose the embedded pics (though they remain as attachments) and all fonts appear as the default font. Also, I am not aware how to prepare an email with embedded pictures or with varying fonts. Can you please advise me how to utilise my email configuration to make use of these functions. Also, is there any way to stop the ">" which appears against each line in the original text when replying to an email message?</b><br>
<br>
Sending rich text emails with embedded pictures is fairly easy with a standard email program, but impossible when using Hotmail's browser interface.<br>
<br>
Luckily though, you do have another option - you can set up Hotmail to work within Outlook Express (Microsoft's standalone email program that comes with Windows), and it has the capability to embed pictures within rich text. <br>
<br>
To do this, you first need to set up the account within OE. Fire it up, and go to the tools menu, then select "accounts". <br>
<br>
Now click Add->Mail, fill in your name, click next, then put in your hotmail email address. The next screen should now default to a server type of "http/hotmail" - if not then you should set it up manually. Finally, finish the wizard by putting in your password and the various other details as requested (it should be fairly self-explanatory).<br>
<br>
Now that you've got your Hotmail account going, compose a new email, and make sure you've selected "rich text (html)" from the Format menu. If you have, there will be a toolbar present for changing the font size, colour and so on. You can also insert pictures using this toolbar, or by selecting the appropriate item from the "insert" menu. <br>
<br>
Regarding the ">" symbols, Hotmail has an online option to disable this, as does Outlook Express. OE's setting is hidden in tools->options->send->mail sending format->plain text settings.<br>
<br>
As a final note, take care when attaching large pictures to emails. It is considered impolite to attach more than about 600kb of data to an email, and with modern digital cameras it's easy to exceed this (they often produce pictures in the order of several megabytes!), so - use your new found powers wisely!<br>
<br>
<br>
<h2>23/5/06</h2><br>
<b>I have a couple of PCs set up on a home lan, and I am trying to connect to my "server" using XP's remote desktop. Unfortunately I get the message "Unable to log you on because of an account restriction". What's going wrong?</b><br>
<br>
You're getting the message because you're trying to log on using an account with a blank password. XP denies this by default, as a security precaution - if your machine is accessible from the Internet then Random J. 733t Haxx0r can log in without even having to enter a password, and promptly take advantage of and pillage your precious machine and it's data.<br>
<br>
If you're satisfied that the machine in question is definitely secured from the Internet, you can disable the requirement for a password by going to Start->run and typing "secpol.msc /s". This will bring up the editor for the local security policy. Go to local policies->security options, and change the value of "Accounts: Limit local account use of blank passwords to console logon only" to disabled.<br>
<br>
Alternatively, and perhaps more simply/securely, you can assign a password to the account you're trying to use.<br>
<br>
<br>
<b>How can I edit a .shs ("scrap") graphic file? Which program(s) support(s) this format? I can't open this sort of file with The Gimp, nor with Microsoft Paint. I would like to open such files and save them in a different format (one recognised by above applications). I have attached an example, cut from a PDF that I am trying to edit the text and images of.</b><br>
<br>
Unfortunately these scrap files are a proprietary Microsoft format. The one you sent me opens just fine in Word 2003 - and from there I can copy and paste it again into an image editor like the ones you listed.<br>
<br>
This won't work as easily for scraps which contain both pictures and text, which, if I understand correctly, is what you're trying to grab from the PDF file.<br>
<br>
Alas, the options here are a little limited. To make life even more difficult, some PDF files lock the images and text to stop people grabbing them. In these cases your only option is to do a screen grab (which you can do by pressing ALT-PRT_SC) and then paste it into the image editor of your choice. This won't let you edit the text though, but it's the next best thing.<br>
<br>
<br>
<h2>30/5/06</h2><br>
<b>I have a problem with my PC's CD drive. Whenever I access it, either for reading or writing, my computer gets extremely slow and 'stuttery', for want of a better word. I've done some research, and discovered that 'DMA mode' needs to be enabled for my drive, but despite following the instructions on the net my drive still reverts to PIO mode. It's fairly new; surely this can't be normal? To make matters worse, Autoplay no longer works on my drive either, despite my efforts to fix it. Help!</b><br>
<br>
Regarding the first issue, it sounds like you're experiencing one of the lesser known, and more irritating features of Windows.<br>
<br>
As you've discovered, enabling DMA (or Direct Memory Access) mode is essential on a modern PC. It lets the CD drive transfer data to and from memory without having to go via the CPU - freeing it up for other, insignificant tasks (like, say,  running your entire operating system).<br>
<br>
Perversely, XP can permanently disable DMA mode under certain circumstances, like if the drive is reports a certain number of data errors. This can be indicative of a bad cable connecting the drive, but more commonly it can happen if you try and read a damaged or dirty disc.<br>
<br>
This is fine and possibly quite sensible (albeit annoying) on a temporary basis, but some genius decided the change should be permanent and impossible to revert without hacking the registry.<br>
<br>
Thankfully a tool exists that can help - it's a simple VB script that does the registry changes for you.<br>
<br>
Regarding Autoplay, there are a number of possible problems. Microsoft themselves have released a utility to address most of these. It can be downloaded from their site, but for convenience I've grabbed it and bundled it with the aforementioned VB script. They can both be downloaded from http://tinyurl.com/o3rtj.<br>
<br>
Note that after you run the script, if your drive still tends to revert to PIO mode even when using undamaged CDs, you probably have a hardware problem (most likely in the form of a faulty data cable, but possibly also the CD drive itself).<br>
<br>
<i><p>Did the information on this page help you? Entertain you? Bore you? <a href="contact.php?subject=MasterIT">Drop me a line</a>.</p>

<p>If you're feeling particularly generous, you can even <a href="buypics.php">click here to send me some dot-com riches</a>. Think of it as online busking.</i></p>
	</div>
</div>
</body>
</html>