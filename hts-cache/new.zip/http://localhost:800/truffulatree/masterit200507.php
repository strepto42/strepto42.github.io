<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - July 2005 - Q&A letters</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="Q&A letters">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="Q&A letters" href='masterit200501.php'>January 2005</a></li>
<li><a title="Q&A letters" href='masterit200502.php'>February 2005</a></li>
<li><a title="Q&A letters" href='masterit200503.php'>March 2005</a></li>
<li><a title="Q&A letters" href='masterit200504.php'>April 2005</a></li>
<li><a title="Q&A letters" href='masterit200505.php'>May 2005</a></li>
<li><a title="Q&A letters" href='masterit200506.php'>June 2005</a></li>
<li><div class='activemenu'>July 2005</div></li>
<li><a title="Q&A letters" href='masterit200508.php'>August 2005</a></li>
<li><a title="Q&A letters" href='masterit200509.php'>September 2005</a></li>
<li><a title="Q&A letters" href='masterit200510.php'>October 2005</a></li>
<li><a title="Q&A letters" href='masterit200511.php'>November 2005</a></li>
<li><a title="Q&A letters" href='masterit200512.php'>December 2005</a></li>
<li> </li><br><li>Or go back to:</li><li><a title='Q&A/MasterIT letters from 2005' href="masterit2005.php">2005 archive</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>July 2005</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Mark's writing' href="written.php">Professional Writing</a> > <a title='My weekly Q&A column in The Australian' href="masterIT.php">MasterIT</a> > <a title='Q&A/MasterIT letters from 2005' href="masterit2005.php">2005 archive</a> > <a title='Q&A letters' href="masterit200507.php">July 2005</a>
<br><br>		<br>
<h2>5/7/05</h2><br>
<b>I'm fairly new to computers, and I often see references to Windows this or Windows that. I was wondering if you could give me executive summary on what all the versions mean, and which one is best.</b><br>
<br>
The magical world of Windows starts back in the 80s, and there are two lineages to cover. I'll skip describing the horrors of the now-antiquated Windows versions 1 to 3 though, and jump to 1995, when Microsoft released their much revamped, Start-button-toting Windows 95.<br>
<br>
There were two incarnations of Win 95 - the original and the much less buggy "B" version. Both are now firmly confined to the realm of obsolescence, but you'll still run into 95 on older PCs from time to time.<br>
<br>
Win 95 was designed for home and small office PCs. For servers, Microsoft had a product called Windows NT, version 4 of which looked superficially similar to 95, but had a completely different engine under the hood (one much more advanced and stable).<br>
<br>
Windows 95 spawned Win 98, then Win 98 Second Edition, and then finally Windows ME. 98 SE was the best of the lot here, but it still had plenty of problems.  ME is basically 98 with more bells, whistles and bugs, and should be avoided like the plague, and all these editions "go bad" over time, requiring regular reinstallations.<br>
<br>
Meanwhile, NT gave birth to Windows 2000, which in turn evolved into XP. Each successive product was better than the last, and whilst XP still has plenty of flaws, it's the best MS operating system around at the moment, provided, of course, that you have a new enough machine to run it efficiently (each new version of Windows has had greater hardware requirements to run smoothly).<br>
<br>
If you think that's fairly complicated, it gets worse, with 2000 and XP coming in different flavours (Home and Professional for XP), with different markets in mind (and that's before we go into the server market, where you'll find Windows 2003).<br>
<br>
So, the executive summary goes like this: If you have new hardware, go with XP, (home or pro, you'll generally know if you need pro).<br>
<br>
If, however, your hardware is really long in the tooth (say more than 5 years old), you might be better off with 98 SE, although Microsoft no longer support it, and hence there are no official security patches being released.<br>
<br>
If you just want to do a spot of word processing it'll be fine, but any serious application these days really probably warrants upgraded hardware and XP.<br>
<br>
<br>
<h2>12/7/05</h2><br>
<b>I am using Windows XP, Outlook Express and Openoffice (having just recently upgraded my computer). My problem is that the spell check in Outlook Express requires Microsoft Word to operate. Can you suggest a solution? My typing is of a standard that a spell check on my emails is almost essential.</b><br>
<br>
Unfortunately, I don't know of any other way to do the spell check thing with OE. I know Outlook itself has built in spell checking, but once again you need Office for that, so it's not really a solution.<br>
<br>
Of course, my usual evangelical advice is to get people to use Mozilla (browser, mail and so on in one), or Thunderbird & Firefox (both also Mozilla projects, but separate packages for browsing and mail).<br>
<br>
I myself have been using Mozilla for years to do my mail, and I find it quite a lot better than OE. It has spell checking as standard, and lots of other cool features. It also stores your mail on disk using an open and accepted standard, as opposed to Microsoft's proprietary formats, which makes changing mail programs and keeping your mail later on in life a much easier prospect.<br>
<br>
If you want to have a look, the downloads are at mozilla.org.<br>
<br>
<br>
<b>My bugbear is backing up Business Contact Manager 2003 seamlessly. I found the utility to back up Outlook 2003, and each time I close my session it asks me if I wish to back up my files. Why they need a second back up facility within the same program is beyond me, but for Business Contact Manager, I have to physically back it up into My Documents, where I back it up into a particular folder. Unfortunately it appears to create little folders all through My Documents in the process. I still haven't figured out how to restore from a back up of Business Contact Manager either.</b><br>
<br>
I'm afraid I'm not exactly a guru on BCM 2003 - but I did find this:<br>
<br>
http://tinyurl.com/c4txv<br>
<br>
It seems a little fiddly, but it also looks like a better solution than the built in backup.<br>
<br>
Overall, the best backup strategy is probably for you to back up your entire system regularly anyway; dedicated backup programs are generally much more flexible and restoration is much easier too, and as we all know, data that isn't backed up is not data you want to keep.<br>
<br>
<br>
<h2>19/7/05</h2><br>
<b>I've been using XP professional for a while now, and I love the fact that you can have multiple users logged on simultaneously, and just switch between them (it's so much handier when you have to share a PC with your partner). I recently also discovered remote desktop connection - so now I can connect to my home computer from work over the net! The only downside is that when I do this, my partner gets kicked off back to the login screen, if she is using the PC (which is not good for domestic bliss). Is there a way to allow a background user to be active at the same time as a local user?</b><br>
<br>
Congratulations - you've just hit on one of my pet XP gripes. Windows is certainly capable of doing what you describe above - having multiple users logged on and active - indeed, it has been for years, and you can do exactly this with the server editions of Windows (2000 server and 2003).<br>
<br>
For some reason though, Microsoft, in their wisdom, disable this functionality in XP, and even though you can have many users simultaneously logged on, only one can be "active" at any time, be they local, or remote.<br>
<br>
MS were set to finally enable this functionality with the latest XP service pack, but changed (lost?) their minds at the last minute, and so we still don't have it, officially.<br>
<br>
The good news is that the last beta release of SP2 had multi-user fully enabled, and so some enterprising hackers have put together a patch to enable the functionality and stick it to Willie Gates.<br>
<br>
Firstly, download the patch from http://tinyurl.com/8tljv, then unzip it to the folder of your choice (say, C:xppatch). Next, reboot into safe mode. You do this by holding  down F8 upon startup, then selecting the appropriate option.<br>
<br>
Once Windows starts, open up a command prompt (the easiest way is to press Windows-R, then type "cmd"), then change to the folder where you unzipped the patch (for our example above, type CD C:xppatch).<br>
<br>
Finally, run the batch file to install the patch by typing "mulTermInst.bat". Reboot, and enjoy the magic.<br>
<br>
If you ever need to uninstall the patch, there is another batch file for doing just that; just follow the procedure above and run the other batch file.<br>
<br>
As a final note, you should be aware that installing an unofficial beta patch like this could make your system unstable, leave it open to hackers, send you blind and generally cause Bad Stuff to happen. So caveat emptor, as usual.<br>
<br>
<br>
<h2>26/7/05</h2><br>
<b>I have just upgraded my OS to XP, and programs I install as the PC administrator seem to go where they want to. Consequently, programs (and shortcuts) that I want to share with other users aren't available to them, and likewise things I don't want to share are universally available. The XP help files don't provide any help in editing a user's access to programs on the PC. Is there a program that allows me to become an uber administrator?</b><br>
<br>
XP's security settings are pretty involved and can be quite baffling, and they can also leave a bit to be desired at times. Without going into it too much, here are a couple of bits of information that you might find helpful:<br>
<br>
1. Any user who is a member of the administrators group can access any file or program. New users are created as admins by default. That's as close to an uber user that you get with Windows.<br>
<br>
2. All user profiles are generally stored in Documents and Settings on your system drive. In here, each user has it's own Start Menu entries, which are basically a series of shortcuts. There is also a shared user area though - under Documents and SettingsAll Users - and any shortcuts put in here will appear to everyone.<br>
<br>
The finer points of XP security are ugly and uninteresting, and are also a bit beyond the scope of this column, but as usual your friend and mine, Google, will turn up some good primers and tutorials. Take small steps and you should be able to grok it eventually.<br>
<br>
2. My mouse won't allow me to use some programs properly. If I move the mouse in a program's main window, smaller windows integral to the program disappear. The best workaround I've found is to minimise the main window to a ridiculous size and move it out the way on the desktop. There must be some kind of setting but the XP help files (and Tweak UI) don't provide any help.<br>
<br>
Have another look in TweakUI under Mouse->X-Mouse, and make sure the autoraise option isn't selected (if you have X-mouse on). Sometimes this option can cause the issue you're having with older software.<br>
<br>
<br>
<b>More on Outlook Express Spell cheque</b><br>
<br>
Two weeks ago I foolishly asserted that there weren't any good spellchecking options for OE. A few people have written in with suggestions, including http://www.snapfiles.com/get/spelloe.html and http://www.geocities.com/vampirefo. I haven't tested either of these, but have it on good authority (i.e. from you, the readers!) that they're quite reliable.<br>
<br>
<i><p>Did the information on this page help you? Entertain you? Bore you? <a href="contact.php?subject=MasterIT">Drop me a line</a>.</p>

<p>If you're feeling particularly generous, you can even <a href="buypics.php">click here to send me some dot-com riches</a>. Think of it as online busking.</i></p>
	</div>
</div>
</body>
</html>