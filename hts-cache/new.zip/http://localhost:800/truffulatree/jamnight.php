<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - Jam Night - Image Gallery</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="Image Gallery">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="Pictures of my 28th Birthday party complete with Sparkler Bomb" href='28th.php'>28th Birthday</a></li>
<li><a title="Pictures of my 30th Birthday party" href='30th.php'>30th Birthday</a></li>
<li><a title="Michael Shamgar and Lindsay Halamek's 30th birthday bash photos" href='sl30th.php'>Shams & Linds' 30th</a></li>
<li><a title="Pictures of Andy Marinos's new flat, cat Toby, and Mum Pam Swain" href='andycatandflat.php'>Andy's Cat & Flat</a></li>
<li><a title="Pictures of a visit to Stephen Jackson's Farm" href='jackovisit.php'>Jacko's Farm</a></li>
<li><a title="Pictures taken at the Peace Convergence action in Rockhampton and Yeppoon in June 2005 to protest the joint US Australia military exercises (Operation Talisman Sabre)" href='peaceconvergence.php'>Peace Convergence</a></li>
<li><a title="Sydney trip - April '06" href='bridges.php'>Sydney, April 06</a></li>
<li><a title="Pics of Naima's 28th birthday dinner" href='mim28th.php'>Naima's 28th</a></li>
<li><a title="Brisbane CBD and the Story Bridge" href='brisbanepics1.php'>Brissie by Night 1</a></li>
<li><a title="Lamington National Park" href='lamington.php'>Lamington NP</a></li>
<li><a title="Various creatures and views from our Brisbane back yard" href='backyard.php'>Backyard Creatures</a></li>
<li><a title="Opening day of the Eleanor Schonell (Green) Bridge" href='greenbridge.php'>Green Bridge</a></li>
<li><a title="Pictutres from the 2006 Woodford Folk Festival" href='woodford0607.php'>Woodford 2006-2007</a></li>
<li><a title="One Cute Puppy" href='jezebel.php'>Jezebel</a></li>
<li><a title="Climbing at Kangaroo Point Cliffs" href='kangaroopt1.php'>Heather's Visit</a></li>
<li><a title="0x0021st (33rd) birthday celebrations" href='0x0021st.php'>0x0021st Birthday</a></li>
<li><a title="Nuptial photography" href='guyandalison.php'>Guy and Alison's Wedding</a></li>
<li><a title="Pictures from the 2007 Woodford Folk Festival" href='woodford0708.php'>Woodford 2007-2008</a></li>
<li><a title="Image gallery" href='sydneytrip0802.php'>Sydney & Yacaaba Head</a></li>
<li><a title="An impressive show by nature" href='lightning.php'>Thunderstorm Moonrise</a></li>
<li><a title="Frightening pictures of a shrinking beard" href='debearding.php'>De-bearding</a></li>
<li><a title="More Nuptial Photography" href='michaelandkaren.php'>Michael and Karen's Wedding</a></li>
<li><a title="A night of celebration" href='andrews21st.php'>Andrew's 21st</a></li>
<li><a title="Image Gallery" href='bloodyknee.php'>Bloody Knee</a></li>
<li><a title="Image Gallery" href='tyesbirthday.php'>Tye's Birthday</a></li>
<li><a title="Image Gallery" href='lasersocialising.php'>Laser Socialising</a></li>
<li><a title="Image Gallery" href='heatherandevan.php'>Heather and Evan's Wedding</a></li>
<li><a title="Image Gallery" href='woodford0809.php'>Woodford 2008-2009</a></li>
<li><a title="Image Gallery" href='allyandben.php'>Ally and Ben's Wedding</a></li>
<li><a title="Image Gallery" href='annes30th.php'>Anne's 30th</a></li>
<li><a title="Image Gallery" href='possumcreek.php'>Possum Creek</a></li>
<li><div class='activemenu'>Jam Night</div></li>
<li><a title="Image Gallery" href='cunninghamsgap.php'>Cunningham's Gap</a></li>
<li><a title="Image Gallery" href='bigcat.php'>Diving on Big Cat</a></li>
<li><a title="Images from my birthday jam" href='birthdayjam.php'>Music, mayhem and merriment</a></li>
<li><a title="Image Gallery" href='fuzzypolaroidpics.php'>Fuzzy Polaroid</a></li>
<li><a title="Image Gallery" href='zombiewalk2009.php'>2009 Zombie Walk</a></li>
<li> </li><br><li>Or go back to:</li><li><a title='Picture galleries' href="pictures.php">Photography</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>Jam Night</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Picture galleries' href="pictures.php">Photography</a> > <a title='Image Gallery' href="jamnight.php">Jam Night</a>
<br><br>		

<p>Lovely people, plenty of wine, a bit of music made for an excellent Saturday. Thanks all!</p>
<br><br>
All images in this gallery:<br>
<table width='800'>
<tr>
</tr>
<tr><td><A ID='IMG_5447.JPG' href='jamnight.php?fileId=IMG_5447.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20090516/IMG_5447.JPG' ALT='IMG_5447.JPG'><BR>IMG_5447.JPG<br>56.41 KB</a><div class='inv'><br><a href='./images/20090516/IMG_5447.JPG' ALT='IMG_5447.JPG'>IMG_5447.JPG</a></div></td>
<td><A ID='IMG_5448.JPG' href='jamnight.php?fileId=IMG_5448.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20090516/IMG_5448.JPG' ALT='IMG_5448.JPG'><BR>IMG_5448.JPG<br>57.03 KB</a><div class='inv'><br><a href='./images/20090516/IMG_5448.JPG' ALT='IMG_5448.JPG'>IMG_5448.JPG</a></div></td>
<td><A ID='IMG_5450.JPG' href='jamnight.php?fileId=IMG_5450.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20090516/IMG_5450.JPG' ALT='IMG_5450.JPG'><BR>IMG_5450.JPG<br>45.63 KB</a><div class='inv'><br><a href='./images/20090516/IMG_5450.JPG' ALT='IMG_5450.JPG'>IMG_5450.JPG</a></div></td>
<td><A ID='IMG_5452.JPG' href='jamnight.php?fileId=IMG_5452.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20090516/IMG_5452.JPG' ALT='IMG_5452.JPG'><BR>IMG_5452.JPG<br>43.68 KB</a><div class='inv'><br><a href='./images/20090516/IMG_5452.JPG' ALT='IMG_5452.JPG'>IMG_5452.JPG</a></div></td>
<td><A ID='IMG_5459.JPG' href='jamnight.php?fileId=IMG_5459.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20090516/IMG_5459.JPG' ALT='IMG_5459.JPG'><BR>IMG_5459.JPG<br>52.93 KB</a><div class='inv'><br><a href='./images/20090516/IMG_5459.JPG' ALT='IMG_5459.JPG'>IMG_5459.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5462.JPG' href='jamnight.php?fileId=IMG_5462.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20090516/IMG_5462.JPG' ALT='IMG_5462.JPG'><BR>IMG_5462.JPG<br>71.33 KB</a><div class='inv'><br><a href='./images/20090516/IMG_5462.JPG' ALT='IMG_5462.JPG'>IMG_5462.JPG</a></div></td>
<td><A ID='IMG_5467.JPG' href='jamnight.php?fileId=IMG_5467.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20090516/IMG_5467.JPG' ALT='IMG_5467.JPG'><BR>IMG_5467.JPG<br>69.01 KB</a><div class='inv'><br><a href='./images/20090516/IMG_5467.JPG' ALT='IMG_5467.JPG'>IMG_5467.JPG</a></div></td>
<td><A ID='IMG_5469.JPG' href='jamnight.php?fileId=IMG_5469.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20090516/IMG_5469.JPG' ALT='IMG_5469.JPG'><BR>IMG_5469.JPG<br>58.55 KB</a><div class='inv'><br><a href='./images/20090516/IMG_5469.JPG' ALT='IMG_5469.JPG'>IMG_5469.JPG</a></div></td>
<td><A ID='IMG_5473.JPG' href='jamnight.php?fileId=IMG_5473.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20090516/IMG_5473.JPG' ALT='IMG_5473.JPG'><BR>IMG_5473.JPG<br>51.05 KB</a><div class='inv'><br><a href='./images/20090516/IMG_5473.JPG' ALT='IMG_5473.JPG'>IMG_5473.JPG</a></div></td>
<td><A ID='IMG_5474.JPG' href='jamnight.php?fileId=IMG_5474.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20090516/IMG_5474.JPG' ALT='IMG_5474.JPG'><BR>IMG_5474.JPG<br>66.53 KB</a><div class='inv'><br><a href='./images/20090516/IMG_5474.JPG' ALT='IMG_5474.JPG'>IMG_5474.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5475.JPG' href='jamnight.php?fileId=IMG_5475.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20090516/IMG_5475.JPG' ALT='IMG_5475.JPG'><BR>IMG_5475.JPG<br>67.52 KB</a><div class='inv'><br><a href='./images/20090516/IMG_5475.JPG' ALT='IMG_5475.JPG'>IMG_5475.JPG</a></div></td>
<td><A ID='IMG_5476.JPG' href='jamnight.php?fileId=IMG_5476.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20090516/IMG_5476.JPG' ALT='IMG_5476.JPG'><BR>IMG_5476.JPG<br>55.6 KB</a><div class='inv'><br><a href='./images/20090516/IMG_5476.JPG' ALT='IMG_5476.JPG'>IMG_5476.JPG</a></div></td>
<td><A ID='IMG_5480.JPG' href='jamnight.php?fileId=IMG_5480.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20090516/IMG_5480.JPG' ALT='IMG_5480.JPG'><BR>IMG_5480.JPG<br>49.46 KB</a><div class='inv'><br><a href='./images/20090516/IMG_5480.JPG' ALT='IMG_5480.JPG'>IMG_5480.JPG</a></div></td>
<td><A ID='IMG_5482.JPG' href='jamnight.php?fileId=IMG_5482.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20090516/IMG_5482.JPG' ALT='IMG_5482.JPG'><BR>IMG_5482.JPG<br>35.87 KB</a><div class='inv'><br><a href='./images/20090516/IMG_5482.JPG' ALT='IMG_5482.JPG'>IMG_5482.JPG</a></div></td>
<td><A ID='IMG_5485.JPG' href='jamnight.php?fileId=IMG_5485.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20090516/IMG_5485.JPG' ALT='IMG_5485.JPG'><BR>IMG_5485.JPG<br>56.07 KB</a><div class='inv'><br><a href='./images/20090516/IMG_5485.JPG' ALT='IMG_5485.JPG'>IMG_5485.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5490.JPG' href='jamnight.php?fileId=IMG_5490.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20090516/IMG_5490.JPG' ALT='IMG_5490.JPG'><BR>IMG_5490.JPG<br>56.66 KB</a><div class='inv'><br><a href='./images/20090516/IMG_5490.JPG' ALT='IMG_5490.JPG'>IMG_5490.JPG</a></div></td>
<td><A ID='IMG_5498.JPG' href='jamnight.php?fileId=IMG_5498.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20090516/IMG_5498.JPG' ALT='IMG_5498.JPG'><BR>IMG_5498.JPG<br>50.66 KB</a><div class='inv'><br><a href='./images/20090516/IMG_5498.JPG' ALT='IMG_5498.JPG'>IMG_5498.JPG</a></div></td>
<td><A ID='IMG_5501.JPG' href='jamnight.php?fileId=IMG_5501.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20090516/IMG_5501.JPG' ALT='IMG_5501.JPG'><BR>IMG_5501.JPG<br>40.07 KB</a><div class='inv'><br><a href='./images/20090516/IMG_5501.JPG' ALT='IMG_5501.JPG'>IMG_5501.JPG</a></div></td>
<td><A ID='IMG_5502.JPG' href='jamnight.php?fileId=IMG_5502.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20090516/IMG_5502.JPG' ALT='IMG_5502.JPG'><BR>IMG_5502.JPG<br>47.39 KB</a><div class='inv'><br><a href='./images/20090516/IMG_5502.JPG' ALT='IMG_5502.JPG'>IMG_5502.JPG</a></div></td>
<td><A ID='IMG_5503.JPG' href='jamnight.php?fileId=IMG_5503.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20090516/IMG_5503.JPG' ALT='IMG_5503.JPG'><BR>IMG_5503.JPG<br>60.6 KB</a><div class='inv'><br><a href='./images/20090516/IMG_5503.JPG' ALT='IMG_5503.JPG'>IMG_5503.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_8784.JPG' href='jamnight.php?fileId=IMG_8784.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20090516/IMG_8784.JPG' ALT='IMG_8784.JPG'><BR>IMG_8784.JPG<br>44.43 KB</a><div class='inv'><br><a href='./images/20090516/IMG_8784.JPG' ALT='IMG_8784.JPG'>IMG_8784.JPG</a></div></td>
<td><A ID='IMG_8786.JPG' href='jamnight.php?fileId=IMG_8786.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20090516/IMG_8786.JPG' ALT='IMG_8786.JPG'><BR>IMG_8786.JPG<br>43.92 KB</a><div class='inv'><br><a href='./images/20090516/IMG_8786.JPG' ALT='IMG_8786.JPG'>IMG_8786.JPG</a></div></td>
<td><A ID='IMG_8787.JPG' href='jamnight.php?fileId=IMG_8787.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20090516/IMG_8787.JPG' ALT='IMG_8787.JPG'><BR>IMG_8787.JPG<br>38.89 KB</a><div class='inv'><br><a href='./images/20090516/IMG_8787.JPG' ALT='IMG_8787.JPG'>IMG_8787.JPG</a></div></td>
<td><A ID='IMG_8793.JPG' href='jamnight.php?fileId=IMG_8793.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20090516/IMG_8793.JPG' ALT='IMG_8793.JPG'><BR>IMG_8793.JPG<br>52.2 KB</a><div class='inv'><br><a href='./images/20090516/IMG_8793.JPG' ALT='IMG_8793.JPG'>IMG_8793.JPG</a></div></td>
<td><A ID='IMG_8796.JPG' href='jamnight.php?fileId=IMG_8796.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20090516/IMG_8796.JPG' ALT='IMG_8796.JPG'><BR>IMG_8796.JPG<br>50.38 KB</a><div class='inv'><br><a href='./images/20090516/IMG_8796.JPG' ALT='IMG_8796.JPG'>IMG_8796.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_8798.JPG' href='jamnight.php?fileId=IMG_8798.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20090516/IMG_8798.JPG' ALT='IMG_8798.JPG'><BR>IMG_8798.JPG<br>41.62 KB</a><div class='inv'><br><a href='./images/20090516/IMG_8798.JPG' ALT='IMG_8798.JPG'>IMG_8798.JPG</a></div></td>
<td><A ID='IMG_8799.JPG' href='jamnight.php?fileId=IMG_8799.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20090516/IMG_8799.JPG' ALT='IMG_8799.JPG'><BR>IMG_8799.JPG<br>70.52 KB</a><div class='inv'><br><a href='./images/20090516/IMG_8799.JPG' ALT='IMG_8799.JPG'>IMG_8799.JPG</a></div></td>
<td><A ID='IMG_8800.JPG' href='jamnight.php?fileId=IMG_8800.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20090516/IMG_8800.JPG' ALT='IMG_8800.JPG'><BR>IMG_8800.JPG<br>47.44 KB</a><div class='inv'><br><a href='./images/20090516/IMG_8800.JPG' ALT='IMG_8800.JPG'>IMG_8800.JPG</a></div></td>
<td><A ID='IMG_8804.JPG' href='jamnight.php?fileId=IMG_8804.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20090516/IMG_8804.JPG' ALT='IMG_8804.JPG'><BR>IMG_8804.JPG<br>38.96 KB</a><div class='inv'><br><a href='./images/20090516/IMG_8804.JPG' ALT='IMG_8804.JPG'>IMG_8804.JPG</a></div></td>
<td><A ID='IMG_8808.JPG' href='jamnight.php?fileId=IMG_8808.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20090516/IMG_8808.JPG' ALT='IMG_8808.JPG'><BR>IMG_8808.JPG<br>55.71 KB</a><div class='inv'><br><a href='./images/20090516/IMG_8808.JPG' ALT='IMG_8808.JPG'>IMG_8808.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_8810.JPG' href='jamnight.php?fileId=IMG_8810.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20090516/IMG_8810.JPG' ALT='IMG_8810.JPG'><BR>IMG_8810.JPG<br>33.38 KB</a><div class='inv'><br><a href='./images/20090516/IMG_8810.JPG' ALT='IMG_8810.JPG'>IMG_8810.JPG</a></div></td>
<td><A ID='IMG_8811.JPG' href='jamnight.php?fileId=IMG_8811.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20090516/IMG_8811.JPG' ALT='IMG_8811.JPG'><BR>IMG_8811.JPG<br>50.11 KB</a><div class='inv'><br><a href='./images/20090516/IMG_8811.JPG' ALT='IMG_8811.JPG'>IMG_8811.JPG</a></div></td>
<td><A ID='IMG_8812.JPG' href='jamnight.php?fileId=IMG_8812.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20090516/IMG_8812.JPG' ALT='IMG_8812.JPG'><BR>IMG_8812.JPG<br>57.91 KB</a><div class='inv'><br><a href='./images/20090516/IMG_8812.JPG' ALT='IMG_8812.JPG'>IMG_8812.JPG</a></div></td>
<td><A ID='IMG_8816.JPG' href='jamnight.php?fileId=IMG_8816.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20090516/IMG_8816.JPG' ALT='IMG_8816.JPG'><BR>IMG_8816.JPG<br>54.06 KB</a><div class='inv'><br><a href='./images/20090516/IMG_8816.JPG' ALT='IMG_8816.JPG'>IMG_8816.JPG</a></div></td>
<td><A ID='IMG_8818.JPG' href='jamnight.php?fileId=IMG_8818.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20090516/IMG_8818.JPG' ALT='IMG_8818.JPG'><BR>IMG_8818.JPG<br>37.59 KB</a><div class='inv'><br><a href='./images/20090516/IMG_8818.JPG' ALT='IMG_8818.JPG'>IMG_8818.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_8819.JPG' href='jamnight.php?fileId=IMG_8819.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20090516/IMG_8819.JPG' ALT='IMG_8819.JPG'><BR>IMG_8819.JPG<br>31.93 KB</a><div class='inv'><br><a href='./images/20090516/IMG_8819.JPG' ALT='IMG_8819.JPG'>IMG_8819.JPG</a></div></td>
<td><A ID='IMG_8824.JPG' href='jamnight.php?fileId=IMG_8824.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20090516/IMG_8824.JPG' ALT='IMG_8824.JPG'><BR>IMG_8824.JPG<br>58.51 KB</a><div class='inv'><br><a href='./images/20090516/IMG_8824.JPG' ALT='IMG_8824.JPG'>IMG_8824.JPG</a></div></td>
<td><A ID='IMG_8831.JPG' href='jamnight.php?fileId=IMG_8831.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20090516/IMG_8831.JPG' ALT='IMG_8831.JPG'><BR>IMG_8831.JPG<br>44.47 KB</a><div class='inv'><br><a href='./images/20090516/IMG_8831.JPG' ALT='IMG_8831.JPG'>IMG_8831.JPG</a></div></td>
<td><A ID='IMG_8834.JPG' href='jamnight.php?fileId=IMG_8834.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20090516/IMG_8834.JPG' ALT='IMG_8834.JPG'><BR>IMG_8834.JPG<br>45.09 KB</a><div class='inv'><br><a href='./images/20090516/IMG_8834.JPG' ALT='IMG_8834.JPG'>IMG_8834.JPG</a></div></td>
<td><A ID='IMG_8835.JPG' href='jamnight.php?fileId=IMG_8835.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20090516/IMG_8835.JPG' ALT='IMG_8835.JPG'><BR>IMG_8835.JPG<br>54.6 KB</a><div class='inv'><br><a href='./images/20090516/IMG_8835.JPG' ALT='IMG_8835.JPG'>IMG_8835.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_8844.JPG' href='jamnight.php?fileId=IMG_8844.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20090516/IMG_8844.JPG' ALT='IMG_8844.JPG'><BR>IMG_8844.JPG<br>46.41 KB</a><div class='inv'><br><a href='./images/20090516/IMG_8844.JPG' ALT='IMG_8844.JPG'>IMG_8844.JPG</a></div></td>
<td><A ID='IMG_8845.JPG' href='jamnight.php?fileId=IMG_8845.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20090516/IMG_8845.JPG' ALT='IMG_8845.JPG'><BR>IMG_8845.JPG<br>70.93 KB</a><div class='inv'><br><a href='./images/20090516/IMG_8845.JPG' ALT='IMG_8845.JPG'>IMG_8845.JPG</a></div></td>
<td><A ID='IMG_8854.JPG' href='jamnight.php?fileId=IMG_8854.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20090516/IMG_8854.JPG' ALT='IMG_8854.JPG'><BR>IMG_8854.JPG<br>29.48 KB</a><div class='inv'><br><a href='./images/20090516/IMG_8854.JPG' ALT='IMG_8854.JPG'>IMG_8854.JPG</a></div></td>
</tr>
</table>	</div>
</div>
</body>
</html>