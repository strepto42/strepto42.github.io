<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - 1/1/2006 - Tassie - Part 1</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="Tassie - Part 1">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="Greetings from a Bum" href='greetingsfromabum.php'>29/4/2005</a></li>
<li><a title="Onward" href='onward.php'>2/5/2005</a></li>
<li><a title="It's a tough life (pt 1: Bundaberg, Agnes Water and 1770)" href='itsatoughlife1.php'>17/5/2005</a></li>
<li><a title="It's a tough life (pt 2: Rockhampton, Emu Park and Great Keppel Island)" href='itsatoughlife2.php'>23/5/2005</a></li>
<li><a title="There and Back Again - a Yo-yo's Tale" href='thereandbackagain.php'>18/6/2005</a></li>
<li><a title="Platypi and Grey Nomads" href='platypiandgreynomads.php'>24/6/2005</a></li>
<li><a title="Blowing Bubbles in a Watery Tomb" href='blowingbubbles.php'>1/7/2005</a></li>
<li><a title="Pieces of History" href='piecesofhistory.php'>8/7/2005</a></li>
<li><a title="Walks and Waterfalls" href='walksandwaterfalls.php'>15/7/2005</a></li>
<li><a title="Mission to Tribulation" href='missiontotribulation.php'>22/7/2005</a></li>
<li><a title="Levity, Limestone and Lava" href='levitylimestoneandlava.php'>29/7/2005</a></li>
<li><a title="Into the Never Never" href='intothenevernever.php'>5/8/2005</a></li>
<li><a title="Slowing the pace in Darwin" href='slowingthepaceindarwin.php'>12/8/2005</a></li>
<li><a title="Blistering Barnacles and Leaping Lizards" href='leapinglizards.php'>19/8/2005</a></li>
<li><a title="Kakadu and Litchfield" href='kakadu.php'>26/8/2005</a></li>
<li><a title="Legacies of War" href='legaciesofwar.php'>2/9/2005</a></li>
<li><a title="Go West" href='gowest.php'>10/9/2005</a></li>
<li><a title="Things from Above" href='thingsfromabove.php'>16/9/2005</a></li>
<li><a title="The West Coast" href='thewestcoast.php'>23/9/2005</a></li>
<li><a title="Reefs and Red Dust" href='reefsandreddust.php'>30/9/2005</a></li>
<li><a title="The Pilbara" href='pilbara.php'>7/10/2005</a></li>
<li><a title="Paradise with a Headwind" href='paradisewithaheadwind.php'>14/10/2005</a></li>
<li><a title="Down the Coral Coast" href='downthecoralcoast.php'>21/10/2005</a></li>
<li><a title="Pinnacles and Pinnipeds" href='pinnaclesandpinnipeds.php'>28/10/2005</a></li>
<li><a title="A week in Perth" href='perth.php'>4/11/2005</a></li>
<li><a title="The Southwest (from Above and Below)" href='thesouthwest.php'>11/11/2005</a></li>
<li><a title="More Heights and Depths" href='moreheightsanddepths.php'>18/11/2005</a></li>
<li><a title="Across the Nullarbor (and a bit beyond)" href='nullarbor.php'>25/11/2005</a></li>
<li><a title="Double Whammy" href='doublewhammy.php'>9/12/2005</a></li>
<li><a title="Two Cities" href='twocities.php'>19/12/2005</a></li>
<li><div class='activemenu'>1/1/2006</div></li>
<li><a title="Tassie - Part 2" href='tassie2.php'>7/1/2006</a></li>
<li><a title="Full Circle" href='fullcircle.php'>26/1/2006</a></li>
<li><a title="The Wrap Up" href='thewrapup.php'>23/3/2006</a></li>
<li> </li><br><li>Or go back to:</li><li><a title='Travelouges and blogs from my trip around Australia' href="nerdseyeview.php">Nerd's Eye View</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>1/1/2006</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Travel stories and pictures' href="travel.php">Travelogues</a> > <a title='Travelouges and blogs from my trip around Australia' href="nerdseyeview.php">Nerd's Eye View</a> > <a title='Tassie - Part 1' href="tassie1.php">1/1/2006</a>
<br><br>		


<h1>Tassie - Part 1</h1>

<a href="images/maps/Map060101.gif"><img src="images/maps/Map060101_sm.gif" align="right"></a>

<p>Hi all. It seems like it's time I wrote again.</p>

<p>We're about half way through Tassie. Xmas has been and gone (as I'm sure everyone noticed). It's also a new year, so I suppose it's as appropriate a time as any! :)</p>

<p>So, stepping back two weeks, Devonport, where the last email was sent from, didn't have much to offer, so we moved on fairly quickly.</p>

<p>Before that, we attempted to book the boat back to Sydney, and found out that (of course) at this time of year they recommend you book a long time in advance to get your preferred seats. Like, a year in advance. Securing preferred seats though, wasn't an issue so much as securing ANY. In the end, we've had to book a boat back to Melbourne, and from there we'll drive to Sydney. No sailing through the Heads will take place, alas.</p>

<p>After that little fizzer of a start, we drove west, along the top bit of the coastline, through various towns, of various sizes. Our first detour inland was to Leven Canyon, and it was a nice intro to the Tasmanian rainforest. Indeed, it rained, as it has done quite a lot, but in a way it's been quite appropriate.</p>

<p>We wandered through the forest on a couple of short walks, and Jana started ticking off some endemic Tassie birds.</p>

<p>After moving along back to the coast, we passed through the cute town of Penguin (where the statue of the town's namesake was dressed in a Santa outfit) to Burnie, a fairly ugly place where you can see huge piles of woodchips on the docks ready for export.</p>

<p>Then we continued west, through Somerset and Wynyard, where there were fields of poppies (with signs warning of DEATH should you accidentally fall over the fence and become a heroin addict) and a lookout over the sea.</p>

<p>Next up was Rocky Cape National Park, where we stopped at a lovely looking (albeit cold) beach for lunch, and then the town of Stanley, where there is a steep-sided, circular headland, called The Nut, overlooking the sea. There's a chairlift up, but we elected to be cheapskates (an all too often occurrence these days), and walked up. It turned out that this was the same chairlift that Jana's younger brother had fallen off years ago on a family visit (although she hadn't actually been there at the time). Eamon was fine, so it's safe for me to embarrass him.</p>

<p>The Nut was quite an interesting spot, and the near gale-force winds at times on top made exploring it quite an experience. Before heading out of town we also checked a beautifully restored old homestead overlooking the area.</p>

<p>This was as far as we pushed west. There are a few spots further on, but there wasn't any particular incentive to visit them, so we backtracked slightly and headed inland to Cradle Mountain National Park.</p>

<p>Tassie is full of spectacular walks, one of which is the famous Overland Track, which winds from Cradle Mountain to Lake St Clair. This is a four day walk, and so a little out of our league equipment-wise, but we explored the start, which winds around Dove Lake, and has views of the famous mountain. We got lucky with the weather, and whilst it was pretty crisp, the sun was out for most of the walk. After walking round the lake we checked out the replica of Gustav Weindorfer's Chalet (he was instrumental in having Cradle Mountain set aside as a national park). We also spotted a wombat on the way.</p>

<p>That night we made it as far as Waratah, a pretty average looking little town with a nice waterfall, and camped there in the council caravan park. The next day we continued west to Corinna, another hamlet tucked away in the forest. There's a barge to cross the river there (with a fairly amusing sign), as well as a walk by the river in the forest.</p>

<p>After making the crossing we switched back east to Tullah, via a few dams and more wild scenery. I should take a moment to comment on the scenery actually. So far, much of Tasmania, especially the northwest, has been a strange mixture of fantastic beauty and complete ugliness. So much of the place has been logged, ravaged by wildfires, flooded (on an enormous scale), and generally degraded by humans that often, it's really quite foul. There seems to be a bizarre approach to clearing land here too; piles of debris from the former forest line the sides of the road and lookouts.</p>
 
<p>Tassie is of course not without incredible beauty - it's just such a strange and unbecoming contrast at times.</p>

<p>Getting back to the narrative though, our next stop after Tullah was Montezuma falls, which one can cycle most of the way to, as the track follows an old tram line through the forest. At 104 metres tall, the falls were quite spectacular, and the rain and mud only served to make the ride there and back all the more fun.</p>

<p>The town of Zeehan was our next overnight stay, and from there we pushed on to Strahan, one of the more famous tourist towns of the area. On the way we stopped off at the amazing 30m high Henty sand dunes, and checked out the wild looking west coast in the distance.</p>

<p>In Strahan there is a fantastic restored railway that runs from there to Queenstown, using a special system (called Abt) to climb the steep grades. Unfortunately at $97 per person one way it was a little out of our league. We seem to continuously find that everything in Tassie is just a little bit unreasonably expensive. Such is life.</p>

<p>Before leaving Strahan we took another short stroll through forest to Hogarth Falls. It was basically more greenery, moist and cool. The temperate rainforest here is quite different to that of the mainland; often there is a carpet of moss over everything, and interesting fungi abound.</p>

<p>Next we drove to Queenstown, a surreal place indeed. Mining practices from the 1800s onwards have resulted in half the countryside being completely stuffed by sulphuric acid and other toxins, and the hills are still bare, despite not having been mined for the last 70 years or so. Just out of town, on the sign showing "Queenstown - 3kms" and so on, someone has spray-painted "Mordor". Quite fitting, really.</p>

<p>It's also amusing, as we therefore spent Christmas in Mordor. It was a pretty low-key affair, but highly enjoyable. Basically, we rented some DVDs and watched them on my laptop, with wine and chocolate. The weather was cold and miserable (it even *hailed* 6 times on xmas eve), and therefore highly appropriate for snug indoor activities.</p>

<p>After that little stopover we made our way to Derwent, and Lake St Clair, the other end of the Overland Track. Along the way we passed through some lovely scenery, including the famous (and beautiful) Franklin River, and Donaghy's lookout.</p>

<p>After an overnight stay in the rain at Lake St Clair, we departed, and headed south via the "green" yet ugly Tarrahleah Power station to Mt Field National Park, the site of Tassie's winter snowfields.</p>

<p>Of course there isn't any snow there now, but the top of the mountain (well, as far as you can drive) was certainly pretty chilly. We drove up and back, and went on various walks, including the Tall Trees Walk, which takes you past some amazing examples of ancient <em>Eucalyptus regnans</em> (or Swamp Gums) - the tallest flowering plants in the world. Cleverly, we skipped a waterfall, as hey, one is much like another, and we'd seen a few. Turns out we unwittingly skipped Nelson Falls, one of the more famous Tassie landmarks. Oh well. :)</p>

<p>Next up we visited the Styx River, including the Valley of the Giants. This spot has been the site of ongoing conservation action for a while, and whilst some small victories have been won, it's still mostly forestry land, with a small reserve around a handful of ancient trees. It's the usual Tassie story - incredibly beautiful forest surrounded by devastation. Forestry Tasmania somehow manages to retain - and even tries to justify with various propaganda - its love of clearfelling as a "modern silvicultural technique", and replanting with single species. In this day and age one wonders how on earth they can be that short-sighted. </p>

<p>So, whilst wonderful, it was also a little depressing to visit some of the tallest trees in the world.</p>

<p>Then we headed south, via New Norfolk and Hobart to Dover. We spent the next couple of days touring the area, and made it as far south as Southport (in fact, this is as far south as I'll ever get on my trip). We also checked out Hastings and Snug (a cutely named town where Jana lived when she was 2), as well as visited Avre Falls in the Hartz Mountains National Park, another gorgeous alpine area surrounded by forestry devastation.</p>

<p>We had a vague plan to spend New Year's Eve in Hobart, but it turned out that it was next to impossible to find budget accommodation in town, so we wound up making our way to a town called Triabunna on the east coast, and a small hostel called the Udda Backpackers. The area here is quite green and rural, and is quite pretty in contrast to the populated parts of the northwest.</p>

<p>NYE was a very low-key affair, yet it was quite enjoyable, relaxing with a couple of other folks in front of the fire with a few brews.</p>

<p>And that brings us to the new year - happy 2006 everyone! Nothing like a bit of terminal eyestrain to start off the new year hey...</p>

<p>I hope everyone is well, and cheers to all the message senders and so on. I'll see many of you soon!</p>

<p>In the meantime, the usual picture selections, from this round's extensive green gallery! </p>

<table width="800">
	<tr>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=IMG_4712.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_4712.JPG' ALT='At least if they put you in the stocks you had a nice view of The Nut'><BR>At least if they put you in the stocks you had a nice view of The Nut</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=IMG_4819.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_4819.JPG' ALT='The old boat shed at Cradle Mountain'><BR>The old boat shed at Cradle Mountain</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=IMG_5464.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5464.JPG' ALT='Styx Valley giants'><BR>Styx Valley giants</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=IMG_5473.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5473.JPG' ALT='An ancient Styx tree fern'><BR>An ancient Styx tree fern</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=IMG_5452.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5452.JPG' ALT='Meanwhile, next door'><BR>Meanwhile, next door</a>
	</td>
	</tr>
</table>

<br><br>
All images in this gallery:<br>
<table width='800'>
<tr>
</tr>
<tr><td><A ID='IMG_4588.JPG' href='tassie1.php?fileId=IMG_4588.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_4588.JPG' ALT='IMG_4588.JPG'><BR>IMG_4588.JPG<br>61.79 KB</a><div class='inv'><br><a href='./images/20060101/IMG_4588.JPG' ALT='IMG_4588.JPG'>IMG_4588.JPG</a></div></td>
<td><A ID='IMG_4590.JPG' href='tassie1.php?fileId=IMG_4590.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_4590.JPG' ALT='IMG_4590.JPG'><BR>IMG_4590.JPG<br>89.65 KB</a><div class='inv'><br><a href='./images/20060101/IMG_4590.JPG' ALT='IMG_4590.JPG'>IMG_4590.JPG</a></div></td>
<td><A ID='IMG_4593.JPG' href='tassie1.php?fileId=IMG_4593.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_4593.JPG' ALT='IMG_4593.JPG'><BR>IMG_4593.JPG<br>60.45 KB</a><div class='inv'><br><a href='./images/20060101/IMG_4593.JPG' ALT='IMG_4593.JPG'>IMG_4593.JPG</a></div></td>
<td><A ID='IMG_4596.JPG' href='tassie1.php?fileId=IMG_4596.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_4596.JPG' ALT='IMG_4596.JPG'><BR>IMG_4596.JPG<br>74.97 KB</a><div class='inv'><br><a href='./images/20060101/IMG_4596.JPG' ALT='IMG_4596.JPG'>IMG_4596.JPG</a></div></td>
<td><A ID='IMG_4607.JPG' href='tassie1.php?fileId=IMG_4607.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_4607.JPG' ALT='IMG_4607.JPG'><BR>IMG_4607.JPG<br>43.6 KB</a><div class='inv'><br><a href='./images/20060101/IMG_4607.JPG' ALT='IMG_4607.JPG'>IMG_4607.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_4616.JPG' href='tassie1.php?fileId=IMG_4616.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_4616.JPG' ALT='IMG_4616.JPG'><BR>IMG_4616.JPG<br>32.75 KB</a><div class='inv'><br><a href='./images/20060101/IMG_4616.JPG' ALT='IMG_4616.JPG'>IMG_4616.JPG</a></div></td>
<td><A ID='IMG_4634.JPG' href='tassie1.php?fileId=IMG_4634.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_4634.JPG' ALT='IMG_4634.JPG'><BR>IMG_4634.JPG<br>66.99 KB</a><div class='inv'><br><a href='./images/20060101/IMG_4634.JPG' ALT='IMG_4634.JPG'>IMG_4634.JPG</a></div></td>
<td><A ID='IMG_4641.JPG' href='tassie1.php?fileId=IMG_4641.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_4641.JPG' ALT='IMG_4641.JPG'><BR>IMG_4641.JPG<br>108.75 KB</a><div class='inv'><br><a href='./images/20060101/IMG_4641.JPG' ALT='IMG_4641.JPG'>IMG_4641.JPG</a></div></td>
<td><A ID='IMG_4642.JPG' href='tassie1.php?fileId=IMG_4642.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_4642.JPG' ALT='IMG_4642.JPG'><BR>IMG_4642.JPG<br>65.18 KB</a><div class='inv'><br><a href='./images/20060101/IMG_4642.JPG' ALT='IMG_4642.JPG'>IMG_4642.JPG</a></div></td>
<td><A ID='IMG_4654.JPG' href='tassie1.php?fileId=IMG_4654.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_4654.JPG' ALT='IMG_4654.JPG'><BR>IMG_4654.JPG<br>83.59 KB</a><div class='inv'><br><a href='./images/20060101/IMG_4654.JPG' ALT='IMG_4654.JPG'>IMG_4654.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_4661.JPG' href='tassie1.php?fileId=IMG_4661.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_4661.JPG' ALT='IMG_4661.JPG'><BR>IMG_4661.JPG<br>58.75 KB</a><div class='inv'><br><a href='./images/20060101/IMG_4661.JPG' ALT='IMG_4661.JPG'>IMG_4661.JPG</a></div></td>
<td><A ID='IMG_4670.JPG' href='tassie1.php?fileId=IMG_4670.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_4670.JPG' ALT='IMG_4670.JPG'><BR>IMG_4670.JPG<br>65.41 KB</a><div class='inv'><br><a href='./images/20060101/IMG_4670.JPG' ALT='IMG_4670.JPG'>IMG_4670.JPG</a></div></td>
<td><A ID='IMG_4671.JPG' href='tassie1.php?fileId=IMG_4671.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_4671.JPG' ALT='IMG_4671.JPG'><BR>IMG_4671.JPG<br>110.28 KB</a><div class='inv'><br><a href='./images/20060101/IMG_4671.JPG' ALT='IMG_4671.JPG'>IMG_4671.JPG</a></div></td>
<td><A ID='IMG_4677.JPG' href='tassie1.php?fileId=IMG_4677.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_4677.JPG' ALT='IMG_4677.JPG'><BR>IMG_4677.JPG<br>117.12 KB</a><div class='inv'><br><a href='./images/20060101/IMG_4677.JPG' ALT='IMG_4677.JPG'>IMG_4677.JPG</a></div></td>
<td><A ID='IMG_4684.JPG' href='tassie1.php?fileId=IMG_4684.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_4684.JPG' ALT='IMG_4684.JPG'><BR>IMG_4684.JPG<br>64.83 KB</a><div class='inv'><br><a href='./images/20060101/IMG_4684.JPG' ALT='IMG_4684.JPG'>IMG_4684.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_4691.JPG' href='tassie1.php?fileId=IMG_4691.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_4691.JPG' ALT='IMG_4691.JPG'><BR>IMG_4691.JPG<br>66.98 KB</a><div class='inv'><br><a href='./images/20060101/IMG_4691.JPG' ALT='IMG_4691.JPG'>IMG_4691.JPG</a></div></td>
<td><A ID='IMG_4696.JPG' href='tassie1.php?fileId=IMG_4696.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_4696.JPG' ALT='IMG_4696.JPG'><BR>IMG_4696.JPG<br>52.97 KB</a><div class='inv'><br><a href='./images/20060101/IMG_4696.JPG' ALT='IMG_4696.JPG'>IMG_4696.JPG</a></div></td>
<td><A ID='IMG_4706.JPG' href='tassie1.php?fileId=IMG_4706.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_4706.JPG' ALT='IMG_4706.JPG'><BR>IMG_4706.JPG<br>92.73 KB</a><div class='inv'><br><a href='./images/20060101/IMG_4706.JPG' ALT='IMG_4706.JPG'>IMG_4706.JPG</a></div></td>
<td><A ID='IMG_4710.JPG' href='tassie1.php?fileId=IMG_4710.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_4710.JPG' ALT='IMG_4710.JPG'><BR>IMG_4710.JPG<br>78.26 KB</a><div class='inv'><br><a href='./images/20060101/IMG_4710.JPG' ALT='IMG_4710.JPG'>IMG_4710.JPG</a></div></td>
<td><A ID='IMG_4711.JPG' href='tassie1.php?fileId=IMG_4711.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_4711.JPG' ALT='IMG_4711.JPG'><BR>IMG_4711.JPG<br>75.18 KB</a><div class='inv'><br><a href='./images/20060101/IMG_4711.JPG' ALT='IMG_4711.JPG'>IMG_4711.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_4712.JPG' href='tassie1.php?fileId=IMG_4712.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_4712.JPG' ALT='IMG_4712.JPG'><BR>IMG_4712.JPG<br>57.85 KB</a><div class='inv'><br><a href='./images/20060101/IMG_4712.JPG' ALT='IMG_4712.JPG'>IMG_4712.JPG</a></div></td>
<td><A ID='IMG_4713.JPG' href='tassie1.php?fileId=IMG_4713.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_4713.JPG' ALT='IMG_4713.JPG'><BR>IMG_4713.JPG<br>84.02 KB</a><div class='inv'><br><a href='./images/20060101/IMG_4713.JPG' ALT='IMG_4713.JPG'>IMG_4713.JPG</a></div></td>
<td><A ID='IMG_4716.JPG' href='tassie1.php?fileId=IMG_4716.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_4716.JPG' ALT='IMG_4716.JPG'><BR>IMG_4716.JPG<br>42.17 KB</a><div class='inv'><br><a href='./images/20060101/IMG_4716.JPG' ALT='IMG_4716.JPG'>IMG_4716.JPG</a></div></td>
<td><A ID='IMG_4727.JPG' href='tassie1.php?fileId=IMG_4727.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_4727.JPG' ALT='IMG_4727.JPG'><BR>IMG_4727.JPG<br>63.21 KB</a><div class='inv'><br><a href='./images/20060101/IMG_4727.JPG' ALT='IMG_4727.JPG'>IMG_4727.JPG</a></div></td>
<td><A ID='IMG_4728.JPG' href='tassie1.php?fileId=IMG_4728.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_4728.JPG' ALT='IMG_4728.JPG'><BR>IMG_4728.JPG<br>82.86 KB</a><div class='inv'><br><a href='./images/20060101/IMG_4728.JPG' ALT='IMG_4728.JPG'>IMG_4728.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_4740.JPG' href='tassie1.php?fileId=IMG_4740.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_4740.JPG' ALT='IMG_4740.JPG'><BR>IMG_4740.JPG<br>63.26 KB</a><div class='inv'><br><a href='./images/20060101/IMG_4740.JPG' ALT='IMG_4740.JPG'>IMG_4740.JPG</a></div></td>
<td><A ID='IMG_4743.JPG' href='tassie1.php?fileId=IMG_4743.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_4743.JPG' ALT='IMG_4743.JPG'><BR>IMG_4743.JPG<br>54.07 KB</a><div class='inv'><br><a href='./images/20060101/IMG_4743.JPG' ALT='IMG_4743.JPG'>IMG_4743.JPG</a></div></td>
<td><A ID='IMG_4749.JPG' href='tassie1.php?fileId=IMG_4749.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_4749.JPG' ALT='IMG_4749.JPG'><BR>IMG_4749.JPG<br>74.07 KB</a><div class='inv'><br><a href='./images/20060101/IMG_4749.JPG' ALT='IMG_4749.JPG'>IMG_4749.JPG</a></div></td>
<td><A ID='IMG_4754.JPG' href='tassie1.php?fileId=IMG_4754.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_4754.JPG' ALT='IMG_4754.JPG'><BR>IMG_4754.JPG<br>72.07 KB</a><div class='inv'><br><a href='./images/20060101/IMG_4754.JPG' ALT='IMG_4754.JPG'>IMG_4754.JPG</a></div></td>
<td><A ID='IMG_4762.JPG' href='tassie1.php?fileId=IMG_4762.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_4762.JPG' ALT='IMG_4762.JPG'><BR>IMG_4762.JPG<br>82.34 KB</a><div class='inv'><br><a href='./images/20060101/IMG_4762.JPG' ALT='IMG_4762.JPG'>IMG_4762.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_4771.JPG' href='tassie1.php?fileId=IMG_4771.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_4771.JPG' ALT='IMG_4771.JPG'><BR>IMG_4771.JPG<br>86.17 KB</a><div class='inv'><br><a href='./images/20060101/IMG_4771.JPG' ALT='IMG_4771.JPG'>IMG_4771.JPG</a></div></td>
<td><A ID='IMG_4774.JPG' href='tassie1.php?fileId=IMG_4774.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_4774.JPG' ALT='IMG_4774.JPG'><BR>IMG_4774.JPG<br>126.48 KB</a><div class='inv'><br><a href='./images/20060101/IMG_4774.JPG' ALT='IMG_4774.JPG'>IMG_4774.JPG</a></div></td>
<td><A ID='IMG_4777.JPG' href='tassie1.php?fileId=IMG_4777.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_4777.JPG' ALT='IMG_4777.JPG'><BR>IMG_4777.JPG<br>125.2 KB</a><div class='inv'><br><a href='./images/20060101/IMG_4777.JPG' ALT='IMG_4777.JPG'>IMG_4777.JPG</a></div></td>
<td><A ID='IMG_4779.JPG' href='tassie1.php?fileId=IMG_4779.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_4779.JPG' ALT='IMG_4779.JPG'><BR>IMG_4779.JPG<br>99.05 KB</a><div class='inv'><br><a href='./images/20060101/IMG_4779.JPG' ALT='IMG_4779.JPG'>IMG_4779.JPG</a></div></td>
<td><A ID='IMG_4782.JPG' href='tassie1.php?fileId=IMG_4782.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_4782.JPG' ALT='IMG_4782.JPG'><BR>IMG_4782.JPG<br>84.43 KB</a><div class='inv'><br><a href='./images/20060101/IMG_4782.JPG' ALT='IMG_4782.JPG'>IMG_4782.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_4787.JPG' href='tassie1.php?fileId=IMG_4787.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_4787.JPG' ALT='IMG_4787.JPG'><BR>IMG_4787.JPG<br>124.96 KB</a><div class='inv'><br><a href='./images/20060101/IMG_4787.JPG' ALT='IMG_4787.JPG'>IMG_4787.JPG</a></div></td>
<td><A ID='IMG_4790.JPG' href='tassie1.php?fileId=IMG_4790.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_4790.JPG' ALT='IMG_4790.JPG'><BR>IMG_4790.JPG<br>73.59 KB</a><div class='inv'><br><a href='./images/20060101/IMG_4790.JPG' ALT='IMG_4790.JPG'>IMG_4790.JPG</a></div></td>
<td><A ID='IMG_4793.JPG' href='tassie1.php?fileId=IMG_4793.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_4793.JPG' ALT='IMG_4793.JPG'><BR>IMG_4793.JPG<br>122.34 KB</a><div class='inv'><br><a href='./images/20060101/IMG_4793.JPG' ALT='IMG_4793.JPG'>IMG_4793.JPG</a></div></td>
<td><A ID='IMG_4795.JPG' href='tassie1.php?fileId=IMG_4795.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_4795.JPG' ALT='IMG_4795.JPG'><BR>IMG_4795.JPG<br>76.97 KB</a><div class='inv'><br><a href='./images/20060101/IMG_4795.JPG' ALT='IMG_4795.JPG'>IMG_4795.JPG</a></div></td>
<td><A ID='IMG_4796.JPG' href='tassie1.php?fileId=IMG_4796.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_4796.JPG' ALT='IMG_4796.JPG'><BR>IMG_4796.JPG<br>60.56 KB</a><div class='inv'><br><a href='./images/20060101/IMG_4796.JPG' ALT='IMG_4796.JPG'>IMG_4796.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_4797.JPG' href='tassie1.php?fileId=IMG_4797.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_4797.JPG' ALT='IMG_4797.JPG'><BR>IMG_4797.JPG<br>132.87 KB</a><div class='inv'><br><a href='./images/20060101/IMG_4797.JPG' ALT='IMG_4797.JPG'>IMG_4797.JPG</a></div></td>
<td><A ID='IMG_4798.JPG' href='tassie1.php?fileId=IMG_4798.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_4798.JPG' ALT='IMG_4798.JPG'><BR>IMG_4798.JPG<br>93.66 KB</a><div class='inv'><br><a href='./images/20060101/IMG_4798.JPG' ALT='IMG_4798.JPG'>IMG_4798.JPG</a></div></td>
<td><A ID='IMG_4803.JPG' href='tassie1.php?fileId=IMG_4803.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_4803.JPG' ALT='IMG_4803.JPG'><BR>IMG_4803.JPG<br>91.85 KB</a><div class='inv'><br><a href='./images/20060101/IMG_4803.JPG' ALT='IMG_4803.JPG'>IMG_4803.JPG</a></div></td>
<td><A ID='IMG_4809.JPG' href='tassie1.php?fileId=IMG_4809.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_4809.JPG' ALT='IMG_4809.JPG'><BR>IMG_4809.JPG<br>100.87 KB</a><div class='inv'><br><a href='./images/20060101/IMG_4809.JPG' ALT='IMG_4809.JPG'>IMG_4809.JPG</a></div></td>
<td><A ID='IMG_4812.JPG' href='tassie1.php?fileId=IMG_4812.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_4812.JPG' ALT='IMG_4812.JPG'><BR>IMG_4812.JPG<br>81.99 KB</a><div class='inv'><br><a href='./images/20060101/IMG_4812.JPG' ALT='IMG_4812.JPG'>IMG_4812.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_4814.JPG' href='tassie1.php?fileId=IMG_4814.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_4814.JPG' ALT='IMG_4814.JPG'><BR>IMG_4814.JPG<br>56.7 KB</a><div class='inv'><br><a href='./images/20060101/IMG_4814.JPG' ALT='IMG_4814.JPG'>IMG_4814.JPG</a></div></td>
<td><A ID='IMG_4815.JPG' href='tassie1.php?fileId=IMG_4815.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_4815.JPG' ALT='IMG_4815.JPG'><BR>IMG_4815.JPG<br>104.29 KB</a><div class='inv'><br><a href='./images/20060101/IMG_4815.JPG' ALT='IMG_4815.JPG'>IMG_4815.JPG</a></div></td>
<td><A ID='IMG_4819.JPG' href='tassie1.php?fileId=IMG_4819.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_4819.JPG' ALT='IMG_4819.JPG'><BR>IMG_4819.JPG<br>94.16 KB</a><div class='inv'><br><a href='./images/20060101/IMG_4819.JPG' ALT='IMG_4819.JPG'>IMG_4819.JPG</a></div></td>
<td><A ID='IMG_4825.JPG' href='tassie1.php?fileId=IMG_4825.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_4825.JPG' ALT='IMG_4825.JPG'><BR>IMG_4825.JPG<br>115.62 KB</a><div class='inv'><br><a href='./images/20060101/IMG_4825.JPG' ALT='IMG_4825.JPG'>IMG_4825.JPG</a></div></td>
<td><A ID='IMG_4829.JPG' href='tassie1.php?fileId=IMG_4829.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_4829.JPG' ALT='IMG_4829.JPG'><BR>IMG_4829.JPG<br>119.48 KB</a><div class='inv'><br><a href='./images/20060101/IMG_4829.JPG' ALT='IMG_4829.JPG'>IMG_4829.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_4842.JPG' href='tassie1.php?fileId=IMG_4842.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_4842.JPG' ALT='IMG_4842.JPG'><BR>IMG_4842.JPG<br>140.59 KB</a><div class='inv'><br><a href='./images/20060101/IMG_4842.JPG' ALT='IMG_4842.JPG'>IMG_4842.JPG</a></div></td>
<td><A ID='IMG_4853.JPG' href='tassie1.php?fileId=IMG_4853.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_4853.JPG' ALT='IMG_4853.JPG'><BR>IMG_4853.JPG<br>120.73 KB</a><div class='inv'><br><a href='./images/20060101/IMG_4853.JPG' ALT='IMG_4853.JPG'>IMG_4853.JPG</a></div></td>
<td><A ID='IMG_4856.JPG' href='tassie1.php?fileId=IMG_4856.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_4856.JPG' ALT='IMG_4856.JPG'><BR>IMG_4856.JPG<br>109.24 KB</a><div class='inv'><br><a href='./images/20060101/IMG_4856.JPG' ALT='IMG_4856.JPG'>IMG_4856.JPG</a></div></td>
<td><A ID='IMG_4860.JPG' href='tassie1.php?fileId=IMG_4860.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_4860.JPG' ALT='IMG_4860.JPG'><BR>IMG_4860.JPG<br>110.62 KB</a><div class='inv'><br><a href='./images/20060101/IMG_4860.JPG' ALT='IMG_4860.JPG'>IMG_4860.JPG</a></div></td>
<td><A ID='IMG_4861.JPG' href='tassie1.php?fileId=IMG_4861.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_4861.JPG' ALT='IMG_4861.JPG'><BR>IMG_4861.JPG<br>90.17 KB</a><div class='inv'><br><a href='./images/20060101/IMG_4861.JPG' ALT='IMG_4861.JPG'>IMG_4861.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_4866.JPG' href='tassie1.php?fileId=IMG_4866.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_4866.JPG' ALT='IMG_4866.JPG'><BR>IMG_4866.JPG<br>63.88 KB</a><div class='inv'><br><a href='./images/20060101/IMG_4866.JPG' ALT='IMG_4866.JPG'>IMG_4866.JPG</a></div></td>
<td><A ID='IMG_4868.JPG' href='tassie1.php?fileId=IMG_4868.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_4868.JPG' ALT='IMG_4868.JPG'><BR>IMG_4868.JPG<br>68.34 KB</a><div class='inv'><br><a href='./images/20060101/IMG_4868.JPG' ALT='IMG_4868.JPG'>IMG_4868.JPG</a></div></td>
<td><A ID='IMG_4869.JPG' href='tassie1.php?fileId=IMG_4869.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_4869.JPG' ALT='IMG_4869.JPG'><BR>IMG_4869.JPG<br>120.96 KB</a><div class='inv'><br><a href='./images/20060101/IMG_4869.JPG' ALT='IMG_4869.JPG'>IMG_4869.JPG</a></div></td>
<td><A ID='IMG_4873.JPG' href='tassie1.php?fileId=IMG_4873.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_4873.JPG' ALT='IMG_4873.JPG'><BR>IMG_4873.JPG<br>69.8 KB</a><div class='inv'><br><a href='./images/20060101/IMG_4873.JPG' ALT='IMG_4873.JPG'>IMG_4873.JPG</a></div></td>
<td><A ID='IMG_4877.JPG' href='tassie1.php?fileId=IMG_4877.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_4877.JPG' ALT='IMG_4877.JPG'><BR>IMG_4877.JPG<br>124.89 KB</a><div class='inv'><br><a href='./images/20060101/IMG_4877.JPG' ALT='IMG_4877.JPG'>IMG_4877.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_4878.JPG' href='tassie1.php?fileId=IMG_4878.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_4878.JPG' ALT='IMG_4878.JPG'><BR>IMG_4878.JPG<br>140.91 KB</a><div class='inv'><br><a href='./images/20060101/IMG_4878.JPG' ALT='IMG_4878.JPG'>IMG_4878.JPG</a></div></td>
<td><A ID='IMG_4883.JPG' href='tassie1.php?fileId=IMG_4883.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_4883.JPG' ALT='IMG_4883.JPG'><BR>IMG_4883.JPG<br>74.3 KB</a><div class='inv'><br><a href='./images/20060101/IMG_4883.JPG' ALT='IMG_4883.JPG'>IMG_4883.JPG</a></div></td>
<td><A ID='IMG_4888.JPG' href='tassie1.php?fileId=IMG_4888.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_4888.JPG' ALT='IMG_4888.JPG'><BR>IMG_4888.JPG<br>57.82 KB</a><div class='inv'><br><a href='./images/20060101/IMG_4888.JPG' ALT='IMG_4888.JPG'>IMG_4888.JPG</a></div></td>
<td><A ID='IMG_4894.JPG' href='tassie1.php?fileId=IMG_4894.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_4894.JPG' ALT='IMG_4894.JPG'><BR>IMG_4894.JPG<br>86.17 KB</a><div class='inv'><br><a href='./images/20060101/IMG_4894.JPG' ALT='IMG_4894.JPG'>IMG_4894.JPG</a></div></td>
<td><A ID='IMG_4900.JPG' href='tassie1.php?fileId=IMG_4900.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_4900.JPG' ALT='IMG_4900.JPG'><BR>IMG_4900.JPG<br>103.3 KB</a><div class='inv'><br><a href='./images/20060101/IMG_4900.JPG' ALT='IMG_4900.JPG'>IMG_4900.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_4901.JPG' href='tassie1.php?fileId=IMG_4901.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_4901.JPG' ALT='IMG_4901.JPG'><BR>IMG_4901.JPG<br>100.68 KB</a><div class='inv'><br><a href='./images/20060101/IMG_4901.JPG' ALT='IMG_4901.JPG'>IMG_4901.JPG</a></div></td>
<td><A ID='IMG_4903.JPG' href='tassie1.php?fileId=IMG_4903.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_4903.JPG' ALT='IMG_4903.JPG'><BR>IMG_4903.JPG<br>101.52 KB</a><div class='inv'><br><a href='./images/20060101/IMG_4903.JPG' ALT='IMG_4903.JPG'>IMG_4903.JPG</a></div></td>
<td><A ID='IMG_4905.JPG' href='tassie1.php?fileId=IMG_4905.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_4905.JPG' ALT='IMG_4905.JPG'><BR>IMG_4905.JPG<br>98.41 KB</a><div class='inv'><br><a href='./images/20060101/IMG_4905.JPG' ALT='IMG_4905.JPG'>IMG_4905.JPG</a></div></td>
<td><A ID='IMG_4906.JPG' href='tassie1.php?fileId=IMG_4906.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_4906.JPG' ALT='IMG_4906.JPG'><BR>IMG_4906.JPG<br>117.28 KB</a><div class='inv'><br><a href='./images/20060101/IMG_4906.JPG' ALT='IMG_4906.JPG'>IMG_4906.JPG</a></div></td>
<td><A ID='IMG_4907.JPG' href='tassie1.php?fileId=IMG_4907.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_4907.JPG' ALT='IMG_4907.JPG'><BR>IMG_4907.JPG<br>140.37 KB</a><div class='inv'><br><a href='./images/20060101/IMG_4907.JPG' ALT='IMG_4907.JPG'>IMG_4907.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_4910.JPG' href='tassie1.php?fileId=IMG_4910.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_4910.JPG' ALT='IMG_4910.JPG'><BR>IMG_4910.JPG<br>125.72 KB</a><div class='inv'><br><a href='./images/20060101/IMG_4910.JPG' ALT='IMG_4910.JPG'>IMG_4910.JPG</a></div></td>
<td><A ID='IMG_4911.JPG' href='tassie1.php?fileId=IMG_4911.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_4911.JPG' ALT='IMG_4911.JPG'><BR>IMG_4911.JPG<br>124.25 KB</a><div class='inv'><br><a href='./images/20060101/IMG_4911.JPG' ALT='IMG_4911.JPG'>IMG_4911.JPG</a></div></td>
<td><A ID='IMG_4912.JPG' href='tassie1.php?fileId=IMG_4912.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_4912.JPG' ALT='IMG_4912.JPG'><BR>IMG_4912.JPG<br>92.54 KB</a><div class='inv'><br><a href='./images/20060101/IMG_4912.JPG' ALT='IMG_4912.JPG'>IMG_4912.JPG</a></div></td>
<td><A ID='IMG_4913.JPG' href='tassie1.php?fileId=IMG_4913.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_4913.JPG' ALT='IMG_4913.JPG'><BR>IMG_4913.JPG<br>78.71 KB</a><div class='inv'><br><a href='./images/20060101/IMG_4913.JPG' ALT='IMG_4913.JPG'>IMG_4913.JPG</a></div></td>
<td><A ID='IMG_4916.JPG' href='tassie1.php?fileId=IMG_4916.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_4916.JPG' ALT='IMG_4916.JPG'><BR>IMG_4916.JPG<br>80.28 KB</a><div class='inv'><br><a href='./images/20060101/IMG_4916.JPG' ALT='IMG_4916.JPG'>IMG_4916.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_4917.JPG' href='tassie1.php?fileId=IMG_4917.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_4917.JPG' ALT='IMG_4917.JPG'><BR>IMG_4917.JPG<br>58.86 KB</a><div class='inv'><br><a href='./images/20060101/IMG_4917.JPG' ALT='IMG_4917.JPG'>IMG_4917.JPG</a></div></td>
<td><A ID='IMG_4919.JPG' href='tassie1.php?fileId=IMG_4919.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_4919.JPG' ALT='IMG_4919.JPG'><BR>IMG_4919.JPG<br>57.46 KB</a><div class='inv'><br><a href='./images/20060101/IMG_4919.JPG' ALT='IMG_4919.JPG'>IMG_4919.JPG</a></div></td>
<td><A ID='IMG_4920.JPG' href='tassie1.php?fileId=IMG_4920.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_4920.JPG' ALT='IMG_4920.JPG'><BR>IMG_4920.JPG<br>80.65 KB</a><div class='inv'><br><a href='./images/20060101/IMG_4920.JPG' ALT='IMG_4920.JPG'>IMG_4920.JPG</a></div></td>
<td><A ID='IMG_4921.JPG' href='tassie1.php?fileId=IMG_4921.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_4921.JPG' ALT='IMG_4921.JPG'><BR>IMG_4921.JPG<br>81.87 KB</a><div class='inv'><br><a href='./images/20060101/IMG_4921.JPG' ALT='IMG_4921.JPG'>IMG_4921.JPG</a></div></td>
<td><A ID='IMG_4923.JPG' href='tassie1.php?fileId=IMG_4923.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_4923.JPG' ALT='IMG_4923.JPG'><BR>IMG_4923.JPG<br>84.49 KB</a><div class='inv'><br><a href='./images/20060101/IMG_4923.JPG' ALT='IMG_4923.JPG'>IMG_4923.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_4925.JPG' href='tassie1.php?fileId=IMG_4925.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_4925.JPG' ALT='IMG_4925.JPG'><BR>IMG_4925.JPG<br>46.07 KB</a><div class='inv'><br><a href='./images/20060101/IMG_4925.JPG' ALT='IMG_4925.JPG'>IMG_4925.JPG</a></div></td>
<td><A ID='IMG_4932.JPG' href='tassie1.php?fileId=IMG_4932.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_4932.JPG' ALT='IMG_4932.JPG'><BR>IMG_4932.JPG<br>57.49 KB</a><div class='inv'><br><a href='./images/20060101/IMG_4932.JPG' ALT='IMG_4932.JPG'>IMG_4932.JPG</a></div></td>
<td><A ID='IMG_4934.JPG' href='tassie1.php?fileId=IMG_4934.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_4934.JPG' ALT='IMG_4934.JPG'><BR>IMG_4934.JPG<br>137.08 KB</a><div class='inv'><br><a href='./images/20060101/IMG_4934.JPG' ALT='IMG_4934.JPG'>IMG_4934.JPG</a></div></td>
<td><A ID='IMG_4936.JPG' href='tassie1.php?fileId=IMG_4936.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_4936.JPG' ALT='IMG_4936.JPG'><BR>IMG_4936.JPG<br>121.31 KB</a><div class='inv'><br><a href='./images/20060101/IMG_4936.JPG' ALT='IMG_4936.JPG'>IMG_4936.JPG</a></div></td>
<td><A ID='IMG_4937.JPG' href='tassie1.php?fileId=IMG_4937.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_4937.JPG' ALT='IMG_4937.JPG'><BR>IMG_4937.JPG<br>139.72 KB</a><div class='inv'><br><a href='./images/20060101/IMG_4937.JPG' ALT='IMG_4937.JPG'>IMG_4937.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_4940.JPG' href='tassie1.php?fileId=IMG_4940.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_4940.JPG' ALT='IMG_4940.JPG'><BR>IMG_4940.JPG<br>120.44 KB</a><div class='inv'><br><a href='./images/20060101/IMG_4940.JPG' ALT='IMG_4940.JPG'>IMG_4940.JPG</a></div></td>
<td><A ID='IMG_4943.JPG' href='tassie1.php?fileId=IMG_4943.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_4943.JPG' ALT='IMG_4943.JPG'><BR>IMG_4943.JPG<br>120.94 KB</a><div class='inv'><br><a href='./images/20060101/IMG_4943.JPG' ALT='IMG_4943.JPG'>IMG_4943.JPG</a></div></td>
<td><A ID='IMG_4944.JPG' href='tassie1.php?fileId=IMG_4944.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_4944.JPG' ALT='IMG_4944.JPG'><BR>IMG_4944.JPG<br>137.91 KB</a><div class='inv'><br><a href='./images/20060101/IMG_4944.JPG' ALT='IMG_4944.JPG'>IMG_4944.JPG</a></div></td>
<td><A ID='IMG_4945.JPG' href='tassie1.php?fileId=IMG_4945.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_4945.JPG' ALT='IMG_4945.JPG'><BR>IMG_4945.JPG<br>153.75 KB</a><div class='inv'><br><a href='./images/20060101/IMG_4945.JPG' ALT='IMG_4945.JPG'>IMG_4945.JPG</a></div></td>
<td><A ID='IMG_4954.JPG' href='tassie1.php?fileId=IMG_4954.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_4954.JPG' ALT='IMG_4954.JPG'><BR>IMG_4954.JPG<br>134.27 KB</a><div class='inv'><br><a href='./images/20060101/IMG_4954.JPG' ALT='IMG_4954.JPG'>IMG_4954.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_4957.JPG' href='tassie1.php?fileId=IMG_4957.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_4957.JPG' ALT='IMG_4957.JPG'><BR>IMG_4957.JPG<br>101.92 KB</a><div class='inv'><br><a href='./images/20060101/IMG_4957.JPG' ALT='IMG_4957.JPG'>IMG_4957.JPG</a></div></td>
<td><A ID='IMG_4958.JPG' href='tassie1.php?fileId=IMG_4958.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_4958.JPG' ALT='IMG_4958.JPG'><BR>IMG_4958.JPG<br>81.87 KB</a><div class='inv'><br><a href='./images/20060101/IMG_4958.JPG' ALT='IMG_4958.JPG'>IMG_4958.JPG</a></div></td>
<td><A ID='IMG_4966.JPG' href='tassie1.php?fileId=IMG_4966.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_4966.JPG' ALT='IMG_4966.JPG'><BR>IMG_4966.JPG<br>137.44 KB</a><div class='inv'><br><a href='./images/20060101/IMG_4966.JPG' ALT='IMG_4966.JPG'>IMG_4966.JPG</a></div></td>
<td><A ID='IMG_4970.JPG' href='tassie1.php?fileId=IMG_4970.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_4970.JPG' ALT='IMG_4970.JPG'><BR>IMG_4970.JPG<br>63.42 KB</a><div class='inv'><br><a href='./images/20060101/IMG_4970.JPG' ALT='IMG_4970.JPG'>IMG_4970.JPG</a></div></td>
<td><A ID='IMG_4977.JPG' href='tassie1.php?fileId=IMG_4977.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_4977.JPG' ALT='IMG_4977.JPG'><BR>IMG_4977.JPG<br>121.02 KB</a><div class='inv'><br><a href='./images/20060101/IMG_4977.JPG' ALT='IMG_4977.JPG'>IMG_4977.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_4978.JPG' href='tassie1.php?fileId=IMG_4978.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_4978.JPG' ALT='IMG_4978.JPG'><BR>IMG_4978.JPG<br>99.11 KB</a><div class='inv'><br><a href='./images/20060101/IMG_4978.JPG' ALT='IMG_4978.JPG'>IMG_4978.JPG</a></div></td>
<td><A ID='IMG_4981.JPG' href='tassie1.php?fileId=IMG_4981.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_4981.JPG' ALT='IMG_4981.JPG'><BR>IMG_4981.JPG<br>136.78 KB</a><div class='inv'><br><a href='./images/20060101/IMG_4981.JPG' ALT='IMG_4981.JPG'>IMG_4981.JPG</a></div></td>
<td><A ID='IMG_4994.JPG' href='tassie1.php?fileId=IMG_4994.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_4994.JPG' ALT='IMG_4994.JPG'><BR>IMG_4994.JPG<br>75.41 KB</a><div class='inv'><br><a href='./images/20060101/IMG_4994.JPG' ALT='IMG_4994.JPG'>IMG_4994.JPG</a></div></td>
<td><A ID='IMG_4996.JPG' href='tassie1.php?fileId=IMG_4996.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_4996.JPG' ALT='IMG_4996.JPG'><BR>IMG_4996.JPG<br>44.77 KB</a><div class='inv'><br><a href='./images/20060101/IMG_4996.JPG' ALT='IMG_4996.JPG'>IMG_4996.JPG</a></div></td>
<td><A ID='IMG_5005.JPG' href='tassie1.php?fileId=IMG_5005.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5005.JPG' ALT='IMG_5005.JPG'><BR>IMG_5005.JPG<br>37.45 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5005.JPG' ALT='IMG_5005.JPG'>IMG_5005.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5006.JPG' href='tassie1.php?fileId=IMG_5006.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5006.JPG' ALT='IMG_5006.JPG'><BR>IMG_5006.JPG<br>79.21 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5006.JPG' ALT='IMG_5006.JPG'>IMG_5006.JPG</a></div></td>
<td><A ID='IMG_5007.JPG' href='tassie1.php?fileId=IMG_5007.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5007.JPG' ALT='IMG_5007.JPG'><BR>IMG_5007.JPG<br>56.3 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5007.JPG' ALT='IMG_5007.JPG'>IMG_5007.JPG</a></div></td>
<td><A ID='IMG_5011.JPG' href='tassie1.php?fileId=IMG_5011.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5011.JPG' ALT='IMG_5011.JPG'><BR>IMG_5011.JPG<br>97.22 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5011.JPG' ALT='IMG_5011.JPG'>IMG_5011.JPG</a></div></td>
<td><A ID='IMG_5013.JPG' href='tassie1.php?fileId=IMG_5013.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5013.JPG' ALT='IMG_5013.JPG'><BR>IMG_5013.JPG<br>40.46 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5013.JPG' ALT='IMG_5013.JPG'>IMG_5013.JPG</a></div></td>
<td><A ID='IMG_5016.JPG' href='tassie1.php?fileId=IMG_5016.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5016.JPG' ALT='IMG_5016.JPG'><BR>IMG_5016.JPG<br>41.16 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5016.JPG' ALT='IMG_5016.JPG'>IMG_5016.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5022.JPG' href='tassie1.php?fileId=IMG_5022.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5022.JPG' ALT='IMG_5022.JPG'><BR>IMG_5022.JPG<br>39.97 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5022.JPG' ALT='IMG_5022.JPG'>IMG_5022.JPG</a></div></td>
<td><A ID='IMG_5024.JPG' href='tassie1.php?fileId=IMG_5024.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5024.JPG' ALT='IMG_5024.JPG'><BR>IMG_5024.JPG<br>37.59 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5024.JPG' ALT='IMG_5024.JPG'>IMG_5024.JPG</a></div></td>
<td><A ID='IMG_5027.JPG' href='tassie1.php?fileId=IMG_5027.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5027.JPG' ALT='IMG_5027.JPG'><BR>IMG_5027.JPG<br>119.5 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5027.JPG' ALT='IMG_5027.JPG'>IMG_5027.JPG</a></div></td>
<td><A ID='IMG_5030.JPG' href='tassie1.php?fileId=IMG_5030.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5030.JPG' ALT='IMG_5030.JPG'><BR>IMG_5030.JPG<br>102.09 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5030.JPG' ALT='IMG_5030.JPG'>IMG_5030.JPG</a></div></td>
<td><A ID='IMG_5032.JPG' href='tassie1.php?fileId=IMG_5032.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5032.JPG' ALT='IMG_5032.JPG'><BR>IMG_5032.JPG<br>128.07 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5032.JPG' ALT='IMG_5032.JPG'>IMG_5032.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5033.JPG' href='tassie1.php?fileId=IMG_5033.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5033.JPG' ALT='IMG_5033.JPG'><BR>IMG_5033.JPG<br>122.47 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5033.JPG' ALT='IMG_5033.JPG'>IMG_5033.JPG</a></div></td>
<td><A ID='IMG_5036.JPG' href='tassie1.php?fileId=IMG_5036.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5036.JPG' ALT='IMG_5036.JPG'><BR>IMG_5036.JPG<br>110.64 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5036.JPG' ALT='IMG_5036.JPG'>IMG_5036.JPG</a></div></td>
<td><A ID='IMG_5039.JPG' href='tassie1.php?fileId=IMG_5039.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5039.JPG' ALT='IMG_5039.JPG'><BR>IMG_5039.JPG<br>125.52 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5039.JPG' ALT='IMG_5039.JPG'>IMG_5039.JPG</a></div></td>
<td><A ID='IMG_5041.JPG' href='tassie1.php?fileId=IMG_5041.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5041.JPG' ALT='IMG_5041.JPG'><BR>IMG_5041.JPG<br>60.86 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5041.JPG' ALT='IMG_5041.JPG'>IMG_5041.JPG</a></div></td>
<td><A ID='IMG_5045.JPG' href='tassie1.php?fileId=IMG_5045.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5045.JPG' ALT='IMG_5045.JPG'><BR>IMG_5045.JPG<br>69.12 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5045.JPG' ALT='IMG_5045.JPG'>IMG_5045.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5050.JPG' href='tassie1.php?fileId=IMG_5050.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5050.JPG' ALT='IMG_5050.JPG'><BR>IMG_5050.JPG<br>124.35 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5050.JPG' ALT='IMG_5050.JPG'>IMG_5050.JPG</a></div></td>
<td><A ID='IMG_5051.JPG' href='tassie1.php?fileId=IMG_5051.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5051.JPG' ALT='IMG_5051.JPG'><BR>IMG_5051.JPG<br>103.38 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5051.JPG' ALT='IMG_5051.JPG'>IMG_5051.JPG</a></div></td>
<td><A ID='IMG_5052.JPG' href='tassie1.php?fileId=IMG_5052.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5052.JPG' ALT='IMG_5052.JPG'><BR>IMG_5052.JPG<br>114.43 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5052.JPG' ALT='IMG_5052.JPG'>IMG_5052.JPG</a></div></td>
<td><A ID='IMG_5054.JPG' href='tassie1.php?fileId=IMG_5054.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5054.JPG' ALT='IMG_5054.JPG'><BR>IMG_5054.JPG<br>57.8 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5054.JPG' ALT='IMG_5054.JPG'>IMG_5054.JPG</a></div></td>
<td><A ID='IMG_5055.JPG' href='tassie1.php?fileId=IMG_5055.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5055.JPG' ALT='IMG_5055.JPG'><BR>IMG_5055.JPG<br>93.73 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5055.JPG' ALT='IMG_5055.JPG'>IMG_5055.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5056.JPG' href='tassie1.php?fileId=IMG_5056.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5056.JPG' ALT='IMG_5056.JPG'><BR>IMG_5056.JPG<br>60.07 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5056.JPG' ALT='IMG_5056.JPG'>IMG_5056.JPG</a></div></td>
<td><A ID='IMG_5062.JPG' href='tassie1.php?fileId=IMG_5062.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5062.JPG' ALT='IMG_5062.JPG'><BR>IMG_5062.JPG<br>71.54 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5062.JPG' ALT='IMG_5062.JPG'>IMG_5062.JPG</a></div></td>
<td><A ID='IMG_5063.JPG' href='tassie1.php?fileId=IMG_5063.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5063.JPG' ALT='IMG_5063.JPG'><BR>IMG_5063.JPG<br>71.17 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5063.JPG' ALT='IMG_5063.JPG'>IMG_5063.JPG</a></div></td>
<td><A ID='IMG_5064.JPG' href='tassie1.php?fileId=IMG_5064.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5064.JPG' ALT='IMG_5064.JPG'><BR>IMG_5064.JPG<br>77.29 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5064.JPG' ALT='IMG_5064.JPG'>IMG_5064.JPG</a></div></td>
<td><A ID='IMG_5065.JPG' href='tassie1.php?fileId=IMG_5065.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5065.JPG' ALT='IMG_5065.JPG'><BR>IMG_5065.JPG<br>67.1 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5065.JPG' ALT='IMG_5065.JPG'>IMG_5065.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5111.JPG' href='tassie1.php?fileId=IMG_5111.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5111.JPG' ALT='IMG_5111.JPG'><BR>IMG_5111.JPG<br>57.02 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5111.JPG' ALT='IMG_5111.JPG'>IMG_5111.JPG</a></div></td>
<td><A ID='IMG_5114.JPG' href='tassie1.php?fileId=IMG_5114.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5114.JPG' ALT='IMG_5114.JPG'><BR>IMG_5114.JPG<br>53.74 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5114.JPG' ALT='IMG_5114.JPG'>IMG_5114.JPG</a></div></td>
<td><A ID='IMG_5117.JPG' href='tassie1.php?fileId=IMG_5117.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5117.JPG' ALT='IMG_5117.JPG'><BR>IMG_5117.JPG<br>74.19 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5117.JPG' ALT='IMG_5117.JPG'>IMG_5117.JPG</a></div></td>
<td><A ID='IMG_5118.JPG' href='tassie1.php?fileId=IMG_5118.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5118.JPG' ALT='IMG_5118.JPG'><BR>IMG_5118.JPG<br>48.92 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5118.JPG' ALT='IMG_5118.JPG'>IMG_5118.JPG</a></div></td>
<td><A ID='IMG_5121.JPG' href='tassie1.php?fileId=IMG_5121.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5121.JPG' ALT='IMG_5121.JPG'><BR>IMG_5121.JPG<br>72.73 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5121.JPG' ALT='IMG_5121.JPG'>IMG_5121.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5123.JPG' href='tassie1.php?fileId=IMG_5123.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5123.JPG' ALT='IMG_5123.JPG'><BR>IMG_5123.JPG<br>83.67 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5123.JPG' ALT='IMG_5123.JPG'>IMG_5123.JPG</a></div></td>
<td><A ID='IMG_5126.JPG' href='tassie1.php?fileId=IMG_5126.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5126.JPG' ALT='IMG_5126.JPG'><BR>IMG_5126.JPG<br>56.08 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5126.JPG' ALT='IMG_5126.JPG'>IMG_5126.JPG</a></div></td>
<td><A ID='IMG_5128.JPG' href='tassie1.php?fileId=IMG_5128.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5128.JPG' ALT='IMG_5128.JPG'><BR>IMG_5128.JPG<br>86.73 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5128.JPG' ALT='IMG_5128.JPG'>IMG_5128.JPG</a></div></td>
<td><A ID='IMG_5134.JPG' href='tassie1.php?fileId=IMG_5134.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5134.JPG' ALT='IMG_5134.JPG'><BR>IMG_5134.JPG<br>63.94 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5134.JPG' ALT='IMG_5134.JPG'>IMG_5134.JPG</a></div></td>
<td><A ID='IMG_5137.JPG' href='tassie1.php?fileId=IMG_5137.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5137.JPG' ALT='IMG_5137.JPG'><BR>IMG_5137.JPG<br>105.13 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5137.JPG' ALT='IMG_5137.JPG'>IMG_5137.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5138.JPG' href='tassie1.php?fileId=IMG_5138.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5138.JPG' ALT='IMG_5138.JPG'><BR>IMG_5138.JPG<br>80.84 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5138.JPG' ALT='IMG_5138.JPG'>IMG_5138.JPG</a></div></td>
<td><A ID='IMG_5142.JPG' href='tassie1.php?fileId=IMG_5142.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5142.JPG' ALT='IMG_5142.JPG'><BR>IMG_5142.JPG<br>47.28 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5142.JPG' ALT='IMG_5142.JPG'>IMG_5142.JPG</a></div></td>
<td><A ID='IMG_5144.JPG' href='tassie1.php?fileId=IMG_5144.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5144.JPG' ALT='IMG_5144.JPG'><BR>IMG_5144.JPG<br>130.2 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5144.JPG' ALT='IMG_5144.JPG'>IMG_5144.JPG</a></div></td>
<td><A ID='IMG_5153.JPG' href='tassie1.php?fileId=IMG_5153.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5153.JPG' ALT='IMG_5153.JPG'><BR>IMG_5153.JPG<br>100.68 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5153.JPG' ALT='IMG_5153.JPG'>IMG_5153.JPG</a></div></td>
<td><A ID='IMG_5155.JPG' href='tassie1.php?fileId=IMG_5155.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5155.JPG' ALT='IMG_5155.JPG'><BR>IMG_5155.JPG<br>81.2 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5155.JPG' ALT='IMG_5155.JPG'>IMG_5155.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5156.JPG' href='tassie1.php?fileId=IMG_5156.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5156.JPG' ALT='IMG_5156.JPG'><BR>IMG_5156.JPG<br>97.57 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5156.JPG' ALT='IMG_5156.JPG'>IMG_5156.JPG</a></div></td>
<td><A ID='IMG_5158.JPG' href='tassie1.php?fileId=IMG_5158.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5158.JPG' ALT='IMG_5158.JPG'><BR>IMG_5158.JPG<br>78.74 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5158.JPG' ALT='IMG_5158.JPG'>IMG_5158.JPG</a></div></td>
<td><A ID='IMG_5161.JPG' href='tassie1.php?fileId=IMG_5161.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5161.JPG' ALT='IMG_5161.JPG'><BR>IMG_5161.JPG<br>66.57 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5161.JPG' ALT='IMG_5161.JPG'>IMG_5161.JPG</a></div></td>
<td><A ID='IMG_5168.JPG' href='tassie1.php?fileId=IMG_5168.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5168.JPG' ALT='IMG_5168.JPG'><BR>IMG_5168.JPG<br>112.75 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5168.JPG' ALT='IMG_5168.JPG'>IMG_5168.JPG</a></div></td>
<td><A ID='IMG_5172.JPG' href='tassie1.php?fileId=IMG_5172.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5172.JPG' ALT='IMG_5172.JPG'><BR>IMG_5172.JPG<br>115.95 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5172.JPG' ALT='IMG_5172.JPG'>IMG_5172.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5173.JPG' href='tassie1.php?fileId=IMG_5173.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5173.JPG' ALT='IMG_5173.JPG'><BR>IMG_5173.JPG<br>56.92 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5173.JPG' ALT='IMG_5173.JPG'>IMG_5173.JPG</a></div></td>
<td><A ID='IMG_5175.JPG' href='tassie1.php?fileId=IMG_5175.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5175.JPG' ALT='IMG_5175.JPG'><BR>IMG_5175.JPG<br>92.46 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5175.JPG' ALT='IMG_5175.JPG'>IMG_5175.JPG</a></div></td>
<td><A ID='IMG_5177.JPG' href='tassie1.php?fileId=IMG_5177.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5177.JPG' ALT='IMG_5177.JPG'><BR>IMG_5177.JPG<br>134.2 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5177.JPG' ALT='IMG_5177.JPG'>IMG_5177.JPG</a></div></td>
<td><A ID='IMG_5178.JPG' href='tassie1.php?fileId=IMG_5178.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5178.JPG' ALT='IMG_5178.JPG'><BR>IMG_5178.JPG<br>112.05 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5178.JPG' ALT='IMG_5178.JPG'>IMG_5178.JPG</a></div></td>
<td><A ID='IMG_5179.JPG' href='tassie1.php?fileId=IMG_5179.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5179.JPG' ALT='IMG_5179.JPG'><BR>IMG_5179.JPG<br>65.59 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5179.JPG' ALT='IMG_5179.JPG'>IMG_5179.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5181.JPG' href='tassie1.php?fileId=IMG_5181.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5181.JPG' ALT='IMG_5181.JPG'><BR>IMG_5181.JPG<br>65.23 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5181.JPG' ALT='IMG_5181.JPG'>IMG_5181.JPG</a></div></td>
<td><A ID='IMG_5184.JPG' href='tassie1.php?fileId=IMG_5184.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5184.JPG' ALT='IMG_5184.JPG'><BR>IMG_5184.JPG<br>69.98 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5184.JPG' ALT='IMG_5184.JPG'>IMG_5184.JPG</a></div></td>
<td><A ID='IMG_5185.JPG' href='tassie1.php?fileId=IMG_5185.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5185.JPG' ALT='IMG_5185.JPG'><BR>IMG_5185.JPG<br>78.01 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5185.JPG' ALT='IMG_5185.JPG'>IMG_5185.JPG</a></div></td>
<td><A ID='IMG_5186.JPG' href='tassie1.php?fileId=IMG_5186.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5186.JPG' ALT='IMG_5186.JPG'><BR>IMG_5186.JPG<br>41.88 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5186.JPG' ALT='IMG_5186.JPG'>IMG_5186.JPG</a></div></td>
<td><A ID='IMG_5187.JPG' href='tassie1.php?fileId=IMG_5187.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5187.JPG' ALT='IMG_5187.JPG'><BR>IMG_5187.JPG<br>48.24 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5187.JPG' ALT='IMG_5187.JPG'>IMG_5187.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5192.JPG' href='tassie1.php?fileId=IMG_5192.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5192.JPG' ALT='IMG_5192.JPG'><BR>IMG_5192.JPG<br>48.28 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5192.JPG' ALT='IMG_5192.JPG'>IMG_5192.JPG</a></div></td>
<td><A ID='IMG_5199.JPG' href='tassie1.php?fileId=IMG_5199.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5199.JPG' ALT='IMG_5199.JPG'><BR>IMG_5199.JPG<br>88.56 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5199.JPG' ALT='IMG_5199.JPG'>IMG_5199.JPG</a></div></td>
<td><A ID='IMG_5203.JPG' href='tassie1.php?fileId=IMG_5203.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5203.JPG' ALT='IMG_5203.JPG'><BR>IMG_5203.JPG<br>42.18 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5203.JPG' ALT='IMG_5203.JPG'>IMG_5203.JPG</a></div></td>
<td><A ID='IMG_5204.JPG' href='tassie1.php?fileId=IMG_5204.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5204.JPG' ALT='IMG_5204.JPG'><BR>IMG_5204.JPG<br>71.25 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5204.JPG' ALT='IMG_5204.JPG'>IMG_5204.JPG</a></div></td>
<td><A ID='IMG_5206.JPG' href='tassie1.php?fileId=IMG_5206.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5206.JPG' ALT='IMG_5206.JPG'><BR>IMG_5206.JPG<br>60 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5206.JPG' ALT='IMG_5206.JPG'>IMG_5206.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5207.JPG' href='tassie1.php?fileId=IMG_5207.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5207.JPG' ALT='IMG_5207.JPG'><BR>IMG_5207.JPG<br>115.52 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5207.JPG' ALT='IMG_5207.JPG'>IMG_5207.JPG</a></div></td>
<td><A ID='IMG_5208.JPG' href='tassie1.php?fileId=IMG_5208.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5208.JPG' ALT='IMG_5208.JPG'><BR>IMG_5208.JPG<br>141.19 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5208.JPG' ALT='IMG_5208.JPG'>IMG_5208.JPG</a></div></td>
<td><A ID='IMG_5211.JPG' href='tassie1.php?fileId=IMG_5211.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5211.JPG' ALT='IMG_5211.JPG'><BR>IMG_5211.JPG<br>50.15 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5211.JPG' ALT='IMG_5211.JPG'>IMG_5211.JPG</a></div></td>
<td><A ID='IMG_5212.JPG' href='tassie1.php?fileId=IMG_5212.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5212.JPG' ALT='IMG_5212.JPG'><BR>IMG_5212.JPG<br>52.96 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5212.JPG' ALT='IMG_5212.JPG'>IMG_5212.JPG</a></div></td>
<td><A ID='IMG_5215.JPG' href='tassie1.php?fileId=IMG_5215.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5215.JPG' ALT='IMG_5215.JPG'><BR>IMG_5215.JPG<br>110.4 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5215.JPG' ALT='IMG_5215.JPG'>IMG_5215.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5220.JPG' href='tassie1.php?fileId=IMG_5220.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5220.JPG' ALT='IMG_5220.JPG'><BR>IMG_5220.JPG<br>101.25 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5220.JPG' ALT='IMG_5220.JPG'>IMG_5220.JPG</a></div></td>
<td><A ID='IMG_5224.JPG' href='tassie1.php?fileId=IMG_5224.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5224.JPG' ALT='IMG_5224.JPG'><BR>IMG_5224.JPG<br>51.79 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5224.JPG' ALT='IMG_5224.JPG'>IMG_5224.JPG</a></div></td>
<td><A ID='IMG_5227.JPG' href='tassie1.php?fileId=IMG_5227.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5227.JPG' ALT='IMG_5227.JPG'><BR>IMG_5227.JPG<br>114.25 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5227.JPG' ALT='IMG_5227.JPG'>IMG_5227.JPG</a></div></td>
<td><A ID='IMG_5230.JPG' href='tassie1.php?fileId=IMG_5230.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5230.JPG' ALT='IMG_5230.JPG'><BR>IMG_5230.JPG<br>107.07 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5230.JPG' ALT='IMG_5230.JPG'>IMG_5230.JPG</a></div></td>
<td><A ID='IMG_5233.JPG' href='tassie1.php?fileId=IMG_5233.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5233.JPG' ALT='IMG_5233.JPG'><BR>IMG_5233.JPG<br>76.9 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5233.JPG' ALT='IMG_5233.JPG'>IMG_5233.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5239.JPG' href='tassie1.php?fileId=IMG_5239.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5239.JPG' ALT='IMG_5239.JPG'><BR>IMG_5239.JPG<br>128.26 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5239.JPG' ALT='IMG_5239.JPG'>IMG_5239.JPG</a></div></td>
<td><A ID='IMG_5244.JPG' href='tassie1.php?fileId=IMG_5244.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5244.JPG' ALT='IMG_5244.JPG'><BR>IMG_5244.JPG<br>129.18 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5244.JPG' ALT='IMG_5244.JPG'>IMG_5244.JPG</a></div></td>
<td><A ID='IMG_5260.JPG' href='tassie1.php?fileId=IMG_5260.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5260.JPG' ALT='IMG_5260.JPG'><BR>IMG_5260.JPG<br>63.16 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5260.JPG' ALT='IMG_5260.JPG'>IMG_5260.JPG</a></div></td>
<td><A ID='IMG_5261.JPG' href='tassie1.php?fileId=IMG_5261.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5261.JPG' ALT='IMG_5261.JPG'><BR>IMG_5261.JPG<br>74.54 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5261.JPG' ALT='IMG_5261.JPG'>IMG_5261.JPG</a></div></td>
<td><A ID='IMG_5264.JPG' href='tassie1.php?fileId=IMG_5264.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5264.JPG' ALT='IMG_5264.JPG'><BR>IMG_5264.JPG<br>113.31 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5264.JPG' ALT='IMG_5264.JPG'>IMG_5264.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5267.JPG' href='tassie1.php?fileId=IMG_5267.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5267.JPG' ALT='IMG_5267.JPG'><BR>IMG_5267.JPG<br>78.5 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5267.JPG' ALT='IMG_5267.JPG'>IMG_5267.JPG</a></div></td>
<td><A ID='IMG_5268.JPG' href='tassie1.php?fileId=IMG_5268.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5268.JPG' ALT='IMG_5268.JPG'><BR>IMG_5268.JPG<br>80.56 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5268.JPG' ALT='IMG_5268.JPG'>IMG_5268.JPG</a></div></td>
<td><A ID='IMG_5269.JPG' href='tassie1.php?fileId=IMG_5269.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5269.JPG' ALT='IMG_5269.JPG'><BR>IMG_5269.JPG<br>63.83 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5269.JPG' ALT='IMG_5269.JPG'>IMG_5269.JPG</a></div></td>
<td><A ID='IMG_5324.JPG' href='tassie1.php?fileId=IMG_5324.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5324.JPG' ALT='IMG_5324.JPG'><BR>IMG_5324.JPG<br>119.22 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5324.JPG' ALT='IMG_5324.JPG'>IMG_5324.JPG</a></div></td>
<td><A ID='IMG_5326.JPG' href='tassie1.php?fileId=IMG_5326.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5326.JPG' ALT='IMG_5326.JPG'><BR>IMG_5326.JPG<br>74.8 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5326.JPG' ALT='IMG_5326.JPG'>IMG_5326.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5334.JPG' href='tassie1.php?fileId=IMG_5334.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5334.JPG' ALT='IMG_5334.JPG'><BR>IMG_5334.JPG<br>96.35 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5334.JPG' ALT='IMG_5334.JPG'>IMG_5334.JPG</a></div></td>
<td><A ID='IMG_5340.JPG' href='tassie1.php?fileId=IMG_5340.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5340.JPG' ALT='IMG_5340.JPG'><BR>IMG_5340.JPG<br>85.64 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5340.JPG' ALT='IMG_5340.JPG'>IMG_5340.JPG</a></div></td>
<td><A ID='IMG_5341.JPG' href='tassie1.php?fileId=IMG_5341.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5341.JPG' ALT='IMG_5341.JPG'><BR>IMG_5341.JPG<br>116.21 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5341.JPG' ALT='IMG_5341.JPG'>IMG_5341.JPG</a></div></td>
<td><A ID='IMG_5343.JPG' href='tassie1.php?fileId=IMG_5343.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5343.JPG' ALT='IMG_5343.JPG'><BR>IMG_5343.JPG<br>98.06 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5343.JPG' ALT='IMG_5343.JPG'>IMG_5343.JPG</a></div></td>
<td><A ID='IMG_5348.JPG' href='tassie1.php?fileId=IMG_5348.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5348.JPG' ALT='IMG_5348.JPG'><BR>IMG_5348.JPG<br>70.02 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5348.JPG' ALT='IMG_5348.JPG'>IMG_5348.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5350.JPG' href='tassie1.php?fileId=IMG_5350.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5350.JPG' ALT='IMG_5350.JPG'><BR>IMG_5350.JPG<br>93.01 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5350.JPG' ALT='IMG_5350.JPG'>IMG_5350.JPG</a></div></td>
<td><A ID='IMG_5355.JPG' href='tassie1.php?fileId=IMG_5355.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5355.JPG' ALT='IMG_5355.JPG'><BR>IMG_5355.JPG<br>80.67 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5355.JPG' ALT='IMG_5355.JPG'>IMG_5355.JPG</a></div></td>
<td><A ID='IMG_5362.JPG' href='tassie1.php?fileId=IMG_5362.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5362.JPG' ALT='IMG_5362.JPG'><BR>IMG_5362.JPG<br>120.63 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5362.JPG' ALT='IMG_5362.JPG'>IMG_5362.JPG</a></div></td>
<td><A ID='IMG_5365.JPG' href='tassie1.php?fileId=IMG_5365.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5365.JPG' ALT='IMG_5365.JPG'><BR>IMG_5365.JPG<br>96.73 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5365.JPG' ALT='IMG_5365.JPG'>IMG_5365.JPG</a></div></td>
<td><A ID='IMG_5368.JPG' href='tassie1.php?fileId=IMG_5368.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5368.JPG' ALT='IMG_5368.JPG'><BR>IMG_5368.JPG<br>102.03 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5368.JPG' ALT='IMG_5368.JPG'>IMG_5368.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5377.JPG' href='tassie1.php?fileId=IMG_5377.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5377.JPG' ALT='IMG_5377.JPG'><BR>IMG_5377.JPG<br>77.56 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5377.JPG' ALT='IMG_5377.JPG'>IMG_5377.JPG</a></div></td>
<td><A ID='IMG_5379.JPG' href='tassie1.php?fileId=IMG_5379.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5379.JPG' ALT='IMG_5379.JPG'><BR>IMG_5379.JPG<br>72.09 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5379.JPG' ALT='IMG_5379.JPG'>IMG_5379.JPG</a></div></td>
<td><A ID='IMG_5380.JPG' href='tassie1.php?fileId=IMG_5380.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5380.JPG' ALT='IMG_5380.JPG'><BR>IMG_5380.JPG<br>124.69 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5380.JPG' ALT='IMG_5380.JPG'>IMG_5380.JPG</a></div></td>
<td><A ID='IMG_5383.JPG' href='tassie1.php?fileId=IMG_5383.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5383.JPG' ALT='IMG_5383.JPG'><BR>IMG_5383.JPG<br>58.52 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5383.JPG' ALT='IMG_5383.JPG'>IMG_5383.JPG</a></div></td>
<td><A ID='IMG_5386.JPG' href='tassie1.php?fileId=IMG_5386.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5386.JPG' ALT='IMG_5386.JPG'><BR>IMG_5386.JPG<br>96.84 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5386.JPG' ALT='IMG_5386.JPG'>IMG_5386.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5388.JPG' href='tassie1.php?fileId=IMG_5388.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5388.JPG' ALT='IMG_5388.JPG'><BR>IMG_5388.JPG<br>113.53 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5388.JPG' ALT='IMG_5388.JPG'>IMG_5388.JPG</a></div></td>
<td><A ID='IMG_5390.JPG' href='tassie1.php?fileId=IMG_5390.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5390.JPG' ALT='IMG_5390.JPG'><BR>IMG_5390.JPG<br>69.02 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5390.JPG' ALT='IMG_5390.JPG'>IMG_5390.JPG</a></div></td>
<td><A ID='IMG_5394.JPG' href='tassie1.php?fileId=IMG_5394.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5394.JPG' ALT='IMG_5394.JPG'><BR>IMG_5394.JPG<br>111.58 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5394.JPG' ALT='IMG_5394.JPG'>IMG_5394.JPG</a></div></td>
<td><A ID='IMG_5395.JPG' href='tassie1.php?fileId=IMG_5395.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5395.JPG' ALT='IMG_5395.JPG'><BR>IMG_5395.JPG<br>97.38 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5395.JPG' ALT='IMG_5395.JPG'>IMG_5395.JPG</a></div></td>
<td><A ID='IMG_5398.JPG' href='tassie1.php?fileId=IMG_5398.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5398.JPG' ALT='IMG_5398.JPG'><BR>IMG_5398.JPG<br>126.19 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5398.JPG' ALT='IMG_5398.JPG'>IMG_5398.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5401.JPG' href='tassie1.php?fileId=IMG_5401.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5401.JPG' ALT='IMG_5401.JPG'><BR>IMG_5401.JPG<br>139.93 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5401.JPG' ALT='IMG_5401.JPG'>IMG_5401.JPG</a></div></td>
<td><A ID='IMG_5403.JPG' href='tassie1.php?fileId=IMG_5403.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5403.JPG' ALT='IMG_5403.JPG'><BR>IMG_5403.JPG<br>125.88 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5403.JPG' ALT='IMG_5403.JPG'>IMG_5403.JPG</a></div></td>
<td><A ID='IMG_5405.JPG' href='tassie1.php?fileId=IMG_5405.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5405.JPG' ALT='IMG_5405.JPG'><BR>IMG_5405.JPG<br>115.65 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5405.JPG' ALT='IMG_5405.JPG'>IMG_5405.JPG</a></div></td>
<td><A ID='IMG_5406.JPG' href='tassie1.php?fileId=IMG_5406.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5406.JPG' ALT='IMG_5406.JPG'><BR>IMG_5406.JPG<br>67.13 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5406.JPG' ALT='IMG_5406.JPG'>IMG_5406.JPG</a></div></td>
<td><A ID='IMG_5407.JPG' href='tassie1.php?fileId=IMG_5407.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5407.JPG' ALT='IMG_5407.JPG'><BR>IMG_5407.JPG<br>86.94 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5407.JPG' ALT='IMG_5407.JPG'>IMG_5407.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5410.JPG' href='tassie1.php?fileId=IMG_5410.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5410.JPG' ALT='IMG_5410.JPG'><BR>IMG_5410.JPG<br>126.03 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5410.JPG' ALT='IMG_5410.JPG'>IMG_5410.JPG</a></div></td>
<td><A ID='IMG_5415.JPG' href='tassie1.php?fileId=IMG_5415.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5415.JPG' ALT='IMG_5415.JPG'><BR>IMG_5415.JPG<br>134.57 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5415.JPG' ALT='IMG_5415.JPG'>IMG_5415.JPG</a></div></td>
<td><A ID='IMG_5416.JPG' href='tassie1.php?fileId=IMG_5416.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5416.JPG' ALT='IMG_5416.JPG'><BR>IMG_5416.JPG<br>73.16 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5416.JPG' ALT='IMG_5416.JPG'>IMG_5416.JPG</a></div></td>
<td><A ID='IMG_5423.JPG' href='tassie1.php?fileId=IMG_5423.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5423.JPG' ALT='IMG_5423.JPG'><BR>IMG_5423.JPG<br>74.6 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5423.JPG' ALT='IMG_5423.JPG'>IMG_5423.JPG</a></div></td>
<td><A ID='IMG_5431.JPG' href='tassie1.php?fileId=IMG_5431.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5431.JPG' ALT='IMG_5431.JPG'><BR>IMG_5431.JPG<br>77.91 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5431.JPG' ALT='IMG_5431.JPG'>IMG_5431.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5434.JPG' href='tassie1.php?fileId=IMG_5434.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5434.JPG' ALT='IMG_5434.JPG'><BR>IMG_5434.JPG<br>111.28 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5434.JPG' ALT='IMG_5434.JPG'>IMG_5434.JPG</a></div></td>
<td><A ID='IMG_5436.JPG' href='tassie1.php?fileId=IMG_5436.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5436.JPG' ALT='IMG_5436.JPG'><BR>IMG_5436.JPG<br>63.15 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5436.JPG' ALT='IMG_5436.JPG'>IMG_5436.JPG</a></div></td>
<td><A ID='IMG_5437.JPG' href='tassie1.php?fileId=IMG_5437.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5437.JPG' ALT='IMG_5437.JPG'><BR>IMG_5437.JPG<br>112.78 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5437.JPG' ALT='IMG_5437.JPG'>IMG_5437.JPG</a></div></td>
<td><A ID='IMG_5440.JPG' href='tassie1.php?fileId=IMG_5440.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5440.JPG' ALT='IMG_5440.JPG'><BR>IMG_5440.JPG<br>91.02 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5440.JPG' ALT='IMG_5440.JPG'>IMG_5440.JPG</a></div></td>
<td><A ID='IMG_5444.JPG' href='tassie1.php?fileId=IMG_5444.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5444.JPG' ALT='IMG_5444.JPG'><BR>IMG_5444.JPG<br>88.85 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5444.JPG' ALT='IMG_5444.JPG'>IMG_5444.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5448.JPG' href='tassie1.php?fileId=IMG_5448.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5448.JPG' ALT='IMG_5448.JPG'><BR>IMG_5448.JPG<br>80.97 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5448.JPG' ALT='IMG_5448.JPG'>IMG_5448.JPG</a></div></td>
<td><A ID='IMG_5451.JPG' href='tassie1.php?fileId=IMG_5451.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5451.JPG' ALT='IMG_5451.JPG'><BR>IMG_5451.JPG<br>91.27 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5451.JPG' ALT='IMG_5451.JPG'>IMG_5451.JPG</a></div></td>
<td><A ID='IMG_5452.JPG' href='tassie1.php?fileId=IMG_5452.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5452.JPG' ALT='IMG_5452.JPG'><BR>IMG_5452.JPG<br>83.58 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5452.JPG' ALT='IMG_5452.JPG'>IMG_5452.JPG</a></div></td>
<td><A ID='IMG_5453.JPG' href='tassie1.php?fileId=IMG_5453.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5453.JPG' ALT='IMG_5453.JPG'><BR>IMG_5453.JPG<br>85.94 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5453.JPG' ALT='IMG_5453.JPG'>IMG_5453.JPG</a></div></td>
<td><A ID='IMG_5456.JPG' href='tassie1.php?fileId=IMG_5456.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5456.JPG' ALT='IMG_5456.JPG'><BR>IMG_5456.JPG<br>81.32 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5456.JPG' ALT='IMG_5456.JPG'>IMG_5456.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5463.JPG' href='tassie1.php?fileId=IMG_5463.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5463.JPG' ALT='IMG_5463.JPG'><BR>IMG_5463.JPG<br>95.04 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5463.JPG' ALT='IMG_5463.JPG'>IMG_5463.JPG</a></div></td>
<td><A ID='IMG_5464.JPG' href='tassie1.php?fileId=IMG_5464.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5464.JPG' ALT='IMG_5464.JPG'><BR>IMG_5464.JPG<br>105.55 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5464.JPG' ALT='IMG_5464.JPG'>IMG_5464.JPG</a></div></td>
<td><A ID='IMG_5465.JPG' href='tassie1.php?fileId=IMG_5465.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5465.JPG' ALT='IMG_5465.JPG'><BR>IMG_5465.JPG<br>82.68 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5465.JPG' ALT='IMG_5465.JPG'>IMG_5465.JPG</a></div></td>
<td><A ID='IMG_5471.JPG' href='tassie1.php?fileId=IMG_5471.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5471.JPG' ALT='IMG_5471.JPG'><BR>IMG_5471.JPG<br>121.78 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5471.JPG' ALT='IMG_5471.JPG'>IMG_5471.JPG</a></div></td>
<td><A ID='IMG_5473.JPG' href='tassie1.php?fileId=IMG_5473.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5473.JPG' ALT='IMG_5473.JPG'><BR>IMG_5473.JPG<br>126.12 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5473.JPG' ALT='IMG_5473.JPG'>IMG_5473.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5475.JPG' href='tassie1.php?fileId=IMG_5475.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5475.JPG' ALT='IMG_5475.JPG'><BR>IMG_5475.JPG<br>104.07 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5475.JPG' ALT='IMG_5475.JPG'>IMG_5475.JPG</a></div></td>
<td><A ID='IMG_5476.JPG' href='tassie1.php?fileId=IMG_5476.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5476.JPG' ALT='IMG_5476.JPG'><BR>IMG_5476.JPG<br>54.17 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5476.JPG' ALT='IMG_5476.JPG'>IMG_5476.JPG</a></div></td>
<td><A ID='IMG_5480.JPG' href='tassie1.php?fileId=IMG_5480.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5480.JPG' ALT='IMG_5480.JPG'><BR>IMG_5480.JPG<br>126.95 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5480.JPG' ALT='IMG_5480.JPG'>IMG_5480.JPG</a></div></td>
<td><A ID='IMG_5483.JPG' href='tassie1.php?fileId=IMG_5483.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5483.JPG' ALT='IMG_5483.JPG'><BR>IMG_5483.JPG<br>82.7 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5483.JPG' ALT='IMG_5483.JPG'>IMG_5483.JPG</a></div></td>
<td><A ID='IMG_5486.JPG' href='tassie1.php?fileId=IMG_5486.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5486.JPG' ALT='IMG_5486.JPG'><BR>IMG_5486.JPG<br>110.66 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5486.JPG' ALT='IMG_5486.JPG'>IMG_5486.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5491.JPG' href='tassie1.php?fileId=IMG_5491.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5491.JPG' ALT='IMG_5491.JPG'><BR>IMG_5491.JPG<br>66.46 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5491.JPG' ALT='IMG_5491.JPG'>IMG_5491.JPG</a></div></td>
<td><A ID='IMG_5493.JPG' href='tassie1.php?fileId=IMG_5493.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5493.JPG' ALT='IMG_5493.JPG'><BR>IMG_5493.JPG<br>53.46 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5493.JPG' ALT='IMG_5493.JPG'>IMG_5493.JPG</a></div></td>
<td><A ID='IMG_5498.JPG' href='tassie1.php?fileId=IMG_5498.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5498.JPG' ALT='IMG_5498.JPG'><BR>IMG_5498.JPG<br>54.61 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5498.JPG' ALT='IMG_5498.JPG'>IMG_5498.JPG</a></div></td>
<td><A ID='IMG_5503.JPG' href='tassie1.php?fileId=IMG_5503.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5503.JPG' ALT='IMG_5503.JPG'><BR>IMG_5503.JPG<br>62.28 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5503.JPG' ALT='IMG_5503.JPG'>IMG_5503.JPG</a></div></td>
<td><A ID='IMG_5504.JPG' href='tassie1.php?fileId=IMG_5504.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5504.JPG' ALT='IMG_5504.JPG'><BR>IMG_5504.JPG<br>66.79 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5504.JPG' ALT='IMG_5504.JPG'>IMG_5504.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5505.JPG' href='tassie1.php?fileId=IMG_5505.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5505.JPG' ALT='IMG_5505.JPG'><BR>IMG_5505.JPG<br>80.88 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5505.JPG' ALT='IMG_5505.JPG'>IMG_5505.JPG</a></div></td>
<td><A ID='IMG_5507.JPG' href='tassie1.php?fileId=IMG_5507.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5507.JPG' ALT='IMG_5507.JPG'><BR>IMG_5507.JPG<br>86.68 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5507.JPG' ALT='IMG_5507.JPG'>IMG_5507.JPG</a></div></td>
<td><A ID='IMG_5519.JPG' href='tassie1.php?fileId=IMG_5519.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5519.JPG' ALT='IMG_5519.JPG'><BR>IMG_5519.JPG<br>71.69 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5519.JPG' ALT='IMG_5519.JPG'>IMG_5519.JPG</a></div></td>
<td><A ID='IMG_5520.JPG' href='tassie1.php?fileId=IMG_5520.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5520.JPG' ALT='IMG_5520.JPG'><BR>IMG_5520.JPG<br>67.55 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5520.JPG' ALT='IMG_5520.JPG'>IMG_5520.JPG</a></div></td>
<td><A ID='IMG_5523.JPG' href='tassie1.php?fileId=IMG_5523.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5523.JPG' ALT='IMG_5523.JPG'><BR>IMG_5523.JPG<br>62.67 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5523.JPG' ALT='IMG_5523.JPG'>IMG_5523.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5524.JPG' href='tassie1.php?fileId=IMG_5524.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5524.JPG' ALT='IMG_5524.JPG'><BR>IMG_5524.JPG<br>65.12 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5524.JPG' ALT='IMG_5524.JPG'>IMG_5524.JPG</a></div></td>
<td><A ID='IMG_5525.JPG' href='tassie1.php?fileId=IMG_5525.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5525.JPG' ALT='IMG_5525.JPG'><BR>IMG_5525.JPG<br>78.74 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5525.JPG' ALT='IMG_5525.JPG'>IMG_5525.JPG</a></div></td>
<td><A ID='IMG_5529.JPG' href='tassie1.php?fileId=IMG_5529.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5529.JPG' ALT='IMG_5529.JPG'><BR>IMG_5529.JPG<br>47.71 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5529.JPG' ALT='IMG_5529.JPG'>IMG_5529.JPG</a></div></td>
<td><A ID='IMG_5531.JPG' href='tassie1.php?fileId=IMG_5531.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5531.JPG' ALT='IMG_5531.JPG'><BR>IMG_5531.JPG<br>98.07 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5531.JPG' ALT='IMG_5531.JPG'>IMG_5531.JPG</a></div></td>
<td><A ID='IMG_5532.JPG' href='tassie1.php?fileId=IMG_5532.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5532.JPG' ALT='IMG_5532.JPG'><BR>IMG_5532.JPG<br>50.74 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5532.JPG' ALT='IMG_5532.JPG'>IMG_5532.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5535.JPG' href='tassie1.php?fileId=IMG_5535.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5535.JPG' ALT='IMG_5535.JPG'><BR>IMG_5535.JPG<br>83.73 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5535.JPG' ALT='IMG_5535.JPG'>IMG_5535.JPG</a></div></td>
<td><A ID='IMG_5537.JPG' href='tassie1.php?fileId=IMG_5537.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5537.JPG' ALT='IMG_5537.JPG'><BR>IMG_5537.JPG<br>91.18 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5537.JPG' ALT='IMG_5537.JPG'>IMG_5537.JPG</a></div></td>
<td><A ID='IMG_5549.JPG' href='tassie1.php?fileId=IMG_5549.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5549.JPG' ALT='IMG_5549.JPG'><BR>IMG_5549.JPG<br>69.86 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5549.JPG' ALT='IMG_5549.JPG'>IMG_5549.JPG</a></div></td>
<td><A ID='IMG_5558.JPG' href='tassie1.php?fileId=IMG_5558.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5558.JPG' ALT='IMG_5558.JPG'><BR>IMG_5558.JPG<br>99.9 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5558.JPG' ALT='IMG_5558.JPG'>IMG_5558.JPG</a></div></td>
<td><A ID='IMG_5561.JPG' href='tassie1.php?fileId=IMG_5561.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5561.JPG' ALT='IMG_5561.JPG'><BR>IMG_5561.JPG<br>80.8 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5561.JPG' ALT='IMG_5561.JPG'>IMG_5561.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5562.JPG' href='tassie1.php?fileId=IMG_5562.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5562.JPG' ALT='IMG_5562.JPG'><BR>IMG_5562.JPG<br>51.17 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5562.JPG' ALT='IMG_5562.JPG'>IMG_5562.JPG</a></div></td>
<td><A ID='IMG_5566.JPG' href='tassie1.php?fileId=IMG_5566.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5566.JPG' ALT='IMG_5566.JPG'><BR>IMG_5566.JPG<br>82.79 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5566.JPG' ALT='IMG_5566.JPG'>IMG_5566.JPG</a></div></td>
<td><A ID='IMG_5568.JPG' href='tassie1.php?fileId=IMG_5568.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5568.JPG' ALT='IMG_5568.JPG'><BR>IMG_5568.JPG<br>78.85 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5568.JPG' ALT='IMG_5568.JPG'>IMG_5568.JPG</a></div></td>
<td><A ID='IMG_5576.JPG' href='tassie1.php?fileId=IMG_5576.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5576.JPG' ALT='IMG_5576.JPG'><BR>IMG_5576.JPG<br>76.27 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5576.JPG' ALT='IMG_5576.JPG'>IMG_5576.JPG</a></div></td>
<td><A ID='IMG_5577.JPG' href='tassie1.php?fileId=IMG_5577.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5577.JPG' ALT='IMG_5577.JPG'><BR>IMG_5577.JPG<br>112.51 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5577.JPG' ALT='IMG_5577.JPG'>IMG_5577.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5581.JPG' href='tassie1.php?fileId=IMG_5581.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5581.JPG' ALT='IMG_5581.JPG'><BR>IMG_5581.JPG<br>86.6 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5581.JPG' ALT='IMG_5581.JPG'>IMG_5581.JPG</a></div></td>
<td><A ID='IMG_5582.JPG' href='tassie1.php?fileId=IMG_5582.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5582.JPG' ALT='IMG_5582.JPG'><BR>IMG_5582.JPG<br>91.46 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5582.JPG' ALT='IMG_5582.JPG'>IMG_5582.JPG</a></div></td>
<td><A ID='IMG_5583.JPG' href='tassie1.php?fileId=IMG_5583.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5583.JPG' ALT='IMG_5583.JPG'><BR>IMG_5583.JPG<br>90.81 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5583.JPG' ALT='IMG_5583.JPG'>IMG_5583.JPG</a></div></td>
<td><A ID='IMG_5585.JPG' href='tassie1.php?fileId=IMG_5585.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5585.JPG' ALT='IMG_5585.JPG'><BR>IMG_5585.JPG<br>76.4 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5585.JPG' ALT='IMG_5585.JPG'>IMG_5585.JPG</a></div></td>
<td><A ID='IMG_5588.JPG' href='tassie1.php?fileId=IMG_5588.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5588.JPG' ALT='IMG_5588.JPG'><BR>IMG_5588.JPG<br>77.69 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5588.JPG' ALT='IMG_5588.JPG'>IMG_5588.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5589.JPG' href='tassie1.php?fileId=IMG_5589.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5589.JPG' ALT='IMG_5589.JPG'><BR>IMG_5589.JPG<br>36.93 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5589.JPG' ALT='IMG_5589.JPG'>IMG_5589.JPG</a></div></td>
<td><A ID='IMG_5594.JPG' href='tassie1.php?fileId=IMG_5594.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5594.JPG' ALT='IMG_5594.JPG'><BR>IMG_5594.JPG<br>81.11 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5594.JPG' ALT='IMG_5594.JPG'>IMG_5594.JPG</a></div></td>
<td><A ID='IMG_5596.JPG' href='tassie1.php?fileId=IMG_5596.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5596.JPG' ALT='IMG_5596.JPG'><BR>IMG_5596.JPG<br>63.6 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5596.JPG' ALT='IMG_5596.JPG'>IMG_5596.JPG</a></div></td>
<td><A ID='IMG_5597.JPG' href='tassie1.php?fileId=IMG_5597.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5597.JPG' ALT='IMG_5597.JPG'><BR>IMG_5597.JPG<br>82.63 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5597.JPG' ALT='IMG_5597.JPG'>IMG_5597.JPG</a></div></td>
<td><A ID='IMG_5598.JPG' href='tassie1.php?fileId=IMG_5598.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5598.JPG' ALT='IMG_5598.JPG'><BR>IMG_5598.JPG<br>89.27 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5598.JPG' ALT='IMG_5598.JPG'>IMG_5598.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5601.JPG' href='tassie1.php?fileId=IMG_5601.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5601.JPG' ALT='IMG_5601.JPG'><BR>IMG_5601.JPG<br>56.91 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5601.JPG' ALT='IMG_5601.JPG'>IMG_5601.JPG</a></div></td>
<td><A ID='IMG_5603.JPG' href='tassie1.php?fileId=IMG_5603.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5603.JPG' ALT='IMG_5603.JPG'><BR>IMG_5603.JPG<br>33.77 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5603.JPG' ALT='IMG_5603.JPG'>IMG_5603.JPG</a></div></td>
<td><A ID='IMG_5604.JPG' href='tassie1.php?fileId=IMG_5604.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5604.JPG' ALT='IMG_5604.JPG'><BR>IMG_5604.JPG<br>48.82 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5604.JPG' ALT='IMG_5604.JPG'>IMG_5604.JPG</a></div></td>
<td><A ID='IMG_5617.JPG' href='tassie1.php?fileId=IMG_5617.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5617.JPG' ALT='IMG_5617.JPG'><BR>IMG_5617.JPG<br>59.01 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5617.JPG' ALT='IMG_5617.JPG'>IMG_5617.JPG</a></div></td>
<td><A ID='IMG_5620.JPG' href='tassie1.php?fileId=IMG_5620.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5620.JPG' ALT='IMG_5620.JPG'><BR>IMG_5620.JPG<br>83.87 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5620.JPG' ALT='IMG_5620.JPG'>IMG_5620.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5628.JPG' href='tassie1.php?fileId=IMG_5628.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5628.JPG' ALT='IMG_5628.JPG'><BR>IMG_5628.JPG<br>115.42 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5628.JPG' ALT='IMG_5628.JPG'>IMG_5628.JPG</a></div></td>
<td><A ID='IMG_5630.JPG' href='tassie1.php?fileId=IMG_5630.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5630.JPG' ALT='IMG_5630.JPG'><BR>IMG_5630.JPG<br>74.29 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5630.JPG' ALT='IMG_5630.JPG'>IMG_5630.JPG</a></div></td>
<td><A ID='IMG_5631.JPG' href='tassie1.php?fileId=IMG_5631.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5631.JPG' ALT='IMG_5631.JPG'><BR>IMG_5631.JPG<br>64.98 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5631.JPG' ALT='IMG_5631.JPG'>IMG_5631.JPG</a></div></td>
<td><A ID='IMG_5636.JPG' href='tassie1.php?fileId=IMG_5636.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5636.JPG' ALT='IMG_5636.JPG'><BR>IMG_5636.JPG<br>60.39 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5636.JPG' ALT='IMG_5636.JPG'>IMG_5636.JPG</a></div></td>
<td><A ID='IMG_5639.JPG' href='tassie1.php?fileId=IMG_5639.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5639.JPG' ALT='IMG_5639.JPG'><BR>IMG_5639.JPG<br>52.6 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5639.JPG' ALT='IMG_5639.JPG'>IMG_5639.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_5642.JPG' href='tassie1.php?fileId=IMG_5642.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060101/IMG_5642.JPG' ALT='IMG_5642.JPG'><BR>IMG_5642.JPG<br>41.41 KB</a><div class='inv'><br><a href='./images/20060101/IMG_5642.JPG' ALT='IMG_5642.JPG'>IMG_5642.JPG</a></div></td>
</tr>
</table>	</div>
</div>
</body>
</html>