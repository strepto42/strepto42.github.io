<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - 23/9/2005 - The West Coast</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="The West Coast">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="Greetings from a Bum" href='greetingsfromabum.php'>29/4/2005</a></li>
<li><a title="Onward" href='onward.php'>2/5/2005</a></li>
<li><a title="It's a tough life (pt 1: Bundaberg, Agnes Water and 1770)" href='itsatoughlife1.php'>17/5/2005</a></li>
<li><a title="It's a tough life (pt 2: Rockhampton, Emu Park and Great Keppel Island)" href='itsatoughlife2.php'>23/5/2005</a></li>
<li><a title="There and Back Again - a Yo-yo's Tale" href='thereandbackagain.php'>18/6/2005</a></li>
<li><a title="Platypi and Grey Nomads" href='platypiandgreynomads.php'>24/6/2005</a></li>
<li><a title="Blowing Bubbles in a Watery Tomb" href='blowingbubbles.php'>1/7/2005</a></li>
<li><a title="Pieces of History" href='piecesofhistory.php'>8/7/2005</a></li>
<li><a title="Walks and Waterfalls" href='walksandwaterfalls.php'>15/7/2005</a></li>
<li><a title="Mission to Tribulation" href='missiontotribulation.php'>22/7/2005</a></li>
<li><a title="Levity, Limestone and Lava" href='levitylimestoneandlava.php'>29/7/2005</a></li>
<li><a title="Into the Never Never" href='intothenevernever.php'>5/8/2005</a></li>
<li><a title="Slowing the pace in Darwin" href='slowingthepaceindarwin.php'>12/8/2005</a></li>
<li><a title="Blistering Barnacles and Leaping Lizards" href='leapinglizards.php'>19/8/2005</a></li>
<li><a title="Kakadu and Litchfield" href='kakadu.php'>26/8/2005</a></li>
<li><a title="Legacies of War" href='legaciesofwar.php'>2/9/2005</a></li>
<li><a title="Go West" href='gowest.php'>10/9/2005</a></li>
<li><a title="Things from Above" href='thingsfromabove.php'>16/9/2005</a></li>
<li><div class='activemenu'>23/9/2005</div></li>
<li><a title="Reefs and Red Dust" href='reefsandreddust.php'>30/9/2005</a></li>
<li><a title="The Pilbara" href='pilbara.php'>7/10/2005</a></li>
<li><a title="Paradise with a Headwind" href='paradisewithaheadwind.php'>14/10/2005</a></li>
<li><a title="Down the Coral Coast" href='downthecoralcoast.php'>21/10/2005</a></li>
<li><a title="Pinnacles and Pinnipeds" href='pinnaclesandpinnipeds.php'>28/10/2005</a></li>
<li><a title="A week in Perth" href='perth.php'>4/11/2005</a></li>
<li><a title="The Southwest (from Above and Below)" href='thesouthwest.php'>11/11/2005</a></li>
<li><a title="More Heights and Depths" href='moreheightsanddepths.php'>18/11/2005</a></li>
<li><a title="Across the Nullarbor (and a bit beyond)" href='nullarbor.php'>25/11/2005</a></li>
<li><a title="Double Whammy" href='doublewhammy.php'>9/12/2005</a></li>
<li><a title="Two Cities" href='twocities.php'>19/12/2005</a></li>
<li><a title="Tassie - Part 1" href='tassie1.php'>1/1/2006</a></li>
<li><a title="Tassie - Part 2" href='tassie2.php'>7/1/2006</a></li>
<li><a title="Full Circle" href='fullcircle.php'>26/1/2006</a></li>
<li><a title="The Wrap Up" href='thewrapup.php'>23/3/2006</a></li>
<li> </li><br><li>Or go back to:</li><li><a title='Travelouges and blogs from my trip around Australia' href="nerdseyeview.php">Nerd's Eye View</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>23/9/2005</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Travel stories and pictures' href="travel.php">Travelogues</a> > <a title='Travelouges and blogs from my trip around Australia' href="nerdseyeview.php">Nerd's Eye View</a> > <a title='The West Coast' href="thewestcoast.php">23/9/2005</a>
<br><br>		


<h1>The West Coast</h1>

<a href="images/maps/Map050923.gif"><img src="images/maps/Map050923_sm.gif" align="right"></a>

<p>Another Friday, another email. This time it's from the town of Derby, sensibly pronounced phonetically, rather than "darby". I've finally made it to the west coast. It's a whole new ocean out there!</p>

<p>Anyway it's been another week of mixed activity. I spent last Friday night at the Crossing Hotel in Fitzroy Crossing. It's the Kimberley's oldest pub, and boasts a certain amount of local character.</p>

<p>In years gone by the floor was dirt, but they've graduated to concrete now. It's pretty rough and rowdy there, but there is a caravan park attached, and a restaurant in which I had the nicest Nasi Goreng of my life.</p>

<p>I spent the next day at nearby Geikie Gorge, a great spot where the river has cut through an ancient limestone deposit (formerly a coral reef several hundred million years ago), leaving spectacular cliffs. There is a natural sandbar after the gorge, so the water gets trapped there in the dry season and it's quite green and lush.</p>

<p>I walked around for half the day, in scorching heat, but there was no hurry, and the scenery was worth it. I spent quite a while sitting by a billabong, under a tree (which was possibly even a Coolabah as they were growing there) watching little birds play.</p>

<p>Later in the arvo I took a cruise up the gorge with the usual collection of oldies. It goes a little further than you can get on foot and was quite pleasant, and I finally got to see some freshwater crocodiles. They're extremely cute, with smaller noses and teeth than salties.</p>

<p>The gorge is also extra spectacular at this time of day. The white/black delineation is caused by the seasonal flooding scouring the limestone clean; the level of the colour change indicates the average wet season flood level.</p>

<p>The next day, I pushed on to Broome. The drive was largely uninteresting, and in the end, so was Broome.</p>

<p>I'd been looking forward to it, but it didn't really live up to expectations. Sort of a mixed vibe there; I think some locals are worried that it's becoming like Byron Bay, to use a loose analogy.</p>

<p>I think matters weren't helped by the fact that the backpackers I was staying at had a really unpleasant, decaying and dismal feel about it. Broome's Last Resort was it's name, and I would say that should you visit, it should be just that re accommodation choice.</p>

<p>The chief highlight though, of my visit to Broome, was not the random festival that was being held there (the parade of which gave me a few nice photos), nor was it the azure water of Cable Beach (although that was rather pretty). It was of course that Jana flew over to meet me there.</p>

<p>We'll be travelling together for the next few months, and it will be lovely (indeed, it has already been) to have someone around to share the experiences with.</p>

<p>The first thing we did (pretty much) was get out of the dismal backpackers, and head to Cable Beach for a night.</p>

<p>We also headed to the Monsoon Hotel one night to witness the famous "staircase to the moon", a local-ish phenomenon where the full moon rises over the tidal mudflats, and the resulting reflections create a "staircase effect" (in theory).</p>

<p>The reality turned out to be somewhat of a non-event, due to clouds (and, I think, a general over-hype), but it was relatively pretty (the moon was a lovely reddish colour).</p>

<p>It was also amusing from another point of view, as we got to watch crowds of idiots experience the event second-hand through the pallid glow of their digital camera screens. Flash photography also abounded, which is always highly effective when shooting a subject over 385,000kms away.</p>

<p>After that diversion, it was time to get out of Broome itself and move on to the Broome Bird Observatory for a night and day.</p>

<p>As some of you might have noticed, I've developed a certain interest in birds over the months, and whilst I'm not in any danger of becoming a serious birder, I do rather enjoy watching and taking photos of them. Having Jana here I can now generally find out what they are straight away too. :)</p>

<p>The time at the bird observatory was quite nice; the bay it's located in (just south of Broome) is very tidal and has the same amazingly coloured water as Cable Beach.</p>

<p>Of course, there are also countless birds there, of many varieties. We got some really nice pictures, and generally had a good time, despite a walking trail snafu that caused us to miss the mangroves.</p>

<p>We've moved on now to Derby, with it's enormous tidal mudflats and famous sunsets, one of which we sat and watched this evening (a sunset, not a mudflat). It was pretty nice, but not amazing (I'll give it a 7/10), but of course I'm spoiled for sunsets these days. A few more clouds about and it would have been a 9.</p>

<p>We also had a pretty damn nice seafood dinner on the jetty overlooking the water. If you come to Derby, I'd recommend it.</p>

<p>Apart from that, there's not much in town, so from here we'll head up the Gibb River Road (from the other end) for a few kms, and loop back down through some nice Kimberley spots before heading off down the coast on the long run to the southern continent; stay tuned next week!</p>

<p>Pics from this week are:</p>
<!-- 
<ul>
<li><a href="?fileId=IMG_9254.JPG">Arty Bark</a></li>
<li><a href="?fileId=IMG_9343.JPG">The Tubbs Farquhar of the freshie world</a></li>
<li><a href="?fileId=IMG_9371.JPG">Geikie Gorge</a></li>
<li><a href="?fileId=IMG_9568.JPG">A cute Double-barred Finch</a></li>
<li><a href="?fileId=IMG_9621.JPG">Roebuck Bay, Broome Bird Observatory</a></li>
</ul>
 -->
<table width="800">
	<tr>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=IMG_9254.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20050923/IMG_9254.JPG' ALT='Arty Bark'><BR>Arty Bark</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=IMG_9343.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20050923/IMG_9343.JPG' ALT='The Tubbs Farquhar of the freshie world'><BR>The Tubbs Farquhar of the freshie world</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=IMG_9371.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20050923/IMG_9371.JPG' ALT='Geikie Gorge'><BR>Geikie Gorge</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=IMG_9568.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20050923/IMG_9568.JPG' ALT='A cute Double-barred Finch'><BR>A cute Double-barred Finch</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=IMG_9621.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20050923/IMG_9621.JPG' ALT='Roebuck Bay, Broome Bird Observatory'><BR>Roebuck Bay, Broome Bird Observatory</a>
	</td>
	</tr>
</table>


<br><br>
All images in this gallery:<br>
<table width='800'>
<tr>
</tr>
<tr><td><A ID='IMG_9201.JPG' href='thewestcoast.php?fileId=IMG_9201.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050923/IMG_9201.JPG' ALT='IMG_9201.JPG'><BR>IMG_9201.JPG<br>77.12 KB</a><div class='inv'><br><a href='./images/20050923/IMG_9201.JPG' ALT='IMG_9201.JPG'>IMG_9201.JPG</a></div></td>
<td><A ID='IMG_9205.JPG' href='thewestcoast.php?fileId=IMG_9205.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050923/IMG_9205.JPG' ALT='IMG_9205.JPG'><BR>IMG_9205.JPG<br>21.88 KB</a><div class='inv'><br><a href='./images/20050923/IMG_9205.JPG' ALT='IMG_9205.JPG'>IMG_9205.JPG</a></div></td>
<td><A ID='IMG_9208.JPG' href='thewestcoast.php?fileId=IMG_9208.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050923/IMG_9208.JPG' ALT='IMG_9208.JPG'><BR>IMG_9208.JPG<br>65.86 KB</a><div class='inv'><br><a href='./images/20050923/IMG_9208.JPG' ALT='IMG_9208.JPG'>IMG_9208.JPG</a></div></td>
<td><A ID='IMG_9209.JPG' href='thewestcoast.php?fileId=IMG_9209.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050923/IMG_9209.JPG' ALT='IMG_9209.JPG'><BR>IMG_9209.JPG<br>51.26 KB</a><div class='inv'><br><a href='./images/20050923/IMG_9209.JPG' ALT='IMG_9209.JPG'>IMG_9209.JPG</a></div></td>
<td><A ID='IMG_9211.JPG' href='thewestcoast.php?fileId=IMG_9211.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050923/IMG_9211.JPG' ALT='IMG_9211.JPG'><BR>IMG_9211.JPG<br>56.88 KB</a><div class='inv'><br><a href='./images/20050923/IMG_9211.JPG' ALT='IMG_9211.JPG'>IMG_9211.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_9212.JPG' href='thewestcoast.php?fileId=IMG_9212.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050923/IMG_9212.JPG' ALT='IMG_9212.JPG'><BR>IMG_9212.JPG<br>91.33 KB</a><div class='inv'><br><a href='./images/20050923/IMG_9212.JPG' ALT='IMG_9212.JPG'>IMG_9212.JPG</a></div></td>
<td><A ID='IMG_9254.JPG' href='thewestcoast.php?fileId=IMG_9254.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050923/IMG_9254.JPG' ALT='IMG_9254.JPG'><BR>IMG_9254.JPG<br>69.7 KB</a><div class='inv'><br><a href='./images/20050923/IMG_9254.JPG' ALT='IMG_9254.JPG'>IMG_9254.JPG</a></div></td>
<td><A ID='IMG_9263.JPG' href='thewestcoast.php?fileId=IMG_9263.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050923/IMG_9263.JPG' ALT='IMG_9263.JPG'><BR>IMG_9263.JPG<br>88.31 KB</a><div class='inv'><br><a href='./images/20050923/IMG_9263.JPG' ALT='IMG_9263.JPG'>IMG_9263.JPG</a></div></td>
<td><A ID='IMG_9279.JPG' href='thewestcoast.php?fileId=IMG_9279.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050923/IMG_9279.JPG' ALT='IMG_9279.JPG'><BR>IMG_9279.JPG<br>54.41 KB</a><div class='inv'><br><a href='./images/20050923/IMG_9279.JPG' ALT='IMG_9279.JPG'>IMG_9279.JPG</a></div></td>
<td><A ID='IMG_9280.JPG' href='thewestcoast.php?fileId=IMG_9280.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050923/IMG_9280.JPG' ALT='IMG_9280.JPG'><BR>IMG_9280.JPG<br>80.96 KB</a><div class='inv'><br><a href='./images/20050923/IMG_9280.JPG' ALT='IMG_9280.JPG'>IMG_9280.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_9281.JPG' href='thewestcoast.php?fileId=IMG_9281.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050923/IMG_9281.JPG' ALT='IMG_9281.JPG'><BR>IMG_9281.JPG<br>93.69 KB</a><div class='inv'><br><a href='./images/20050923/IMG_9281.JPG' ALT='IMG_9281.JPG'>IMG_9281.JPG</a></div></td>
<td><A ID='IMG_9283.JPG' href='thewestcoast.php?fileId=IMG_9283.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050923/IMG_9283.JPG' ALT='IMG_9283.JPG'><BR>IMG_9283.JPG<br>63.4 KB</a><div class='inv'><br><a href='./images/20050923/IMG_9283.JPG' ALT='IMG_9283.JPG'>IMG_9283.JPG</a></div></td>
<td><A ID='IMG_9285.JPG' href='thewestcoast.php?fileId=IMG_9285.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050923/IMG_9285.JPG' ALT='IMG_9285.JPG'><BR>IMG_9285.JPG<br>84.66 KB</a><div class='inv'><br><a href='./images/20050923/IMG_9285.JPG' ALT='IMG_9285.JPG'>IMG_9285.JPG</a></div></td>
<td><A ID='IMG_9286.JPG' href='thewestcoast.php?fileId=IMG_9286.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050923/IMG_9286.JPG' ALT='IMG_9286.JPG'><BR>IMG_9286.JPG<br>113.62 KB</a><div class='inv'><br><a href='./images/20050923/IMG_9286.JPG' ALT='IMG_9286.JPG'>IMG_9286.JPG</a></div></td>
<td><A ID='IMG_9287.JPG' href='thewestcoast.php?fileId=IMG_9287.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050923/IMG_9287.JPG' ALT='IMG_9287.JPG'><BR>IMG_9287.JPG<br>94.42 KB</a><div class='inv'><br><a href='./images/20050923/IMG_9287.JPG' ALT='IMG_9287.JPG'>IMG_9287.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_9289.JPG' href='thewestcoast.php?fileId=IMG_9289.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050923/IMG_9289.JPG' ALT='IMG_9289.JPG'><BR>IMG_9289.JPG<br>60.83 KB</a><div class='inv'><br><a href='./images/20050923/IMG_9289.JPG' ALT='IMG_9289.JPG'>IMG_9289.JPG</a></div></td>
<td><A ID='IMG_9290.JPG' href='thewestcoast.php?fileId=IMG_9290.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050923/IMG_9290.JPG' ALT='IMG_9290.JPG'><BR>IMG_9290.JPG<br>77.02 KB</a><div class='inv'><br><a href='./images/20050923/IMG_9290.JPG' ALT='IMG_9290.JPG'>IMG_9290.JPG</a></div></td>
<td><A ID='IMG_9301.JPG' href='thewestcoast.php?fileId=IMG_9301.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050923/IMG_9301.JPG' ALT='IMG_9301.JPG'><BR>IMG_9301.JPG<br>32.68 KB</a><div class='inv'><br><a href='./images/20050923/IMG_9301.JPG' ALT='IMG_9301.JPG'>IMG_9301.JPG</a></div></td>
<td><A ID='IMG_9302.JPG' href='thewestcoast.php?fileId=IMG_9302.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050923/IMG_9302.JPG' ALT='IMG_9302.JPG'><BR>IMG_9302.JPG<br>86.08 KB</a><div class='inv'><br><a href='./images/20050923/IMG_9302.JPG' ALT='IMG_9302.JPG'>IMG_9302.JPG</a></div></td>
<td><A ID='IMG_9303.JPG' href='thewestcoast.php?fileId=IMG_9303.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050923/IMG_9303.JPG' ALT='IMG_9303.JPG'><BR>IMG_9303.JPG<br>78.2 KB</a><div class='inv'><br><a href='./images/20050923/IMG_9303.JPG' ALT='IMG_9303.JPG'>IMG_9303.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_9304.JPG' href='thewestcoast.php?fileId=IMG_9304.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050923/IMG_9304.JPG' ALT='IMG_9304.JPG'><BR>IMG_9304.JPG<br>35.5 KB</a><div class='inv'><br><a href='./images/20050923/IMG_9304.JPG' ALT='IMG_9304.JPG'>IMG_9304.JPG</a></div></td>
<td><A ID='IMG_9317.JPG' href='thewestcoast.php?fileId=IMG_9317.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050923/IMG_9317.JPG' ALT='IMG_9317.JPG'><BR>IMG_9317.JPG<br>96.51 KB</a><div class='inv'><br><a href='./images/20050923/IMG_9317.JPG' ALT='IMG_9317.JPG'>IMG_9317.JPG</a></div></td>
<td><A ID='IMG_9318.JPG' href='thewestcoast.php?fileId=IMG_9318.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050923/IMG_9318.JPG' ALT='IMG_9318.JPG'><BR>IMG_9318.JPG<br>100.69 KB</a><div class='inv'><br><a href='./images/20050923/IMG_9318.JPG' ALT='IMG_9318.JPG'>IMG_9318.JPG</a></div></td>
<td><A ID='IMG_9319.JPG' href='thewestcoast.php?fileId=IMG_9319.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050923/IMG_9319.JPG' ALT='IMG_9319.JPG'><BR>IMG_9319.JPG<br>102.83 KB</a><div class='inv'><br><a href='./images/20050923/IMG_9319.JPG' ALT='IMG_9319.JPG'>IMG_9319.JPG</a></div></td>
<td><A ID='IMG_9323.JPG' href='thewestcoast.php?fileId=IMG_9323.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050923/IMG_9323.JPG' ALT='IMG_9323.JPG'><BR>IMG_9323.JPG<br>79.24 KB</a><div class='inv'><br><a href='./images/20050923/IMG_9323.JPG' ALT='IMG_9323.JPG'>IMG_9323.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_9324.JPG' href='thewestcoast.php?fileId=IMG_9324.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050923/IMG_9324.JPG' ALT='IMG_9324.JPG'><BR>IMG_9324.JPG<br>60.71 KB</a><div class='inv'><br><a href='./images/20050923/IMG_9324.JPG' ALT='IMG_9324.JPG'>IMG_9324.JPG</a></div></td>
<td><A ID='IMG_9325.JPG' href='thewestcoast.php?fileId=IMG_9325.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050923/IMG_9325.JPG' ALT='IMG_9325.JPG'><BR>IMG_9325.JPG<br>89.96 KB</a><div class='inv'><br><a href='./images/20050923/IMG_9325.JPG' ALT='IMG_9325.JPG'>IMG_9325.JPG</a></div></td>
<td><A ID='IMG_9326.JPG' href='thewestcoast.php?fileId=IMG_9326.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050923/IMG_9326.JPG' ALT='IMG_9326.JPG'><BR>IMG_9326.JPG<br>64.83 KB</a><div class='inv'><br><a href='./images/20050923/IMG_9326.JPG' ALT='IMG_9326.JPG'>IMG_9326.JPG</a></div></td>
<td><A ID='IMG_9329.JPG' href='thewestcoast.php?fileId=IMG_9329.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050923/IMG_9329.JPG' ALT='IMG_9329.JPG'><BR>IMG_9329.JPG<br>76.9 KB</a><div class='inv'><br><a href='./images/20050923/IMG_9329.JPG' ALT='IMG_9329.JPG'>IMG_9329.JPG</a></div></td>
<td><A ID='IMG_9331.JPG' href='thewestcoast.php?fileId=IMG_9331.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050923/IMG_9331.JPG' ALT='IMG_9331.JPG'><BR>IMG_9331.JPG<br>75.45 KB</a><div class='inv'><br><a href='./images/20050923/IMG_9331.JPG' ALT='IMG_9331.JPG'>IMG_9331.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_9332.JPG' href='thewestcoast.php?fileId=IMG_9332.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050923/IMG_9332.JPG' ALT='IMG_9332.JPG'><BR>IMG_9332.JPG<br>87.29 KB</a><div class='inv'><br><a href='./images/20050923/IMG_9332.JPG' ALT='IMG_9332.JPG'>IMG_9332.JPG</a></div></td>
<td><A ID='IMG_9336.JPG' href='thewestcoast.php?fileId=IMG_9336.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050923/IMG_9336.JPG' ALT='IMG_9336.JPG'><BR>IMG_9336.JPG<br>76.87 KB</a><div class='inv'><br><a href='./images/20050923/IMG_9336.JPG' ALT='IMG_9336.JPG'>IMG_9336.JPG</a></div></td>
<td><A ID='IMG_9343.JPG' href='thewestcoast.php?fileId=IMG_9343.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050923/IMG_9343.JPG' ALT='IMG_9343.JPG'><BR>IMG_9343.JPG<br>82.59 KB</a><div class='inv'><br><a href='./images/20050923/IMG_9343.JPG' ALT='IMG_9343.JPG'>IMG_9343.JPG</a></div></td>
<td><A ID='IMG_9345.JPG' href='thewestcoast.php?fileId=IMG_9345.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050923/IMG_9345.JPG' ALT='IMG_9345.JPG'><BR>IMG_9345.JPG<br>86.98 KB</a><div class='inv'><br><a href='./images/20050923/IMG_9345.JPG' ALT='IMG_9345.JPG'>IMG_9345.JPG</a></div></td>
<td><A ID='IMG_9346.JPG' href='thewestcoast.php?fileId=IMG_9346.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050923/IMG_9346.JPG' ALT='IMG_9346.JPG'><BR>IMG_9346.JPG<br>92.3 KB</a><div class='inv'><br><a href='./images/20050923/IMG_9346.JPG' ALT='IMG_9346.JPG'>IMG_9346.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_9350.JPG' href='thewestcoast.php?fileId=IMG_9350.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050923/IMG_9350.JPG' ALT='IMG_9350.JPG'><BR>IMG_9350.JPG<br>68.88 KB</a><div class='inv'><br><a href='./images/20050923/IMG_9350.JPG' ALT='IMG_9350.JPG'>IMG_9350.JPG</a></div></td>
<td><A ID='IMG_9351.JPG' href='thewestcoast.php?fileId=IMG_9351.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050923/IMG_9351.JPG' ALT='IMG_9351.JPG'><BR>IMG_9351.JPG<br>59.12 KB</a><div class='inv'><br><a href='./images/20050923/IMG_9351.JPG' ALT='IMG_9351.JPG'>IMG_9351.JPG</a></div></td>
<td><A ID='IMG_9354.JPG' href='thewestcoast.php?fileId=IMG_9354.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050923/IMG_9354.JPG' ALT='IMG_9354.JPG'><BR>IMG_9354.JPG<br>80.48 KB</a><div class='inv'><br><a href='./images/20050923/IMG_9354.JPG' ALT='IMG_9354.JPG'>IMG_9354.JPG</a></div></td>
<td><A ID='IMG_9356.JPG' href='thewestcoast.php?fileId=IMG_9356.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050923/IMG_9356.JPG' ALT='IMG_9356.JPG'><BR>IMG_9356.JPG<br>58.56 KB</a><div class='inv'><br><a href='./images/20050923/IMG_9356.JPG' ALT='IMG_9356.JPG'>IMG_9356.JPG</a></div></td>
<td><A ID='IMG_9357.JPG' href='thewestcoast.php?fileId=IMG_9357.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050923/IMG_9357.JPG' ALT='IMG_9357.JPG'><BR>IMG_9357.JPG<br>53.71 KB</a><div class='inv'><br><a href='./images/20050923/IMG_9357.JPG' ALT='IMG_9357.JPG'>IMG_9357.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_9358.JPG' href='thewestcoast.php?fileId=IMG_9358.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050923/IMG_9358.JPG' ALT='IMG_9358.JPG'><BR>IMG_9358.JPG<br>63.52 KB</a><div class='inv'><br><a href='./images/20050923/IMG_9358.JPG' ALT='IMG_9358.JPG'>IMG_9358.JPG</a></div></td>
<td><A ID='IMG_9364.JPG' href='thewestcoast.php?fileId=IMG_9364.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050923/IMG_9364.JPG' ALT='IMG_9364.JPG'><BR>IMG_9364.JPG<br>72.96 KB</a><div class='inv'><br><a href='./images/20050923/IMG_9364.JPG' ALT='IMG_9364.JPG'>IMG_9364.JPG</a></div></td>
<td><A ID='IMG_9369.JPG' href='thewestcoast.php?fileId=IMG_9369.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050923/IMG_9369.JPG' ALT='IMG_9369.JPG'><BR>IMG_9369.JPG<br>101.78 KB</a><div class='inv'><br><a href='./images/20050923/IMG_9369.JPG' ALT='IMG_9369.JPG'>IMG_9369.JPG</a></div></td>
<td><A ID='IMG_9371.JPG' href='thewestcoast.php?fileId=IMG_9371.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050923/IMG_9371.JPG' ALT='IMG_9371.JPG'><BR>IMG_9371.JPG<br>69.34 KB</a><div class='inv'><br><a href='./images/20050923/IMG_9371.JPG' ALT='IMG_9371.JPG'>IMG_9371.JPG</a></div></td>
<td><A ID='IMG_9372.JPG' href='thewestcoast.php?fileId=IMG_9372.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050923/IMG_9372.JPG' ALT='IMG_9372.JPG'><BR>IMG_9372.JPG<br>93.71 KB</a><div class='inv'><br><a href='./images/20050923/IMG_9372.JPG' ALT='IMG_9372.JPG'>IMG_9372.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_9374.JPG' href='thewestcoast.php?fileId=IMG_9374.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050923/IMG_9374.JPG' ALT='IMG_9374.JPG'><BR>IMG_9374.JPG<br>109.38 KB</a><div class='inv'><br><a href='./images/20050923/IMG_9374.JPG' ALT='IMG_9374.JPG'>IMG_9374.JPG</a></div></td>
<td><A ID='IMG_9381.JPG' href='thewestcoast.php?fileId=IMG_9381.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050923/IMG_9381.JPG' ALT='IMG_9381.JPG'><BR>IMG_9381.JPG<br>123.59 KB</a><div class='inv'><br><a href='./images/20050923/IMG_9381.JPG' ALT='IMG_9381.JPG'>IMG_9381.JPG</a></div></td>
<td><A ID='IMG_9383.JPG' href='thewestcoast.php?fileId=IMG_9383.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050923/IMG_9383.JPG' ALT='IMG_9383.JPG'><BR>IMG_9383.JPG<br>75.74 KB</a><div class='inv'><br><a href='./images/20050923/IMG_9383.JPG' ALT='IMG_9383.JPG'>IMG_9383.JPG</a></div></td>
<td><A ID='IMG_9384.JPG' href='thewestcoast.php?fileId=IMG_9384.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050923/IMG_9384.JPG' ALT='IMG_9384.JPG'><BR>IMG_9384.JPG<br>54.85 KB</a><div class='inv'><br><a href='./images/20050923/IMG_9384.JPG' ALT='IMG_9384.JPG'>IMG_9384.JPG</a></div></td>
<td><A ID='IMG_9385.JPG' href='thewestcoast.php?fileId=IMG_9385.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050923/IMG_9385.JPG' ALT='IMG_9385.JPG'><BR>IMG_9385.JPG<br>34 KB</a><div class='inv'><br><a href='./images/20050923/IMG_9385.JPG' ALT='IMG_9385.JPG'>IMG_9385.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_9395.JPG' href='thewestcoast.php?fileId=IMG_9395.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050923/IMG_9395.JPG' ALT='IMG_9395.JPG'><BR>IMG_9395.JPG<br>31.5 KB</a><div class='inv'><br><a href='./images/20050923/IMG_9395.JPG' ALT='IMG_9395.JPG'>IMG_9395.JPG</a></div></td>
<td><A ID='IMG_9397.JPG' href='thewestcoast.php?fileId=IMG_9397.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050923/IMG_9397.JPG' ALT='IMG_9397.JPG'><BR>IMG_9397.JPG<br>66.77 KB</a><div class='inv'><br><a href='./images/20050923/IMG_9397.JPG' ALT='IMG_9397.JPG'>IMG_9397.JPG</a></div></td>
<td><A ID='IMG_9400.JPG' href='thewestcoast.php?fileId=IMG_9400.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050923/IMG_9400.JPG' ALT='IMG_9400.JPG'><BR>IMG_9400.JPG<br>81.41 KB</a><div class='inv'><br><a href='./images/20050923/IMG_9400.JPG' ALT='IMG_9400.JPG'>IMG_9400.JPG</a></div></td>
<td><A ID='IMG_9403.JPG' href='thewestcoast.php?fileId=IMG_9403.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050923/IMG_9403.JPG' ALT='IMG_9403.JPG'><BR>IMG_9403.JPG<br>84.68 KB</a><div class='inv'><br><a href='./images/20050923/IMG_9403.JPG' ALT='IMG_9403.JPG'>IMG_9403.JPG</a></div></td>
<td><A ID='IMG_9411.JPG' href='thewestcoast.php?fileId=IMG_9411.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050923/IMG_9411.JPG' ALT='IMG_9411.JPG'><BR>IMG_9411.JPG<br>82.28 KB</a><div class='inv'><br><a href='./images/20050923/IMG_9411.JPG' ALT='IMG_9411.JPG'>IMG_9411.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_9415.JPG' href='thewestcoast.php?fileId=IMG_9415.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050923/IMG_9415.JPG' ALT='IMG_9415.JPG'><BR>IMG_9415.JPG<br>112.42 KB</a><div class='inv'><br><a href='./images/20050923/IMG_9415.JPG' ALT='IMG_9415.JPG'>IMG_9415.JPG</a></div></td>
<td><A ID='IMG_9418.JPG' href='thewestcoast.php?fileId=IMG_9418.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050923/IMG_9418.JPG' ALT='IMG_9418.JPG'><BR>IMG_9418.JPG<br>39.69 KB</a><div class='inv'><br><a href='./images/20050923/IMG_9418.JPG' ALT='IMG_9418.JPG'>IMG_9418.JPG</a></div></td>
<td><A ID='IMG_9424.JPG' href='thewestcoast.php?fileId=IMG_9424.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050923/IMG_9424.JPG' ALT='IMG_9424.JPG'><BR>IMG_9424.JPG<br>78.87 KB</a><div class='inv'><br><a href='./images/20050923/IMG_9424.JPG' ALT='IMG_9424.JPG'>IMG_9424.JPG</a></div></td>
<td><A ID='IMG_9425.JPG' href='thewestcoast.php?fileId=IMG_9425.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050923/IMG_9425.JPG' ALT='IMG_9425.JPG'><BR>IMG_9425.JPG<br>68.56 KB</a><div class='inv'><br><a href='./images/20050923/IMG_9425.JPG' ALT='IMG_9425.JPG'>IMG_9425.JPG</a></div></td>
<td><A ID='IMG_9430.JPG' href='thewestcoast.php?fileId=IMG_9430.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050923/IMG_9430.JPG' ALT='IMG_9430.JPG'><BR>IMG_9430.JPG<br>75.91 KB</a><div class='inv'><br><a href='./images/20050923/IMG_9430.JPG' ALT='IMG_9430.JPG'>IMG_9430.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_9437.JPG' href='thewestcoast.php?fileId=IMG_9437.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050923/IMG_9437.JPG' ALT='IMG_9437.JPG'><BR>IMG_9437.JPG<br>37.72 KB</a><div class='inv'><br><a href='./images/20050923/IMG_9437.JPG' ALT='IMG_9437.JPG'>IMG_9437.JPG</a></div></td>
<td><A ID='IMG_9439.JPG' href='thewestcoast.php?fileId=IMG_9439.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050923/IMG_9439.JPG' ALT='IMG_9439.JPG'><BR>IMG_9439.JPG<br>40.45 KB</a><div class='inv'><br><a href='./images/20050923/IMG_9439.JPG' ALT='IMG_9439.JPG'>IMG_9439.JPG</a></div></td>
<td><A ID='IMG_9442.JPG' href='thewestcoast.php?fileId=IMG_9442.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050923/IMG_9442.JPG' ALT='IMG_9442.JPG'><BR>IMG_9442.JPG<br>56.89 KB</a><div class='inv'><br><a href='./images/20050923/IMG_9442.JPG' ALT='IMG_9442.JPG'>IMG_9442.JPG</a></div></td>
<td><A ID='IMG_9463.JPG' href='thewestcoast.php?fileId=IMG_9463.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050923/IMG_9463.JPG' ALT='IMG_9463.JPG'><BR>IMG_9463.JPG<br>35.43 KB</a><div class='inv'><br><a href='./images/20050923/IMG_9463.JPG' ALT='IMG_9463.JPG'>IMG_9463.JPG</a></div></td>
<td><A ID='IMG_9465.JPG' href='thewestcoast.php?fileId=IMG_9465.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050923/IMG_9465.JPG' ALT='IMG_9465.JPG'><BR>IMG_9465.JPG<br>42.14 KB</a><div class='inv'><br><a href='./images/20050923/IMG_9465.JPG' ALT='IMG_9465.JPG'>IMG_9465.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_9498.JPG' href='thewestcoast.php?fileId=IMG_9498.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050923/IMG_9498.JPG' ALT='IMG_9498.JPG'><BR>IMG_9498.JPG<br>84.39 KB</a><div class='inv'><br><a href='./images/20050923/IMG_9498.JPG' ALT='IMG_9498.JPG'>IMG_9498.JPG</a></div></td>
<td><A ID='IMG_9503.JPG' href='thewestcoast.php?fileId=IMG_9503.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050923/IMG_9503.JPG' ALT='IMG_9503.JPG'><BR>IMG_9503.JPG<br>23.43 KB</a><div class='inv'><br><a href='./images/20050923/IMG_9503.JPG' ALT='IMG_9503.JPG'>IMG_9503.JPG</a></div></td>
<td><A ID='IMG_9511.JPG' href='thewestcoast.php?fileId=IMG_9511.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050923/IMG_9511.JPG' ALT='IMG_9511.JPG'><BR>IMG_9511.JPG<br>47.48 KB</a><div class='inv'><br><a href='./images/20050923/IMG_9511.JPG' ALT='IMG_9511.JPG'>IMG_9511.JPG</a></div></td>
<td><A ID='IMG_9512.JPG' href='thewestcoast.php?fileId=IMG_9512.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050923/IMG_9512.JPG' ALT='IMG_9512.JPG'><BR>IMG_9512.JPG<br>67.64 KB</a><div class='inv'><br><a href='./images/20050923/IMG_9512.JPG' ALT='IMG_9512.JPG'>IMG_9512.JPG</a></div></td>
<td><A ID='IMG_9516.JPG' href='thewestcoast.php?fileId=IMG_9516.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050923/IMG_9516.JPG' ALT='IMG_9516.JPG'><BR>IMG_9516.JPG<br>49.79 KB</a><div class='inv'><br><a href='./images/20050923/IMG_9516.JPG' ALT='IMG_9516.JPG'>IMG_9516.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_9521.JPG' href='thewestcoast.php?fileId=IMG_9521.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050923/IMG_9521.JPG' ALT='IMG_9521.JPG'><BR>IMG_9521.JPG<br>54.33 KB</a><div class='inv'><br><a href='./images/20050923/IMG_9521.JPG' ALT='IMG_9521.JPG'>IMG_9521.JPG</a></div></td>
<td><A ID='IMG_9528.JPG' href='thewestcoast.php?fileId=IMG_9528.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050923/IMG_9528.JPG' ALT='IMG_9528.JPG'><BR>IMG_9528.JPG<br>68.08 KB</a><div class='inv'><br><a href='./images/20050923/IMG_9528.JPG' ALT='IMG_9528.JPG'>IMG_9528.JPG</a></div></td>
<td><A ID='IMG_9545.JPG' href='thewestcoast.php?fileId=IMG_9545.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050923/IMG_9545.JPG' ALT='IMG_9545.JPG'><BR>IMG_9545.JPG<br>71.54 KB</a><div class='inv'><br><a href='./images/20050923/IMG_9545.JPG' ALT='IMG_9545.JPG'>IMG_9545.JPG</a></div></td>
<td><A ID='IMG_9551.JPG' href='thewestcoast.php?fileId=IMG_9551.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050923/IMG_9551.JPG' ALT='IMG_9551.JPG'><BR>IMG_9551.JPG<br>71.82 KB</a><div class='inv'><br><a href='./images/20050923/IMG_9551.JPG' ALT='IMG_9551.JPG'>IMG_9551.JPG</a></div></td>
<td><A ID='IMG_9553.JPG' href='thewestcoast.php?fileId=IMG_9553.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050923/IMG_9553.JPG' ALT='IMG_9553.JPG'><BR>IMG_9553.JPG<br>67.05 KB</a><div class='inv'><br><a href='./images/20050923/IMG_9553.JPG' ALT='IMG_9553.JPG'>IMG_9553.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_9556.JPG' href='thewestcoast.php?fileId=IMG_9556.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050923/IMG_9556.JPG' ALT='IMG_9556.JPG'><BR>IMG_9556.JPG<br>65.92 KB</a><div class='inv'><br><a href='./images/20050923/IMG_9556.JPG' ALT='IMG_9556.JPG'>IMG_9556.JPG</a></div></td>
<td><A ID='IMG_9568.JPG' href='thewestcoast.php?fileId=IMG_9568.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050923/IMG_9568.JPG' ALT='IMG_9568.JPG'><BR>IMG_9568.JPG<br>84.32 KB</a><div class='inv'><br><a href='./images/20050923/IMG_9568.JPG' ALT='IMG_9568.JPG'>IMG_9568.JPG</a></div></td>
<td><A ID='IMG_9580.JPG' href='thewestcoast.php?fileId=IMG_9580.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050923/IMG_9580.JPG' ALT='IMG_9580.JPG'><BR>IMG_9580.JPG<br>48.16 KB</a><div class='inv'><br><a href='./images/20050923/IMG_9580.JPG' ALT='IMG_9580.JPG'>IMG_9580.JPG</a></div></td>
<td><A ID='IMG_9583.JPG' href='thewestcoast.php?fileId=IMG_9583.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050923/IMG_9583.JPG' ALT='IMG_9583.JPG'><BR>IMG_9583.JPG<br>35.08 KB</a><div class='inv'><br><a href='./images/20050923/IMG_9583.JPG' ALT='IMG_9583.JPG'>IMG_9583.JPG</a></div></td>
<td><A ID='IMG_9586.JPG' href='thewestcoast.php?fileId=IMG_9586.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050923/IMG_9586.JPG' ALT='IMG_9586.JPG'><BR>IMG_9586.JPG<br>68.33 KB</a><div class='inv'><br><a href='./images/20050923/IMG_9586.JPG' ALT='IMG_9586.JPG'>IMG_9586.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_9589.JPG' href='thewestcoast.php?fileId=IMG_9589.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050923/IMG_9589.JPG' ALT='IMG_9589.JPG'><BR>IMG_9589.JPG<br>36.53 KB</a><div class='inv'><br><a href='./images/20050923/IMG_9589.JPG' ALT='IMG_9589.JPG'>IMG_9589.JPG</a></div></td>
<td><A ID='IMG_9597.JPG' href='thewestcoast.php?fileId=IMG_9597.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050923/IMG_9597.JPG' ALT='IMG_9597.JPG'><BR>IMG_9597.JPG<br>120.51 KB</a><div class='inv'><br><a href='./images/20050923/IMG_9597.JPG' ALT='IMG_9597.JPG'>IMG_9597.JPG</a></div></td>
<td><A ID='IMG_9614.JPG' href='thewestcoast.php?fileId=IMG_9614.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050923/IMG_9614.JPG' ALT='IMG_9614.JPG'><BR>IMG_9614.JPG<br>35.8 KB</a><div class='inv'><br><a href='./images/20050923/IMG_9614.JPG' ALT='IMG_9614.JPG'>IMG_9614.JPG</a></div></td>
<td><A ID='IMG_9616.JPG' href='thewestcoast.php?fileId=IMG_9616.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050923/IMG_9616.JPG' ALT='IMG_9616.JPG'><BR>IMG_9616.JPG<br>123.55 KB</a><div class='inv'><br><a href='./images/20050923/IMG_9616.JPG' ALT='IMG_9616.JPG'>IMG_9616.JPG</a></div></td>
<td><A ID='IMG_9621.JPG' href='thewestcoast.php?fileId=IMG_9621.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050923/IMG_9621.JPG' ALT='IMG_9621.JPG'><BR>IMG_9621.JPG<br>84.87 KB</a><div class='inv'><br><a href='./images/20050923/IMG_9621.JPG' ALT='IMG_9621.JPG'>IMG_9621.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_9622.JPG' href='thewestcoast.php?fileId=IMG_9622.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050923/IMG_9622.JPG' ALT='IMG_9622.JPG'><BR>IMG_9622.JPG<br>106.56 KB</a><div class='inv'><br><a href='./images/20050923/IMG_9622.JPG' ALT='IMG_9622.JPG'>IMG_9622.JPG</a></div></td>
<td><A ID='IMG_9627.JPG' href='thewestcoast.php?fileId=IMG_9627.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050923/IMG_9627.JPG' ALT='IMG_9627.JPG'><BR>IMG_9627.JPG<br>96.28 KB</a><div class='inv'><br><a href='./images/20050923/IMG_9627.JPG' ALT='IMG_9627.JPG'>IMG_9627.JPG</a></div></td>
<td><A ID='IMG_9632.JPG' href='thewestcoast.php?fileId=IMG_9632.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050923/IMG_9632.JPG' ALT='IMG_9632.JPG'><BR>IMG_9632.JPG<br>58.22 KB</a><div class='inv'><br><a href='./images/20050923/IMG_9632.JPG' ALT='IMG_9632.JPG'>IMG_9632.JPG</a></div></td>
<td><A ID='IMG_9638.JPG' href='thewestcoast.php?fileId=IMG_9638.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050923/IMG_9638.JPG' ALT='IMG_9638.JPG'><BR>IMG_9638.JPG<br>55 KB</a><div class='inv'><br><a href='./images/20050923/IMG_9638.JPG' ALT='IMG_9638.JPG'>IMG_9638.JPG</a></div></td>
<td><A ID='IMG_9639.JPG' href='thewestcoast.php?fileId=IMG_9639.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050923/IMG_9639.JPG' ALT='IMG_9639.JPG'><BR>IMG_9639.JPG<br>63.17 KB</a><div class='inv'><br><a href='./images/20050923/IMG_9639.JPG' ALT='IMG_9639.JPG'>IMG_9639.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_9640.JPG' href='thewestcoast.php?fileId=IMG_9640.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050923/IMG_9640.JPG' ALT='IMG_9640.JPG'><BR>IMG_9640.JPG<br>63.93 KB</a><div class='inv'><br><a href='./images/20050923/IMG_9640.JPG' ALT='IMG_9640.JPG'>IMG_9640.JPG</a></div></td>
<td><A ID='IMG_9645.JPG' href='thewestcoast.php?fileId=IMG_9645.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050923/IMG_9645.JPG' ALT='IMG_9645.JPG'><BR>IMG_9645.JPG<br>54.86 KB</a><div class='inv'><br><a href='./images/20050923/IMG_9645.JPG' ALT='IMG_9645.JPG'>IMG_9645.JPG</a></div></td>
<td><A ID='IMG_9646.JPG' href='thewestcoast.php?fileId=IMG_9646.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050923/IMG_9646.JPG' ALT='IMG_9646.JPG'><BR>IMG_9646.JPG<br>63.03 KB</a><div class='inv'><br><a href='./images/20050923/IMG_9646.JPG' ALT='IMG_9646.JPG'>IMG_9646.JPG</a></div></td>
<td><A ID='IMG_9650.JPG' href='thewestcoast.php?fileId=IMG_9650.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050923/IMG_9650.JPG' ALT='IMG_9650.JPG'><BR>IMG_9650.JPG<br>52.44 KB</a><div class='inv'><br><a href='./images/20050923/IMG_9650.JPG' ALT='IMG_9650.JPG'>IMG_9650.JPG</a></div></td>
<td><A ID='IMG_9656.JPG' href='thewestcoast.php?fileId=IMG_9656.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050923/IMG_9656.JPG' ALT='IMG_9656.JPG'><BR>IMG_9656.JPG<br>34.17 KB</a><div class='inv'><br><a href='./images/20050923/IMG_9656.JPG' ALT='IMG_9656.JPG'>IMG_9656.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_9657.JPG' href='thewestcoast.php?fileId=IMG_9657.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050923/IMG_9657.JPG' ALT='IMG_9657.JPG'><BR>IMG_9657.JPG<br>87.24 KB</a><div class='inv'><br><a href='./images/20050923/IMG_9657.JPG' ALT='IMG_9657.JPG'>IMG_9657.JPG</a></div></td>
<td><A ID='IMG_9670.JPG' href='thewestcoast.php?fileId=IMG_9670.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050923/IMG_9670.JPG' ALT='IMG_9670.JPG'><BR>IMG_9670.JPG<br>44.59 KB</a><div class='inv'><br><a href='./images/20050923/IMG_9670.JPG' ALT='IMG_9670.JPG'>IMG_9670.JPG</a></div></td>
<td><A ID='IMG_9673.JPG' href='thewestcoast.php?fileId=IMG_9673.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050923/IMG_9673.JPG' ALT='IMG_9673.JPG'><BR>IMG_9673.JPG<br>70.99 KB</a><div class='inv'><br><a href='./images/20050923/IMG_9673.JPG' ALT='IMG_9673.JPG'>IMG_9673.JPG</a></div></td>
<td><A ID='IMG_9675.JPG' href='thewestcoast.php?fileId=IMG_9675.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050923/IMG_9675.JPG' ALT='IMG_9675.JPG'><BR>IMG_9675.JPG<br>93.7 KB</a><div class='inv'><br><a href='./images/20050923/IMG_9675.JPG' ALT='IMG_9675.JPG'>IMG_9675.JPG</a></div></td>
<td><A ID='IMG_9676.JPG' href='thewestcoast.php?fileId=IMG_9676.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050923/IMG_9676.JPG' ALT='IMG_9676.JPG'><BR>IMG_9676.JPG<br>51.53 KB</a><div class='inv'><br><a href='./images/20050923/IMG_9676.JPG' ALT='IMG_9676.JPG'>IMG_9676.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_9680.JPG' href='thewestcoast.php?fileId=IMG_9680.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050923/IMG_9680.JPG' ALT='IMG_9680.JPG'><BR>IMG_9680.JPG<br>49.29 KB</a><div class='inv'><br><a href='./images/20050923/IMG_9680.JPG' ALT='IMG_9680.JPG'>IMG_9680.JPG</a></div></td>
<td><A ID='IMG_9686.JPG' href='thewestcoast.php?fileId=IMG_9686.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050923/IMG_9686.JPG' ALT='IMG_9686.JPG'><BR>IMG_9686.JPG<br>48.97 KB</a><div class='inv'><br><a href='./images/20050923/IMG_9686.JPG' ALT='IMG_9686.JPG'>IMG_9686.JPG</a></div></td>
<td><A ID='IMG_9703.JPG' href='thewestcoast.php?fileId=IMG_9703.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050923/IMG_9703.JPG' ALT='IMG_9703.JPG'><BR>IMG_9703.JPG<br>28.19 KB</a><div class='inv'><br><a href='./images/20050923/IMG_9703.JPG' ALT='IMG_9703.JPG'>IMG_9703.JPG</a></div></td>
<td><A ID='IMG_9706.JPG' href='thewestcoast.php?fileId=IMG_9706.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050923/IMG_9706.JPG' ALT='IMG_9706.JPG'><BR>IMG_9706.JPG<br>29.37 KB</a><div class='inv'><br><a href='./images/20050923/IMG_9706.JPG' ALT='IMG_9706.JPG'>IMG_9706.JPG</a></div></td>
<td><A ID='IMG_9708.JPG' href='thewestcoast.php?fileId=IMG_9708.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050923/IMG_9708.JPG' ALT='IMG_9708.JPG'><BR>IMG_9708.JPG<br>62.37 KB</a><div class='inv'><br><a href='./images/20050923/IMG_9708.JPG' ALT='IMG_9708.JPG'>IMG_9708.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_9711.JPG' href='thewestcoast.php?fileId=IMG_9711.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050923/IMG_9711.JPG' ALT='IMG_9711.JPG'><BR>IMG_9711.JPG<br>60.73 KB</a><div class='inv'><br><a href='./images/20050923/IMG_9711.JPG' ALT='IMG_9711.JPG'>IMG_9711.JPG</a></div></td>
<td><A ID='IMG_9716.JPG' href='thewestcoast.php?fileId=IMG_9716.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050923/IMG_9716.JPG' ALT='IMG_9716.JPG'><BR>IMG_9716.JPG<br>80.18 KB</a><div class='inv'><br><a href='./images/20050923/IMG_9716.JPG' ALT='IMG_9716.JPG'>IMG_9716.JPG</a></div></td>
<td><A ID='IMG_9718.JPG' href='thewestcoast.php?fileId=IMG_9718.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050923/IMG_9718.JPG' ALT='IMG_9718.JPG'><BR>IMG_9718.JPG<br>84.75 KB</a><div class='inv'><br><a href='./images/20050923/IMG_9718.JPG' ALT='IMG_9718.JPG'>IMG_9718.JPG</a></div></td>
<td><A ID='IMG_9725.JPG' href='thewestcoast.php?fileId=IMG_9725.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050923/IMG_9725.JPG' ALT='IMG_9725.JPG'><BR>IMG_9725.JPG<br>47.88 KB</a><div class='inv'><br><a href='./images/20050923/IMG_9725.JPG' ALT='IMG_9725.JPG'>IMG_9725.JPG</a></div></td>
</tr>
</table>	</div>
</div>
</body>
</html>