<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - Guy and Alison's Wedding - Nuptial photography</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="Nuptial photography">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="Pictures of my 28th Birthday party complete with Sparkler Bomb" href='28th.php'>28th Birthday</a></li>
<li><a title="Pictures of my 30th Birthday party" href='30th.php'>30th Birthday</a></li>
<li><a title="Michael Shamgar and Lindsay Halamek's 30th birthday bash photos" href='sl30th.php'>Shams & Linds' 30th</a></li>
<li><a title="Pictures of Andy Marinos's new flat, cat Toby, and Mum Pam Swain" href='andycatandflat.php'>Andy's Cat & Flat</a></li>
<li><a title="Pictures of a visit to Stephen Jackson's Farm" href='jackovisit.php'>Jacko's Farm</a></li>
<li><a title="Pictures taken at the Peace Convergence action in Rockhampton and Yeppoon in June 2005 to protest the joint US Australia military exercises (Operation Talisman Sabre)" href='peaceconvergence.php'>Peace Convergence</a></li>
<li><a title="Sydney trip - April '06" href='bridges.php'>Sydney, April 06</a></li>
<li><a title="Pics of Naima's 28th birthday dinner" href='mim28th.php'>Naima's 28th</a></li>
<li><a title="Brisbane CBD and the Story Bridge" href='brisbanepics1.php'>Brissie by Night 1</a></li>
<li><a title="Lamington National Park" href='lamington.php'>Lamington NP</a></li>
<li><a title="Various creatures and views from our Brisbane back yard" href='backyard.php'>Backyard Creatures</a></li>
<li><a title="Opening day of the Eleanor Schonell (Green) Bridge" href='greenbridge.php'>Green Bridge</a></li>
<li><a title="Pictutres from the 2006 Woodford Folk Festival" href='woodford0607.php'>Woodford 2006-2007</a></li>
<li><a title="One Cute Puppy" href='jezebel.php'>Jezebel</a></li>
<li><a title="Climbing at Kangaroo Point Cliffs" href='kangaroopt1.php'>Heather's Visit</a></li>
<li><a title="0x0021st (33rd) birthday celebrations" href='0x0021st.php'>0x0021st Birthday</a></li>
<li><div class='activemenu'>Guy and Alison's Wedding</div></li>
<li><a title="Pictures from the 2007 Woodford Folk Festival" href='woodford0708.php'>Woodford 2007-2008</a></li>
<li><a title="Image gallery" href='sydneytrip0802.php'>Sydney & Yacaaba Head</a></li>
<li><a title="An impressive show by nature" href='lightning.php'>Thunderstorm Moonrise</a></li>
<li><a title="Frightening pictures of a shrinking beard" href='debearding.php'>De-bearding</a></li>
<li><a title="More Nuptial Photography" href='michaelandkaren.php'>Michael and Karen's Wedding</a></li>
<li><a title="A night of celebration" href='andrews21st.php'>Andrew's 21st</a></li>
<li><a title="Image Gallery" href='bloodyknee.php'>Bloody Knee</a></li>
<li><a title="Image Gallery" href='tyesbirthday.php'>Tye's Birthday</a></li>
<li><a title="Image Gallery" href='lasersocialising.php'>Laser Socialising</a></li>
<li><a title="Image Gallery" href='heatherandevan.php'>Heather and Evan's Wedding</a></li>
<li><a title="Image Gallery" href='woodford0809.php'>Woodford 2008-2009</a></li>
<li><a title="Image Gallery" href='allyandben.php'>Ally and Ben's Wedding</a></li>
<li><a title="Image Gallery" href='annes30th.php'>Anne's 30th</a></li>
<li><a title="Image Gallery" href='possumcreek.php'>Possum Creek</a></li>
<li><a title="Image Gallery" href='jamnight.php'>Jam Night</a></li>
<li><a title="Image Gallery" href='cunninghamsgap.php'>Cunningham's Gap</a></li>
<li><a title="Image Gallery" href='bigcat.php'>Diving on Big Cat</a></li>
<li><a title="Images from my birthday jam" href='birthdayjam.php'>Music, mayhem and merriment</a></li>
<li><a title="Image Gallery" href='fuzzypolaroidpics.php'>Fuzzy Polaroid</a></li>
<li><a title="Image Gallery" href='zombiewalk2009.php'>2009 Zombie Walk</a></li>
<li> </li><br><li>Or go back to:</li><li><a title='Picture galleries' href="pictures.php">Photography</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>Guy and Alison's Wedding</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Picture galleries' href="pictures.php">Photography</a> > <a title='Nuptial photography' href="guyandalison.php">Guy and Alison's Wedding</a>
<br><br>		

<p>Here are my pictures from Guy and Alison's wedding. They were kind enough to ask me to be their official photographer, but I declined, suggesting instead that they get someone who knew what they were doing (as I've never shot a wedding in my life).</p>

<p>I think it was a sensible decision, but I'm still quite happy with some of these shots... and they make such a pretty couple.</p>

<p>I could wax lyrical here about weddings, the characters involved, and photography in general, but instead I might just let the pictures speak for themselves.</p>

<p>All the best for your future, guys!</p>
<br><br>
All images in this gallery:<br>
<table width='800'>
<tr>
</tr>
<tr><td><A ID='IMG_9103.JPG' href='guyandalison.php?fileId=IMG_9103.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9103.JPG' ALT='IMG_9103.JPG'><BR>IMG_9103.JPG<br>73.59 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9103.JPG' ALT='IMG_9103.JPG'>IMG_9103.JPG</a></div></td>
<td><A ID='IMG_9105.JPG' href='guyandalison.php?fileId=IMG_9105.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9105.JPG' ALT='IMG_9105.JPG'><BR>IMG_9105.JPG<br>92.79 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9105.JPG' ALT='IMG_9105.JPG'>IMG_9105.JPG</a></div></td>
<td><A ID='IMG_9106.JPG' href='guyandalison.php?fileId=IMG_9106.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9106.JPG' ALT='IMG_9106.JPG'><BR>IMG_9106.JPG<br>89.27 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9106.JPG' ALT='IMG_9106.JPG'>IMG_9106.JPG</a></div></td>
<td><A ID='IMG_9108.JPG' href='guyandalison.php?fileId=IMG_9108.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9108.JPG' ALT='IMG_9108.JPG'><BR>IMG_9108.JPG<br>58.16 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9108.JPG' ALT='IMG_9108.JPG'>IMG_9108.JPG</a></div></td>
<td><A ID='IMG_9109.JPG' href='guyandalison.php?fileId=IMG_9109.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9109.JPG' ALT='IMG_9109.JPG'><BR>IMG_9109.JPG<br>60.76 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9109.JPG' ALT='IMG_9109.JPG'>IMG_9109.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_9110.JPG' href='guyandalison.php?fileId=IMG_9110.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9110.JPG' ALT='IMG_9110.JPG'><BR>IMG_9110.JPG<br>99.16 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9110.JPG' ALT='IMG_9110.JPG'>IMG_9110.JPG</a></div></td>
<td><A ID='IMG_9111.JPG' href='guyandalison.php?fileId=IMG_9111.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9111.JPG' ALT='IMG_9111.JPG'><BR>IMG_9111.JPG<br>75.67 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9111.JPG' ALT='IMG_9111.JPG'>IMG_9111.JPG</a></div></td>
<td><A ID='IMG_9113.JPG' href='guyandalison.php?fileId=IMG_9113.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9113.JPG' ALT='IMG_9113.JPG'><BR>IMG_9113.JPG<br>105.26 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9113.JPG' ALT='IMG_9113.JPG'>IMG_9113.JPG</a></div></td>
<td><A ID='IMG_9114.JPG' href='guyandalison.php?fileId=IMG_9114.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9114.JPG' ALT='IMG_9114.JPG'><BR>IMG_9114.JPG<br>88.9 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9114.JPG' ALT='IMG_9114.JPG'>IMG_9114.JPG</a></div></td>
<td><A ID='IMG_9115.JPG' href='guyandalison.php?fileId=IMG_9115.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9115.JPG' ALT='IMG_9115.JPG'><BR>IMG_9115.JPG<br>98.2 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9115.JPG' ALT='IMG_9115.JPG'>IMG_9115.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_9116.JPG' href='guyandalison.php?fileId=IMG_9116.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9116.JPG' ALT='IMG_9116.JPG'><BR>IMG_9116.JPG<br>57.27 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9116.JPG' ALT='IMG_9116.JPG'>IMG_9116.JPG</a></div></td>
<td><A ID='IMG_9119.JPG' href='guyandalison.php?fileId=IMG_9119.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9119.JPG' ALT='IMG_9119.JPG'><BR>IMG_9119.JPG<br>71.86 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9119.JPG' ALT='IMG_9119.JPG'>IMG_9119.JPG</a></div></td>
<td><A ID='IMG_9120.JPG' href='guyandalison.php?fileId=IMG_9120.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9120.JPG' ALT='IMG_9120.JPG'><BR>IMG_9120.JPG<br>73.22 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9120.JPG' ALT='IMG_9120.JPG'>IMG_9120.JPG</a></div></td>
<td><A ID='IMG_9122.JPG' href='guyandalison.php?fileId=IMG_9122.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9122.JPG' ALT='IMG_9122.JPG'><BR>IMG_9122.JPG<br>72.45 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9122.JPG' ALT='IMG_9122.JPG'>IMG_9122.JPG</a></div></td>
<td><A ID='IMG_9124.JPG' href='guyandalison.php?fileId=IMG_9124.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9124.JPG' ALT='IMG_9124.JPG'><BR>IMG_9124.JPG<br>46.96 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9124.JPG' ALT='IMG_9124.JPG'>IMG_9124.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_9126.JPG' href='guyandalison.php?fileId=IMG_9126.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9126.JPG' ALT='IMG_9126.JPG'><BR>IMG_9126.JPG<br>43.86 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9126.JPG' ALT='IMG_9126.JPG'>IMG_9126.JPG</a></div></td>
<td><A ID='IMG_9127.JPG' href='guyandalison.php?fileId=IMG_9127.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9127.JPG' ALT='IMG_9127.JPG'><BR>IMG_9127.JPG<br>38.95 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9127.JPG' ALT='IMG_9127.JPG'>IMG_9127.JPG</a></div></td>
<td><A ID='IMG_9129.JPG' href='guyandalison.php?fileId=IMG_9129.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9129.JPG' ALT='IMG_9129.JPG'><BR>IMG_9129.JPG<br>39.9 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9129.JPG' ALT='IMG_9129.JPG'>IMG_9129.JPG</a></div></td>
<td><A ID='IMG_9131.JPG' href='guyandalison.php?fileId=IMG_9131.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9131.JPG' ALT='IMG_9131.JPG'><BR>IMG_9131.JPG<br>92.82 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9131.JPG' ALT='IMG_9131.JPG'>IMG_9131.JPG</a></div></td>
<td><A ID='IMG_9132.JPG' href='guyandalison.php?fileId=IMG_9132.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9132.JPG' ALT='IMG_9132.JPG'><BR>IMG_9132.JPG<br>72.73 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9132.JPG' ALT='IMG_9132.JPG'>IMG_9132.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_9133.JPG' href='guyandalison.php?fileId=IMG_9133.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9133.JPG' ALT='IMG_9133.JPG'><BR>IMG_9133.JPG<br>50.9 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9133.JPG' ALT='IMG_9133.JPG'>IMG_9133.JPG</a></div></td>
<td><A ID='IMG_9134.JPG' href='guyandalison.php?fileId=IMG_9134.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9134.JPG' ALT='IMG_9134.JPG'><BR>IMG_9134.JPG<br>47.45 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9134.JPG' ALT='IMG_9134.JPG'>IMG_9134.JPG</a></div></td>
<td><A ID='IMG_9135.JPG' href='guyandalison.php?fileId=IMG_9135.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9135.JPG' ALT='IMG_9135.JPG'><BR>IMG_9135.JPG<br>45.14 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9135.JPG' ALT='IMG_9135.JPG'>IMG_9135.JPG</a></div></td>
<td><A ID='IMG_9137.JPG' href='guyandalison.php?fileId=IMG_9137.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9137.JPG' ALT='IMG_9137.JPG'><BR>IMG_9137.JPG<br>47.33 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9137.JPG' ALT='IMG_9137.JPG'>IMG_9137.JPG</a></div></td>
<td><A ID='IMG_9138.JPG' href='guyandalison.php?fileId=IMG_9138.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9138.JPG' ALT='IMG_9138.JPG'><BR>IMG_9138.JPG<br>46.24 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9138.JPG' ALT='IMG_9138.JPG'>IMG_9138.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_9139.JPG' href='guyandalison.php?fileId=IMG_9139.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9139.JPG' ALT='IMG_9139.JPG'><BR>IMG_9139.JPG<br>41.83 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9139.JPG' ALT='IMG_9139.JPG'>IMG_9139.JPG</a></div></td>
<td><A ID='IMG_9140.JPG' href='guyandalison.php?fileId=IMG_9140.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9140.JPG' ALT='IMG_9140.JPG'><BR>IMG_9140.JPG<br>41.74 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9140.JPG' ALT='IMG_9140.JPG'>IMG_9140.JPG</a></div></td>
<td><A ID='IMG_9141.JPG' href='guyandalison.php?fileId=IMG_9141.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9141.JPG' ALT='IMG_9141.JPG'><BR>IMG_9141.JPG<br>41.98 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9141.JPG' ALT='IMG_9141.JPG'>IMG_9141.JPG</a></div></td>
<td><A ID='IMG_9142.JPG' href='guyandalison.php?fileId=IMG_9142.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9142.JPG' ALT='IMG_9142.JPG'><BR>IMG_9142.JPG<br>51.3 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9142.JPG' ALT='IMG_9142.JPG'>IMG_9142.JPG</a></div></td>
<td><A ID='IMG_9143.JPG' href='guyandalison.php?fileId=IMG_9143.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9143.JPG' ALT='IMG_9143.JPG'><BR>IMG_9143.JPG<br>51.14 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9143.JPG' ALT='IMG_9143.JPG'>IMG_9143.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_9145.JPG' href='guyandalison.php?fileId=IMG_9145.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9145.JPG' ALT='IMG_9145.JPG'><BR>IMG_9145.JPG<br>50.76 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9145.JPG' ALT='IMG_9145.JPG'>IMG_9145.JPG</a></div></td>
<td><A ID='IMG_9146.JPG' href='guyandalison.php?fileId=IMG_9146.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9146.JPG' ALT='IMG_9146.JPG'><BR>IMG_9146.JPG<br>49.13 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9146.JPG' ALT='IMG_9146.JPG'>IMG_9146.JPG</a></div></td>
<td><A ID='IMG_9149.JPG' href='guyandalison.php?fileId=IMG_9149.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9149.JPG' ALT='IMG_9149.JPG'><BR>IMG_9149.JPG<br>58.68 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9149.JPG' ALT='IMG_9149.JPG'>IMG_9149.JPG</a></div></td>
<td><A ID='IMG_9151.JPG' href='guyandalison.php?fileId=IMG_9151.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9151.JPG' ALT='IMG_9151.JPG'><BR>IMG_9151.JPG<br>55.85 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9151.JPG' ALT='IMG_9151.JPG'>IMG_9151.JPG</a></div></td>
<td><A ID='IMG_9153.JPG' href='guyandalison.php?fileId=IMG_9153.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9153.JPG' ALT='IMG_9153.JPG'><BR>IMG_9153.JPG<br>81.75 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9153.JPG' ALT='IMG_9153.JPG'>IMG_9153.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_9154.JPG' href='guyandalison.php?fileId=IMG_9154.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9154.JPG' ALT='IMG_9154.JPG'><BR>IMG_9154.JPG<br>54.08 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9154.JPG' ALT='IMG_9154.JPG'>IMG_9154.JPG</a></div></td>
<td><A ID='IMG_9155.JPG' href='guyandalison.php?fileId=IMG_9155.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9155.JPG' ALT='IMG_9155.JPG'><BR>IMG_9155.JPG<br>59.3 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9155.JPG' ALT='IMG_9155.JPG'>IMG_9155.JPG</a></div></td>
<td><A ID='IMG_9156.JPG' href='guyandalison.php?fileId=IMG_9156.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9156.JPG' ALT='IMG_9156.JPG'><BR>IMG_9156.JPG<br>67.88 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9156.JPG' ALT='IMG_9156.JPG'>IMG_9156.JPG</a></div></td>
<td><A ID='IMG_9159.JPG' href='guyandalison.php?fileId=IMG_9159.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9159.JPG' ALT='IMG_9159.JPG'><BR>IMG_9159.JPG<br>49.2 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9159.JPG' ALT='IMG_9159.JPG'>IMG_9159.JPG</a></div></td>
<td><A ID='IMG_9160.JPG' href='guyandalison.php?fileId=IMG_9160.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9160.JPG' ALT='IMG_9160.JPG'><BR>IMG_9160.JPG<br>70.69 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9160.JPG' ALT='IMG_9160.JPG'>IMG_9160.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_9162.JPG' href='guyandalison.php?fileId=IMG_9162.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9162.JPG' ALT='IMG_9162.JPG'><BR>IMG_9162.JPG<br>63.59 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9162.JPG' ALT='IMG_9162.JPG'>IMG_9162.JPG</a></div></td>
<td><A ID='IMG_9163.JPG' href='guyandalison.php?fileId=IMG_9163.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9163.JPG' ALT='IMG_9163.JPG'><BR>IMG_9163.JPG<br>82.64 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9163.JPG' ALT='IMG_9163.JPG'>IMG_9163.JPG</a></div></td>
<td><A ID='IMG_9164.JPG' href='guyandalison.php?fileId=IMG_9164.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9164.JPG' ALT='IMG_9164.JPG'><BR>IMG_9164.JPG<br>68.49 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9164.JPG' ALT='IMG_9164.JPG'>IMG_9164.JPG</a></div></td>
<td><A ID='IMG_9165.JPG' href='guyandalison.php?fileId=IMG_9165.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9165.JPG' ALT='IMG_9165.JPG'><BR>IMG_9165.JPG<br>66.3 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9165.JPG' ALT='IMG_9165.JPG'>IMG_9165.JPG</a></div></td>
<td><A ID='IMG_9166.JPG' href='guyandalison.php?fileId=IMG_9166.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9166.JPG' ALT='IMG_9166.JPG'><BR>IMG_9166.JPG<br>54.81 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9166.JPG' ALT='IMG_9166.JPG'>IMG_9166.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_9167.JPG' href='guyandalison.php?fileId=IMG_9167.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9167.JPG' ALT='IMG_9167.JPG'><BR>IMG_9167.JPG<br>61.33 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9167.JPG' ALT='IMG_9167.JPG'>IMG_9167.JPG</a></div></td>
<td><A ID='IMG_9168.JPG' href='guyandalison.php?fileId=IMG_9168.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9168.JPG' ALT='IMG_9168.JPG'><BR>IMG_9168.JPG<br>65.6 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9168.JPG' ALT='IMG_9168.JPG'>IMG_9168.JPG</a></div></td>
<td><A ID='IMG_9169.JPG' href='guyandalison.php?fileId=IMG_9169.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9169.JPG' ALT='IMG_9169.JPG'><BR>IMG_9169.JPG<br>91.4 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9169.JPG' ALT='IMG_9169.JPG'>IMG_9169.JPG</a></div></td>
<td><A ID='IMG_9172.JPG' href='guyandalison.php?fileId=IMG_9172.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9172.JPG' ALT='IMG_9172.JPG'><BR>IMG_9172.JPG<br>75.87 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9172.JPG' ALT='IMG_9172.JPG'>IMG_9172.JPG</a></div></td>
<td><A ID='IMG_9174.JPG' href='guyandalison.php?fileId=IMG_9174.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9174.JPG' ALT='IMG_9174.JPG'><BR>IMG_9174.JPG<br>76.11 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9174.JPG' ALT='IMG_9174.JPG'>IMG_9174.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_9176.JPG' href='guyandalison.php?fileId=IMG_9176.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9176.JPG' ALT='IMG_9176.JPG'><BR>IMG_9176.JPG<br>118.96 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9176.JPG' ALT='IMG_9176.JPG'>IMG_9176.JPG</a></div></td>
<td><A ID='IMG_9177.JPG' href='guyandalison.php?fileId=IMG_9177.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9177.JPG' ALT='IMG_9177.JPG'><BR>IMG_9177.JPG<br>89.47 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9177.JPG' ALT='IMG_9177.JPG'>IMG_9177.JPG</a></div></td>
<td><A ID='IMG_9179.JPG' href='guyandalison.php?fileId=IMG_9179.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9179.JPG' ALT='IMG_9179.JPG'><BR>IMG_9179.JPG<br>98.18 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9179.JPG' ALT='IMG_9179.JPG'>IMG_9179.JPG</a></div></td>
<td><A ID='IMG_9180.JPG' href='guyandalison.php?fileId=IMG_9180.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9180.JPG' ALT='IMG_9180.JPG'><BR>IMG_9180.JPG<br>91.36 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9180.JPG' ALT='IMG_9180.JPG'>IMG_9180.JPG</a></div></td>
<td><A ID='IMG_9181.JPG' href='guyandalison.php?fileId=IMG_9181.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9181.JPG' ALT='IMG_9181.JPG'><BR>IMG_9181.JPG<br>81.82 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9181.JPG' ALT='IMG_9181.JPG'>IMG_9181.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_9182.JPG' href='guyandalison.php?fileId=IMG_9182.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9182.JPG' ALT='IMG_9182.JPG'><BR>IMG_9182.JPG<br>70.33 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9182.JPG' ALT='IMG_9182.JPG'>IMG_9182.JPG</a></div></td>
<td><A ID='IMG_9183.JPG' href='guyandalison.php?fileId=IMG_9183.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9183.JPG' ALT='IMG_9183.JPG'><BR>IMG_9183.JPG<br>68.84 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9183.JPG' ALT='IMG_9183.JPG'>IMG_9183.JPG</a></div></td>
<td><A ID='IMG_9185.JPG' href='guyandalison.php?fileId=IMG_9185.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9185.JPG' ALT='IMG_9185.JPG'><BR>IMG_9185.JPG<br>68.8 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9185.JPG' ALT='IMG_9185.JPG'>IMG_9185.JPG</a></div></td>
<td><A ID='IMG_9186.JPG' href='guyandalison.php?fileId=IMG_9186.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9186.JPG' ALT='IMG_9186.JPG'><BR>IMG_9186.JPG<br>69.01 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9186.JPG' ALT='IMG_9186.JPG'>IMG_9186.JPG</a></div></td>
<td><A ID='IMG_9187.JPG' href='guyandalison.php?fileId=IMG_9187.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9187.JPG' ALT='IMG_9187.JPG'><BR>IMG_9187.JPG<br>83.02 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9187.JPG' ALT='IMG_9187.JPG'>IMG_9187.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_9188.JPG' href='guyandalison.php?fileId=IMG_9188.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9188.JPG' ALT='IMG_9188.JPG'><BR>IMG_9188.JPG<br>44.27 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9188.JPG' ALT='IMG_9188.JPG'>IMG_9188.JPG</a></div></td>
<td><A ID='IMG_9189.JPG' href='guyandalison.php?fileId=IMG_9189.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9189.JPG' ALT='IMG_9189.JPG'><BR>IMG_9189.JPG<br>47.23 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9189.JPG' ALT='IMG_9189.JPG'>IMG_9189.JPG</a></div></td>
<td><A ID='IMG_9190.JPG' href='guyandalison.php?fileId=IMG_9190.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9190.JPG' ALT='IMG_9190.JPG'><BR>IMG_9190.JPG<br>41 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9190.JPG' ALT='IMG_9190.JPG'>IMG_9190.JPG</a></div></td>
<td><A ID='IMG_9192.JPG' href='guyandalison.php?fileId=IMG_9192.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9192.JPG' ALT='IMG_9192.JPG'><BR>IMG_9192.JPG<br>51.41 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9192.JPG' ALT='IMG_9192.JPG'>IMG_9192.JPG</a></div></td>
<td><A ID='IMG_9193.JPG' href='guyandalison.php?fileId=IMG_9193.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9193.JPG' ALT='IMG_9193.JPG'><BR>IMG_9193.JPG<br>35.57 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9193.JPG' ALT='IMG_9193.JPG'>IMG_9193.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_9194.JPG' href='guyandalison.php?fileId=IMG_9194.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9194.JPG' ALT='IMG_9194.JPG'><BR>IMG_9194.JPG<br>63.75 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9194.JPG' ALT='IMG_9194.JPG'>IMG_9194.JPG</a></div></td>
<td><A ID='IMG_9195.JPG' href='guyandalison.php?fileId=IMG_9195.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9195.JPG' ALT='IMG_9195.JPG'><BR>IMG_9195.JPG<br>44.39 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9195.JPG' ALT='IMG_9195.JPG'>IMG_9195.JPG</a></div></td>
<td><A ID='IMG_9197.JPG' href='guyandalison.php?fileId=IMG_9197.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9197.JPG' ALT='IMG_9197.JPG'><BR>IMG_9197.JPG<br>36.14 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9197.JPG' ALT='IMG_9197.JPG'>IMG_9197.JPG</a></div></td>
<td><A ID='IMG_9200.JPG' href='guyandalison.php?fileId=IMG_9200.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9200.JPG' ALT='IMG_9200.JPG'><BR>IMG_9200.JPG<br>55.11 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9200.JPG' ALT='IMG_9200.JPG'>IMG_9200.JPG</a></div></td>
<td><A ID='IMG_9201.JPG' href='guyandalison.php?fileId=IMG_9201.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9201.JPG' ALT='IMG_9201.JPG'><BR>IMG_9201.JPG<br>66.92 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9201.JPG' ALT='IMG_9201.JPG'>IMG_9201.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_9202.JPG' href='guyandalison.php?fileId=IMG_9202.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9202.JPG' ALT='IMG_9202.JPG'><BR>IMG_9202.JPG<br>74.13 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9202.JPG' ALT='IMG_9202.JPG'>IMG_9202.JPG</a></div></td>
<td><A ID='IMG_9204.JPG' href='guyandalison.php?fileId=IMG_9204.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9204.JPG' ALT='IMG_9204.JPG'><BR>IMG_9204.JPG<br>55.47 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9204.JPG' ALT='IMG_9204.JPG'>IMG_9204.JPG</a></div></td>
<td><A ID='IMG_9205.JPG' href='guyandalison.php?fileId=IMG_9205.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9205.JPG' ALT='IMG_9205.JPG'><BR>IMG_9205.JPG<br>67.21 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9205.JPG' ALT='IMG_9205.JPG'>IMG_9205.JPG</a></div></td>
<td><A ID='IMG_9206.JPG' href='guyandalison.php?fileId=IMG_9206.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9206.JPG' ALT='IMG_9206.JPG'><BR>IMG_9206.JPG<br>54.23 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9206.JPG' ALT='IMG_9206.JPG'>IMG_9206.JPG</a></div></td>
<td><A ID='IMG_9207.JPG' href='guyandalison.php?fileId=IMG_9207.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9207.JPG' ALT='IMG_9207.JPG'><BR>IMG_9207.JPG<br>54.07 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9207.JPG' ALT='IMG_9207.JPG'>IMG_9207.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_9208.JPG' href='guyandalison.php?fileId=IMG_9208.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9208.JPG' ALT='IMG_9208.JPG'><BR>IMG_9208.JPG<br>44.78 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9208.JPG' ALT='IMG_9208.JPG'>IMG_9208.JPG</a></div></td>
<td><A ID='IMG_9209.JPG' href='guyandalison.php?fileId=IMG_9209.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9209.JPG' ALT='IMG_9209.JPG'><BR>IMG_9209.JPG<br>43.28 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9209.JPG' ALT='IMG_9209.JPG'>IMG_9209.JPG</a></div></td>
<td><A ID='IMG_9210.JPG' href='guyandalison.php?fileId=IMG_9210.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9210.JPG' ALT='IMG_9210.JPG'><BR>IMG_9210.JPG<br>49.52 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9210.JPG' ALT='IMG_9210.JPG'>IMG_9210.JPG</a></div></td>
<td><A ID='IMG_9212.JPG' href='guyandalison.php?fileId=IMG_9212.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9212.JPG' ALT='IMG_9212.JPG'><BR>IMG_9212.JPG<br>57.05 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9212.JPG' ALT='IMG_9212.JPG'>IMG_9212.JPG</a></div></td>
<td><A ID='IMG_9213.JPG' href='guyandalison.php?fileId=IMG_9213.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9213.JPG' ALT='IMG_9213.JPG'><BR>IMG_9213.JPG<br>42.21 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9213.JPG' ALT='IMG_9213.JPG'>IMG_9213.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_9215.JPG' href='guyandalison.php?fileId=IMG_9215.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9215.JPG' ALT='IMG_9215.JPG'><BR>IMG_9215.JPG<br>44.25 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9215.JPG' ALT='IMG_9215.JPG'>IMG_9215.JPG</a></div></td>
<td><A ID='IMG_9216.JPG' href='guyandalison.php?fileId=IMG_9216.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9216.JPG' ALT='IMG_9216.JPG'><BR>IMG_9216.JPG<br>42.47 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9216.JPG' ALT='IMG_9216.JPG'>IMG_9216.JPG</a></div></td>
<td><A ID='IMG_9217.JPG' href='guyandalison.php?fileId=IMG_9217.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9217.JPG' ALT='IMG_9217.JPG'><BR>IMG_9217.JPG<br>33.4 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9217.JPG' ALT='IMG_9217.JPG'>IMG_9217.JPG</a></div></td>
<td><A ID='IMG_9220.JPG' href='guyandalison.php?fileId=IMG_9220.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9220.JPG' ALT='IMG_9220.JPG'><BR>IMG_9220.JPG<br>34.9 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9220.JPG' ALT='IMG_9220.JPG'>IMG_9220.JPG</a></div></td>
<td><A ID='IMG_9221.JPG' href='guyandalison.php?fileId=IMG_9221.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9221.JPG' ALT='IMG_9221.JPG'><BR>IMG_9221.JPG<br>44.34 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9221.JPG' ALT='IMG_9221.JPG'>IMG_9221.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_9224.JPG' href='guyandalison.php?fileId=IMG_9224.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9224.JPG' ALT='IMG_9224.JPG'><BR>IMG_9224.JPG<br>33.15 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9224.JPG' ALT='IMG_9224.JPG'>IMG_9224.JPG</a></div></td>
<td><A ID='IMG_9226.JPG' href='guyandalison.php?fileId=IMG_9226.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9226.JPG' ALT='IMG_9226.JPG'><BR>IMG_9226.JPG<br>44.25 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9226.JPG' ALT='IMG_9226.JPG'>IMG_9226.JPG</a></div></td>
<td><A ID='IMG_9227.JPG' href='guyandalison.php?fileId=IMG_9227.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9227.JPG' ALT='IMG_9227.JPG'><BR>IMG_9227.JPG<br>44.12 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9227.JPG' ALT='IMG_9227.JPG'>IMG_9227.JPG</a></div></td>
<td><A ID='IMG_9229.JPG' href='guyandalison.php?fileId=IMG_9229.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9229.JPG' ALT='IMG_9229.JPG'><BR>IMG_9229.JPG<br>50.12 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9229.JPG' ALT='IMG_9229.JPG'>IMG_9229.JPG</a></div></td>
<td><A ID='IMG_9231.JPG' href='guyandalison.php?fileId=IMG_9231.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9231.JPG' ALT='IMG_9231.JPG'><BR>IMG_9231.JPG<br>43.91 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9231.JPG' ALT='IMG_9231.JPG'>IMG_9231.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_9232.JPG' href='guyandalison.php?fileId=IMG_9232.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9232.JPG' ALT='IMG_9232.JPG'><BR>IMG_9232.JPG<br>43.97 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9232.JPG' ALT='IMG_9232.JPG'>IMG_9232.JPG</a></div></td>
<td><A ID='IMG_9233.JPG' href='guyandalison.php?fileId=IMG_9233.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9233.JPG' ALT='IMG_9233.JPG'><BR>IMG_9233.JPG<br>47.52 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9233.JPG' ALT='IMG_9233.JPG'>IMG_9233.JPG</a></div></td>
<td><A ID='IMG_9234.JPG' href='guyandalison.php?fileId=IMG_9234.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9234.JPG' ALT='IMG_9234.JPG'><BR>IMG_9234.JPG<br>39.87 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9234.JPG' ALT='IMG_9234.JPG'>IMG_9234.JPG</a></div></td>
<td><A ID='IMG_9237.JPG' href='guyandalison.php?fileId=IMG_9237.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9237.JPG' ALT='IMG_9237.JPG'><BR>IMG_9237.JPG<br>41.12 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9237.JPG' ALT='IMG_9237.JPG'>IMG_9237.JPG</a></div></td>
<td><A ID='IMG_9238.JPG' href='guyandalison.php?fileId=IMG_9238.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9238.JPG' ALT='IMG_9238.JPG'><BR>IMG_9238.JPG<br>41.58 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9238.JPG' ALT='IMG_9238.JPG'>IMG_9238.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_9240.JPG' href='guyandalison.php?fileId=IMG_9240.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9240.JPG' ALT='IMG_9240.JPG'><BR>IMG_9240.JPG<br>33.93 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9240.JPG' ALT='IMG_9240.JPG'>IMG_9240.JPG</a></div></td>
<td><A ID='IMG_9241.JPG' href='guyandalison.php?fileId=IMG_9241.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9241.JPG' ALT='IMG_9241.JPG'><BR>IMG_9241.JPG<br>47.37 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9241.JPG' ALT='IMG_9241.JPG'>IMG_9241.JPG</a></div></td>
<td><A ID='IMG_9243.JPG' href='guyandalison.php?fileId=IMG_9243.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9243.JPG' ALT='IMG_9243.JPG'><BR>IMG_9243.JPG<br>35.66 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9243.JPG' ALT='IMG_9243.JPG'>IMG_9243.JPG</a></div></td>
<td><A ID='IMG_9246.JPG' href='guyandalison.php?fileId=IMG_9246.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9246.JPG' ALT='IMG_9246.JPG'><BR>IMG_9246.JPG<br>43.32 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9246.JPG' ALT='IMG_9246.JPG'>IMG_9246.JPG</a></div></td>
<td><A ID='IMG_9248.JPG' href='guyandalison.php?fileId=IMG_9248.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9248.JPG' ALT='IMG_9248.JPG'><BR>IMG_9248.JPG<br>47.1 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9248.JPG' ALT='IMG_9248.JPG'>IMG_9248.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_9249.JPG' href='guyandalison.php?fileId=IMG_9249.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9249.JPG' ALT='IMG_9249.JPG'><BR>IMG_9249.JPG<br>39.72 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9249.JPG' ALT='IMG_9249.JPG'>IMG_9249.JPG</a></div></td>
<td><A ID='IMG_9252.JPG' href='guyandalison.php?fileId=IMG_9252.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9252.JPG' ALT='IMG_9252.JPG'><BR>IMG_9252.JPG<br>40.14 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9252.JPG' ALT='IMG_9252.JPG'>IMG_9252.JPG</a></div></td>
<td><A ID='IMG_9253.JPG' href='guyandalison.php?fileId=IMG_9253.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9253.JPG' ALT='IMG_9253.JPG'><BR>IMG_9253.JPG<br>48.15 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9253.JPG' ALT='IMG_9253.JPG'>IMG_9253.JPG</a></div></td>
<td><A ID='IMG_9254.JPG' href='guyandalison.php?fileId=IMG_9254.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9254.JPG' ALT='IMG_9254.JPG'><BR>IMG_9254.JPG<br>46.4 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9254.JPG' ALT='IMG_9254.JPG'>IMG_9254.JPG</a></div></td>
<td><A ID='IMG_9255.JPG' href='guyandalison.php?fileId=IMG_9255.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9255.JPG' ALT='IMG_9255.JPG'><BR>IMG_9255.JPG<br>41.5 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9255.JPG' ALT='IMG_9255.JPG'>IMG_9255.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_9257.JPG' href='guyandalison.php?fileId=IMG_9257.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9257.JPG' ALT='IMG_9257.JPG'><BR>IMG_9257.JPG<br>40.38 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9257.JPG' ALT='IMG_9257.JPG'>IMG_9257.JPG</a></div></td>
<td><A ID='IMG_9259.JPG' href='guyandalison.php?fileId=IMG_9259.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9259.JPG' ALT='IMG_9259.JPG'><BR>IMG_9259.JPG<br>43.96 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9259.JPG' ALT='IMG_9259.JPG'>IMG_9259.JPG</a></div></td>
<td><A ID='IMG_9260.JPG' href='guyandalison.php?fileId=IMG_9260.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9260.JPG' ALT='IMG_9260.JPG'><BR>IMG_9260.JPG<br>34.93 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9260.JPG' ALT='IMG_9260.JPG'>IMG_9260.JPG</a></div></td>
<td><A ID='IMG_9261.JPG' href='guyandalison.php?fileId=IMG_9261.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9261.JPG' ALT='IMG_9261.JPG'><BR>IMG_9261.JPG<br>34.25 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9261.JPG' ALT='IMG_9261.JPG'>IMG_9261.JPG</a></div></td>
<td><A ID='IMG_9263.JPG' href='guyandalison.php?fileId=IMG_9263.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9263.JPG' ALT='IMG_9263.JPG'><BR>IMG_9263.JPG<br>39.92 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9263.JPG' ALT='IMG_9263.JPG'>IMG_9263.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_9265.JPG' href='guyandalison.php?fileId=IMG_9265.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9265.JPG' ALT='IMG_9265.JPG'><BR>IMG_9265.JPG<br>41.27 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9265.JPG' ALT='IMG_9265.JPG'>IMG_9265.JPG</a></div></td>
<td><A ID='IMG_9267.JPG' href='guyandalison.php?fileId=IMG_9267.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9267.JPG' ALT='IMG_9267.JPG'><BR>IMG_9267.JPG<br>62.33 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9267.JPG' ALT='IMG_9267.JPG'>IMG_9267.JPG</a></div></td>
<td><A ID='IMG_9270.JPG' href='guyandalison.php?fileId=IMG_9270.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9270.JPG' ALT='IMG_9270.JPG'><BR>IMG_9270.JPG<br>48.21 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9270.JPG' ALT='IMG_9270.JPG'>IMG_9270.JPG</a></div></td>
<td><A ID='IMG_9271.JPG' href='guyandalison.php?fileId=IMG_9271.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9271.JPG' ALT='IMG_9271.JPG'><BR>IMG_9271.JPG<br>53.17 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9271.JPG' ALT='IMG_9271.JPG'>IMG_9271.JPG</a></div></td>
<td><A ID='IMG_9273.JPG' href='guyandalison.php?fileId=IMG_9273.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9273.JPG' ALT='IMG_9273.JPG'><BR>IMG_9273.JPG<br>38.93 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9273.JPG' ALT='IMG_9273.JPG'>IMG_9273.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_9276.JPG' href='guyandalison.php?fileId=IMG_9276.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9276.JPG' ALT='IMG_9276.JPG'><BR>IMG_9276.JPG<br>62.67 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9276.JPG' ALT='IMG_9276.JPG'>IMG_9276.JPG</a></div></td>
<td><A ID='IMG_9277.JPG' href='guyandalison.php?fileId=IMG_9277.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9277.JPG' ALT='IMG_9277.JPG'><BR>IMG_9277.JPG<br>39.45 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9277.JPG' ALT='IMG_9277.JPG'>IMG_9277.JPG</a></div></td>
<td><A ID='IMG_9280.JPG' href='guyandalison.php?fileId=IMG_9280.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9280.JPG' ALT='IMG_9280.JPG'><BR>IMG_9280.JPG<br>36.92 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9280.JPG' ALT='IMG_9280.JPG'>IMG_9280.JPG</a></div></td>
<td><A ID='IMG_9282.JPG' href='guyandalison.php?fileId=IMG_9282.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9282.JPG' ALT='IMG_9282.JPG'><BR>IMG_9282.JPG<br>37.45 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9282.JPG' ALT='IMG_9282.JPG'>IMG_9282.JPG</a></div></td>
<td><A ID='IMG_9284.JPG' href='guyandalison.php?fileId=IMG_9284.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9284.JPG' ALT='IMG_9284.JPG'><BR>IMG_9284.JPG<br>42.3 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9284.JPG' ALT='IMG_9284.JPG'>IMG_9284.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_9286.JPG' href='guyandalison.php?fileId=IMG_9286.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9286.JPG' ALT='IMG_9286.JPG'><BR>IMG_9286.JPG<br>52.97 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9286.JPG' ALT='IMG_9286.JPG'>IMG_9286.JPG</a></div></td>
<td><A ID='IMG_9288.JPG' href='guyandalison.php?fileId=IMG_9288.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9288.JPG' ALT='IMG_9288.JPG'><BR>IMG_9288.JPG<br>45.7 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9288.JPG' ALT='IMG_9288.JPG'>IMG_9288.JPG</a></div></td>
<td><A ID='IMG_9289.JPG' href='guyandalison.php?fileId=IMG_9289.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9289.JPG' ALT='IMG_9289.JPG'><BR>IMG_9289.JPG<br>57.64 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9289.JPG' ALT='IMG_9289.JPG'>IMG_9289.JPG</a></div></td>
<td><A ID='IMG_9291.JPG' href='guyandalison.php?fileId=IMG_9291.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9291.JPG' ALT='IMG_9291.JPG'><BR>IMG_9291.JPG<br>60.26 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9291.JPG' ALT='IMG_9291.JPG'>IMG_9291.JPG</a></div></td>
<td><A ID='IMG_9293.JPG' href='guyandalison.php?fileId=IMG_9293.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9293.JPG' ALT='IMG_9293.JPG'><BR>IMG_9293.JPG<br>58.67 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9293.JPG' ALT='IMG_9293.JPG'>IMG_9293.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_9294.JPG' href='guyandalison.php?fileId=IMG_9294.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9294.JPG' ALT='IMG_9294.JPG'><BR>IMG_9294.JPG<br>43.85 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9294.JPG' ALT='IMG_9294.JPG'>IMG_9294.JPG</a></div></td>
<td><A ID='IMG_9296.JPG' href='guyandalison.php?fileId=IMG_9296.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9296.JPG' ALT='IMG_9296.JPG'><BR>IMG_9296.JPG<br>54.78 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9296.JPG' ALT='IMG_9296.JPG'>IMG_9296.JPG</a></div></td>
<td><A ID='IMG_9297.JPG' href='guyandalison.php?fileId=IMG_9297.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9297.JPG' ALT='IMG_9297.JPG'><BR>IMG_9297.JPG<br>45.2 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9297.JPG' ALT='IMG_9297.JPG'>IMG_9297.JPG</a></div></td>
<td><A ID='IMG_9298.JPG' href='guyandalison.php?fileId=IMG_9298.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9298.JPG' ALT='IMG_9298.JPG'><BR>IMG_9298.JPG<br>47.6 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9298.JPG' ALT='IMG_9298.JPG'>IMG_9298.JPG</a></div></td>
<td><A ID='IMG_9299.JPG' href='guyandalison.php?fileId=IMG_9299.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9299.JPG' ALT='IMG_9299.JPG'><BR>IMG_9299.JPG<br>50.38 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9299.JPG' ALT='IMG_9299.JPG'>IMG_9299.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_9301.JPG' href='guyandalison.php?fileId=IMG_9301.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9301.JPG' ALT='IMG_9301.JPG'><BR>IMG_9301.JPG<br>51.82 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9301.JPG' ALT='IMG_9301.JPG'>IMG_9301.JPG</a></div></td>
<td><A ID='IMG_9302.JPG' href='guyandalison.php?fileId=IMG_9302.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9302.JPG' ALT='IMG_9302.JPG'><BR>IMG_9302.JPG<br>51.93 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9302.JPG' ALT='IMG_9302.JPG'>IMG_9302.JPG</a></div></td>
<td><A ID='IMG_9303.JPG' href='guyandalison.php?fileId=IMG_9303.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9303.JPG' ALT='IMG_9303.JPG'><BR>IMG_9303.JPG<br>36.59 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9303.JPG' ALT='IMG_9303.JPG'>IMG_9303.JPG</a></div></td>
<td><A ID='IMG_9305.JPG' href='guyandalison.php?fileId=IMG_9305.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9305.JPG' ALT='IMG_9305.JPG'><BR>IMG_9305.JPG<br>37.1 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9305.JPG' ALT='IMG_9305.JPG'>IMG_9305.JPG</a></div></td>
<td><A ID='IMG_9306.JPG' href='guyandalison.php?fileId=IMG_9306.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9306.JPG' ALT='IMG_9306.JPG'><BR>IMG_9306.JPG<br>33.12 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9306.JPG' ALT='IMG_9306.JPG'>IMG_9306.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_9308.JPG' href='guyandalison.php?fileId=IMG_9308.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9308.JPG' ALT='IMG_9308.JPG'><BR>IMG_9308.JPG<br>45.82 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9308.JPG' ALT='IMG_9308.JPG'>IMG_9308.JPG</a></div></td>
<td><A ID='IMG_9309.JPG' href='guyandalison.php?fileId=IMG_9309.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9309.JPG' ALT='IMG_9309.JPG'><BR>IMG_9309.JPG<br>48.26 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9309.JPG' ALT='IMG_9309.JPG'>IMG_9309.JPG</a></div></td>
<td><A ID='IMG_9310.JPG' href='guyandalison.php?fileId=IMG_9310.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9310.JPG' ALT='IMG_9310.JPG'><BR>IMG_9310.JPG<br>49.45 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9310.JPG' ALT='IMG_9310.JPG'>IMG_9310.JPG</a></div></td>
<td><A ID='IMG_9311.JPG' href='guyandalison.php?fileId=IMG_9311.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9311.JPG' ALT='IMG_9311.JPG'><BR>IMG_9311.JPG<br>48.78 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9311.JPG' ALT='IMG_9311.JPG'>IMG_9311.JPG</a></div></td>
<td><A ID='IMG_9313.JPG' href='guyandalison.php?fileId=IMG_9313.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9313.JPG' ALT='IMG_9313.JPG'><BR>IMG_9313.JPG<br>54.02 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9313.JPG' ALT='IMG_9313.JPG'>IMG_9313.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_9314.JPG' href='guyandalison.php?fileId=IMG_9314.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9314.JPG' ALT='IMG_9314.JPG'><BR>IMG_9314.JPG<br>54.4 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9314.JPG' ALT='IMG_9314.JPG'>IMG_9314.JPG</a></div></td>
<td><A ID='IMG_9315.JPG' href='guyandalison.php?fileId=IMG_9315.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9315.JPG' ALT='IMG_9315.JPG'><BR>IMG_9315.JPG<br>56.45 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9315.JPG' ALT='IMG_9315.JPG'>IMG_9315.JPG</a></div></td>
<td><A ID='IMG_9316.JPG' href='guyandalison.php?fileId=IMG_9316.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9316.JPG' ALT='IMG_9316.JPG'><BR>IMG_9316.JPG<br>56.74 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9316.JPG' ALT='IMG_9316.JPG'>IMG_9316.JPG</a></div></td>
<td><A ID='IMG_9317.JPG' href='guyandalison.php?fileId=IMG_9317.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9317.JPG' ALT='IMG_9317.JPG'><BR>IMG_9317.JPG<br>56.54 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9317.JPG' ALT='IMG_9317.JPG'>IMG_9317.JPG</a></div></td>
<td><A ID='IMG_9318.JPG' href='guyandalison.php?fileId=IMG_9318.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9318.JPG' ALT='IMG_9318.JPG'><BR>IMG_9318.JPG<br>56.89 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9318.JPG' ALT='IMG_9318.JPG'>IMG_9318.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_9320.JPG' href='guyandalison.php?fileId=IMG_9320.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9320.JPG' ALT='IMG_9320.JPG'><BR>IMG_9320.JPG<br>55.86 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9320.JPG' ALT='IMG_9320.JPG'>IMG_9320.JPG</a></div></td>
<td><A ID='IMG_9321.JPG' href='guyandalison.php?fileId=IMG_9321.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9321.JPG' ALT='IMG_9321.JPG'><BR>IMG_9321.JPG<br>45.42 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9321.JPG' ALT='IMG_9321.JPG'>IMG_9321.JPG</a></div></td>
<td><A ID='IMG_9322.JPG' href='guyandalison.php?fileId=IMG_9322.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9322.JPG' ALT='IMG_9322.JPG'><BR>IMG_9322.JPG<br>42.82 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9322.JPG' ALT='IMG_9322.JPG'>IMG_9322.JPG</a></div></td>
<td><A ID='IMG_9323.JPG' href='guyandalison.php?fileId=IMG_9323.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9323.JPG' ALT='IMG_9323.JPG'><BR>IMG_9323.JPG<br>70.69 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9323.JPG' ALT='IMG_9323.JPG'>IMG_9323.JPG</a></div></td>
<td><A ID='IMG_9325.JPG' href='guyandalison.php?fileId=IMG_9325.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9325.JPG' ALT='IMG_9325.JPG'><BR>IMG_9325.JPG<br>61.6 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9325.JPG' ALT='IMG_9325.JPG'>IMG_9325.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_9327.JPG' href='guyandalison.php?fileId=IMG_9327.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9327.JPG' ALT='IMG_9327.JPG'><BR>IMG_9327.JPG<br>59.12 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9327.JPG' ALT='IMG_9327.JPG'>IMG_9327.JPG</a></div></td>
<td><A ID='IMG_9330.JPG' href='guyandalison.php?fileId=IMG_9330.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9330.JPG' ALT='IMG_9330.JPG'><BR>IMG_9330.JPG<br>46.62 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9330.JPG' ALT='IMG_9330.JPG'>IMG_9330.JPG</a></div></td>
<td><A ID='IMG_9332.JPG' href='guyandalison.php?fileId=IMG_9332.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9332.JPG' ALT='IMG_9332.JPG'><BR>IMG_9332.JPG<br>56.65 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9332.JPG' ALT='IMG_9332.JPG'>IMG_9332.JPG</a></div></td>
<td><A ID='IMG_9334.JPG' href='guyandalison.php?fileId=IMG_9334.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9334.JPG' ALT='IMG_9334.JPG'><BR>IMG_9334.JPG<br>56.75 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9334.JPG' ALT='IMG_9334.JPG'>IMG_9334.JPG</a></div></td>
<td><A ID='IMG_9337.JPG' href='guyandalison.php?fileId=IMG_9337.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9337.JPG' ALT='IMG_9337.JPG'><BR>IMG_9337.JPG<br>40.19 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9337.JPG' ALT='IMG_9337.JPG'>IMG_9337.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_9339.JPG' href='guyandalison.php?fileId=IMG_9339.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9339.JPG' ALT='IMG_9339.JPG'><BR>IMG_9339.JPG<br>39.36 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9339.JPG' ALT='IMG_9339.JPG'>IMG_9339.JPG</a></div></td>
<td><A ID='IMG_9341.JPG' href='guyandalison.php?fileId=IMG_9341.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9341.JPG' ALT='IMG_9341.JPG'><BR>IMG_9341.JPG<br>39.43 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9341.JPG' ALT='IMG_9341.JPG'>IMG_9341.JPG</a></div></td>
<td><A ID='IMG_9343.JPG' href='guyandalison.php?fileId=IMG_9343.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9343.JPG' ALT='IMG_9343.JPG'><BR>IMG_9343.JPG<br>47.86 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9343.JPG' ALT='IMG_9343.JPG'>IMG_9343.JPG</a></div></td>
<td><A ID='IMG_9345.JPG' href='guyandalison.php?fileId=IMG_9345.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9345.JPG' ALT='IMG_9345.JPG'><BR>IMG_9345.JPG<br>48.46 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9345.JPG' ALT='IMG_9345.JPG'>IMG_9345.JPG</a></div></td>
<td><A ID='IMG_9347.JPG' href='guyandalison.php?fileId=IMG_9347.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9347.JPG' ALT='IMG_9347.JPG'><BR>IMG_9347.JPG<br>46.76 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9347.JPG' ALT='IMG_9347.JPG'>IMG_9347.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_9349.JPG' href='guyandalison.php?fileId=IMG_9349.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9349.JPG' ALT='IMG_9349.JPG'><BR>IMG_9349.JPG<br>46.75 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9349.JPG' ALT='IMG_9349.JPG'>IMG_9349.JPG</a></div></td>
<td><A ID='IMG_9352.JPG' href='guyandalison.php?fileId=IMG_9352.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9352.JPG' ALT='IMG_9352.JPG'><BR>IMG_9352.JPG<br>52.02 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9352.JPG' ALT='IMG_9352.JPG'>IMG_9352.JPG</a></div></td>
<td><A ID='IMG_9353.JPG' href='guyandalison.php?fileId=IMG_9353.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9353.JPG' ALT='IMG_9353.JPG'><BR>IMG_9353.JPG<br>46.81 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9353.JPG' ALT='IMG_9353.JPG'>IMG_9353.JPG</a></div></td>
<td><A ID='IMG_9354.JPG' href='guyandalison.php?fileId=IMG_9354.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9354.JPG' ALT='IMG_9354.JPG'><BR>IMG_9354.JPG<br>54.13 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9354.JPG' ALT='IMG_9354.JPG'>IMG_9354.JPG</a></div></td>
<td><A ID='IMG_9357.JPG' href='guyandalison.php?fileId=IMG_9357.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9357.JPG' ALT='IMG_9357.JPG'><BR>IMG_9357.JPG<br>40.43 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9357.JPG' ALT='IMG_9357.JPG'>IMG_9357.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_9359.JPG' href='guyandalison.php?fileId=IMG_9359.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9359.JPG' ALT='IMG_9359.JPG'><BR>IMG_9359.JPG<br>49.99 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9359.JPG' ALT='IMG_9359.JPG'>IMG_9359.JPG</a></div></td>
<td><A ID='IMG_9360.JPG' href='guyandalison.php?fileId=IMG_9360.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9360.JPG' ALT='IMG_9360.JPG'><BR>IMG_9360.JPG<br>47.42 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9360.JPG' ALT='IMG_9360.JPG'>IMG_9360.JPG</a></div></td>
<td><A ID='IMG_9362.JPG' href='guyandalison.php?fileId=IMG_9362.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9362.JPG' ALT='IMG_9362.JPG'><BR>IMG_9362.JPG<br>50.39 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9362.JPG' ALT='IMG_9362.JPG'>IMG_9362.JPG</a></div></td>
<td><A ID='IMG_9365.JPG' href='guyandalison.php?fileId=IMG_9365.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9365.JPG' ALT='IMG_9365.JPG'><BR>IMG_9365.JPG<br>45.14 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9365.JPG' ALT='IMG_9365.JPG'>IMG_9365.JPG</a></div></td>
<td><A ID='IMG_9368.JPG' href='guyandalison.php?fileId=IMG_9368.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9368.JPG' ALT='IMG_9368.JPG'><BR>IMG_9368.JPG<br>39.4 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9368.JPG' ALT='IMG_9368.JPG'>IMG_9368.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_9370.JPG' href='guyandalison.php?fileId=IMG_9370.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9370.JPG' ALT='IMG_9370.JPG'><BR>IMG_9370.JPG<br>34.65 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9370.JPG' ALT='IMG_9370.JPG'>IMG_9370.JPG</a></div></td>
<td><A ID='IMG_9371.JPG' href='guyandalison.php?fileId=IMG_9371.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9371.JPG' ALT='IMG_9371.JPG'><BR>IMG_9371.JPG<br>32.52 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9371.JPG' ALT='IMG_9371.JPG'>IMG_9371.JPG</a></div></td>
<td><A ID='IMG_9376.JPG' href='guyandalison.php?fileId=IMG_9376.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9376.JPG' ALT='IMG_9376.JPG'><BR>IMG_9376.JPG<br>43.49 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9376.JPG' ALT='IMG_9376.JPG'>IMG_9376.JPG</a></div></td>
<td><A ID='IMG_9377.JPG' href='guyandalison.php?fileId=IMG_9377.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9377.JPG' ALT='IMG_9377.JPG'><BR>IMG_9377.JPG<br>51.91 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9377.JPG' ALT='IMG_9377.JPG'>IMG_9377.JPG</a></div></td>
<td><A ID='IMG_9378.JPG' href='guyandalison.php?fileId=IMG_9378.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9378.JPG' ALT='IMG_9378.JPG'><BR>IMG_9378.JPG<br>49.2 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9378.JPG' ALT='IMG_9378.JPG'>IMG_9378.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_9379.JPG' href='guyandalison.php?fileId=IMG_9379.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9379.JPG' ALT='IMG_9379.JPG'><BR>IMG_9379.JPG<br>49.97 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9379.JPG' ALT='IMG_9379.JPG'>IMG_9379.JPG</a></div></td>
<td><A ID='IMG_9380.JPG' href='guyandalison.php?fileId=IMG_9380.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9380.JPG' ALT='IMG_9380.JPG'><BR>IMG_9380.JPG<br>45.59 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9380.JPG' ALT='IMG_9380.JPG'>IMG_9380.JPG</a></div></td>
<td><A ID='IMG_9381.JPG' href='guyandalison.php?fileId=IMG_9381.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9381.JPG' ALT='IMG_9381.JPG'><BR>IMG_9381.JPG<br>53.13 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9381.JPG' ALT='IMG_9381.JPG'>IMG_9381.JPG</a></div></td>
<td><A ID='IMG_9382.JPG' href='guyandalison.php?fileId=IMG_9382.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9382.JPG' ALT='IMG_9382.JPG'><BR>IMG_9382.JPG<br>49.52 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9382.JPG' ALT='IMG_9382.JPG'>IMG_9382.JPG</a></div></td>
<td><A ID='IMG_9385.JPG' href='guyandalison.php?fileId=IMG_9385.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9385.JPG' ALT='IMG_9385.JPG'><BR>IMG_9385.JPG<br>49.49 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9385.JPG' ALT='IMG_9385.JPG'>IMG_9385.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_9386.JPG' href='guyandalison.php?fileId=IMG_9386.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9386.JPG' ALT='IMG_9386.JPG'><BR>IMG_9386.JPG<br>79.18 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9386.JPG' ALT='IMG_9386.JPG'>IMG_9386.JPG</a></div></td>
<td><A ID='IMG_9389.JPG' href='guyandalison.php?fileId=IMG_9389.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20071116/IMG_9389.JPG' ALT='IMG_9389.JPG'><BR>IMG_9389.JPG<br>48.98 KB</a><div class='inv'><br><a href='./images/20071116/IMG_9389.JPG' ALT='IMG_9389.JPG'>IMG_9389.JPG</a></div></td>
</tr>
</table>	</div>
</div>
</body>
</html>