<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - Webcam - Mark Cocquio's webcam</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="Mark Cocquio's webcam">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="Random mp3s" href='mp3s.php'>MP3s</a></li>
<li><div class='activemenu'>Webcam</div></li>
<li><a title="James Ruse Agricultural High School Class of 1992 10 year reunion" href='reunion.php'>Reunion</a></li>
<li> </li><br><li>Or go back to:</li><li><a title='Old stuff from my site' href="archive.php">Archive</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>Webcam</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Old stuff from my site' href="archive.php">Archive</a> > <a title='Mark Cocquio's webcam' href="webcam.php">Webcam</a>
<br><br>		
<script LANGUAGE="JavaScript">
<!-- 
// "var speed" is the refresh rate adjustment in seconds.
var speed = 3600;
var y = 1;
var x = speed + y;
var time = x - y;
var now;
campicture = new Image();

function stopClock() {
	x = "off";
	document.form0.clock.value = x;
}

function startClock() {
    if (x != "off") {
		x = x - y;
		document.form0.clock.value = x;
		if (x < 1) {
	        reload()
        }
		timerID = setTimeout("startClock()", 1000);
    }
}

function reload() {
	now = new Date();
	var camImg = "http://strepto.mine.nu:8888/video/frame" + "?" + now.getTime();
//	var camImg = "http://strepto.mine.nu:8888/cam_1.jpg" + "?" + now.getTime();
	var camImg2 = "http://io.bpa.nu:8888/video/frame" + "?" + now.getTime();
//	var hitcounterImg = "_vti_bin/fpcount.exe/strepto/?Page=webcam.php|Image=1|Digits=5" + "?" + now.getTime();
	document.campicture.src = camImg;
//	document.campicture2.src = camImg2;
//	document.hitcounter.src = hitcounterImg;
    x = speed;
    document.form0.clock.value = x;
}

startClock();

// -->
</script>
<p>You may or may not get the feeling of intense gratification, depending on whether my camera is on or not, and whether you want to see me or not.</p>

<p>If the image is broken it means the camera is off.</p>

<form action="webcam.php" name="form0">
<!--- <A HREF="javascript:reload()"><IMG src="http://strepto.mine.nu:8888/cam_1.jpg" name="campicture" alt="Potentially Hideous Picture" border=0 reload="60"></A> --->
<A HREF="javascript:reload()"><IMG src="http://strepto.mine.nu:8888/video/frame" name="campicture" alt="Potentially Hideous Picture" border=0 reload="60"></A>
<!--- 	<A HREF="javascript:reload()"><IMG src="http://io.bpa.nu:8888/video/frame" name="campicture2" alt="Picture" border=0 reload="60"></A> --->
<input type="hidden" name="clock" size="3" value="">
</form>

<p>Note: Due to certain people leaving this page open all the BALLY TIME, it will now only refresh once an hour. You can manually refresh it by clicking on the image.</p>

	</div>
</div>
</body>
</html>