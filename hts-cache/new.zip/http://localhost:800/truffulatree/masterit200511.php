<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - November 2005 - Q&A letters</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="Q&A letters">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="Q&A letters" href='masterit200501.php'>January 2005</a></li>
<li><a title="Q&A letters" href='masterit200502.php'>February 2005</a></li>
<li><a title="Q&A letters" href='masterit200503.php'>March 2005</a></li>
<li><a title="Q&A letters" href='masterit200504.php'>April 2005</a></li>
<li><a title="Q&A letters" href='masterit200505.php'>May 2005</a></li>
<li><a title="Q&A letters" href='masterit200506.php'>June 2005</a></li>
<li><a title="Q&A letters" href='masterit200507.php'>July 2005</a></li>
<li><a title="Q&A letters" href='masterit200508.php'>August 2005</a></li>
<li><a title="Q&A letters" href='masterit200509.php'>September 2005</a></li>
<li><a title="Q&A letters" href='masterit200510.php'>October 2005</a></li>
<li><div class='activemenu'>November 2005</div></li>
<li><a title="Q&A letters" href='masterit200512.php'>December 2005</a></li>
<li> </li><br><li>Or go back to:</li><li><a title='Q&A/MasterIT letters from 2005' href="masterit2005.php">2005 archive</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>November 2005</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Mark's writing' href="written.php">Professional Writing</a> > <a title='My weekly Q&A column in The Australian' href="masterIT.php">MasterIT</a> > <a title='Q&A/MasterIT letters from 2005' href="masterit2005.php">2005 archive</a> > <a title='Q&A letters' href="masterit200511.php">November 2005</a>
<br><br>		<br>
<h2>1/11/05</h2><br>
<b>Earlier this year I bought a registry cleanup app. After a re-install of XP, I have not bothered to reinstall it, as I found the message box advising to run a "critical cleanup" on boot-up quite annoying. Previously, the app seemed to do its work but I never noticed a difference in performance; maybe at a speed of many MHz this is just not noticeable. Just how critical is it to cleanup the registry, and does XP have a native app to do this?</b><br>
<br>
Microsoft don't supply a registry cleaner with XP. They used to have a program called Regclean available for download, but it's no longer supported by them (although you can find it on the 'net quite easily).<br>
<br>
I wouldn't bother with it though, or with cleaning the registry at all, for a few reasons.<br>
<br>
The most simplistic cleaners simply scan for references to hard drive locations that no longer exist, and remove them, along with doing a few other housekeeping tasks.<br>
<br>
All this does is free up a little bit of hard drive space, as your registry ends up smaller (but only very slightly). You're unlikely to notice any difference in day to day computer speed. If you can, your brain may be of interest to NASA.<br>
<br>
At the end of the day, these apps are pretty harmless, but they don't actually do anything useful, apart remove a bit of junk that wasn't particularly hurting anything (more serious than one's sense of order), and remove a bit of money from your bank account (if they're not freeware).<br>
<br>
Additionally, it's actually useful to retain some registry junk; for example, consider the case of a program you once had installed, but removed. If you ever reinstall it, you may find it still retains some of it's original settings, as they'd be still sitting in the registry.<br>
<br>
More complex registry cleaners also offer "fixing" services (Regclean does a bit of both). This is where I feel things start to get a little bit less benign though, as the modern-day registry is a behemoth of a thing.<br>
<br>
Microsoft puts pretty much all of Windows' hardware and software setup information in there, so if it gets messed up it's quite possible to end up with a non-bootable PC, or one that does the Blue Screen of Death thing on a regular basis.<br>
<br>
In the end, the registry will end up a mess no matter what. A good fresh reinstall every few years is the best - and sadly only - way of knowing for sure your registry gremlins are sorted and Windows remains stable.<br>
<br>
<br>
<h2>8/11/05</h2><br>
<b>Without doing an installation, is it possible to explore a disk to find out whether it is 98 or 98se?</b><br>
<br>
Yep, no problem. If you pop in the CD, and open the setup.txt file in the root directory, the version should be at the top.<br>
<br>
<br>
<b>When my computer has been idle for a short while, perhaps an hour, the CPU usage, usually ticking along at 2% or 3% suddenly jerks up and down to 98% or thereabouts and back down again. The effect on the computer is to cause the cursor to jump and jerk, CDs and CD-Roms to skip - basically, the computer goes berserk.  The only cure is to reboot. Curiously, if I disconnect from the Internet, the problem does not occur. Any ideas?</b><br>
<br>
When it next happens, hit CTRL-ALT-DEL to bring up the task manager, and then select the Processes tab to view the list of tasks currently running. One of the columns is "cpu" - this shows the amount of CPU time that the particular task is taking up.<br>
<br>
Normally, if your computer isn't working hard, most of the time is taken up by "System Idle Process" (a program which basically just tells the CPU to execute special "no operation" instructions, cutting down heat and power consumption). <br>
<br>
Check to see if there is any one task taking up all the CPU time. Once you have the name you can Google it to see what it is, and to find out if it should be behaving that way or not.<br>
<br>
<br>
<b>I would like to know what the following Windows 2000 message means: 'The ordinal 129 could not be located in the dynamic link library MAPI32.DLL'</b><br>
<br>
Generally speaking, it means that some program can't access another bit of a DLL library (in this case the MAPI library, which is associated with email). This can be happen for a few reasons, but generally speaking it's a conflict caused by badly written software and Windows not playing with each other nicely.<br>
<br>
Without knowing the context of the error, it's pretty much impossible to narrow it down much further, however the reading I've done suggests that it's a common issue that people run into when they're running Norton products, in particular Norton Security and email antivirus stuff.<br>
<br>
If you're using any of these products, you could try uninstalling or disabling them to see if it makes any difference.<br>
<br>
<br>
<h2>15/11/05</h2><br>
<b>My PC has been very slow lately. The trouble started when an automatic Windows update failed to install (twice). Then Mozilla came up with errors, for example "....componentswallet.dll is not a valid Windows image", asking for passwords and failing to download new mail. The event log shows a "bad block on harddisk0" amongst about 1600 warnings of "error detected in device Harddisk0D during paging operation". I did a full scan for viruses, with none found. Now the PC is behaving increasingly erratically. Any suggestions?</b><br>
<br>
This is all bad news I'm afraid. It sounds like your hard drive is dying an undignified slow death. The event log entries indicate that Windows is trying - unsuccessfully - to read information from the disk. This is Bad.<br>
<br>
The least worst possibility is that your hard drive has suffered some minor damage to it's logical magnetic structure. If this is the case, a full reformat may fix the problem, however, obviously, the disk will be wiped in the process.<br>
<br>
The worst case scenario is that the drive is physically on the way out, and will continue to degrade. In this case, formatting will be of no avail, and the drive will need to be replaced.<br>
<br>
The silver lining to this cloud is that even high capacity hard drives are very cheap these days, and the chances are that you'll end up with a lot more space than you had, for not a lot of money. Think of it as a forced upgrade.<br>
<br>
Plus, if you keep the old (dead) drive, you can pull it to bits, and harvest some frighteningly strong fridge magnets from it, as well as some pretty-looking shiny disks.<br>
<br>
In either case, your number one priority is to back up any data that you want to keep, as soon as possible. Regular backups are never going to be completely up to date (unless you happened to have just made one), so you'll need to quickly back up any new and/or important files.<br>
<br>
From there, your best bet is to find a reputable computer repairer (or suitably geeky relative) and let them see what can be done.<br>
<br>
<br>
<h2>22/11/05</h2><br>
<b>Occasionally, when following links on Internet sites (IE, Office 2003), I end up with a porn site (the same one each time). This appears to be random. Any idea how I can put a stop to this?</b><br>
<br>
This sort of thing is due to some sort of malware (mal for malevolent) running on your system. These programs are a pretty insidious type of spyware, and are often delivered to their unsuspecting victims PC via a trojan program, or virus.<br>
<br>
Often, they can be hidden inside free software that seems to offer a free lunch; they may also be bundled with cracks for pirate software, or even be delivered to you automatically when you visit certain less savoury websites, if your Internet security settings aren't locked down fairly tightly, and you're using IE instead of Mozilla.<br>
<br>
In any case, it's not all doom and gloom. Generally these things are pretty easy to remove. You can try an anti-spyware tool like Adaware (from www.lavasoft.de), or Spybot Search & Destroy, but the best solution is to use an up to date virus scanner. I use McAfee 7, but there are also some freebies out there like AVG.<br>
<br>
Once your system is clean, make sure you keep your scanner up to date. This is the best way of preventing the situation from happening again, and it'll give you peace of mind in general. <br>
<br>
<br>
<b>My laptop gives a flash of the hard disk light every few seconds when idle; previously it didn't. I found a fix: set the Virtual Memory to manual and constant size, not variable-sized controlled by some wanker in Seattle, but it doesn't work. I'm running XP pro.</b><br>
<br>
XP polls the IDE bus every second (to see it you've inserted a CD), and on many desktops this results in the HD light flashing regularly. It's dependant on your particular hardware and firmware; some machines do it, some don't.<br>
<br>
Unfortunately, manually setting The VM size won't help; in fact there's nothing one can do about it, short of putting tape over the light, or closing your eyes, both of which sort of defeat the purpose of the exercise.<br>
<br>
<i><p>Did the information on this page help you? Entertain you? Bore you? <a href="contact.php?subject=MasterIT">Drop me a line</a>.</p>

<p>If you're feeling particularly generous, you can even <a href="buypics.php">click here to send me some dot-com riches</a>. Think of it as online busking.</i></p>
	</div>
</div>
</body>
</html>