<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - August 2006 - Q&A letters</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="Q&A letters">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="Q&A letters" href='masterit200601.php'>January 2006</a></li>
<li><a title="Q&A letters" href='masterit200602.php'>February 2006</a></li>
<li><a title="Q&A letters" href='masterit200603.php'>March 2006</a></li>
<li><a title="Q&A letters" href='masterit200604.php'>April 2006</a></li>
<li><a title="Q&A letters" href='masterit200605.php'>May 2006</a></li>
<li><a title="Q&A letters" href='masterit200606.php'>June 2006</a></li>
<li><a title="Q&A letters" href='masterit200607.php'>July 2006</a></li>
<li><div class='activemenu'>August 2006</div></li>
<li><a title="Q&A letters" href='masterit200609.php'>September 2006</a></li>
<li><a title="Q&A letters" href='masterit200610.php'>October 2006</a></li>
<li><a title="Q&A letters" href='masterit200611.php'>November 2006</a></li>
<li><a title="Q&A letters" href='masterit200612.php'>December 2006</a></li>
<li> </li><br><li>Or go back to:</li><li><a title='Q&A/MasterIT letters from 2006' href="masterit2006.php">2006 archive</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>August 2006</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Mark's writing' href="written.php">Professional Writing</a> > <a title='My weekly Q&A column in The Australian' href="masterIT.php">MasterIT</a> > <a title='Q&A/MasterIT letters from 2006' href="masterit2006.php">2006 archive</a> > <a title='Q&A letters' href="masterit200608.php">August 2006</a>
<br><br>		<br>
<h2>1/8/06</h2><br>
<b>I recently purchased a BBC MP3-CD audio book - but am unable to get it downloaded onto my iPod. My computer recognises what the CD is as soon as I load it (I use Windows - latest version) but none of the options offered is download to iPod.  Do I have to go through iTunes - and if so, how do I get iTunes to do this? Surely if it's an MP3 CD audio disc it should be destined for life on an iPod! I'm leaving on an overseas trip on 19th July and rather fancied travelling across Russia by train listening to Jane Austen!</b><br>
<br>
It should be fairly easy to get Jane onto your iPod. Audio books like this are a great idea and are becoming increasingly more popular thanks to MP3 players. I drove around Australia last year (gratuitous plug: http://tinyurl.com/pocbd) and wish I'd had more talking books with me.<br>
<br>
You will have to go through iTunes as Windows doesn't have native drivers for the iPod. It can be downloaded from apple's website at  http://www.apple.com/au/itunes/download. Note that you don't need to enter an email address - it's just an evil mailing list grab by Apple. Instead, simply click the download button and all should be well.<br>
<br>
Once installed, iTunes should automatically detect the disc when you put it in. The rest should be pretty smooth sailing; there's an Apple tutorial at http://www.apple.com/support/ipod/tutorial/ip_gettingstarted_t1.html, and no doubt Google can point you at 50,000 other tutorials on the net.<br>
<br>
<br>
<b>Hi, I run identical windows (2000 pro) at work and at home, at work windows remembers user names and passwords from the first letter punched in, at home it does not. Our IT bloke does not know how to switch the feature on, can you help?</b><br>
<br>
It's hidden away in the Internet Explorer options. Go to tools->options in IE, then select the Content tab, then click the Autocomplete button, and tick the various boxes.<br>
<br>
<br>
<h2>8/8/06</h2><br>
<b>Sometimes, on my PC, I hit the Caps Lock and Insert keys by accident, and I find myself SHOUTING IN CAPS or overwriting something that I didn't want to. I notice that Windows supports different keyboard layouts, and so presumably has the capability to change the mappings of various keys. I was wondering if it's possible to easily re-map (or disable entirely) the Caps Lock and Insert keys?</b><br>
<br>
Microsoft provide a tool for creating custom keyboard maps (available at http://tinyurl.com/aek48), but it doesn't let you change the more "exotic" keys like Caps Lock.<br>
<br>
It's quite easy to change these keyboard mappings, but  it involves editing the Registry. For the more adventurous, there is a good article at http://www.usnetizen.com/fix_capslock.html, which even provides a couple of links to registry patches that disable and re-enable the Caps Lock key.<br>
<br>
For those who would prefer to keep their sticky fingers out of their Registry, or to remap/disable other keys (like Insert), pcmag.com have an extensive article on the subject and a good utility at http://tinyurl.com/nkbwn (You'll have to wade through the article to get to the download at the end).<br>
<br>
Note that I accept no responsibility for hilarious practical jokes involving cruelly remapping your co-worker's keyboards.<br>
<br>
<br>
<b>I've been using the program Notmad Explorer for a while to interface my PC (a fairly modern Dell) with my Creative MP3 player, as the Creative Labs software was less than spectacular. It's fantastic, but I have one strange problem. Once I double click the icon in the taskbar to access the player, my PC doesn't seem to multitask as well. I know it sounds crazy but I can back it up with benchmarks. Any ideas?</b><br>
<br>
What's happening is that Notmad Explorer is changing your CPU affinity. The plain English explanation is as follows: Your CPU is a "Hyperthreading" model, which means that from Windows' point of view, it appears as two separate CPUs.<br>
<br>
Normally, Windows splits system load between CPUs automatically and evenly, but it is possible to specify that a program uses only on one virtual CPU, rather than both (changing the program's "CPU affinity"). When this happens, tasks that run on both CPUs can suffer a performance hit when multitasking heavily.<br>
<br>
Notmad is a great piece of software, but for some reason it programmatically changes the affinity of Explorer.exe, and henceforth all the programs that are subsequently run from it.<br>
<br>
Red Chair software, the people behind Notmad, were kind enough to send me through a fix to this issue, in the form of a registry patch. It can be downloaded from http://tinyurl.com/s97mb.<br>
<br>
<br>
<h2>22/8/06</h2><br>
<b>My iPod has given me the world of music, but I can't work out how to get it into Power Point presentations. Some of iTunes are from my own CDs and many are bought from iTunes. Help!</b><br>
<br>
In order to get music from your iPod into Powerpoint, the first step is to make sure it's copied to your computer. If your copy of iTunes is set up to automatically sync with your iPod, there's no problem. If not, you'll need to manually make sure the music in question is copied to you local iTunes library.<br>
<br>
Next, you'll need to make sure the file is in a format compatible with Powerpoint, such as MP3. Apple's custom AAC format (or any other mpeg-4 format) won't work directly. Unfortunately this means that purchased music from the iTunes store is also unlikely to work, as it has built in copy-protection. All is not lost though - see below for an alternative solution.<br>
<br>
Assuming the music is in a readable format, it should as simple as dragging and dropping the song from iTunes to the particular slide in Powerpoint. In some cases though, Powerpoint doesn't seem to like particular files and will refuse to play them. If this happens, you'll also have to resort to option B below.<br>
<br>
If dragging and dropping works, cheer joyously, but also bear in mind that Powerpoint links to the music (rather than embedding it) if it's larger than a certain size. This is 100k by default, but the setting can be changed under Tools->options->General. Remember that if the music isn't embedded, it will only play on your PC, and none other.<br>
<br>
Anyway, if your music wasn't playable in the first place for one of the reasons above, option B is go to Insert->Movies & Sounds->Record Sound in Powerpoint, and then click the little record button. At the same time, start the track playing in iTunes. Recording this way will reduce the quality of the audio, but at least you'll be able to get it into the presentation.<br>
<br>
In order to get this to work though (nothing is simple!), you'll need to configure your sound card's recording device to pick up the output from iTunes. Doing this can be a bit technical, and (best of all) not all sound cards can do it. There is a basic guide at http://tinyurl.com/fzr7x. Good luck!<br>
<br>
<br>
<h2>29/8/06</h2><br>
<b>Recently I installed an application called Check it Diagnostics which is included with the 2006 Norton System Works package. I then decided to uninstall it using the uninstall program included. After finishing, it told me that not all of the package had been removed, and that I needed to remove the remainder manually. How do I do this? Do you think that the Norton maintenance tools are any more effective than the tools supplied in Windows XP?</b><br>
<br>
After uninstalling something, it's fairly common to see a message about "leftovers". What happens is that when it they run, programs often create some extra files (eg, settings, logs and so on) on your hard disk.<br>
<br>
Uninstall scripts often don't know about these files; they only know about the files that were originally installed. Those they dutifully remove, but any other files get left behind.<br>
<br>
Perhaps they are working on the theory that you might want to keep them for future reference, but I think it's just laziness on the part of the programmers, as a good uninstall script should ask the user if they wish to keep saved settings and other superfluous files, or remove them.<br>
<br>
Either way, these files tend to be small and insignificant. Unless you know exactly where to look for them, it's probably safer to leave them be, rather than embarking on a hit-and-miss deletion mission.<br>
<br>
As far as Norton tools go, I make no secrets about having a fairly strong dislike of them all, as well as many other Symantec products. Of course, they're far from useless - they do quite a few things that the standard Windows tools can't - but there are other alternatives out there, often free, and almost always better.<br>
<br>
My main gripes are that, one, many of Symantec's products are simply re-badged programs that they have bought out. Sometimes these contain bugs and are not maintained properly. More than occasionally, they can cause system instability, either on their own, but more commonly by interacting badly with other programs.<br>
<br>
Two, Norton stuff tends not to uninstall itself properly and/or cleanly. Leaving a few log files around is one thing, but leaving modified registry values, drivers and system files behind that cannot be removed without a lot of manual work is another.<br>
<br>
(Rant ends)<br>
<br>
Of course, if things are working for you, don't feel you have to rush out and change them. Software that works is good software. I am certainly not alleging that Symantec/Norton products are useless - just that they've caused myself (wearing my techie hat) - and others - significant pain in the past.<br>
<br>
<i><p>Did the information on this page help you? Entertain you? Bore you? <a href="contact.php?subject=MasterIT">Drop me a line</a>.</p>

<p>If you're feeling particularly generous, you can even <a href="buypics.php">click here to send me some dot-com riches</a>. Think of it as online busking.</i></p>
	</div>
</div>
</body>
</html>