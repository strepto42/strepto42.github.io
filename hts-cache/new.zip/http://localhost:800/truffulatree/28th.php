<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - 28th Birthday - Pictures of my 28th Birthday party complete with Sparkler Bomb</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="Pictures of my 28th Birthday party complete with Sparkler Bomb">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><div class='activemenu'>28th Birthday</div></li>
<li><a title="Pictures of my 30th Birthday party" href='30th.php'>30th Birthday</a></li>
<li><a title="Michael Shamgar and Lindsay Halamek's 30th birthday bash photos" href='sl30th.php'>Shams & Linds' 30th</a></li>
<li><a title="Pictures of Andy Marinos's new flat, cat Toby, and Mum Pam Swain" href='andycatandflat.php'>Andy's Cat & Flat</a></li>
<li><a title="Pictures of a visit to Stephen Jackson's Farm" href='jackovisit.php'>Jacko's Farm</a></li>
<li><a title="Pictures taken at the Peace Convergence action in Rockhampton and Yeppoon in June 2005 to protest the joint US Australia military exercises (Operation Talisman Sabre)" href='peaceconvergence.php'>Peace Convergence</a></li>
<li><a title="Sydney trip - April '06" href='bridges.php'>Sydney, April 06</a></li>
<li><a title="Pics of Naima's 28th birthday dinner" href='mim28th.php'>Naima's 28th</a></li>
<li><a title="Brisbane CBD and the Story Bridge" href='brisbanepics1.php'>Brissie by Night 1</a></li>
<li><a title="Lamington National Park" href='lamington.php'>Lamington NP</a></li>
<li><a title="Various creatures and views from our Brisbane back yard" href='backyard.php'>Backyard Creatures</a></li>
<li><a title="Opening day of the Eleanor Schonell (Green) Bridge" href='greenbridge.php'>Green Bridge</a></li>
<li><a title="Pictutres from the 2006 Woodford Folk Festival" href='woodford0607.php'>Woodford 2006-2007</a></li>
<li><a title="One Cute Puppy" href='jezebel.php'>Jezebel</a></li>
<li><a title="Climbing at Kangaroo Point Cliffs" href='kangaroopt1.php'>Heather's Visit</a></li>
<li><a title="0x0021st (33rd) birthday celebrations" href='0x0021st.php'>0x0021st Birthday</a></li>
<li><a title="Nuptial photography" href='guyandalison.php'>Guy and Alison's Wedding</a></li>
<li><a title="Pictures from the 2007 Woodford Folk Festival" href='woodford0708.php'>Woodford 2007-2008</a></li>
<li><a title="Image gallery" href='sydneytrip0802.php'>Sydney & Yacaaba Head</a></li>
<li><a title="An impressive show by nature" href='lightning.php'>Thunderstorm Moonrise</a></li>
<li><a title="Frightening pictures of a shrinking beard" href='debearding.php'>De-bearding</a></li>
<li><a title="More Nuptial Photography" href='michaelandkaren.php'>Michael and Karen's Wedding</a></li>
<li><a title="A night of celebration" href='andrews21st.php'>Andrew's 21st</a></li>
<li><a title="Image Gallery" href='bloodyknee.php'>Bloody Knee</a></li>
<li><a title="Image Gallery" href='tyesbirthday.php'>Tye's Birthday</a></li>
<li><a title="Image Gallery" href='lasersocialising.php'>Laser Socialising</a></li>
<li><a title="Image Gallery" href='heatherandevan.php'>Heather and Evan's Wedding</a></li>
<li><a title="Image Gallery" href='woodford0809.php'>Woodford 2008-2009</a></li>
<li><a title="Image Gallery" href='allyandben.php'>Ally and Ben's Wedding</a></li>
<li><a title="Image Gallery" href='annes30th.php'>Anne's 30th</a></li>
<li><a title="Image Gallery" href='possumcreek.php'>Possum Creek</a></li>
<li><a title="Image Gallery" href='jamnight.php'>Jam Night</a></li>
<li><a title="Image Gallery" href='cunninghamsgap.php'>Cunningham's Gap</a></li>
<li><a title="Image Gallery" href='bigcat.php'>Diving on Big Cat</a></li>
<li><a title="Images from my birthday jam" href='birthdayjam.php'>Music, mayhem and merriment</a></li>
<li><a title="Image Gallery" href='fuzzypolaroidpics.php'>Fuzzy Polaroid</a></li>
<li><a title="Image Gallery" href='zombiewalk2009.php'>2009 Zombie Walk</a></li>
<li> </li><br><li>Or go back to:</li><li><a title='Picture galleries' href="pictures.php">Photography</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>28th Birthday</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Picture galleries' href="pictures.php">Photography</a> > <a title='Pictures of my 28th Birthday party complete with Sparkler Bomb' href="28th.php">28th Birthday</a>
<br><br>		

<p>Some happy snaps from my 28th. A little dated now, but still entertaining. And the sparkler bomb came out well.</p>

<p>A random note - if you want people to look happy and smile in photos, just hand out sparklers beforehand!</p>

<br><br>
All images in this gallery:<br>
<table width='800'>
<tr>
</tr>
<tr><td><A ID='Picture 001.jpg' href='28th.php?fileId=Picture 001.jpg'><img src='modules/cms/showthumb.php?image=../.././images/28th/Picture 001.jpg' ALT='Picture 001.jpg'><BR>Picture 001.jpg<br>44.34 KB</a><div class='inv'><br><a href='./images/28th/Picture 001.jpg' ALT='Picture 001.jpg'>Picture 001.jpg</a></div></td>
<td><A ID='Picture 002.jpg' href='28th.php?fileId=Picture 002.jpg'><img src='modules/cms/showthumb.php?image=../.././images/28th/Picture 002.jpg' ALT='Picture 002.jpg'><BR>Picture 002.jpg<br>54.47 KB</a><div class='inv'><br><a href='./images/28th/Picture 002.jpg' ALT='Picture 002.jpg'>Picture 002.jpg</a></div></td>
<td><A ID='Picture 003.jpg' href='28th.php?fileId=Picture 003.jpg'><img src='modules/cms/showthumb.php?image=../.././images/28th/Picture 003.jpg' ALT='Picture 003.jpg'><BR>Picture 003.jpg<br>58.62 KB</a><div class='inv'><br><a href='./images/28th/Picture 003.jpg' ALT='Picture 003.jpg'>Picture 003.jpg</a></div></td>
<td><A ID='Picture 004.jpg' href='28th.php?fileId=Picture 004.jpg'><img src='modules/cms/showthumb.php?image=../.././images/28th/Picture 004.jpg' ALT='Picture 004.jpg'><BR>Picture 004.jpg<br>65.52 KB</a><div class='inv'><br><a href='./images/28th/Picture 004.jpg' ALT='Picture 004.jpg'>Picture 004.jpg</a></div></td>
<td><A ID='Picture 005.jpg' href='28th.php?fileId=Picture 005.jpg'><img src='modules/cms/showthumb.php?image=../.././images/28th/Picture 005.jpg' ALT='Picture 005.jpg'><BR>Picture 005.jpg<br>48.35 KB</a><div class='inv'><br><a href='./images/28th/Picture 005.jpg' ALT='Picture 005.jpg'>Picture 005.jpg</a></div></td>
</tr>
<tr><td><A ID='Picture 006.jpg' href='28th.php?fileId=Picture 006.jpg'><img src='modules/cms/showthumb.php?image=../.././images/28th/Picture 006.jpg' ALT='Picture 006.jpg'><BR>Picture 006.jpg<br>70.11 KB</a><div class='inv'><br><a href='./images/28th/Picture 006.jpg' ALT='Picture 006.jpg'>Picture 006.jpg</a></div></td>
<td><A ID='Picture 007.jpg' href='28th.php?fileId=Picture 007.jpg'><img src='modules/cms/showthumb.php?image=../.././images/28th/Picture 007.jpg' ALT='Picture 007.jpg'><BR>Picture 007.jpg<br>82.16 KB</a><div class='inv'><br><a href='./images/28th/Picture 007.jpg' ALT='Picture 007.jpg'>Picture 007.jpg</a></div></td>
<td><A ID='Picture 008.jpg' href='28th.php?fileId=Picture 008.jpg'><img src='modules/cms/showthumb.php?image=../.././images/28th/Picture 008.jpg' ALT='Picture 008.jpg'><BR>Picture 008.jpg<br>75.77 KB</a><div class='inv'><br><a href='./images/28th/Picture 008.jpg' ALT='Picture 008.jpg'>Picture 008.jpg</a></div></td>
<td><A ID='Picture 009.jpg' href='28th.php?fileId=Picture 009.jpg'><img src='modules/cms/showthumb.php?image=../.././images/28th/Picture 009.jpg' ALT='Picture 009.jpg'><BR>Picture 009.jpg<br>53 KB</a><div class='inv'><br><a href='./images/28th/Picture 009.jpg' ALT='Picture 009.jpg'>Picture 009.jpg</a></div></td>
<td><A ID='Picture 010.jpg' href='28th.php?fileId=Picture 010.jpg'><img src='modules/cms/showthumb.php?image=../.././images/28th/Picture 010.jpg' ALT='Picture 010.jpg'><BR>Picture 010.jpg<br>47.83 KB</a><div class='inv'><br><a href='./images/28th/Picture 010.jpg' ALT='Picture 010.jpg'>Picture 010.jpg</a></div></td>
</tr>
<tr><td><A ID='Picture 011.jpg' href='28th.php?fileId=Picture 011.jpg'><img src='modules/cms/showthumb.php?image=../.././images/28th/Picture 011.jpg' ALT='Picture 011.jpg'><BR>Picture 011.jpg<br>65.75 KB</a><div class='inv'><br><a href='./images/28th/Picture 011.jpg' ALT='Picture 011.jpg'>Picture 011.jpg</a></div></td>
<td><A ID='Picture 012.jpg' href='28th.php?fileId=Picture 012.jpg'><img src='modules/cms/showthumb.php?image=../.././images/28th/Picture 012.jpg' ALT='Picture 012.jpg'><BR>Picture 012.jpg<br>45.75 KB</a><div class='inv'><br><a href='./images/28th/Picture 012.jpg' ALT='Picture 012.jpg'>Picture 012.jpg</a></div></td>
<td><A ID='Picture 013.jpg' href='28th.php?fileId=Picture 013.jpg'><img src='modules/cms/showthumb.php?image=../.././images/28th/Picture 013.jpg' ALT='Picture 013.jpg'><BR>Picture 013.jpg<br>24 KB</a><div class='inv'><br><a href='./images/28th/Picture 013.jpg' ALT='Picture 013.jpg'>Picture 013.jpg</a></div></td>
<td><A ID='Picture 014.jpg' href='28th.php?fileId=Picture 014.jpg'><img src='modules/cms/showthumb.php?image=../.././images/28th/Picture 014.jpg' ALT='Picture 014.jpg'><BR>Picture 014.jpg<br>1024.3 KB</a><div class='inv'><br><a href='./images/28th/Picture 014.jpg' ALT='Picture 014.jpg'>Picture 014.jpg</a></div></td>
<td><A ID='Picture 015.jpg' href='28th.php?fileId=Picture 015.jpg'><img src='modules/cms/showthumb.php?image=../.././images/28th/Picture 015.jpg' ALT='Picture 015.jpg'><BR>Picture 015.jpg<br>813.17 KB</a><div class='inv'><br><a href='./images/28th/Picture 015.jpg' ALT='Picture 015.jpg'>Picture 015.jpg</a></div></td>
</tr>
<tr><td><A ID='Picture 016.jpg' href='28th.php?fileId=Picture 016.jpg'><img src='modules/cms/showthumb.php?image=../.././images/28th/Picture 016.jpg' ALT='Picture 016.jpg'><BR>Picture 016.jpg<br>1059.58 KB</a><div class='inv'><br><a href='./images/28th/Picture 016.jpg' ALT='Picture 016.jpg'>Picture 016.jpg</a></div></td>
<td><A ID='Picture 017.jpg' href='28th.php?fileId=Picture 017.jpg'><img src='modules/cms/showthumb.php?image=../.././images/28th/Picture 017.jpg' ALT='Picture 017.jpg'><BR>Picture 017.jpg<br>57.12 KB</a><div class='inv'><br><a href='./images/28th/Picture 017.jpg' ALT='Picture 017.jpg'>Picture 017.jpg</a></div></td>
<td><A ID='Picture 018.jpg' href='28th.php?fileId=Picture 018.jpg'><img src='modules/cms/showthumb.php?image=../.././images/28th/Picture 018.jpg' ALT='Picture 018.jpg'><BR>Picture 018.jpg<br>60.7 KB</a><div class='inv'><br><a href='./images/28th/Picture 018.jpg' ALT='Picture 018.jpg'>Picture 018.jpg</a></div></td>
<td><A ID='Picture 019.jpg' href='28th.php?fileId=Picture 019.jpg'><img src='modules/cms/showthumb.php?image=../.././images/28th/Picture 019.jpg' ALT='Picture 019.jpg'><BR>Picture 019.jpg<br>63.89 KB</a><div class='inv'><br><a href='./images/28th/Picture 019.jpg' ALT='Picture 019.jpg'>Picture 019.jpg</a></div></td>
<td><A ID='Picture 020.jpg' href='28th.php?fileId=Picture 020.jpg'><img src='modules/cms/showthumb.php?image=../.././images/28th/Picture 020.jpg' ALT='Picture 020.jpg'><BR>Picture 020.jpg<br>40.35 KB</a><div class='inv'><br><a href='./images/28th/Picture 020.jpg' ALT='Picture 020.jpg'>Picture 020.jpg</a></div></td>
</tr>
<tr><td><A ID='Picture 021.jpg' href='28th.php?fileId=Picture 021.jpg'><img src='modules/cms/showthumb.php?image=../.././images/28th/Picture 021.jpg' ALT='Picture 021.jpg'><BR>Picture 021.jpg<br>51.97 KB</a><div class='inv'><br><a href='./images/28th/Picture 021.jpg' ALT='Picture 021.jpg'>Picture 021.jpg</a></div></td>
<td><A ID='Picture 022.jpg' href='28th.php?fileId=Picture 022.jpg'><img src='modules/cms/showthumb.php?image=../.././images/28th/Picture 022.jpg' ALT='Picture 022.jpg'><BR>Picture 022.jpg<br>38.01 KB</a><div class='inv'><br><a href='./images/28th/Picture 022.jpg' ALT='Picture 022.jpg'>Picture 022.jpg</a></div></td>
<td><A ID='Picture 023.jpg' href='28th.php?fileId=Picture 023.jpg'><img src='modules/cms/showthumb.php?image=../.././images/28th/Picture 023.jpg' ALT='Picture 023.jpg'><BR>Picture 023.jpg<br>47.63 KB</a><div class='inv'><br><a href='./images/28th/Picture 023.jpg' ALT='Picture 023.jpg'>Picture 023.jpg</a></div></td>
<td><A ID='Picture 024.jpg' href='28th.php?fileId=Picture 024.jpg'><img src='modules/cms/showthumb.php?image=../.././images/28th/Picture 024.jpg' ALT='Picture 024.jpg'><BR>Picture 024.jpg<br>37.31 KB</a><div class='inv'><br><a href='./images/28th/Picture 024.jpg' ALT='Picture 024.jpg'>Picture 024.jpg</a></div></td>
<td><A ID='Picture 025.jpg' href='28th.php?fileId=Picture 025.jpg'><img src='modules/cms/showthumb.php?image=../.././images/28th/Picture 025.jpg' ALT='Picture 025.jpg'><BR>Picture 025.jpg<br>56.44 KB</a><div class='inv'><br><a href='./images/28th/Picture 025.jpg' ALT='Picture 025.jpg'>Picture 025.jpg</a></div></td>
</tr>
<tr><td><A ID='Picture 026.jpg' href='28th.php?fileId=Picture 026.jpg'><img src='modules/cms/showthumb.php?image=../.././images/28th/Picture 026.jpg' ALT='Picture 026.jpg'><BR>Picture 026.jpg<br>48.89 KB</a><div class='inv'><br><a href='./images/28th/Picture 026.jpg' ALT='Picture 026.jpg'>Picture 026.jpg</a></div></td>
<td><A ID='Picture 027.jpg' href='28th.php?fileId=Picture 027.jpg'><img src='modules/cms/showthumb.php?image=../.././images/28th/Picture 027.jpg' ALT='Picture 027.jpg'><BR>Picture 027.jpg<br>36.13 KB</a><div class='inv'><br><a href='./images/28th/Picture 027.jpg' ALT='Picture 027.jpg'>Picture 027.jpg</a></div></td>
<td><A ID='Picture 028.jpg' href='28th.php?fileId=Picture 028.jpg'><img src='modules/cms/showthumb.php?image=../.././images/28th/Picture 028.jpg' ALT='Picture 028.jpg'><BR>Picture 028.jpg<br>74.68 KB</a><div class='inv'><br><a href='./images/28th/Picture 028.jpg' ALT='Picture 028.jpg'>Picture 028.jpg</a></div></td>
<td><A ID='Picture 029.jpg' href='28th.php?fileId=Picture 029.jpg'><img src='modules/cms/showthumb.php?image=../.././images/28th/Picture 029.jpg' ALT='Picture 029.jpg'><BR>Picture 029.jpg<br>64.4 KB</a><div class='inv'><br><a href='./images/28th/Picture 029.jpg' ALT='Picture 029.jpg'>Picture 029.jpg</a></div></td>
<td><A ID='Picture 030.jpg' href='28th.php?fileId=Picture 030.jpg'><img src='modules/cms/showthumb.php?image=../.././images/28th/Picture 030.jpg' ALT='Picture 030.jpg'><BR>Picture 030.jpg<br>60.93 KB</a><div class='inv'><br><a href='./images/28th/Picture 030.jpg' ALT='Picture 030.jpg'>Picture 030.jpg</a></div></td>
</tr>
<tr><td><A ID='Picture 031.jpg' href='28th.php?fileId=Picture 031.jpg'><img src='modules/cms/showthumb.php?image=../.././images/28th/Picture 031.jpg' ALT='Picture 031.jpg'><BR>Picture 031.jpg<br>76.25 KB</a><div class='inv'><br><a href='./images/28th/Picture 031.jpg' ALT='Picture 031.jpg'>Picture 031.jpg</a></div></td>
<td><A ID='Picture 032.jpg' href='28th.php?fileId=Picture 032.jpg'><img src='modules/cms/showthumb.php?image=../.././images/28th/Picture 032.jpg' ALT='Picture 032.jpg'><BR>Picture 032.jpg<br>21.13 KB</a><div class='inv'><br><a href='./images/28th/Picture 032.jpg' ALT='Picture 032.jpg'>Picture 032.jpg</a></div></td>
<td><A ID='Picture 033.jpg' href='28th.php?fileId=Picture 033.jpg'><img src='modules/cms/showthumb.php?image=../.././images/28th/Picture 033.jpg' ALT='Picture 033.jpg'><BR>Picture 033.jpg<br>51.76 KB</a><div class='inv'><br><a href='./images/28th/Picture 033.jpg' ALT='Picture 033.jpg'>Picture 033.jpg</a></div></td>
<td><A ID='Picture 034.jpg' href='28th.php?fileId=Picture 034.jpg'><img src='modules/cms/showthumb.php?image=../.././images/28th/Picture 034.jpg' ALT='Picture 034.jpg'><BR>Picture 034.jpg<br>43.9 KB</a><div class='inv'><br><a href='./images/28th/Picture 034.jpg' ALT='Picture 034.jpg'>Picture 034.jpg</a></div></td>
<td><A ID='Picture 035.jpg' href='28th.php?fileId=Picture 035.jpg'><img src='modules/cms/showthumb.php?image=../.././images/28th/Picture 035.jpg' ALT='Picture 035.jpg'><BR>Picture 035.jpg<br>71.75 KB</a><div class='inv'><br><a href='./images/28th/Picture 035.jpg' ALT='Picture 035.jpg'>Picture 035.jpg</a></div></td>
</tr>
<tr><td><A ID='Picture 036.jpg' href='28th.php?fileId=Picture 036.jpg'><img src='modules/cms/showthumb.php?image=../.././images/28th/Picture 036.jpg' ALT='Picture 036.jpg'><BR>Picture 036.jpg<br>62.15 KB</a><div class='inv'><br><a href='./images/28th/Picture 036.jpg' ALT='Picture 036.jpg'>Picture 036.jpg</a></div></td>
<td><A ID='Picture 037.jpg' href='28th.php?fileId=Picture 037.jpg'><img src='modules/cms/showthumb.php?image=../.././images/28th/Picture 037.jpg' ALT='Picture 037.jpg'><BR>Picture 037.jpg<br>70.56 KB</a><div class='inv'><br><a href='./images/28th/Picture 037.jpg' ALT='Picture 037.jpg'>Picture 037.jpg</a></div></td>
<td><A ID='Picture 038.jpg' href='28th.php?fileId=Picture 038.jpg'><img src='modules/cms/showthumb.php?image=../.././images/28th/Picture 038.jpg' ALT='Picture 038.jpg'><BR>Picture 038.jpg<br>65.61 KB</a><div class='inv'><br><a href='./images/28th/Picture 038.jpg' ALT='Picture 038.jpg'>Picture 038.jpg</a></div></td>
<td><A ID='Picture 039.jpg' href='28th.php?fileId=Picture 039.jpg'><img src='modules/cms/showthumb.php?image=../.././images/28th/Picture 039.jpg' ALT='Picture 039.jpg'><BR>Picture 039.jpg<br>100.04 KB</a><div class='inv'><br><a href='./images/28th/Picture 039.jpg' ALT='Picture 039.jpg'>Picture 039.jpg</a></div></td>
<td><A ID='Picture 040.jpg' href='28th.php?fileId=Picture 040.jpg'><img src='modules/cms/showthumb.php?image=../.././images/28th/Picture 040.jpg' ALT='Picture 040.jpg'><BR>Picture 040.jpg<br>22.11 KB</a><div class='inv'><br><a href='./images/28th/Picture 040.jpg' ALT='Picture 040.jpg'>Picture 040.jpg</a></div></td>
</tr>
<tr><td><A ID='Picture 041.jpg' href='28th.php?fileId=Picture 041.jpg'><img src='modules/cms/showthumb.php?image=../.././images/28th/Picture 041.jpg' ALT='Picture 041.jpg'><BR>Picture 041.jpg<br>65.81 KB</a><div class='inv'><br><a href='./images/28th/Picture 041.jpg' ALT='Picture 041.jpg'>Picture 041.jpg</a></div></td>
</tr>
</table>	</div>
</div>
</body>
</html>