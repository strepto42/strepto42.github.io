<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - November 2003 - Q&A letters</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="Q&A letters">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="Q&A letters" href='masterit200301.php'>January 2003</a></li>
<li><a title="Q&A letters" href='masterit200302.php'>February 2003</a></li>
<li><a title="Q&A letters" href='masterit200303.php'>March 2003</a></li>
<li><a title="Q&A letters" href='masterit200304.php'>April 2003</a></li>
<li><a title="Q&A letters" href='masterit200305.php'>May 2003</a></li>
<li><a title="Q&A letters" href='masterit200306.php'>June 2003</a></li>
<li><a title="Q&A letters" href='masterit200307.php'>July 2003</a></li>
<li><a title="Q&A letters" href='masterit200308.php'>August 2003</a></li>
<li><a title="Q&A letters" href='masterit200309.php'>September 2003</a></li>
<li><a title="Q&A letters" href='masterit200310.php'>October 2003</a></li>
<li><div class='activemenu'>November 2003</div></li>
<li><a title="Q&A letters" href='masterit200312.php'>December 2003</a></li>
<li> </li><br><li>Or go back to:</li><li><a title='Q&A/MasterIT letters from 2003' href="masterit2003.php">2003 archive</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>November 2003</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Mark's writing' href="written.php">Professional Writing</a> > <a title='My weekly Q&A column in The Australian' href="masterIT.php">MasterIT</a> > <a title='Q&A/MasterIT letters from 2003' href="masterit2003.php">2003 archive</a> > <a title='Q&A letters' href="masterit200311.php">November 2003</a>
<br><br>		<br>
<h2>4/11/03</h2><br>
<b>I am running Windows98 with an HPDeskjet 400. When trying to print envelopes I cannot get the printer to respond to manual feed setting. It withdraws from the paper tray. Have checked all settings and re-installed the driver without result. Would you say this is a problem in the printer itself?<br>
It's quite possible, especially if the printer is a few years old.</b><br>
<br>
If you can, try the printer on a different computer, preferably one with a different version of Windows, and see if it still has the same problem. If it does, it's almost certainly a hardware issue.<br>
<br>
<br>
<b>I am running windows 98 and have recently noticed an awful amount of popup ads appearing on my screen. Do you know any good (free) software or strategies to remove these ads?</b><br>
<br>
Various third party pop-up blockers are readily available on the internet. Check out <a href="http://www.download.com" target="_blank">www.download.com</a> or your favourite search engine. Mozilla (<a href="http://www.mozilla.org" target="_blank">www.mozilla.org</a>) also has a really good pop-up blocker built in.<br>
<br>
It's also possible you've inadvertently installed some bottom-feeding spyware/adware application like Gator. You might like to download Ad-aware from <a href="http://www.lavasoft.de" target="_blank">www.lavasoft.de</a> and check your system to make sure it's clean.<br>
<br>
<br>
<b>My new PC has got Windows XP home on it. It requires me to log on with a username and password. Is this strictly necessary? I'm the only person who's going to be using it, and I don't have any particularly 'sensitive' files.</b><br>
<br>
It's fairly easy to set up an auto-login for XP, but although Windows supports it, you can't actually set it up without downloading a special program (or hacking your registry).<br>
<br>
The latter will earn you geek kudos but the former is easier. There are many utilities out there to fiddle with XP's hidden settings. TweakUI is simple, it's free and is even an official Microsoft product. Grab it from <a href="http://www.microsoft.com/windowsxp/downloads/powertoys/xppowertoys.mspx" target="_blank">www.microsoft.com/windowsxp/downloads/powertoys/xppowertoys.mspx</a>.<br>
<br>
Once you've installed it, expand the "logon" menu and set up your options in Autologon.<br>
<br>
You might like to go to the General menu, select Focus and tick the box to prevent applications stealing the focus as this is probably the single most irritating thing Windows does. Ever.<br>
<br>
<br>
<h2>11/11/03</h2><br>
<b>David Frith (The Barrow, 4/11) wrote about Apple's attempts to convert Mac OS 9 users to the new operating system, Panther, or OS X 10.3. I would be happy to pay the $229 asking fee, but have a problem. My PowerPC G3 runs at 233MHz with 224 MB memory, which is all I need, and I can't afford one of those magnificent new iMacs with a flat screen and half a football that contains the grunt.<br>
<br>
Two questions. Can I run Panther on my machine? And would I need to upgrade my software (mainly PageMaker and Photoshop) - at more expense - if I could?</b><br>
<br>
You may be able to run Panther, but you must have a Mac with built in USB, as this is one of the hardware requirements. The full list can be found on Apple's website at <a href="http://www.apple.com/macosx/upgrade/requirements.html" target="_blank">www.apple.com/macosx/upgrade/requirements.html</a>.<br>
<br>
Bear in mind that the requirement of at least 128MB of memory means physical (and not virtual) memory.<br>
<br>
Also, remember that you may find Panther a bit slower than OS9, despite it being reportedly the fastest version of X thus far. That said, the new GUI is still a lot nicer to use. It's like comparing a Toyota Crown with a Prius.<br>
<br>
Your existing applications can be run using Classic Mode, which essentially emulates the OS9 environment. There will be a speed hit associated with doing this though - they'll run slower and you'll use more memory. Some applications won't run properly in classic mode either, although you should be pretty right with the more common ones.<br>
<br>
At the end of the day though, to get the most out of your apps though you'll need to upgrade them. Adobe have OS X versions of Pagemaker and Photoshop available, at a cost of course.<br>
<br>
If you're using an old Beige G3 box without USB though, your only option is a hardware upgrade. A cheaper solution than the an iMac may be the eMac. It lacks the groovy LCD but still packs a reasonable punch, and for quite a few less dollars - the base model lists for $A1350, however with 128mb of ram you'd most likely want to add some.<br>
<br>
<br>
Send pro-Toyota-crown-flames and queries to <a href="contact.php">(the masterit contact email address)</a>.<br>
<br>
<br>
<h2>18/11/03</h2><br>
<b>I'm setting up a small, quiet PC as a file server & DVD player. I'd also like to hook it up to the stereo and use it to play MP3s, and I was wondering what the Master recommends regarding the best software to do this. I'm also interested in any information regarding remote controlling the PC.</b><br>
<br>
Currently, three good options to look at are Winamp, Musicmatch Jukebox and the recently launched PC version of Apple's iTunes.<br>
<br>
When we say Winamp, we mean of course Winamp 2.91; Winamp 3 is a bit of a Spruce Goose. It's certainly the most basic player of the lot, but it's fast, free and now has a nice music library feature built in to help organise your music.<br>
<br>
Musicmatch Jukebox is available in a free, cut down version, or a "pro" version which adds some extra functionality at a price. If Winamp is a steak knife (ok, maybe a Splade), Musicmatch is a Swiss Army Knife, with the features of Winamp, plus provision to rip (copy from) and burn CDs. The pro version will also let you print CD covers, and record directly from a line-in source (like an old school record or tape player - remember those?).<br>
<br>
Apple's iTunes is the new kid on the block for PC users - Mac users have enjoyed it for years. It's also an all-in-one solution, with music library, ripping and burning options, as well as access to Apple's online music store, where you can buy music quite cheaply (and of course legally).<br>
<br>
Both Musicmatch and iTunes also support Apple's iPod, although reportedly installing iTunes disables support for it in Musicmatch.<br>
<br>
As far as remote control options go, there are plenty of solutions available. Often sound cards come with a remote; whether or not they can control the software you want is up to their drivers.<br>
<br>
A good jumping off point is <a href="http://www.pcremotecontrol.com" target="_blank">www.pcremotecontrol.com</a>. It's a shareware site that offers generic software for using remotes, and it has a good list of links to available hardware, including <a href="http://www.evation.com" target="_blank">www.evation.com</a>, home of the Irman, which is an excellent remote receiver with good software support for all sorts of Windows applications.<br>
<br>
<br>
<h2>25/11/03</h2><br>
<b>After formatting my C drive and reinstalling my Creative Sound Blaster Live Value sound card, I am getting crashes with the blue screen error: A FATAL EXCEPTION OE, HAS OCCURED AT OO28:C14B4DOO IN VXD EMUIOKI(O1) +OOOOB830. Do I need to download some sort of driver? What's up?</b><br>
<br>
This is apparently a fairly common (and old) problem with Win98 and ME. Your best first port of call will be the Creative Labs website (<a href="http://us.creative.com/support/downloads" target="_blank">us.creative.com/support/downloads</a>) from which you can download the latest driver.<br>
<br>
If installing the new sound card driver doesn't help, you may have to do some fiddling with your VXD drivers. These are special kernel drivers used by Windows. Rather than regurgitate all the info here, check out <a href="http://tweakhomepc.virtualave.net/upd/vmm32vxd.shtml" target="_blank">tweakhomepc.virtualave.net/upd/vmm32vxd.shtml</a> for the good oil, including plenty of things you can try to fix the problem.<br>
<br>
<br>
<b>I've recently tried to record something on my laptop's WIN 98SE inbuilt recorder and when I play the recording back it's very noisy with lots of whirring and static-like sounds as well as the recorded sound. This happens with both the inbuilt microphone and an external microphone. The soundcard is the standard inbuilt one. Any ideas as to what could be causing this?</b><br>
<br>
It could just be a software issue; try recording with a different application and see if the noise is still there. An updated sound card driver could also help.<br>
<br>
Finally, check the recording properties of the microphone. Open the windows sound mixer, check under the Options menu to make sure that advanced controls are enabled, then check those controls. Some sound card drivers have an optional "mic boost" setting which increases the volume of recorded sound, but which also adds a ton of noise to the signal.<br>
<br>
Another possibility is that you could be picking up some nasty electrical interference. Check to see if the problem exists at different locations, and if being on batteries changes anything.<br>
<br>
Unfortunately, many laptops have pretty lousy onboard sound cards. It's quite possible that this is the best yours can manage. If all else fails, there are pretty good external USB sound cards available now; one might be a worthwhile investment.<br>
<br>
<i><p>Did the information on this page help you? Entertain you? Bore you? <a href="contact.php?subject=MasterIT">Drop me a line</a>.</p>

<p>If you're feeling particularly generous, you can even <a href="buypics.php">click here to send me some dot-com riches</a>. Think of it as online busking.</i></p>
	</div>
</div>
</body>
</html>