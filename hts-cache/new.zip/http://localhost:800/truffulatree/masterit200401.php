<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - January 2004 - Q&A letters</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="Q&A letters">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><div class='activemenu'>January 2004</div></li>
<li><a title="Q&A letters" href='masterit200402.php'>February 2004</a></li>
<li><a title="Q&A letters" href='masterit200403.php'>March 2004</a></li>
<li><a title="Q&A letters" href='masterit200404.php'>April 2004</a></li>
<li><a title="Q&A letters" href='masterit200405.php'>May 2004</a></li>
<li><a title="Q&A letters" href='masterit200406.php'>June 2004</a></li>
<li><a title="Q&A letters" href='masterit200407.php'>July 2004</a></li>
<li><a title="Q&A letters" href='masterit200408.php'>August 2004</a></li>
<li><a title="Q&A letters" href='masterit200409.php'>September 2004</a></li>
<li><a title="Q&A letters" href='masterit200410.php'>October 2004</a></li>
<li><a title="Q&A letters" href='masterit200411.php'>November 2004</a></li>
<li><a title="Q&A letters" href='masterit200412.php'>December 2004</a></li>
<li> </li><br><li>Or go back to:</li><li><a title='Q&A/MasterIT letters from 2004' href="masterit2004.php">2004 archive</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>January 2004</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Mark's writing' href="written.php">Professional Writing</a> > <a title='My weekly Q&A column in The Australian' href="masterIT.php">MasterIT</a> > <a title='Q&A/MasterIT letters from 2004' href="masterit2004.php">2004 archive</a> > <a title='Q&A letters' href="masterit200401.php">January 2004</a>
<br><br>		<br>
<h2>27/1/2004</h2><br>
<b>I have a question about making a copy of songs from websites. As you may know, not all websites allow you to save songs. Some of them only allow you to play and listen to them online. If you right click on the link for the song, you only get the option of saving it as an HTML or ASP file. I do know that the song initially gets into the buffer of the local disk before it is played. So are there any means of recording it as it is being played?</b><br>
<br>
It's quite possible to capture streaming audio, but you'll probably need a third party program to do it.<br>
<br>
The reason you get a webpage rather than the audio itself when you try to "save as" is that the link you click on only contains another link to the actual audio. In many cases this second link points to a special server that only delivers the audio a bit at a time, so you can't just save the file from here either.<br>
<br>
A quick Google search came up with three programs that will let you save streaming audio (these are untested by the Master so standard disclaimers apply).<br>
<br>
The first is called Ripcast Streaming Audio Ripper (a naming masterpiece of brevity) and it will allow you to save audio from Shoutcast servers (a very popular type of Internet radio).<br>
<br>
The next is confidently named Super MP3 Recorder, and it'll deal with many audio formats, including Windows Media Player, QuickTime, RealPlayer, and Flash. Captured audio can apparently be saved as WAV or MP3 files.<br>
<br>
Last on the list is Real MP3 Recorder, with similar functionality to the last contender.<br>
<br>
All these programs are shareware, and the first two have limitations - Ripcast can only record 30mb of audio and won't allow more than two simultaneous downloads. Super MP3 Recorder will only let you record 40 second bursts.<br>
<br>
You can find Ripcast at <a href="http://www.xoteck.com/ripcast" target="_blank">www.xoteck.com/ripcast</a>, Super MP3 Recorder at <a href="http://www.supermp3recorder.com" target="_blank">www.supermp3recorder.com</a>, and Real MP3 Recorder by searching at www.download.com.<br>
<br>
Remember that you might be violating copyright by capturing music, and you should always support artists where possible (especially the struggling variety, which is most of them, and there's plenty of those on the net!).<br>
<br>
<i><p>Did the information on this page help you? Entertain you? Bore you? <a href="contact.php?subject=MasterIT">Drop me a line</a>.</p>

<p>If you're feeling particularly generous, you can even <a href="buypics.php">click here to send me some dot-com riches</a>. Think of it as online busking.</i></p>
	</div>
</div>
</body>
</html>