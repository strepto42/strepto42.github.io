<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:v="urn:schemas-microsoft-com:vml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - The Red Centre - Alice Springs and surrounds</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="Alice Springs and surrounds">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://maps.google.com/maps?file=api&amp;v=2&amp;key=ABQIAAAAlaGTdQKzpFhAqFR_JcbA7xRW4RXHGTymU03qqBIMaqzwHnmPjBToKZLfamCKvG6RWS9CNwQTlUDziw" type="text/javascript"></script>

	</head>

<body onload="load();" onunload="GUnload();">
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="Travelouges from my trip through India in 2000" href='india2000.php'>India 2000</a></li>
<li><a title="Travelouges and blogs from my trip around Australia" href='nerdseyeview.php'>Nerd's Eye View</a></li>
<li><a title="Warrumbungle, Kings Plains and Bald Rock National Parks" href='outbackNSW.php'>Outback NSW</a></li>
<li><div class='activemenu'>The Red Centre</div></li>
<li> </li><br><li>Or go back to:</li><li><a title='Travel stories and pictures' href="travel.php">Travelogues</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>The Red Centre</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Travel stories and pictures' href="travel.php">Travelogues</a> > <a title='Alice Springs and surrounds' href="redcentre.php">The Red Centre</a>
<br><br>		

<div id="gmap_div" style="border: 0px none ; margin: 3px; padding: 0px; width: 675px; height: 400px; float: right; vertical-align: text-top;"></div>
<p>Again, it seems that time has flown. My <a href="outbackNSW.php">last travel diary</a> was from early 2007. Now, I'm writing about August 2008, from the start of 2009... gah!</p>

<p>Anyway, back last August my aunt, cousin and their friend visited from Italy. Not content with boring old NSW, Mum and Dad soon hatched a plan to show them some of the "real" outback.</p>

<p>The plan was to spend a couple of days touring around the <a href="http://en.wikipedia.org/wiki/MacDonnell_Ranges" target="_blank">MacDonnell Ranges</a> near <a href="http://www.alicesprings.nt.gov.au" target="_blank">Alice Springs</a>, giving Mum and Dad a chance to revisit some places they'd been years before, and the rest of us a chance to explore some of the Aussie red centre.</p>

<p>Myself, I never got to Alice Springs when I was doing the big <a href="nerdseyeview.php">Nerd's Eye View</a> trip. I got as far as the <a href="intothenevernever.php">Devil's Marbles</a>, but Alice was just too much further out of the way. So, I was loving the idea of getting out and seeing some beautiful gorges again, especially in a place I hadn't ever been.</p>

<p>And so, on with the story. First of all my presence on the trip was to be kept a secret, and so I flew directly from Brisbane to Alice, and was there waiting when the rest of the troops arrived. Thankfully there were no heart attacks, just great excitement all round.</p>

<p>We spent the first evening at the <a href="http://www.auroraresorts.com.au/Accommodation/HeavitreeGapOutbackLodge/tabid/114/language/en-US/Default.aspx" target="_blank">Heavitree Gap Outback Lodge</a>, just out of town. It wasn't a bad start at all - a very pretty setting, and some friendly local <a href="http://en.wikipedia.org/wiki/Black-flanked_Rock-wallaby" target="_blank">Black-footed Rock Wallabies</a> wowed us all. I'm not normally one for feeding wildlife, but these wallabies were already well fed with the right food (yours for a price of course), and they were tremendously cute, so what can you do.</p>

<h2>Day 1.</h2>

<p>We started our tour the next day. My folks had booked a private tour, for we filled a big 4WD nicely, so it was up to us how much time we wanted to spend doing things. This was quite nice, as it meant we could skip some things in order to spend more time doing others.</p>

<p>Our guide Colin picked us up, and after squeezing all our luggage and ourselves into the car we set off. First stop was a quick (and freezing - it was cold!) look around Alice Springs from the lookout there, and then it was off to Standley Chasm.</p>

<p>The MacDonnell range runs pretty much straight west from Alice, and is peppered with lovely gorges, and Standley Chasm is one of the closer ones to town.</p>

<p>It's quite narrow, and at midday is apparently very spectacular, but we were there early in the morning. I have to say it was still pretty nice. It was also a great feeling to get out into the bush again, even if this time I was with a tour and various rellies. The fact of the matter is that I wasn't so spry anyway, having <a href="bloodyknee.php">torn</a> my <a href="http://en.wikipedia.org/wiki/Anterior_cruciate_ligament" target="_blank">ACL</a> only a week or two beforehand, so I had to be extra careful not to do any further damage to my wobbly knee.</p>

<p>(Stress and nervous tension are now serious social problems in all parts of the Galaxy,  and it is in order that this situation should not in any way be exacerbated that the following fact will now be revealed in advance: my knee was fine; the worst thing that happened was that everyone watched me like hungry wolves to make sure I wasn't being silly with it)</p>

<p>Anyway the chasm was lovely, as was the scenery, and I even got to snap some birds (a <a href="http://www.birdsinbackyards.net/finder/display.cfm?id=144" target="_blank">White-plumed Honeyeater</a> and <a href="http://www.birdsinbackyards.net/finder/display.cfm?id=17" target="_blank">Grey Shrike-thrush</a> - not very exciting but still...). Actually it turned out that Colin, our tour guide, was into both geology and birds, so that pretty much suited Dad and I to a T.</p>

<p>After a cup of tea by the fire at the cafeteria there (yup, it's a bit touristy, and yes, it was pretty cold!) we made our way back into the car, and to Ellery Creek Big Hole. This is a lovely little gorge with a lake in it (at this time of year), and during summer is a particularly popular spot for locals and tourists alike.</p>

<p>We spent some time admiring the pretty - but freezing - water, and spotted some <a href="http://www.birdsinbackyards.net/finder/display.cfm?id=317" target="_blank">Diamond Firetails</a>, which were a little unexpected, before heading off on a walk through the dry river bed for a while.</p>

<p>More lovely scenery ensued, and, while Dad checked out the rocks, I watched a couple of <a href="http://www.birdsinbackyards.net/finder/display.cfm?id=174" target="_blank">Rainbow Bee-eaters</a> as they picked the flies off from around us.</p>

<p>After a significant amount of dawdling, we headed off to <a href="http://www.glenhelen.com.au" target="_blank">Glen Helen Resort</a>, the place our tour was based, and also the place we were staying that night. We'd decided to splurge and do some quick helicopter rides around the Glen Helen Gorge, and I think that despite some arm twisting being needed for some of the party, a great time was had by all.</p>

<p>I for one love helicopters - and I've wanted to get back into one ever since I did an <a href="http://www.airwork.com.au/J_TIF.html" target="_blank">introductory flight thing</a> for my 30th. The flights over the gorge were perfect, not only because of the scenery, but because they were in a little <a href="http://www.bell47.net/" target="_blank">Bell 47</a> helicopter with no doors, the same as the one I'd flown in before. No doors also means good photos. :)</p>

<p>(If I ever become fabulously rich, there's no way I'd waste my money on a <a href="legaciesofwar.php?fileId=IMG_8120.JPG">stupid big boat</a>. It's gotta be a helicopter all the way!)</p>

<p>Anyway, after our little skyward diversion we squeezed back into the car, and Colin showed us some of the local area, including an interesting place with odd geology. After poking around for a while Dad concluded that someone had probably done some mineral exploration there, as the geology suggested that something interesting could have lain beneath the surface. I guess in the end they concluded that it didn't - but the colours of the place were still pretty amazing.</p>

<p>By then it was pretty late, so we hurried back out to Ormiston Gorge. It's a pretty amazing place; two mountain ranges meet there and the rocks are piled up on top of each other, so the cliffs are doubly high. The atmosphere at dusk was quite serene too.</p>

<p>I spotted a <a href="http://www.birdsinbackyards.net/finder/display.cfm?id=221" target="_blank">White-necked Heron</a> and what I think were <a href="http://www.birdsinbackyards.net/finder/display.cfm?id=200" target="_blank">Chestnut Teal</a>, as well as more of the rock wallabies. It's a shame we had to flit through the places we did so quickly; back when I was travelling I would have spent days at some of these places, but that was the nature of the tour beast, and I had a bum knee after all. I'll just have to come back in my car some day for Nerd's Eye II.</p>

<p>So back we whizzed to Glen Helen, for a nice dinner, and some pretty damn good acoustic music.</p>

<h2>Day 2.</h2>

<p>It was another crack of dawn start, but that's what you get when you try to jam as much stuff as possible into two days, and by now Colin was wise to our dawdling ways and knew it was going to be a long one.</p>

<p>We had a nice big brekkie while we checked out the amazing colours of the rock wall just behind Glen Helen (<a href="redcentre.php?fileId=glenhelen_panorama.JPG">panorama</a>), then it was time to wedge into the car again and head out to Roma Gorge.</p>

<p>It was a nice contrast to the previous day's tourist spots, as Roma Gorge is off the beaten track a bit, and you need to drive up a dry creek bed to get there for a while. It's famous for its rock art - in the form of carvings rather than paintings which made a nice change from the usual. Colin was also hoping there would be some good bird life there, but the waterhole had dried up completely, so the wildlife had moved on. We did see some <a href="http://www.graemechapman.com.au/cgi-bin/viewphotos.php?c=369" target="_blank">Mulga Parrots</a> though (which proved bloody elusive to photograph).</p>

<p>Roma Gorge also had a pretty special atmosphere to it. Some places are just like that; you can feel the history and character of the place. It's great that we got there.</p>

<p>Once again I could have stayed there for hours, but time pressed us and we headed off on a grand old drive via some 'back streets' (rough 4WD tracks) which took in some great views before arriving back at the main road and Tyler's Pass Lookout.</p>

<p>It was from there that we got our first view in the distance of <a href="http://amonline.net.au/geoscience/earth/gosses.htm" target="_blank">Gosses Bluff</a> (<a href="redcentre.php?fileId=gossesbluff_outside_panorama.JPG">panorama</a>), our next destination and I think, highlight for more than one person on the trip. :)</p>

<p>Gosses Bluff is the remnant of a meteorite impact crater. It's not, however, the rim wall of the original crater. Rather, it's what remains of the central cone of the crater (which would have been about 22kms across, but is now completely eroded away).</p>

<p>Compare and contrast that with my two other previous meteorite crater encounters - the serene <a href="http://en.wikipedia.org/wiki/Lonar_crater" target="_blank">Lonar crater</a> in <a href="backtobloodyreality.php">India</a> (1.8kms across), and the fabulous <a href="http://www.mindat.org/loc-10207.html" target="_blank">Wolfe Creek crater</a> <a href="thingsfromabove.php">in WA</a> (a mere 800m across)... yes, this one was big.</p>

<p>Anyway, Gosses Bluff (or Tnorala, to use it's traditional name) is where we went next.</p>

<p>Before we had a good explore, Colin produced morning tea for us and we were visited by two very sweet birds, a <a href="http://www.birdsinbackyards.net/finder/display.cfm?id=308" target="_blank">Crested Bellbird</a> and a very fluffed up <a href="http://www.birdphotos.com.au/Western%20Bowerbird/default.html" target="_blank">Western Bowerbird</a>.</p>

<p>Then we spent a while exploring the crater (<a href="redcentre.php?fileId=gossesbluff_inside_panorama.JPG">panorama</a>), and looking for <a href="http://en.wikipedia.org/wiki/Shatter_cone" target="_blank">shatter cones</a> on the ground. These are geological structures within the rocks that are basically results of the rock being blasted to buggery when the meteor hits.</p>

<p>I'd love to go back there again some day, and spend a couple of days exploring, although I think parts of the place are off-limits at the request of the traditional owners, which is a shame really.</p>

<p>By now it was getting late (our little morning tea had been more like lunch), so we pressed on again. We had a quick look at Albert Namatjira's house, and then the town of Hermannsburg.</p>

<p>I'm sad to say that the latter won't be winning any tidy town awards in the near future, but such is life. The old buildings were interesting, as was the solar power station just out of town.</p>

<p>Then it was time to press on to Palm Valley. We drove part of the way in before settling down for a late lunch, accompanied once again by avian friends (<a href="http://www.lanerealty.com.au/picPiedButcherbird.html" target="_blank">Pied Butcherbirds</a> and the like - they must really love tourists), then Colin drove us in to the Valley of the Palms itself.</p>

<p>The drive is totally off-road stuff, but after a bit of amusing bouncing around we made it in there and had a fairly quick (comparatively) walk around. It's really quite lovely in there, and worth the trip. But because we dawdled so much in other spots (particularly Gosses Bluff) we had to leave and head back to Alice.</p>

<p>I guess I'll just had to go back there myself sometime, although the old Subie <a href="http://www.digi-comic.com/?comicId=50" target="_blank">won't make it</a> in there, so I'll have to work something out. :)</p>

<p>Anyway, after a long drive back at sunset Colin deposited us back in Alice, long after the tour was actually supposed to finish. I have to take my hat off to him - he really did make the trip interesting and worthwhile, and he tolerated our various forms of madness quite cheerfully (and I think he may have even picked up some Italian). If you're in the area, <a href="http://www.glenhelen.com.au" target="_blank">Glen Helen</a> is a beautiful place to stay (you can even camp there for free, so long as you don't want any amenities!), and as far as tours go they don't get much better than that.</p>

<p>So thanks again, and thanks to my folks for making is possible, and to Zia Meme, Rusi and Paola for giving them an excuse by visiting!</p>

<p>And now... the pictures. Enjoy.</p>

   <script type="text/javascript">
    //<![CDATA[
    function load() {
      if (GBrowserIsCompatible()) {
        var map = new GMap2(document.getElementById("gmap_div"));
		map.setCenter(new GLatLng(-23.79208,133.16), 9, G_HYBRID_MAP);
		map.addControl(new GLargeMapControl());
		map.addControl(new GScaleControl());
		map.addControl(new GMapTypeControl());

		var polyline = new GPolyline([
						new GLatLng(-23.7274647,133.8666916),
						new GLatLng(-23.7292242,133.8657904),
						new GLatLng(-23.7284517,133.8641596),
						new GLatLng(-23.7214565,133.8672709),
						new GLatLng(-23.7211132,133.8687944),
						new GLatLng(-23.7025952,133.8813686),
						new GLatLng(-23.7032819,133.8856173),
						new GLatLng(-23.7013936,133.8911533),
						new GLatLng(-23.6960721,133.8949084),
						new GLatLng(-23.6969948,133.884201),
						new GLatLng(-23.698175,133.8835788),
						new GLatLng(-23.6969733,133.8840508),
						new GLatLng(-23.695085,133.8798881),
						new GLatLng(-23.692832,133.879652),
						new GLatLng(-23.6944413,133.8820767),
						new GLatLng(-23.6926389,133.8778067),
						new GLatLng(-23.6933041,133.8743949),
						new GLatLng(-23.6943984,133.8742661),
						new GLatLng(-23.6900425,133.8627005),
						new GLatLng(-23.6978316,133.8596749),
						new GLatLng(-23.7012434,133.8602543),
						new GLatLng(-23.70502,133.8551259),
						new GLatLng(-23.7045693,133.8525724),
						new GLatLng(-23.6978102,133.8422942),
						new GLatLng(-23.6984754,133.8232183),
						new GLatLng(-23.6952782,133.8095069),
						new GLatLng(-23.708303,133.7657547),
						new GLatLng(-23.7118649,133.7598968),
						new GLatLng(-23.7280655,133.744812),
						new GLatLng(-23.7400818,133.7230539),
						new GLatLng(-23.7435365,133.7134838),
						new GLatLng(-23.7512612,133.6812544),
						new GLatLng(-23.7565398,133.6676073),
						new GLatLng(-23.7584066,133.6582088),
						new GLatLng(-23.7716246,133.616817),
						new GLatLng(-23.7717748,133.605423),
						new GLatLng(-23.7788343,133.5609627),
						new GLatLng(-23.7826538,133.5490751),
						new GLatLng(-23.7823749,133.5258794),
						new GLatLng(-23.7869239,133.5154724),
						new GLatLng(-23.7802076,133.5067391),
						new GLatLng(-23.7628484,133.5013318),
						new GLatLng(-23.7580419,133.4917402),
						new GLatLng(-23.7373352,133.4823418),
						new GLatLng(-23.7297606,133.4704542),
						new GLatLng(-23.7257481,133.4686089),
						new GLatLng(-23.7216067,133.4699821),
						new GLatLng(-23.7208772,133.4689522),
						new GLatLng(-23.7159848,133.4704542),
						new GLatLng(-23.715384,133.4719348),
						new GLatLng(-23.7152982,133.4704757),
						new GLatLng(-23.7257695,133.4687376),
						new GLatLng(-23.7291598,133.4701324),
						new GLatLng(-23.7374425,133.4826636),
						new GLatLng(-23.7569261,133.4907317),
						new GLatLng(-23.7637925,133.5023189),
						new GLatLng(-23.7802505,133.5069108),
						new GLatLng(-23.7868595,133.5153437),
						new GLatLng(-23.7885547,133.5121679),
						new GLatLng(-23.7943912,133.5080695),
						new GLatLng(-23.7963223,133.5034561),
						new GLatLng(-23.7960649,133.4945512),
						new GLatLng(-23.8017297,133.4877062),
						new GLatLng(-23.8077378,133.4856248),
						new GLatLng(-23.819046,133.4776855),
						new GLatLng(-23.8223505,133.4735012),
						new GLatLng(-23.8212776,133.4672141),
						new GLatLng(-23.8166213,133.4565711),
						new GLatLng(-23.8187885,133.4494901),
						new GLatLng(-23.8121796,133.4322596),
						new GLatLng(-23.8141751,133.4244061),
						new GLatLng(-23.8103127,133.3880568),
						new GLatLng(-23.8151407,133.3806324),
						new GLatLng(-23.8105273,133.3646464),
						new GLatLng(-23.8151407,133.3178258),
						new GLatLng(-23.8133597,133.294158),
						new GLatLng(-23.8140893,133.2810044),
						new GLatLng(-23.8090897,133.2205796),
						new GLatLng(-23.8098836,133.2116747),
						new GLatLng(-23.8088965,133.1983495),
						new GLatLng(-23.8102269,133.1837153),
						new GLatLng(-23.8040257,133.1766558),
						new GLatLng(-23.8012362,133.1631804),
						new GLatLng(-23.7933397,133.0759978),
						new GLatLng(-23.7903142,133.0773497),
						new GLatLng(-23.7883186,133.0738521),
						new GLatLng(-23.7793493,133.0726075),
						new GLatLng(-23.7767744,133.0738735),
						new GLatLng(-23.7792635,133.0727577),
						new GLatLng(-23.7787056,133.0705261),
						new GLatLng(-23.7794137,133.0730796),
						new GLatLng(-23.7881041,133.0737448),
						new GLatLng(-23.7900352,133.0773926),
						new GLatLng(-23.7932754,133.0756974),
						new GLatLng(-23.7876749,133.0256367),
						new GLatLng(-23.7848425,133.0141354),
						new GLatLng(-23.7738347,132.9856825),
						new GLatLng(-23.7751007,132.97755),
						new GLatLng(-23.764286,132.9415226),
						new GLatLng(-23.753686,132.9171252),
						new GLatLng(-23.7479568,132.9003239),
						new GLatLng(-23.7475061,132.8953886),
						new GLatLng(-23.7347603,132.8606272),
						new GLatLng(-23.7338591,132.8541255),
						new GLatLng(-23.7214351,132.8165102),
						new GLatLng(-23.7189889,132.8143215),
						new GLatLng(-23.7145472,132.7951384),
						new GLatLng(-23.7072945,132.7788091),
						new GLatLng(-23.6971235,132.7476311),
						new GLatLng(-23.6937547,132.7426958),
						new GLatLng(-23.6872315,132.7238774),
						new GLatLng(-23.6787987,132.6859832),
						new GLatLng(-23.6816525,132.677958),
						new GLatLng(-23.6813951,132.6749539),
						new GLatLng(-23.6861157,132.6730657),
						new GLatLng(-23.6842489,132.6730227),
						new GLatLng(-23.6865878,132.6775074),
						new GLatLng(-23.6977029,132.6750398),
						new GLatLng(-23.7081099,132.6778722),
						new GLatLng(-23.7271428,132.6731944),
						new GLatLng(-23.7282801,132.6684952),
						new GLatLng(-23.7251043,132.665534),
						new GLatLng(-23.7189245,132.6681733),
						new GLatLng(-23.711586,132.6735806),
						new GLatLng(-23.6979389,132.6716065),
						new GLatLng(-23.6882401,132.6758981),
						new GLatLng(-23.6871243,132.6752114),
						new GLatLng(-23.6851072,132.6646972),
						new GLatLng(-23.6821461,132.663753),
						new GLatLng(-23.6844635,132.6743531),
						new GLatLng(-23.6841846,132.6733232),
						new GLatLng(-23.6811376,132.6747394),
						new GLatLng(-23.680172,132.6717353),
						new GLatLng(-23.6809874,132.674396),
						new GLatLng(-23.6747646,132.6725292),
						new GLatLng(-23.6740994,132.670877),
						new GLatLng(-23.6667395,132.6702762),
						new GLatLng(-23.6686492,132.6710486),
						new GLatLng(-23.6693788,132.6736236),
						new GLatLng(-23.6661601,132.676692),
						new GLatLng(-23.6683702,132.6768208),
						new GLatLng(-23.6692715,132.681284),
						new GLatLng(-23.6732626,132.6827002),
						new GLatLng(-23.6764598,132.6803613),
						new GLatLng(-23.6807513,132.6804686),
						new GLatLng(-23.6787558,132.6860046),
						new GLatLng(-23.684721,132.709415),
						new GLatLng(-23.6707306,132.7150154),
						new GLatLng(-23.6638212,132.7163672),
						new GLatLng(-23.6612892,132.7188134),
						new GLatLng(-23.6592507,132.7247787),
						new GLatLng(-23.6510968,132.7332759),
						new GLatLng(-23.6385226,132.7332973),
						new GLatLng(-23.6345744,132.7314949),
						new GLatLng(-23.6323214,132.7280831),
						new GLatLng(-23.6329222,132.7269244),
						new GLatLng(-23.6277938,132.7273107),
						new GLatLng(-23.6325359,132.7269888),
						new GLatLng(-23.6319566,132.7277613),
						new GLatLng(-23.6346817,132.7314949),
						new GLatLng(-23.6400676,132.7336621),
						new GLatLng(-23.6518478,132.7329326),
						new GLatLng(-23.659873,132.7240062),
						new GLatLng(-23.6612892,132.7190709),
						new GLatLng(-23.6649156,132.7158093),
						new GLatLng(-23.6724687,132.7145219),
						new GLatLng(-23.6847854,132.7092862),
						new GLatLng(-23.6787987,132.6842666),
						new GLatLng(-23.6815882,132.678237),
						new GLatLng(-23.6814594,132.6748252),
						new GLatLng(-23.6861587,132.6729584),
						new GLatLng(-23.6812019,132.6746321),
						new GLatLng(-23.6773396,132.6613927),
						new GLatLng(-23.6695933,132.6489043),
						new GLatLng(-23.660903,132.609551),
						new GLatLng(-23.6546373,132.6020622),
						new GLatLng(-23.6456251,132.5735235),
						new GLatLng(-23.6355829,132.5666785),
						new GLatLng(-23.6309481,132.5613141),
						new GLatLng(-23.6281157,132.5417662),
						new GLatLng(-23.6224937,132.533977),
						new GLatLng(-23.6221504,132.5247288),
						new GLatLng(-23.6174512,132.5148368),
						new GLatLng(-23.6129665,132.5115967),
						new GLatLng(-23.6081815,132.4992156),
						new GLatLng(-23.6095119,132.4805474),
						new GLatLng(-23.6033106,132.4556351),
						new GLatLng(-23.6103702,132.4569011),
						new GLatLng(-23.6123872,132.4560857),
						new GLatLng(-23.6139321,132.4528456),
						new GLatLng(-23.6199188,132.4472237),
						new GLatLng(-23.6203909,132.4437261),
						new GLatLng(-23.6271715,132.4362159),
						new GLatLng(-23.6309266,132.4257016),
						new GLatLng(-23.6338019,132.4257231),
						new GLatLng(-23.6364627,132.4189639),
						new GLatLng(-23.6391664,132.4194789),
						new GLatLng(-23.6406255,132.4157882),
						new GLatLng(-23.6508179,132.4151659),
						new GLatLng(-23.6515903,132.4134493),
						new GLatLng(-23.6561179,132.4132347),
						new GLatLng(-23.6561179,132.4132347),
						new GLatLng(-23.6510324,132.4137712),
						new GLatLng(-23.6468911,132.4017119),
						new GLatLng(-23.6480069,132.3981714),
						new GLatLng(-23.6542296,132.3982358),
						new GLatLng(-23.6593366,132.3929572),
						new GLatLng(-23.65762,132.3875928),
						new GLatLng(-23.6565471,132.3877001),
						new GLatLng(-23.6574054,132.3865843),
						new GLatLng(-23.6514401,132.3710918),
						new GLatLng(-23.6476421,132.3678303),
						new GLatLng(-23.6498737,132.3687315),
						new GLatLng(-23.6559463,132.3657274),
						new GLatLng(-23.6697006,132.3633027),
						new GLatLng(-23.6714816,132.3657918),
						new GLatLng(-23.6699152,132.3631525),
						new GLatLng(-23.6732197,132.3615432),
						new GLatLng(-23.6809874,132.3624873),
						new GLatLng(-23.6940336,132.3575735),
						new GLatLng(-23.6959863,132.3547411),
						new GLatLng(-23.7015867,132.3535609),
						new GLatLng(-23.7120152,132.3481107),
						new GLatLng(-23.7219286,132.3464155),
						new GLatLng(-23.7278295,132.3433042),
						new GLatLng(-23.7331724,132.3458791),
						new GLatLng(-23.7472486,132.3449779),
						new GLatLng(-23.759973,132.3500848),
						new GLatLng(-23.7778044,132.3508358),
						new GLatLng(-23.7934041,132.3612213),
						new GLatLng(-23.7928033,132.3520374),
						new GLatLng(-23.7983394,132.3427463),
						new GLatLng(-23.804605,132.3362231),
						new GLatLng(-23.8101411,132.3340344),
						new GLatLng(-23.8133597,132.3272324),
						new GLatLng(-23.8131881,132.3191857),
						new GLatLng(-23.8158059,132.3182631),
						new GLatLng(-23.8165569,132.3142934),
						new GLatLng(-23.8187027,132.3136067),
						new GLatLng(-23.8193464,132.3151517),
						new GLatLng(-23.8171148,132.3162246),
						new GLatLng(-23.81675,132.3142934),
						new GLatLng(-23.8159561,132.3180914),
						new GLatLng(-23.813231,132.3191428),
						new GLatLng(-23.8134456,132.3271251),
						new GLatLng(-23.8100338,132.3342919),
						new GLatLng(-23.8045192,132.3363304),
						new GLatLng(-23.7982535,132.3427677),
						new GLatLng(-23.7929535,132.3513508),
						new GLatLng(-23.7936401,132.3613286),
						new GLatLng(-23.7986827,132.3657703),
						new GLatLng(-23.8014507,132.3741174),
						new GLatLng(-23.8048196,132.3791599),
						new GLatLng(-23.8157201,132.3883009),
						new GLatLng(-23.8261271,132.4033427),
						new GLatLng(-23.8290882,132.4057674),
						new GLatLng(-23.8331223,132.4066901),
						new GLatLng(-23.8373494,132.405467),
						new GLatLng(-23.8500953,132.3951888),
						new GLatLng(-23.8768101,132.390554),
						new GLatLng(-23.8765526,132.4201655),
						new GLatLng(-23.8779044,132.4293923),
						new GLatLng(-23.8987827,132.5003958),
						new GLatLng(-23.8983965,132.5232697),
						new GLatLng(-23.8955426,132.5367022),
						new GLatLng(-23.8828826,132.563417),
						new GLatLng(-23.8806081,132.571485),
						new GLatLng(-23.8800716,132.5883722),
						new GLatLng(-23.8820028,132.6081991),
						new GLatLng(-23.8843846,132.6171899),
						new GLatLng(-23.8931823,132.6382399),
						new GLatLng(-23.9030743,132.6726365),
						new GLatLng(-23.9216352,132.7089643),
						new GLatLng(-23.9366126,132.7305937),
						new GLatLng(-23.9421058,132.743125),
						new GLatLng(-23.9403248,132.7444339),
						new GLatLng(-23.9423203,132.7432752),
						new GLatLng(-23.9532423,132.768445),
						new GLatLng(-23.9533067,132.7723718),
						new GLatLng(-23.9453244,132.7848387),
						new GLatLng(-23.9415479,132.7798176),
						new GLatLng(-23.9445949,132.7754617),
						new GLatLng(-23.9432645,132.7740455),
						new GLatLng(-23.9410758,132.7754617),
						new GLatLng(-23.9365697,132.7718353),
						new GLatLng(-23.9400673,132.7737021),
						new GLatLng(-23.9426208,132.7776289),
						new GLatLng(-23.9416337,132.7799678),
						new GLatLng(-23.9453888,132.7847528),
						new GLatLng(-23.949101,132.7806544),
						new GLatLng(-23.9533496,132.7724791),
						new GLatLng(-23.9612889,132.7731228),
						new GLatLng(-23.9642072,132.7682948),
						new GLatLng(-23.9709878,132.7620935),
						new GLatLng(-23.9766526,132.7604198),
						new GLatLng(-23.979528,132.763145),
						new GLatLng(-23.9827895,132.7765346),
						new GLatLng(-23.9971662,132.7756763),
						new GLatLng(-24.0066719,132.7687883),
						new GLatLng(-24.0089035,132.7695394),
						new GLatLng(-24.0130019,132.7677798),
						new GLatLng(-24.0398884,132.7646899),
						new GLatLng(-24.04742,132.7658272),
						new GLatLng(-24.0556169,132.763896),
						new GLatLng(-24.0612173,132.7485967),
						new GLatLng(-24.0562177,132.740593),
						new GLatLng(-24.0569043,132.7400136),
						new GLatLng(-24.0558958,132.7402282),
						new GLatLng(-24.0519476,132.7245641),
						new GLatLng(-24.0481925,132.7234697),
						new GLatLng(-24.0497375,132.7160454),
						new GLatLng(-24.0477848,132.7108955),
						new GLatLng(-24.049716,132.7161527),
						new GLatLng(-24.0481496,132.7234268),
						new GLatLng(-24.0519691,132.7246928),
						new GLatLng(-24.0552521,132.7390051),
						new GLatLng(-24.0612602,132.7486825),
						new GLatLng(-24.0601873,132.7527595),
						new GLatLng(-24.0588999,132.7533388),
						new GLatLng(-24.05581,132.7637243),
						new GLatLng(-24.0472913,132.7657843),
						new GLatLng(-24.0406609,132.7649045),
						new GLatLng(-24.0128732,132.7678227),
						new GLatLng(-24.0087962,132.7694964),
						new GLatLng(-24.0055776,132.7689171),
						new GLatLng(-23.9991188,132.7748394),
						new GLatLng(-23.9828324,132.7764487),
						new GLatLng(-23.9790559,132.7621579),
						new GLatLng(-23.9765882,132.7604198),
						new GLatLng(-23.9719534,132.7614284),
						new GLatLng(-23.963778,132.7688098),
						new GLatLng(-23.9625335,132.7724576),
						new GLatLng(-23.9590788,132.7735949),
						new GLatLng(-23.9533496,132.7723932),
						new GLatLng(-23.9486289,132.7813411),
						new GLatLng(-23.9368701,132.792778),
						new GLatLng(-23.9347029,132.7968335),
						new GLatLng(-23.9340162,132.8031635),
						new GLatLng(-23.9307761,132.811296),
						new GLatLng(-23.9420843,132.8418517),
						new GLatLng(-23.938179,132.8733301),
						new GLatLng(-23.9396381,132.8777719),
						new GLatLng(-23.9475131,132.8880501),
						new GLatLng(-23.9493799,132.8932643),
						new GLatLng(-23.9501524,132.9021049),
						new GLatLng(-23.9467192,132.9510713),
						new GLatLng(-23.9396167,132.9692245),
						new GLatLng(-23.9407969,132.9822922),
						new GLatLng(-23.9403462,132.9987073),
						new GLatLng(-23.9491439,133.0258727),
						new GLatLng(-23.9649153,133.0443907),
						new GLatLng(-23.9676404,133.0650115),
						new GLatLng(-23.9752364,133.0824995),
						new GLatLng(-23.9597011,133.1238484),
						new GLatLng(-23.9586067,133.1305647),
						new GLatLng(-23.9594436,133.1387615),
						new GLatLng(-23.9684987,133.1621504),
						new GLatLng(-23.9697218,133.1735659),
						new GLatLng(-23.9676619,133.190732),
						new GLatLng(-23.9714813,133.202126),
						new GLatLng(-23.9712238,133.2066107),
						new GLatLng(-23.9473844,133.2748246),
						new GLatLng(-23.932364,133.2925057),
						new GLatLng(-23.9237809,133.3127189),
						new GLatLng(-23.8890409,133.3525658),
						new GLatLng(-23.8764668,133.3793879),
						new GLatLng(-23.8658452,133.3914256),
						new GLatLng(-23.8542151,133.4216166),
						new GLatLng(-23.8486362,133.4501338),
						new GLatLng(-23.8400745,133.4630942),
						new GLatLng(-23.8285947,133.4670639),
						new GLatLng(-23.8179088,133.4783936),
						new GLatLng(-23.8087893,133.485024),
						new GLatLng(-23.8017941,133.4875774),
						new GLatLng(-23.7960434,133.4946156),
						new GLatLng(-23.7963223,133.5023403),
						new GLatLng(-23.7948847,133.5073185),
						new GLatLng(-23.7876749,133.5132623),
						new GLatLng(-23.7824392,133.5256648),
						new GLatLng(-23.7826109,133.5497189),
						new GLatLng(-23.7785554,133.5621643),
						new GLatLng(-23.7715816,133.6085558),
						new GLatLng(-23.7718821,133.6152077),
						new GLatLng(-23.7643075,133.6383605),
						new GLatLng(-23.7632561,133.6450768),
						new GLatLng(-23.7589431,133.6561275),
						new GLatLng(-23.7556601,133.6702251),
						new GLatLng(-23.7513256,133.6807394),
						new GLatLng(-23.7442875,133.7114024),
						new GLatLng(-23.7394166,133.7244701),
						new GLatLng(-23.7285376,133.7441897),
						new GLatLng(-23.7112427,133.7604976),
						new GLatLng(-23.7081528,133.7658405),
						new GLatLng(-23.7055779,133.7773418),
						new GLatLng(-23.6954498,133.8072968),
						new GLatLng(-23.6984539,133.8233471),
						new GLatLng(-23.6981535,133.8437748),
						new GLatLng(-23.7048912,133.8548255),
						new GLatLng(-23.7012434,133.8600826),
						new GLatLng(-23.7002778,133.8639021),
						new GLatLng(-23.7011361,133.8792229)
			], "#FFFF00",3,0.8);
			map.addOverlay(polyline);
		} else {
				document.getElementById('gmap_div').style.backgroundColor = '#DDDDDD';
				document.getElementById('gmap_div').innerHTML = 'Sorry, your Google Map cannot be displayed.';
		}
    }

    //]]>
    </script>
<br><br>
All images in this gallery:<br>
<table width='800'>
<tr>
</tr>
<tr><td><A ID='IMG_6264.JPG' href='redcentre.php?fileId=IMG_6264.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6264.JPG' ALT='Surprise!'><BR>Surprise!<br>94.67 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6264.JPG' ALT='Surprise!'>Surprise!</a></div></td>
<td><A ID='IMG_6265.JPG' href='redcentre.php?fileId=IMG_6265.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6265.JPG' ALT='IMG_6265.JPG'><BR>IMG_6265.JPG<br>109.06 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6265.JPG' ALT='IMG_6265.JPG'>IMG_6265.JPG</a></div></td>
<td><A ID='IMG_6271.JPG' href='redcentre.php?fileId=IMG_6271.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6271.JPG' ALT='Crested Pigeons'><BR>Crested Pigeons<br>96.68 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6271.JPG' ALT='Crested Pigeons'>Crested Pigeons</a></div></td>
<td><A ID='IMG_6275.JPG' href='redcentre.php?fileId=IMG_6275.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6275.JPG' ALT='Crested Pigeon'><BR>Crested Pigeon<br>59.14 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6275.JPG' ALT='Crested Pigeon'>Crested Pigeon</a></div></td>
<td><A ID='IMG_6276.JPG' href='redcentre.php?fileId=IMG_6276.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6276.JPG' ALT='Crested Pigeon'><BR>Crested Pigeon<br>57.03 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6276.JPG' ALT='Crested Pigeon'>Crested Pigeon</a></div></td>
</tr>
<tr><td><A ID='IMG_6278.JPG' href='redcentre.php?fileId=IMG_6278.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6278.JPG' ALT='Pied Butcherbird'><BR>Pied Butcherbird<br>89.11 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6278.JPG' ALT='Pied Butcherbird'>Pied Butcherbird</a></div></td>
<td><A ID='IMG_6282.JPG' href='redcentre.php?fileId=IMG_6282.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6282.JPG' ALT='Black-footed Rock Wallaby'><BR>Black-footed Rock Wallaby<br>85.52 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6282.JPG' ALT='Black-footed Rock Wallaby'>Black-footed Rock Wallaby</a></div></td>
<td><A ID='IMG_6285.JPG' href='redcentre.php?fileId=IMG_6285.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6285.JPG' ALT='IMG_6285.JPG'><BR>IMG_6285.JPG<br>104.26 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6285.JPG' ALT='IMG_6285.JPG'>IMG_6285.JPG</a></div></td>
<td><A ID='IMG_6288.JPG' href='redcentre.php?fileId=IMG_6288.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6288.JPG' ALT='IMG_6288.JPG'><BR>IMG_6288.JPG<br>89.73 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6288.JPG' ALT='IMG_6288.JPG'>IMG_6288.JPG</a></div></td>
<td><A ID='IMG_6292.JPG' href='redcentre.php?fileId=IMG_6292.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6292.JPG' ALT='Black-footed Rock Wallaby'><BR>Black-footed Rock Wallaby<br>84.15 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6292.JPG' ALT='Black-footed Rock Wallaby'>Black-footed Rock Wallaby</a></div></td>
</tr>
<tr><td><A ID='IMG_6295.JPG' href='redcentre.php?fileId=IMG_6295.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6295.JPG' ALT='IMG_6295.JPG'><BR>IMG_6295.JPG<br>74.06 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6295.JPG' ALT='IMG_6295.JPG'>IMG_6295.JPG</a></div></td>
<td><A ID='IMG_6296.JPG' href='redcentre.php?fileId=IMG_6296.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6296.JPG' ALT='Black-footed Rock Wallabies'><BR>Black-footed Rock Wallabies<br>58.36 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6296.JPG' ALT='Black-footed Rock Wallabies'>Black-footed Rock Wallabies</a></div></td>
<td><A ID='IMG_6299.JPG' href='redcentre.php?fileId=IMG_6299.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6299.JPG' ALT='Black-footed Rock Wallaby'><BR>Black-footed Rock Wallaby<br>56.3 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6299.JPG' ALT='Black-footed Rock Wallaby'>Black-footed Rock Wallaby</a></div></td>
<td><A ID='IMG_6301.JPG' href='redcentre.php?fileId=IMG_6301.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6301.JPG' ALT='Black-footed Rock Wallaby'><BR>Black-footed Rock Wallaby<br>72.72 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6301.JPG' ALT='Black-footed Rock Wallaby'>Black-footed Rock Wallaby</a></div></td>
<td><A ID='IMG_6304.JPG' href='redcentre.php?fileId=IMG_6304.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6304.JPG' ALT='Black-footed Rock Wallaby'><BR>Black-footed Rock Wallaby<br>55.45 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6304.JPG' ALT='Black-footed Rock Wallaby'>Black-footed Rock Wallaby</a></div></td>
</tr>
<tr><td><A ID='IMG_6306.JPG' href='redcentre.php?fileId=IMG_6306.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6306.JPG' ALT='IMG_6306.JPG'><BR>IMG_6306.JPG<br>65.27 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6306.JPG' ALT='IMG_6306.JPG'>IMG_6306.JPG</a></div></td>
<td><A ID='IMG_6310.JPG' href='redcentre.php?fileId=IMG_6310.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6310.JPG' ALT='View from the back door at Heavitree Gap'><BR>View from the back door at Heavitree Gap<br>80.21 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6310.JPG' ALT='View from the back door at Heavitree Gap'>View from the back door at Heavitree Gap</a></div></td>
<td><A ID='IMG_6311.JPG' href='redcentre.php?fileId=IMG_6311.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6311.JPG' ALT='IMG_6311.JPG'><BR>IMG_6311.JPG<br>80.55 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6311.JPG' ALT='IMG_6311.JPG'>IMG_6311.JPG</a></div></td>
<td><A ID='IMG_6313.JPG' href='redcentre.php?fileId=IMG_6313.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6313.JPG' ALT='IMG_6313.JPG'><BR>IMG_6313.JPG<br>62.47 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6313.JPG' ALT='IMG_6313.JPG'>IMG_6313.JPG</a></div></td>
<td><A ID='IMG_6319.JPG' href='redcentre.php?fileId=IMG_6319.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6319.JPG' ALT='Alice Springs'><BR>Alice Springs<br>85.03 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6319.JPG' ALT='Alice Springs'>Alice Springs</a></div></td>
</tr>
<tr><td><A ID='IMG_6320.JPG' href='redcentre.php?fileId=IMG_6320.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6320.JPG' ALT='Alice Springs'><BR>Alice Springs<br>96.03 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6320.JPG' ALT='Alice Springs'>Alice Springs</a></div></td>
<td><A ID='IMG_6328.JPG' href='redcentre.php?fileId=IMG_6328.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6328.JPG' ALT='IMG_6328.JPG'><BR>IMG_6328.JPG<br>66.71 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6328.JPG' ALT='IMG_6328.JPG'>IMG_6328.JPG</a></div></td>
<td><A ID='IMG_6329.JPG' href='redcentre.php?fileId=IMG_6329.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6329.JPG' ALT='IMG_6329.JPG'><BR>IMG_6329.JPG<br>65.55 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6329.JPG' ALT='IMG_6329.JPG'>IMG_6329.JPG</a></div></td>
<td><A ID='IMG_6330.JPG' href='redcentre.php?fileId=IMG_6330.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6330.JPG' ALT='IMG_6330.JPG'><BR>IMG_6330.JPG<br>115.55 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6330.JPG' ALT='IMG_6330.JPG'>IMG_6330.JPG</a></div></td>
<td><A ID='IMG_6332.JPG' href='redcentre.php?fileId=IMG_6332.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6332.JPG' ALT='IMG_6332.JPG'><BR>IMG_6332.JPG<br>75.4 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6332.JPG' ALT='IMG_6332.JPG'>IMG_6332.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_6334.JPG' href='redcentre.php?fileId=IMG_6334.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6334.JPG' ALT='IMG_6334.JPG'><BR>IMG_6334.JPG<br>84.1 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6334.JPG' ALT='IMG_6334.JPG'>IMG_6334.JPG</a></div></td>
<td><A ID='IMG_6338.JPG' href='redcentre.php?fileId=IMG_6338.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6338.JPG' ALT='IMG_6338.JPG'><BR>IMG_6338.JPG<br>102.43 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6338.JPG' ALT='IMG_6338.JPG'>IMG_6338.JPG</a></div></td>
<td><A ID='IMG_6344.JPG' href='redcentre.php?fileId=IMG_6344.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6344.JPG' ALT='White-plumed Honeyeater'><BR>White-plumed Honeyeater<br>100.73 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6344.JPG' ALT='White-plumed Honeyeater'>White-plumed Honeyeater</a></div></td>
<td><A ID='IMG_6345.JPG' href='redcentre.php?fileId=IMG_6345.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6345.JPG' ALT='IMG_6345.JPG'><BR>IMG_6345.JPG<br>132.98 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6345.JPG' ALT='IMG_6345.JPG'>IMG_6345.JPG</a></div></td>
<td><A ID='IMG_6347.JPG' href='redcentre.php?fileId=IMG_6347.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6347.JPG' ALT='IMG_6347.JPG'><BR>IMG_6347.JPG<br>106.89 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6347.JPG' ALT='IMG_6347.JPG'>IMG_6347.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_6349.JPG' href='redcentre.php?fileId=IMG_6349.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6349.JPG' ALT='IMG_6349.JPG'><BR>IMG_6349.JPG<br>32.12 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6349.JPG' ALT='IMG_6349.JPG'>IMG_6349.JPG</a></div></td>
<td><A ID='IMG_6352.JPG' href='redcentre.php?fileId=IMG_6352.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6352.JPG' ALT='IMG_6352.JPG'><BR>IMG_6352.JPG<br>96.07 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6352.JPG' ALT='IMG_6352.JPG'>IMG_6352.JPG</a></div></td>
<td><A ID='IMG_6353.JPG' href='redcentre.php?fileId=IMG_6353.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6353.JPG' ALT='IMG_6353.JPG'><BR>IMG_6353.JPG<br>98.92 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6353.JPG' ALT='IMG_6353.JPG'>IMG_6353.JPG</a></div></td>
<td><A ID='IMG_6354.JPG' href='redcentre.php?fileId=IMG_6354.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6354.JPG' ALT='IMG_6354.JPG'><BR>IMG_6354.JPG<br>97.73 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6354.JPG' ALT='IMG_6354.JPG'>IMG_6354.JPG</a></div></td>
<td><A ID='IMG_6362.JPG' href='redcentre.php?fileId=IMG_6362.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6362.JPG' ALT='Grey Shrike-Thrush'><BR>Grey Shrike-Thrush<br>91.54 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6362.JPG' ALT='Grey Shrike-Thrush'>Grey Shrike-Thrush</a></div></td>
</tr>
<tr><td><A ID='IMG_6364.JPG' href='redcentre.php?fileId=IMG_6364.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6364.JPG' ALT='IMG_6364.JPG'><BR>IMG_6364.JPG<br>105.46 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6364.JPG' ALT='IMG_6364.JPG'>IMG_6364.JPG</a></div></td>
<td><A ID='IMG_6369.JPG' href='redcentre.php?fileId=IMG_6369.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6369.JPG' ALT='IMG_6369.JPG'><BR>IMG_6369.JPG<br>64.1 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6369.JPG' ALT='IMG_6369.JPG'>IMG_6369.JPG</a></div></td>
<td><A ID='IMG_6371.JPG' href='redcentre.php?fileId=IMG_6371.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6371.JPG' ALT='IMG_6371.JPG'><BR>IMG_6371.JPG<br>112.82 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6371.JPG' ALT='IMG_6371.JPG'>IMG_6371.JPG</a></div></td>
<td><A ID='IMG_6372.JPG' href='redcentre.php?fileId=IMG_6372.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6372.JPG' ALT='Standley Chasm'><BR>Standley Chasm<br>115.66 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6372.JPG' ALT='Standley Chasm'>Standley Chasm</a></div></td>
<td><A ID='IMG_6374.JPG' href='redcentre.php?fileId=IMG_6374.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6374.JPG' ALT='Standley Chasm'><BR>Standley Chasm<br>116.86 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6374.JPG' ALT='Standley Chasm'>Standley Chasm</a></div></td>
</tr>
<tr><td><A ID='IMG_6375.JPG' href='redcentre.php?fileId=IMG_6375.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6375.JPG' ALT='Standley Chasm'><BR>Standley Chasm<br>99.79 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6375.JPG' ALT='Standley Chasm'>Standley Chasm</a></div></td>
<td><A ID='IMG_6376.JPG' href='redcentre.php?fileId=IMG_6376.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6376.JPG' ALT='Standley Chasm'><BR>Standley Chasm<br>81.76 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6376.JPG' ALT='Standley Chasm'>Standley Chasm</a></div></td>
<td><A ID='IMG_6383.JPG' href='redcentre.php?fileId=IMG_6383.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6383.JPG' ALT='Standley Chasm'><BR>Standley Chasm<br>72.68 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6383.JPG' ALT='Standley Chasm'>Standley Chasm</a></div></td>
<td><A ID='IMG_6384.JPG' href='redcentre.php?fileId=IMG_6384.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6384.JPG' ALT='Standley Chasm'><BR>Standley Chasm<br>95.77 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6384.JPG' ALT='Standley Chasm'>Standley Chasm</a></div></td>
<td><A ID='IMG_6393.JPG' href='redcentre.php?fileId=IMG_6393.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6393.JPG' ALT='IMG_6393.JPG'><BR>IMG_6393.JPG<br>89.57 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6393.JPG' ALT='IMG_6393.JPG'>IMG_6393.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_6394.JPG' href='redcentre.php?fileId=IMG_6394.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6394.JPG' ALT='IMG_6394.JPG'><BR>IMG_6394.JPG<br>104.04 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6394.JPG' ALT='IMG_6394.JPG'>IMG_6394.JPG</a></div></td>
<td><A ID='IMG_6398.JPG' href='redcentre.php?fileId=IMG_6398.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6398.JPG' ALT='IMG_6398.JPG'><BR>IMG_6398.JPG<br>81.05 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6398.JPG' ALT='IMG_6398.JPG'>IMG_6398.JPG</a></div></td>
<td><A ID='IMG_6401.JPG' href='redcentre.php?fileId=IMG_6401.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6401.JPG' ALT='Ellery Creek Big Hole'><BR>Ellery Creek Big Hole<br>87.27 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6401.JPG' ALT='Ellery Creek Big Hole'>Ellery Creek Big Hole</a></div></td>
<td><A ID='IMG_6405.JPG' href='redcentre.php?fileId=IMG_6405.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6405.JPG' ALT='IMG_6405.JPG'><BR>IMG_6405.JPG<br>74.64 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6405.JPG' ALT='IMG_6405.JPG'>IMG_6405.JPG</a></div></td>
<td><A ID='IMG_6407.JPG' href='redcentre.php?fileId=IMG_6407.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6407.JPG' ALT='Ellery Creek Big Hole'><BR>Ellery Creek Big Hole<br>81.72 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6407.JPG' ALT='Ellery Creek Big Hole'>Ellery Creek Big Hole</a></div></td>
</tr>
<tr><td><A ID='IMG_6410.JPG' href='redcentre.php?fileId=IMG_6410.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6410.JPG' ALT='Ellery Creek Big Hole'><BR>Ellery Creek Big Hole<br>69.7 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6410.JPG' ALT='Ellery Creek Big Hole'>Ellery Creek Big Hole</a></div></td>
<td><A ID='IMG_6411.JPG' href='redcentre.php?fileId=IMG_6411.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6411.JPG' ALT='Ellery Creek Big Hole'><BR>Ellery Creek Big Hole<br>84.72 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6411.JPG' ALT='Ellery Creek Big Hole'>Ellery Creek Big Hole</a></div></td>
<td><A ID='IMG_6412.JPG' href='redcentre.php?fileId=IMG_6412.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6412.JPG' ALT='Diamond Firetail Finches'><BR>Diamond Firetail Finches<br>84.42 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6412.JPG' ALT='Diamond Firetail Finches'>Diamond Firetail Finches</a></div></td>
<td><A ID='IMG_6420.JPG' href='redcentre.php?fileId=IMG_6420.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6420.JPG' ALT='Diamond Firetail Finches'><BR>Diamond Firetail Finches<br>112.82 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6420.JPG' ALT='Diamond Firetail Finches'>Diamond Firetail Finches</a></div></td>
<td><A ID='IMG_6421.JPG' href='redcentre.php?fileId=IMG_6421.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6421.JPG' ALT='Diamond Firetail Finches'><BR>Diamond Firetail Finches<br>113.2 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6421.JPG' ALT='Diamond Firetail Finches'>Diamond Firetail Finches</a></div></td>
</tr>
<tr><td><A ID='IMG_6433.JPG' href='redcentre.php?fileId=IMG_6433.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6433.JPG' ALT='IMG_6433.JPG'><BR>IMG_6433.JPG<br>79.14 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6433.JPG' ALT='IMG_6433.JPG'>IMG_6433.JPG</a></div></td>
<td><A ID='IMG_6438.JPG' href='redcentre.php?fileId=IMG_6438.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6438.JPG' ALT='IMG_6438.JPG'><BR>IMG_6438.JPG<br>85.79 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6438.JPG' ALT='IMG_6438.JPG'>IMG_6438.JPG</a></div></td>
<td><A ID='IMG_6440.JPG' href='redcentre.php?fileId=IMG_6440.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6440.JPG' ALT='IMG_6440.JPG'><BR>IMG_6440.JPG<br>76.33 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6440.JPG' ALT='IMG_6440.JPG'>IMG_6440.JPG</a></div></td>
<td><A ID='IMG_6442.JPG' href='redcentre.php?fileId=IMG_6442.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6442.JPG' ALT='IMG_6442.JPG'><BR>IMG_6442.JPG<br>77.21 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6442.JPG' ALT='IMG_6442.JPG'>IMG_6442.JPG</a></div></td>
<td><A ID='IMG_6443.JPG' href='redcentre.php?fileId=IMG_6443.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6443.JPG' ALT='IMG_6443.JPG'><BR>IMG_6443.JPG<br>114.45 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6443.JPG' ALT='IMG_6443.JPG'>IMG_6443.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_6445.JPG' href='redcentre.php?fileId=IMG_6445.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6445.JPG' ALT='IMG_6445.JPG'><BR>IMG_6445.JPG<br>102.59 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6445.JPG' ALT='IMG_6445.JPG'>IMG_6445.JPG</a></div></td>
<td><A ID='IMG_6446.JPG' href='redcentre.php?fileId=IMG_6446.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6446.JPG' ALT='IMG_6446.JPG'><BR>IMG_6446.JPG<br>98.4 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6446.JPG' ALT='IMG_6446.JPG'>IMG_6446.JPG</a></div></td>
<td><A ID='IMG_6451.JPG' href='redcentre.php?fileId=IMG_6451.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6451.JPG' ALT='Rainbow Bee-eater'><BR>Rainbow Bee-eater<br>71.48 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6451.JPG' ALT='Rainbow Bee-eater'>Rainbow Bee-eater</a></div></td>
<td><A ID='IMG_6463.JPG' href='redcentre.php?fileId=IMG_6463.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6463.JPG' ALT='Rainbow Bee-eater'><BR>Rainbow Bee-eater<br>67.21 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6463.JPG' ALT='Rainbow Bee-eater'>Rainbow Bee-eater</a></div></td>
<td><A ID='IMG_6470.JPG' href='redcentre.php?fileId=IMG_6470.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6470.JPG' ALT='Rainbow Bee-eater'><BR>Rainbow Bee-eater<br>78.93 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6470.JPG' ALT='Rainbow Bee-eater'>Rainbow Bee-eater</a></div></td>
</tr>
<tr><td><A ID='IMG_6474.JPG' href='redcentre.php?fileId=IMG_6474.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6474.JPG' ALT='Rainbow Bee-eater'><BR>Rainbow Bee-eater<br>68.67 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6474.JPG' ALT='Rainbow Bee-eater'>Rainbow Bee-eater</a></div></td>
<td><A ID='IMG_6476.JPG' href='redcentre.php?fileId=IMG_6476.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6476.JPG' ALT='IMG_6476.JPG'><BR>IMG_6476.JPG<br>95.46 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6476.JPG' ALT='IMG_6476.JPG'>IMG_6476.JPG</a></div></td>
<td><A ID='IMG_6479.JPG' href='redcentre.php?fileId=IMG_6479.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6479.JPG' ALT='IMG_6479.JPG'><BR>IMG_6479.JPG<br>79.67 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6479.JPG' ALT='IMG_6479.JPG'>IMG_6479.JPG</a></div></td>
<td><A ID='IMG_6480.JPG' href='redcentre.php?fileId=IMG_6480.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6480.JPG' ALT='IMG_6480.JPG'><BR>IMG_6480.JPG<br>108.88 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6480.JPG' ALT='IMG_6480.JPG'>IMG_6480.JPG</a></div></td>
<td><A ID='IMG_6485.JPG' href='redcentre.php?fileId=IMG_6485.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6485.JPG' ALT='IMG_6485.JPG'><BR>IMG_6485.JPG<br>68.21 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6485.JPG' ALT='IMG_6485.JPG'>IMG_6485.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_6486.JPG' href='redcentre.php?fileId=IMG_6486.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6486.JPG' ALT='IMG_6486.JPG'><BR>IMG_6486.JPG<br>85.76 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6486.JPG' ALT='IMG_6486.JPG'>IMG_6486.JPG</a></div></td>
<td><A ID='IMG_6488.JPG' href='redcentre.php?fileId=IMG_6488.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6488.JPG' ALT='Get to da choppa!'><BR>Get to da choppa!<br>118.22 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6488.JPG' ALT='Get to da choppa!'>Get to da choppa!</a></div></td>
<td><A ID='IMG_6489.JPG' href='redcentre.php?fileId=IMG_6489.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6489.JPG' ALT='IMG_6489.JPG'><BR>IMG_6489.JPG<br>89.99 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6489.JPG' ALT='IMG_6489.JPG'>IMG_6489.JPG</a></div></td>
<td><A ID='IMG_6494.JPG' href='redcentre.php?fileId=IMG_6494.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6494.JPG' ALT='IMG_6494.JPG'><BR>IMG_6494.JPG<br>78.97 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6494.JPG' ALT='IMG_6494.JPG'>IMG_6494.JPG</a></div></td>
<td><A ID='IMG_6499.JPG' href='redcentre.php?fileId=IMG_6499.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6499.JPG' ALT='IMG_6499.JPG'><BR>IMG_6499.JPG<br>51.83 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6499.JPG' ALT='IMG_6499.JPG'>IMG_6499.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_6501.JPG' href='redcentre.php?fileId=IMG_6501.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6501.JPG' ALT='IMG_6501.JPG'><BR>IMG_6501.JPG<br>87.18 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6501.JPG' ALT='IMG_6501.JPG'>IMG_6501.JPG</a></div></td>
<td><A ID='IMG_6512.JPG' href='redcentre.php?fileId=IMG_6512.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6512.JPG' ALT='IMG_6512.JPG'><BR>IMG_6512.JPG<br>88.98 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6512.JPG' ALT='IMG_6512.JPG'>IMG_6512.JPG</a></div></td>
<td><A ID='IMG_6514.JPG' href='redcentre.php?fileId=IMG_6514.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6514.JPG' ALT='IMG_6514.JPG'><BR>IMG_6514.JPG<br>85.41 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6514.JPG' ALT='IMG_6514.JPG'>IMG_6514.JPG</a></div></td>
<td><A ID='IMG_6523.JPG' href='redcentre.php?fileId=IMG_6523.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6523.JPG' ALT='IMG_6523.JPG'><BR>IMG_6523.JPG<br>69.09 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6523.JPG' ALT='IMG_6523.JPG'>IMG_6523.JPG</a></div></td>
<td><A ID='IMG_6532.JPG' href='redcentre.php?fileId=IMG_6532.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6532.JPG' ALT='IMG_6532.JPG'><BR>IMG_6532.JPG<br>79.73 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6532.JPG' ALT='IMG_6532.JPG'>IMG_6532.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_6535.JPG' href='redcentre.php?fileId=IMG_6535.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6535.JPG' ALT='Glen Helen Resort'><BR>Glen Helen Resort<br>110.39 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6535.JPG' ALT='Glen Helen Resort'>Glen Helen Resort</a></div></td>
<td><A ID='IMG_6536.JPG' href='redcentre.php?fileId=IMG_6536.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6536.JPG' ALT='Glen Helen Gorge'><BR>Glen Helen Gorge<br>102.84 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6536.JPG' ALT='Glen Helen Gorge'>Glen Helen Gorge</a></div></td>
<td><A ID='IMG_6541.JPG' href='redcentre.php?fileId=IMG_6541.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6541.JPG' ALT='Glen Helen Gorge'><BR>Glen Helen Gorge<br>113.82 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6541.JPG' ALT='Glen Helen Gorge'>Glen Helen Gorge</a></div></td>
<td><A ID='IMG_6542.JPG' href='redcentre.php?fileId=IMG_6542.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6542.JPG' ALT='MacDonnell Ranges'><BR>MacDonnell Ranges<br>83.38 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6542.JPG' ALT='MacDonnell Ranges'>MacDonnell Ranges</a></div></td>
<td><A ID='IMG_6545.JPG' href='redcentre.php?fileId=IMG_6545.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6545.JPG' ALT='IMG_6545.JPG'><BR>IMG_6545.JPG<br>51.57 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6545.JPG' ALT='IMG_6545.JPG'>IMG_6545.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_6548.JPG' href='redcentre.php?fileId=IMG_6548.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6548.JPG' ALT='Finke River'><BR>Finke River<br>96.44 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6548.JPG' ALT='Finke River'>Finke River</a></div></td>
<td><A ID='IMG_6551.JPG' href='redcentre.php?fileId=IMG_6551.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6551.JPG' ALT='MacDonnell Ranges'><BR>MacDonnell Ranges<br>71.95 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6551.JPG' ALT='MacDonnell Ranges'>MacDonnell Ranges</a></div></td>
<td><A ID='IMG_6552.JPG' href='redcentre.php?fileId=IMG_6552.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6552.JPG' ALT='MacDonnell Ranges'><BR>MacDonnell Ranges<br>64.66 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6552.JPG' ALT='MacDonnell Ranges'>MacDonnell Ranges</a></div></td>
<td><A ID='IMG_6554.JPG' href='redcentre.php?fileId=IMG_6554.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6554.JPG' ALT='Finke River'><BR>Finke River<br>100.07 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6554.JPG' ALT='Finke River'>Finke River</a></div></td>
<td><A ID='IMG_6557.JPG' href='redcentre.php?fileId=IMG_6557.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6557.JPG' ALT='MacDonnell Ranges'><BR>MacDonnell Ranges<br>75.41 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6557.JPG' ALT='MacDonnell Ranges'>MacDonnell Ranges</a></div></td>
</tr>
<tr><td><A ID='IMG_6559.JPG' href='redcentre.php?fileId=IMG_6559.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6559.JPG' ALT='Finke River'><BR>Finke River<br>72.29 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6559.JPG' ALT='Finke River'>Finke River</a></div></td>
<td><A ID='IMG_6560.JPG' href='redcentre.php?fileId=IMG_6560.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6560.JPG' ALT='IMG_6560.JPG'><BR>IMG_6560.JPG<br>67.76 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6560.JPG' ALT='IMG_6560.JPG'>IMG_6560.JPG</a></div></td>
<td><A ID='IMG_6563.JPG' href='redcentre.php?fileId=IMG_6563.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6563.JPG' ALT='IMG_6563.JPG'><BR>IMG_6563.JPG<br>83.25 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6563.JPG' ALT='IMG_6563.JPG'>IMG_6563.JPG</a></div></td>
<td><A ID='IMG_6564.JPG' href='redcentre.php?fileId=IMG_6564.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6564.JPG' ALT='IMG_6564.JPG'><BR>IMG_6564.JPG<br>90.79 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6564.JPG' ALT='IMG_6564.JPG'>IMG_6564.JPG</a></div></td>
<td><A ID='IMG_6567.JPG' href='redcentre.php?fileId=IMG_6567.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6567.JPG' ALT='Finke River'><BR>Finke River<br>91.62 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6567.JPG' ALT='Finke River'>Finke River</a></div></td>
</tr>
<tr><td><A ID='IMG_6569.JPG' href='redcentre.php?fileId=IMG_6569.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6569.JPG' ALT='Finke River'><BR>Finke River<br>87.23 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6569.JPG' ALT='Finke River'>Finke River</a></div></td>
<td><A ID='IMG_6570.JPG' href='redcentre.php?fileId=IMG_6570.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6570.JPG' ALT='Finke River'><BR>Finke River<br>100.25 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6570.JPG' ALT='Finke River'>Finke River</a></div></td>
<td><A ID='IMG_6571.JPG' href='redcentre.php?fileId=IMG_6571.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6571.JPG' ALT='IMG_6571.JPG'><BR>IMG_6571.JPG<br>108.66 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6571.JPG' ALT='IMG_6571.JPG'>IMG_6571.JPG</a></div></td>
<td><A ID='IMG_6575.JPG' href='redcentre.php?fileId=IMG_6575.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6575.JPG' ALT='MacDonnell Ranges'><BR>MacDonnell Ranges<br>83.05 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6575.JPG' ALT='MacDonnell Ranges'>MacDonnell Ranges</a></div></td>
<td><A ID='IMG_6578.JPG' href='redcentre.php?fileId=IMG_6578.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6578.JPG' ALT='MacDonnell Ranges'><BR>MacDonnell Ranges<br>79.76 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6578.JPG' ALT='MacDonnell Ranges'>MacDonnell Ranges</a></div></td>
</tr>
<tr><td><A ID='IMG_6580.JPG' href='redcentre.php?fileId=IMG_6580.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6580.JPG' ALT='Finke River'><BR>Finke River<br>77.83 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6580.JPG' ALT='Finke River'>Finke River</a></div></td>
<td><A ID='IMG_6581.JPG' href='redcentre.php?fileId=IMG_6581.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6581.JPG' ALT='MacDonnell Ranges'><BR>MacDonnell Ranges<br>106.37 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6581.JPG' ALT='MacDonnell Ranges'>MacDonnell Ranges</a></div></td>
<td><A ID='IMG_6586.JPG' href='redcentre.php?fileId=IMG_6586.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6586.JPG' ALT='MacDonnell Ranges'><BR>MacDonnell Ranges<br>82.57 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6586.JPG' ALT='MacDonnell Ranges'>MacDonnell Ranges</a></div></td>
<td><A ID='IMG_6588.JPG' href='redcentre.php?fileId=IMG_6588.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6588.JPG' ALT='Glen Helen Resort'><BR>Glen Helen Resort<br>99.1 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6588.JPG' ALT='Glen Helen Resort'>Glen Helen Resort</a></div></td>
<td><A ID='IMG_6589.JPG' href='redcentre.php?fileId=IMG_6589.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6589.JPG' ALT='Glen Helen Resort'><BR>Glen Helen Resort<br>103.25 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6589.JPG' ALT='Glen Helen Resort'>Glen Helen Resort</a></div></td>
</tr>
<tr><td><A ID='IMG_6591.JPG' href='redcentre.php?fileId=IMG_6591.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6591.JPG' ALT='IMG_6591.JPG'><BR>IMG_6591.JPG<br>109.33 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6591.JPG' ALT='IMG_6591.JPG'>IMG_6591.JPG</a></div></td>
<td><A ID='IMG_6592.JPG' href='redcentre.php?fileId=IMG_6592.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6592.JPG' ALT='IMG_6592.JPG'><BR>IMG_6592.JPG<br>73.13 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6592.JPG' ALT='IMG_6592.JPG'>IMG_6592.JPG</a></div></td>
<td><A ID='IMG_6593.JPG' href='redcentre.php?fileId=IMG_6593.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6593.JPG' ALT='IMG_6593.JPG'><BR>IMG_6593.JPG<br>65.67 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6593.JPG' ALT='IMG_6593.JPG'>IMG_6593.JPG</a></div></td>
<td><A ID='IMG_6595.JPG' href='redcentre.php?fileId=IMG_6595.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6595.JPG' ALT='Glen Helen'><BR>Glen Helen<br>99.72 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6595.JPG' ALT='Glen Helen'>Glen Helen</a></div></td>
<td><A ID='IMG_6599.JPG' href='redcentre.php?fileId=IMG_6599.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6599.JPG' ALT='Glen Helen'><BR>Glen Helen<br>124.11 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6599.JPG' ALT='Glen Helen'>Glen Helen</a></div></td>
</tr>
<tr><td><A ID='IMG_6600.JPG' href='redcentre.php?fileId=IMG_6600.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6600.JPG' ALT='IMG_6600.JPG'><BR>IMG_6600.JPG<br>61.33 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6600.JPG' ALT='IMG_6600.JPG'>IMG_6600.JPG</a></div></td>
<td><A ID='IMG_6603.JPG' href='redcentre.php?fileId=IMG_6603.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6603.JPG' ALT='IMG_6603.JPG'><BR>IMG_6603.JPG<br>59.99 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6603.JPG' ALT='IMG_6603.JPG'>IMG_6603.JPG</a></div></td>
<td><A ID='IMG_6604.JPG' href='redcentre.php?fileId=IMG_6604.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6604.JPG' ALT='Exploring the interesting geology'><BR>Exploring the interesting geology<br>115.09 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6604.JPG' ALT='Exploring the interesting geology'>Exploring the interesting geology</a></div></td>
<td><A ID='IMG_6605.JPG' href='redcentre.php?fileId=IMG_6605.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6605.JPG' ALT='Exploring the interesting geology'><BR>Exploring the interesting geology<br>115.56 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6605.JPG' ALT='Exploring the interesting geology'>Exploring the interesting geology</a></div></td>
<td><A ID='IMG_6607.JPG' href='redcentre.php?fileId=IMG_6607.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6607.JPG' ALT='IMG_6607.JPG'><BR>IMG_6607.JPG<br>79.28 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6607.JPG' ALT='IMG_6607.JPG'>IMG_6607.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_6608.JPG' href='redcentre.php?fileId=IMG_6608.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6608.JPG' ALT='IMG_6608.JPG'><BR>IMG_6608.JPG<br>81.12 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6608.JPG' ALT='IMG_6608.JPG'>IMG_6608.JPG</a></div></td>
<td><A ID='IMG_6611.JPG' href='redcentre.php?fileId=IMG_6611.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6611.JPG' ALT='IMG_6611.JPG'><BR>IMG_6611.JPG<br>117.21 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6611.JPG' ALT='IMG_6611.JPG'>IMG_6611.JPG</a></div></td>
<td><A ID='IMG_6612.JPG' href='redcentre.php?fileId=IMG_6612.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6612.JPG' ALT='IMG_6612.JPG'><BR>IMG_6612.JPG<br>87.4 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6612.JPG' ALT='IMG_6612.JPG'>IMG_6612.JPG</a></div></td>
<td><A ID='IMG_6613.JPG' href='redcentre.php?fileId=IMG_6613.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6613.JPG' ALT='Exploring the interesting geology'><BR>Exploring the interesting geology<br>109.65 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6613.JPG' ALT='Exploring the interesting geology'>Exploring the interesting geology</a></div></td>
<td><A ID='IMG_6615.JPG' href='redcentre.php?fileId=IMG_6615.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6615.JPG' ALT='Ormiston Gorge'><BR>Ormiston Gorge<br>85.94 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6615.JPG' ALT='Ormiston Gorge'>Ormiston Gorge</a></div></td>
</tr>
<tr><td><A ID='IMG_6620.JPG' href='redcentre.php?fileId=IMG_6620.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6620.JPG' ALT='Ormiston Gorge'><BR>Ormiston Gorge<br>90.14 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6620.JPG' ALT='Ormiston Gorge'>Ormiston Gorge</a></div></td>
<td><A ID='IMG_6621.JPG' href='redcentre.php?fileId=IMG_6621.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6621.JPG' ALT='Black-footed Rock Wallaby'><BR>Black-footed Rock Wallaby<br>87.04 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6621.JPG' ALT='Black-footed Rock Wallaby'>Black-footed Rock Wallaby</a></div></td>
<td><A ID='IMG_6625.JPG' href='redcentre.php?fileId=IMG_6625.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6625.JPG' ALT='White-necked Heron'><BR>White-necked Heron<br>83.51 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6625.JPG' ALT='White-necked Heron'>White-necked Heron</a></div></td>
<td><A ID='IMG_6627.JPG' href='redcentre.php?fileId=IMG_6627.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6627.JPG' ALT='White-necked Heron'><BR>White-necked Heron<br>81.39 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6627.JPG' ALT='White-necked Heron'>White-necked Heron</a></div></td>
<td><A ID='IMG_6628.JPG' href='redcentre.php?fileId=IMG_6628.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6628.JPG' ALT='White-necked Heron'><BR>White-necked Heron<br>78.01 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6628.JPG' ALT='White-necked Heron'>White-necked Heron</a></div></td>
</tr>
<tr><td><A ID='IMG_6635.JPG' href='redcentre.php?fileId=IMG_6635.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6635.JPG' ALT='Chestnut Teal ?'><BR>Chestnut Teal ?<br>80.59 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6635.JPG' ALT='Chestnut Teal ?'>Chestnut Teal ?</a></div></td>
<td><A ID='IMG_6637.JPG' href='redcentre.php?fileId=IMG_6637.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6637.JPG' ALT='Ormiston Gorge'><BR>Ormiston Gorge<br>93.27 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6637.JPG' ALT='Ormiston Gorge'>Ormiston Gorge</a></div></td>
<td><A ID='IMG_6638.JPG' href='redcentre.php?fileId=IMG_6638.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6638.JPG' ALT='Ormiston Gorge'><BR>Ormiston Gorge<br>82.72 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6638.JPG' ALT='Ormiston Gorge'>Ormiston Gorge</a></div></td>
<td><A ID='IMG_6643.JPG' href='redcentre.php?fileId=IMG_6643.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6643.JPG' ALT='Ormiston Gorge'><BR>Ormiston Gorge<br>79.75 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6643.JPG' ALT='Ormiston Gorge'>Ormiston Gorge</a></div></td>
<td><A ID='IMG_6645.JPG' href='redcentre.php?fileId=IMG_6645.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6645.JPG' ALT='Ormiston Gorge'><BR>Ormiston Gorge<br>80.72 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6645.JPG' ALT='Ormiston Gorge'>Ormiston Gorge</a></div></td>
</tr>
<tr><td><A ID='IMG_6648.JPG' href='redcentre.php?fileId=IMG_6648.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6648.JPG' ALT='IMG_6648.JPG'><BR>IMG_6648.JPG<br>56.1 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6648.JPG' ALT='IMG_6648.JPG'>IMG_6648.JPG</a></div></td>
<td><A ID='IMG_6649.JPG' href='redcentre.php?fileId=IMG_6649.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6649.JPG' ALT='IMG_6649.JPG'><BR>IMG_6649.JPG<br>28.02 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6649.JPG' ALT='IMG_6649.JPG'>IMG_6649.JPG</a></div></td>
<td><A ID='IMG_6653.JPG' href='redcentre.php?fileId=IMG_6653.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6653.JPG' ALT='Glen Helen'><BR>Glen Helen<br>97.37 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6653.JPG' ALT='Glen Helen'>Glen Helen</a></div></td>
<td><A ID='IMG_6657.JPG' href='redcentre.php?fileId=IMG_6657.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6657.JPG' ALT='Glen Helen'><BR>Glen Helen<br>97.51 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6657.JPG' ALT='Glen Helen'>Glen Helen</a></div></td>
<td><A ID='IMG_6659.JPG' href='redcentre.php?fileId=IMG_6659.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6659.JPG' ALT='Glen Helen'><BR>Glen Helen<br>63.17 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6659.JPG' ALT='Glen Helen'>Glen Helen</a></div></td>
</tr>
<tr><td><A ID='IMG_6664.JPG' href='redcentre.php?fileId=IMG_6664.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6664.JPG' ALT='Glen Helen'><BR>Glen Helen<br>125.15 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6664.JPG' ALT='Glen Helen'>Glen Helen</a></div></td>
<td><A ID='IMG_6665.JPG' href='redcentre.php?fileId=IMG_6665.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6665.JPG' ALT='Glen Helen'><BR>Glen Helen<br>119.74 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6665.JPG' ALT='Glen Helen'>Glen Helen</a></div></td>
<td><A ID='IMG_6666.JPG' href='redcentre.php?fileId=IMG_6666.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6666.JPG' ALT='Glen Helen'><BR>Glen Helen<br>89.66 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6666.JPG' ALT='Glen Helen'>Glen Helen</a></div></td>
<td><A ID='IMG_6667.JPG' href='redcentre.php?fileId=IMG_6667.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6667.JPG' ALT='Glen Helen'><BR>Glen Helen<br>101.01 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6667.JPG' ALT='Glen Helen'>Glen Helen</a></div></td>
<td><A ID='IMG_6668.JPG' href='redcentre.php?fileId=IMG_6668.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6668.JPG' ALT='Glen Helen'><BR>Glen Helen<br>113.24 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6668.JPG' ALT='Glen Helen'>Glen Helen</a></div></td>
</tr>
<tr><td><A ID='IMG_6669.JPG' href='redcentre.php?fileId=IMG_6669.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6669.JPG' ALT='Glen Helen'><BR>Glen Helen<br>92.85 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6669.JPG' ALT='Glen Helen'>Glen Helen</a></div></td>
<td><A ID='IMG_6670.JPG' href='redcentre.php?fileId=IMG_6670.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6670.JPG' ALT='Glen Helen'><BR>Glen Helen<br>69.83 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6670.JPG' ALT='Glen Helen'>Glen Helen</a></div></td>
<td><A ID='IMG_6671.JPG' href='redcentre.php?fileId=IMG_6671.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6671.JPG' ALT='Glen Helen'><BR>Glen Helen<br>89.23 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6671.JPG' ALT='Glen Helen'>Glen Helen</a></div></td>
<td><A ID='IMG_6672.JPG' href='redcentre.php?fileId=IMG_6672.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6672.JPG' ALT='Glen Helen'><BR>Glen Helen<br>97.73 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6672.JPG' ALT='Glen Helen'>Glen Helen</a></div></td>
<td><A ID='IMG_6673.JPG' href='redcentre.php?fileId=IMG_6673.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6673.JPG' ALT='Glen Helen'><BR>Glen Helen<br>90.76 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6673.JPG' ALT='Glen Helen'>Glen Helen</a></div></td>
</tr>
<tr><td><A ID='IMG_6674.JPG' href='redcentre.php?fileId=IMG_6674.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6674.JPG' ALT='Glen Helen'><BR>Glen Helen<br>75.26 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6674.JPG' ALT='Glen Helen'>Glen Helen</a></div></td>
<td><A ID='IMG_6675.JPG' href='redcentre.php?fileId=IMG_6675.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6675.JPG' ALT='Glen Helen'><BR>Glen Helen<br>102.99 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6675.JPG' ALT='Glen Helen'>Glen Helen</a></div></td>
<td><A ID='IMG_6676.JPG' href='redcentre.php?fileId=IMG_6676.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6676.JPG' ALT='Glen Helen'><BR>Glen Helen<br>126.47 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6676.JPG' ALT='Glen Helen'>Glen Helen</a></div></td>
<td><A ID='IMG_6677.JPG' href='redcentre.php?fileId=IMG_6677.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6677.JPG' ALT='Glen Helen'><BR>Glen Helen<br>112.9 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6677.JPG' ALT='Glen Helen'>Glen Helen</a></div></td>
<td><A ID='IMG_6678.JPG' href='redcentre.php?fileId=IMG_6678.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6678.JPG' ALT='IMG_6678.JPG'><BR>IMG_6678.JPG<br>67.75 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6678.JPG' ALT='IMG_6678.JPG'>IMG_6678.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_6680.JPG' href='redcentre.php?fileId=IMG_6680.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6680.JPG' ALT='IMG_6680.JPG'><BR>IMG_6680.JPG<br>57.66 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6680.JPG' ALT='IMG_6680.JPG'>IMG_6680.JPG</a></div></td>
<td><A ID='IMG_6682.JPG' href='redcentre.php?fileId=IMG_6682.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6682.JPG' ALT='Roma Gorge'><BR>Roma Gorge<br>82.72 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6682.JPG' ALT='Roma Gorge'>Roma Gorge</a></div></td>
<td><A ID='IMG_6683.JPG' href='redcentre.php?fileId=IMG_6683.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6683.JPG' ALT='Roma Gorge'><BR>Roma Gorge<br>104.3 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6683.JPG' ALT='Roma Gorge'>Roma Gorge</a></div></td>
<td><A ID='IMG_6684.JPG' href='redcentre.php?fileId=IMG_6684.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6684.JPG' ALT='Roma Gorge'><BR>Roma Gorge<br>95.59 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6684.JPG' ALT='Roma Gorge'>Roma Gorge</a></div></td>
<td><A ID='IMG_6685.JPG' href='redcentre.php?fileId=IMG_6685.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6685.JPG' ALT='Ancient sea bed ripples in Roma Gorge'><BR>Ancient sea bed ripples in Roma Gorge<br>105.03 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6685.JPG' ALT='Ancient sea bed ripples in Roma Gorge'>Ancient sea bed ripples in Roma Gorge</a></div></td>
</tr>
<tr><td><A ID='IMG_6686.JPG' href='redcentre.php?fileId=IMG_6686.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6686.JPG' ALT='Ancient carvings in Roma Gorge'><BR>Ancient carvings in Roma Gorge<br>100.38 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6686.JPG' ALT='Ancient carvings in Roma Gorge'>Ancient carvings in Roma Gorge</a></div></td>
<td><A ID='IMG_6687.JPG' href='redcentre.php?fileId=IMG_6687.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6687.JPG' ALT='Roma Gorge'><BR>Roma Gorge<br>91.98 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6687.JPG' ALT='Roma Gorge'>Roma Gorge</a></div></td>
<td><A ID='IMG_6691.JPG' href='redcentre.php?fileId=IMG_6691.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6691.JPG' ALT='Nests in Roma Gorge'><BR>Nests in Roma Gorge<br>95.45 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6691.JPG' ALT='Nests in Roma Gorge'>Nests in Roma Gorge</a></div></td>
<td><A ID='IMG_6696.JPG' href='redcentre.php?fileId=IMG_6696.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6696.JPG' ALT='Mulga Parrots'><BR>Mulga Parrots<br>61.17 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6696.JPG' ALT='Mulga Parrots'>Mulga Parrots</a></div></td>
<td><A ID='IMG_6698.JPG' href='redcentre.php?fileId=IMG_6698.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6698.JPG' ALT='Mulga Parrot'><BR>Mulga Parrot<br>129.03 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6698.JPG' ALT='Mulga Parrot'>Mulga Parrot</a></div></td>
</tr>
<tr><td><A ID='IMG_6700.JPG' href='redcentre.php?fileId=IMG_6700.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6700.JPG' ALT='Roma Gorge'><BR>Roma Gorge<br>107.03 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6700.JPG' ALT='Roma Gorge'>Roma Gorge</a></div></td>
<td><A ID='IMG_6704.JPG' href='redcentre.php?fileId=IMG_6704.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6704.JPG' ALT='Grey-headed Honeyeater'><BR>Grey-headed Honeyeater<br>116.28 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6704.JPG' ALT='Grey-headed Honeyeater'>Grey-headed Honeyeater</a></div></td>
<td><A ID='IMG_6705.JPG' href='redcentre.php?fileId=IMG_6705.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6705.JPG' ALT='IMG_6705.JPG'><BR>IMG_6705.JPG<br>91.82 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6705.JPG' ALT='IMG_6705.JPG'>IMG_6705.JPG</a></div></td>
<td><A ID='IMG_6707.JPG' href='redcentre.php?fileId=IMG_6707.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6707.JPG' ALT='IMG_6707.JPG'><BR>IMG_6707.JPG<br>87.93 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6707.JPG' ALT='IMG_6707.JPG'>IMG_6707.JPG</a></div></td>
<td><A ID='IMG_6709.JPG' href='redcentre.php?fileId=IMG_6709.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6709.JPG' ALT='IMG_6709.JPG'><BR>IMG_6709.JPG<br>76.53 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6709.JPG' ALT='IMG_6709.JPG'>IMG_6709.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_6710.JPG' href='redcentre.php?fileId=IMG_6710.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6710.JPG' ALT='IMG_6710.JPG'><BR>IMG_6710.JPG<br>87.33 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6710.JPG' ALT='IMG_6710.JPG'>IMG_6710.JPG</a></div></td>
<td><A ID='IMG_6721.JPG' href='redcentre.php?fileId=IMG_6721.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6721.JPG' ALT='Very Outback'><BR>Very Outback<br>80.84 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6721.JPG' ALT='Very Outback'>Very Outback</a></div></td>
<td><A ID='IMG_6722.JPG' href='redcentre.php?fileId=IMG_6722.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6722.JPG' ALT='View from Tyler's Pass lookout'><BR>View from Tyler's Pass lookout<br>76.93 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6722.JPG' ALT='View from Tyler's Pass lookout'>View from Tyler's Pass lookout</a></div></td>
<td><A ID='IMG_6723.JPG' href='redcentre.php?fileId=IMG_6723.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6723.JPG' ALT='View from Tyler's Pass lookout'><BR>View from Tyler's Pass lookout<br>87.03 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6723.JPG' ALT='View from Tyler's Pass lookout'>View from Tyler's Pass lookout</a></div></td>
<td><A ID='IMG_6724.JPG' href='redcentre.php?fileId=IMG_6724.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6724.JPG' ALT='Gosses Bluff from Tyler's Pass Lookout'><BR>Gosses Bluff from Tyler's Pass Lookout<br>72.51 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6724.JPG' ALT='Gosses Bluff from Tyler's Pass Lookout'>Gosses Bluff from Tyler's Pass Lookout</a></div></td>
</tr>
<tr><td><A ID='IMG_6727.JPG' href='redcentre.php?fileId=IMG_6727.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6727.JPG' ALT='IMG_6727.JPG'><BR>IMG_6727.JPG<br>65.08 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6727.JPG' ALT='IMG_6727.JPG'>IMG_6727.JPG</a></div></td>
<td><A ID='IMG_6739.JPG' href='redcentre.php?fileId=IMG_6739.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6739.JPG' ALT='Crested Bellbird'><BR>Crested Bellbird<br>67.06 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6739.JPG' ALT='Crested Bellbird'>Crested Bellbird</a></div></td>
<td><A ID='IMG_6741.JPG' href='redcentre.php?fileId=IMG_6741.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6741.JPG' ALT='Crested Bellbird'><BR>Crested Bellbird<br>62.58 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6741.JPG' ALT='Crested Bellbird'>Crested Bellbird</a></div></td>
<td><A ID='IMG_6742.JPG' href='redcentre.php?fileId=IMG_6742.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6742.JPG' ALT='Crested Bellbird'><BR>Crested Bellbird<br>62.53 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6742.JPG' ALT='Crested Bellbird'>Crested Bellbird</a></div></td>
<td><A ID='IMG_6744.JPG' href='redcentre.php?fileId=IMG_6744.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6744.JPG' ALT='Crested Bellbird'><BR>Crested Bellbird<br>53.58 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6744.JPG' ALT='Crested Bellbird'>Crested Bellbird</a></div></td>
</tr>
<tr><td><A ID='IMG_6745.JPG' href='redcentre.php?fileId=IMG_6745.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6745.JPG' ALT='Crested Bellbird'><BR>Crested Bellbird<br>43.55 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6745.JPG' ALT='Crested Bellbird'>Crested Bellbird</a></div></td>
<td><A ID='IMG_6753.JPG' href='redcentre.php?fileId=IMG_6753.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6753.JPG' ALT='Western Bowerbird'><BR>Western Bowerbird<br>96.71 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6753.JPG' ALT='Western Bowerbird'>Western Bowerbird</a></div></td>
<td><A ID='IMG_6759.JPG' href='redcentre.php?fileId=IMG_6759.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6759.JPG' ALT='Western Bowerbird'><BR>Western Bowerbird<br>53.65 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6759.JPG' ALT='Western Bowerbird'>Western Bowerbird</a></div></td>
<td><A ID='IMG_6766.JPG' href='redcentre.php?fileId=IMG_6766.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6766.JPG' ALT='Western Bowerbird'><BR>Western Bowerbird<br>75.91 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6766.JPG' ALT='Western Bowerbird'>Western Bowerbird</a></div></td>
<td><A ID='IMG_6769.JPG' href='redcentre.php?fileId=IMG_6769.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6769.JPG' ALT='Western Bowerbird'><BR>Western Bowerbird<br>65.78 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6769.JPG' ALT='Western Bowerbird'>Western Bowerbird</a></div></td>
</tr>
<tr><td><A ID='IMG_6779.JPG' href='redcentre.php?fileId=IMG_6779.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6779.JPG' ALT='Western Bowerbird'><BR>Western Bowerbird<br>65.09 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6779.JPG' ALT='Western Bowerbird'>Western Bowerbird</a></div></td>
<td><A ID='IMG_6781.JPG' href='redcentre.php?fileId=IMG_6781.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6781.JPG' ALT='Inside Gosses Bluff (Tnorala)'><BR>Inside Gosses Bluff (Tnorala)<br>116.37 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6781.JPG' ALT='Inside Gosses Bluff (Tnorala)'>Inside Gosses Bluff (Tnorala)</a></div></td>
<td><A ID='IMG_6783.JPG' href='redcentre.php?fileId=IMG_6783.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6783.JPG' ALT='Inside Gosses Bluff (Tnorala)'><BR>Inside Gosses Bluff (Tnorala)<br>88.95 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6783.JPG' ALT='Inside Gosses Bluff (Tnorala)'>Inside Gosses Bluff (Tnorala)</a></div></td>
<td><A ID='IMG_6784.JPG' href='redcentre.php?fileId=IMG_6784.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6784.JPG' ALT='Inside Gosses Bluff (Tnorala)'><BR>Inside Gosses Bluff (Tnorala)<br>108.31 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6784.JPG' ALT='Inside Gosses Bluff (Tnorala)'>Inside Gosses Bluff (Tnorala)</a></div></td>
<td><A ID='IMG_6785.JPG' href='redcentre.php?fileId=IMG_6785.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6785.JPG' ALT='Inside Gosses Bluff (Tnorala)'><BR>Inside Gosses Bluff (Tnorala)<br>90.79 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6785.JPG' ALT='Inside Gosses Bluff (Tnorala)'>Inside Gosses Bluff (Tnorala)</a></div></td>
</tr>
<tr><td><A ID='IMG_6786.JPG' href='redcentre.php?fileId=IMG_6786.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6786.JPG' ALT='Inside Gosses Bluff (Tnorala)'><BR>Inside Gosses Bluff (Tnorala)<br>91.85 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6786.JPG' ALT='Inside Gosses Bluff (Tnorala)'>Inside Gosses Bluff (Tnorala)</a></div></td>
<td><A ID='IMG_6790.JPG' href='redcentre.php?fileId=IMG_6790.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6790.JPG' ALT='Inside Gosses Bluff (Tnorala)'><BR>Inside Gosses Bluff (Tnorala)<br>83.54 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6790.JPG' ALT='Inside Gosses Bluff (Tnorala)'>Inside Gosses Bluff (Tnorala)</a></div></td>
<td><A ID='IMG_6792.JPG' href='redcentre.php?fileId=IMG_6792.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6792.JPG' ALT='Inside Gosses Bluff (Tnorala)'><BR>Inside Gosses Bluff (Tnorala)<br>100.86 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6792.JPG' ALT='Inside Gosses Bluff (Tnorala)'>Inside Gosses Bluff (Tnorala)</a></div></td>
<td><A ID='IMG_6793.JPG' href='redcentre.php?fileId=IMG_6793.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6793.JPG' ALT='Inside Gosses Bluff (Tnorala)'><BR>Inside Gosses Bluff (Tnorala)<br>104 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6793.JPG' ALT='Inside Gosses Bluff (Tnorala)'>Inside Gosses Bluff (Tnorala)</a></div></td>
<td><A ID='IMG_6802.JPG' href='redcentre.php?fileId=IMG_6802.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6802.JPG' ALT='Inside Gosses Bluff (Tnorala)'><BR>Inside Gosses Bluff (Tnorala)<br>103.72 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6802.JPG' ALT='Inside Gosses Bluff (Tnorala)'>Inside Gosses Bluff (Tnorala)</a></div></td>
</tr>
<tr><td><A ID='IMG_6803.JPG' href='redcentre.php?fileId=IMG_6803.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6803.JPG' ALT='Looking for shatter cones inside Gosses Bluff'><BR>Looking for shatter cones inside Gosses Bluff<br>88.15 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6803.JPG' ALT='Looking for shatter cones inside Gosses Bluff'>Looking for shatter cones inside Gosses Bluff</a></div></td>
<td><A ID='IMG_6804.JPG' href='redcentre.php?fileId=IMG_6804.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6804.JPG' ALT='Looking for shatter cones inside Gosses Bluff'><BR>Looking for shatter cones inside Gosses Bluff<br>90.1 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6804.JPG' ALT='Looking for shatter cones inside Gosses Bluff'>Looking for shatter cones inside Gosses Bluff</a></div></td>
<td><A ID='IMG_6806.JPG' href='redcentre.php?fileId=IMG_6806.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6806.JPG' ALT='Looking for shatter cones inside Gosses Bluff'><BR>Looking for shatter cones inside Gosses Bluff<br>106.99 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6806.JPG' ALT='Looking for shatter cones inside Gosses Bluff'>Looking for shatter cones inside Gosses Bluff</a></div></td>
<td><A ID='IMG_6808.JPG' href='redcentre.php?fileId=IMG_6808.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6808.JPG' ALT='Looking for shatter cones inside Gosses Bluff'><BR>Looking for shatter cones inside Gosses Bluff<br>111.71 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6808.JPG' ALT='Looking for shatter cones inside Gosses Bluff'>Looking for shatter cones inside Gosses Bluff</a></div></td>
<td><A ID='IMG_6809.JPG' href='redcentre.php?fileId=IMG_6809.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6809.JPG' ALT='Looking for shatter cones inside Gosses Bluff'><BR>Looking for shatter cones inside Gosses Bluff<br>51.37 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6809.JPG' ALT='Looking for shatter cones inside Gosses Bluff'>Looking for shatter cones inside Gosses Bluff</a></div></td>
</tr>
<tr><td><A ID='IMG_6811.JPG' href='redcentre.php?fileId=IMG_6811.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6811.JPG' ALT='Looking for shatter cones inside Gosses Bluff'><BR>Looking for shatter cones inside Gosses Bluff<br>103.18 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6811.JPG' ALT='Looking for shatter cones inside Gosses Bluff'>Looking for shatter cones inside Gosses Bluff</a></div></td>
<td><A ID='IMG_6812.JPG' href='redcentre.php?fileId=IMG_6812.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6812.JPG' ALT='Termite nest in the Spinifex'><BR>Termite nest in the Spinifex<br>136.22 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6812.JPG' ALT='Termite nest in the Spinifex'>Termite nest in the Spinifex</a></div></td>
<td><A ID='IMG_6814.JPG' href='redcentre.php?fileId=IMG_6814.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6814.JPG' ALT='Hermannsberg Solar Power station'><BR>Hermannsberg Solar Power station<br>70.56 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6814.JPG' ALT='Hermannsberg Solar Power station'>Hermannsberg Solar Power station</a></div></td>
<td><A ID='IMG_6818.JPG' href='redcentre.php?fileId=IMG_6818.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6818.JPG' ALT='Hermannsberg Solar Power station'><BR>Hermannsberg Solar Power station<br>58.41 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6818.JPG' ALT='Hermannsberg Solar Power station'>Hermannsberg Solar Power station</a></div></td>
<td><A ID='IMG_6820.JPG' href='redcentre.php?fileId=IMG_6820.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6820.JPG' ALT='Hermannsberg Solar Power station'><BR>Hermannsberg Solar Power station<br>76.49 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6820.JPG' ALT='Hermannsberg Solar Power station'>Hermannsberg Solar Power station</a></div></td>
</tr>
<tr><td><A ID='IMG_6821.JPG' href='redcentre.php?fileId=IMG_6821.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6821.JPG' ALT='Hermannsberg Solar Power station'><BR>Hermannsberg Solar Power station<br>87.13 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6821.JPG' ALT='Hermannsberg Solar Power station'>Hermannsberg Solar Power station</a></div></td>
<td><A ID='IMG_6823.JPG' href='redcentre.php?fileId=IMG_6823.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6823.JPG' ALT='On the way into Palm Valley'><BR>On the way into Palm Valley<br>82.55 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6823.JPG' ALT='On the way into Palm Valley'>On the way into Palm Valley</a></div></td>
<td><A ID='IMG_6824.JPG' href='redcentre.php?fileId=IMG_6824.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6824.JPG' ALT='On the way into Palm Valley'><BR>On the way into Palm Valley<br>104.88 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6824.JPG' ALT='On the way into Palm Valley'>On the way into Palm Valley</a></div></td>
<td><A ID='IMG_6825.JPG' href='redcentre.php?fileId=IMG_6825.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6825.JPG' ALT='On the way into Palm Valley'><BR>On the way into Palm Valley<br>120.99 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6825.JPG' ALT='On the way into Palm Valley'>On the way into Palm Valley</a></div></td>
<td><A ID='IMG_6826.JPG' href='redcentre.php?fileId=IMG_6826.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6826.JPG' ALT='On the way into Palm Valley'><BR>On the way into Palm Valley<br>100.27 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6826.JPG' ALT='On the way into Palm Valley'>On the way into Palm Valley</a></div></td>
</tr>
<tr><td><A ID='IMG_6827.JPG' href='redcentre.php?fileId=IMG_6827.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6827.JPG' ALT='On the way into Palm Valley'><BR>On the way into Palm Valley<br>90.83 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6827.JPG' ALT='On the way into Palm Valley'>On the way into Palm Valley</a></div></td>
<td><A ID='IMG_6828.JPG' href='redcentre.php?fileId=IMG_6828.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6828.JPG' ALT='On the way into Palm Valley'><BR>On the way into Palm Valley<br>98.78 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6828.JPG' ALT='On the way into Palm Valley'>On the way into Palm Valley</a></div></td>
<td><A ID='IMG_6832.JPG' href='redcentre.php?fileId=IMG_6832.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6832.JPG' ALT='On the way into Palm Valley'><BR>On the way into Palm Valley<br>87.44 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6832.JPG' ALT='On the way into Palm Valley'>On the way into Palm Valley</a></div></td>
<td><A ID='IMG_6833.JPG' href='redcentre.php?fileId=IMG_6833.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6833.JPG' ALT='Pied Butcherbird'><BR>Pied Butcherbird<br>73.4 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6833.JPG' ALT='Pied Butcherbird'>Pied Butcherbird</a></div></td>
<td><A ID='IMG_6835.JPG' href='redcentre.php?fileId=IMG_6835.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6835.JPG' ALT='Palm Valley'><BR>Palm Valley<br>95.72 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6835.JPG' ALT='Palm Valley'>Palm Valley</a></div></td>
</tr>
<tr><td><A ID='IMG_6837.JPG' href='redcentre.php?fileId=IMG_6837.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6837.JPG' ALT='Palm Valley'><BR>Palm Valley<br>103.73 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6837.JPG' ALT='Palm Valley'>Palm Valley</a></div></td>
<td><A ID='IMG_6842.JPG' href='redcentre.php?fileId=IMG_6842.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6842.JPG' ALT='Palm Valley'><BR>Palm Valley<br>114.24 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6842.JPG' ALT='Palm Valley'>Palm Valley</a></div></td>
<td><A ID='IMG_6845.JPG' href='redcentre.php?fileId=IMG_6845.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6845.JPG' ALT='Palm Valley'><BR>Palm Valley<br>101.22 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6845.JPG' ALT='Palm Valley'>Palm Valley</a></div></td>
<td><A ID='IMG_6848.JPG' href='redcentre.php?fileId=IMG_6848.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6848.JPG' ALT='Palm Valley'><BR>Palm Valley<br>99.28 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6848.JPG' ALT='Palm Valley'>Palm Valley</a></div></td>
<td><A ID='IMG_6849.JPG' href='redcentre.php?fileId=IMG_6849.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6849.JPG' ALT='Palm Valley'><BR>Palm Valley<br>112.28 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6849.JPG' ALT='Palm Valley'>Palm Valley</a></div></td>
</tr>
<tr><td><A ID='IMG_6851.JPG' href='redcentre.php?fileId=IMG_6851.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6851.JPG' ALT='Spinifex in Palm Valley'><BR>Spinifex in Palm Valley<br>120.94 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6851.JPG' ALT='Spinifex in Palm Valley'>Spinifex in Palm Valley</a></div></td>
<td><A ID='IMG_6853.JPG' href='redcentre.php?fileId=IMG_6853.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6853.JPG' ALT='Palm Valley'><BR>Palm Valley<br>99.96 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6853.JPG' ALT='Palm Valley'>Palm Valley</a></div></td>
<td><A ID='IMG_6857.JPG' href='redcentre.php?fileId=IMG_6857.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6857.JPG' ALT='Palm Valley'><BR>Palm Valley<br>101.98 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6857.JPG' ALT='Palm Valley'>Palm Valley</a></div></td>
<td><A ID='IMG_6859.JPG' href='redcentre.php?fileId=IMG_6859.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6859.JPG' ALT='Palm Valley'><BR>Palm Valley<br>83.57 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6859.JPG' ALT='Palm Valley'>Palm Valley</a></div></td>
<td><A ID='IMG_6865.JPG' href='redcentre.php?fileId=IMG_6865.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6865.JPG' ALT='Zebra Finches'><BR>Zebra Finches<br>90.07 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6865.JPG' ALT='Zebra Finches'>Zebra Finches</a></div></td>
</tr>
<tr><td><A ID='IMG_6867.JPG' href='redcentre.php?fileId=IMG_6867.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6867.JPG' ALT='Zebra Finches'><BR>Zebra Finches<br>101.64 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6867.JPG' ALT='Zebra Finches'>Zebra Finches</a></div></td>
<td><A ID='IMG_6869.JPG' href='redcentre.php?fileId=IMG_6869.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6869.JPG' ALT='Kinky Palms in Palm Valley'><BR>Kinky Palms in Palm Valley<br>78.18 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6869.JPG' ALT='Kinky Palms in Palm Valley'>Kinky Palms in Palm Valley</a></div></td>
<td><A ID='IMG_6874.JPG' href='redcentre.php?fileId=IMG_6874.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6874.JPG' ALT='IMG_6874.JPG'><BR>IMG_6874.JPG<br>84.39 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6874.JPG' ALT='IMG_6874.JPG'>IMG_6874.JPG</a></div></td>
<td><A ID='IMG_6877.JPG' href='redcentre.php?fileId=IMG_6877.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6877.JPG' ALT='IMG_6877.JPG'><BR>IMG_6877.JPG<br>112.42 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6877.JPG' ALT='IMG_6877.JPG'>IMG_6877.JPG</a></div></td>
<td><A ID='IMG_6881.JPG' href='redcentre.php?fileId=IMG_6881.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6881.JPG' ALT='IMG_6881.JPG'><BR>IMG_6881.JPG<br>88.29 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6881.JPG' ALT='IMG_6881.JPG'>IMG_6881.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_6883.JPG' href='redcentre.php?fileId=IMG_6883.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6883.JPG' ALT='Palm Valley'><BR>Palm Valley<br>94.95 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6883.JPG' ALT='Palm Valley'>Palm Valley</a></div></td>
<td><A ID='IMG_6884.JPG' href='redcentre.php?fileId=IMG_6884.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6884.JPG' ALT='IMG_6884.JPG'><BR>IMG_6884.JPG<br>46.67 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6884.JPG' ALT='IMG_6884.JPG'>IMG_6884.JPG</a></div></td>
<td><A ID='IMG_6886.JPG' href='redcentre.php?fileId=IMG_6886.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6886.JPG' ALT='Tired but happy'><BR>Tired but happy<br>67.87 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6886.JPG' ALT='Tired but happy'>Tired but happy</a></div></td>
<td><A ID='IMG_6892.JPG' href='redcentre.php?fileId=IMG_6892.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6892.JPG' ALT='IMG_6892.JPG'><BR>IMG_6892.JPG<br>59.65 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6892.JPG' ALT='IMG_6892.JPG'>IMG_6892.JPG</a></div></td>
<td><A ID='IMG_6893.JPG' href='redcentre.php?fileId=IMG_6893.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/IMG_6893.JPG' ALT='Wild Horses'><BR>Wild Horses<br>67.08 KB</a><div class='inv'><br><a href='./images/20080821/IMG_6893.JPG' ALT='Wild Horses'>Wild Horses</a></div></td>
</tr>
<tr><td><A ID='glenhelen_panorama.JPG' href='redcentre.php?fileId=glenhelen_panorama.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/glenhelen_panorama.JPG' ALT='glenhelen_panorama.JPG'><BR>glenhelen_panorama.JPG<br>261.14 KB</a><div class='inv'><br><a href='./images/20080821/glenhelen_panorama.JPG' ALT='glenhelen_panorama.JPG'>glenhelen_panorama.JPG</a></div></td>
<td><A ID='gossesbluff_inside_panorama.JPG' href='redcentre.php?fileId=gossesbluff_inside_panorama.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/gossesbluff_inside_panorama.JPG' ALT='gossesbluff_inside_panorama.JPG'><BR>gossesbluff_inside_panorama.JPG<br>183.9 KB</a><div class='inv'><br><a href='./images/20080821/gossesbluff_inside_panorama.JPG' ALT='gossesbluff_inside_panorama.JPG'>gossesbluff_inside_panorama.JPG</a></div></td>
<td><A ID='gossesbluff_outside_panorama.JPG' href='redcentre.php?fileId=gossesbluff_outside_panorama.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20080821/gossesbluff_outside_panorama.JPG' ALT='gossesbluff_outside_panorama.JPG'><BR>gossesbluff_outside_panorama.JPG<br>209.1 KB</a><div class='inv'><br><a href='./images/20080821/gossesbluff_outside_panorama.JPG' ALT='gossesbluff_outside_panorama.JPG'>gossesbluff_outside_panorama.JPG</a></div></td>
</tr>
</table>	</div>
</div>
</body>
</html>