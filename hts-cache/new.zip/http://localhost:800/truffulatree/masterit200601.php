<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - January 2006 - Q&A letters</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="Q&A letters">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><div class='activemenu'>January 2006</div></li>
<li><a title="Q&A letters" href='masterit200602.php'>February 2006</a></li>
<li><a title="Q&A letters" href='masterit200603.php'>March 2006</a></li>
<li><a title="Q&A letters" href='masterit200604.php'>April 2006</a></li>
<li><a title="Q&A letters" href='masterit200605.php'>May 2006</a></li>
<li><a title="Q&A letters" href='masterit200606.php'>June 2006</a></li>
<li><a title="Q&A letters" href='masterit200607.php'>July 2006</a></li>
<li><a title="Q&A letters" href='masterit200608.php'>August 2006</a></li>
<li><a title="Q&A letters" href='masterit200609.php'>September 2006</a></li>
<li><a title="Q&A letters" href='masterit200610.php'>October 2006</a></li>
<li><a title="Q&A letters" href='masterit200611.php'>November 2006</a></li>
<li><a title="Q&A letters" href='masterit200612.php'>December 2006</a></li>
<li> </li><br><li>Or go back to:</li><li><a title='Q&A/MasterIT letters from 2006' href="masterit2006.php">2006 archive</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>January 2006</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Mark's writing' href="written.php">Professional Writing</a> > <a title='My weekly Q&A column in The Australian' href="masterIT.php">MasterIT</a> > <a title='Q&A/MasterIT letters from 2006' href="masterit2006.php">2006 archive</a> > <a title='Q&A letters' href="masterit200601.php">January 2006</a>
<br><br>		<br>
<h2>31/1/06</h2><br>
<br>
<b>For a couple of years now, I've had Norton's Anti-virus. I am now tired of Ccapp errors and Lucom Server errors (which, as best I can figure it through Googling, have to do with Norton's). I am due to renew with Norton's and do not wish to, but I'm confused about the best product to get. Is the free AVG no good? If not, what in your view is the best product?</b><br>
<br>
I've not extensively tried AVG, but from what I've seen it works pretty well. This, incidentally, is not because it's lousy, but because I've always been pretty happy with McAfee (I've been using version 7 for a few years now, and have never had a virus infection. I believe they're up to version 9 now).<br>
<br>
As far as Norton products go, I too have had a few bad experiences, and over the years various readers have reported a myriad of issues. As a result, I tend to avoid Norton software entirely, and other Symantec products, as they can cause all sorts of odd PC behaviour, and can sometimes be a pain to uninstall.<br>
<br>
Of course, I'm not saying that their stuff doesn't work. Many people use Symantec products without issues; it's just that my own mileage (and my mileage as an IT troubleshooter) varied considerably.<br>
<br>
Alienating myself from the Symantec Christmas Card List aside, the most important thing about a virus scanner is that it be kept up to date. New worms and security exploits appear constantly, and staying ahead of the game is essential.<br>
<br>
All good scanners can be configured to update transparently (and do complete scans) at user-specified intervals. I recommend every couple of days for the former and every month for the latter.<br>
<br>
Ideally, you should make sure the scanner is set up to intercept viruses before they even get a chance to make it to your hard disk. This means an automatic scan whenever you read or write to the disk (or both) - the latter is the most effective.<br>
<br>
Both AVG and McAfee offer free virus definition updates, which I also consider a must-have - why continue to pay for a product once you've bought it? Major software updates are one thing, but bug fixes and virus definition files are a different kettle of fish.<br>
<br>
<i><p>Did the information on this page help you? Entertain you? Bore you? <a href="contact.php?subject=MasterIT">Drop me a line</a>.</p>

<p>If you're feeling particularly generous, you can even <a href="buypics.php">click here to send me some dot-com riches</a>. Think of it as online busking.</i></p>
	</div>
</div>
</body>
</html>