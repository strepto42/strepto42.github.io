<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - IPChangeDetect - IPChangedetect - an update tool for ddns.nu</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="IPChangedetect - an update tool for ddns.nu">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><div class='activemenu'>IPChangeDetect</div></li>
<li> </li><br><li>Or go back to:</li><li><a title='Programming work I've done' href="programming.php">Programming</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>IPChangeDetect</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Programming work I've done' href="programming.php">Programming</a> > <a title='IPChangedetect - an update tool for ddns.nu' href="ipchangedetect.php">IPChangeDetect</a>
<br><br>		<br>
<br>
IPChangeDetect is a program that will periodically scan your machine's internet IP address, and automatically update your DDNS entry if it changes, using the DDNS system at <a href="http://www.ddns.nu">http://www.ddns.nu</a>. It's pretty simple really. Read the docs to get more info.<br>
<br>
Version History:<br>
<br>
<table border="0" valign="top"><tr><td valign="top">1.1.21</td><td class="optimus"> </td></tr><tr><td align="right" valign="top">-</td><td class="optimus">Added 127.0.0.1 to the 'private' ip list so it will be flagged as static by default.</td></tr><tr><td class="optimus"> </td><td class="optimus"> </td></tr><tr><td valign="top">1.1.20</td><td class="optimus"> </td></tr><tr><td align="right" valign="top">-</td><td class="optimus">New IPs will be automatically flagged as 'static' if they are in the private ranges 10.0.0.x, 192.168.x.x and 169.254.x.x.</td></tr><tr><td class="optimus"> </td><td class="optimus"> </td></tr><tr><td valign="top">1.1.19</td><td class="optimus"> </td></tr><tr><td align="right" valign="top">-</td><td class="optimus">Fixed bug where if update was called twice in one go (eg if two IPs were not flagged as static) it would crash with an error. Now it'll pop up a box and warn you, so you can go in and make sure only one IP is not ticked as static</td></tr><tr><td align="right" valign="top">-</td><td class="optimus">Redid the display code for the DDNS updater, it's a bit cleaner now and doesn't show the password.</td></tr><tr></tr><td align="right" valign="top">-</td><td class="optimus">tested the timeout code - it does work properly (of course ;))</td></tr><tr><td class="optimus"> </td><td class="optimus"> </td></tr><tr><td valign="top">1.1.17</td><td class="optimus"> </td></tr><tr><td align="right" valign="top">-</td><td class="optimus">Fixed a bug whereby only one update would work per time run</td></tr><tr><td align="right" valign="top">-</td><td class="optimus">Added a manual 'update now' button</td></tr><tr><td align="right" valign="top">-</td><td class="optimus">Tried to add code to handle server timeouts, kinda hard to test but I think it'll work</td></tr><tr><td class="optimus"> </td><td class="optimus"> </td></tr><tr><td valign="top">1.1.15</td><td class="optimus"> </td></tr><tr><td align="right" valign="top">-</td><td class="optimus">Incorporated <a href="http://transf0r.hypermart.net/other.htm">James Salter's AutoDDNS code</a></td></tr><tr><td class="optimus"> </td><td class="optimus"> </td></tr><tr><td valign="top">1.1.10</td><td class="optimus"> </td></tr><tr><td align="right" valign="top">-</td><td class="optimus">First Release, boring and buggy</td></tr></table><br>
<br>
Click below to download the latest version (EXE only - 56k, or full installer - 1455k) (28/10/01, V1.1.21)<br>
<br><br>
Files available for download:<br>
<ul class="dirlist"><li><a href="./files/ipchangedetect/IPChangeDetect.exe">IPChangeDetect.exe</a></li><li><a href="./files/ipchangedetect/IPChangeDetect.zip">IPChangeDetect.zip</a></li></ul><!-- old method
getTheFiles($file);

function getTheFiles($folder) {
	if ($handle = opendir($folder)) {
		while (false !== ($file = readdir($handle))) {
			If ($file!= "." && $file!= ".." and !is_dir($folder."/".$file)) {
				$filesize = round(filesize ($folder."/".$file)/1024,2);
				echo "<tr><td><div align='left'><A href='$corelise$folder/$file'>$file</a></div></td><td><div align='left'>$filesize KB</div></td><tr>\n";
			} else {
			If ($file!= "." && $file!= ".." and is_dir($folder."/".$file)) {
				getTheFiles($file);
			}
		}
		closedir($handle);
	}
} -->
	</div>
</div>
</body>
</html>