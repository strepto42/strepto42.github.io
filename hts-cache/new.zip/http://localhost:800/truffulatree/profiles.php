<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - People's Profiles - James Ruse Agricultural High School Class of 1992 10 year reunion - personal profiles</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="James Ruse Agricultural High School Class of 1992 10 year reunion - personal profiles">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="James Ruse Agricultural High School Class of 1992 10 year reunion pictures" href='10yearpics.php'>Reunion Photos</a></li>
<li><a title="James Ruse Agricultural High School Class of 1992 - Class photo" href='classphoto.php'>Class Photo</a></li>
<li><div class='activemenu'>People's Profiles</div></li>
<li> </li><br><li>Or go back to:</li><li><a title='James Ruse Agricultural High School Class of 1992 10 year reunion' href="reunion.php">Reunion</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>People's Profiles</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Old stuff from my site' href="archive.php">Archive</a> > <a title='James Ruse Agricultural High School Class of 1992 10 year reunion' href="reunion.php">Reunion</a> > <a title='James Ruse Agricultural High School Class of 1992 10 year reunion - personal profiles' href="profiles.php">People's Profiles</a>
<br><br>		<br>
Here are all the updates that everyone put together. I'm a slackarse and still haven't done mine, but you can check out the <a href="about.php">about page</a> if you care about me that much.<br>
<br>
Pick from the files below to download people's profiles.<br>
<br><br>
Files available for download:<br>
<ul class="dirlist"><li><a href="files/reunion/adam_keppie.ppt">adam_keppie.ppt</a></li><li><a href="files/reunion/adrian_cory.doc">adrian_cory.doc</a></li><li><a href="files/reunion/bronwyn_walker.doc">bronwyn_walker.doc</a></li><li><a href="files/reunion/brooke_keppie.doc">brooke_keppie.doc</a></li><li><a href="files/reunion/chee-hoe_tham.doc">chee-hoe_tham.doc</a></li><li><a href="files/reunion/david_chinner.txt">david_chinner.txt</a></li><li><a href="files/reunion/guy_bunn.doc">guy_bunn.doc</a></li><li><a href="files/reunion/helen_troup.doc">helen_troup.doc</a></li><li><a href="files/reunion/iain_lauer.doc">iain_lauer.doc</a></li><li><a href="files/reunion/jenny_cooper.doc">jenny_cooper.doc</a></li><li><a href="files/reunion/jenny_cooper.jpg">jenny_cooper.jpg</a></li><li><a href="files/reunion/jenny_crandell.doc">jenny_crandell.doc</a></li><li><a href="files/reunion/jenny_darnell.doc">jenny_darnell.doc</a></li><li><a href="files/reunion/jenny_eden.doc">jenny_eden.doc</a></li><li><a href="files/reunion/jenny_harvey.doc">jenny_harvey.doc</a></li><li><a href="files/reunion/justine_drew_calleja.doc">justine_drew_calleja.doc</a></li><li><a href="files/reunion/karen_cambrell.doc">karen_cambrell.doc</a></li><li><a href="files/reunion/katrina_groot_obbink.doc">katrina_groot_obbink.doc</a></li><li><a href="files/reunion/katy_white.txt">katy_white.txt</a></li><li><a href="files/reunion/kirsty_harvison.zip">kirsty_harvison.zip</a></li><li><a href="files/reunion/liz_scott.doc">liz_scott.doc</a></li><li><a href="files/reunion/lucy_curlewis.doc">lucy_curlewis.doc</a></li><li><a href="files/reunion/lucy_johnson.doc">lucy_johnson.doc</a></li><li><a href="files/reunion/mark_edler.doc">mark_edler.doc</a></li><li><a href="files/reunion/matt_webster.doc">matt_webster.doc</a></li><li><a href="files/reunion/michael_shamgar.rtf">michael_shamgar.rtf</a></li><li><a href="files/reunion/michael_tidman.txt">michael_tidman.txt</a></li><li><a href="files/reunion/mila_kasby.doc">mila_kasby.doc</a></li><li><a href="files/reunion/nads.doc">nads.doc</a></li><li><a href="files/reunion/neisha_and_george.doc">neisha_and_george.doc</a></li><li><a href="files/reunion/paul_and_row.doc">paul_and_row.doc</a></li><li><a href="files/reunion/peter_hoy.doc">peter_hoy.doc</a></li><li><a href="files/reunion/rebecca_shead.doc">rebecca_shead.doc</a></li><li><a href="files/reunion/sam_ridler.doc">sam_ridler.doc</a></li><li><a href="files/reunion/winston_chu.doc">winston_chu.doc</a></li></ul><!-- old method
getTheFiles($file);

function getTheFiles($folder) {
	if ($handle = opendir($folder)) {
		while (false !== ($file = readdir($handle))) {
			If ($file!= "." && $file!= ".." and !is_dir($folder."/".$file)) {
				$filesize = round(filesize ($folder."/".$file)/1024,2);
				echo "<tr><td><div align='left'><A href='$corelise$folder/$file'>$file</a></div></td><td><div align='left'>$filesize KB</div></td><tr>\n";
			} else {
			If ($file!= "." && $file!= ".." and is_dir($folder."/".$file)) {
				getTheFiles($file);
			}
		}
		closedir($handle);
	}
} -->
	</div>
</div>
</body>
</html>