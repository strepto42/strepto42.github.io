<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - India 2000 - Travelouges from my trip through India in 2000</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="Travelouges from my trip through India in 2000">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><div class='activemenu'>India 2000</div></li>
<ul>
<li><a title="Greetings from the Other Side" href='greetingsfromtheotherside.php'>16/10/2000</a></li>
<li><a title="Another quick update from the land of rupees..." href='anotherquickupdate.php'>19/10/2000</a></li>
<li><a title="More Miscellaneous Ramblings from the Teeming Subcontinent" href='subcontinentramblings.php'>25/10/2000</a></li>
<li><a title="Indian Update" href='indianupdate.php'>4/11/2000</a></li>
<li><a title="From the Ganges to the Taj... and beyond" href='gangestotaj.php'>18/11/2000</a></li>
<li><a title="Camels, Tigers, Elephants and Octopussies" href='camelstigersoctopussies.php'>9/12/2000</a></li>
<li><a title="Back to bloody reality" href='backtobloodyreality.php'>14/12/2000</a></li>
</ul>
<li><a title="Travelouges and blogs from my trip around Australia" href='nerdseyeview.php'>Nerd's Eye View</a></li>
<li><a title="Warrumbungle, Kings Plains and Bald Rock National Parks" href='outbackNSW.php'>Outback NSW</a></li>
<li><a title="Alice Springs and surrounds" href='redcentre.php'>The Red Centre</a></li>
<li> </li><br><li>Or go back to:</li><li><a title='Travel stories and pictures' href="travel.php">Travelogues</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>India 2000</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Travel stories and pictures' href="travel.php">Travelogues</a> > <a title='Travelouges from my trip through India in 2000' href="india2000.php">India 2000</a>
<br>Select a link on the left to continue navigating.<br><br>		<br>
Before <a href="nerdseyeview.php">Nerd's Eye View</a>, my first travel emails came from a trip to India back in 2000. It's a bloody amazing place; I'll definitely go back there sometime.<br>
<br>
The emails home are presented here for the first time with pictures (as I finally got 'em scanned). Click on a link above to get started!<br>
<br>
I've also posted these blogs on Carl's site, <a href="http://www.swagtravel.com" target="_blank">www.swagtravel.com</a> with a limited selection of pics. Check it out if you like.<br>


	</div>
</div>
</body>
</html>