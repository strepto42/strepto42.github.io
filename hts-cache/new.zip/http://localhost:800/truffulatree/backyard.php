<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - Backyard Creatures - Various creatures and views from our Brisbane back yard</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="Various creatures and views from our Brisbane back yard">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="Pictures of my 28th Birthday party complete with Sparkler Bomb" href='28th.php'>28th Birthday</a></li>
<li><a title="Pictures of my 30th Birthday party" href='30th.php'>30th Birthday</a></li>
<li><a title="Michael Shamgar and Lindsay Halamek's 30th birthday bash photos" href='sl30th.php'>Shams & Linds' 30th</a></li>
<li><a title="Pictures of Andy Marinos's new flat, cat Toby, and Mum Pam Swain" href='andycatandflat.php'>Andy's Cat & Flat</a></li>
<li><a title="Pictures of a visit to Stephen Jackson's Farm" href='jackovisit.php'>Jacko's Farm</a></li>
<li><a title="Pictures taken at the Peace Convergence action in Rockhampton and Yeppoon in June 2005 to protest the joint US Australia military exercises (Operation Talisman Sabre)" href='peaceconvergence.php'>Peace Convergence</a></li>
<li><a title="Sydney trip - April '06" href='bridges.php'>Sydney, April 06</a></li>
<li><a title="Pics of Naima's 28th birthday dinner" href='mim28th.php'>Naima's 28th</a></li>
<li><a title="Brisbane CBD and the Story Bridge" href='brisbanepics1.php'>Brissie by Night 1</a></li>
<li><a title="Lamington National Park" href='lamington.php'>Lamington NP</a></li>
<li><div class='activemenu'>Backyard Creatures</div></li>
<li><a title="Opening day of the Eleanor Schonell (Green) Bridge" href='greenbridge.php'>Green Bridge</a></li>
<li><a title="Pictutres from the 2006 Woodford Folk Festival" href='woodford0607.php'>Woodford 2006-2007</a></li>
<li><a title="One Cute Puppy" href='jezebel.php'>Jezebel</a></li>
<li><a title="Climbing at Kangaroo Point Cliffs" href='kangaroopt1.php'>Heather's Visit</a></li>
<li><a title="0x0021st (33rd) birthday celebrations" href='0x0021st.php'>0x0021st Birthday</a></li>
<li><a title="Nuptial photography" href='guyandalison.php'>Guy and Alison's Wedding</a></li>
<li><a title="Pictures from the 2007 Woodford Folk Festival" href='woodford0708.php'>Woodford 2007-2008</a></li>
<li><a title="Image gallery" href='sydneytrip0802.php'>Sydney & Yacaaba Head</a></li>
<li><a title="An impressive show by nature" href='lightning.php'>Thunderstorm Moonrise</a></li>
<li><a title="Frightening pictures of a shrinking beard" href='debearding.php'>De-bearding</a></li>
<li><a title="More Nuptial Photography" href='michaelandkaren.php'>Michael and Karen's Wedding</a></li>
<li><a title="A night of celebration" href='andrews21st.php'>Andrew's 21st</a></li>
<li><a title="Image Gallery" href='bloodyknee.php'>Bloody Knee</a></li>
<li><a title="Image Gallery" href='tyesbirthday.php'>Tye's Birthday</a></li>
<li><a title="Image Gallery" href='lasersocialising.php'>Laser Socialising</a></li>
<li><a title="Image Gallery" href='heatherandevan.php'>Heather and Evan's Wedding</a></li>
<li><a title="Image Gallery" href='woodford0809.php'>Woodford 2008-2009</a></li>
<li><a title="Image Gallery" href='allyandben.php'>Ally and Ben's Wedding</a></li>
<li><a title="Image Gallery" href='annes30th.php'>Anne's 30th</a></li>
<li><a title="Image Gallery" href='possumcreek.php'>Possum Creek</a></li>
<li><a title="Image Gallery" href='jamnight.php'>Jam Night</a></li>
<li><a title="Image Gallery" href='cunninghamsgap.php'>Cunningham's Gap</a></li>
<li><a title="Image Gallery" href='bigcat.php'>Diving on Big Cat</a></li>
<li><a title="Images from my birthday jam" href='birthdayjam.php'>Music, mayhem and merriment</a></li>
<li><a title="Image Gallery" href='fuzzypolaroidpics.php'>Fuzzy Polaroid</a></li>
<li><a title="Image Gallery" href='zombiewalk2009.php'>2009 Zombie Walk</a></li>
<li> </li><br><li>Or go back to:</li><li><a title='Picture galleries' href="pictures.php">Photography</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>Backyard Creatures</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Picture galleries' href="pictures.php">Photography</a> > <a title='Various creatures and views from our Brisbane back yard' href="backyard.php">Backyard Creatures</a>
<br><br>		

<p>One of the nice things about living in Australia is that you get visited by various creatures, even in the city. Here are some pictures of various visitors and residents of our back yard, including a nice big Blue-tongue Lizard, and a White-faced Heron.</p>

<p>There are also pics of a massive grasshopper (which may have been eaten now, as I haven't seen it for a while, but it was hanging around for months), fighting Geckos, a few miscellaneous pictures of one of the local hospital's Apocalypsenowmobiles, my first IR picture (more <a href="greenbridge.php">here</a>), and some random shots of the pink Frangipani in a particularly nice evening light.</p>
<br><br>
All images in this gallery:<br>
<table width='800'>
<tr>
</tr>
<tr><td><A ID='IMG_0229.JPG' href='backyard.php?fileId=IMG_0229.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061216/IMG_0229.JPG' ALT='Unusual Sunset'><BR>Unusual Sunset<br>58.92 KB</a><div class='inv'><br><a href='./images/20061216/IMG_0229.JPG' ALT='Unusual Sunset'>Unusual Sunset</a></div></td>
<td><A ID='IMG_0231.JPG' href='backyard.php?fileId=IMG_0231.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061216/IMG_0231.JPG' ALT='Unusual Sunset'><BR>Unusual Sunset<br>29.44 KB</a><div class='inv'><br><a href='./images/20061216/IMG_0231.JPG' ALT='Unusual Sunset'>Unusual Sunset</a></div></td>
<td><A ID='IMG_0232.JPG' href='backyard.php?fileId=IMG_0232.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061216/IMG_0232.JPG' ALT='Unusual Sunset'><BR>Unusual Sunset<br>45.54 KB</a><div class='inv'><br><a href='./images/20061216/IMG_0232.JPG' ALT='Unusual Sunset'>Unusual Sunset</a></div></td>
<td><A ID='IMG_0236.JPG' href='backyard.php?fileId=IMG_0236.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061216/IMG_0236.JPG' ALT='Unusual Sunset'><BR>Unusual Sunset<br>32.03 KB</a><div class='inv'><br><a href='./images/20061216/IMG_0236.JPG' ALT='Unusual Sunset'>Unusual Sunset</a></div></td>
<td><A ID='IMG_0298.JPG' href='backyard.php?fileId=IMG_0298.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061216/IMG_0298.JPG' ALT='Grey Butcher Bird'><BR>Grey Butcher Bird<br>39.95 KB</a><div class='inv'><br><a href='./images/20061216/IMG_0298.JPG' ALT='Grey Butcher Bird'>Grey Butcher Bird</a></div></td>
</tr>
<tr><td><A ID='IMG_0302.JPG' href='backyard.php?fileId=IMG_0302.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061216/IMG_0302.JPG' ALT='A lost Dove'><BR>A lost Dove<br>47.33 KB</a><div class='inv'><br><a href='./images/20061216/IMG_0302.JPG' ALT='A lost Dove'>A lost Dove</a></div></td>
<td><A ID='IMG_0311.JPG' href='backyard.php?fileId=IMG_0311.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061216/IMG_0311.JPG' ALT='Cute moth'><BR>Cute moth<br>74.96 KB</a><div class='inv'><br><a href='./images/20061216/IMG_0311.JPG' ALT='Cute moth'>Cute moth</a></div></td>
<td><A ID='IMG_0313.JPG' href='backyard.php?fileId=IMG_0313.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061216/IMG_0313.JPG' ALT='Cute moth'><BR>Cute moth<br>24.83 KB</a><div class='inv'><br><a href='./images/20061216/IMG_0313.JPG' ALT='Cute moth'>Cute moth</a></div></td>
<td><A ID='IMG_0531.JPG' href='backyard.php?fileId=IMG_0531.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061216/IMG_0531.JPG' ALT='Blue-tongue Lizard'><BR>Blue-tongue Lizard<br>90.4 KB</a><div class='inv'><br><a href='./images/20061216/IMG_0531.JPG' ALT='Blue-tongue Lizard'>Blue-tongue Lizard</a></div></td>
<td><A ID='IMG_0534.JPG' href='backyard.php?fileId=IMG_0534.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061216/IMG_0534.JPG' ALT='Blue-tongue Lizard'><BR>Blue-tongue Lizard<br>128.54 KB</a><div class='inv'><br><a href='./images/20061216/IMG_0534.JPG' ALT='Blue-tongue Lizard'>Blue-tongue Lizard</a></div></td>
</tr>
<tr><td><A ID='IMG_0549.JPG' href='backyard.php?fileId=IMG_0549.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061216/IMG_0549.JPG' ALT='Blue-tongue Lizard'><BR>Blue-tongue Lizard<br>86.63 KB</a><div class='inv'><br><a href='./images/20061216/IMG_0549.JPG' ALT='Blue-tongue Lizard'>Blue-tongue Lizard</a></div></td>
<td><A ID='IMG_0552.JPG' href='backyard.php?fileId=IMG_0552.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061216/IMG_0552.JPG' ALT='Blue-tongue Lizard'><BR>Blue-tongue Lizard<br>68.81 KB</a><div class='inv'><br><a href='./images/20061216/IMG_0552.JPG' ALT='Blue-tongue Lizard'>Blue-tongue Lizard</a></div></td>
<td><A ID='IMG_0554.JPG' href='backyard.php?fileId=IMG_0554.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061216/IMG_0554.JPG' ALT='Blue-tongue Lizard'><BR>Blue-tongue Lizard<br>127.8 KB</a><div class='inv'><br><a href='./images/20061216/IMG_0554.JPG' ALT='Blue-tongue Lizard'>Blue-tongue Lizard</a></div></td>
<td><A ID='IMG_0621.JPG' href='backyard.php?fileId=IMG_0621.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061216/IMG_0621.JPG' ALT='White-faced Heron'><BR>White-faced Heron<br>111.4 KB</a><div class='inv'><br><a href='./images/20061216/IMG_0621.JPG' ALT='White-faced Heron'>White-faced Heron</a></div></td>
<td><A ID='IMG_0624.JPG' href='backyard.php?fileId=IMG_0624.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061216/IMG_0624.JPG' ALT='White-faced Heron'><BR>White-faced Heron<br>77.99 KB</a><div class='inv'><br><a href='./images/20061216/IMG_0624.JPG' ALT='White-faced Heron'>White-faced Heron</a></div></td>
</tr>
<tr><td><A ID='IMG_0631.JPG' href='backyard.php?fileId=IMG_0631.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061216/IMG_0631.JPG' ALT='White-faced Heron'><BR>White-faced Heron<br>78.93 KB</a><div class='inv'><br><a href='./images/20061216/IMG_0631.JPG' ALT='White-faced Heron'>White-faced Heron</a></div></td>
<td><A ID='IMG_0633.JPG' href='backyard.php?fileId=IMG_0633.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061216/IMG_0633.JPG' ALT='White-faced Heron'><BR>White-faced Heron<br>48.64 KB</a><div class='inv'><br><a href='./images/20061216/IMG_0633.JPG' ALT='White-faced Heron'>White-faced Heron</a></div></td>
<td><A ID='IMG_0993.JPG' href='backyard.php?fileId=IMG_0993.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061216/IMG_0993.JPG' ALT='Lillies'><BR>Lillies<br>62.98 KB</a><div class='inv'><br><a href='./images/20061216/IMG_0993.JPG' ALT='Lillies'>Lillies</a></div></td>
<td><A ID='IMG_0995.JPG' href='backyard.php?fileId=IMG_0995.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061216/IMG_0995.JPG' ALT='Lillies'><BR>Lillies<br>62.53 KB</a><div class='inv'><br><a href='./images/20061216/IMG_0995.JPG' ALT='Lillies'>Lillies</a></div></td>
<td><A ID='IMG_0998.JPG' href='backyard.php?fileId=IMG_0998.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061216/IMG_0998.JPG' ALT='Dragonfly'><BR>Dragonfly<br>40.74 KB</a><div class='inv'><br><a href='./images/20061216/IMG_0998.JPG' ALT='Dragonfly'>Dragonfly</a></div></td>
</tr>
<tr><td><A ID='IMG_1610.JPG' href='backyard.php?fileId=IMG_1610.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061216/IMG_1610.JPG' ALT='A massive grasshopper'><BR>A massive grasshopper<br>60.75 KB</a><div class='inv'><br><a href='./images/20061216/IMG_1610.JPG' ALT='A massive grasshopper'>A massive grasshopper</a></div></td>
<td><A ID='IMG_1613.JPG' href='backyard.php?fileId=IMG_1613.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061216/IMG_1613.JPG' ALT='A massive grasshopper'><BR>A massive grasshopper<br>69.78 KB</a><div class='inv'><br><a href='./images/20061216/IMG_1613.JPG' ALT='A massive grasshopper'>A massive grasshopper</a></div></td>
<td><A ID='IMG_1615.JPG' href='backyard.php?fileId=IMG_1615.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061216/IMG_1615.JPG' ALT='A massive grasshopper'><BR>A massive grasshopper<br>66.61 KB</a><div class='inv'><br><a href='./images/20061216/IMG_1615.JPG' ALT='A massive grasshopper'>A massive grasshopper</a></div></td>
<td><A ID='IMG_1656.JPG' href='backyard.php?fileId=IMG_1656.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061216/IMG_1656.JPG' ALT='Fighting Geckos'><BR>Fighting Geckos<br>42 KB</a><div class='inv'><br><a href='./images/20061216/IMG_1656.JPG' ALT='Fighting Geckos'>Fighting Geckos</a></div></td>
<td><A ID='IMG_2630.JPG' href='backyard.php?fileId=IMG_2630.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061216/IMG_2630.JPG' ALT='Frangipani tree by infrared'><BR>Frangipani tree by infrared<br>78.03 KB</a><div class='inv'><br><a href='./images/20061216/IMG_2630.JPG' ALT='Frangipani tree by infrared'>Frangipani tree by infrared</a></div></td>
</tr>
<tr><td><A ID='IMG_2635.JPG' href='backyard.php?fileId=IMG_2635.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061216/IMG_2635.JPG' ALT='IMG_2635.JPG'><BR>IMG_2635.JPG<br>26.47 KB</a><div class='inv'><br><a href='./images/20061216/IMG_2635.JPG' ALT='IMG_2635.JPG'>IMG_2635.JPG</a></div></td>
<td><A ID='IMG_2638.JPG' href='backyard.php?fileId=IMG_2638.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061216/IMG_2638.JPG' ALT='IMG_2638.JPG'><BR>IMG_2638.JPG<br>29.38 KB</a><div class='inv'><br><a href='./images/20061216/IMG_2638.JPG' ALT='IMG_2638.JPG'>IMG_2638.JPG</a></div></td>
<td><A ID='IMG_2644.JPG' href='backyard.php?fileId=IMG_2644.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061216/IMG_2644.JPG' ALT='IMG_2644.JPG'><BR>IMG_2644.JPG<br>95.68 KB</a><div class='inv'><br><a href='./images/20061216/IMG_2644.JPG' ALT='IMG_2644.JPG'>IMG_2644.JPG</a></div></td>
<td><A ID='IMG_2647.JPG' href='backyard.php?fileId=IMG_2647.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061216/IMG_2647.JPG' ALT='IMG_2647.JPG'><BR>IMG_2647.JPG<br>97.33 KB</a><div class='inv'><br><a href='./images/20061216/IMG_2647.JPG' ALT='IMG_2647.JPG'>IMG_2647.JPG</a></div></td>
<td><A ID='IMG_2650.JPG' href='backyard.php?fileId=IMG_2650.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061216/IMG_2650.JPG' ALT='IMG_2650.JPG'><BR>IMG_2650.JPG<br>86.18 KB</a><div class='inv'><br><a href='./images/20061216/IMG_2650.JPG' ALT='IMG_2650.JPG'>IMG_2650.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_2655.JPG' href='backyard.php?fileId=IMG_2655.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061216/IMG_2655.JPG' ALT='IMG_2655.JPG'><BR>IMG_2655.JPG<br>71.93 KB</a><div class='inv'><br><a href='./images/20061216/IMG_2655.JPG' ALT='IMG_2655.JPG'>IMG_2655.JPG</a></div></td>
<td><A ID='IMG_2660.JPG' href='backyard.php?fileId=IMG_2660.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061216/IMG_2660.JPG' ALT='IMG_2660.JPG'><BR>IMG_2660.JPG<br>77.51 KB</a><div class='inv'><br><a href='./images/20061216/IMG_2660.JPG' ALT='IMG_2660.JPG'>IMG_2660.JPG</a></div></td>
<td><A ID='IMG_2665.JPG' href='backyard.php?fileId=IMG_2665.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061216/IMG_2665.JPG' ALT='IMG_2665.JPG'><BR>IMG_2665.JPG<br>96.34 KB</a><div class='inv'><br><a href='./images/20061216/IMG_2665.JPG' ALT='IMG_2665.JPG'>IMG_2665.JPG</a></div></td>
<td><A ID='IMG_2667.JPG' href='backyard.php?fileId=IMG_2667.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061216/IMG_2667.JPG' ALT='IMG_2667.JPG'><BR>IMG_2667.JPG<br>74.02 KB</a><div class='inv'><br><a href='./images/20061216/IMG_2667.JPG' ALT='IMG_2667.JPG'>IMG_2667.JPG</a></div></td>
<td><A ID='IMG_2669.JPG' href='backyard.php?fileId=IMG_2669.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061216/IMG_2669.JPG' ALT='IMG_2669.JPG'><BR>IMG_2669.JPG<br>72.85 KB</a><div class='inv'><br><a href='./images/20061216/IMG_2669.JPG' ALT='IMG_2669.JPG'>IMG_2669.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_2670.JPG' href='backyard.php?fileId=IMG_2670.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061216/IMG_2670.JPG' ALT='IMG_2670.JPG'><BR>IMG_2670.JPG<br>64.83 KB</a><div class='inv'><br><a href='./images/20061216/IMG_2670.JPG' ALT='IMG_2670.JPG'>IMG_2670.JPG</a></div></td>
<td><A ID='IMG_2671.JPG' href='backyard.php?fileId=IMG_2671.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061216/IMG_2671.JPG' ALT='IMG_2671.JPG'><BR>IMG_2671.JPG<br>73.37 KB</a><div class='inv'><br><a href='./images/20061216/IMG_2671.JPG' ALT='IMG_2671.JPG'>IMG_2671.JPG</a></div></td>
</tr>
</table>	</div>
</div>
</body>
</html>