<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - July 2007 - Q&A letters</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="Q&A letters">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="Q&A letters" href='masterit200701.php'>January 2007</a></li>
<li><a title="Q&A letters" href='masterit200702.php'>February 2007</a></li>
<li><a title="Q&A letters" href='masterit200703.php'>March 2007</a></li>
<li><a title="Q&A letters" href='masterit200704.php'>April 2007</a></li>
<li><a title="Q&A letters" href='masterit200705.php'>May 2007</a></li>
<li><a title="Q&A letters" href='masterit200706.php'>June 2007</a></li>
<li><div class='activemenu'>July 2007</div></li>
<li> </li><br><li>Or go back to:</li><li><a title='Q&A letters from 2007' href="masterit2007.php">2007 archive</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>July 2007</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Mark's writing' href="written.php">Professional Writing</a> > <a title='My weekly Q&A column in The Australian' href="masterIT.php">MasterIT</a> > <a title='Q&A letters from 2007' href="masterit2007.php">2007 archive</a> > <a title='Q&A letters' href="masterit200707.php">July 2007</a>
<br><br>		<br>
<h2>3/7/07</h2><br>
<b>A question out of curiosity: when a DVD is burned "at 16x", what does the 16x mean, and how is it calculated?</b><br>
<br>
16x means that the DVD is being written to at sixteen times the "standard DVD read speed" (about 1352kb/sec) - in other words, at just over 21 megabytes per second.<br>
<br>
CDs also have a speed rating, but theirs is lower - 1x for CD means only 150k/sec, which is a perfectly good speed for streaming 44.1kHz stereo audio, but is quite slow for data transfer on a computer.<br>
<br>
Because of this, CD-ROM drive manufacturers started multiplying the basic rotation speed of the disc by various amounts, allowing the laser to read the data more quickly.<br>
<br>
The standard DVD 1x speed is faster because the data is more densely packed on the disc; a CD writer burning at 45x speed is actually writing the same amount of data each second as a DVD burner would at 5x. There's a comparison at http://tinyurl.com/4mgjr.<br>
<br>
By the way, if you're wondering why CD writers have maxed out at about 55x, it's because at that speed the disc is spinning so fast that it risks spontaneously shattering at any higher speed (this is generally considered Bad for both drive and disc).<br>
<br>
DVDs at 16x are also approaching this speed limit - but we have Blu-ray and HD-DVD lurking in the wings to keep up the pace in the future.<br>
<br>
<br>
<b>I fairly regularly get emails from friends warning about various viruses. Most of these sound scary, but a little dubious. For example, the other day I got one about an "Olympic Torch" which "burns" the C drive. I don't know enough to dismiss these outright though... should I be forwarding them?</b><br>
<br>
Being careful about viruses is never a bad thing, but emails about them are almost always hoaxes.<br>
<br>
Some of these hoaxes are remarkably long-lived. The Olympic Torch one has been circulating since at least 2000 (and yes, it is a hoax).<br>
<br>
I really have no idea what motivates people to write these things in the first place, but I don't understand the joy of chain letters either, so I must be in a different headspace.<br>
<br>
You can verify the authenticity of these warnings, and all other sorts of urban myths, by visiting the excellent website snopes.com.<br>
<br>
<br>
<h2>10/7/07</h2><br>
<b>I've just bought a new HP lappie, and for the life of me I cannot get web pages to fill the screen. I have gone into the advanced browser settings and ticked the "enable full screen" box, but I still get many web pages only taking up the left half of the screen. Any ideas mate?</b><br>
<br>
The problem lies in the website design, not in your configuration. Full screen mode in the browsers only stretches the available viewspace to fill the screen; it doesn't stretch the content.<br>
<br>
The real life details are a bit muddier, but simply speaking, when you build web pages, you can specify the widths of things as absolute numbers of pixels, or as relative percentages of the total width.<br>
<br>
A well built web page will use percentages, and will scale nicely to whatever screen resolution you're using. It's harder to build them this way though, so many don't scale properly at all.<br>
<br>
Laptops, with their high-pixel-count widescreens, tend to accentuate the problem.<br>
<br>
You can try to increase the font size with Control-plus (Control-minus reduces it again), and this may help in some cases.<br>
<br>
For example, my own web banking site is a tiny-fonted blob in the middle of a huge expanse of white, but I can make it slightly more usable using the technique above.<br>
<br>
It's still a shame, because before my credit union merged with CUA, their old web banking system scaled nicely to fill the screen. My complaints about this, and some other idiotic features of their new site have (unsurprisingly) fallen on deaf ears.<br>
<br>
At least I can still rant about it here.<br>
<br>
<br>
<b>I'm looking to brighten up my work PC with some new wallpaper. What I'd really like to be able to do is to have a number of different pictures that change each day, but I can't seem to find an option in Windows to do it. I also have two screens, and it would be nice to have a different picture on each. Is this possible?</b><br>
<br>
Windows' own wallpaper management is pretty basic set-and-forget stuff, but there are countless third party utilities out there that will give you the ability to rotate wallpapers at given intervals.<br>
<br>
As far as running two different wallpapers on different monitors goes, I've only found one utility to do it, called Wallpaper Master (www.jamesgart.com). It's not free, but it does sport just about every feature under the sun, and there's a 30 day trial available before it drops back to a more basic, single monitor mode.<br>
<br>
Another good utility is Wallpaper changer (www.wallpaperchanger.de). It's completely free, but doesn't have multi-monitor support.<br>
<br>
<br>
<h2>17/7/07</h2><br>
<b>With all the hype over the low cost of VOIP, I understand that there is still a cost related to the download and upload on my Broadband. I have a relatively small allowance of 500MB, after which I pay 15c extra per mb. I was wondering what one can expect a to use in a normal phone call. I realise that the length of a call will vary, but assuming that there is a constant conversation going on, is it possible to arrive at a average per minute MB use?</b><br>
<br>
You're right about VOIP using a small amount of your data transfer allowance. Normally this isn't a huge deal, but with your 500mb uncapped plan (I'm guessing its with Telstra, as most other ISPs don't charge for excess usage - they just slow down the connection) it could become a factor.<br>
<br>
Like you say, it's hard to pin down exactly how much data a VOIP call will use, because the audio is compressed, and so varies in size depending on its complexity, whether both people are speaking, etc.<br>
<br>
To add to the problem, there are different 'codecs' out there - basically algorithms that compress the data - and some are more efficient than others. Two commonly mentioned ones are G.711 (less efficient) and G.729 (more efficient, but with slightly lower sound quality).<br>
<br>
As a worst case, ball park figure, you can count on G.711 using about 60mb an hour.<br>
<br>
There is a somewhat technical calculator for working this stuff out at tinyurl.com/34aute. To convert the kbps figure, use 1 kbps = 0.44 megabytes per hour.<br>
<br>
At the end of the day, your best bet may be to seek an Internet provider with better value plans, so that the bandwidth use doesn't matter. <br>
<br>
Telstra's other bad habit of charging for outgoing traffic as well as incoming (something which almost no other ISP does, although, sadly, Optus recently announced that it would do this too) also means that this double-dipping effectively doubles your VOIP data usage.<br>
<br>
<br>
<b>Last Tuesday's Briefing article about music rippers is a bit confusing for people who use Mac OSX machines. The picture showed a Powerbook with a Nano being used, but the programs you mentioned are not Mac compatible. One I used is at tinyurl.com/2n48lx.</b><br>
<br>
Yes, blessings on Murphy and the sub editors for putting in that particular picture.<br>
<br>
Exact Audio Copy is indeed Windows only - but the FLAC and LAME codecs are open source, and Mac compatible builds are available.<br>
<br>
For a Mac compatible build of FLAC, check out flac.sourceforge.net/download.html. For LAME, have a look at lame.sourceforge.net/links.php.<br>
<br>
<i><p>Did the information on this page help you? Entertain you? Bore you? <a href="contact.php?subject=MasterIT">Drop me a line</a>.</p>

<p>If you're feeling particularly generous, you can even <a href="buypics.php">click here to send me some dot-com riches</a>. Think of it as online busking.</i></p>
	</div>
</div>
</body>
</html>