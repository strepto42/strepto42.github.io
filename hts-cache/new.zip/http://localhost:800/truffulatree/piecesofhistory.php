<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - 8/7/2005 - Pieces of History</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="Pieces of History">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="Greetings from a Bum" href='greetingsfromabum.php'>29/4/2005</a></li>
<li><a title="Onward" href='onward.php'>2/5/2005</a></li>
<li><a title="It's a tough life (pt 1: Bundaberg, Agnes Water and 1770)" href='itsatoughlife1.php'>17/5/2005</a></li>
<li><a title="It's a tough life (pt 2: Rockhampton, Emu Park and Great Keppel Island)" href='itsatoughlife2.php'>23/5/2005</a></li>
<li><a title="There and Back Again - a Yo-yo's Tale" href='thereandbackagain.php'>18/6/2005</a></li>
<li><a title="Platypi and Grey Nomads" href='platypiandgreynomads.php'>24/6/2005</a></li>
<li><a title="Blowing Bubbles in a Watery Tomb" href='blowingbubbles.php'>1/7/2005</a></li>
<li><div class='activemenu'>8/7/2005</div></li>
<li><a title="Walks and Waterfalls" href='walksandwaterfalls.php'>15/7/2005</a></li>
<li><a title="Mission to Tribulation" href='missiontotribulation.php'>22/7/2005</a></li>
<li><a title="Levity, Limestone and Lava" href='levitylimestoneandlava.php'>29/7/2005</a></li>
<li><a title="Into the Never Never" href='intothenevernever.php'>5/8/2005</a></li>
<li><a title="Slowing the pace in Darwin" href='slowingthepaceindarwin.php'>12/8/2005</a></li>
<li><a title="Blistering Barnacles and Leaping Lizards" href='leapinglizards.php'>19/8/2005</a></li>
<li><a title="Kakadu and Litchfield" href='kakadu.php'>26/8/2005</a></li>
<li><a title="Legacies of War" href='legaciesofwar.php'>2/9/2005</a></li>
<li><a title="Go West" href='gowest.php'>10/9/2005</a></li>
<li><a title="Things from Above" href='thingsfromabove.php'>16/9/2005</a></li>
<li><a title="The West Coast" href='thewestcoast.php'>23/9/2005</a></li>
<li><a title="Reefs and Red Dust" href='reefsandreddust.php'>30/9/2005</a></li>
<li><a title="The Pilbara" href='pilbara.php'>7/10/2005</a></li>
<li><a title="Paradise with a Headwind" href='paradisewithaheadwind.php'>14/10/2005</a></li>
<li><a title="Down the Coral Coast" href='downthecoralcoast.php'>21/10/2005</a></li>
<li><a title="Pinnacles and Pinnipeds" href='pinnaclesandpinnipeds.php'>28/10/2005</a></li>
<li><a title="A week in Perth" href='perth.php'>4/11/2005</a></li>
<li><a title="The Southwest (from Above and Below)" href='thesouthwest.php'>11/11/2005</a></li>
<li><a title="More Heights and Depths" href='moreheightsanddepths.php'>18/11/2005</a></li>
<li><a title="Across the Nullarbor (and a bit beyond)" href='nullarbor.php'>25/11/2005</a></li>
<li><a title="Double Whammy" href='doublewhammy.php'>9/12/2005</a></li>
<li><a title="Two Cities" href='twocities.php'>19/12/2005</a></li>
<li><a title="Tassie - Part 1" href='tassie1.php'>1/1/2006</a></li>
<li><a title="Tassie - Part 2" href='tassie2.php'>7/1/2006</a></li>
<li><a title="Full Circle" href='fullcircle.php'>26/1/2006</a></li>
<li><a title="The Wrap Up" href='thewrapup.php'>23/3/2006</a></li>
<li> </li><br><li>Or go back to:</li><li><a title='Travelouges and blogs from my trip around Australia' href="nerdseyeview.php">Nerd's Eye View</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>8/7/2005</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Travel stories and pictures' href="travel.php">Travelogues</a> > <a title='Travelouges and blogs from my trip around Australia' href="nerdseyeview.php">Nerd's Eye View</a> > <a title='Pieces of History' href="piecesofhistory.php">8/7/2005</a>
<br><br>		


<h1>Pieces of History</h1>

<a href="images/maps/Map050708.gif"><img src="images/maps/Map050708_sm.gif" align="right"></a>
<p>Hi all,</p>

<p>It's me yet again. This will actually be the last big email I send around to everyone. Don't worry though - from now on, I'll simply post a link to here on my website, and if you want to read the latest you can go there. I think this will work better for a lot of people, and it won't set off as many spam filters or fill up anyone's inbox without warning.</p>

<p>After the diving adventure last week, I decided a change of scenery was in order, and whilst it was my plan to go to Townsville straight away, a quick look at the map revealed that if I wanted to visit Charters Towers it would be a better idea to go there first, or I'd have to backtrack.</p>

<p>So I headed inland to Charters, a former gold rush town, which in it's heyday had many many pubs and a stock exchange of its own. Now it's contracted somewhat, and really, there's not a whole lot to do there.</p>

<p>I spent the first day there getting my bearings, and on the advice of the owners of the (very quiet) hostel, I went for a ride to an old cemetery up the road. This sad-looking spot has a lot of unmarked graves, and a lot of falling over tombstones and so on.</p>

<p>As I was walking around the desolate place taking a few photos, my front bicycle tyre spontaneously burst and hissed it's life away like the Wicked Witch of the West in a puddle of water. This of course immediately proved the existence of the supernatural.</p>

<p>Actually, it turned out that I had proved the existence of a plant called Goat's Weed, or something like that (it has various names, none of which I can remember now). It's the evil big brother of the Bindy eye, specially evolved to puncture bike tyres. I'm thankful I didn't find out how it feels to tread on it with bare feet.</p>

<p>So that ended my little excursion, and I walked back to the hostel and did some tube changing and patching. Joyfully, the next morning I found my rear tyre also flat. Bugger.</p>

<p>The next day I headed out to one of the old ore crushing mills (or batteries) to have a looksee. I ended up on a strange tour with a bunch of old folks, given by an old fellow who knew his stuff, but somehow disturbed me.</p>

<p>They used a lot of mercury in the old days, and maybe that explains something about the whole area; but maybe it's just outback northern Qld (which I suspect is actually the case).</p>

<p>Still, he was full of interesting stories, like how various workers used to steal gold by smuggling it out in their pipes (often mixed with mercury mind you - don't light that baby up or you'll get more than a headache!).</p>

<p>Anyway, apart from some cheesy optical trickery in the form of presentations from "ghosts", and some interesting old machinery, it wasn't exactly the experience of my life. But as always, I got photos.</p>

<p>I ended the day with an all-you-can-eat meal at the local Chinese place. All two Chinese eateries I saw in town there had "gold" puns in their name - I suppose that's only fair for a former mining town. Still, I was reminded of Bargearse's "Golden Retriever". I don't think the locals would have gotten the joke.</p>

<p>From there I pushed on to Townsville, at long last, and booked myself into the second hostel I visited, as the first wouldn't let me stay in a dorm room because I was Australian. Apparently we cause all the trouble.</p>

<p>After another number 10 evening of guitar and wine with some Irish guys (it's always Irish guys�), I headed out on the bike the next day for a spot of exploration. When I was a wee bub, my folks lived in Townsville for some months, and I even had my first birthday there. Mum and Dad sent me a scanned photo of me outside the flat where they stayed, plus it's location, so I went on a mission to find it, and find it I did - check out the last two photos. Awww.</p>

<p>I also decided it would be fun :| to cycle up Castle Hill, the big hill in the middle of town. It seems I've lost a wee bit of cycling condition, so it was a task, but I made it up, and then took some nice pics (after sitting down and panting for some time). The ride down was of course exemplary, albeit brief compared to the journey up.</p>

<p>My Dad also sent me this short story about Castle Hill:</p>

<p><em>"Do you realize that when you went cycling to Castle Hill you were riding on an atom bomb? During Ben Lomond times, one of our guys told the press that the whole of Castle Hill (which is indeed pretty hot granite) probably contained 500 tons of uranium, to show that people live with radiation all the time. The next day there was the front-page headline 'TOWNSVILLE BUILT ON A POTENTIAL ATOM BOMB!'. So there."</em></p>

<p>Anyway I'm not glowing yet.</p>

<p>The following day I headed out to Magnetic Island, which is just off the coast of Townsville, and was so named by Captain Cook after his compass went wiggy (technical term) as he passed by.</p>

<p>They charge quite a lot of money to take the car on the ferry, but bikes are free, so I figured I'd pack enough for one night and get round on two wheels, what with it being an island and all, and no doubt flat. I mean, islands are, aren't they?</p>

<p>Turns out it's hillier than I thought, and bigger, especially when you're going up those hills. After my hill-climbing escapades of the previous day I was well and truly knackered by the end of the day, and a little grumpy, due to the weather, my legs, and crappy surf where I had wanted to snorkel. Not to worry, it's all part of the fun of travel, and I got lots of lovely exercise.</p>

<p>Magnetic Island is quite pretty, but after Great Keppel I think I've been spoiled for island living (for the moment, at least).</p>

<p>I caught the ferry back the next day, and stayed one more night in Townsville, where I watched Qld get steamrollered in the footy, much to my amusement and the disgust of the locals. It also served to remind me why I don't bother watching it (it's hell-boring, even with beer).</p>

<p>Now I'm on the road again, on my way slowly further north, with some more national parks beckoning.</p>

<p>I hope you're all well, and as usual I'd love to hear from you. As I said from now on I'll just post my stories and pictures on my here, as well as on <a href="http://www.and2makes4.com" target="_blank">Carl's Website</a>, as it'll make life easier for all.</p>

<p>Oh, captions for this last batch of selected pics:</p>
<!-- 
<ul>
<li><a href="?fileId=IMG_3878.JPG">The old stock exchange, Charters Towers</a></li>
<li><a href="?fileId=IMG_3887.JPG">The exciting Venus Gold Battery</a></li>
<li><a href="?fileId=IMG_4090.JPG">Magnetic Island. Yes I know the horizon isn't straight. It's art.</a></li>
<li><a href="?fileId=IMG_4106.JPG">Some chubby kid or other - present day</a></li>
<li><a href="?fileId=IMG_4106_1975.JPG">Some chubby kid or other - way back when</a></li>
</ul>
 -->
<table width="800">
	<tr>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=IMG_3878.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20050708/IMG_3878.JPG' ALT='The old stock exchange, Charters Towers'><BR>The old stock exchange, Charters Towers</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=IMG_3887.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20050708/IMG_3887.JPG' ALT='The exciting Venus Gold Battery'><BR>The exciting Venus Gold Battery</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=IMG_4090.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20050708/IMG_4090.JPG' ALT='Magnetic Island. Yes I know the horizon isn't straight. It's art.'><BR>Magnetic Island. Yes I know the horizon isn't straight. It's art.</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=IMG_4106.JPG'>
		<img src='./images/20050708/TN_IMG_4106.JPG' ALT='Some chubby kid or other - present day'><BR>Some chubby kid or other - present day</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=IMG_4106_1975.JPG'>
		<img src='./images/20050708/TN_IMG_4106_1975.JPG' ALT='Some chubby kid or other - way back when'><BR>Some chubby kid or other - way back when</a>
	</td>
	</tr>
</table>

<p>Bye now!</p>

<br><br>
All images in this gallery:<br>
<table width='800'>
<tr>
</tr>
<tr><td><A ID='IMG_3862.JPG' href='piecesofhistory.php?fileId=IMG_3862.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050708/IMG_3862.JPG' ALT='IMG_3862.JPG'><BR>IMG_3862.JPG<br>120.53 KB</a><div class='inv'><br><a href='./images/20050708/IMG_3862.JPG' ALT='IMG_3862.JPG'>IMG_3862.JPG</a></div></td>
<td><A ID='IMG_3864.JPG' href='piecesofhistory.php?fileId=IMG_3864.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050708/IMG_3864.JPG' ALT='IMG_3864.JPG'><BR>IMG_3864.JPG<br>97.97 KB</a><div class='inv'><br><a href='./images/20050708/IMG_3864.JPG' ALT='IMG_3864.JPG'>IMG_3864.JPG</a></div></td>
<td><A ID='IMG_3865.JPG' href='piecesofhistory.php?fileId=IMG_3865.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050708/IMG_3865.JPG' ALT='IMG_3865.JPG'><BR>IMG_3865.JPG<br>82.51 KB</a><div class='inv'><br><a href='./images/20050708/IMG_3865.JPG' ALT='IMG_3865.JPG'>IMG_3865.JPG</a></div></td>
<td><A ID='IMG_3867.JPG' href='piecesofhistory.php?fileId=IMG_3867.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050708/IMG_3867.JPG' ALT='IMG_3867.JPG'><BR>IMG_3867.JPG<br>54.18 KB</a><div class='inv'><br><a href='./images/20050708/IMG_3867.JPG' ALT='IMG_3867.JPG'>IMG_3867.JPG</a></div></td>
<td><A ID='IMG_3874.JPG' href='piecesofhistory.php?fileId=IMG_3874.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050708/IMG_3874.JPG' ALT='IMG_3874.JPG'><BR>IMG_3874.JPG<br>74.12 KB</a><div class='inv'><br><a href='./images/20050708/IMG_3874.JPG' ALT='IMG_3874.JPG'>IMG_3874.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_3878.JPG' href='piecesofhistory.php?fileId=IMG_3878.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050708/IMG_3878.JPG' ALT='IMG_3878.JPG'><BR>IMG_3878.JPG<br>67.08 KB</a><div class='inv'><br><a href='./images/20050708/IMG_3878.JPG' ALT='IMG_3878.JPG'>IMG_3878.JPG</a></div></td>
<td><A ID='IMG_3883.JPG' href='piecesofhistory.php?fileId=IMG_3883.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050708/IMG_3883.JPG' ALT='IMG_3883.JPG'><BR>IMG_3883.JPG<br>100.3 KB</a><div class='inv'><br><a href='./images/20050708/IMG_3883.JPG' ALT='IMG_3883.JPG'>IMG_3883.JPG</a></div></td>
<td><A ID='IMG_3885.JPG' href='piecesofhistory.php?fileId=IMG_3885.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050708/IMG_3885.JPG' ALT='IMG_3885.JPG'><BR>IMG_3885.JPG<br>67.47 KB</a><div class='inv'><br><a href='./images/20050708/IMG_3885.JPG' ALT='IMG_3885.JPG'>IMG_3885.JPG</a></div></td>
<td><A ID='IMG_3886.JPG' href='piecesofhistory.php?fileId=IMG_3886.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050708/IMG_3886.JPG' ALT='IMG_3886.JPG'><BR>IMG_3886.JPG<br>108.99 KB</a><div class='inv'><br><a href='./images/20050708/IMG_3886.JPG' ALT='IMG_3886.JPG'>IMG_3886.JPG</a></div></td>
<td><A ID='IMG_3887.JPG' href='piecesofhistory.php?fileId=IMG_3887.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050708/IMG_3887.JPG' ALT='IMG_3887.JPG'><BR>IMG_3887.JPG<br>76.95 KB</a><div class='inv'><br><a href='./images/20050708/IMG_3887.JPG' ALT='IMG_3887.JPG'>IMG_3887.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_3889.JPG' href='piecesofhistory.php?fileId=IMG_3889.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050708/IMG_3889.JPG' ALT='IMG_3889.JPG'><BR>IMG_3889.JPG<br>93.5 KB</a><div class='inv'><br><a href='./images/20050708/IMG_3889.JPG' ALT='IMG_3889.JPG'>IMG_3889.JPG</a></div></td>
<td><A ID='IMG_3891.JPG' href='piecesofhistory.php?fileId=IMG_3891.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050708/IMG_3891.JPG' ALT='IMG_3891.JPG'><BR>IMG_3891.JPG<br>107.1 KB</a><div class='inv'><br><a href='./images/20050708/IMG_3891.JPG' ALT='IMG_3891.JPG'>IMG_3891.JPG</a></div></td>
<td><A ID='IMG_3893.JPG' href='piecesofhistory.php?fileId=IMG_3893.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050708/IMG_3893.JPG' ALT='IMG_3893.JPG'><BR>IMG_3893.JPG<br>90.65 KB</a><div class='inv'><br><a href='./images/20050708/IMG_3893.JPG' ALT='IMG_3893.JPG'>IMG_3893.JPG</a></div></td>
<td><A ID='IMG_3894.JPG' href='piecesofhistory.php?fileId=IMG_3894.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050708/IMG_3894.JPG' ALT='IMG_3894.JPG'><BR>IMG_3894.JPG<br>83.69 KB</a><div class='inv'><br><a href='./images/20050708/IMG_3894.JPG' ALT='IMG_3894.JPG'>IMG_3894.JPG</a></div></td>
<td><A ID='IMG_3897.JPG' href='piecesofhistory.php?fileId=IMG_3897.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050708/IMG_3897.JPG' ALT='IMG_3897.JPG'><BR>IMG_3897.JPG<br>76.16 KB</a><div class='inv'><br><a href='./images/20050708/IMG_3897.JPG' ALT='IMG_3897.JPG'>IMG_3897.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_3901.JPG' href='piecesofhistory.php?fileId=IMG_3901.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050708/IMG_3901.JPG' ALT='IMG_3901.JPG'><BR>IMG_3901.JPG<br>60.88 KB</a><div class='inv'><br><a href='./images/20050708/IMG_3901.JPG' ALT='IMG_3901.JPG'>IMG_3901.JPG</a></div></td>
<td><A ID='IMG_3902.JPG' href='piecesofhistory.php?fileId=IMG_3902.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050708/IMG_3902.JPG' ALT='IMG_3902.JPG'><BR>IMG_3902.JPG<br>102.94 KB</a><div class='inv'><br><a href='./images/20050708/IMG_3902.JPG' ALT='IMG_3902.JPG'>IMG_3902.JPG</a></div></td>
<td><A ID='IMG_3903.JPG' href='piecesofhistory.php?fileId=IMG_3903.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050708/IMG_3903.JPG' ALT='IMG_3903.JPG'><BR>IMG_3903.JPG<br>92.02 KB</a><div class='inv'><br><a href='./images/20050708/IMG_3903.JPG' ALT='IMG_3903.JPG'>IMG_3903.JPG</a></div></td>
<td><A ID='IMG_3906.JPG' href='piecesofhistory.php?fileId=IMG_3906.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050708/IMG_3906.JPG' ALT='IMG_3906.JPG'><BR>IMG_3906.JPG<br>85.13 KB</a><div class='inv'><br><a href='./images/20050708/IMG_3906.JPG' ALT='IMG_3906.JPG'>IMG_3906.JPG</a></div></td>
<td><A ID='IMG_3907.JPG' href='piecesofhistory.php?fileId=IMG_3907.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050708/IMG_3907.JPG' ALT='IMG_3907.JPG'><BR>IMG_3907.JPG<br>106.64 KB</a><div class='inv'><br><a href='./images/20050708/IMG_3907.JPG' ALT='IMG_3907.JPG'>IMG_3907.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_3908.JPG' href='piecesofhistory.php?fileId=IMG_3908.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050708/IMG_3908.JPG' ALT='IMG_3908.JPG'><BR>IMG_3908.JPG<br>94.67 KB</a><div class='inv'><br><a href='./images/20050708/IMG_3908.JPG' ALT='IMG_3908.JPG'>IMG_3908.JPG</a></div></td>
<td><A ID='IMG_3909.JPG' href='piecesofhistory.php?fileId=IMG_3909.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050708/IMG_3909.JPG' ALT='IMG_3909.JPG'><BR>IMG_3909.JPG<br>91.26 KB</a><div class='inv'><br><a href='./images/20050708/IMG_3909.JPG' ALT='IMG_3909.JPG'>IMG_3909.JPG</a></div></td>
<td><A ID='IMG_3912.JPG' href='piecesofhistory.php?fileId=IMG_3912.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050708/IMG_3912.JPG' ALT='IMG_3912.JPG'><BR>IMG_3912.JPG<br>71.99 KB</a><div class='inv'><br><a href='./images/20050708/IMG_3912.JPG' ALT='IMG_3912.JPG'>IMG_3912.JPG</a></div></td>
<td><A ID='IMG_3921.JPG' href='piecesofhistory.php?fileId=IMG_3921.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050708/IMG_3921.JPG' ALT='IMG_3921.JPG'><BR>IMG_3921.JPG<br>54.32 KB</a><div class='inv'><br><a href='./images/20050708/IMG_3921.JPG' ALT='IMG_3921.JPG'>IMG_3921.JPG</a></div></td>
<td><A ID='IMG_3922.JPG' href='piecesofhistory.php?fileId=IMG_3922.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050708/IMG_3922.JPG' ALT='IMG_3922.JPG'><BR>IMG_3922.JPG<br>55.25 KB</a><div class='inv'><br><a href='./images/20050708/IMG_3922.JPG' ALT='IMG_3922.JPG'>IMG_3922.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_3923.JPG' href='piecesofhistory.php?fileId=IMG_3923.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050708/IMG_3923.JPG' ALT='IMG_3923.JPG'><BR>IMG_3923.JPG<br>117.75 KB</a><div class='inv'><br><a href='./images/20050708/IMG_3923.JPG' ALT='IMG_3923.JPG'>IMG_3923.JPG</a></div></td>
<td><A ID='IMG_3925.JPG' href='piecesofhistory.php?fileId=IMG_3925.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050708/IMG_3925.JPG' ALT='IMG_3925.JPG'><BR>IMG_3925.JPG<br>119.21 KB</a><div class='inv'><br><a href='./images/20050708/IMG_3925.JPG' ALT='IMG_3925.JPG'>IMG_3925.JPG</a></div></td>
<td><A ID='IMG_3926.JPG' href='piecesofhistory.php?fileId=IMG_3926.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050708/IMG_3926.JPG' ALT='IMG_3926.JPG'><BR>IMG_3926.JPG<br>72.83 KB</a><div class='inv'><br><a href='./images/20050708/IMG_3926.JPG' ALT='IMG_3926.JPG'>IMG_3926.JPG</a></div></td>
<td><A ID='IMG_3928.JPG' href='piecesofhistory.php?fileId=IMG_3928.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050708/IMG_3928.JPG' ALT='IMG_3928.JPG'><BR>IMG_3928.JPG<br>69.72 KB</a><div class='inv'><br><a href='./images/20050708/IMG_3928.JPG' ALT='IMG_3928.JPG'>IMG_3928.JPG</a></div></td>
<td><A ID='IMG_3929.JPG' href='piecesofhistory.php?fileId=IMG_3929.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050708/IMG_3929.JPG' ALT='IMG_3929.JPG'><BR>IMG_3929.JPG<br>101.17 KB</a><div class='inv'><br><a href='./images/20050708/IMG_3929.JPG' ALT='IMG_3929.JPG'>IMG_3929.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_3932.JPG' href='piecesofhistory.php?fileId=IMG_3932.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050708/IMG_3932.JPG' ALT='IMG_3932.JPG'><BR>IMG_3932.JPG<br>63.79 KB</a><div class='inv'><br><a href='./images/20050708/IMG_3932.JPG' ALT='IMG_3932.JPG'>IMG_3932.JPG</a></div></td>
<td><A ID='IMG_3934.JPG' href='piecesofhistory.php?fileId=IMG_3934.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050708/IMG_3934.JPG' ALT='IMG_3934.JPG'><BR>IMG_3934.JPG<br>71.66 KB</a><div class='inv'><br><a href='./images/20050708/IMG_3934.JPG' ALT='IMG_3934.JPG'>IMG_3934.JPG</a></div></td>
<td><A ID='IMG_3936.JPG' href='piecesofhistory.php?fileId=IMG_3936.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050708/IMG_3936.JPG' ALT='IMG_3936.JPG'><BR>IMG_3936.JPG<br>100.14 KB</a><div class='inv'><br><a href='./images/20050708/IMG_3936.JPG' ALT='IMG_3936.JPG'>IMG_3936.JPG</a></div></td>
<td><A ID='IMG_3952.JPG' href='piecesofhistory.php?fileId=IMG_3952.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050708/IMG_3952.JPG' ALT='IMG_3952.JPG'><BR>IMG_3952.JPG<br>27.16 KB</a><div class='inv'><br><a href='./images/20050708/IMG_3952.JPG' ALT='IMG_3952.JPG'>IMG_3952.JPG</a></div></td>
<td><A ID='IMG_3959.JPG' href='piecesofhistory.php?fileId=IMG_3959.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050708/IMG_3959.JPG' ALT='IMG_3959.JPG'><BR>IMG_3959.JPG<br>132.94 KB</a><div class='inv'><br><a href='./images/20050708/IMG_3959.JPG' ALT='IMG_3959.JPG'>IMG_3959.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_3960.JPG' href='piecesofhistory.php?fileId=IMG_3960.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050708/IMG_3960.JPG' ALT='IMG_3960.JPG'><BR>IMG_3960.JPG<br>84.26 KB</a><div class='inv'><br><a href='./images/20050708/IMG_3960.JPG' ALT='IMG_3960.JPG'>IMG_3960.JPG</a></div></td>
<td><A ID='IMG_3961.JPG' href='piecesofhistory.php?fileId=IMG_3961.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050708/IMG_3961.JPG' ALT='IMG_3961.JPG'><BR>IMG_3961.JPG<br>111.13 KB</a><div class='inv'><br><a href='./images/20050708/IMG_3961.JPG' ALT='IMG_3961.JPG'>IMG_3961.JPG</a></div></td>
<td><A ID='IMG_3964.JPG' href='piecesofhistory.php?fileId=IMG_3964.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050708/IMG_3964.JPG' ALT='IMG_3964.JPG'><BR>IMG_3964.JPG<br>124.69 KB</a><div class='inv'><br><a href='./images/20050708/IMG_3964.JPG' ALT='IMG_3964.JPG'>IMG_3964.JPG</a></div></td>
<td><A ID='IMG_3966.JPG' href='piecesofhistory.php?fileId=IMG_3966.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050708/IMG_3966.JPG' ALT='IMG_3966.JPG'><BR>IMG_3966.JPG<br>67.67 KB</a><div class='inv'><br><a href='./images/20050708/IMG_3966.JPG' ALT='IMG_3966.JPG'>IMG_3966.JPG</a></div></td>
<td><A ID='IMG_3967.JPG' href='piecesofhistory.php?fileId=IMG_3967.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050708/IMG_3967.JPG' ALT='IMG_3967.JPG'><BR>IMG_3967.JPG<br>80.08 KB</a><div class='inv'><br><a href='./images/20050708/IMG_3967.JPG' ALT='IMG_3967.JPG'>IMG_3967.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_3968.JPG' href='piecesofhistory.php?fileId=IMG_3968.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050708/IMG_3968.JPG' ALT='IMG_3968.JPG'><BR>IMG_3968.JPG<br>53.6 KB</a><div class='inv'><br><a href='./images/20050708/IMG_3968.JPG' ALT='IMG_3968.JPG'>IMG_3968.JPG</a></div></td>
<td><A ID='IMG_3971.JPG' href='piecesofhistory.php?fileId=IMG_3971.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050708/IMG_3971.JPG' ALT='IMG_3971.JPG'><BR>IMG_3971.JPG<br>53.14 KB</a><div class='inv'><br><a href='./images/20050708/IMG_3971.JPG' ALT='IMG_3971.JPG'>IMG_3971.JPG</a></div></td>
<td><A ID='IMG_3976.JPG' href='piecesofhistory.php?fileId=IMG_3976.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050708/IMG_3976.JPG' ALT='IMG_3976.JPG'><BR>IMG_3976.JPG<br>66.45 KB</a><div class='inv'><br><a href='./images/20050708/IMG_3976.JPG' ALT='IMG_3976.JPG'>IMG_3976.JPG</a></div></td>
<td><A ID='IMG_3979.JPG' href='piecesofhistory.php?fileId=IMG_3979.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050708/IMG_3979.JPG' ALT='IMG_3979.JPG'><BR>IMG_3979.JPG<br>54.17 KB</a><div class='inv'><br><a href='./images/20050708/IMG_3979.JPG' ALT='IMG_3979.JPG'>IMG_3979.JPG</a></div></td>
<td><A ID='IMG_3990.JPG' href='piecesofhistory.php?fileId=IMG_3990.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050708/IMG_3990.JPG' ALT='IMG_3990.JPG'><BR>IMG_3990.JPG<br>55.83 KB</a><div class='inv'><br><a href='./images/20050708/IMG_3990.JPG' ALT='IMG_3990.JPG'>IMG_3990.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_3991.JPG' href='piecesofhistory.php?fileId=IMG_3991.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050708/IMG_3991.JPG' ALT='IMG_3991.JPG'><BR>IMG_3991.JPG<br>61.86 KB</a><div class='inv'><br><a href='./images/20050708/IMG_3991.JPG' ALT='IMG_3991.JPG'>IMG_3991.JPG</a></div></td>
<td><A ID='IMG_3997.JPG' href='piecesofhistory.php?fileId=IMG_3997.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050708/IMG_3997.JPG' ALT='IMG_3997.JPG'><BR>IMG_3997.JPG<br>49.74 KB</a><div class='inv'><br><a href='./images/20050708/IMG_3997.JPG' ALT='IMG_3997.JPG'>IMG_3997.JPG</a></div></td>
<td><A ID='IMG_4008.JPG' href='piecesofhistory.php?fileId=IMG_4008.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050708/IMG_4008.JPG' ALT='IMG_4008.JPG'><BR>IMG_4008.JPG<br>49 KB</a><div class='inv'><br><a href='./images/20050708/IMG_4008.JPG' ALT='IMG_4008.JPG'>IMG_4008.JPG</a></div></td>
<td><A ID='IMG_4012.JPG' href='piecesofhistory.php?fileId=IMG_4012.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050708/IMG_4012.JPG' ALT='IMG_4012.JPG'><BR>IMG_4012.JPG<br>54.36 KB</a><div class='inv'><br><a href='./images/20050708/IMG_4012.JPG' ALT='IMG_4012.JPG'>IMG_4012.JPG</a></div></td>
<td><A ID='IMG_4013.JPG' href='piecesofhistory.php?fileId=IMG_4013.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050708/IMG_4013.JPG' ALT='IMG_4013.JPG'><BR>IMG_4013.JPG<br>79.63 KB</a><div class='inv'><br><a href='./images/20050708/IMG_4013.JPG' ALT='IMG_4013.JPG'>IMG_4013.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_4015.JPG' href='piecesofhistory.php?fileId=IMG_4015.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050708/IMG_4015.JPG' ALT='IMG_4015.JPG'><BR>IMG_4015.JPG<br>60.29 KB</a><div class='inv'><br><a href='./images/20050708/IMG_4015.JPG' ALT='IMG_4015.JPG'>IMG_4015.JPG</a></div></td>
<td><A ID='IMG_4016.JPG' href='piecesofhistory.php?fileId=IMG_4016.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050708/IMG_4016.JPG' ALT='IMG_4016.JPG'><BR>IMG_4016.JPG<br>57.69 KB</a><div class='inv'><br><a href='./images/20050708/IMG_4016.JPG' ALT='IMG_4016.JPG'>IMG_4016.JPG</a></div></td>
<td><A ID='IMG_4017.JPG' href='piecesofhistory.php?fileId=IMG_4017.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050708/IMG_4017.JPG' ALT='IMG_4017.JPG'><BR>IMG_4017.JPG<br>85.39 KB</a><div class='inv'><br><a href='./images/20050708/IMG_4017.JPG' ALT='IMG_4017.JPG'>IMG_4017.JPG</a></div></td>
<td><A ID='IMG_4019.JPG' href='piecesofhistory.php?fileId=IMG_4019.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050708/IMG_4019.JPG' ALT='IMG_4019.JPG'><BR>IMG_4019.JPG<br>72.74 KB</a><div class='inv'><br><a href='./images/20050708/IMG_4019.JPG' ALT='IMG_4019.JPG'>IMG_4019.JPG</a></div></td>
<td><A ID='IMG_4023.JPG' href='piecesofhistory.php?fileId=IMG_4023.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050708/IMG_4023.JPG' ALT='IMG_4023.JPG'><BR>IMG_4023.JPG<br>91.4 KB</a><div class='inv'><br><a href='./images/20050708/IMG_4023.JPG' ALT='IMG_4023.JPG'>IMG_4023.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_4024.JPG' href='piecesofhistory.php?fileId=IMG_4024.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050708/IMG_4024.JPG' ALT='IMG_4024.JPG'><BR>IMG_4024.JPG<br>107.94 KB</a><div class='inv'><br><a href='./images/20050708/IMG_4024.JPG' ALT='IMG_4024.JPG'>IMG_4024.JPG</a></div></td>
<td><A ID='IMG_4026.JPG' href='piecesofhistory.php?fileId=IMG_4026.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050708/IMG_4026.JPG' ALT='IMG_4026.JPG'><BR>IMG_4026.JPG<br>63.33 KB</a><div class='inv'><br><a href='./images/20050708/IMG_4026.JPG' ALT='IMG_4026.JPG'>IMG_4026.JPG</a></div></td>
<td><A ID='IMG_4027.JPG' href='piecesofhistory.php?fileId=IMG_4027.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050708/IMG_4027.JPG' ALT='IMG_4027.JPG'><BR>IMG_4027.JPG<br>66.23 KB</a><div class='inv'><br><a href='./images/20050708/IMG_4027.JPG' ALT='IMG_4027.JPG'>IMG_4027.JPG</a></div></td>
<td><A ID='IMG_4028.JPG' href='piecesofhistory.php?fileId=IMG_4028.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050708/IMG_4028.JPG' ALT='IMG_4028.JPG'><BR>IMG_4028.JPG<br>74.9 KB</a><div class='inv'><br><a href='./images/20050708/IMG_4028.JPG' ALT='IMG_4028.JPG'>IMG_4028.JPG</a></div></td>
<td><A ID='IMG_4029.JPG' href='piecesofhistory.php?fileId=IMG_4029.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050708/IMG_4029.JPG' ALT='IMG_4029.JPG'><BR>IMG_4029.JPG<br>64 KB</a><div class='inv'><br><a href='./images/20050708/IMG_4029.JPG' ALT='IMG_4029.JPG'>IMG_4029.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_4032.JPG' href='piecesofhistory.php?fileId=IMG_4032.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050708/IMG_4032.JPG' ALT='IMG_4032.JPG'><BR>IMG_4032.JPG<br>63.8 KB</a><div class='inv'><br><a href='./images/20050708/IMG_4032.JPG' ALT='IMG_4032.JPG'>IMG_4032.JPG</a></div></td>
<td><A ID='IMG_4033.JPG' href='piecesofhistory.php?fileId=IMG_4033.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050708/IMG_4033.JPG' ALT='IMG_4033.JPG'><BR>IMG_4033.JPG<br>54.14 KB</a><div class='inv'><br><a href='./images/20050708/IMG_4033.JPG' ALT='IMG_4033.JPG'>IMG_4033.JPG</a></div></td>
<td><A ID='IMG_4035.JPG' href='piecesofhistory.php?fileId=IMG_4035.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050708/IMG_4035.JPG' ALT='IMG_4035.JPG'><BR>IMG_4035.JPG<br>74.05 KB</a><div class='inv'><br><a href='./images/20050708/IMG_4035.JPG' ALT='IMG_4035.JPG'>IMG_4035.JPG</a></div></td>
<td><A ID='IMG_4036.JPG' href='piecesofhistory.php?fileId=IMG_4036.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050708/IMG_4036.JPG' ALT='IMG_4036.JPG'><BR>IMG_4036.JPG<br>64.57 KB</a><div class='inv'><br><a href='./images/20050708/IMG_4036.JPG' ALT='IMG_4036.JPG'>IMG_4036.JPG</a></div></td>
<td><A ID='IMG_4038.JPG' href='piecesofhistory.php?fileId=IMG_4038.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050708/IMG_4038.JPG' ALT='IMG_4038.JPG'><BR>IMG_4038.JPG<br>41.86 KB</a><div class='inv'><br><a href='./images/20050708/IMG_4038.JPG' ALT='IMG_4038.JPG'>IMG_4038.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_4040.JPG' href='piecesofhistory.php?fileId=IMG_4040.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050708/IMG_4040.JPG' ALT='IMG_4040.JPG'><BR>IMG_4040.JPG<br>52.7 KB</a><div class='inv'><br><a href='./images/20050708/IMG_4040.JPG' ALT='IMG_4040.JPG'>IMG_4040.JPG</a></div></td>
<td><A ID='IMG_4042.JPG' href='piecesofhistory.php?fileId=IMG_4042.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050708/IMG_4042.JPG' ALT='IMG_4042.JPG'><BR>IMG_4042.JPG<br>77.22 KB</a><div class='inv'><br><a href='./images/20050708/IMG_4042.JPG' ALT='IMG_4042.JPG'>IMG_4042.JPG</a></div></td>
<td><A ID='IMG_4044.JPG' href='piecesofhistory.php?fileId=IMG_4044.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050708/IMG_4044.JPG' ALT='IMG_4044.JPG'><BR>IMG_4044.JPG<br>76.73 KB</a><div class='inv'><br><a href='./images/20050708/IMG_4044.JPG' ALT='IMG_4044.JPG'>IMG_4044.JPG</a></div></td>
<td><A ID='IMG_4046.JPG' href='piecesofhistory.php?fileId=IMG_4046.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050708/IMG_4046.JPG' ALT='IMG_4046.JPG'><BR>IMG_4046.JPG<br>52.94 KB</a><div class='inv'><br><a href='./images/20050708/IMG_4046.JPG' ALT='IMG_4046.JPG'>IMG_4046.JPG</a></div></td>
<td><A ID='IMG_4050.JPG' href='piecesofhistory.php?fileId=IMG_4050.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050708/IMG_4050.JPG' ALT='IMG_4050.JPG'><BR>IMG_4050.JPG<br>61.24 KB</a><div class='inv'><br><a href='./images/20050708/IMG_4050.JPG' ALT='IMG_4050.JPG'>IMG_4050.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_4053.JPG' href='piecesofhistory.php?fileId=IMG_4053.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050708/IMG_4053.JPG' ALT='IMG_4053.JPG'><BR>IMG_4053.JPG<br>55.26 KB</a><div class='inv'><br><a href='./images/20050708/IMG_4053.JPG' ALT='IMG_4053.JPG'>IMG_4053.JPG</a></div></td>
<td><A ID='IMG_4058.JPG' href='piecesofhistory.php?fileId=IMG_4058.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050708/IMG_4058.JPG' ALT='IMG_4058.JPG'><BR>IMG_4058.JPG<br>76.97 KB</a><div class='inv'><br><a href='./images/20050708/IMG_4058.JPG' ALT='IMG_4058.JPG'>IMG_4058.JPG</a></div></td>
<td><A ID='IMG_4064.JPG' href='piecesofhistory.php?fileId=IMG_4064.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050708/IMG_4064.JPG' ALT='IMG_4064.JPG'><BR>IMG_4064.JPG<br>71.03 KB</a><div class='inv'><br><a href='./images/20050708/IMG_4064.JPG' ALT='IMG_4064.JPG'>IMG_4064.JPG</a></div></td>
<td><A ID='IMG_4065.JPG' href='piecesofhistory.php?fileId=IMG_4065.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050708/IMG_4065.JPG' ALT='IMG_4065.JPG'><BR>IMG_4065.JPG<br>54.67 KB</a><div class='inv'><br><a href='./images/20050708/IMG_4065.JPG' ALT='IMG_4065.JPG'>IMG_4065.JPG</a></div></td>
<td><A ID='IMG_4068.JPG' href='piecesofhistory.php?fileId=IMG_4068.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050708/IMG_4068.JPG' ALT='IMG_4068.JPG'><BR>IMG_4068.JPG<br>59 KB</a><div class='inv'><br><a href='./images/20050708/IMG_4068.JPG' ALT='IMG_4068.JPG'>IMG_4068.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_4071.JPG' href='piecesofhistory.php?fileId=IMG_4071.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050708/IMG_4071.JPG' ALT='IMG_4071.JPG'><BR>IMG_4071.JPG<br>59.88 KB</a><div class='inv'><br><a href='./images/20050708/IMG_4071.JPG' ALT='IMG_4071.JPG'>IMG_4071.JPG</a></div></td>
<td><A ID='IMG_4073.JPG' href='piecesofhistory.php?fileId=IMG_4073.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050708/IMG_4073.JPG' ALT='IMG_4073.JPG'><BR>IMG_4073.JPG<br>79.69 KB</a><div class='inv'><br><a href='./images/20050708/IMG_4073.JPG' ALT='IMG_4073.JPG'>IMG_4073.JPG</a></div></td>
<td><A ID='IMG_4074.JPG' href='piecesofhistory.php?fileId=IMG_4074.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050708/IMG_4074.JPG' ALT='IMG_4074.JPG'><BR>IMG_4074.JPG<br>55.83 KB</a><div class='inv'><br><a href='./images/20050708/IMG_4074.JPG' ALT='IMG_4074.JPG'>IMG_4074.JPG</a></div></td>
<td><A ID='IMG_4076.JPG' href='piecesofhistory.php?fileId=IMG_4076.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050708/IMG_4076.JPG' ALT='IMG_4076.JPG'><BR>IMG_4076.JPG<br>63.23 KB</a><div class='inv'><br><a href='./images/20050708/IMG_4076.JPG' ALT='IMG_4076.JPG'>IMG_4076.JPG</a></div></td>
<td><A ID='IMG_4083.JPG' href='piecesofhistory.php?fileId=IMG_4083.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050708/IMG_4083.JPG' ALT='IMG_4083.JPG'><BR>IMG_4083.JPG<br>53.15 KB</a><div class='inv'><br><a href='./images/20050708/IMG_4083.JPG' ALT='IMG_4083.JPG'>IMG_4083.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_4085.JPG' href='piecesofhistory.php?fileId=IMG_4085.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050708/IMG_4085.JPG' ALT='IMG_4085.JPG'><BR>IMG_4085.JPG<br>48.55 KB</a><div class='inv'><br><a href='./images/20050708/IMG_4085.JPG' ALT='IMG_4085.JPG'>IMG_4085.JPG</a></div></td>
<td><A ID='IMG_4086.JPG' href='piecesofhistory.php?fileId=IMG_4086.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050708/IMG_4086.JPG' ALT='IMG_4086.JPG'><BR>IMG_4086.JPG<br>66.69 KB</a><div class='inv'><br><a href='./images/20050708/IMG_4086.JPG' ALT='IMG_4086.JPG'>IMG_4086.JPG</a></div></td>
<td><A ID='IMG_4090.JPG' href='piecesofhistory.php?fileId=IMG_4090.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050708/IMG_4090.JPG' ALT='IMG_4090.JPG'><BR>IMG_4090.JPG<br>74.31 KB</a><div class='inv'><br><a href='./images/20050708/IMG_4090.JPG' ALT='IMG_4090.JPG'>IMG_4090.JPG</a></div></td>
<td><A ID='IMG_4093.JPG' href='piecesofhistory.php?fileId=IMG_4093.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050708/IMG_4093.JPG' ALT='IMG_4093.JPG'><BR>IMG_4093.JPG<br>63.33 KB</a><div class='inv'><br><a href='./images/20050708/IMG_4093.JPG' ALT='IMG_4093.JPG'>IMG_4093.JPG</a></div></td>
<td><A ID='IMG_4096.JPG' href='piecesofhistory.php?fileId=IMG_4096.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050708/IMG_4096.JPG' ALT='IMG_4096.JPG'><BR>IMG_4096.JPG<br>57.4 KB</a><div class='inv'><br><a href='./images/20050708/IMG_4096.JPG' ALT='IMG_4096.JPG'>IMG_4096.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_4101.JPG' href='piecesofhistory.php?fileId=IMG_4101.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050708/IMG_4101.JPG' ALT='IMG_4101.JPG'><BR>IMG_4101.JPG<br>50.19 KB</a><div class='inv'><br><a href='./images/20050708/IMG_4101.JPG' ALT='IMG_4101.JPG'>IMG_4101.JPG</a></div></td>
<td><A ID='IMG_4106.JPG' href='?fileId=IMG_4106.JPG'><img src='./images/20050708/TN_IMG_4106.JPG' ALT='IMG_4106.JPG'><BR>IMG_4106.JPG<br>42.98 KB</a></td>
<td><A ID='IMG_4106_1975.JPG' href='?fileId=IMG_4106_1975.JPG'><img src='./images/20050708/TN_IMG_4106_1975.JPG' ALT='IMG_4106_1975.JPG'><BR>IMG_4106_1975.JPG<br>30.95 KB</a></td>
</tr>
</table>	</div>
</div>
</body>
</html>