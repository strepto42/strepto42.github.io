<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - May 2007 - Q&A letters</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="Q&A letters">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="Q&A letters" href='masterit200701.php'>January 2007</a></li>
<li><a title="Q&A letters" href='masterit200702.php'>February 2007</a></li>
<li><a title="Q&A letters" href='masterit200703.php'>March 2007</a></li>
<li><a title="Q&A letters" href='masterit200704.php'>April 2007</a></li>
<li><div class='activemenu'>May 2007</div></li>
<li><a title="Q&A letters" href='masterit200706.php'>June 2007</a></li>
<li><a title="Q&A letters" href='masterit200707.php'>July 2007</a></li>
<li> </li><br><li>Or go back to:</li><li><a title='Q&A letters from 2007' href="masterit2007.php">2007 archive</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>May 2007</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Mark's writing' href="written.php">Professional Writing</a> > <a title='My weekly Q&A column in The Australian' href="masterIT.php">MasterIT</a> > <a title='Q&A letters from 2007' href="masterit2007.php">2007 archive</a> > <a title='Q&A letters' href="masterit200705.php">May 2007</a>
<br><br>		<br>
<h2>8/5/07</h2><br>
<b>I have an older Nomad Jukebox Zen. When I tried to use it with my shiny new copy of Vista, I discovered that a firmware update was needed. I followed the links on Creative's website, but when I ran the firmware updater it froze half way through. Now my jukebox doesn't work correctly; it only goes into diagnostic mode. Not Happy Jan!</b><br>
<br>
You're not alone - this is a known issue.<br>
<br>
Creative have always suffered from a peculiar problem. Their hardware is excellent, but their driver and software department appears to be staffed with large, hairy proto-humanoids who type with two fingers.<br>
<br>
Your particular problem is caused by the fact that Creative's firmware updater doesn't work with Windows Media Player 11 - the version that is built into Vista.<br>
<br>
When I say "doesn't work", I actually mean "will effectively break the player".<br>
<br>
To fix the issue and make your player work again, you'll need access to a PC running Windows XP and WMP 10 (or lower).<br>
<br>
If the only XP computer around has Media Player 11 on it, you should be able to uninstall it to fix your player, and then reinstall it again afterwards.<br>
<br>
Once you have WMP10 going, your basic steps to reviving the player are:<br>
<br>
1. Unplug your player and uninstall any Creative Zen drivers.<br>
2. Reinstall the Zen drivers from the creative website and reboot.<br>
3. Plug in the jukebox.<br>
4. On the Zen, select "Reload OS". As soon as "Reload new firmware now via USB" flashes up, start the firmware update.<br>
<br>
With a bit of luck this should get you back in business. Once the new firmware is installed, you can reinstall WMP11 if you like.<br>
<br>
There's a lengthy discussion of the issue at tinyurl.com/yoh53q.<br>
<br>
<br>
<b>How easy is it to make a USB key bootable? I'd like to put DOS on it, but Windows won't let me format it that way.</b><br>
<br>
It's quite easy, and there are a few ways to do it. You'll need a third party utility in most cases, because, as you've discovered, Windows doesn't let you do it directly.<br>
<br>
One set of instructions can be found at tinyurl.com/7xtdj. Another good link is to an HP utility, which apparently works with a variety of keys. You can find this download at tinyurl.com/kaytz.<br>
<br>
Once you've made your flash drive bootable, you'll may also need to set up the computer's BIOS to allow it to boot from USB devices.<br>
<br>
Instructions for doing this vary according to you particular motherboard, so you'll need to refer to your manual (RTFM).<br>
<br>
<br>
<h2>15/5/07</h2><br>
<b>I keep getting this error every time I receive/install a Microsoft Windows update.  It seems to be related to registry errors. How can I go about fixing this, and would you recommend using registry cleaners such as RegCure or RegistryFix?</b><br>
<br>
The problem appears to be related to the Windows Update service - but not specifically to registry errors.<br>
<br>
Luckily, it appears to be a known problem. Microsoft have an article on the subject here.<br>
<br>
http://support.microsoft.com/kb/916089<br>
<br>
Apparently the problem often appears after installing a particular Windows update, and that to fix it you have to install a hotfix, which you can find here:<br>
<br>
http://support.microsoft.com/kb/927891<br>
<br>
On the subject of registry cleaners, as I said a few weeks ago - I wouldn't bother.<br>
<br>
There are many options out there, but they can sometimes cause more problems than they fix, simply because the registry is such a complicated beastie, and a program really needs to know what it's doing to be effective and not cause damage.<br>
<br>
<br>
<b>I have a problem with Internet Explorer 7. Previously, I would left click on a heading to open a link to further pages. This no longer works, and I now have to right click on the heading and then left click on "open" in the box to access further pages. It is not the site as this problem does not arise when using Mozilla Firefox, or another computer using Internet Explorer 7. It would be appreciated if you could advise me as how to solve this minor but annoying problem.</b><br>
<br>
There are a few things you can try. First up, if you have any third party add-ons for IE, try removing them. This includes things like the Yahoo/Google toolbar, etc.<br>
<br>
Next, download AdAware or Prevx (both easy to find with Google) and run a spyware check on your system.<br>
<br>
If that still doesn't help, you might have a problem with the default Windows action when it comes to URL links. Have a look at the instructions on this page:<br>
<br>
http://www.fjsmjs.com/OE/nolinks.htm<br>
<br>
If all else fails, check the "file and folder" settings in the control panel. If it's set to "single click" to open folders, perhaps change it to double click. This probably won't help, but it's worth a try.<br>
<br>
<br>
<h2>29/5/07</h2><br>
<b>One of my hard drives was generating intermittent errors in the Windows system event log when I tried to write to it. Now it seems to be fine, and I'm not sure what happened. It is a few years old - should I be looking at replacing it?</b><br>
<br>
Given that it's an old drive, I'd say it is quite reasonable to look at replacing it. Most consumer drives are only designed to last a few years, and when a hard drive starts to misbehave like this, it's a kindly warning that disaster may be in the works.<br>
<br>
The good news is that new hard drives are super cheap. Grab yourself a replacement, and use a program like Acronis Trueimage or Ghost to replicate your existing drive onto the new one.<br>
<br>
Now you can format (wipe) the old drive and use it as a scratch disk for data you don't care about too much. For example, you can put your Windows swapfile on it, or your collection of Viagra-spam.<br>
<br>
That way, if it continues to kick on for a while you can still make use of it, but if it does fail then it's no big deal.<br>
<br>
<br>
<h2>It is my understanding that Optical Character Recognition (OCR) involves a computer program representing analogue text and images, usually captured by a scanner, into files (in an editable digital format). Here comes the question: Are you aware of the existence of a program that would do OCR not on analogue data, but on data contained in a digital file like the example below?</h2><br>
<br>
*X*X**Y*Y*<br>
**X****Y**<br>
*X*X***Y**<br>
<br>
All of the commercial OCR software out there is designed to recognise text within images, which are basically collections of pixels (or dots) of course. The text-characters you included are essentially the same thing, but in a different format.<br>
<br>
So, there's no reason why a program to perform OCR from a text file couldn't exist, but there's almost certainly no demand for one.<br>
<br>
I've done a bit of net scouring, but unfortunately I can't turn up any applications that work with text like that. After all, the "O" in OCR does stand for Optical, and I guess what you're after is a pretty specialised application.<br>
<br>
If any readers know of a solution, feel free to email me and I'll pass the information on.<br>
<br>
<i><p>Did the information on this page help you? Entertain you? Bore you? <a href="contact.php?subject=MasterIT">Drop me a line</a>.</p>

<p>If you're feeling particularly generous, you can even <a href="buypics.php">click here to send me some dot-com riches</a>. Think of it as online busking.</i></p>
	</div>
</div>
</body>
</html>