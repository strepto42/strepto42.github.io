<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - June 2006 - Q&A letters</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="Q&A letters">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="Q&A letters" href='masterit200601.php'>January 2006</a></li>
<li><a title="Q&A letters" href='masterit200602.php'>February 2006</a></li>
<li><a title="Q&A letters" href='masterit200603.php'>March 2006</a></li>
<li><a title="Q&A letters" href='masterit200604.php'>April 2006</a></li>
<li><a title="Q&A letters" href='masterit200605.php'>May 2006</a></li>
<li><div class='activemenu'>June 2006</div></li>
<li><a title="Q&A letters" href='masterit200607.php'>July 2006</a></li>
<li><a title="Q&A letters" href='masterit200608.php'>August 2006</a></li>
<li><a title="Q&A letters" href='masterit200609.php'>September 2006</a></li>
<li><a title="Q&A letters" href='masterit200610.php'>October 2006</a></li>
<li><a title="Q&A letters" href='masterit200611.php'>November 2006</a></li>
<li><a title="Q&A letters" href='masterit200612.php'>December 2006</a></li>
<li> </li><br><li>Or go back to:</li><li><a title='Q&A/MasterIT letters from 2006' href="masterit2006.php">2006 archive</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>June 2006</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Mark's writing' href="written.php">Professional Writing</a> > <a title='My weekly Q&A column in The Australian' href="masterIT.php">MasterIT</a> > <a title='Q&A/MasterIT letters from 2006' href="masterit2006.php">2006 archive</a> > <a title='Q&A letters' href="masterit200606.php">June 2006</a>
<br><br>		<br>
<h2>6/6/06</h2><br>
<b>My ISP has just upgraded me from ADSL to ADSL2+. Apparently, this can give me speeds of up to 24000, but I'm only getting about 6000. Whilst this is a big improvement from 512, I'm wondering if there's anything I can do to improve the situation.</b><br>
<br>
The magic marketing words here are "up to". In reality, you'd have to live next door to the exchange to get close to the top potential speed of ADSL2+.<br>
<br>
The speed you get is basically a product of line attenuation (how much signal gets lost between your modem and the exchange), and this in turn is a direct product of how simply long the wire is. The longer it is, the slower the speed. The quality of the line (and any joins in it) will also effect your speed.<br>
<br>
While the above factors are pretty much out of your control, not all ADLS modems are created equal, so you may be able to squeeze a little more out of your connection by changing brands (at a cost of course).<br>
<br>
If you want to lose yourself in endless discussions on the above, check out the Whirlpool forums at http://forums.whirlpool.net.au.<br>
<br>
<br>
<b>I've been using Bluetooth for some time to synchronise my mobile phone's contact list with Outlook on my laptop. The phone also came with one of those fancy little Bluetooth headsets, and it works a treat. It's got me wondering though - can I use the headset with the computer? I can get it to recognise it, but I can't seem to find the option to get it to connect as an audio device. It'd be really handy for things like Skype.</b><br>
<br>
Bluetooth headsets will indeed work as wireless audio devices in Windows, but not with the Microsoft-supplied drivers.<br>
<br>
What you basically need to do is uninstall the Microsoft Bluetooth "stack" (basically a fancy word for a set of drivers), and install the third party driver that came with your laptop. In most cases, this driver is provided by Widcomm.<br>
<br>
Rather than go into the gory details here, I'll refer you to this article - http://tinyurl.com/buzyl - where all the hard work has been done for me.<br>
<br>
The article is specific to a certain headset, but the same concepts will work for any compatible device. You'll need to refer to your own headset's documentation as to how to make it "discoverable"; typically this involves something as complex as holding down the button on it for a few seconds.<br>
<br>
Once you're up and running, you can use the device from within any windows application that supports standard sound drivers, including MSN, Skype and other VOIP Phone software.<br>
<br>
<br>
<h2>13/6/06</h2><br>
<b>A few people have recommended Mozilla (Firefox) to me now. It's certainly impressive, but I can't find out how to match IE's ability to seek confirmation before accepting cookies - I never accept them unless I absolutely need them (as one does for eBay and other sites). Does Moz have this facility?</b><br>
<br>
It doesn't; in the privacy options, under cookies, you can specify whether to accept cookies in general, or only from the originating site. You can also block or always accept cookies on a site-wide basis, but there isn't an option to query each and every one.<br>
<br>
All is not lost though; Firefox itself lacks the functionality, but an excellent extension for managing cookies exists which does in fact have the option you seek. You can download it from https://addons.mozilla.org/firefox/2497.<br>
<br>
The thing to bear in mind though, is that cookies are almost always a good thing. They're somewhat maligned, and there's this feeling amongst some people that they have some sinister purpose, and can deliver your valuable data into the clutches of nefarious corporations and seedy hackers.<br>
<br>
In reality, the poor old cookie is just piece of data that a website wants your browser to remember. Mostly, it wants this so that it can read the data back again in order to keep track of who you are in a crowd of users. When many people are viewing a website at the same time, cookies let the server "remember" your particular session in between page loads; like for example when you're filling out a multi-page form.<br>
<br>
Without cookies, doing this sort of thing becomes quite messy and fiddly (from a programmer's point of view), and it poses certain security risks (and in some cases it makes certain tasks completely impossible, which is why some sites like Ebay require that they be enabled).<br>
<br>
So, accepting cookies is generally a good idea, rather than a bad one. Some advertising sites do use them to track you as an individual user, but they can't tell much about you, and if you block cookies that don't originate from the site you're viewing, you pretty much prevent this from being an issue at all.<br>
<br>
There is of course the privacy issue of someone sitting at you PC and looking through your cookies, but Windows is full of revealing lists like this, and cookies are just the tip of the iceberg.<br>
<br>
Perhaps cookies would gain more acceptance if Australian software localised their name to "bikkies". After all, it's hard to turn down a nice bikkie.<br>
<br>
<br>
<h2>20/6/06</h2><br>
<b>I'm looking at satellite broadband, as, living out in the bush, it's pretty much the only option available. I've gotten a bit confused about the speed it offers though; some reading I've done suggests it will be no faster than dial-up. In particular, what exactly are people going on about when they talk about 'latency'?</b><br>
<br>
It's easy to get confused about how "fast" a type of connection is these days, because there are big steaming piles of marketing everywhere, put there by the vendors to make their service sound better than everyone else's.<br>
<br>
A network's latency is a measure of how long it takes a signal to do a round trip from your computer to any arbitrary computer on that network. When talking about the latency of a given Internet connection type, the measure we care about is between your computer and the ISP.<br>
<br>
Typical response times for dialup are around 150-300ms (roughly 1/6th of a second at best, give or take a bit). DSL connections have a typical latency of maybe 15-20ms, a lot faster.<br>
<br>
The problem with satellite Internet is that the signal has to travel a long way. Even at the speed of light, travelling 36000kms (the distance to a geosynchronous satellite) takes about a quarter of a second, and there's nothing that can be done to shorten this delay, short of moving to the Star Trek universe and picking up a subspace radio at Scotty's garage sale.<br>
<br>
If you take into account random overheads and the fact that the signal has to travel the distance twice (there and back again), there will always be the best part of a second between your click and the remote computer's response when you're on satellite.<br>
<br>
Of course, once the actual data starts flowing, it flows quickly. Just how quickly depends on your ISP, but ADSL-like speeds are pretty typical.<br>
<br>
One way to help cut the latency, as well as simplifying equipment requirements, is to use a dialup account or ISDN line for outgoing traffic, and only use the satellite for downloads. This is also cheaper to implement. Telstra offer all three options, for a price of course.<br>
<br>
The bottom line: satellite can be quite fast, but it will always be "laggy", making it completely unsuitable for games, and somewhat painful for other real-time applications (like using terminal sessions on remote computers).<br>
<br>
<br>
<h2>27/6/06</h2><br>
<b>I had the misfortune to "catch" a dose of spyware that nearly took over my computer, despite having Norton 2006 and Microsoft anti-spyware installed. In desperation I did a Google search and came up with BraveSentry for which I paid $30+ for 6 months to download. It did the job and removed the spyware quick smart. Now when I do a check on Microsoft Antispyware, it tells me that BraveSentry is a threat! Is that just Microsoft looking after its own, or is there a problem with BraveSentry?</b><br>
<br>
Unfortunately, it looks like you've been had. Microsoft are actually right (for once!).<br>
<br>
Bravesentry seems to be a program which doesn't do much good at all, and in fact does it's best to swindle you into buying it. See http://tinyurl.com/opulq for more info.<br>
<br>
My own personal anti-spyware package of choice is Lavasoft Adaware, the basic version of which is free and can be grabbed at http://lavasoft.de.<br>
<br>
<br>
<b>I was scanning my laptop with AVG anti virus. Suddenly a message popped up saying virus found. After scanning a little while my laptop turned off by itself and ever since I am not able to run my computer. When I plug in the adaptor in to the power point it failed to supply any power. Would you please suggest what is the remedy for this sort of trouble.</b><br>
<br>
It sounds like you have two separate problems. One is that you have a virus, and the other is that your laptop may have a broken power supply. These two things are completely unrelated, though probably equally irritating.<br>
<br>
For the former problem, a good scan and clean with an up-to-date AVG should remove the virus. For the latter, you'll have to contact the vendor of the laptop to see if they can supply you with a new AC adaptor.<br>
<br>
<br>
<b>I use XP pro, and the Windows search function seems to be broken. From the start button, I put in, say, *. Dbf and nothing happens. When I look in Windows task manager (applications screen) the search has stopped responding.</b><br>
<br>
You might have a problem with the indexing service that's built in to XP. This is a program that runs on in the background and speeds up searches by building an index of the files on your drive. Unfortunately if this gets corrupted it can break the search functionality.<br>
<br>
To disable it, right click on My Computer, and select "manage". Then open up "Services and applications", and right click on "Indexing Service". Now click "stop", and then try a search.<br>
<br>
<i><p>Did the information on this page help you? Entertain you? Bore you? <a href="contact.php?subject=MasterIT">Drop me a line</a>.</p>

<p>If you're feeling particularly generous, you can even <a href="buypics.php">click here to send me some dot-com riches</a>. Think of it as online busking.</i></p>
	</div>
</div>
</body>
</html>