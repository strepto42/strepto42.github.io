<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - 2/9/2005 - Legacies of War</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="Legacies of War">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="Greetings from a Bum" href='greetingsfromabum.php'>29/4/2005</a></li>
<li><a title="Onward" href='onward.php'>2/5/2005</a></li>
<li><a title="It's a tough life (pt 1: Bundaberg, Agnes Water and 1770)" href='itsatoughlife1.php'>17/5/2005</a></li>
<li><a title="It's a tough life (pt 2: Rockhampton, Emu Park and Great Keppel Island)" href='itsatoughlife2.php'>23/5/2005</a></li>
<li><a title="There and Back Again - a Yo-yo's Tale" href='thereandbackagain.php'>18/6/2005</a></li>
<li><a title="Platypi and Grey Nomads" href='platypiandgreynomads.php'>24/6/2005</a></li>
<li><a title="Blowing Bubbles in a Watery Tomb" href='blowingbubbles.php'>1/7/2005</a></li>
<li><a title="Pieces of History" href='piecesofhistory.php'>8/7/2005</a></li>
<li><a title="Walks and Waterfalls" href='walksandwaterfalls.php'>15/7/2005</a></li>
<li><a title="Mission to Tribulation" href='missiontotribulation.php'>22/7/2005</a></li>
<li><a title="Levity, Limestone and Lava" href='levitylimestoneandlava.php'>29/7/2005</a></li>
<li><a title="Into the Never Never" href='intothenevernever.php'>5/8/2005</a></li>
<li><a title="Slowing the pace in Darwin" href='slowingthepaceindarwin.php'>12/8/2005</a></li>
<li><a title="Blistering Barnacles and Leaping Lizards" href='leapinglizards.php'>19/8/2005</a></li>
<li><a title="Kakadu and Litchfield" href='kakadu.php'>26/8/2005</a></li>
<li><div class='activemenu'>2/9/2005</div></li>
<li><a title="Go West" href='gowest.php'>10/9/2005</a></li>
<li><a title="Things from Above" href='thingsfromabove.php'>16/9/2005</a></li>
<li><a title="The West Coast" href='thewestcoast.php'>23/9/2005</a></li>
<li><a title="Reefs and Red Dust" href='reefsandreddust.php'>30/9/2005</a></li>
<li><a title="The Pilbara" href='pilbara.php'>7/10/2005</a></li>
<li><a title="Paradise with a Headwind" href='paradisewithaheadwind.php'>14/10/2005</a></li>
<li><a title="Down the Coral Coast" href='downthecoralcoast.php'>21/10/2005</a></li>
<li><a title="Pinnacles and Pinnipeds" href='pinnaclesandpinnipeds.php'>28/10/2005</a></li>
<li><a title="A week in Perth" href='perth.php'>4/11/2005</a></li>
<li><a title="The Southwest (from Above and Below)" href='thesouthwest.php'>11/11/2005</a></li>
<li><a title="More Heights and Depths" href='moreheightsanddepths.php'>18/11/2005</a></li>
<li><a title="Across the Nullarbor (and a bit beyond)" href='nullarbor.php'>25/11/2005</a></li>
<li><a title="Double Whammy" href='doublewhammy.php'>9/12/2005</a></li>
<li><a title="Two Cities" href='twocities.php'>19/12/2005</a></li>
<li><a title="Tassie - Part 1" href='tassie1.php'>1/1/2006</a></li>
<li><a title="Tassie - Part 2" href='tassie2.php'>7/1/2006</a></li>
<li><a title="Full Circle" href='fullcircle.php'>26/1/2006</a></li>
<li><a title="The Wrap Up" href='thewrapup.php'>23/3/2006</a></li>
<li> </li><br><li>Or go back to:</li><li><a title='Travelouges and blogs from my trip around Australia' href="nerdseyeview.php">Nerd's Eye View</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>2/9/2005</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Travel stories and pictures' href="travel.php">Travelogues</a> > <a title='Travelouges and blogs from my trip around Australia' href="nerdseyeview.php">Nerd's Eye View</a> > <a title='Legacies of War' href="legaciesofwar.php">2/9/2005</a>
<br><br>		


<h1>Legacies of War</h1>

<!-- <a href="images/maps/Map050826.gif"><img src="images/maps/Map050826_sm.gif" align="right"></a> -->

<p>Hi all, greetings once again from the top end. I've not yet left Darwin, but the time is drawing near.</p>

<p>Basically I've had a fairly quiet week, especially compared to the previous couple! So this might well be one of the shortest updates I send round. After last week's monster though, perhaps it sort of balances out.</p>

<p>Anyway, I spent the first few days relaxing at Justine and Harley's place again. I have to say, they've been bloody fantastic, putting me up like they have, and for as long as they have. Guys, I can't thank you enough. I know I probably stayed a little longer than expected, so cheers!</p>

<p>But yes, I was starting to push my luck a little (we were all starting to refer to the spare room where I was staying as "Mark's room") so I've moved to a local hostel for the last few days up here. The hostel is quite nice, and relaxed, and even has a salt water pool. I've also met a fellow with whom I played guitar in Mt Isa, so of course the music has been happening again.</p>

<p>As far as activities go, Justine, Harley and I headed off to the local outdoor cinema on Sunday night. It's called the Deckchair cinema. Kiwi accent jokes have of course been duly made. :)</p>

<p>They do a good feed down there, and you sit back and relax on big deckchair type things with a glass of wine. We saw a German film called Downfall, about the last days of Hitler and the people around him. It was excellent, although a little dark of course (lots of people shoot themselves and so on).</p>

<p>I've spent most of the rest of the time relaxing, tweaking my website, and getting little chores done, like reattaching my number plate to the bike rack (it was cracking and looking like flying off at some stage), and getting the soles of my brand new hiking boots stuck back on, as they randomly fell off. All very exciting stuff.</p>

<p>On Wednesday night I tracked down a local Taekwondo school and they were kind enough to let me train with them. So I finally got to do some proper training.</p>

<p>Thankfully, I haven't forgotten too much, although my body didn't want to keep up with my brain, and I'm still sore. I'm looking forward to some healthy pain when I get back. :) </p>

<p>Apart from that, I've been ticking off the last few touristy things of interest up here. Yesterday I went for a ride down to the wharf for a nice fish and chip lunch, and to check out the 70 million dollar rich bugger boat that is moored there currently. It is very shiny and white. There were even minions scrubbing the already-spotless deck.</p>

<p>On the way back I stopped off at the WWII Oil Tunnels to have a sticky beak. These are big underground tanks that were dug out of the hill, with the intension of storing oil and fuel there, as the Japanese were bombing the outdoor tanks.</p>

<p>As fate would have it, the war ended just as they were completed, and they also subsequently filled up with groundwater during the wet season, so they were never actually used. Closed until recently, they're now opened up again, and there are some interesting old wartime photos on display there.</p>

<p>To be honest, I thought they would probably be a bit lame, so I had put off visiting, but in reality they are larger than I imagined, and actually quite atmospheric. I kept expecting to see Gordon Freeman with crowbar in hand to step out of the shadows.</p>

<p>The other batch of photos came from a visit today to the Australian Aviation Heritage Centre. As the sign says, they have one of the only two B52 bombers on display outside the US, as well as countless other planes and lots of interesting stuff.</p>

<p>The B52 dwarfs everything else there; they're damn massive, but have virtually no passenger space, being essentially one big fuel tank with a bomb bay.</p>

<p>So that's it for my week's adventures. And, pretty much, for Darwin and the NT. By next week I'll be in WA. Thanks again to the Whittingtons, and thanks as usual to those people who've been in touch.</p>

<p>Happy snaps for this week are:</p>
<!-- 
<ul>
<li><a href="?fileId=IMG_8120.JPG">One very shiny boat</a></li>
<li><a href="?fileId=IMG_8144.JPG">Oil tunnel, now gallery</a></li>
<li><a href="?fileId=IMG_8212.JPG">An empty rocket pod</a></li>
<li><a href="?fileId=IMG_8262.JPG">One Big Plane, with cute vintage portable stairs</a></li>
<li><a href="?fileId=IMG_8275.JPG">Cheerful looking headgear</a></li>
</ul>
 -->
<table width="800">
	<tr>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=IMG_8120.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20050902/IMG_8120.JPG' ALT='One very shiny boat'><BR>One very shiny boat</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=IMG_8144.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20050902/IMG_8144.JPG' ALT='Oil tunnel, now gallery'><BR>Oil tunnel, now gallery</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=IMG_8212.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20050902/IMG_8212.JPG' ALT='An empty rocket pod'><BR>An empty rocket pod</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=IMG_8262.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20050902/IMG_8262.JPG' ALT='One Big Plane, with cute vintage portable stairs'><BR>One Big Plane, with cute vintage portable stairs</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=IMG_8275.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20050902/IMG_8275.JPG' ALT='Cheerful-looking headgear'><BR>Cheerful-looking headgear</a>
	</td>
	</tr>
</table>


<br><br>
All images in this gallery:<br>
<table width='800'>
<tr>
</tr>
<tr><td><A ID='IMG_8065.JPG' href='legaciesofwar.php?fileId=IMG_8065.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050902/IMG_8065.JPG' ALT='IMG_8065.JPG'><BR>IMG_8065.JPG<br>65.84 KB</a><div class='inv'><br><a href='./images/20050902/IMG_8065.JPG' ALT='IMG_8065.JPG'>IMG_8065.JPG</a></div></td>
<td><A ID='IMG_8066.JPG' href='legaciesofwar.php?fileId=IMG_8066.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050902/IMG_8066.JPG' ALT='IMG_8066.JPG'><BR>IMG_8066.JPG<br>100.37 KB</a><div class='inv'><br><a href='./images/20050902/IMG_8066.JPG' ALT='IMG_8066.JPG'>IMG_8066.JPG</a></div></td>
<td><A ID='IMG_8070.JPG' href='legaciesofwar.php?fileId=IMG_8070.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050902/IMG_8070.JPG' ALT='IMG_8070.JPG'><BR>IMG_8070.JPG<br>51.13 KB</a><div class='inv'><br><a href='./images/20050902/IMG_8070.JPG' ALT='IMG_8070.JPG'>IMG_8070.JPG</a></div></td>
<td><A ID='IMG_8110.JPG' href='legaciesofwar.php?fileId=IMG_8110.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050902/IMG_8110.JPG' ALT='IMG_8110.JPG'><BR>IMG_8110.JPG<br>89.6 KB</a><div class='inv'><br><a href='./images/20050902/IMG_8110.JPG' ALT='IMG_8110.JPG'>IMG_8110.JPG</a></div></td>
<td><A ID='IMG_8113.JPG' href='legaciesofwar.php?fileId=IMG_8113.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050902/IMG_8113.JPG' ALT='IMG_8113.JPG'><BR>IMG_8113.JPG<br>62.5 KB</a><div class='inv'><br><a href='./images/20050902/IMG_8113.JPG' ALT='IMG_8113.JPG'>IMG_8113.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_8116.JPG' href='legaciesofwar.php?fileId=IMG_8116.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050902/IMG_8116.JPG' ALT='IMG_8116.JPG'><BR>IMG_8116.JPG<br>28.38 KB</a><div class='inv'><br><a href='./images/20050902/IMG_8116.JPG' ALT='IMG_8116.JPG'>IMG_8116.JPG</a></div></td>
<td><A ID='IMG_8117.JPG' href='legaciesofwar.php?fileId=IMG_8117.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050902/IMG_8117.JPG' ALT='IMG_8117.JPG'><BR>IMG_8117.JPG<br>60.2 KB</a><div class='inv'><br><a href='./images/20050902/IMG_8117.JPG' ALT='IMG_8117.JPG'>IMG_8117.JPG</a></div></td>
<td><A ID='IMG_8120.JPG' href='legaciesofwar.php?fileId=IMG_8120.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050902/IMG_8120.JPG' ALT='IMG_8120.JPG'><BR>IMG_8120.JPG<br>44.29 KB</a><div class='inv'><br><a href='./images/20050902/IMG_8120.JPG' ALT='IMG_8120.JPG'>IMG_8120.JPG</a></div></td>
<td><A ID='IMG_8121.JPG' href='legaciesofwar.php?fileId=IMG_8121.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050902/IMG_8121.JPG' ALT='IMG_8121.JPG'><BR>IMG_8121.JPG<br>49.04 KB</a><div class='inv'><br><a href='./images/20050902/IMG_8121.JPG' ALT='IMG_8121.JPG'>IMG_8121.JPG</a></div></td>
<td><A ID='IMG_8129.JPG' href='legaciesofwar.php?fileId=IMG_8129.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050902/IMG_8129.JPG' ALT='IMG_8129.JPG'><BR>IMG_8129.JPG<br>56.71 KB</a><div class='inv'><br><a href='./images/20050902/IMG_8129.JPG' ALT='IMG_8129.JPG'>IMG_8129.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_8136.JPG' href='legaciesofwar.php?fileId=IMG_8136.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050902/IMG_8136.JPG' ALT='IMG_8136.JPG'><BR>IMG_8136.JPG<br>89.67 KB</a><div class='inv'><br><a href='./images/20050902/IMG_8136.JPG' ALT='IMG_8136.JPG'>IMG_8136.JPG</a></div></td>
<td><A ID='IMG_8139.JPG' href='legaciesofwar.php?fileId=IMG_8139.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050902/IMG_8139.JPG' ALT='IMG_8139.JPG'><BR>IMG_8139.JPG<br>58.26 KB</a><div class='inv'><br><a href='./images/20050902/IMG_8139.JPG' ALT='IMG_8139.JPG'>IMG_8139.JPG</a></div></td>
<td><A ID='IMG_8142.JPG' href='legaciesofwar.php?fileId=IMG_8142.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050902/IMG_8142.JPG' ALT='IMG_8142.JPG'><BR>IMG_8142.JPG<br>61.72 KB</a><div class='inv'><br><a href='./images/20050902/IMG_8142.JPG' ALT='IMG_8142.JPG'>IMG_8142.JPG</a></div></td>
<td><A ID='IMG_8144.JPG' href='legaciesofwar.php?fileId=IMG_8144.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050902/IMG_8144.JPG' ALT='IMG_8144.JPG'><BR>IMG_8144.JPG<br>58.23 KB</a><div class='inv'><br><a href='./images/20050902/IMG_8144.JPG' ALT='IMG_8144.JPG'>IMG_8144.JPG</a></div></td>
<td><A ID='IMG_8145.JPG' href='legaciesofwar.php?fileId=IMG_8145.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050902/IMG_8145.JPG' ALT='IMG_8145.JPG'><BR>IMG_8145.JPG<br>57.79 KB</a><div class='inv'><br><a href='./images/20050902/IMG_8145.JPG' ALT='IMG_8145.JPG'>IMG_8145.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_8153.JPG' href='legaciesofwar.php?fileId=IMG_8153.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050902/IMG_8153.JPG' ALT='IMG_8153.JPG'><BR>IMG_8153.JPG<br>47.73 KB</a><div class='inv'><br><a href='./images/20050902/IMG_8153.JPG' ALT='IMG_8153.JPG'>IMG_8153.JPG</a></div></td>
<td><A ID='IMG_8176.JPG' href='legaciesofwar.php?fileId=IMG_8176.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050902/IMG_8176.JPG' ALT='IMG_8176.JPG'><BR>IMG_8176.JPG<br>64.59 KB</a><div class='inv'><br><a href='./images/20050902/IMG_8176.JPG' ALT='IMG_8176.JPG'>IMG_8176.JPG</a></div></td>
<td><A ID='IMG_8179.JPG' href='legaciesofwar.php?fileId=IMG_8179.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050902/IMG_8179.JPG' ALT='IMG_8179.JPG'><BR>IMG_8179.JPG<br>54.91 KB</a><div class='inv'><br><a href='./images/20050902/IMG_8179.JPG' ALT='IMG_8179.JPG'>IMG_8179.JPG</a></div></td>
<td><A ID='IMG_8181.JPG' href='legaciesofwar.php?fileId=IMG_8181.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050902/IMG_8181.JPG' ALT='IMG_8181.JPG'><BR>IMG_8181.JPG<br>38.72 KB</a><div class='inv'><br><a href='./images/20050902/IMG_8181.JPG' ALT='IMG_8181.JPG'>IMG_8181.JPG</a></div></td>
<td><A ID='IMG_8186.JPG' href='legaciesofwar.php?fileId=IMG_8186.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050902/IMG_8186.JPG' ALT='IMG_8186.JPG'><BR>IMG_8186.JPG<br>39.55 KB</a><div class='inv'><br><a href='./images/20050902/IMG_8186.JPG' ALT='IMG_8186.JPG'>IMG_8186.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_8187.JPG' href='legaciesofwar.php?fileId=IMG_8187.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050902/IMG_8187.JPG' ALT='IMG_8187.JPG'><BR>IMG_8187.JPG<br>59.47 KB</a><div class='inv'><br><a href='./images/20050902/IMG_8187.JPG' ALT='IMG_8187.JPG'>IMG_8187.JPG</a></div></td>
<td><A ID='IMG_8194.JPG' href='legaciesofwar.php?fileId=IMG_8194.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050902/IMG_8194.JPG' ALT='IMG_8194.JPG'><BR>IMG_8194.JPG<br>108.14 KB</a><div class='inv'><br><a href='./images/20050902/IMG_8194.JPG' ALT='IMG_8194.JPG'>IMG_8194.JPG</a></div></td>
<td><A ID='IMG_8195.JPG' href='legaciesofwar.php?fileId=IMG_8195.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050902/IMG_8195.JPG' ALT='IMG_8195.JPG'><BR>IMG_8195.JPG<br>77.24 KB</a><div class='inv'><br><a href='./images/20050902/IMG_8195.JPG' ALT='IMG_8195.JPG'>IMG_8195.JPG</a></div></td>
<td><A ID='IMG_8196.JPG' href='legaciesofwar.php?fileId=IMG_8196.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050902/IMG_8196.JPG' ALT='IMG_8196.JPG'><BR>IMG_8196.JPG<br>81.56 KB</a><div class='inv'><br><a href='./images/20050902/IMG_8196.JPG' ALT='IMG_8196.JPG'>IMG_8196.JPG</a></div></td>
<td><A ID='IMG_8197.JPG' href='legaciesofwar.php?fileId=IMG_8197.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050902/IMG_8197.JPG' ALT='IMG_8197.JPG'><BR>IMG_8197.JPG<br>45.44 KB</a><div class='inv'><br><a href='./images/20050902/IMG_8197.JPG' ALT='IMG_8197.JPG'>IMG_8197.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_8199.JPG' href='legaciesofwar.php?fileId=IMG_8199.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050902/IMG_8199.JPG' ALT='IMG_8199.JPG'><BR>IMG_8199.JPG<br>62.73 KB</a><div class='inv'><br><a href='./images/20050902/IMG_8199.JPG' ALT='IMG_8199.JPG'>IMG_8199.JPG</a></div></td>
<td><A ID='IMG_8200.JPG' href='legaciesofwar.php?fileId=IMG_8200.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050902/IMG_8200.JPG' ALT='IMG_8200.JPG'><BR>IMG_8200.JPG<br>67.44 KB</a><div class='inv'><br><a href='./images/20050902/IMG_8200.JPG' ALT='IMG_8200.JPG'>IMG_8200.JPG</a></div></td>
<td><A ID='IMG_8202.JPG' href='legaciesofwar.php?fileId=IMG_8202.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050902/IMG_8202.JPG' ALT='IMG_8202.JPG'><BR>IMG_8202.JPG<br>66.93 KB</a><div class='inv'><br><a href='./images/20050902/IMG_8202.JPG' ALT='IMG_8202.JPG'>IMG_8202.JPG</a></div></td>
<td><A ID='IMG_8206.JPG' href='legaciesofwar.php?fileId=IMG_8206.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050902/IMG_8206.JPG' ALT='IMG_8206.JPG'><BR>IMG_8206.JPG<br>55.89 KB</a><div class='inv'><br><a href='./images/20050902/IMG_8206.JPG' ALT='IMG_8206.JPG'>IMG_8206.JPG</a></div></td>
<td><A ID='IMG_8212.JPG' href='legaciesofwar.php?fileId=IMG_8212.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050902/IMG_8212.JPG' ALT='IMG_8212.JPG'><BR>IMG_8212.JPG<br>64.71 KB</a><div class='inv'><br><a href='./images/20050902/IMG_8212.JPG' ALT='IMG_8212.JPG'>IMG_8212.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_8214.JPG' href='legaciesofwar.php?fileId=IMG_8214.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050902/IMG_8214.JPG' ALT='IMG_8214.JPG'><BR>IMG_8214.JPG<br>47.88 KB</a><div class='inv'><br><a href='./images/20050902/IMG_8214.JPG' ALT='IMG_8214.JPG'>IMG_8214.JPG</a></div></td>
<td><A ID='IMG_8216.JPG' href='legaciesofwar.php?fileId=IMG_8216.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050902/IMG_8216.JPG' ALT='IMG_8216.JPG'><BR>IMG_8216.JPG<br>68.19 KB</a><div class='inv'><br><a href='./images/20050902/IMG_8216.JPG' ALT='IMG_8216.JPG'>IMG_8216.JPG</a></div></td>
<td><A ID='IMG_8218.JPG' href='legaciesofwar.php?fileId=IMG_8218.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050902/IMG_8218.JPG' ALT='IMG_8218.JPG'><BR>IMG_8218.JPG<br>64.03 KB</a><div class='inv'><br><a href='./images/20050902/IMG_8218.JPG' ALT='IMG_8218.JPG'>IMG_8218.JPG</a></div></td>
<td><A ID='IMG_8219.JPG' href='legaciesofwar.php?fileId=IMG_8219.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050902/IMG_8219.JPG' ALT='IMG_8219.JPG'><BR>IMG_8219.JPG<br>92.03 KB</a><div class='inv'><br><a href='./images/20050902/IMG_8219.JPG' ALT='IMG_8219.JPG'>IMG_8219.JPG</a></div></td>
<td><A ID='IMG_8220.JPG' href='legaciesofwar.php?fileId=IMG_8220.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050902/IMG_8220.JPG' ALT='IMG_8220.JPG'><BR>IMG_8220.JPG<br>78.47 KB</a><div class='inv'><br><a href='./images/20050902/IMG_8220.JPG' ALT='IMG_8220.JPG'>IMG_8220.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_8221.JPG' href='legaciesofwar.php?fileId=IMG_8221.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050902/IMG_8221.JPG' ALT='IMG_8221.JPG'><BR>IMG_8221.JPG<br>83.17 KB</a><div class='inv'><br><a href='./images/20050902/IMG_8221.JPG' ALT='IMG_8221.JPG'>IMG_8221.JPG</a></div></td>
<td><A ID='IMG_8223.JPG' href='legaciesofwar.php?fileId=IMG_8223.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050902/IMG_8223.JPG' ALT='IMG_8223.JPG'><BR>IMG_8223.JPG<br>78.06 KB</a><div class='inv'><br><a href='./images/20050902/IMG_8223.JPG' ALT='IMG_8223.JPG'>IMG_8223.JPG</a></div></td>
<td><A ID='IMG_8225.JPG' href='legaciesofwar.php?fileId=IMG_8225.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050902/IMG_8225.JPG' ALT='IMG_8225.JPG'><BR>IMG_8225.JPG<br>80.37 KB</a><div class='inv'><br><a href='./images/20050902/IMG_8225.JPG' ALT='IMG_8225.JPG'>IMG_8225.JPG</a></div></td>
<td><A ID='IMG_8227.JPG' href='legaciesofwar.php?fileId=IMG_8227.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050902/IMG_8227.JPG' ALT='IMG_8227.JPG'><BR>IMG_8227.JPG<br>55.3 KB</a><div class='inv'><br><a href='./images/20050902/IMG_8227.JPG' ALT='IMG_8227.JPG'>IMG_8227.JPG</a></div></td>
<td><A ID='IMG_8228.JPG' href='legaciesofwar.php?fileId=IMG_8228.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050902/IMG_8228.JPG' ALT='IMG_8228.JPG'><BR>IMG_8228.JPG<br>87.49 KB</a><div class='inv'><br><a href='./images/20050902/IMG_8228.JPG' ALT='IMG_8228.JPG'>IMG_8228.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_8229.JPG' href='legaciesofwar.php?fileId=IMG_8229.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050902/IMG_8229.JPG' ALT='IMG_8229.JPG'><BR>IMG_8229.JPG<br>63.48 KB</a><div class='inv'><br><a href='./images/20050902/IMG_8229.JPG' ALT='IMG_8229.JPG'>IMG_8229.JPG</a></div></td>
<td><A ID='IMG_8231.JPG' href='legaciesofwar.php?fileId=IMG_8231.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050902/IMG_8231.JPG' ALT='IMG_8231.JPG'><BR>IMG_8231.JPG<br>75.94 KB</a><div class='inv'><br><a href='./images/20050902/IMG_8231.JPG' ALT='IMG_8231.JPG'>IMG_8231.JPG</a></div></td>
<td><A ID='IMG_8233.JPG' href='legaciesofwar.php?fileId=IMG_8233.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050902/IMG_8233.JPG' ALT='IMG_8233.JPG'><BR>IMG_8233.JPG<br>41.66 KB</a><div class='inv'><br><a href='./images/20050902/IMG_8233.JPG' ALT='IMG_8233.JPG'>IMG_8233.JPG</a></div></td>
<td><A ID='IMG_8234.JPG' href='legaciesofwar.php?fileId=IMG_8234.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050902/IMG_8234.JPG' ALT='IMG_8234.JPG'><BR>IMG_8234.JPG<br>78.7 KB</a><div class='inv'><br><a href='./images/20050902/IMG_8234.JPG' ALT='IMG_8234.JPG'>IMG_8234.JPG</a></div></td>
<td><A ID='IMG_8236.JPG' href='legaciesofwar.php?fileId=IMG_8236.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050902/IMG_8236.JPG' ALT='IMG_8236.JPG'><BR>IMG_8236.JPG<br>86.4 KB</a><div class='inv'><br><a href='./images/20050902/IMG_8236.JPG' ALT='IMG_8236.JPG'>IMG_8236.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_8238.JPG' href='legaciesofwar.php?fileId=IMG_8238.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050902/IMG_8238.JPG' ALT='IMG_8238.JPG'><BR>IMG_8238.JPG<br>59.59 KB</a><div class='inv'><br><a href='./images/20050902/IMG_8238.JPG' ALT='IMG_8238.JPG'>IMG_8238.JPG</a></div></td>
<td><A ID='IMG_8239.JPG' href='legaciesofwar.php?fileId=IMG_8239.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050902/IMG_8239.JPG' ALT='IMG_8239.JPG'><BR>IMG_8239.JPG<br>72.86 KB</a><div class='inv'><br><a href='./images/20050902/IMG_8239.JPG' ALT='IMG_8239.JPG'>IMG_8239.JPG</a></div></td>
<td><A ID='IMG_8240.JPG' href='legaciesofwar.php?fileId=IMG_8240.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050902/IMG_8240.JPG' ALT='IMG_8240.JPG'><BR>IMG_8240.JPG<br>52.67 KB</a><div class='inv'><br><a href='./images/20050902/IMG_8240.JPG' ALT='IMG_8240.JPG'>IMG_8240.JPG</a></div></td>
<td><A ID='IMG_8241.JPG' href='legaciesofwar.php?fileId=IMG_8241.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050902/IMG_8241.JPG' ALT='IMG_8241.JPG'><BR>IMG_8241.JPG<br>80.38 KB</a><div class='inv'><br><a href='./images/20050902/IMG_8241.JPG' ALT='IMG_8241.JPG'>IMG_8241.JPG</a></div></td>
<td><A ID='IMG_8243.JPG' href='legaciesofwar.php?fileId=IMG_8243.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050902/IMG_8243.JPG' ALT='IMG_8243.JPG'><BR>IMG_8243.JPG<br>92.67 KB</a><div class='inv'><br><a href='./images/20050902/IMG_8243.JPG' ALT='IMG_8243.JPG'>IMG_8243.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_8244.JPG' href='legaciesofwar.php?fileId=IMG_8244.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050902/IMG_8244.JPG' ALT='IMG_8244.JPG'><BR>IMG_8244.JPG<br>83.21 KB</a><div class='inv'><br><a href='./images/20050902/IMG_8244.JPG' ALT='IMG_8244.JPG'>IMG_8244.JPG</a></div></td>
<td><A ID='IMG_8245.JPG' href='legaciesofwar.php?fileId=IMG_8245.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050902/IMG_8245.JPG' ALT='IMG_8245.JPG'><BR>IMG_8245.JPG<br>80.16 KB</a><div class='inv'><br><a href='./images/20050902/IMG_8245.JPG' ALT='IMG_8245.JPG'>IMG_8245.JPG</a></div></td>
<td><A ID='IMG_8250.JPG' href='legaciesofwar.php?fileId=IMG_8250.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050902/IMG_8250.JPG' ALT='IMG_8250.JPG'><BR>IMG_8250.JPG<br>68.2 KB</a><div class='inv'><br><a href='./images/20050902/IMG_8250.JPG' ALT='IMG_8250.JPG'>IMG_8250.JPG</a></div></td>
<td><A ID='IMG_8253.JPG' href='legaciesofwar.php?fileId=IMG_8253.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050902/IMG_8253.JPG' ALT='IMG_8253.JPG'><BR>IMG_8253.JPG<br>66.1 KB</a><div class='inv'><br><a href='./images/20050902/IMG_8253.JPG' ALT='IMG_8253.JPG'>IMG_8253.JPG</a></div></td>
<td><A ID='IMG_8262.JPG' href='legaciesofwar.php?fileId=IMG_8262.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050902/IMG_8262.JPG' ALT='IMG_8262.JPG'><BR>IMG_8262.JPG<br>84.14 KB</a><div class='inv'><br><a href='./images/20050902/IMG_8262.JPG' ALT='IMG_8262.JPG'>IMG_8262.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_8263.JPG' href='legaciesofwar.php?fileId=IMG_8263.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050902/IMG_8263.JPG' ALT='IMG_8263.JPG'><BR>IMG_8263.JPG<br>77.46 KB</a><div class='inv'><br><a href='./images/20050902/IMG_8263.JPG' ALT='IMG_8263.JPG'>IMG_8263.JPG</a></div></td>
<td><A ID='IMG_8265.JPG' href='legaciesofwar.php?fileId=IMG_8265.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050902/IMG_8265.JPG' ALT='IMG_8265.JPG'><BR>IMG_8265.JPG<br>75.62 KB</a><div class='inv'><br><a href='./images/20050902/IMG_8265.JPG' ALT='IMG_8265.JPG'>IMG_8265.JPG</a></div></td>
<td><A ID='IMG_8266.JPG' href='legaciesofwar.php?fileId=IMG_8266.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050902/IMG_8266.JPG' ALT='IMG_8266.JPG'><BR>IMG_8266.JPG<br>94.32 KB</a><div class='inv'><br><a href='./images/20050902/IMG_8266.JPG' ALT='IMG_8266.JPG'>IMG_8266.JPG</a></div></td>
<td><A ID='IMG_8268.JPG' href='legaciesofwar.php?fileId=IMG_8268.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050902/IMG_8268.JPG' ALT='IMG_8268.JPG'><BR>IMG_8268.JPG<br>72.75 KB</a><div class='inv'><br><a href='./images/20050902/IMG_8268.JPG' ALT='IMG_8268.JPG'>IMG_8268.JPG</a></div></td>
<td><A ID='IMG_8270.JPG' href='legaciesofwar.php?fileId=IMG_8270.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050902/IMG_8270.JPG' ALT='IMG_8270.JPG'><BR>IMG_8270.JPG<br>76.15 KB</a><div class='inv'><br><a href='./images/20050902/IMG_8270.JPG' ALT='IMG_8270.JPG'>IMG_8270.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_8272.JPG' href='legaciesofwar.php?fileId=IMG_8272.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050902/IMG_8272.JPG' ALT='IMG_8272.JPG'><BR>IMG_8272.JPG<br>57.38 KB</a><div class='inv'><br><a href='./images/20050902/IMG_8272.JPG' ALT='IMG_8272.JPG'>IMG_8272.JPG</a></div></td>
<td><A ID='IMG_8273.JPG' href='legaciesofwar.php?fileId=IMG_8273.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050902/IMG_8273.JPG' ALT='IMG_8273.JPG'><BR>IMG_8273.JPG<br>55.23 KB</a><div class='inv'><br><a href='./images/20050902/IMG_8273.JPG' ALT='IMG_8273.JPG'>IMG_8273.JPG</a></div></td>
<td><A ID='IMG_8275.JPG' href='legaciesofwar.php?fileId=IMG_8275.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050902/IMG_8275.JPG' ALT='IMG_8275.JPG'><BR>IMG_8275.JPG<br>57.87 KB</a><div class='inv'><br><a href='./images/20050902/IMG_8275.JPG' ALT='IMG_8275.JPG'>IMG_8275.JPG</a></div></td>
<td><A ID='IMG_8276.JPG' href='legaciesofwar.php?fileId=IMG_8276.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050902/IMG_8276.JPG' ALT='IMG_8276.JPG'><BR>IMG_8276.JPG<br>81.66 KB</a><div class='inv'><br><a href='./images/20050902/IMG_8276.JPG' ALT='IMG_8276.JPG'>IMG_8276.JPG</a></div></td>
<td><A ID='IMG_8278.JPG' href='legaciesofwar.php?fileId=IMG_8278.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050902/IMG_8278.JPG' ALT='IMG_8278.JPG'><BR>IMG_8278.JPG<br>102.12 KB</a><div class='inv'><br><a href='./images/20050902/IMG_8278.JPG' ALT='IMG_8278.JPG'>IMG_8278.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_8279.JPG' href='legaciesofwar.php?fileId=IMG_8279.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050902/IMG_8279.JPG' ALT='IMG_8279.JPG'><BR>IMG_8279.JPG<br>60.22 KB</a><div class='inv'><br><a href='./images/20050902/IMG_8279.JPG' ALT='IMG_8279.JPG'>IMG_8279.JPG</a></div></td>
<td><A ID='IMG_8281.JPG' href='legaciesofwar.php?fileId=IMG_8281.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050902/IMG_8281.JPG' ALT='IMG_8281.JPG'><BR>IMG_8281.JPG<br>75.36 KB</a><div class='inv'><br><a href='./images/20050902/IMG_8281.JPG' ALT='IMG_8281.JPG'>IMG_8281.JPG</a></div></td>
<td><A ID='IMG_8285.JPG' href='legaciesofwar.php?fileId=IMG_8285.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050902/IMG_8285.JPG' ALT='IMG_8285.JPG'><BR>IMG_8285.JPG<br>60.29 KB</a><div class='inv'><br><a href='./images/20050902/IMG_8285.JPG' ALT='IMG_8285.JPG'>IMG_8285.JPG</a></div></td>
</tr>
</table>	</div>
</div>
</body>
</html>