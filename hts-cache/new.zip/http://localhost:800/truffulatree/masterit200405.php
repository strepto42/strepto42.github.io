<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - May 2004 - Q&A letters</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="Q&A letters">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="Q&A letters" href='masterit200401.php'>January 2004</a></li>
<li><a title="Q&A letters" href='masterit200402.php'>February 2004</a></li>
<li><a title="Q&A letters" href='masterit200403.php'>March 2004</a></li>
<li><a title="Q&A letters" href='masterit200404.php'>April 2004</a></li>
<li><div class='activemenu'>May 2004</div></li>
<li><a title="Q&A letters" href='masterit200406.php'>June 2004</a></li>
<li><a title="Q&A letters" href='masterit200407.php'>July 2004</a></li>
<li><a title="Q&A letters" href='masterit200408.php'>August 2004</a></li>
<li><a title="Q&A letters" href='masterit200409.php'>September 2004</a></li>
<li><a title="Q&A letters" href='masterit200410.php'>October 2004</a></li>
<li><a title="Q&A letters" href='masterit200411.php'>November 2004</a></li>
<li><a title="Q&A letters" href='masterit200412.php'>December 2004</a></li>
<li> </li><br><li>Or go back to:</li><li><a title='Q&A/MasterIT letters from 2004' href="masterit2004.php">2004 archive</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>May 2004</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Mark's writing' href="written.php">Professional Writing</a> > <a title='My weekly Q&A column in The Australian' href="masterIT.php">MasterIT</a> > <a title='Q&A/MasterIT letters from 2004' href="masterit2004.php">2004 archive</a> > <a title='Q&A letters' href="masterit200405.php">May 2004</a>
<br><br>		<br>
<h2>4/5/04</h2><br>
<b>I am interested in broadband and noticed that TPG is offering $19.95 a month at 200 MB download. Is there any way that I can measure the downloads that I am using over a period of say a week or month?</b><br>
<br>
Certainly; any ISP worth it's mettle will provide you with a method of doing this. Often this is in the form of a downloadable utility that sits in your system tray and gives you a fairly current idea of how much data you've transferred, either by communicating with the ISP, or by simply counting how much data flows in and out of your PC.<br>
<br>
You can also generally access this information via the ISP's account home page, although this is less convenient.<br>
<br>
It's worth noting that in this context 200MB is, in technical terms, three-fifths of bugger all. You can download that much in around two hours on the slowest ADSL speed. It's almost always worth paying a little more per month for a much larger allowance.<br>
<br>
Before signing up you should also check out broadbandchoice.com.au for an objective comparison of Australian ISPs. They also recently conducted a user survey, the results of which are at whirlpool.net.au/survey/results.htm.<br>
<br>
<br>
<b>I am running a DELL with XP, now 2 years old. For some reason, when I turn it on of late, it finds "New Programs Installed" in the Start Menu. But they are not new - just a selection of existing programs. Any ideas on what button I have incorrectly pressed?</b><br>
<br>
Yep, you pressed the "install Windows" button. XP is great, but the new Start Menu is a bit of a disaster. I think the guys at Microsoft let the Work Experience Kid write that bit.<br>
<br>
The general consensus on the net seems to be that the "highlight new programs" feature often plays up, and turning it off entirely is a pretty good idea.<br>
<br>
Thankfully this is easy; just right-click the Start menu, click Properties, then select "customize" (as they so quaintly put it over there).<br>
<br>
Next, click the Advanced tab, and then untick the "Highlight newly installed programs" check box.<br>
<br>
<br>
<h2>11/5/04</h2><br>
<b>I am running Windows XP and Office XP Professional. I have two users set up on the machine. Sometimes when I log on I get the message "Windows cannot find the file 'C:Program'. Make sure you typed the name correctly, and try again etc". It also appears when my wife, the other person set up on the machine, tries to log on. By simply clicking OK I continue to my normal desktop. The message does not appear every time I log on, any ideas as to what is causing the problem?</b><br>
<br>
Once again we see the genius of Windows at work. You've got a bad entry in the XP autostart list. Rather than give us the option of simply removing it, we get accused of typing something wrong.<br>
<br>
This problem can happen when you uninstall a poorly designed program that leaves behind a startup shortcut to some file that no longer exists. It's also possible that a trojan or virus is cheerfully trying to fire itself up - it'd be a good idea to do a full scan. Assuming you system is clean, it should be fairly simple to get rid of.<br>
<br>
XP tries to run programs listed in two places when you power up. One is the Startup folder of your Start menu. The other place is dark and secret, and buried in the registry. XP further complicates matters by dividing these shortcuts into those that apply to all users, and those that just apply to the current login. As the problem seems universal the offending broken shortcut is most likely in the former category.<br>
<br>
Thankfully we don't have to go poking round in four places to try and fix the problem. Just click on Start->Run (or press Windows-R), type "msconfig" and press enter. A program will pop up with various options; flip straight to the Startup tab.<br>
<br>
Here you will find the list of programs that are run upon startup. Your mission is to find the offending entry in amongst them. Look for something incomplete; it's very likely going to start with (or be) "C:Program". Unfortunately you can't maximise this window, so you'll probably have to do some scrolling.<br>
<br>
Now untick the (alleged) offending item, hit apply, reboot and see if the problem is gone. Repeat as necessary.<br>
<br>
<br>
<h2>18/5/04</h2><br>
<b>I've been playing back DVDs on my computer for some time. I recently upgraded to a shiny new video card which supports TV out. I can get a picture of my desktop happening on the telly without any problem, but when I try to play back a DVD I get a weird pulsing picture that is unwatchable. Ironically, I can play back (ahem) perfectly legal AVI movies without any problem. Any hints?</b><br>
<br>
You're experiencing the joy of Macrovision copy protection. It's designed to make the world a better place by preventing people from recording the DVDs directly onto VHS. Pretty much every standalone DVD player in the world has this "feature" built in, and most computer video cards with a TV out can also switch it on at will, which is what's happening when you try to watch a DVD - the playback software activates Macrovision at a driver level.<br>
<br>
It works by corrupting the video signal in a way that interferes with the automatic gain control on the video recorder. The result is an unwatchable picture - commonly the brightness pulses up and down - when you connect to the AV input of a video recorder.<br>
<br>
The clever thing is that if you connect directly to a TV you probably won't see anything wrong, and if this is feasible then it's the easiest solution to the problem.<br>
<br>
If your TV doesn't have an AV in (and you're stuck with going through the VCR), or your TV just doesn't work properly with Macrovision (which is unlikely but not impossible), you're best option is to try to disable the copy protection with software.<br>
<br>
Various solutions exist, perhaps try DVD Region-Free at www.dvdidle.com, or do a Google search for "macrovision-free".<br>
<br>
Bear in mind that doing this sort of thing is questionably legal at best, and completely illegal at worst. If cattle prod wielding lawyers for large media companies invade your home and confiscate your firstborn I accept no responsibility. Ethically, there is a good argument for being able to view and even back up DVDs that you've paid for and own, but ethics and laws don't always overlap. Caveat emptor.<br>
<br>
<br>
<h2>25/5/04</h2><br>
<b>Recently I have updated to Windows XP (from Windows 98) and in spite of having "Pop Up Cop" and "Zone Alarm" systems in place I am now getting multi daily annoying pop ups from Spyware Advisory saying user may be infected with unauthorised spyware programs and to log onto www.spw4.com. Can you please tell me how I can stop this web access.</b><br>
<br>
It should just be a case of doing a virus check, and then an anti spyware check. You should also check windowsupdate.com for any new security patches that you might be missing.<br>
<br>
Ironically (and quite cheekily), the URL you provided claims to be selling anti-spyware products, however the site looked incredibly suspect so I did a little digging.<br>
<br>
It turns out that the company involved ("Secure Computing", if you please) appear to be at best a bunch of spammers and at worst a bunch of virus-writing crooks. See tinyurl.com/2ypxy for an interesting exchange.<br>
<br>
Real anti-spyware can be had in the form of Ad-aware, an excellent package. It works well and it's free. You can download it from www.lavasoft.de.<br>
<br>
Remember that spyware often gets installed via the greatest security risk on any computer - namely the one which exists between the keyboard and the chair. Be careful what you install, especially free things that claim to make your life better, and keep an eye on what other people do with your pc.<br>
<br>
Your popup was semi-malicious, and popups in general are annoying. It's interesting to see that they are slowly being strangled out of existence, mainly by browsers like Mozilla (which has an excellent popup blocker built in), and third party apps like the one you use.<br>
<br>
You can also block many ads by installing a customised "hosts" file. This is a system configuration file that maps various URLs to IP addresses. You can use it to override the real world values with dummies. For example, every time the browser requests an ad from "ads.doubleclick.net", it gets redirected to nowhere, which blocks the ad entirely.<br>
<br>
Of course, enterprising geeks have already done the hard work of compiling lists of servers to block. One such list can be downloaded and easily installed from everythingisnt.com/hosts.html.<br>
<br>
<i><p>Did the information on this page help you? Entertain you? Bore you? <a href="contact.php?subject=MasterIT">Drop me a line</a>.</p>

<p>If you're feeling particularly generous, you can even <a href="buypics.php">click here to send me some dot-com riches</a>. Think of it as online busking.</i></p>
	</div>
</div>
</body>
</html>