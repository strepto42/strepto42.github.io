<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - Brissie by Night 1 - Brisbane CBD and the Story Bridge</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="Brisbane CBD and the Story Bridge">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="Pictures of my 28th Birthday party complete with Sparkler Bomb" href='28th.php'>28th Birthday</a></li>
<li><a title="Pictures of my 30th Birthday party" href='30th.php'>30th Birthday</a></li>
<li><a title="Michael Shamgar and Lindsay Halamek's 30th birthday bash photos" href='sl30th.php'>Shams & Linds' 30th</a></li>
<li><a title="Pictures of Andy Marinos's new flat, cat Toby, and Mum Pam Swain" href='andycatandflat.php'>Andy's Cat & Flat</a></li>
<li><a title="Pictures of a visit to Stephen Jackson's Farm" href='jackovisit.php'>Jacko's Farm</a></li>
<li><a title="Pictures taken at the Peace Convergence action in Rockhampton and Yeppoon in June 2005 to protest the joint US Australia military exercises (Operation Talisman Sabre)" href='peaceconvergence.php'>Peace Convergence</a></li>
<li><a title="Sydney trip - April '06" href='bridges.php'>Sydney, April 06</a></li>
<li><a title="Pics of Naima's 28th birthday dinner" href='mim28th.php'>Naima's 28th</a></li>
<li><div class='activemenu'>Brissie by Night 1</div></li>
<li><a title="Lamington National Park" href='lamington.php'>Lamington NP</a></li>
<li><a title="Various creatures and views from our Brisbane back yard" href='backyard.php'>Backyard Creatures</a></li>
<li><a title="Opening day of the Eleanor Schonell (Green) Bridge" href='greenbridge.php'>Green Bridge</a></li>
<li><a title="Pictutres from the 2006 Woodford Folk Festival" href='woodford0607.php'>Woodford 2006-2007</a></li>
<li><a title="One Cute Puppy" href='jezebel.php'>Jezebel</a></li>
<li><a title="Climbing at Kangaroo Point Cliffs" href='kangaroopt1.php'>Heather's Visit</a></li>
<li><a title="0x0021st (33rd) birthday celebrations" href='0x0021st.php'>0x0021st Birthday</a></li>
<li><a title="Nuptial photography" href='guyandalison.php'>Guy and Alison's Wedding</a></li>
<li><a title="Pictures from the 2007 Woodford Folk Festival" href='woodford0708.php'>Woodford 2007-2008</a></li>
<li><a title="Image gallery" href='sydneytrip0802.php'>Sydney & Yacaaba Head</a></li>
<li><a title="An impressive show by nature" href='lightning.php'>Thunderstorm Moonrise</a></li>
<li><a title="Frightening pictures of a shrinking beard" href='debearding.php'>De-bearding</a></li>
<li><a title="More Nuptial Photography" href='michaelandkaren.php'>Michael and Karen's Wedding</a></li>
<li><a title="A night of celebration" href='andrews21st.php'>Andrew's 21st</a></li>
<li><a title="Image Gallery" href='bloodyknee.php'>Bloody Knee</a></li>
<li><a title="Image Gallery" href='tyesbirthday.php'>Tye's Birthday</a></li>
<li><a title="Image Gallery" href='lasersocialising.php'>Laser Socialising</a></li>
<li><a title="Image Gallery" href='heatherandevan.php'>Heather and Evan's Wedding</a></li>
<li><a title="Image Gallery" href='woodford0809.php'>Woodford 2008-2009</a></li>
<li><a title="Image Gallery" href='allyandben.php'>Ally and Ben's Wedding</a></li>
<li><a title="Image Gallery" href='annes30th.php'>Anne's 30th</a></li>
<li><a title="Image Gallery" href='possumcreek.php'>Possum Creek</a></li>
<li><a title="Image Gallery" href='jamnight.php'>Jam Night</a></li>
<li><a title="Image Gallery" href='cunninghamsgap.php'>Cunningham's Gap</a></li>
<li><a title="Image Gallery" href='bigcat.php'>Diving on Big Cat</a></li>
<li><a title="Images from my birthday jam" href='birthdayjam.php'>Music, mayhem and merriment</a></li>
<li><a title="Image Gallery" href='fuzzypolaroidpics.php'>Fuzzy Polaroid</a></li>
<li><a title="Image Gallery" href='zombiewalk2009.php'>2009 Zombie Walk</a></li>
<li> </li><br><li>Or go back to:</li><li><a title='Picture galleries' href="pictures.php">Photography</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>Brissie by Night 1</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Picture galleries' href="pictures.php">Photography</a> > <a title='Brisbane CBD and the Story Bridge' href="brisbanepics1.php">Brissie by Night 1</a>
<br><br>		

<p><a href="http://www.rhyskeepence.com" target="_blank">Rhys</a> and I have spent another evening photo-nerding around the Story Bridge. I played with his EF-S 10-22mm and he had a go of my 50mm F1.4.</p>
<br><br>
All images in this gallery:<br>
<table width='800'>
<tr>
</tr>
<tr><td><A ID='IMG_1675.JPG' href='brisbanepics1.php?fileId=IMG_1675.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061120/IMG_1675.JPG' ALT='IMG_1675.JPG'><BR>IMG_1675.JPG<br>44.51 KB</a><div class='inv'><br><a href='./images/20061120/IMG_1675.JPG' ALT='IMG_1675.JPG'>IMG_1675.JPG</a></div></td>
<td><A ID='IMG_1676.JPG' href='brisbanepics1.php?fileId=IMG_1676.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061120/IMG_1676.JPG' ALT='IMG_1676.JPG'><BR>IMG_1676.JPG<br>57.72 KB</a><div class='inv'><br><a href='./images/20061120/IMG_1676.JPG' ALT='IMG_1676.JPG'>IMG_1676.JPG</a></div></td>
<td><A ID='IMG_1679.JPG' href='brisbanepics1.php?fileId=IMG_1679.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061120/IMG_1679.JPG' ALT='IMG_1679.JPG'><BR>IMG_1679.JPG<br>75.83 KB</a><div class='inv'><br><a href='./images/20061120/IMG_1679.JPG' ALT='IMG_1679.JPG'>IMG_1679.JPG</a></div></td>
<td><A ID='IMG_1680.JPG' href='brisbanepics1.php?fileId=IMG_1680.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061120/IMG_1680.JPG' ALT='IMG_1680.JPG'><BR>IMG_1680.JPG<br>49.47 KB</a><div class='inv'><br><a href='./images/20061120/IMG_1680.JPG' ALT='IMG_1680.JPG'>IMG_1680.JPG</a></div></td>
<td><A ID='IMG_1681.JPG' href='brisbanepics1.php?fileId=IMG_1681.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061120/IMG_1681.JPG' ALT='IMG_1681.JPG'><BR>IMG_1681.JPG<br>62.89 KB</a><div class='inv'><br><a href='./images/20061120/IMG_1681.JPG' ALT='IMG_1681.JPG'>IMG_1681.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_1682.JPG' href='brisbanepics1.php?fileId=IMG_1682.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061120/IMG_1682.JPG' ALT='IMG_1682.JPG'><BR>IMG_1682.JPG<br>69.44 KB</a><div class='inv'><br><a href='./images/20061120/IMG_1682.JPG' ALT='IMG_1682.JPG'>IMG_1682.JPG</a></div></td>
<td><A ID='IMG_1684.JPG' href='brisbanepics1.php?fileId=IMG_1684.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061120/IMG_1684.JPG' ALT='IMG_1684.JPG'><BR>IMG_1684.JPG<br>68.31 KB</a><div class='inv'><br><a href='./images/20061120/IMG_1684.JPG' ALT='IMG_1684.JPG'>IMG_1684.JPG</a></div></td>
<td><A ID='IMG_1687.JPG' href='brisbanepics1.php?fileId=IMG_1687.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061120/IMG_1687.JPG' ALT='IMG_1687.JPG'><BR>IMG_1687.JPG<br>51.03 KB</a><div class='inv'><br><a href='./images/20061120/IMG_1687.JPG' ALT='IMG_1687.JPG'>IMG_1687.JPG</a></div></td>
<td><A ID='IMG_1707.JPG' href='brisbanepics1.php?fileId=IMG_1707.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061120/IMG_1707.JPG' ALT='IMG_1707.JPG'><BR>IMG_1707.JPG<br>96.03 KB</a><div class='inv'><br><a href='./images/20061120/IMG_1707.JPG' ALT='IMG_1707.JPG'>IMG_1707.JPG</a></div></td>
<td><A ID='IMG_1710.JPG' href='brisbanepics1.php?fileId=IMG_1710.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061120/IMG_1710.JPG' ALT='IMG_1710.JPG'><BR>IMG_1710.JPG<br>48.33 KB</a><div class='inv'><br><a href='./images/20061120/IMG_1710.JPG' ALT='IMG_1710.JPG'>IMG_1710.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_1712.JPG' href='brisbanepics1.php?fileId=IMG_1712.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061120/IMG_1712.JPG' ALT='IMG_1712.JPG'><BR>IMG_1712.JPG<br>53.84 KB</a><div class='inv'><br><a href='./images/20061120/IMG_1712.JPG' ALT='IMG_1712.JPG'>IMG_1712.JPG</a></div></td>
<td><A ID='IMG_1721.JPG' href='brisbanepics1.php?fileId=IMG_1721.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061120/IMG_1721.JPG' ALT='IMG_1721.JPG'><BR>IMG_1721.JPG<br>60.88 KB</a><div class='inv'><br><a href='./images/20061120/IMG_1721.JPG' ALT='IMG_1721.JPG'>IMG_1721.JPG</a></div></td>
<td><A ID='IMG_1725.JPG' href='brisbanepics1.php?fileId=IMG_1725.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061120/IMG_1725.JPG' ALT='IMG_1725.JPG'><BR>IMG_1725.JPG<br>66.86 KB</a><div class='inv'><br><a href='./images/20061120/IMG_1725.JPG' ALT='IMG_1725.JPG'>IMG_1725.JPG</a></div></td>
<td><A ID='IMG_1739.JPG' href='brisbanepics1.php?fileId=IMG_1739.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061120/IMG_1739.JPG' ALT='IMG_1739.JPG'><BR>IMG_1739.JPG<br>52.35 KB</a><div class='inv'><br><a href='./images/20061120/IMG_1739.JPG' ALT='IMG_1739.JPG'>IMG_1739.JPG</a></div></td>
<td><A ID='IMG_1741.JPG' href='brisbanepics1.php?fileId=IMG_1741.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061120/IMG_1741.JPG' ALT='IMG_1741.JPG'><BR>IMG_1741.JPG<br>63.5 KB</a><div class='inv'><br><a href='./images/20061120/IMG_1741.JPG' ALT='IMG_1741.JPG'>IMG_1741.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_1747.JPG' href='brisbanepics1.php?fileId=IMG_1747.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061120/IMG_1747.JPG' ALT='IMG_1747.JPG'><BR>IMG_1747.JPG<br>57.69 KB</a><div class='inv'><br><a href='./images/20061120/IMG_1747.JPG' ALT='IMG_1747.JPG'>IMG_1747.JPG</a></div></td>
<td><A ID='IMG_1750.JPG' href='brisbanepics1.php?fileId=IMG_1750.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061120/IMG_1750.JPG' ALT='IMG_1750.JPG'><BR>IMG_1750.JPG<br>72.67 KB</a><div class='inv'><br><a href='./images/20061120/IMG_1750.JPG' ALT='IMG_1750.JPG'>IMG_1750.JPG</a></div></td>
<td><A ID='IMG_1753.JPG' href='brisbanepics1.php?fileId=IMG_1753.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061120/IMG_1753.JPG' ALT='IMG_1753.JPG'><BR>IMG_1753.JPG<br>53.12 KB</a><div class='inv'><br><a href='./images/20061120/IMG_1753.JPG' ALT='IMG_1753.JPG'>IMG_1753.JPG</a></div></td>
</tr>
</table>	</div>
</div>
</body>
</html>