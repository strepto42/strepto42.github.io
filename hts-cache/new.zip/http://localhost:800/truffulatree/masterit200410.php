<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - October 2004 - Q&A letters</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="Q&A letters">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="Q&A letters" href='masterit200401.php'>January 2004</a></li>
<li><a title="Q&A letters" href='masterit200402.php'>February 2004</a></li>
<li><a title="Q&A letters" href='masterit200403.php'>March 2004</a></li>
<li><a title="Q&A letters" href='masterit200404.php'>April 2004</a></li>
<li><a title="Q&A letters" href='masterit200405.php'>May 2004</a></li>
<li><a title="Q&A letters" href='masterit200406.php'>June 2004</a></li>
<li><a title="Q&A letters" href='masterit200407.php'>July 2004</a></li>
<li><a title="Q&A letters" href='masterit200408.php'>August 2004</a></li>
<li><a title="Q&A letters" href='masterit200409.php'>September 2004</a></li>
<li><div class='activemenu'>October 2004</div></li>
<li><a title="Q&A letters" href='masterit200411.php'>November 2004</a></li>
<li><a title="Q&A letters" href='masterit200412.php'>December 2004</a></li>
<li> </li><br><li>Or go back to:</li><li><a title='Q&A/MasterIT letters from 2004' href="masterit2004.php">2004 archive</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>October 2004</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Mark's writing' href="written.php">Professional Writing</a> > <a title='My weekly Q&A column in The Australian' href="masterIT.php">MasterIT</a> > <a title='Q&A/MasterIT letters from 2004' href="masterit2004.php">2004 archive</a> > <a title='Q&A letters' href="masterit200410.php">October 2004</a>
<br><br>		<br>
<h2>19/10/2004</h2><br>
<b>I noticed in today's M'IT that you quote again the tinyurl site; it seems to be a great source of information but how does it work? I mean, how do you know which tinyurl to go to, or do you find the info first and create the shortcut after?</b><br>
<br>
Tinyurl.com is just a redirector. It will take any long URL you enter and produce a small one, which never expires, for free. This is of course very helpful when space is at a premium, and it can also be useful to prevent email programs from badly wrapping long URLs and breaking them in the process. It can also help circumvent certain URL-based content filtering firewalls, but the Master wouldn't know anything about that.<br>
<br>
<br>
<b>Whenever I try to access favourite sites offline (that I have ticked for offline access when first making them favourites), I get a message back:  'Unable to find server'. How can I fix this?</b><br>
<br>
Not all sites can be made available offline, as they have dynamic content (for example, webmail like Hotmail, shopping sites and sites where you have to log on).<br>
<br>
There's a Microsoft guide (may as well go to the horse's mouth) at http://tinyurl.com/48shj.<br>
<br>
<br>
<b>A few weeks ago you mentioned a program called Bittorrent. I've installed it, but my transfer rates are all over the place, and not up to what I'd expect from a 512k ADSL connection. My normal internet browsing is also really slow even though I'm not using all my incoming bandwidth. Am I just unlucky or am I missing something?</b><br>
<br>
What's happening is that all your outgoing bandwidth is being used to share data with other Bittorrent clients. The problem with this is that in the process of normal browsing, and downloading of any sort, your computer needs to send outgoing acknowledgements for any data it receives. If your outgoing bandwidth is already all used up, these acknowledgements back up and slow down the incoming data too (this is tech irony).<br>
<br>
The trick with Bittorrent (or any other file sharing arrangement) is to limit the maximum amount of outgoing bandwidth it can use. This can be tricky with the standard Bittorrent client, but third party clients like Bittornado make it easy.<br>
<br>
Set your upload rate to approximately 80% of your upstream connection speed, so about 10kB/s for a 512k/128k DSL connection.<br>
<br>
<i><p>Did the information on this page help you? Entertain you? Bore you? <a href="contact.php?subject=MasterIT">Drop me a line</a>.</p>

<p>If you're feeling particularly generous, you can even <a href="buypics.php">click here to send me some dot-com riches</a>. Think of it as online busking.</i></p>
	</div>
</div>
</body>
</html>