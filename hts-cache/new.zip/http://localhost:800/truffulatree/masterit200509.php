<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - September 2005 - Q&A letters</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="Q&A letters">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="Q&A letters" href='masterit200501.php'>January 2005</a></li>
<li><a title="Q&A letters" href='masterit200502.php'>February 2005</a></li>
<li><a title="Q&A letters" href='masterit200503.php'>March 2005</a></li>
<li><a title="Q&A letters" href='masterit200504.php'>April 2005</a></li>
<li><a title="Q&A letters" href='masterit200505.php'>May 2005</a></li>
<li><a title="Q&A letters" href='masterit200506.php'>June 2005</a></li>
<li><a title="Q&A letters" href='masterit200507.php'>July 2005</a></li>
<li><a title="Q&A letters" href='masterit200508.php'>August 2005</a></li>
<li><div class='activemenu'>September 2005</div></li>
<li><a title="Q&A letters" href='masterit200510.php'>October 2005</a></li>
<li><a title="Q&A letters" href='masterit200511.php'>November 2005</a></li>
<li><a title="Q&A letters" href='masterit200512.php'>December 2005</a></li>
<li> </li><br><li>Or go back to:</li><li><a title='Q&A/MasterIT letters from 2005' href="masterit2005.php">2005 archive</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>September 2005</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Mark's writing' href="written.php">Professional Writing</a> > <a title='My weekly Q&A column in The Australian' href="masterIT.php">MasterIT</a> > <a title='Q&A/MasterIT letters from 2005' href="masterit2005.php">2005 archive</a> > <a title='Q&A letters' href="masterit200509.php">September 2005</a>
<br><br>		<br>
<h2>6/9/05</h2><br>
<b>I have connected up to MSN audio and have two people who I want to talk to. Both are set up with Headset/microphone. The problem is that I am having trouble with the hearing. They come in clear but their voices cut in and out and I miss parts of a sentence which can mean that I just don't know what they are talking about. I have rung Bigpond, my ISP, but they say that it is not a dial-up problem. Neither of my two contacts have the problem when using it elsewhere. I have been into my Control Panel to the Sounds and Audio Devices but can't find anything amiss there.</b><br>
<br>
The problem here is that, because you're on dialup, your Internet connection doesn't have enough bandwidth (enough "room" if you will) to let the audio through smoothly.<br>
<br>
Think of your Internet connection as a pipe, with a certain diameter. Only a particular amount of data can fit through it at any one time. A bigger pipe will let more data flow, a smaller one less. If there is too much information trying to get sent and received, it gets banked up, and things slow down.<br>
<br>
When this happens, the computer can do one of two things: either queue up the data and send it when it gets a chance, or just throw it away.<br>
<br>
"Critical" data, like email, will just get delayed, however, in the case of audio, your computer uses a protocol called UDP, which is used for continuously streaming data. Because queuing up the audio data would just make matters worse (it would just keep banking up like Sydney traffic), it gets thrown away when the pipe is full, and this is why it cuts in and out.<br>
<br>
To fix the problem, the best solution is to get a bigger pipe, ie broadband, however, you can also try using a different program for audio conversations.<br>
<br>
Different programs may make more efficient use of your connection, and therefore they'll work better. One popular voice program is Skype (www.skype.com). The only thing you need to bear in mind is that your friends will also need to use the same program.<br>
<br>
<br>
<h2>13/9/05</h2><br>
<b>I recently upgraded my hardware & software, and I am now running Windows XP with Outlook 2002. When I try and send a message it will sometimes (but not always) give me an error message from the System Administrator saying "553 sorry, that domain isn't in my list of allowed rcpthosts (#5.7.1)". Next time I try & send an email to that same address the message will get through. Major hassle. Would love even an inkling of a solution.</b><br>
<br>
Unfortunately this is one of those lovely generic errors, which can be caused by quite a few things, so getting to the bottom of it may be tricky. The basic gist of it is that a security issue of some sort is causing the problem, and the issue may or may not be at your end.<br>
<br>
Some of the more common reasons for the error are:<br>
<br>
- trying to relay your mail through another SMTP (outgoing mail) server, when the server does not permit you to do this<br>
<br>
- delivery restrictions on the recipient has mailbox, which are blocking your message<br>
<br>
- not having the permission you need to send mail through your outgoing server <br>
<br>
The last option is most likely to be the cause of problem, however, the intermittent nature of the problem is puzzling. Some mail servers can be configured to allow outgoing mail for a limited time after you last check your inbox, so perhaps that is what's going on.<br>
<br>
Basically, you may need to provide a username and password when you send mail. Have a look for this in the email account settings - it could well fix your problem, but if it doesn't, you'll have to seek help from your ISP or friendly sysadmin.<br>
<br>
<br>
<b>Can you tell me if it is possible to take music from a DVD and put it on my Ipod via Itunes? The new AC/DC DVD would be a great addition to my Ipod.</b><br>
<br>
Certainly, every Ipod needs a little Acka-dacka. It's not hard to grab the audio from a DVD, provided you use special software, and the DVD has been authored well (with chapter points dividing up the songs properly).<br>
<br>
A quick link hunt found this software:<br>
<br>
http://www.audioutilities.com/dvd-audio-ripper/dvd-audio-ripper.htm<br>
<br>
I haven't tried this program yet as I left my AC/DC in my other pants, so I'm not sure if it's any good, but if it's not there will be other programs out there. Google and doom9.org should help track them down.<br>
<br>
<br>
<h2>20/9/05</h2><br>
<b>I recently upgraded my PC's RAM, to 1Gb. In theory, XP should be faster, yet I notice that it still does a lot of disk flogging when I switch applications. Surely this shouldn't be necessary. I've found the setting to manually configure the swapfile, but I get warned against switching it off entirely. Is this truly a bad thing?</b><br>
<br>
Most articles on the net recommend against disabling the swapfile, but it's not necessarily a bad thing, provided you understand what you're doing, and the implications.<br>
<br>
A "swapfile", in it's simplest form, is used by the operating system to swap data stored in RAM (which is fast) to disk (which is slow). This lets the operating system use more RAM than it physically has, at the expense of speed. Hence the term "virtual memory", because it's not really there; it's just pretend RAM mapped on to the hard disk.<br>
<br>
In theory, a PC with abundant RAM shouldn't need any of the virtual stuff. If Windows used RAM in a straightforward way, it would always use it's physical RAM first before hitting the disc (like other operating systems do).<br>
<br>
Unfortunately, life isn't quite that simple any more, and Windows uses the swapfile in a more complicated way than this. In a way, it uses it proactively, swapping data out that isn't likely to get needed for a while, in order to free up more physical RAM. This is great if you don't have much RAM, but pointless if you have more than enough.<br>
<br>
In answer to your question, yes, you can completely disable the swapfile, and this will force Windows to use real RAM all the time. This actually works well, but you have to be aware of a couple of caveats.<br>
<br>
First and foremost, if you load too many programs at one and your PC runs out of real RAM, it will become quite unhappy, and confused, your applications will start to crash, and you'll lose work.<br>
<br>
Secondly, some applications will refuse to work properly without virtual memory. One example is Adobe Photoshop; some earlier versions won't even start without the swapfile enabled. Later versions do work, but display scary warnings on startup.<br>
<br>
So it's up to you. The swapfile is there for a reason; and Windows is designed to function with it as an integral part of it's structure. If you remove this safety net, you will sacrifice stability in a low RAM situation. But if you like living on the edge, and you have enough RAM, I say go for it, as it will stop the annoying and often unnecessary disk activity.<br>
<br>
 applications will refuse to work properly without virtual memory. One example is Adobe Photoshop; some earlier versions won't even start without the swapfile enabled. Later versions do work, but display scary warnings on startup.<br>
<br>
So it's up to you. The swapfile is there for a reason; and Windows is designed to function with it as an integral part of it's structure. If you remove this safety net, you will sacrifice stability in a low RAM situation. But if you like living on the edge, and you have enough RAM, I say go for it, as it will stop the annoying and often unnecessary disk activity.<br>
<br>
<br>
<h2>27/9/05</h2><br>
<b>I do not seem to be able to delete (music) files from the Library in Windows Media Player � even though, when prompted, I check the option of deleting from both WMP and my PC. They (or most of them) just won�t go! Other people do have access to my PC. Is it possible that they are able to prevent files from being deleted? And, if so, can I override their wishes and delete these files � once and for all?</b><br>
<br>
It's strange that ticking the option to remove the files from the PC as well as the library doesn't work.<br>
<br>
Try going into Windows Explorer (My Computer) and deleting the files there from your C: drive. You'll then have to go through and remove them from the library in WMP too, if they're still showing up.<br>
<br>
It is possible to restrict access rights to certain files using Windows security, but it's not a particularly easy thing to do by accident. Unless the files were created by a different user, you should be able to delete them, and if you can do this in Windows Explorer then you shouldn't have any problems with them reappearing in WMP.<br>
<br>
If, however, you run into access issues, you'll need to get the computer's administrator to look into it for you. Don't forget the chocolate for bribes.<br>
<br>
<br>
<b>I am now using Microsoft�s new automatic updates but am experiencing some problems. The following ("Cumulative security update for Outlook Express 6 SP1.  Code KB823353") is a critical update that I have down loaded and installed a total of 7 times now, yet each time I check for updates it reappears. Have you any idea why this keeps repeating? Each download/install has shown up as successful.</b><br>
<br>
Generally speaking, Windows Update works quite well these days, but sometimes it still gets a bit confused, and you get the Groundhog Day of updates.<br>
<br>
The first thing to do is have a look for an option to hide the update. As you've installed it already then you can safely hide it without worrying.<br>
<br>
Sometimes though, Microsoft deems an update so earth-shatteringly critical that you can't hide it. If that happens, try to uninstall the patch by going to add/remove programs in control panel, and then reinstall it.<br>
<br>
Failing that, try clearing your IE cache, including "all offline content", and cookies.<br>
<br>
<i><p>Did the information on this page help you? Entertain you? Bore you? <a href="contact.php?subject=MasterIT">Drop me a line</a>.</p>

<p>If you're feeling particularly generous, you can even <a href="buypics.php">click here to send me some dot-com riches</a>. Think of it as online busking.</i></p>
	</div>
</div>
</body>
</html>