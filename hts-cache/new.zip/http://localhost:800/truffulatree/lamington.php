<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - Lamington NP - Lamington National Park</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="Lamington National Park">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="Pictures of my 28th Birthday party complete with Sparkler Bomb" href='28th.php'>28th Birthday</a></li>
<li><a title="Pictures of my 30th Birthday party" href='30th.php'>30th Birthday</a></li>
<li><a title="Michael Shamgar and Lindsay Halamek's 30th birthday bash photos" href='sl30th.php'>Shams & Linds' 30th</a></li>
<li><a title="Pictures of Andy Marinos's new flat, cat Toby, and Mum Pam Swain" href='andycatandflat.php'>Andy's Cat & Flat</a></li>
<li><a title="Pictures of a visit to Stephen Jackson's Farm" href='jackovisit.php'>Jacko's Farm</a></li>
<li><a title="Pictures taken at the Peace Convergence action in Rockhampton and Yeppoon in June 2005 to protest the joint US Australia military exercises (Operation Talisman Sabre)" href='peaceconvergence.php'>Peace Convergence</a></li>
<li><a title="Sydney trip - April '06" href='bridges.php'>Sydney, April 06</a></li>
<li><a title="Pics of Naima's 28th birthday dinner" href='mim28th.php'>Naima's 28th</a></li>
<li><a title="Brisbane CBD and the Story Bridge" href='brisbanepics1.php'>Brissie by Night 1</a></li>
<li><div class='activemenu'>Lamington NP</div></li>
<li><a title="Various creatures and views from our Brisbane back yard" href='backyard.php'>Backyard Creatures</a></li>
<li><a title="Opening day of the Eleanor Schonell (Green) Bridge" href='greenbridge.php'>Green Bridge</a></li>
<li><a title="Pictutres from the 2006 Woodford Folk Festival" href='woodford0607.php'>Woodford 2006-2007</a></li>
<li><a title="One Cute Puppy" href='jezebel.php'>Jezebel</a></li>
<li><a title="Climbing at Kangaroo Point Cliffs" href='kangaroopt1.php'>Heather's Visit</a></li>
<li><a title="0x0021st (33rd) birthday celebrations" href='0x0021st.php'>0x0021st Birthday</a></li>
<li><a title="Nuptial photography" href='guyandalison.php'>Guy and Alison's Wedding</a></li>
<li><a title="Pictures from the 2007 Woodford Folk Festival" href='woodford0708.php'>Woodford 2007-2008</a></li>
<li><a title="Image gallery" href='sydneytrip0802.php'>Sydney & Yacaaba Head</a></li>
<li><a title="An impressive show by nature" href='lightning.php'>Thunderstorm Moonrise</a></li>
<li><a title="Frightening pictures of a shrinking beard" href='debearding.php'>De-bearding</a></li>
<li><a title="More Nuptial Photography" href='michaelandkaren.php'>Michael and Karen's Wedding</a></li>
<li><a title="A night of celebration" href='andrews21st.php'>Andrew's 21st</a></li>
<li><a title="Image Gallery" href='bloodyknee.php'>Bloody Knee</a></li>
<li><a title="Image Gallery" href='tyesbirthday.php'>Tye's Birthday</a></li>
<li><a title="Image Gallery" href='lasersocialising.php'>Laser Socialising</a></li>
<li><a title="Image Gallery" href='heatherandevan.php'>Heather and Evan's Wedding</a></li>
<li><a title="Image Gallery" href='woodford0809.php'>Woodford 2008-2009</a></li>
<li><a title="Image Gallery" href='allyandben.php'>Ally and Ben's Wedding</a></li>
<li><a title="Image Gallery" href='annes30th.php'>Anne's 30th</a></li>
<li><a title="Image Gallery" href='possumcreek.php'>Possum Creek</a></li>
<li><a title="Image Gallery" href='jamnight.php'>Jam Night</a></li>
<li><a title="Image Gallery" href='cunninghamsgap.php'>Cunningham's Gap</a></li>
<li><a title="Image Gallery" href='bigcat.php'>Diving on Big Cat</a></li>
<li><a title="Images from my birthday jam" href='birthdayjam.php'>Music, mayhem and merriment</a></li>
<li><a title="Image Gallery" href='fuzzypolaroidpics.php'>Fuzzy Polaroid</a></li>
<li><a title="Image Gallery" href='zombiewalk2009.php'>2009 Zombie Walk</a></li>
<li> </li><br><li>Or go back to:</li><li><a title='Picture galleries' href="pictures.php">Photography</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>Lamington NP</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Picture galleries' href="pictures.php">Photography</a> > <a title='Lamington National Park' href="lamington.php">Lamington NP</a>
<br><br>		

<p>Pictures from a couple of days spend down at Lamington National Park. There was lovely mist and an abundance of friendly bird life. <a href="http://www.rhyskeepence.com" target="_blank">Rhys</a> was kind enough to lend me his EF 70-200 f2.8 L glass too, which made for some extra-pretty pictures.</p>
<br><br>
All images in this gallery:<br>
<table width='800'>
<tr>
</tr>
<tr><td><A ID='IMG_1989.JPG' href='lamington.php?fileId=IMG_1989.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061201/IMG_1989.JPG' ALT='IMG_1989.JPG'><BR>IMG_1989.JPG<br>81.2 KB</a><div class='inv'><br><a href='./images/20061201/IMG_1989.JPG' ALT='IMG_1989.JPG'>IMG_1989.JPG</a></div></td>
<td><A ID='IMG_1992.JPG' href='lamington.php?fileId=IMG_1992.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061201/IMG_1992.JPG' ALT='Regent Bower Bird'><BR>Regent Bower Bird<br>34.15 KB</a><div class='inv'><br><a href='./images/20061201/IMG_1992.JPG' ALT='Regent Bower Bird'>Regent Bower Bird</a></div></td>
<td><A ID='IMG_1995.JPG' href='lamington.php?fileId=IMG_1995.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061201/IMG_1995.JPG' ALT='Regent Bower Bird'><BR>Regent Bower Bird<br>37.92 KB</a><div class='inv'><br><a href='./images/20061201/IMG_1995.JPG' ALT='Regent Bower Bird'>Regent Bower Bird</a></div></td>
<td><A ID='IMG_1996.JPG' href='lamington.php?fileId=IMG_1996.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061201/IMG_1996.JPG' ALT='Regent Bower Bird'><BR>Regent Bower Bird<br>37.85 KB</a><div class='inv'><br><a href='./images/20061201/IMG_1996.JPG' ALT='Regent Bower Bird'>Regent Bower Bird</a></div></td>
<td><A ID='IMG_1998.JPG' href='lamington.php?fileId=IMG_1998.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061201/IMG_1998.JPG' ALT='Regent Bower Bird'><BR>Regent Bower Bird<br>55.31 KB</a><div class='inv'><br><a href='./images/20061201/IMG_1998.JPG' ALT='Regent Bower Bird'>Regent Bower Bird</a></div></td>
</tr>
<tr><td><A ID='IMG_2000.JPG' href='lamington.php?fileId=IMG_2000.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061201/IMG_2000.JPG' ALT='Regent Bower Bird'><BR>Regent Bower Bird<br>39.61 KB</a><div class='inv'><br><a href='./images/20061201/IMG_2000.JPG' ALT='Regent Bower Bird'>Regent Bower Bird</a></div></td>
<td><A ID='IMG_2002.JPG' href='lamington.php?fileId=IMG_2002.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061201/IMG_2002.JPG' ALT='Regent Bower Bird'><BR>Regent Bower Bird<br>42.71 KB</a><div class='inv'><br><a href='./images/20061201/IMG_2002.JPG' ALT='Regent Bower Bird'>Regent Bower Bird</a></div></td>
<td><A ID='IMG_2004.JPG' href='lamington.php?fileId=IMG_2004.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061201/IMG_2004.JPG' ALT='IMG_2004.JPG'><BR>IMG_2004.JPG<br>78.59 KB</a><div class='inv'><br><a href='./images/20061201/IMG_2004.JPG' ALT='IMG_2004.JPG'>IMG_2004.JPG</a></div></td>
<td><A ID='IMG_2007.JPG' href='lamington.php?fileId=IMG_2007.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061201/IMG_2007.JPG' ALT='IMG_2007.JPG'><BR>IMG_2007.JPG<br>53.17 KB</a><div class='inv'><br><a href='./images/20061201/IMG_2007.JPG' ALT='IMG_2007.JPG'>IMG_2007.JPG</a></div></td>
<td><A ID='IMG_2012.JPG' href='lamington.php?fileId=IMG_2012.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061201/IMG_2012.JPG' ALT='IMG_2012.JPG'><BR>IMG_2012.JPG<br>72.45 KB</a><div class='inv'><br><a href='./images/20061201/IMG_2012.JPG' ALT='IMG_2012.JPG'>IMG_2012.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_2015.JPG' href='lamington.php?fileId=IMG_2015.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061201/IMG_2015.JPG' ALT='IMG_2015.JPG'><BR>IMG_2015.JPG<br>91.86 KB</a><div class='inv'><br><a href='./images/20061201/IMG_2015.JPG' ALT='IMG_2015.JPG'>IMG_2015.JPG</a></div></td>
<td><A ID='IMG_2020.JPG' href='lamington.php?fileId=IMG_2020.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061201/IMG_2020.JPG' ALT='IMG_2020.JPG'><BR>IMG_2020.JPG<br>72.6 KB</a><div class='inv'><br><a href='./images/20061201/IMG_2020.JPG' ALT='IMG_2020.JPG'>IMG_2020.JPG</a></div></td>
<td><A ID='IMG_2021.JPG' href='lamington.php?fileId=IMG_2021.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061201/IMG_2021.JPG' ALT='IMG_2021.JPG'><BR>IMG_2021.JPG<br>72.78 KB</a><div class='inv'><br><a href='./images/20061201/IMG_2021.JPG' ALT='IMG_2021.JPG'>IMG_2021.JPG</a></div></td>
<td><A ID='IMG_2022.JPG' href='lamington.php?fileId=IMG_2022.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061201/IMG_2022.JPG' ALT='IMG_2022.JPG'><BR>IMG_2022.JPG<br>100.16 KB</a><div class='inv'><br><a href='./images/20061201/IMG_2022.JPG' ALT='IMG_2022.JPG'>IMG_2022.JPG</a></div></td>
<td><A ID='IMG_2027.JPG' href='lamington.php?fileId=IMG_2027.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061201/IMG_2027.JPG' ALT='IMG_2027.JPG'><BR>IMG_2027.JPG<br>105.46 KB</a><div class='inv'><br><a href='./images/20061201/IMG_2027.JPG' ALT='IMG_2027.JPG'>IMG_2027.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_2030.JPG' href='lamington.php?fileId=IMG_2030.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061201/IMG_2030.JPG' ALT='IMG_2030.JPG'><BR>IMG_2030.JPG<br>56.8 KB</a><div class='inv'><br><a href='./images/20061201/IMG_2030.JPG' ALT='IMG_2030.JPG'>IMG_2030.JPG</a></div></td>
<td><A ID='IMG_2033.JPG' href='lamington.php?fileId=IMG_2033.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061201/IMG_2033.JPG' ALT='IMG_2033.JPG'><BR>IMG_2033.JPG<br>63.62 KB</a><div class='inv'><br><a href='./images/20061201/IMG_2033.JPG' ALT='IMG_2033.JPG'>IMG_2033.JPG</a></div></td>
<td><A ID='IMG_2034.JPG' href='lamington.php?fileId=IMG_2034.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061201/IMG_2034.JPG' ALT='IMG_2034.JPG'><BR>IMG_2034.JPG<br>87.15 KB</a><div class='inv'><br><a href='./images/20061201/IMG_2034.JPG' ALT='IMG_2034.JPG'>IMG_2034.JPG</a></div></td>
<td><A ID='IMG_2042.JPG' href='lamington.php?fileId=IMG_2042.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061201/IMG_2042.JPG' ALT='IMG_2042.JPG'><BR>IMG_2042.JPG<br>83.08 KB</a><div class='inv'><br><a href='./images/20061201/IMG_2042.JPG' ALT='IMG_2042.JPG'>IMG_2042.JPG</a></div></td>
<td><A ID='IMG_2043.JPG' href='lamington.php?fileId=IMG_2043.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061201/IMG_2043.JPG' ALT='IMG_2043.JPG'><BR>IMG_2043.JPG<br>84.28 KB</a><div class='inv'><br><a href='./images/20061201/IMG_2043.JPG' ALT='IMG_2043.JPG'>IMG_2043.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_2048.JPG' href='lamington.php?fileId=IMG_2048.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061201/IMG_2048.JPG' ALT='IMG_2048.JPG'><BR>IMG_2048.JPG<br>79.73 KB</a><div class='inv'><br><a href='./images/20061201/IMG_2048.JPG' ALT='IMG_2048.JPG'>IMG_2048.JPG</a></div></td>
<td><A ID='IMG_2051.JPG' href='lamington.php?fileId=IMG_2051.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061201/IMG_2051.JPG' ALT='IMG_2051.JPG'><BR>IMG_2051.JPG<br>75.91 KB</a><div class='inv'><br><a href='./images/20061201/IMG_2051.JPG' ALT='IMG_2051.JPG'>IMG_2051.JPG</a></div></td>
<td><A ID='IMG_2052.JPG' href='lamington.php?fileId=IMG_2052.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061201/IMG_2052.JPG' ALT='IMG_2052.JPG'><BR>IMG_2052.JPG<br>72.91 KB</a><div class='inv'><br><a href='./images/20061201/IMG_2052.JPG' ALT='IMG_2052.JPG'>IMG_2052.JPG</a></div></td>
<td><A ID='IMG_2053.JPG' href='lamington.php?fileId=IMG_2053.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061201/IMG_2053.JPG' ALT='IMG_2053.JPG'><BR>IMG_2053.JPG<br>68.26 KB</a><div class='inv'><br><a href='./images/20061201/IMG_2053.JPG' ALT='IMG_2053.JPG'>IMG_2053.JPG</a></div></td>
<td><A ID='IMG_2055.JPG' href='lamington.php?fileId=IMG_2055.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061201/IMG_2055.JPG' ALT='IMG_2055.JPG'><BR>IMG_2055.JPG<br>109.98 KB</a><div class='inv'><br><a href='./images/20061201/IMG_2055.JPG' ALT='IMG_2055.JPG'>IMG_2055.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_2058.JPG' href='lamington.php?fileId=IMG_2058.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061201/IMG_2058.JPG' ALT='IMG_2058.JPG'><BR>IMG_2058.JPG<br>63.57 KB</a><div class='inv'><br><a href='./images/20061201/IMG_2058.JPG' ALT='IMG_2058.JPG'>IMG_2058.JPG</a></div></td>
<td><A ID='IMG_2061.JPG' href='lamington.php?fileId=IMG_2061.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061201/IMG_2061.JPG' ALT='Regent Bower Bird'><BR>Regent Bower Bird<br>82.89 KB</a><div class='inv'><br><a href='./images/20061201/IMG_2061.JPG' ALT='Regent Bower Bird'>Regent Bower Bird</a></div></td>
<td><A ID='IMG_2062.JPG' href='lamington.php?fileId=IMG_2062.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061201/IMG_2062.JPG' ALT='Regent Bower Bird'><BR>Regent Bower Bird<br>78.55 KB</a><div class='inv'><br><a href='./images/20061201/IMG_2062.JPG' ALT='Regent Bower Bird'>Regent Bower Bird</a></div></td>
<td><A ID='IMG_2064.JPG' href='lamington.php?fileId=IMG_2064.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061201/IMG_2064.JPG' ALT='Regent Bower Bird'><BR>Regent Bower Bird<br>82.56 KB</a><div class='inv'><br><a href='./images/20061201/IMG_2064.JPG' ALT='Regent Bower Bird'>Regent Bower Bird</a></div></td>
<td><A ID='IMG_2066.JPG' href='lamington.php?fileId=IMG_2066.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061201/IMG_2066.JPG' ALT='Regent Bower Bird'><BR>Regent Bower Bird<br>69.02 KB</a><div class='inv'><br><a href='./images/20061201/IMG_2066.JPG' ALT='Regent Bower Bird'>Regent Bower Bird</a></div></td>
</tr>
<tr><td><A ID='IMG_2068.JPG' href='lamington.php?fileId=IMG_2068.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061201/IMG_2068.JPG' ALT='IMG_2068.JPG'><BR>IMG_2068.JPG<br>69.1 KB</a><div class='inv'><br><a href='./images/20061201/IMG_2068.JPG' ALT='IMG_2068.JPG'>IMG_2068.JPG</a></div></td>
<td><A ID='IMG_2072.JPG' href='lamington.php?fileId=IMG_2072.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061201/IMG_2072.JPG' ALT='Satin Bower Bird'><BR>Satin Bower Bird<br>48.35 KB</a><div class='inv'><br><a href='./images/20061201/IMG_2072.JPG' ALT='Satin Bower Bird'>Satin Bower Bird</a></div></td>
<td><A ID='IMG_2073.JPG' href='lamington.php?fileId=IMG_2073.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061201/IMG_2073.JPG' ALT='Satin Bower Bird'><BR>Satin Bower Bird<br>46.25 KB</a><div class='inv'><br><a href='./images/20061201/IMG_2073.JPG' ALT='Satin Bower Bird'>Satin Bower Bird</a></div></td>
<td><A ID='IMG_2077.JPG' href='lamington.php?fileId=IMG_2077.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061201/IMG_2077.JPG' ALT='IMG_2077.JPG'><BR>IMG_2077.JPG<br>96.75 KB</a><div class='inv'><br><a href='./images/20061201/IMG_2077.JPG' ALT='IMG_2077.JPG'>IMG_2077.JPG</a></div></td>
<td><A ID='IMG_2078.JPG' href='lamington.php?fileId=IMG_2078.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061201/IMG_2078.JPG' ALT='White Browed Scrub Wren'><BR>White Browed Scrub Wren<br>79.19 KB</a><div class='inv'><br><a href='./images/20061201/IMG_2078.JPG' ALT='White Browed Scrub Wren'>White Browed Scrub Wren</a></div></td>
</tr>
<tr><td><A ID='IMG_2081.JPG' href='lamington.php?fileId=IMG_2081.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061201/IMG_2081.JPG' ALT='White Browed Scrub Wren'><BR>White Browed Scrub Wren<br>68.08 KB</a><div class='inv'><br><a href='./images/20061201/IMG_2081.JPG' ALT='White Browed Scrub Wren'>White Browed Scrub Wren</a></div></td>
<td><A ID='IMG_2082.JPG' href='lamington.php?fileId=IMG_2082.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061201/IMG_2082.JPG' ALT='White Browed Scrub Wren'><BR>White Browed Scrub Wren<br>67.98 KB</a><div class='inv'><br><a href='./images/20061201/IMG_2082.JPG' ALT='White Browed Scrub Wren'>White Browed Scrub Wren</a></div></td>
<td><A ID='IMG_2083.JPG' href='lamington.php?fileId=IMG_2083.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061201/IMG_2083.JPG' ALT='White Browed Scrub Wren'><BR>White Browed Scrub Wren<br>68.14 KB</a><div class='inv'><br><a href='./images/20061201/IMG_2083.JPG' ALT='White Browed Scrub Wren'>White Browed Scrub Wren</a></div></td>
<td><A ID='IMG_2086.JPG' href='lamington.php?fileId=IMG_2086.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061201/IMG_2086.JPG' ALT='IMG_2086.JPG'><BR>IMG_2086.JPG<br>56.85 KB</a><div class='inv'><br><a href='./images/20061201/IMG_2086.JPG' ALT='IMG_2086.JPG'>IMG_2086.JPG</a></div></td>
<td><A ID='IMG_2093.JPG' href='lamington.php?fileId=IMG_2093.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061201/IMG_2093.JPG' ALT='Satin Bower Bird'><BR>Satin Bower Bird<br>54.24 KB</a><div class='inv'><br><a href='./images/20061201/IMG_2093.JPG' ALT='Satin Bower Bird'>Satin Bower Bird</a></div></td>
</tr>
<tr><td><A ID='IMG_2094.JPG' href='lamington.php?fileId=IMG_2094.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061201/IMG_2094.JPG' ALT='Satin Bower Bird'><BR>Satin Bower Bird<br>56.96 KB</a><div class='inv'><br><a href='./images/20061201/IMG_2094.JPG' ALT='Satin Bower Bird'>Satin Bower Bird</a></div></td>
<td><A ID='IMG_2096.JPG' href='lamington.php?fileId=IMG_2096.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061201/IMG_2096.JPG' ALT='Satin Bower Bird'><BR>Satin Bower Bird<br>58.41 KB</a><div class='inv'><br><a href='./images/20061201/IMG_2096.JPG' ALT='Satin Bower Bird'>Satin Bower Bird</a></div></td>
<td><A ID='IMG_2098.JPG' href='lamington.php?fileId=IMG_2098.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061201/IMG_2098.JPG' ALT='Satin Bower Bird'><BR>Satin Bower Bird<br>68.66 KB</a><div class='inv'><br><a href='./images/20061201/IMG_2098.JPG' ALT='Satin Bower Bird'>Satin Bower Bird</a></div></td>
<td><A ID='IMG_2100.JPG' href='lamington.php?fileId=IMG_2100.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061201/IMG_2100.JPG' ALT='IMG_2100.JPG'><BR>IMG_2100.JPG<br>59.77 KB</a><div class='inv'><br><a href='./images/20061201/IMG_2100.JPG' ALT='IMG_2100.JPG'>IMG_2100.JPG</a></div></td>
<td><A ID='IMG_2103.JPG' href='lamington.php?fileId=IMG_2103.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061201/IMG_2103.JPG' ALT='IMG_2103.JPG'><BR>IMG_2103.JPG<br>71.86 KB</a><div class='inv'><br><a href='./images/20061201/IMG_2103.JPG' ALT='IMG_2103.JPG'>IMG_2103.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_2105.JPG' href='lamington.php?fileId=IMG_2105.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061201/IMG_2105.JPG' ALT='Satin Bower Bird'><BR>Satin Bower Bird<br>66.84 KB</a><div class='inv'><br><a href='./images/20061201/IMG_2105.JPG' ALT='Satin Bower Bird'>Satin Bower Bird</a></div></td>
<td><A ID='IMG_2107.JPG' href='lamington.php?fileId=IMG_2107.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061201/IMG_2107.JPG' ALT='Satin Bower Bird'><BR>Satin Bower Bird<br>75.2 KB</a><div class='inv'><br><a href='./images/20061201/IMG_2107.JPG' ALT='Satin Bower Bird'>Satin Bower Bird</a></div></td>
<td><A ID='IMG_2109.JPG' href='lamington.php?fileId=IMG_2109.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061201/IMG_2109.JPG' ALT='IMG_2109.JPG'><BR>IMG_2109.JPG<br>100.83 KB</a><div class='inv'><br><a href='./images/20061201/IMG_2109.JPG' ALT='IMG_2109.JPG'>IMG_2109.JPG</a></div></td>
<td><A ID='IMG_2112.JPG' href='lamington.php?fileId=IMG_2112.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061201/IMG_2112.JPG' ALT='IMG_2112.JPG'><BR>IMG_2112.JPG<br>64.06 KB</a><div class='inv'><br><a href='./images/20061201/IMG_2112.JPG' ALT='IMG_2112.JPG'>IMG_2112.JPG</a></div></td>
<td><A ID='IMG_2113.JPG' href='lamington.php?fileId=IMG_2113.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061201/IMG_2113.JPG' ALT='IMG_2113.JPG'><BR>IMG_2113.JPG<br>83.78 KB</a><div class='inv'><br><a href='./images/20061201/IMG_2113.JPG' ALT='IMG_2113.JPG'>IMG_2113.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_2114.JPG' href='lamington.php?fileId=IMG_2114.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061201/IMG_2114.JPG' ALT='IMG_2114.JPG'><BR>IMG_2114.JPG<br>84.38 KB</a><div class='inv'><br><a href='./images/20061201/IMG_2114.JPG' ALT='IMG_2114.JPG'>IMG_2114.JPG</a></div></td>
<td><A ID='IMG_2120.JPG' href='lamington.php?fileId=IMG_2120.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061201/IMG_2120.JPG' ALT='IMG_2120.JPG'><BR>IMG_2120.JPG<br>117.37 KB</a><div class='inv'><br><a href='./images/20061201/IMG_2120.JPG' ALT='IMG_2120.JPG'>IMG_2120.JPG</a></div></td>
<td><A ID='IMG_2126.JPG' href='lamington.php?fileId=IMG_2126.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061201/IMG_2126.JPG' ALT='Satin Bower Bird'><BR>Satin Bower Bird<br>83.71 KB</a><div class='inv'><br><a href='./images/20061201/IMG_2126.JPG' ALT='Satin Bower Bird'>Satin Bower Bird</a></div></td>
<td><A ID='IMG_2133.JPG' href='lamington.php?fileId=IMG_2133.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061201/IMG_2133.JPG' ALT='IMG_2133.JPG'><BR>IMG_2133.JPG<br>99.67 KB</a><div class='inv'><br><a href='./images/20061201/IMG_2133.JPG' ALT='IMG_2133.JPG'>IMG_2133.JPG</a></div></td>
<td><A ID='IMG_2135.JPG' href='lamington.php?fileId=IMG_2135.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061201/IMG_2135.JPG' ALT='IMG_2135.JPG'><BR>IMG_2135.JPG<br>97.96 KB</a><div class='inv'><br><a href='./images/20061201/IMG_2135.JPG' ALT='IMG_2135.JPG'>IMG_2135.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_2136.JPG' href='lamington.php?fileId=IMG_2136.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061201/IMG_2136.JPG' ALT='IMG_2136.JPG'><BR>IMG_2136.JPG<br>95.5 KB</a><div class='inv'><br><a href='./images/20061201/IMG_2136.JPG' ALT='IMG_2136.JPG'>IMG_2136.JPG</a></div></td>
<td><A ID='IMG_2138.JPG' href='lamington.php?fileId=IMG_2138.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061201/IMG_2138.JPG' ALT='IMG_2138.JPG'><BR>IMG_2138.JPG<br>94.04 KB</a><div class='inv'><br><a href='./images/20061201/IMG_2138.JPG' ALT='IMG_2138.JPG'>IMG_2138.JPG</a></div></td>
<td><A ID='IMG_2144.JPG' href='lamington.php?fileId=IMG_2144.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061201/IMG_2144.JPG' ALT='IMG_2144.JPG'><BR>IMG_2144.JPG<br>48.51 KB</a><div class='inv'><br><a href='./images/20061201/IMG_2144.JPG' ALT='IMG_2144.JPG'>IMG_2144.JPG</a></div></td>
<td><A ID='IMG_2145.JPG' href='lamington.php?fileId=IMG_2145.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061201/IMG_2145.JPG' ALT='IMG_2145.JPG'><BR>IMG_2145.JPG<br>73.49 KB</a><div class='inv'><br><a href='./images/20061201/IMG_2145.JPG' ALT='IMG_2145.JPG'>IMG_2145.JPG</a></div></td>
<td><A ID='IMG_2146.JPG' href='lamington.php?fileId=IMG_2146.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061201/IMG_2146.JPG' ALT='IMG_2146.JPG'><BR>IMG_2146.JPG<br>74.04 KB</a><div class='inv'><br><a href='./images/20061201/IMG_2146.JPG' ALT='IMG_2146.JPG'>IMG_2146.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_2150.JPG' href='lamington.php?fileId=IMG_2150.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061201/IMG_2150.JPG' ALT='IMG_2150.JPG'><BR>IMG_2150.JPG<br>73.01 KB</a><div class='inv'><br><a href='./images/20061201/IMG_2150.JPG' ALT='IMG_2150.JPG'>IMG_2150.JPG</a></div></td>
<td><A ID='IMG_2152.JPG' href='lamington.php?fileId=IMG_2152.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061201/IMG_2152.JPG' ALT='IMG_2152.JPG'><BR>IMG_2152.JPG<br>104.81 KB</a><div class='inv'><br><a href='./images/20061201/IMG_2152.JPG' ALT='IMG_2152.JPG'>IMG_2152.JPG</a></div></td>
<td><A ID='IMG_2154.JPG' href='lamington.php?fileId=IMG_2154.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061201/IMG_2154.JPG' ALT='IMG_2154.JPG'><BR>IMG_2154.JPG<br>101.33 KB</a><div class='inv'><br><a href='./images/20061201/IMG_2154.JPG' ALT='IMG_2154.JPG'>IMG_2154.JPG</a></div></td>
<td><A ID='IMG_2155.JPG' href='lamington.php?fileId=IMG_2155.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061201/IMG_2155.JPG' ALT='IMG_2155.JPG'><BR>IMG_2155.JPG<br>111.88 KB</a><div class='inv'><br><a href='./images/20061201/IMG_2155.JPG' ALT='IMG_2155.JPG'>IMG_2155.JPG</a></div></td>
<td><A ID='IMG_2156.JPG' href='lamington.php?fileId=IMG_2156.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061201/IMG_2156.JPG' ALT='IMG_2156.JPG'><BR>IMG_2156.JPG<br>127.53 KB</a><div class='inv'><br><a href='./images/20061201/IMG_2156.JPG' ALT='IMG_2156.JPG'>IMG_2156.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_2160.JPG' href='lamington.php?fileId=IMG_2160.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061201/IMG_2160.JPG' ALT='IMG_2160.JPG'><BR>IMG_2160.JPG<br>58.04 KB</a><div class='inv'><br><a href='./images/20061201/IMG_2160.JPG' ALT='IMG_2160.JPG'>IMG_2160.JPG</a></div></td>
<td><A ID='IMG_2163.JPG' href='lamington.php?fileId=IMG_2163.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061201/IMG_2163.JPG' ALT='IMG_2163.JPG'><BR>IMG_2163.JPG<br>87.06 KB</a><div class='inv'><br><a href='./images/20061201/IMG_2163.JPG' ALT='IMG_2163.JPG'>IMG_2163.JPG</a></div></td>
<td><A ID='IMG_2177.JPG' href='lamington.php?fileId=IMG_2177.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061201/IMG_2177.JPG' ALT='IMG_2177.JPG'><BR>IMG_2177.JPG<br>76.33 KB</a><div class='inv'><br><a href='./images/20061201/IMG_2177.JPG' ALT='IMG_2177.JPG'>IMG_2177.JPG</a></div></td>
<td><A ID='IMG_2180.JPG' href='lamington.php?fileId=IMG_2180.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061201/IMG_2180.JPG' ALT='IMG_2180.JPG'><BR>IMG_2180.JPG<br>50.92 KB</a><div class='inv'><br><a href='./images/20061201/IMG_2180.JPG' ALT='IMG_2180.JPG'>IMG_2180.JPG</a></div></td>
<td><A ID='IMG_2182.JPG' href='lamington.php?fileId=IMG_2182.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061201/IMG_2182.JPG' ALT='IMG_2182.JPG'><BR>IMG_2182.JPG<br>51.05 KB</a><div class='inv'><br><a href='./images/20061201/IMG_2182.JPG' ALT='IMG_2182.JPG'>IMG_2182.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_2184.JPG' href='lamington.php?fileId=IMG_2184.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061201/IMG_2184.JPG' ALT='IMG_2184.JPG'><BR>IMG_2184.JPG<br>88.1 KB</a><div class='inv'><br><a href='./images/20061201/IMG_2184.JPG' ALT='IMG_2184.JPG'>IMG_2184.JPG</a></div></td>
<td><A ID='IMG_2186.JPG' href='lamington.php?fileId=IMG_2186.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061201/IMG_2186.JPG' ALT='IMG_2186.JPG'><BR>IMG_2186.JPG<br>98.65 KB</a><div class='inv'><br><a href='./images/20061201/IMG_2186.JPG' ALT='IMG_2186.JPG'>IMG_2186.JPG</a></div></td>
<td><A ID='IMG_2197.JPG' href='lamington.php?fileId=IMG_2197.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061201/IMG_2197.JPG' ALT='IMG_2197.JPG'><BR>IMG_2197.JPG<br>50.85 KB</a><div class='inv'><br><a href='./images/20061201/IMG_2197.JPG' ALT='IMG_2197.JPG'>IMG_2197.JPG</a></div></td>
<td><A ID='IMG_2206.JPG' href='lamington.php?fileId=IMG_2206.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061201/IMG_2206.JPG' ALT='IMG_2206.JPG'><BR>IMG_2206.JPG<br>60.23 KB</a><div class='inv'><br><a href='./images/20061201/IMG_2206.JPG' ALT='IMG_2206.JPG'>IMG_2206.JPG</a></div></td>
<td><A ID='IMG_2210.JPG' href='lamington.php?fileId=IMG_2210.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061201/IMG_2210.JPG' ALT='IMG_2210.JPG'><BR>IMG_2210.JPG<br>59.27 KB</a><div class='inv'><br><a href='./images/20061201/IMG_2210.JPG' ALT='IMG_2210.JPG'>IMG_2210.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_2211.JPG' href='lamington.php?fileId=IMG_2211.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061201/IMG_2211.JPG' ALT='IMG_2211.JPG'><BR>IMG_2211.JPG<br>58.58 KB</a><div class='inv'><br><a href='./images/20061201/IMG_2211.JPG' ALT='IMG_2211.JPG'>IMG_2211.JPG</a></div></td>
<td><A ID='IMG_2221.JPG' href='lamington.php?fileId=IMG_2221.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20061201/IMG_2221.JPG' ALT='IMG_2221.JPG'><BR>IMG_2221.JPG<br>59.36 KB</a><div class='inv'><br><a href='./images/20061201/IMG_2221.JPG' ALT='IMG_2221.JPG'>IMG_2221.JPG</a></div></td>
</tr>
</table>	</div>
</div>
</body>
</html>