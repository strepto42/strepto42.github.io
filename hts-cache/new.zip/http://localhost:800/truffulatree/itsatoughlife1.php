<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - 17/5/2005 - It's a tough life (pt 1: Bundaberg, Agnes Water and 1770)</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="It's a tough life (pt 1: Bundaberg, Agnes Water and 1770)">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="Greetings from a Bum" href='greetingsfromabum.php'>29/4/2005</a></li>
<li><a title="Onward" href='onward.php'>2/5/2005</a></li>
<li><div class='activemenu'>17/5/2005</div></li>
<li><a title="It's a tough life (pt 2: Rockhampton, Emu Park and Great Keppel Island)" href='itsatoughlife2.php'>23/5/2005</a></li>
<li><a title="There and Back Again - a Yo-yo's Tale" href='thereandbackagain.php'>18/6/2005</a></li>
<li><a title="Platypi and Grey Nomads" href='platypiandgreynomads.php'>24/6/2005</a></li>
<li><a title="Blowing Bubbles in a Watery Tomb" href='blowingbubbles.php'>1/7/2005</a></li>
<li><a title="Pieces of History" href='piecesofhistory.php'>8/7/2005</a></li>
<li><a title="Walks and Waterfalls" href='walksandwaterfalls.php'>15/7/2005</a></li>
<li><a title="Mission to Tribulation" href='missiontotribulation.php'>22/7/2005</a></li>
<li><a title="Levity, Limestone and Lava" href='levitylimestoneandlava.php'>29/7/2005</a></li>
<li><a title="Into the Never Never" href='intothenevernever.php'>5/8/2005</a></li>
<li><a title="Slowing the pace in Darwin" href='slowingthepaceindarwin.php'>12/8/2005</a></li>
<li><a title="Blistering Barnacles and Leaping Lizards" href='leapinglizards.php'>19/8/2005</a></li>
<li><a title="Kakadu and Litchfield" href='kakadu.php'>26/8/2005</a></li>
<li><a title="Legacies of War" href='legaciesofwar.php'>2/9/2005</a></li>
<li><a title="Go West" href='gowest.php'>10/9/2005</a></li>
<li><a title="Things from Above" href='thingsfromabove.php'>16/9/2005</a></li>
<li><a title="The West Coast" href='thewestcoast.php'>23/9/2005</a></li>
<li><a title="Reefs and Red Dust" href='reefsandreddust.php'>30/9/2005</a></li>
<li><a title="The Pilbara" href='pilbara.php'>7/10/2005</a></li>
<li><a title="Paradise with a Headwind" href='paradisewithaheadwind.php'>14/10/2005</a></li>
<li><a title="Down the Coral Coast" href='downthecoralcoast.php'>21/10/2005</a></li>
<li><a title="Pinnacles and Pinnipeds" href='pinnaclesandpinnipeds.php'>28/10/2005</a></li>
<li><a title="A week in Perth" href='perth.php'>4/11/2005</a></li>
<li><a title="The Southwest (from Above and Below)" href='thesouthwest.php'>11/11/2005</a></li>
<li><a title="More Heights and Depths" href='moreheightsanddepths.php'>18/11/2005</a></li>
<li><a title="Across the Nullarbor (and a bit beyond)" href='nullarbor.php'>25/11/2005</a></li>
<li><a title="Double Whammy" href='doublewhammy.php'>9/12/2005</a></li>
<li><a title="Two Cities" href='twocities.php'>19/12/2005</a></li>
<li><a title="Tassie - Part 1" href='tassie1.php'>1/1/2006</a></li>
<li><a title="Tassie - Part 2" href='tassie2.php'>7/1/2006</a></li>
<li><a title="Full Circle" href='fullcircle.php'>26/1/2006</a></li>
<li><a title="The Wrap Up" href='thewrapup.php'>23/3/2006</a></li>
<li> </li><br><li>Or go back to:</li><li><a title='Travelouges and blogs from my trip around Australia' href="nerdseyeview.php">Nerd's Eye View</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>17/5/2005</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Travel stories and pictures' href="travel.php">Travelogues</a> > <a title='Travelouges and blogs from my trip around Australia' href="nerdseyeview.php">Nerd's Eye View</a> > <a title='It's a tough life (pt 1: Bundaberg, Agnes Water and 1770)' href="itsatoughlife1.php">17/5/2005</a>
<br><br>		


<h1>It's a tough life (pt 1: Bundaberg, Agnes Water and 1770)</h1>

<a href="images/maps/Map050517.gif"><img src="images/maps/Map050517_sm.gif" align="right"></a>
<p>I've been a little slack on the email front lately, so it's time I played catch up.</p>

<p>I last left off at Rainbow beach. After getting eaten by mozzies and sandflies at the caravan park, I moved to the YHA. It was nice to have a "proper" bed and a few people to talk to.</p>

<p>I was going to try and do some diving, but the weather turned lousy, and in the end it set in for several days, so it didn't happen.</p>

<p>So basically I had a fairly quiet couple of days there. I rode the bike around during the day, and had a few beers in the evening.</p>

<p>After that I headed to Bundaberg. I wasn't expecting much, after hearing Nathan's descriptions of the place (he grew up there, and used a lot of expletives describing it), and therefore I wasn't disappointed. The hostel there was full of muddy shoes and their tired looking backpackers (who had been fruit picking all day). And when I say full, it was full full; so I picked a caravan park and stayed there.</p>

<p>All up the most exciting thing that happened in Bundy was to visit a net cafe with free tea and coffee, and a bare concrete floor. Nice.</p>

<p>I'd also given up on ever using my dialup account, so I did some research and picked up a CDMA modem for my laptop, so I can get online pretty much anywhere where there is mobile reception. It's a little dear to run, but works well, and it works out cheaper than using net cafes.</p>

<p>While I'm on the subject � a few people have recently sent me enormous emails. Please � don't. For anything above 500-600k or so, just chuck it on the web and send me the link, so I can download it piecemeal in my own time. Now that you've been warned, I shall be administering tocks on the forehead with a teaspoon to any offenders when I next see them.</p>

<p>After Bundy I headed north again, to a town called Agnes Water, just next to another town called 1770, which is the named after the year Captain Cook landed there and "discovered" Queensland. For the 1337 nerds out there, no, it's not pronounced "leeo". :)</p>

<p>A few people I'd met had recommended this part of the world to me as being nice, and they weren't wrong. It's fairly removed from the beaten track, but becoming increasingly developed. There are, however, national parks all around the place, so development is going to be limited.</p>

<p>I checked into a hostel called Cool Bananas. It was recommended by the Lonely Planet as being new, clean and chilled of atmosphere, and indeed it was. I was originally going to stay for two or three days, but in the end I decided to stay for 10 and get my Advanced Open Water PADI certification.</p>

<p>The so called advanced diving course isn't really; it's just basically a series of dives that extend slightly what you learn in the basic course, but it's fun. All up I did a night dive (actually, I did a couple), a drift dive where you cruise lazily with the current, an underwater navigation dive (swimming in squares with a compass - woo), and a couple of wreck dives, including a deep dive, more about which later.</p>

<p>The night dives were a lot of fun � I didn't see much on the first one, but as it was my first dive in a while it was just good to get back underwater. The second one was great � there was a thunderstorm at the time, and we could see flashes of lightning and hear the rain on the surface when we were under. It was also quite an experience wading out into the water with all the gear on and lightning flashing in the distance. It also turned out to be an excellent Octopus viewing dive - I lost count of how many I saw. We even saw two have a bit of a fight, tentacles writhing everywhere and bodies changing colour. They're pretty bizarre creatures. Also saw a sleeping turtle.</p>

<p>The drift dive was pretty cool too. The highlight was seeing a school of Barracuda. I never realised quite how big they are � a good 1-2m in length. I also saw a turtle which excited me at the time, as I really love them. Now I'm somewhat turtled out � more about that later.</p>

<p>Anyway, all those dives were done in the estuary at 1770. They were nice, but not exactly the most exciting diving in the world. Nor were they particularly deep either, only about 6-9m depending on the tide.</p>

<p>The dives that I was really looking forward to were out at the wreck of a boat called the Karma. It's a big cargo vessel, and it's only been down for about 18 months, but it's already teeming with life.</p>

<p>The only problem is that getting out there can be a bit iffy, as the conditions have to be really good. Thankfully we managed it, and lucked in with a near-perfect day. The underwater visibility was amazing - 25-30 metres (which is fantastic, for you non-divers). :) The wreck is in about 25m of water but is a good 15m high in places (it was a fairly big cargo boat). The vis was so good that we could see it from the surface. Check out <a href="http://www.1770underseaadventures.com/Undersea/Photo.html" target="_blank">http://www.1770underseaadventures.com/Undersea/Photo.html</a> for some pics that actually don't show much at all. :)</p>

<p>Anyway, we did two dives, the first one deep and the second one not so deep. Both were amazing. Tim � we have to do this dive sometime. I reckon you'll need to wear a brown wetsuit. :) There were thousands of fish everywhere, from the very tiny to the rather large. I have this mental snapshot of another diver with a school of golden 1m long fish behind him, and the wreck in the foreground.</p>

<p>Apart from the diving, my stay at Cool Bananas was pretty nice. We spent most nights sitting round a fire outside, drinking beers and belting out various songs on guitar. There were a few regulars there, including a couple of Irish guys who seemed to know most of the Beatles back catalogue. (See attached photo).</p>

<p>I also spent one evening learning to take photos of the sunset. Hence the million and one sunset shots on my website. :)</p>

<p>There was also this slightly crazy local guy who comes around doing free facials with some clay and herb mix, which is fine and nice (it actually works rather well), but he it also full of insane ideas, like ciggies being grown with radioactive waste fertiliser, and that�s why they cause cancer. Clay is also apparently the cure for everything, as it draws the radiation out of your body with electromagnetism. And don't even get him started on the New World Order. Daniel, you would love this guy. The strange thing is, he is a mixture of quite down to earth sensibility and real knowledge, but with some really fruity ideas thrown in.</p>

<p><a href="itsatoughlife2.php">Continued...</a></p>


<br><br>
All images in this gallery:<br>
<table width='800'>
<tr>
</tr>
<tr><td><A ID='IMG_2139.JPG' href='itsatoughlife1.php?fileId=IMG_2139.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050517/IMG_2139.JPG' ALT='Bundaberg from the caravan park in the evening'><BR>Bundaberg from the caravan park in the evening<br>55.47 KB</a><div class='inv'><br><a href='./images/20050517/IMG_2139.JPG' ALT='Bundaberg from the caravan park in the evening'>Bundaberg from the caravan park in the evening</a></div></td>
<td><A ID='IMG_2149.JPG' href='itsatoughlife1.php?fileId=IMG_2149.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050517/IMG_2149.JPG' ALT='Random arty shot in Anges Water'><BR>Random arty shot in Anges Water<br>86.48 KB</a><div class='inv'><br><a href='./images/20050517/IMG_2149.JPG' ALT='Random arty shot in Anges Water'>Random arty shot in Anges Water</a></div></td>
<td><A ID='IMG_2150.JPG' href='itsatoughlife1.php?fileId=IMG_2150.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050517/IMG_2150.JPG' ALT='Town of 1770'><BR>Town of 1770<br>48.78 KB</a><div class='inv'><br><a href='./images/20050517/IMG_2150.JPG' ALT='Town of 1770'>Town of 1770</a></div></td>
<td><A ID='IMG_2151.JPG' href='itsatoughlife1.php?fileId=IMG_2151.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050517/IMG_2151.JPG' ALT='Town of 1770'><BR>Town of 1770<br>54.97 KB</a><div class='inv'><br><a href='./images/20050517/IMG_2151.JPG' ALT='Town of 1770'>Town of 1770</a></div></td>
<td><A ID='IMG_2152.JPG' href='itsatoughlife1.php?fileId=IMG_2152.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050517/IMG_2152.JPG' ALT='Town of 1770'><BR>Town of 1770<br>51.67 KB</a><div class='inv'><br><a href='./images/20050517/IMG_2152.JPG' ALT='Town of 1770'>Town of 1770</a></div></td>
</tr>
<tr><td><A ID='IMG_2155.JPG' href='itsatoughlife1.php?fileId=IMG_2155.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050517/IMG_2155.JPG' ALT='Monumen to Captain Cook, Town of 1770'><BR>Monumen to Captain Cook, Town of 1770<br>75.03 KB</a><div class='inv'><br><a href='./images/20050517/IMG_2155.JPG' ALT='Monumen to Captain Cook, Town of 1770'>Monumen to Captain Cook, Town of 1770</a></div></td>
<td><A ID='IMG_2156.JPG' href='itsatoughlife1.php?fileId=IMG_2156.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050517/IMG_2156.JPG' ALT='Town of 1770'><BR>Town of 1770<br>71.94 KB</a><div class='inv'><br><a href='./images/20050517/IMG_2156.JPG' ALT='Town of 1770'>Town of 1770</a></div></td>
<td><A ID='IMG_2157.JPG' href='itsatoughlife1.php?fileId=IMG_2157.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050517/IMG_2157.JPG' ALT='Town of 1770'><BR>Town of 1770<br>63.69 KB</a><div class='inv'><br><a href='./images/20050517/IMG_2157.JPG' ALT='Town of 1770'>Town of 1770</a></div></td>
<td><A ID='IMG_2158.JPG' href='itsatoughlife1.php?fileId=IMG_2158.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050517/IMG_2158.JPG' ALT='Town of 1770'><BR>Town of 1770<br>69.16 KB</a><div class='inv'><br><a href='./images/20050517/IMG_2158.JPG' ALT='Town of 1770'>Town of 1770</a></div></td>
<td><A ID='IMG_2159.JPG' href='itsatoughlife1.php?fileId=IMG_2159.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050517/IMG_2159.JPG' ALT='Town of 1770'><BR>Town of 1770<br>83.45 KB</a><div class='inv'><br><a href='./images/20050517/IMG_2159.JPG' ALT='Town of 1770'>Town of 1770</a></div></td>
</tr>
<tr><td><A ID='IMG_2163.JPG' href='itsatoughlife1.php?fileId=IMG_2163.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050517/IMG_2163.JPG' ALT='Workman's Beach, Anges Water'><BR>Workman's Beach, Anges Water<br>44.9 KB</a><div class='inv'><br><a href='./images/20050517/IMG_2163.JPG' ALT='Workman's Beach, Anges Water'>Workman's Beach, Anges Water</a></div></td>
<td><A ID='IMG_2164.JPG' href='itsatoughlife1.php?fileId=IMG_2164.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050517/IMG_2164.JPG' ALT='Workman's Beach, Anges Water'><BR>Workman's Beach, Anges Water<br>54.23 KB</a><div class='inv'><br><a href='./images/20050517/IMG_2164.JPG' ALT='Workman's Beach, Anges Water'>Workman's Beach, Anges Water</a></div></td>
<td><A ID='IMG_2165.JPG' href='itsatoughlife1.php?fileId=IMG_2165.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050517/IMG_2165.JPG' ALT='Workman's Beach, Anges Water'><BR>Workman's Beach, Anges Water<br>75.7 KB</a><div class='inv'><br><a href='./images/20050517/IMG_2165.JPG' ALT='Workman's Beach, Anges Water'>Workman's Beach, Anges Water</a></div></td>
<td><A ID='IMG_2173.JPG' href='itsatoughlife1.php?fileId=IMG_2173.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050517/IMG_2173.JPG' ALT='Workman's Beach, Anges Water'><BR>Workman's Beach, Anges Water<br>69.36 KB</a><div class='inv'><br><a href='./images/20050517/IMG_2173.JPG' ALT='Workman's Beach, Anges Water'>Workman's Beach, Anges Water</a></div></td>
<td><A ID='IMG_2176.JPG' href='itsatoughlife1.php?fileId=IMG_2176.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050517/IMG_2176.JPG' ALT='Drinks at Cool Bananas'><BR>Drinks at Cool Bananas<br>44.89 KB</a><div class='inv'><br><a href='./images/20050517/IMG_2176.JPG' ALT='Drinks at Cool Bananas'>Drinks at Cool Bananas</a></div></td>
</tr>
<tr><td><A ID='IMG_2178.JPG' href='itsatoughlife1.php?fileId=IMG_2178.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050517/IMG_2178.JPG' ALT='Drinks at Cool Bananas'><BR>Drinks at Cool Bananas<br>42.23 KB</a><div class='inv'><br><a href='./images/20050517/IMG_2178.JPG' ALT='Drinks at Cool Bananas'>Drinks at Cool Bananas</a></div></td>
<td><A ID='IMG_2180.JPG' href='itsatoughlife1.php?fileId=IMG_2180.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050517/IMG_2180.JPG' ALT='Bettina and Carlos, Cool Bananas'><BR>Bettina and Carlos, Cool Bananas<br>52.12 KB</a><div class='inv'><br><a href='./images/20050517/IMG_2180.JPG' ALT='Bettina and Carlos, Cool Bananas'>Bettina and Carlos, Cool Bananas</a></div></td>
<td><A ID='IMG_2181.JPG' href='itsatoughlife1.php?fileId=IMG_2181.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050517/IMG_2181.JPG' ALT='Johnny, Cool Bananas'><BR>Johnny, Cool Bananas<br>44.84 KB</a><div class='inv'><br><a href='./images/20050517/IMG_2181.JPG' ALT='Johnny, Cool Bananas'>Johnny, Cool Bananas</a></div></td>
<td><A ID='IMG_2183.JPG' href='itsatoughlife1.php?fileId=IMG_2183.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050517/IMG_2183.JPG' ALT='Drinks at Cool Bananas'><BR>Drinks at Cool Bananas<br>39.47 KB</a><div class='inv'><br><a href='./images/20050517/IMG_2183.JPG' ALT='Drinks at Cool Bananas'>Drinks at Cool Bananas</a></div></td>
<td><A ID='IMG_2186.JPG' href='itsatoughlife1.php?fileId=IMG_2186.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050517/IMG_2186.JPG' ALT='Drinks at Cool Bananas'><BR>Drinks at Cool Bananas<br>69.19 KB</a><div class='inv'><br><a href='./images/20050517/IMG_2186.JPG' ALT='Drinks at Cool Bananas'>Drinks at Cool Bananas</a></div></td>
</tr>
<tr><td><A ID='IMG_2189.JPG' href='itsatoughlife1.php?fileId=IMG_2189.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050517/IMG_2189.JPG' ALT='Baby grasshopper, Cool Bananas'><BR>Baby grasshopper, Cool Bananas<br>38.35 KB</a><div class='inv'><br><a href='./images/20050517/IMG_2189.JPG' ALT='Baby grasshopper, Cool Bananas'>Baby grasshopper, Cool Bananas</a></div></td>
<td><A ID='IMG_2191.JPG' href='itsatoughlife1.php?fileId=IMG_2191.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050517/IMG_2191.JPG' ALT='Jamming around the fire, Cool Bananas'><BR>Jamming around the fire, Cool Bananas<br>52.09 KB</a><div class='inv'><br><a href='./images/20050517/IMG_2191.JPG' ALT='Jamming around the fire, Cool Bananas'>Jamming around the fire, Cool Bananas</a></div></td>
<td><A ID='IMG_2192.JPG' href='itsatoughlife1.php?fileId=IMG_2192.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050517/IMG_2192.JPG' ALT='Jamming around the fire, Cool Bananas'><BR>Jamming around the fire, Cool Bananas<br>47.95 KB</a><div class='inv'><br><a href='./images/20050517/IMG_2192.JPG' ALT='Jamming around the fire, Cool Bananas'>Jamming around the fire, Cool Bananas</a></div></td>
<td><A ID='IMG_2195.JPG' href='itsatoughlife1.php?fileId=IMG_2195.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050517/IMG_2195.JPG' ALT='Jamming around the fire, Cool Bananas'><BR>Jamming around the fire, Cool Bananas<br>58.33 KB</a><div class='inv'><br><a href='./images/20050517/IMG_2195.JPG' ALT='Jamming around the fire, Cool Bananas'>Jamming around the fire, Cool Bananas</a></div></td>
<td><A ID='IMG_2197.JPG' href='itsatoughlife1.php?fileId=IMG_2197.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050517/IMG_2197.JPG' ALT='Jamming around the fire, Cool Bananas'><BR>Jamming around the fire, Cool Bananas<br>64.84 KB</a><div class='inv'><br><a href='./images/20050517/IMG_2197.JPG' ALT='Jamming around the fire, Cool Bananas'>Jamming around the fire, Cool Bananas</a></div></td>
</tr>
<tr><td><A ID='IMG_2198.JPG' href='itsatoughlife1.php?fileId=IMG_2198.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050517/IMG_2198.JPG' ALT='Jamming around the fire, Cool Bananas'><BR>Jamming around the fire, Cool Bananas<br>56.23 KB</a><div class='inv'><br><a href='./images/20050517/IMG_2198.JPG' ALT='Jamming around the fire, Cool Bananas'>Jamming around the fire, Cool Bananas</a></div></td>
<td><A ID='IMG_2199.JPG' href='itsatoughlife1.php?fileId=IMG_2199.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050517/IMG_2199.JPG' ALT='Jamming around the fire, Cool Bananas'><BR>Jamming around the fire, Cool Bananas<br>58.81 KB</a><div class='inv'><br><a href='./images/20050517/IMG_2199.JPG' ALT='Jamming around the fire, Cool Bananas'>Jamming around the fire, Cool Bananas</a></div></td>
<td><A ID='IMG_2205.JPG' href='itsatoughlife1.php?fileId=IMG_2205.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050517/IMG_2205.JPG' ALT='Jamming around the fire, Cool Bananas'><BR>Jamming around the fire, Cool Bananas<br>65.06 KB</a><div class='inv'><br><a href='./images/20050517/IMG_2205.JPG' ALT='Jamming around the fire, Cool Bananas'>Jamming around the fire, Cool Bananas</a></div></td>
<td><A ID='IMG_2207.JPG' href='itsatoughlife1.php?fileId=IMG_2207.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050517/IMG_2207.JPG' ALT='Jamming around the fire, Cool Bananas'><BR>Jamming around the fire, Cool Bananas<br>37.36 KB</a><div class='inv'><br><a href='./images/20050517/IMG_2207.JPG' ALT='Jamming around the fire, Cool Bananas'>Jamming around the fire, Cool Bananas</a></div></td>
<td><A ID='IMG_2209.JPG' href='itsatoughlife1.php?fileId=IMG_2209.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050517/IMG_2209.JPG' ALT='Jamming around the fire, Cool Bananas'><BR>Jamming around the fire, Cool Bananas<br>42.26 KB</a><div class='inv'><br><a href='./images/20050517/IMG_2209.JPG' ALT='Jamming around the fire, Cool Bananas'>Jamming around the fire, Cool Bananas</a></div></td>
</tr>
<tr><td><A ID='IMG_2210.JPG' href='itsatoughlife1.php?fileId=IMG_2210.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050517/IMG_2210.JPG' ALT='Jamming around the fire, Cool Bananas'><BR>Jamming around the fire, Cool Bananas<br>46.06 KB</a><div class='inv'><br><a href='./images/20050517/IMG_2210.JPG' ALT='Jamming around the fire, Cool Bananas'>Jamming around the fire, Cool Bananas</a></div></td>
<td><A ID='IMG_2211.JPG' href='itsatoughlife1.php?fileId=IMG_2211.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050517/IMG_2211.JPG' ALT='Jamming around the fire, Cool Bananas'><BR>Jamming around the fire, Cool Bananas<br>41.62 KB</a><div class='inv'><br><a href='./images/20050517/IMG_2211.JPG' ALT='Jamming around the fire, Cool Bananas'>Jamming around the fire, Cool Bananas</a></div></td>
<td><A ID='IMG_2216.JPG' href='itsatoughlife1.php?fileId=IMG_2216.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050517/IMG_2216.JPG' ALT='Jamming around the fire, Cool Bananas'><BR>Jamming around the fire, Cool Bananas<br>65.59 KB</a><div class='inv'><br><a href='./images/20050517/IMG_2216.JPG' ALT='Jamming around the fire, Cool Bananas'>Jamming around the fire, Cool Bananas</a></div></td>
<td><A ID='IMG_2218.JPG' href='itsatoughlife1.php?fileId=IMG_2218.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050517/IMG_2218.JPG' ALT='Rainbow'><BR>Rainbow<br>32.33 KB</a><div class='inv'><br><a href='./images/20050517/IMG_2218.JPG' ALT='Rainbow'>Rainbow</a></div></td>
<td><A ID='IMG_2220.JPG' href='itsatoughlife1.php?fileId=IMG_2220.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050517/IMG_2220.JPG' ALT='Out the back of Cool Bananas'><BR>Out the back of Cool Bananas<br>82.09 KB</a><div class='inv'><br><a href='./images/20050517/IMG_2220.JPG' ALT='Out the back of Cool Bananas'>Out the back of Cool Bananas</a></div></td>
</tr>
<tr><td><A ID='IMG_2225.JPG' href='itsatoughlife1.php?fileId=IMG_2225.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050517/IMG_2225.JPG' ALT='Pretty sky, Agnes Water'><BR>Pretty sky, Agnes Water<br>77.54 KB</a><div class='inv'><br><a href='./images/20050517/IMG_2225.JPG' ALT='Pretty sky, Agnes Water'>Pretty sky, Agnes Water</a></div></td>
<td><A ID='IMG_2226.JPG' href='itsatoughlife1.php?fileId=IMG_2226.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050517/IMG_2226.JPG' ALT='Bettina playing barmaid'><BR>Bettina playing barmaid<br>74.88 KB</a><div class='inv'><br><a href='./images/20050517/IMG_2226.JPG' ALT='Bettina playing barmaid'>Bettina playing barmaid</a></div></td>
<td><A ID='IMG_2227.JPG' href='itsatoughlife1.php?fileId=IMG_2227.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050517/IMG_2227.JPG' ALT='Yvonne, yours truly and Dave'><BR>Yvonne, yours truly and Dave<br>73.18 KB</a><div class='inv'><br><a href='./images/20050517/IMG_2227.JPG' ALT='Yvonne, yours truly and Dave'>Yvonne, yours truly and Dave</a></div></td>
<td><A ID='IMG_2230.JPG' href='itsatoughlife1.php?fileId=IMG_2230.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050517/IMG_2230.JPG' ALT='Pete and Mateas'><BR>Pete and Mateas<br>48.2 KB</a><div class='inv'><br><a href='./images/20050517/IMG_2230.JPG' ALT='Pete and Mateas'>Pete and Mateas</a></div></td>
<td><A ID='IMG_2232.JPG' href='itsatoughlife1.php?fileId=IMG_2232.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050517/IMG_2232.JPG' ALT='Drinks at Cool Bananas'><BR>Drinks at Cool Bananas<br>77.72 KB</a><div class='inv'><br><a href='./images/20050517/IMG_2232.JPG' ALT='Drinks at Cool Bananas'>Drinks at Cool Bananas</a></div></td>
</tr>
<tr><td><A ID='IMG_2233.JPG' href='itsatoughlife1.php?fileId=IMG_2233.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050517/IMG_2233.JPG' ALT='Drinks at Cool Bananas'><BR>Drinks at Cool Bananas<br>78.34 KB</a><div class='inv'><br><a href='./images/20050517/IMG_2233.JPG' ALT='Drinks at Cool Bananas'>Drinks at Cool Bananas</a></div></td>
<td><A ID='IMG_2236.JPG' href='itsatoughlife1.php?fileId=IMG_2236.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050517/IMG_2236.JPG' ALT='Don and Mateas'><BR>Don and Mateas<br>65.77 KB</a><div class='inv'><br><a href='./images/20050517/IMG_2236.JPG' ALT='Don and Mateas'>Don and Mateas</a></div></td>
<td><A ID='IMG_2237.JPG' href='itsatoughlife1.php?fileId=IMG_2237.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050517/IMG_2237.JPG' ALT='Pete, Prue and Yvonne'><BR>Pete, Prue and Yvonne<br>76.45 KB</a><div class='inv'><br><a href='./images/20050517/IMG_2237.JPG' ALT='Pete, Prue and Yvonne'>Pete, Prue and Yvonne</a></div></td>
<td><A ID='IMG_2238.JPG' href='itsatoughlife1.php?fileId=IMG_2238.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050517/IMG_2238.JPG' ALT='Bettina and Johnny'><BR>Bettina and Johnny<br>73.81 KB</a><div class='inv'><br><a href='./images/20050517/IMG_2238.JPG' ALT='Bettina and Johnny'>Bettina and Johnny</a></div></td>
<td><A ID='IMG_2241.JPG' href='itsatoughlife1.php?fileId=IMG_2241.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050517/IMG_2241.JPG' ALT='The evening's clutch of guitars'><BR>The evening's clutch of guitars<br>89.38 KB</a><div class='inv'><br><a href='./images/20050517/IMG_2241.JPG' ALT='The evening's clutch of guitars'>The evening's clutch of guitars</a></div></td>
</tr>
<tr><td><A ID='IMG_2242.JPG' href='itsatoughlife1.php?fileId=IMG_2242.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050517/IMG_2242.JPG' ALT='Yvonne'><BR>Yvonne<br>49.66 KB</a><div class='inv'><br><a href='./images/20050517/IMG_2242.JPG' ALT='Yvonne'>Yvonne</a></div></td>
<td><A ID='IMG_2243.JPG' href='itsatoughlife1.php?fileId=IMG_2243.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050517/IMG_2243.JPG' ALT='Bettina and Johnny'><BR>Bettina and Johnny<br>52.84 KB</a><div class='inv'><br><a href='./images/20050517/IMG_2243.JPG' ALT='Bettina and Johnny'>Bettina and Johnny</a></div></td>
<td><A ID='IMG_2244.JPG' href='itsatoughlife1.php?fileId=IMG_2244.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050517/IMG_2244.JPG' ALT='Prue looking psychotic'><BR>Prue looking psychotic<br>63.66 KB</a><div class='inv'><br><a href='./images/20050517/IMG_2244.JPG' ALT='Prue looking psychotic'>Prue looking psychotic</a></div></td>
<td><A ID='IMG_2245.JPG' href='itsatoughlife1.php?fileId=IMG_2245.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050517/IMG_2245.JPG' ALT='Yvonne and Mateas'><BR>Yvonne and Mateas<br>43.14 KB</a><div class='inv'><br><a href='./images/20050517/IMG_2245.JPG' ALT='Yvonne and Mateas'>Yvonne and Mateas</a></div></td>
<td><A ID='IMG_2246.JPG' href='itsatoughlife1.php?fileId=IMG_2246.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050517/IMG_2246.JPG' ALT='Prue'><BR>Prue<br>43.79 KB</a><div class='inv'><br><a href='./images/20050517/IMG_2246.JPG' ALT='Prue'>Prue</a></div></td>
</tr>
<tr><td><A ID='IMG_2250.JPG' href='itsatoughlife1.php?fileId=IMG_2250.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050517/IMG_2250.JPG' ALT='Yvonne and Dave'><BR>Yvonne and Dave<br>48.99 KB</a><div class='inv'><br><a href='./images/20050517/IMG_2250.JPG' ALT='Yvonne and Dave'>Yvonne and Dave</a></div></td>
<td><A ID='IMG_2252.JPG' href='itsatoughlife1.php?fileId=IMG_2252.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050517/IMG_2252.JPG' ALT='Various folks, Cool Bananas'><BR>Various folks, Cool Bananas<br>49.35 KB</a><div class='inv'><br><a href='./images/20050517/IMG_2252.JPG' ALT='Various folks, Cool Bananas'>Various folks, Cool Bananas</a></div></td>
<td><A ID='IMG_2254.JPG' href='itsatoughlife1.php?fileId=IMG_2254.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050517/IMG_2254.JPG' ALT='Beer and Lamp'><BR>Beer and Lamp<br>49.55 KB</a><div class='inv'><br><a href='./images/20050517/IMG_2254.JPG' ALT='Beer and Lamp'>Beer and Lamp</a></div></td>
<td><A ID='IMG_2260.JPG' href='itsatoughlife1.php?fileId=IMG_2260.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050517/IMG_2260.JPG' ALT='Prue, Bettina and Yvonne'><BR>Prue, Bettina and Yvonne<br>52.67 KB</a><div class='inv'><br><a href='./images/20050517/IMG_2260.JPG' ALT='Prue, Bettina and Yvonne'>Prue, Bettina and Yvonne</a></div></td>
<td><A ID='IMG_2269.JPG' href='itsatoughlife1.php?fileId=IMG_2269.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050517/IMG_2269.JPG' ALT='Claudia and I'><BR>Claudia and I<br>60.75 KB</a><div class='inv'><br><a href='./images/20050517/IMG_2269.JPG' ALT='Claudia and I'>Claudia and I</a></div></td>
</tr>
<tr><td><A ID='IMG_2274.JPG' href='itsatoughlife1.php?fileId=IMG_2274.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050517/IMG_2274.JPG' ALT='The main beach in Agnes Water'><BR>The main beach in Agnes Water<br>59.79 KB</a><div class='inv'><br><a href='./images/20050517/IMG_2274.JPG' ALT='The main beach in Agnes Water'>The main beach in Agnes Water</a></div></td>
<td><A ID='IMG_2279.JPG' href='itsatoughlife1.php?fileId=IMG_2279.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050517/IMG_2279.JPG' ALT='Free facials at Cool Bananas, Agnes Water'><BR>Free facials at Cool Bananas, Agnes Water<br>57.9 KB</a><div class='inv'><br><a href='./images/20050517/IMG_2279.JPG' ALT='Free facials at Cool Bananas, Agnes Water'>Free facials at Cool Bananas, Agnes Water</a></div></td>
<td><A ID='IMG_2280.JPG' href='itsatoughlife1.php?fileId=IMG_2280.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050517/IMG_2280.JPG' ALT='Free facials at Cool Bananas, Agnes Water'><BR>Free facials at Cool Bananas, Agnes Water<br>62.34 KB</a><div class='inv'><br><a href='./images/20050517/IMG_2280.JPG' ALT='Free facials at Cool Bananas, Agnes Water'>Free facials at Cool Bananas, Agnes Water</a></div></td>
<td><A ID='IMG_2288.JPG' href='itsatoughlife1.php?fileId=IMG_2288.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050517/IMG_2288.JPG' ALT='Cool Bananas Hostel, Agnes Water'><BR>Cool Bananas Hostel, Agnes Water<br>75.17 KB</a><div class='inv'><br><a href='./images/20050517/IMG_2288.JPG' ALT='Cool Bananas Hostel, Agnes Water'>Cool Bananas Hostel, Agnes Water</a></div></td>
<td><A ID='IMG_2294.JPG' href='itsatoughlife1.php?fileId=IMG_2294.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050517/IMG_2294.JPG' ALT='Cool Bananas Hostel, Agnes Water'><BR>Cool Bananas Hostel, Agnes Water<br>82.88 KB</a><div class='inv'><br><a href='./images/20050517/IMG_2294.JPG' ALT='Cool Bananas Hostel, Agnes Water'>Cool Bananas Hostel, Agnes Water</a></div></td>
</tr>
<tr><td><A ID='IMG_2295.JPG' href='itsatoughlife1.php?fileId=IMG_2295.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050517/IMG_2295.JPG' ALT='Cool Bananas Hostel, Agnes Water'><BR>Cool Bananas Hostel, Agnes Water<br>119.1 KB</a><div class='inv'><br><a href='./images/20050517/IMG_2295.JPG' ALT='Cool Bananas Hostel, Agnes Water'>Cool Bananas Hostel, Agnes Water</a></div></td>
<td><A ID='IMG_2297.JPG' href='itsatoughlife1.php?fileId=IMG_2297.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050517/IMG_2297.JPG' ALT='Cool Bananas Hostel, Agnes Water'><BR>Cool Bananas Hostel, Agnes Water<br>73.47 KB</a><div class='inv'><br><a href='./images/20050517/IMG_2297.JPG' ALT='Cool Bananas Hostel, Agnes Water'>Cool Bananas Hostel, Agnes Water</a></div></td>
<td><A ID='IMG_2298.JPG' href='itsatoughlife1.php?fileId=IMG_2298.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050517/IMG_2298.JPG' ALT='Cool Bananas Hostel, Agnes Water'><BR>Cool Bananas Hostel, Agnes Water<br>62.62 KB</a><div class='inv'><br><a href='./images/20050517/IMG_2298.JPG' ALT='Cool Bananas Hostel, Agnes Water'>Cool Bananas Hostel, Agnes Water</a></div></td>
<td><A ID='IMG_2303.JPG' href='itsatoughlife1.php?fileId=IMG_2303.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050517/IMG_2303.JPG' ALT='Cool Bananas Hostel, Agnes Water'><BR>Cool Bananas Hostel, Agnes Water<br>55.66 KB</a><div class='inv'><br><a href='./images/20050517/IMG_2303.JPG' ALT='Cool Bananas Hostel, Agnes Water'>Cool Bananas Hostel, Agnes Water</a></div></td>
<td><A ID='IMG_2311.JPG' href='itsatoughlife1.php?fileId=IMG_2311.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050517/IMG_2311.JPG' ALT='Agnes Water'><BR>Agnes Water<br>54.47 KB</a><div class='inv'><br><a href='./images/20050517/IMG_2311.JPG' ALT='Agnes Water'>Agnes Water</a></div></td>
</tr>
<tr><td><A ID='IMG_2326.JPG' href='itsatoughlife1.php?fileId=IMG_2326.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050517/IMG_2326.JPG' ALT='Town of 1770'><BR>Town of 1770<br>47.8 KB</a><div class='inv'><br><a href='./images/20050517/IMG_2326.JPG' ALT='Town of 1770'>Town of 1770</a></div></td>
<td><A ID='IMG_2331.JPG' href='itsatoughlife1.php?fileId=IMG_2331.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050517/IMG_2331.JPG' ALT='Arty palm, Town of 1770'><BR>Arty palm, Town of 1770<br>95.43 KB</a><div class='inv'><br><a href='./images/20050517/IMG_2331.JPG' ALT='Arty palm, Town of 1770'>Arty palm, Town of 1770</a></div></td>
<td><A ID='IMG_2340.JPG' href='itsatoughlife1.php?fileId=IMG_2340.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050517/IMG_2340.JPG' ALT='Self Portrait at sunset, Town of 1770'><BR>Self Portrait at sunset, Town of 1770<br>76.88 KB</a><div class='inv'><br><a href='./images/20050517/IMG_2340.JPG' ALT='Self Portrait at sunset, Town of 1770'>Self Portrait at sunset, Town of 1770</a></div></td>
<td><A ID='IMG_2342.JPG' href='itsatoughlife1.php?fileId=IMG_2342.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050517/IMG_2342.JPG' ALT='Nice trees, Town of 1770'><BR>Nice trees, Town of 1770<br>57.32 KB</a><div class='inv'><br><a href='./images/20050517/IMG_2342.JPG' ALT='Nice trees, Town of 1770'>Nice trees, Town of 1770</a></div></td>
<td><A ID='IMG_2344.JPG' href='itsatoughlife1.php?fileId=IMG_2344.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050517/IMG_2344.JPG' ALT='Nice trees, Town of 1770'><BR>Nice trees, Town of 1770<br>61.96 KB</a><div class='inv'><br><a href='./images/20050517/IMG_2344.JPG' ALT='Nice trees, Town of 1770'>Nice trees, Town of 1770</a></div></td>
</tr>
<tr><td><A ID='IMG_2347.JPG' href='itsatoughlife1.php?fileId=IMG_2347.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050517/IMG_2347.JPG' ALT='Nice trees, Town of 1770'><BR>Nice trees, Town of 1770<br>65.58 KB</a><div class='inv'><br><a href='./images/20050517/IMG_2347.JPG' ALT='Nice trees, Town of 1770'>Nice trees, Town of 1770</a></div></td>
<td><A ID='IMG_2348.JPG' href='itsatoughlife1.php?fileId=IMG_2348.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050517/IMG_2348.JPG' ALT='Sunset, Town of 1770'><BR>Sunset, Town of 1770<br>44.95 KB</a><div class='inv'><br><a href='./images/20050517/IMG_2348.JPG' ALT='Sunset, Town of 1770'>Sunset, Town of 1770</a></div></td>
<td><A ID='IMG_2361.JPG' href='itsatoughlife1.php?fileId=IMG_2361.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050517/IMG_2361.JPG' ALT='Sunset, Town of 1770'><BR>Sunset, Town of 1770<br>59.94 KB</a><div class='inv'><br><a href='./images/20050517/IMG_2361.JPG' ALT='Sunset, Town of 1770'>Sunset, Town of 1770</a></div></td>
<td><A ID='IMG_2363.JPG' href='itsatoughlife1.php?fileId=IMG_2363.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050517/IMG_2363.JPG' ALT='Sunset, Town of 1770'><BR>Sunset, Town of 1770<br>38.1 KB</a><div class='inv'><br><a href='./images/20050517/IMG_2363.JPG' ALT='Sunset, Town of 1770'>Sunset, Town of 1770</a></div></td>
<td><A ID='IMG_2384.JPG' href='itsatoughlife1.php?fileId=IMG_2384.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050517/IMG_2384.JPG' ALT='Sunset, Town of 1770'><BR>Sunset, Town of 1770<br>36.46 KB</a><div class='inv'><br><a href='./images/20050517/IMG_2384.JPG' ALT='Sunset, Town of 1770'>Sunset, Town of 1770</a></div></td>
</tr>
<tr><td><A ID='IMG_2390.JPG' href='itsatoughlife1.php?fileId=IMG_2390.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050517/IMG_2390.JPG' ALT='Sunset, Town of 1770'><BR>Sunset, Town of 1770<br>23.85 KB</a><div class='inv'><br><a href='./images/20050517/IMG_2390.JPG' ALT='Sunset, Town of 1770'>Sunset, Town of 1770</a></div></td>
</tr>
</table>	</div>
</div>
</body>
</html>