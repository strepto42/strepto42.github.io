<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - April 2003 - Q&A letters</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="Q&A letters">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="Q&A letters" href='masterit200301.php'>January 2003</a></li>
<li><a title="Q&A letters" href='masterit200302.php'>February 2003</a></li>
<li><a title="Q&A letters" href='masterit200303.php'>March 2003</a></li>
<li><div class='activemenu'>April 2003</div></li>
<li><a title="Q&A letters" href='masterit200305.php'>May 2003</a></li>
<li><a title="Q&A letters" href='masterit200306.php'>June 2003</a></li>
<li><a title="Q&A letters" href='masterit200307.php'>July 2003</a></li>
<li><a title="Q&A letters" href='masterit200308.php'>August 2003</a></li>
<li><a title="Q&A letters" href='masterit200309.php'>September 2003</a></li>
<li><a title="Q&A letters" href='masterit200310.php'>October 2003</a></li>
<li><a title="Q&A letters" href='masterit200311.php'>November 2003</a></li>
<li><a title="Q&A letters" href='masterit200312.php'>December 2003</a></li>
<li> </li><br><li>Or go back to:</li><li><a title='Q&A/MasterIT letters from 2003' href="masterit2003.php">2003 archive</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>April 2003</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Mark's writing' href="written.php">Professional Writing</a> > <a title='My weekly Q&A column in The Australian' href="masterIT.php">MasterIT</a> > <a title='Q&A/MasterIT letters from 2003' href="masterit2003.php">2003 archive</a> > <a title='Q&A letters' href="masterit200304.php">April 2003</a>
<br><br>		<br>
<h2>1/4/03</h2><br>
<b>I had been loading CDs onto my computer lately and it was working wonderfully. On Friday I tried to do some more and I got the message "Windows  Media Player encountered and error when reading the CD-ROM in digital mode". Could you offer some help? I always try to stay up to date with latest releases of the programs I have and I wonder if my update of Roxio Easy CD Creator 5 has pushed it over.</b><br>
<br>
Tying down the problem here is difficult, but it's quite possible that updating Easy CD Creator has caused the problems - others have experienced issues with this software in the past.<br>
<br>
The problem is that there are components of Windows Media Player that are shared with Easy CD Creator, and updating one can break the other.<br>
<br>
Give the following a go. Open up the control panel and select "Add/Remove programs".<br>
<br>
Select Windows Media Player 7, and then click Add/Remove. Click Remove Windows Media components, and then click Next.<br>
<br>
Finally, click to select the checkbox next to "Adaptec CD-Burning Plug-in", click Next twice, and then click Finish.<br>
<br>
<br>
<b>I have a number of oldish games that run so fast on my new PC that I lose the music and practically all the action. Is there a way to slow it down so I can enjoy my old games?</b><br>
<br>
This is a fairly common problem for older games. Super-fast PCs do make them comically fast, but it tends to reduce the playability somewhat.<br>
<br>
There are plenty of utilities around to solve the problem; they work well to varying extents; some older games get choppy with certain utilities but are fine with others - you'll just have to experiment.<br>
<br>
"Mo'Slo" (<a href="http://www.hpaa.com/moslo" target="_blank">www.hpaa.com/moslo</a>) seems to be the utility of choice. It's not entirely free but a cut down version can be downloaded to give it a go.<br>
<br>
Another option is the cheerfully named "CPUKILLER", which sports a nice user interface, as well as a website that still uses the fabulous old-school blink tag (<a href="http://www.cpukiller.com" target="_blank">www.cpukiller.com</a>).<br>
<br>
<b>Incidentally, are you a human or a machine?</b><br>
<br>
There is as yet insufficient data for a meaningful answer.<br>
<br>
<br>
<b>(April 1st special) My friend just bought a really small computer to use with the stereo. I can't afford a fancy new case but would love something small. How easy is it to modify an existing box to fit?</b><br>
<br>
It's a lot easier that you might think. Check out <a href="http://www.datadocktorn.nu/us_desktop1.php" target="_blank">www.datadocktorn.nu/us_desktop1.php</a>. This site also has a great article on hard disk defragmentation.<br>
<br>
Make sure to check your computer's date before undertaking either of these projects.<br>
<br>
<br>
<h2>8/4/03</h2><br>
<b>How do you make a "path" around a picture to cut it out? I want to cut out a person from a picture and don't want anything BUT the person (no background). How do I do this with Adobe Elements?</b><br>
<br>
There are a few different techniques you can use. Probably the most common approach is to use the selection brush. Have a look at <a href="http://www.adobe.com/digitalimag/tips/phsel2mask/main.html" target="_blank">www.adobe.com/digitalimag/tips/phsel2mask/main.html</a> for a good introductory tutorial.<br>
<br>
You can also check out <a href="http://www.arraich.com/elements/pse_mmask1.htm" target="_blank">www.arraich.com/elements/pse_mmask1.htm</a> for an alternative way of accomplishing the same thing.<br>
<br>
<br>
<b>I'm trying to upgrade my aging 6Gb hard disk to a larger 60Gb model. I've used Norton Ghost to transfer my Win2k install and data across, but when I try and boot off the new hard disk I get a blue screen of death with some sort of message about a missing boot device. Any ideas? I'd really love to avoid having to reformat and reinstall everything.</b><br>
<br>
The problem here is that Windows is trying to find a specific boot device on startup - namely your old hard drive. NT, 2000 and XP will all have this problem; 95, 98 and ME don't.<br>
<br>
To get around this, boot from your old hard drive, and then go into the device manager (right click on My Computer, select "Manage" for a nice shortcut).<br>
<br>
Open up the "Disk Drives" branch in the device tree, right click on your old hard drive and select "uninstall". Windows will give you the old faithful message about needing to restart your computer for the changes to take effect - click yes, and have your DOS boot disk ready to go.<br>
<br>
This is the point at which you must use Ghost to copy your system to the new drive. Do NOT let windows restart until this is done.<br>
<br>
Once copied, boot from your new drive but make sure that the old drive is not installed - this is very important as Windows will get horribly confused if it can see both your old drive and the new.<br>
<br>
Once you've performed a successful boot with the new drive, it's ok to shut down and reinstall your old one if you want.<br>
<br>
<br>
<h2>15/4/03</h2><br>
<b>Can I completely disable the recycle bin in Windows? I tend to never delete things by accident, and I'm happy to live without the safety net (and hassle of having to constantly empty the darn thing!)</b><br>
<br>
You can indeed disable the bin. Just right click on the icon, select Properties, and tick the box entitled "Do not move files to the Recycle Bin�".<br>
<br>
If you're feeling extra macho, untick the "Display delete confirmation dialog" checkbox. Now all it takes is one slip of the delete key to remove your precious files (or, say, the entire Windows folder�).<br>
<br>
Running without a safety net may be exhilarating, but it's perhaps more sensible to retain use of the bin. An alternative way to speed things up without completely sacrificing the safely option is to leave the bin on, but disable the confirmation dialog.<br>
<br>
Another handy shortcut to know is that you can use Shift-Delete to bypass the bin and permanently delete a file in one go.<br>
<br>
<br>
<b>I'd like to get two monitors working on my PC. Can I do this easily? My computer is a few years old, but I have Windows XP and a Matrox Millenium G200 video card.</b><br>
<br>
Yep, it's pretty easy. You'll either need an additional PCI video card, or you can replace your current Matrox with a newer card that supports two monitors.<br>
<br>
The latter option is likely to be more expensive and there are few multi-output cards to choose from. Matrox's "Parhelia" (thank the Matrox Marketroids for that name) is one which can support up to three displays, but it doesn't come cheap (you're looking at more than $800).<br>
<br>
Matrox also produce less frighteningly-priced models that support two monitors. You'll still be looking at more than $200 though.<br>
<br>
Just adding a cheap second video card is often the easiest way to go. Make sure that it's a PCI card though, as your current video card will most likely be taking up the AGP slot already. A cheapie card should set you back less than $100.<br>
<br>
Windows XP supports up to 10 monitors - check out the following link for more information.<br>
<br>
<a href="support.microsoft.com?kbid=307873" target="_blank">support.microsoft.com?kbid=307873</a><br>
<br>
<br>
<h2>22/4/03</h2><br>
<b>The last Automatic Windows Update offered is a "security update for Microsoft Virtual Machine". It says that "once this item is installed it cannot be removed". Do I need it or am I just loading myself with junk? What is the Microsoft VM?</b><br>
<br>
The Microsoft VM, or Virtual Machine, is Microsoft's version of the Java engine. Java is a widely used programming language that is used for all sorts of things, including applets, which are little programs that run in your browser (for a cute example check out <a href="http://www.sodaplay.com" target="_blank">www.sodaplay.com</a>).<br>
<br>
This particular update is recommended as it fixes a rather nasty security hole.<br>
<br>
It's always a good idea to stay up to date with the latest security fixes for Windows, especially so if you have a permanent internet connection like cable or ADSL.<br>
<br>
Check out the latest updates and patches at windowsupdate.microsoft.com.<br>
<br>
<br>
<b>I've got a cable connection and would like to access my home computer when I'm at work (or elsewhere). I've found out how to do this using the IP address, but it keeps changing. Is there some easy way I can find out when this has happened remotely?</b><br>
<br>
There are various ways to cope with this problem. The easiest is to get yourself a fixed IP address if possible. Only some ISPs will give you the option of doing this, and often it's under a so-called business plan and costs more.<br>
<br>
Option B is to use a service called Dynamic DNS. These services let you set up an alias for your computer that maps onto your current IP address.<br>
<br>
There are only two catches; firstly, you can't just pick the alias, although you can pick the first part of it, and choose from a few easy to remember options for the rest.<br>
<br>
Secondly, you still need to keep the alias up to date with your current IP address. This isn't generally a problem as there are plenty of software tools available to help do this (some hardware routers even support doing it automatically).<br>
<br>
Two good places to start looking are <a href="http://www.ddns.nu" target="_blank">www.ddns.nu</a> (a home grown and friendly outfit) and <a href="http://www.dyndns.org" target="_blank">www.dyndns.org</a> (supported by some hardware routers).<br>
<br>
<br>
<h2>29/4/03</h2><br>
<b>I just upgraded to Windows XP. Now I have two options for font smoothing in the display properties. What's the difference between "Standard" font smoothing and "Cleartype"?</b><br>
<br>
"Cleartype" is Microsoft's fancy brand name for a newer type of font smoothing that uses a technology called sub-pixel rendering.<br>
<br>
Normal font smoothing uses whole pixels and shades of grey to mask out jagged edges. Sub-pixel rendering takes this a step further, separately using the individual red, green and blue dots that make up a whole pixel to smooth edges more precisely.<br>
<br>
The net result it that it's vastly superior to the old type of font smoothing when used on a display with exact pixels, like liquid crystal displays. So if you've got a nice shiny flat panel or a laptop it's definitely worth switching on.<br>
<br>
On the other hand, when used on a normal CRT monitor it can make the fonts appear slightly blurry. Some people think this looks nice, some hate it. It's a matter of personal choice.<br>
<br>
Windows XP also lets you set the font contrast, making them darker or lighter to suit your taste. Microsoft have a web page for it; there is also a standalone utility called Cleartweak that does the same thing.<br>
<br>
There's a good article on the whole subject, including a link to Cleartweak at <a href="http://www.richleader.com/cleartype.htm" target="_blank">www.richleader.com/cleartype.htm</a><br>
<br>
<br>
<b>Further to your published answer in MasterIT on 15/4/03, is it possible to run two separate monitors from a notebook computer in addition to the notebook's own screen simultaneously, or at least two monitors without the notebook's screen?</b><br>
<br>
In theory, if the laptop has the right hardware and the drivers supplied for the operating system supported it, you can do it.<br>
<br>
The problem, however, is that you need two external video ports to drive the two displays. Currently we're not aware of any laptops which have two VGA outputs as standard, however there are third party display adaptors which let you run multiple displays.<br>
<br>
Whilst they're available, such beasties are also likely to be expensive - for example the ones available from <a href="http://www.margi.com" target="_blank">www.margi.com</a> start at $US150 and don't officially support Windows XP.<br>
<br>
<i><p>Did the information on this page help you? Entertain you? Bore you? <a href="contact.php?subject=MasterIT">Drop me a line</a>.</p>

<p>If you're feeling particularly generous, you can even <a href="buypics.php">click here to send me some dot-com riches</a>. Think of it as online busking.</i></p>
	</div>
</div>
</body>
</html>