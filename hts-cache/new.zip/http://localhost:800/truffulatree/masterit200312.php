<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - December 2003 - Q&A letters</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="Q&A letters">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="Q&A letters" href='masterit200301.php'>January 2003</a></li>
<li><a title="Q&A letters" href='masterit200302.php'>February 2003</a></li>
<li><a title="Q&A letters" href='masterit200303.php'>March 2003</a></li>
<li><a title="Q&A letters" href='masterit200304.php'>April 2003</a></li>
<li><a title="Q&A letters" href='masterit200305.php'>May 2003</a></li>
<li><a title="Q&A letters" href='masterit200306.php'>June 2003</a></li>
<li><a title="Q&A letters" href='masterit200307.php'>July 2003</a></li>
<li><a title="Q&A letters" href='masterit200308.php'>August 2003</a></li>
<li><a title="Q&A letters" href='masterit200309.php'>September 2003</a></li>
<li><a title="Q&A letters" href='masterit200310.php'>October 2003</a></li>
<li><a title="Q&A letters" href='masterit200311.php'>November 2003</a></li>
<li><div class='activemenu'>December 2003</div></li>
<li> </li><br><li>Or go back to:</li><li><a title='Q&A/MasterIT letters from 2003' href="masterit2003.php">2003 archive</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>December 2003</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Mark's writing' href="written.php">Professional Writing</a> > <a title='My weekly Q&A column in The Australian' href="masterIT.php">MasterIT</a> > <a title='Q&A/MasterIT letters from 2003' href="masterit2003.php">2003 archive</a> > <a title='Q&A letters' href="masterit200312.php">December 2003</a>
<br><br>		<br>
<h2>2/12/03</h2><br>
<b>I have a new PC; running XP Home Edition with 512MB of RAM. Every second or so the hard disk is accessed, making a sort of "clock-clock" sound (with the hard-drive access light blinking mainly twice per second).<br>
<br>
During the day, the noise is almost unnoticeable; however, at night, it is distracting and stressful. It seems to happen constantly, even when my only interaction with the computer is to read what is on the screen.<br>
<br>
If I run MSCONFIG.EXE and select "Diagnostic Startup", the problem mostly disappears (no more rattle, but the activity light still blinks very frequently), however, in this mode, I lose functionality.<br>
<br>
I wonder how long will the drive last if the rate of access is so high?</b><br>
<br>
To address the last question first, the drive should still last a long time, even with constant access. In theory, modern hard drives have a Mean Time Between Failure of hundreds of thousands of hours. In practice several years of service can be expected, even with constant access.<br>
<br>
Regarding the noise question, it could be a number of things. We can start by telling you what it's NOT likely to be.<br>
<br>
It's unlikely to be the indexing service, as that would create a less frequent, larger burst of activity.<br>
<br>
It could be XP swapping in and out virtual memory, but this is also unlikely as you have plenty of RAM, and your problem seems more constant. Similarly, it's also unlikely to be XP performing minor drive defrags and optimising it's boot sequence, which can be another cause of mystery disk activity.<br>
<br>
The hard drive light blinking after a diagnostic boot will be due to Autoplay polling the IDE bus to see if you've just inserted a CD. This also isn't the cause of the noise problem, but it's interesting to know.<br>
<br>
Unfortunately, this pretty much covers the usual suspects. To help narrow it down, have a look at a couple of utilities called Filemon and Diskmon. They can be downloaded for free from <a href="http://www.sysinternals.com" target="_blank">www.sysinternals.com</a>, and with luck they'll let you track down the culprit.<br>
<br>
Failing everything, perhaps it's a good excuse to upgrade to a new, quieter (and of course larger) hard drive.<br>
<br>
<br>
<h2>9/12/03</h2><br>
<b>Can you reformat a corrupted HDD? Will it be reliable? Trustworthy?</b><br>
<br>
That really depends on how it became corrupted. If the drive got screwed up after a badly timed power outage, virus attack or just some lousy software going on a random disk writing spree, then it's most likely still fine, and after a full format will be fully usable. In this case there's nothing wrong with the drive, it's just that some of the data got messed up and the operating system can't deal with it any more.<br>
<br>
On the other hand if the drive has had some sort of hardware failure then you can kiss it goodbye, as when this happens there's a physical reason - hard drives have deicate moving parts which can eventually break down. Sometimes the controller board on the drive can also get fried (by a lightning induced power surge for example).<br>
<br>
Good uses for dead drives include doorstops, paperweights, and sources of really strong magnets. You'll need to dismantle the drive to remove them - they're part of the mechanism that controls the read/write heads. Once extracted they can be put to use holding entire magazines to the fridge - just don't get any extremities caught in between them.<br>
<br>
<br>
<b>I've had to reinstall Windows XP Home. Then there was a problem with the C drive, so I installed XP Home onto the D Drive.<br>
<br>
I formatted the C drive and got rid of the two XP Home installations, and now I've installed XP Pro onto that drive and formatted the D drive.<br>
<br>
Now when the computer starts it asks which operating system I wish to log onto... there's XP Pro as well as three XP Homes.<br>
<br>
How do I get rid of this from the system boot?</b><br>
<br>
You'll need to modify the file "boot.ini". One easy way in XP is to run msconfig.exe (press Windows-R, type "msconfig" and hit enter), click on the "BOOT.INI" tab and make changes as needed.<br>
<br>
If you want to manually trim the boot.ini file, the easiest way is to right click My Computer, select Properties, select Advanced, then click on "startup and recovery settings", and then click edit.<br>
<br>
Official advice can be found at <a href="http://support.microsoft.com/?kbid=289022" target="_blank">support.microsoft.com/?kbid=289022</a>.<br>
<br>
<br>
<h2>16/12/03</h2><br>
<b>I recently volunteered to help an non-profit organisation to set up a small network to learn more of networking. The network consist of a WinXP PC and 2 Win98 systems. All the systems are using 100-base-T network.<br>
<br>
The PCs can see each other on the network. The XP machine can access the 2 Win98 share directories without any hassles. However, when the Win98 systems try to access the share directory on the XP machine, it takes ages to come back, sometimes just timing out and returning with a no access to XP message. What should I do and where do I look to resolve this issue? Is this problem on XP or 98?</b><br>
<br>
The sharing problem comes from the different security models that are used in 98 and XP. Windows 98 hails from 95, which in turn hails from crusty old Windows 3.1. XP's pedigree is more genteel, and its lineage traces back to Windows 2000 and NT, which have a much more complex (and, generally speaking, tougher) security model.<br>
<br>
Hence XP can talk to the more primitive 98, but problems arise in reverse.<br>
<br>
To get around this, you'll need to create some users on the XP machine with the same usernames you're using to log into the Windows 98 machines. Next, you have to make sure that the XP shares allow those users access - you can set this up in the properties for the share.<br>
<br>
To make matters more confusing, if you're using the NTFS filesystem with XP, every file and folder can have individual security permissions. You'll probably need to check these too, not only on the folder that you're sharing, but also on any files that are in that folder.<br>
<br>
Your best net resource for this sort of thing is probably Google Groups. Have a search there for "98 XP file sharing howto" or something similar.<br>
<br>
<br>
<b>In Windows XP, I can execute the Windows Task Manager, choose the "Processes" tab, and get a listing of active processes. How do I find out what each of these does?</b><br>
<br>
The simplest and most effective way is to just type the name of the file (eg SVCHOST.EXE) into Google.<br>
<br>
<br>
Send queries and xmas stockings full of iPods to <a href="contact.php">(the masterit contact email address)</a>.<br>
<br>
<i><p>Did the information on this page help you? Entertain you? Bore you? <a href="contact.php?subject=MasterIT">Drop me a line</a>.</p>

<p>If you're feeling particularly generous, you can even <a href="buypics.php">click here to send me some dot-com riches</a>. Think of it as online busking.</i></p>
	</div>
</div>
</body>
</html>