<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - November 2004 - Q&A letters</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="Q&A letters">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="Q&A letters" href='masterit200401.php'>January 2004</a></li>
<li><a title="Q&A letters" href='masterit200402.php'>February 2004</a></li>
<li><a title="Q&A letters" href='masterit200403.php'>March 2004</a></li>
<li><a title="Q&A letters" href='masterit200404.php'>April 2004</a></li>
<li><a title="Q&A letters" href='masterit200405.php'>May 2004</a></li>
<li><a title="Q&A letters" href='masterit200406.php'>June 2004</a></li>
<li><a title="Q&A letters" href='masterit200407.php'>July 2004</a></li>
<li><a title="Q&A letters" href='masterit200408.php'>August 2004</a></li>
<li><a title="Q&A letters" href='masterit200409.php'>September 2004</a></li>
<li><a title="Q&A letters" href='masterit200410.php'>October 2004</a></li>
<li><div class='activemenu'>November 2004</div></li>
<li><a title="Q&A letters" href='masterit200412.php'>December 2004</a></li>
<li> </li><br><li>Or go back to:</li><li><a title='Q&A/MasterIT letters from 2004' href="masterit2004.php">2004 archive</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>November 2004</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Mark's writing' href="written.php">Professional Writing</a> > <a title='My weekly Q&A column in The Australian' href="masterIT.php">MasterIT</a> > <a title='Q&A/MasterIT letters from 2004' href="masterit2004.php">2004 archive</a> > <a title='Q&A letters' href="masterit200411.php">November 2004</a>
<br><br>		<br>
<h2>9/11/2004</h2><br>
<b>I have a notebook running Windows XP and notice that it has two drives on the hard disk, C and D. At present, all my program files and data files are on C. Someone said I should keep data files on D, in case C crashes at some time. Do you agree with this? Also, can you have too much memory? I have bought an upgrade of 256Mb, when plugged on top of current memory it will become 362Mb. Currently my notebook runs very slowly, like pulling teeth waiting for it to boot up etc.</b><br>
<br>
There are arguments for and against keeping data on a separate drive letter to everything else. It also depends on whether the drive letters are on the same physical disk, or if they're just virtual drives created by partitioning (as they are in your case).<br>
<br>
As the latter applies to your laptop, the argument for keeping data files on a different drive isn't as strong. If your drive dies you'll lose both C and D anyway.<br>
<br>
There are other arguments for and against partitioning a hard drive. Not partitioning (my preference) means you can't run out of space until your whole drive is out of space. On a partitioned drive you might fill up D before C, even though they're the same drive, and then you have to start shuffling data, which gets messy.<br>
<br>
The opposing argument is that if you keep all you documents and program settings on D, you can format C and reinstall Windows without having to back everything up first. Also, it won't help you if your drive physically fails, but if for some reason C gets corrupted the files on D should still be recoverable.<br>
<br>
This is all a bit moot in your case anyway, as the drive is already partitioned. If you want to keep just data on D, that's fine, and probably not a bad idea overall.<br>
<br>
Regarding RAM, having too much won't hurt anything, but it's a waste of money, although we're talking gigabytes here; an extra 256Mb to your system will improve performance, but only in certain ways.<br>
<br>
Specifically, if your system runs out of RAM, it starts to use the hard disk as virtual memory, which is much slower. Adding more ram will help alleviate this.<br>
<br>
If you're still experiencing a slow startup and general disk performance, you should also defragment the hard disk. You can do this by right clicking on C, selecting Properties->Tools->Defragment Now.<br>
<br>
<br>
<h2>16/11/04</h2><br>
<b>Recently I acquired a Logitech Quickcam. My problem is I can see and hear my contact on MSN Messenger, but he can not see me or hear me. I have recorded myself and sent the recording as an attachment in an E-mail, which arrived both picture and sound. I have Windows XP home and Intel Pentium 4 processor 1.9GHz and dial up Internet.</b><br>
<br>
It sounds like you've got some firewall issues happening. The MSN messenger video conference code uses the Netmeeting protocol. Unfortunately it's hard to configure firewalls to work with it, as the software uses semi-random ports.<br>
<br>
Even if you get your firewall configured correctly, the firewall at the other end of the connection could still be a problem. Ultimately, you'll probably have more success with another application. Eyeball Chat is one that allegedly works through firewalls.<br>
<br>
<br>
<b>When I go to shut down Windows, I get a small white box with red lettering saying "Out Of Range". Can you tell me what the problem is and how to cure it? Also, some time ago in reply to a letter you suggested uninstalling and reinstalling Windows to freshen up your computer. I am running Windows ME and would like to know the procedure and what to beware of. Would it affect my non-windows programmes such as Lotus or mess up my current files?</b><br>
<br>
The message you get when you shut down is coming from the monitor itself and not the PC. For some reason, as your PC shuts off, its putting out a strange video signal that the monitor can't deal with (hence the message, the signal is out of the monitor's acceptable frequency range).<br>
<br>
Unfortunately I'm not sure if there is a lot you can do about it. You could try updating the drivers for your video card. The Windows "reinstall" might also help.<br>
<br>
On that subject, I'm not personally familiar with the ME install, but the process is going to be similar to this:<br>
<br>
Boot Windows normally, put in the Windows CD, and run setup.exe. When asked if you want to upgrade or install a new copy, select upgrade. Note that you'll need to reapply any security patches from windowsupdate.com afterwards.<br>
<br>
If you can't select an option to upgrade, don't proceed, or you'll lose all your settings. Sometimes the upgrade option isn't there, it depends on the particular Windows disc - some OEM copies only allow a complete fresh install.<br>
<br>
<br>
<h2>23/11/04</h2><br>
<b>Please tell me if there is a way that I can disengage automatic overtype - especially in Outlook Express - in my relatively new computer with Windows XP. It is driving me around the bend! I touch-type, fast, and don't always look at the screen when I am working on a long message. When I want to add something in the middle of a paragraph or sentence, I click on the mouse where I wish to add it, and off I go, typing the new text. Nearly always, Windows decides that I wish to replace what was there with the new text, and automatically overtypes. This is also happening in Word 2003. I do hope that you can help me with this infuriating and time-wasting problem... before I completely run out of hair to tear out!</b><br>
<br>
That is indeed a curious problem. Windows shouldn't behave like that; I would no doubt have had a good rant about it by now if it did!<br>
<br>
It seems really unlikely that it'll be a software problem, unless some strange virus designed to mischievously toggle overtype exists; although doubtless I would have already heard of something that amusing, and no doubt used it for evil.<br>
<br>
Barring gremlins in the software, I can only think of gremlins in the hardware, or, respectfully, the user.<br>
<br>
Hardware seems more likely - perhaps your keyboard is cactus, and the insert key is triggering randomly when you type. If you have access to another keyboard, try swapping and see how it goes.<br>
<br>
Alternately, go into Word and watch the status bar at the bottom of the screen. It has a section with "REC TRK EXT OVR". When overtype mode is on the OVR goes from grey to black. Try thumping the desk/keyboard and see if it changes by itself. If it does, then it's definitely the keyboard. If not, it's still a good excuse to thump something. If anyone asks, it's a technical procedure called percussive maintenance (it also works on TVs, but isn't recommended for LCD screens).<br>
<br>
If you still have no joy, have a look at where your hands are when you edit. The zero key on the numeric pad will also function as an insert/overtype toggle when Num Lock is off.<br>
<br>
If any readers have a similar problem, please write and let me know. I'll send you a lollypop.<br>
<br>
Send queries and smashed keyboards to <a href="contact.php?subject=MasterIT">(the masterit contact email address)</a><br>
<br>
<br>
<h2>30/11/04</h2><br>
<b>I'm thinking of getting ADSL hooked up, but I'm not sure which plan to go with. By that I mean, I don't know how much download allowance I need. So many hundred megabytes just doesn't translate easily for me. I'm not a very heavy user (I think); I'd just be browsing and doing email etc.</b><br>
<br>
Download allowances do certainly vary greatly from plan to plan - a quick check of www.broadbandchoice.com.au reveals that you can sign up for anything from 200 megabytes a month to 30 gigabytes (150 times more!). <br>
<br>
Apart from the actual amount of data you can download, there is also great variation in the penalties for going over your limit. Some ISPs throttle your speed back to (roughly) modem speed once you reach the limit, while others start charging through the nose and slicing off your appendages (one of those things may not be true). <br>
<br>
In real world terms, typical browsing and email doesn't actually use much allowance. For example, heavy browsing and emailing willy-nilly will probably only use 30-50mb a day. That's still 900-1500mb a month on average, and that's quite heavy usage. Additionally, many ISPs don't count checking your local email (hotmail doesn't count) at all.<br>
<br>
So, many people can, and do, get away with the entry level plans - just watch the fine print for going over the limit.<br>
<br>
If you're wondering how and why people download countless gigabytes per month, the culprits are usually sound and video files. MP3 files are 3-10mb each; an album's worth can easily be 100mb. Video is the big daddy though, with AVI files easily running into the hundreds of megabytes each, or even gigabytes for whole DVD images.<br>
<br>
So unless you're planning on using your broadband connection for activities involving a black bandanna, cutlass and eye patch, a smaller plan is going to be fine.<br>
<br>
<br>
<b>More on keyboard gremlins</b><br>
<br>
Last week's problem of overtype/insert mysteriously toggling itself turned out to be a combination of both hardware and user gremlins. The 0 key on our correspondent's numeric pad turned out to be overly sensitive, and accidental brushes against it whilst using the arrow keys resulted in overtype mode being randomly activated.<br>
<br>
<i><p>Did the information on this page help you? Entertain you? Bore you? <a href="contact.php?subject=MasterIT">Drop me a line</a>.</p>

<p>If you're feeling particularly generous, you can even <a href="buypics.php">click here to send me some dot-com riches</a>. Think of it as online busking.</i></p>
	</div>
</div>
</body>
</html>