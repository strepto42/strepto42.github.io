<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - RDNG - The Random Domain Name Game</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="The Random Domain Name Game">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="A page dedicated to the worst Optimus Prime outfits on the net" href='badoptimus.php'>Bad Optimus</a></li>
<li><a title="WD40 cans going whoosh and Sparkler Bomb videos" href='wd40.php'>WD40</a></li>
<li><a title="2weeks.com internet art concept site" href='2weeks.php'>2weeks.com</a></li>
<li><a title="A pong game featuring Rudi Mueller's head by John Hawkins" href='rudipong.php'>Rudipong</a></li>
<li><div class='activemenu'>RDNG</div></li>
<li><a title="Various animations for download" href='anims.php'>Animations</a></li>
<li><a title="Arnold Schwarzenegger and Michael Jackson soundboards" href='soundboards.php'>Soundboards</a></li>
<li> </li><br><li>Or go back to:</li><li><a title='Silly things for your amusement' href="silliness.php">Silliness</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>RDNG</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Silly things for your amusement' href="silliness.php">Silliness</a> > <a title='The Random Domain Name Game' href="rdng.php">RDNG</a>
<br><br>		<br>
<img src="images/rdng_banner.gif" width="549" height="134"><br>
<br>
This is a simple game that can be enjoyed by all net-loving folk.<br>
<br>
Simply pick a random domain, and see what's there.<br>
<br>
Scoring is arbitrary, but allow me to offer some pointers. A site is considered *really* good if:<br>
<br>
- it is a single page<br>
- it has no purpose<br>
<br>
You lose points if the domain exists, but is being camped on by some wanker, or if it's a totally corporate site.<br>
<br>
Some of our most wonderful finds are now unfortunately gone, but some survive, including:<br>
<br>
<a href="http://www.bigtrouble.com" target="_blank">Big trouble</a><br>
<a href="http://www.dotcomschmotcom.com" target="_blank">Dotcomschmotcom.com (reload this)</a><br>
<a href="http://www.yourethemannowdog.com/" target="_blank">Yourethemannowdog.com (not actually technically a random find, but soo cool)</a><br>
<a href="http://www.smellthecheese.com" target="_blank">Smellthecheese.com</a><br>
<a href="http://www.cheesemetal.com" target="_blank">Cheesemetal.com</a><br>
<br>
And of course the list goes on. <br>
<br>
You can even play the Random Domain Name Game online now. <a href="http://www.geocities.com/rdng2002" target="_blank">Click here for a taste.</a><br>
<br>
Got a RDNG find to share with the world? <a href="contact.php">Email me</a>.<br>
<br>
Also, check out <a href="http://home.iprimus.com.au/spargs/rdng.html" target="_blank">Nathan's RDNG page</a> (it was the page I ripped the above graphic off :D).<br>


	</div>
</div>
</body>
</html>