<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - April 2006 - Q&A letters</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="Q&A letters">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="Q&A letters" href='masterit200601.php'>January 2006</a></li>
<li><a title="Q&A letters" href='masterit200602.php'>February 2006</a></li>
<li><a title="Q&A letters" href='masterit200603.php'>March 2006</a></li>
<li><div class='activemenu'>April 2006</div></li>
<li><a title="Q&A letters" href='masterit200605.php'>May 2006</a></li>
<li><a title="Q&A letters" href='masterit200606.php'>June 2006</a></li>
<li><a title="Q&A letters" href='masterit200607.php'>July 2006</a></li>
<li><a title="Q&A letters" href='masterit200608.php'>August 2006</a></li>
<li><a title="Q&A letters" href='masterit200609.php'>September 2006</a></li>
<li><a title="Q&A letters" href='masterit200610.php'>October 2006</a></li>
<li><a title="Q&A letters" href='masterit200611.php'>November 2006</a></li>
<li><a title="Q&A letters" href='masterit200612.php'>December 2006</a></li>
<li> </li><br><li>Or go back to:</li><li><a title='Q&A/MasterIT letters from 2006' href="masterit2006.php">2006 archive</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>April 2006</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Mark's writing' href="written.php">Professional Writing</a> > <a title='My weekly Q&A column in The Australian' href="masterIT.php">MasterIT</a> > <a title='Q&A/MasterIT letters from 2006' href="masterit2006.php">2006 archive</a> > <a title='Q&A letters' href="masterit200604.php">April 2006</a>
<br><br>		<br>
<h2>4/4/06</h2><br>
<b>I wish to set English (UK) as the default language for Word documents, and had no problem achieving this with previous versions of Word. With Word 2003 though, no matter what I do it always kicks back to English (US). I have nothing against Americans and their language, in their place, but that place is not in my Word documents. I have tried modifying the NORMAL.DOT template, as well as fiddling with the "Changing the Default Language" tool in the Microsoft Office Tools, but it's all to no avail (as the language change doesn't stick). What am I doing wrong?</b><br>
<br>
Microsoft's default dictionary issues are a pet peeve of mine, and no doubt, when coupled with automatic spelling and grammar checks they're responsible for some of the general degradation of written language we see so often these days (long time readers will know of my lamentations regarding apostrophe abuse).<br>
<br>
You've certainly checked in the logical places so far, but perhaps your overall system language settings are (illogically) overriding Office. To check these, go to the Control Panel, and select Regional and Language options. Now Australianise everything in sight, and see if that helps.<br>
<br>
<br>
I've recently swapped from the behemoth Mozilla to the separate Thunderbird and Firefox programs. Whilst leaner and meaner, I've found that opening a series of bookmarks as tabs in the browser overwrites any pages I already have open. I could configure Mozilla to prevent this (and open the bookmarks in new tabs), but I can't seem to find an equivalent setting in Firefox. Is there a way?<br>
<br>
Yes, but it's not immediately obvious. For the more geeky at heart, Firefox has a myriad of hidden settings. To see (and edit) them, simply type "about:config" into a new browser window. A formidable number of settings should appear.<br>
<br>
From here, you can easily modify these raw settings (provided you know what they do!). The particular tweak we are interested in is "Browser.tabs.loadFolderAndReplace". Scroll down to it (they're in alphabetical order thankfully) and right click, then select "toggle" to change it's value.<br>
<br>
If you're interested in further tweaking, full explanations of the about:config settings can be found at mozdev.org.<br>
<br>
<br>
<h2>11/4/06</h2><br>
<b>I've just added a new hard drive to my computer, and it started me thinking about wear and tear, as my computer is on 24/7 these days. I was wondering if it's better to leave hard drives running all the time, or use the power options in Windows to spin them down when they're not being used.</b><br>
<br>
There isn't a simple answer to this one, as it all comes down to your usage patterns.<br>
<br>
For those readers who don't know, modern hard drives can be put into a power saving state where the disk motor is stopped and started as needed by the operating system. There are two basic schools of thought regarding whether this is a good idea or not.<br>
<br>
One camp states that when a disk isn't running, it's not wearing out it's bearings and other moving parts. Also, sleeping disks are much cooler (most of a hard drive's heat comes from air friction inside where the platters are spinning rapidly), and cooler generally equals longer-lived in the computer world. You also save some energy and therefore dollars with this strategy (although the amount is negligible for a single disk). <br>
<br>
The other school of thought says that the most disk wear and tear takes place when it spins up and down, or changes temperature. Drives are generally only rated for a certain number of power cycles, and so the best bet is to leave a disk spinning all the time.<br>
<br>
I think a good philosophy to employ is a mixture of the two.<br>
<br>
Powering a disk up and down is a good thing only if it's not constantly happening. If your disk is used primarily for data, and access is fairly infrequent, you can quite happily set it to spin down after a reasonable period of inactivity (an hour or three perhaps). This will prevent excessive start/stop cycles, but will also let the disk spin down at night, significantly reducing it's spinning time. <br>
<br>
Incidentally, laptop drives are a different animal - they're designed to be spun up and down a lot more, as saving power is the number one goal when you're off the mains. They also spin up a lot faster, as the smaller platters have less inertia, so the best strategy is to set them to spin down quite quickly when idle, particularly when running on batteries.<br>
<br>
<br>
<h2>18/4/06</h2><br>
<b>I've recently swapped from the behemoth Mozilla to the separate Thunderbird and Firefox programs. Whilst leaner and meaner, I've found that opening a series of bookmarks as tabs in the browser overwrites any pages I already have open. I could configure Mozilla to prevent this (and open the bookmarks in new tabs), but I can't seem to find an equivalent setting in Firefox. Is there a way?</b><br>
<br>
Yes, but it's not immediately obvious. For the more geeky at heart, Firefox has a myriad of hidden settings. To see (and edit) them, simply type "about:config" into a new browser window. A formidable number of settings should appear.<br>
<br>
From here, you can easily modify these raw settings (provided you know what they do!). The particular tweak we are interested in is "Browser.tabs.loadFolderAndReplace". Scroll down to it (they're in alphabetical order thankfully) and right click, then select "toggle" to change it's value.<br>
<br>
If you're interested in further tweaking, full explanations of the about:config settings can be found at mozdev.org.<br>
<br>
<br>
<b>I'm using a laptop with Microsoft XP Pro SP2, and run Mozilla Firefox and Thunderbird as browser and email. I also use Outpost Firewall Pro and AVG anti virus. I have had no trouble since setting up that way after the Blaster Worm.</b><br>
<br>
I have switched off Microsoft Automatic Updates, because I can't see any point in downloading patches for Explorer and Outlook if I don't use them. However, I get a reminder each time I boot up that I have switched them off. Is there any way I can disable this annoying reminder?<br>
<br>
Well, apparently you can disable it by turning off the automatic updates service - but this is generally considered to be a Bad Idea. The security updates that Microsoft are always pushing at you aren't just for IE or Outlook Express - they're also for the core components of Windows itself.<br>
<br>
Without the critical updates you could be open to new Windows hacks that are discovered on an alarmingly regular basis. Of course, having a good firewall, running anti-virus software and Firefox all helps to alleviate the danger to a reasonable extent, but it's better to be safe than sorry really.<br>
<br>
Think of it as wearing many raincoats at once. :)<br>
<br>
<br>
<h2>25/4/06</h2><br>
<b>Some time ago you answered a question on anti-virus programs, suggesting having real time protection enabled and running a scan once a month. If real time protection is permanently enabled, why is it necessary to run the scans?</b><br>
<br>
You wouldn't think it was necessary, but it's basically a better-safe-than-sorry approach.<br>
<br>
The reason is that, by default, some virus scanners only scan certain types of files, like .EXE, .VBS and so on. This is because these are generally the higher risk ones that contain viruses, and it slows your PC down less if it just scans these files, as opposed to everything under the sun. However, if a virus comes along labelled as something else, it will get skipped by the real time scanner.<br>
<br>
In cases like this, it's unlikely that the virus will ever get a chance to "run itself" and become active, but it will still sit on the hard drive dormant. Doing a complete scan will pick up and get rid of these little landmines. <br>
<br>
<br>
<b>I have an intermittent problem with my PC, which is running XP Pro SP2. I have 2 printers installed; one is a Canon S450 bubble jet, and the other a Canon Laser LBP1120 on a USB port. Periodically, I get a message saying the Spooler sub system has developed a fault and is shutting down, and when I check on the Control Panel/Printers & Scanners, I find that no printers are shown. Invariably by shutting down the PC and restarting it, things seem to be ok.  It doesn't happen every time I start the computer, but frequently enough to be annoying. I have tried deleting the printers and re installing them but to avail. Any ideas?</b><br>
<br>
It's hard to suggest a magic bullet here, but generally speaking this sort of problem is caused by a faulty printer driver.<br>
<br>
Check the Canon website (http://www.canon.com.au/drivers/index.html) for updated drivers for both your printers - you're possibly using the default Windows drivers which may be quite old, and big manufacturers like Canon often release their own drivers with updated code.<br>
<br>
Uninstall and update both drivers, and see if the problem goes away. If it doesn't,  Canon's own support people may be able to shed some light on the subject.<br>
<br>
<i><p>Did the information on this page help you? Entertain you? Bore you? <a href="contact.php?subject=MasterIT">Drop me a line</a>.</p>

<p>If you're feeling particularly generous, you can even <a href="buypics.php">click here to send me some dot-com riches</a>. Think of it as online busking.</i></p>
	</div>
</div>
</body>
</html>