<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - 19/8/2005 - Blistering Barnacles and Leaping Lizards</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="Blistering Barnacles and Leaping Lizards">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="Greetings from a Bum" href='greetingsfromabum.php'>29/4/2005</a></li>
<li><a title="Onward" href='onward.php'>2/5/2005</a></li>
<li><a title="It's a tough life (pt 1: Bundaberg, Agnes Water and 1770)" href='itsatoughlife1.php'>17/5/2005</a></li>
<li><a title="It's a tough life (pt 2: Rockhampton, Emu Park and Great Keppel Island)" href='itsatoughlife2.php'>23/5/2005</a></li>
<li><a title="There and Back Again - a Yo-yo's Tale" href='thereandbackagain.php'>18/6/2005</a></li>
<li><a title="Platypi and Grey Nomads" href='platypiandgreynomads.php'>24/6/2005</a></li>
<li><a title="Blowing Bubbles in a Watery Tomb" href='blowingbubbles.php'>1/7/2005</a></li>
<li><a title="Pieces of History" href='piecesofhistory.php'>8/7/2005</a></li>
<li><a title="Walks and Waterfalls" href='walksandwaterfalls.php'>15/7/2005</a></li>
<li><a title="Mission to Tribulation" href='missiontotribulation.php'>22/7/2005</a></li>
<li><a title="Levity, Limestone and Lava" href='levitylimestoneandlava.php'>29/7/2005</a></li>
<li><a title="Into the Never Never" href='intothenevernever.php'>5/8/2005</a></li>
<li><a title="Slowing the pace in Darwin" href='slowingthepaceindarwin.php'>12/8/2005</a></li>
<li><div class='activemenu'>19/8/2005</div></li>
<li><a title="Kakadu and Litchfield" href='kakadu.php'>26/8/2005</a></li>
<li><a title="Legacies of War" href='legaciesofwar.php'>2/9/2005</a></li>
<li><a title="Go West" href='gowest.php'>10/9/2005</a></li>
<li><a title="Things from Above" href='thingsfromabove.php'>16/9/2005</a></li>
<li><a title="The West Coast" href='thewestcoast.php'>23/9/2005</a></li>
<li><a title="Reefs and Red Dust" href='reefsandreddust.php'>30/9/2005</a></li>
<li><a title="The Pilbara" href='pilbara.php'>7/10/2005</a></li>
<li><a title="Paradise with a Headwind" href='paradisewithaheadwind.php'>14/10/2005</a></li>
<li><a title="Down the Coral Coast" href='downthecoralcoast.php'>21/10/2005</a></li>
<li><a title="Pinnacles and Pinnipeds" href='pinnaclesandpinnipeds.php'>28/10/2005</a></li>
<li><a title="A week in Perth" href='perth.php'>4/11/2005</a></li>
<li><a title="The Southwest (from Above and Below)" href='thesouthwest.php'>11/11/2005</a></li>
<li><a title="More Heights and Depths" href='moreheightsanddepths.php'>18/11/2005</a></li>
<li><a title="Across the Nullarbor (and a bit beyond)" href='nullarbor.php'>25/11/2005</a></li>
<li><a title="Double Whammy" href='doublewhammy.php'>9/12/2005</a></li>
<li><a title="Two Cities" href='twocities.php'>19/12/2005</a></li>
<li><a title="Tassie - Part 1" href='tassie1.php'>1/1/2006</a></li>
<li><a title="Tassie - Part 2" href='tassie2.php'>7/1/2006</a></li>
<li><a title="Full Circle" href='fullcircle.php'>26/1/2006</a></li>
<li><a title="The Wrap Up" href='thewrapup.php'>23/3/2006</a></li>
<li> </li><br><li>Or go back to:</li><li><a title='Travelouges and blogs from my trip around Australia' href="nerdseyeview.php">Nerd's Eye View</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>19/8/2005</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Travel stories and pictures' href="travel.php">Travelogues</a> > <a title='Travelouges and blogs from my trip around Australia' href="nerdseyeview.php">Nerd's Eye View</a> > <a title='Blistering Barnacles and Leaping Lizards' href="leapinglizards.php">19/8/2005</a>
<br><br>		


<h1>Blistering Barnacles and Leaping Lizards</h1>

<a href="images/maps/Map050819.gif"><img src="images/maps/Map050819_sm.gif" align="right"></a>

<p>Me again. It must be Friday, yay!</p>

<p>Well, hopefully. Sometimes I don't send these till late, so it might be Monday when you read it. My condolences if it is. And remember: It's un-Australian to work on Monday or Friday (even if you GO to work).</p>

<p>Right now, I'm sitting in the middle (more or less, poetic licence) of Kakadu. I'm getting molested my mozzies, but thanks to the remains of the industrial strength insect repellent bought for the India trip years ago, the molestation is mostly the buzz-in-your-ear-and-send-you-insane type, rather than the suck-your-blood-and-give-you-Dengue type.</p>

<p>But I should backtrack. After the last instalment, Justine and I proceeded to have a lazy weekend. Who'd have guessed!</p>

<p>On the Sunday we headed out to Berry Springs again, and I took some photos this time, as well as snorkelled a little bit, to check out the fish (which were mostly hiding) and the bottom of the creek (about 4-5m in places, and muddy). Apparently the Angler fish there will shoot jets of water to knock bread out of your hand.</p>

<p>There are also apparently fresh water crocodiles there too. It would have been quite cool to see one, although underwater it might have been a bit of a brown-swimwear moment, as despite the fact that freshies have never attacked anyone, they're still, like, <strong>crocs</strong>.</p>

<p>(when I say never attacked anyone, I mean anyone who hasn't been stupid enough to poke one in the eye or something. More about crocodiles later).</p>

<p>On Monday, I went shopping and picked up a big-arse zoom lens. I resisted the urge to spend several thousand bucks on a stabilised L series model, and went with a cheapie instead. For the camera buffs, it's an EF 90-300mm, and it's actually not that terrible (despite what you read on the net); it just suffers a bit when there's not much  light around, and at maximum zoom you can really see how bad your deliriums tremens are (is?).</p>

<p>Anyway this new toy will afford me the ability to annoy you with endless pictures of wildlife; probably mostly birds. So I hope you like birds. Stiff cheese if you don't.</p>

<p>On Tuesday I finally got into the water again, and did a couple of wreck dives in Darwin harbour. There are actually heaps of wrecks up here; some from WWII, some from Cyclone Tracy, and some random refugee boats that have been sunk (don't worry, I'm sure they locked up those child-hurling degenerate freeloaders in Baxter beforehand).</p>

<p>Darwin's water is a little different to that of the east coast. It's greener (read: murkier), and a bit siltier (read: murkier). The first dive of the day was fine, but the visibility was only about 3m. This is not much, especially at 24m down, where there ain't much in the way of light. But it was fun, and good experience. The wreck itself (a refugee boat) was completely covered in tiny little fish, so you had to shoo them away before you could even see it.</p>

<p>The second dive of the day was much cooler - an old WWII wreck. It was sunk by the Japanese, who subsequently salvaged the metal from it and sold it back to us as Toyotas. You can still see the ribs of the boat, and a lot of the stuff that was on it when it sank, like tracked vehicles and mortar shells (hitting these with hammers is inadvisable). We had a good explore, and the vis was much better (maybe 6m).</p>

<p>So all up diving in Darwin is pretty good I reckon; just don't expect crystal clear water like on the barrier reef.</p>

<p>Come Wednesday, it was finally time to move on, and so I headed off to the Mary River national park. I went via some wetlands and tested out my new lens. There is much wildlife to see.</p>

<p>I also went on a slightly daggy jumping croc cruise. This involves heading up the river in a fairly sturdy metal boat, while the guide makes the local crocs leap out of the water by offering them chunks of meat on a pole. As the guidebook says, it's a bit of a circus, but the crocs get a feed, and it's all pretty harmless (armless too if you hang yours over the side - hur hur hur hur!).</p>

<p>There are specific resident crocs that get fed, both large and small, and they know when to expect a feed too. They all have names, and the guide seems to know them pretty well. It's all quite sweet, and I really felt a lot less nervous about being near huge efficient predators than perhaps I should have.</p>

<p>(A small, perverse part of me kept picturing what would happen if one of the bigger crocs decided to jump into the boat. I figured I could move quicker than most of the older, more meaty tourists if that happened). :)</p>

<p>There were also a few birds of prey around, specifically a pair of White Breasted Sea Eagles (Oz's second largest raptor after the Wedge Tailed Eagle) and some Whistling Kites (which I can now tell from the very common Black Kites. It's all in the tail. And the colour. And the fact that they look quite different).</p>

<p>I spent the night after that in a nice little national park campground, and got some rather pretty sunset pictures. Another day, another set of sunset pics, but this time with 300mm of zoom! :)</p>

<p>Thursday, I finally made it into Kakadu proper. So far it's mostly scruffy tropical bush, with gum trees and Pandanus palms, and quite dry at this time of year. Of course, it changes dramatically in the wet.</p>

<p>Pandanus palms are, by the way, an pretty good indicator of water reasonably close to the surface. If you're ever stuck in the bush and want to build a market garden, planting near these palms is a good start.</p>

<p>Anyway I made it to another campsite, which eventually I decided I didn't like (flies, potential crocs, no walks, seen it all before...) so I pushed on to a little touristy spot on the highway, where you can camp for not a lot, and go on a nice bushwalk past some wetlands (and they had a pool).</p>

<p>And that brings me pretty much up to date. Tomorrow I think I'll head on to some more wildlife watching and walking, in the general direction of the town of Jabiru.</p>

<p>Hope you're all enjoying the sensations of life, whatever the might be right now (I'm guessing computer screens, sore backs, tired eyes...) ;)</p>

<p>Pictures this week are:</p>
<!-- 
<ul>
<li><a href="?fileId=IMG_6246.JPG">Lunching with a book in Darwin</a></li>
<li><a href="?fileId=IMG_7264.JPG">What big eyes you have, Grandma! All the better to see you with, my dear!</a></li>
<li><a href="?fileId=IMG_7290.JPG">They tried putting them on Jatz and rice crackers first, but this works better</a></li>
<li><a href="?fileId=IMG_7332.JPG">Sunset at Couzens's lookout, Mary River NP</a></li>
<li><a href="?fileId=IMG_7407_crop.jpg">Check out the those toes!</a></li>
</ul>
 -->
<table width="800">
	<tr>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=IMG_6246.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20050819/IMG_6246.JPG' ALT='Lunching with a book in Darwin'><BR>Lunching with a book in Darwin</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=IMG_7264.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20050819/IMG_7264.JPG' ALT='What big eyes you have, Grandma! All the better to see you with, my dear!'><BR>What big eyes you have, Grandma! All the better to see you with, my dear!</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=IMG_7290.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20050819/IMG_7290.JPG' ALT='They tried putting them on Jatz and rice crackers first, but this works better'><BR>They tried putting them on Jatz and rice crackers first, but this works better</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=IMG_7332.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20050819/IMG_7332.JPG' ALT="Sunset at Couzens's lookout, Mary River NP"><BR>Sunset at Couzens's lookout, Mary River NP</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=IMG_7407_crop.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20050819/IMG_7407_crop.JPG' ALT='The Comb-crested Jacana (Jesus bird) in action - check out the those toes!'><BR>The Comb-crested Jacana (Jesus bird) in action - check out the those toes!</a>
	</td>
	</tr>
</table>

<br><br>
All images in this gallery:<br>
<table width='800'>
<tr>
</tr>
<tr><td><A ID='IMG_6163.JPG' href='leapinglizards.php?fileId=IMG_6163.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050819/IMG_6163.JPG' ALT='IMG_6163.JPG'><BR>IMG_6163.JPG<br>139.56 KB</a><div class='inv'><br><a href='./images/20050819/IMG_6163.JPG' ALT='IMG_6163.JPG'>IMG_6163.JPG</a></div></td>
<td><A ID='IMG_6165.JPG' href='leapinglizards.php?fileId=IMG_6165.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050819/IMG_6165.JPG' ALT='IMG_6165.JPG'><BR>IMG_6165.JPG<br>73.3 KB</a><div class='inv'><br><a href='./images/20050819/IMG_6165.JPG' ALT='IMG_6165.JPG'>IMG_6165.JPG</a></div></td>
<td><A ID='IMG_6170.JPG' href='leapinglizards.php?fileId=IMG_6170.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050819/IMG_6170.JPG' ALT='IMG_6170.JPG'><BR>IMG_6170.JPG<br>117.71 KB</a><div class='inv'><br><a href='./images/20050819/IMG_6170.JPG' ALT='IMG_6170.JPG'>IMG_6170.JPG</a></div></td>
<td><A ID='IMG_6173.JPG' href='leapinglizards.php?fileId=IMG_6173.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050819/IMG_6173.JPG' ALT='IMG_6173.JPG'><BR>IMG_6173.JPG<br>130.47 KB</a><div class='inv'><br><a href='./images/20050819/IMG_6173.JPG' ALT='IMG_6173.JPG'>IMG_6173.JPG</a></div></td>
<td><A ID='IMG_6175.JPG' href='leapinglizards.php?fileId=IMG_6175.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050819/IMG_6175.JPG' ALT='IMG_6175.JPG'><BR>IMG_6175.JPG<br>161.47 KB</a><div class='inv'><br><a href='./images/20050819/IMG_6175.JPG' ALT='IMG_6175.JPG'>IMG_6175.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_6210.JPG' href='leapinglizards.php?fileId=IMG_6210.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050819/IMG_6210.JPG' ALT='IMG_6210.JPG'><BR>IMG_6210.JPG<br>64.36 KB</a><div class='inv'><br><a href='./images/20050819/IMG_6210.JPG' ALT='IMG_6210.JPG'>IMG_6210.JPG</a></div></td>
<td><A ID='IMG_6213.JPG' href='leapinglizards.php?fileId=IMG_6213.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050819/IMG_6213.JPG' ALT='IMG_6213.JPG'><BR>IMG_6213.JPG<br>57.85 KB</a><div class='inv'><br><a href='./images/20050819/IMG_6213.JPG' ALT='IMG_6213.JPG'>IMG_6213.JPG</a></div></td>
<td><A ID='IMG_6215.JPG' href='leapinglizards.php?fileId=IMG_6215.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050819/IMG_6215.JPG' ALT='IMG_6215.JPG'><BR>IMG_6215.JPG<br>57.14 KB</a><div class='inv'><br><a href='./images/20050819/IMG_6215.JPG' ALT='IMG_6215.JPG'>IMG_6215.JPG</a></div></td>
<td><A ID='IMG_6229.JPG' href='leapinglizards.php?fileId=IMG_6229.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050819/IMG_6229.JPG' ALT='IMG_6229.JPG'><BR>IMG_6229.JPG<br>93.21 KB</a><div class='inv'><br><a href='./images/20050819/IMG_6229.JPG' ALT='IMG_6229.JPG'>IMG_6229.JPG</a></div></td>
<td><A ID='IMG_6239.JPG' href='leapinglizards.php?fileId=IMG_6239.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050819/IMG_6239.JPG' ALT='IMG_6239.JPG'><BR>IMG_6239.JPG<br>75.79 KB</a><div class='inv'><br><a href='./images/20050819/IMG_6239.JPG' ALT='IMG_6239.JPG'>IMG_6239.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_6244.JPG' href='leapinglizards.php?fileId=IMG_6244.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050819/IMG_6244.JPG' ALT='IMG_6244.JPG'><BR>IMG_6244.JPG<br>51.87 KB</a><div class='inv'><br><a href='./images/20050819/IMG_6244.JPG' ALT='IMG_6244.JPG'>IMG_6244.JPG</a></div></td>
<td><A ID='IMG_6246.JPG' href='leapinglizards.php?fileId=IMG_6246.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050819/IMG_6246.JPG' ALT='IMG_6246.JPG'><BR>IMG_6246.JPG<br>88.12 KB</a><div class='inv'><br><a href='./images/20050819/IMG_6246.JPG' ALT='IMG_6246.JPG'>IMG_6246.JPG</a></div></td>
<td><A ID='IMG_7217.JPG' href='leapinglizards.php?fileId=IMG_7217.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050819/IMG_7217.JPG' ALT='IMG_7217.JPG'><BR>IMG_7217.JPG<br>87.95 KB</a><div class='inv'><br><a href='./images/20050819/IMG_7217.JPG' ALT='IMG_7217.JPG'>IMG_7217.JPG</a></div></td>
<td><A ID='IMG_7229.JPG' href='leapinglizards.php?fileId=IMG_7229.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050819/IMG_7229.JPG' ALT='IMG_7229.JPG'><BR>IMG_7229.JPG<br>76.74 KB</a><div class='inv'><br><a href='./images/20050819/IMG_7229.JPG' ALT='IMG_7229.JPG'>IMG_7229.JPG</a></div></td>
<td><A ID='IMG_7236.JPG' href='leapinglizards.php?fileId=IMG_7236.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050819/IMG_7236.JPG' ALT='IMG_7236.JPG'><BR>IMG_7236.JPG<br>72.69 KB</a><div class='inv'><br><a href='./images/20050819/IMG_7236.JPG' ALT='IMG_7236.JPG'>IMG_7236.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_7237.JPG' href='leapinglizards.php?fileId=IMG_7237.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050819/IMG_7237.JPG' ALT='IMG_7237.JPG'><BR>IMG_7237.JPG<br>106.21 KB</a><div class='inv'><br><a href='./images/20050819/IMG_7237.JPG' ALT='IMG_7237.JPG'>IMG_7237.JPG</a></div></td>
<td><A ID='IMG_7248.JPG' href='leapinglizards.php?fileId=IMG_7248.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050819/IMG_7248.JPG' ALT='IMG_7248.JPG'><BR>IMG_7248.JPG<br>58.99 KB</a><div class='inv'><br><a href='./images/20050819/IMG_7248.JPG' ALT='IMG_7248.JPG'>IMG_7248.JPG</a></div></td>
<td><A ID='IMG_7252.JPG' href='leapinglizards.php?fileId=IMG_7252.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050819/IMG_7252.JPG' ALT='IMG_7252.JPG'><BR>IMG_7252.JPG<br>132.09 KB</a><div class='inv'><br><a href='./images/20050819/IMG_7252.JPG' ALT='IMG_7252.JPG'>IMG_7252.JPG</a></div></td>
<td><A ID='IMG_7260.JPG' href='leapinglizards.php?fileId=IMG_7260.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050819/IMG_7260.JPG' ALT='IMG_7260.JPG'><BR>IMG_7260.JPG<br>80.77 KB</a><div class='inv'><br><a href='./images/20050819/IMG_7260.JPG' ALT='IMG_7260.JPG'>IMG_7260.JPG</a></div></td>
<td><A ID='IMG_7261.JPG' href='leapinglizards.php?fileId=IMG_7261.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050819/IMG_7261.JPG' ALT='IMG_7261.JPG'><BR>IMG_7261.JPG<br>52.57 KB</a><div class='inv'><br><a href='./images/20050819/IMG_7261.JPG' ALT='IMG_7261.JPG'>IMG_7261.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_7264.JPG' href='leapinglizards.php?fileId=IMG_7264.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050819/IMG_7264.JPG' ALT='IMG_7264.JPG'><BR>IMG_7264.JPG<br>107.55 KB</a><div class='inv'><br><a href='./images/20050819/IMG_7264.JPG' ALT='IMG_7264.JPG'>IMG_7264.JPG</a></div></td>
<td><A ID='IMG_7267.JPG' href='leapinglizards.php?fileId=IMG_7267.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050819/IMG_7267.JPG' ALT='IMG_7267.JPG'><BR>IMG_7267.JPG<br>52.96 KB</a><div class='inv'><br><a href='./images/20050819/IMG_7267.JPG' ALT='IMG_7267.JPG'>IMG_7267.JPG</a></div></td>
<td><A ID='IMG_7271.JPG' href='leapinglizards.php?fileId=IMG_7271.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050819/IMG_7271.JPG' ALT='IMG_7271.JPG'><BR>IMG_7271.JPG<br>88.05 KB</a><div class='inv'><br><a href='./images/20050819/IMG_7271.JPG' ALT='IMG_7271.JPG'>IMG_7271.JPG</a></div></td>
<td><A ID='IMG_7278.JPG' href='leapinglizards.php?fileId=IMG_7278.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050819/IMG_7278.JPG' ALT='IMG_7278.JPG'><BR>IMG_7278.JPG<br>36.33 KB</a><div class='inv'><br><a href='./images/20050819/IMG_7278.JPG' ALT='IMG_7278.JPG'>IMG_7278.JPG</a></div></td>
<td><A ID='IMG_7279.JPG' href='leapinglizards.php?fileId=IMG_7279.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050819/IMG_7279.JPG' ALT='IMG_7279.JPG'><BR>IMG_7279.JPG<br>36.83 KB</a><div class='inv'><br><a href='./images/20050819/IMG_7279.JPG' ALT='IMG_7279.JPG'>IMG_7279.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_7281.JPG' href='leapinglizards.php?fileId=IMG_7281.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050819/IMG_7281.JPG' ALT='IMG_7281.JPG'><BR>IMG_7281.JPG<br>41.45 KB</a><div class='inv'><br><a href='./images/20050819/IMG_7281.JPG' ALT='IMG_7281.JPG'>IMG_7281.JPG</a></div></td>
<td><A ID='IMG_7284.JPG' href='leapinglizards.php?fileId=IMG_7284.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050819/IMG_7284.JPG' ALT='IMG_7284.JPG'><BR>IMG_7284.JPG<br>53.46 KB</a><div class='inv'><br><a href='./images/20050819/IMG_7284.JPG' ALT='IMG_7284.JPG'>IMG_7284.JPG</a></div></td>
<td><A ID='IMG_7285.JPG' href='leapinglizards.php?fileId=IMG_7285.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050819/IMG_7285.JPG' ALT='IMG_7285.JPG'><BR>IMG_7285.JPG<br>41.75 KB</a><div class='inv'><br><a href='./images/20050819/IMG_7285.JPG' ALT='IMG_7285.JPG'>IMG_7285.JPG</a></div></td>
<td><A ID='IMG_7286.JPG' href='leapinglizards.php?fileId=IMG_7286.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050819/IMG_7286.JPG' ALT='IMG_7286.JPG'><BR>IMG_7286.JPG<br>44.85 KB</a><div class='inv'><br><a href='./images/20050819/IMG_7286.JPG' ALT='IMG_7286.JPG'>IMG_7286.JPG</a></div></td>
<td><A ID='IMG_7287.JPG' href='leapinglizards.php?fileId=IMG_7287.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050819/IMG_7287.JPG' ALT='IMG_7287.JPG'><BR>IMG_7287.JPG<br>49.5 KB</a><div class='inv'><br><a href='./images/20050819/IMG_7287.JPG' ALT='IMG_7287.JPG'>IMG_7287.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_7288.JPG' href='leapinglizards.php?fileId=IMG_7288.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050819/IMG_7288.JPG' ALT='IMG_7288.JPG'><BR>IMG_7288.JPG<br>63.76 KB</a><div class='inv'><br><a href='./images/20050819/IMG_7288.JPG' ALT='IMG_7288.JPG'>IMG_7288.JPG</a></div></td>
<td><A ID='IMG_7289.JPG' href='leapinglizards.php?fileId=IMG_7289.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050819/IMG_7289.JPG' ALT='IMG_7289.JPG'><BR>IMG_7289.JPG<br>63.34 KB</a><div class='inv'><br><a href='./images/20050819/IMG_7289.JPG' ALT='IMG_7289.JPG'>IMG_7289.JPG</a></div></td>
<td><A ID='IMG_7290.JPG' href='leapinglizards.php?fileId=IMG_7290.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050819/IMG_7290.JPG' ALT='IMG_7290.JPG'><BR>IMG_7290.JPG<br>62.56 KB</a><div class='inv'><br><a href='./images/20050819/IMG_7290.JPG' ALT='IMG_7290.JPG'>IMG_7290.JPG</a></div></td>
<td><A ID='IMG_7291.JPG' href='leapinglizards.php?fileId=IMG_7291.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050819/IMG_7291.JPG' ALT='IMG_7291.JPG'><BR>IMG_7291.JPG<br>58.42 KB</a><div class='inv'><br><a href='./images/20050819/IMG_7291.JPG' ALT='IMG_7291.JPG'>IMG_7291.JPG</a></div></td>
<td><A ID='IMG_7293.JPG' href='leapinglizards.php?fileId=IMG_7293.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050819/IMG_7293.JPG' ALT='IMG_7293.JPG'><BR>IMG_7293.JPG<br>53.1 KB</a><div class='inv'><br><a href='./images/20050819/IMG_7293.JPG' ALT='IMG_7293.JPG'>IMG_7293.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_7294.JPG' href='leapinglizards.php?fileId=IMG_7294.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050819/IMG_7294.JPG' ALT='IMG_7294.JPG'><BR>IMG_7294.JPG<br>56.51 KB</a><div class='inv'><br><a href='./images/20050819/IMG_7294.JPG' ALT='IMG_7294.JPG'>IMG_7294.JPG</a></div></td>
<td><A ID='IMG_7295.JPG' href='leapinglizards.php?fileId=IMG_7295.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050819/IMG_7295.JPG' ALT='IMG_7295.JPG'><BR>IMG_7295.JPG<br>57.88 KB</a><div class='inv'><br><a href='./images/20050819/IMG_7295.JPG' ALT='IMG_7295.JPG'>IMG_7295.JPG</a></div></td>
<td><A ID='IMG_7296.JPG' href='leapinglizards.php?fileId=IMG_7296.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050819/IMG_7296.JPG' ALT='IMG_7296.JPG'><BR>IMG_7296.JPG<br>55.78 KB</a><div class='inv'><br><a href='./images/20050819/IMG_7296.JPG' ALT='IMG_7296.JPG'>IMG_7296.JPG</a></div></td>
<td><A ID='IMG_7297.JPG' href='leapinglizards.php?fileId=IMG_7297.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050819/IMG_7297.JPG' ALT='IMG_7297.JPG'><BR>IMG_7297.JPG<br>54.8 KB</a><div class='inv'><br><a href='./images/20050819/IMG_7297.JPG' ALT='IMG_7297.JPG'>IMG_7297.JPG</a></div></td>
<td><A ID='IMG_7299.JPG' href='leapinglizards.php?fileId=IMG_7299.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050819/IMG_7299.JPG' ALT='IMG_7299.JPG'><BR>IMG_7299.JPG<br>33.77 KB</a><div class='inv'><br><a href='./images/20050819/IMG_7299.JPG' ALT='IMG_7299.JPG'>IMG_7299.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_7300.JPG' href='leapinglizards.php?fileId=IMG_7300.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050819/IMG_7300.JPG' ALT='IMG_7300.JPG'><BR>IMG_7300.JPG<br>38.13 KB</a><div class='inv'><br><a href='./images/20050819/IMG_7300.JPG' ALT='IMG_7300.JPG'>IMG_7300.JPG</a></div></td>
<td><A ID='IMG_7303.JPG' href='leapinglizards.php?fileId=IMG_7303.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050819/IMG_7303.JPG' ALT='IMG_7303.JPG'><BR>IMG_7303.JPG<br>65.69 KB</a><div class='inv'><br><a href='./images/20050819/IMG_7303.JPG' ALT='IMG_7303.JPG'>IMG_7303.JPG</a></div></td>
<td><A ID='IMG_7309.JPG' href='leapinglizards.php?fileId=IMG_7309.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050819/IMG_7309.JPG' ALT='IMG_7309.JPG'><BR>IMG_7309.JPG<br>61.16 KB</a><div class='inv'><br><a href='./images/20050819/IMG_7309.JPG' ALT='IMG_7309.JPG'>IMG_7309.JPG</a></div></td>
<td><A ID='IMG_7313.JPG' href='leapinglizards.php?fileId=IMG_7313.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050819/IMG_7313.JPG' ALT='IMG_7313.JPG'><BR>IMG_7313.JPG<br>48.27 KB</a><div class='inv'><br><a href='./images/20050819/IMG_7313.JPG' ALT='IMG_7313.JPG'>IMG_7313.JPG</a></div></td>
<td><A ID='IMG_7320.JPG' href='leapinglizards.php?fileId=IMG_7320.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050819/IMG_7320.JPG' ALT='IMG_7320.JPG'><BR>IMG_7320.JPG<br>122.6 KB</a><div class='inv'><br><a href='./images/20050819/IMG_7320.JPG' ALT='IMG_7320.JPG'>IMG_7320.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_7329.JPG' href='leapinglizards.php?fileId=IMG_7329.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050819/IMG_7329.JPG' ALT='IMG_7329.JPG'><BR>IMG_7329.JPG<br>38.68 KB</a><div class='inv'><br><a href='./images/20050819/IMG_7329.JPG' ALT='IMG_7329.JPG'>IMG_7329.JPG</a></div></td>
<td><A ID='IMG_7330.JPG' href='leapinglizards.php?fileId=IMG_7330.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050819/IMG_7330.JPG' ALT='IMG_7330.JPG'><BR>IMG_7330.JPG<br>67.99 KB</a><div class='inv'><br><a href='./images/20050819/IMG_7330.JPG' ALT='IMG_7330.JPG'>IMG_7330.JPG</a></div></td>
<td><A ID='IMG_7332.JPG' href='leapinglizards.php?fileId=IMG_7332.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050819/IMG_7332.JPG' ALT='IMG_7332.JPG'><BR>IMG_7332.JPG<br>46.82 KB</a><div class='inv'><br><a href='./images/20050819/IMG_7332.JPG' ALT='IMG_7332.JPG'>IMG_7332.JPG</a></div></td>
<td><A ID='IMG_7335.JPG' href='leapinglizards.php?fileId=IMG_7335.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050819/IMG_7335.JPG' ALT='IMG_7335.JPG'><BR>IMG_7335.JPG<br>36.46 KB</a><div class='inv'><br><a href='./images/20050819/IMG_7335.JPG' ALT='IMG_7335.JPG'>IMG_7335.JPG</a></div></td>
<td><A ID='IMG_7337.JPG' href='leapinglizards.php?fileId=IMG_7337.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050819/IMG_7337.JPG' ALT='IMG_7337.JPG'><BR>IMG_7337.JPG<br>36.89 KB</a><div class='inv'><br><a href='./images/20050819/IMG_7337.JPG' ALT='IMG_7337.JPG'>IMG_7337.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_7338.JPG' href='leapinglizards.php?fileId=IMG_7338.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050819/IMG_7338.JPG' ALT='IMG_7338.JPG'><BR>IMG_7338.JPG<br>40.46 KB</a><div class='inv'><br><a href='./images/20050819/IMG_7338.JPG' ALT='IMG_7338.JPG'>IMG_7338.JPG</a></div></td>
<td><A ID='IMG_7341.JPG' href='leapinglizards.php?fileId=IMG_7341.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050819/IMG_7341.JPG' ALT='IMG_7341.JPG'><BR>IMG_7341.JPG<br>29.51 KB</a><div class='inv'><br><a href='./images/20050819/IMG_7341.JPG' ALT='IMG_7341.JPG'>IMG_7341.JPG</a></div></td>
<td><A ID='IMG_7346.JPG' href='leapinglizards.php?fileId=IMG_7346.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050819/IMG_7346.JPG' ALT='IMG_7346.JPG'><BR>IMG_7346.JPG<br>21.52 KB</a><div class='inv'><br><a href='./images/20050819/IMG_7346.JPG' ALT='IMG_7346.JPG'>IMG_7346.JPG</a></div></td>
<td><A ID='IMG_7347.JPG' href='leapinglizards.php?fileId=IMG_7347.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050819/IMG_7347.JPG' ALT='IMG_7347.JPG'><BR>IMG_7347.JPG<br>79.6 KB</a><div class='inv'><br><a href='./images/20050819/IMG_7347.JPG' ALT='IMG_7347.JPG'>IMG_7347.JPG</a></div></td>
<td><A ID='IMG_7348.JPG' href='leapinglizards.php?fileId=IMG_7348.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050819/IMG_7348.JPG' ALT='IMG_7348.JPG'><BR>IMG_7348.JPG<br>77.17 KB</a><div class='inv'><br><a href='./images/20050819/IMG_7348.JPG' ALT='IMG_7348.JPG'>IMG_7348.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_7355.JPG' href='leapinglizards.php?fileId=IMG_7355.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050819/IMG_7355.JPG' ALT='IMG_7355.JPG'><BR>IMG_7355.JPG<br>32.47 KB</a><div class='inv'><br><a href='./images/20050819/IMG_7355.JPG' ALT='IMG_7355.JPG'>IMG_7355.JPG</a></div></td>
<td><A ID='IMG_7363.JPG' href='leapinglizards.php?fileId=IMG_7363.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050819/IMG_7363.JPG' ALT='IMG_7363.JPG'><BR>IMG_7363.JPG<br>21.92 KB</a><div class='inv'><br><a href='./images/20050819/IMG_7363.JPG' ALT='IMG_7363.JPG'>IMG_7363.JPG</a></div></td>
<td><A ID='IMG_7367.JPG' href='leapinglizards.php?fileId=IMG_7367.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050819/IMG_7367.JPG' ALT='IMG_7367.JPG'><BR>IMG_7367.JPG<br>122.4 KB</a><div class='inv'><br><a href='./images/20050819/IMG_7367.JPG' ALT='IMG_7367.JPG'>IMG_7367.JPG</a></div></td>
<td><A ID='IMG_7370.JPG' href='leapinglizards.php?fileId=IMG_7370.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050819/IMG_7370.JPG' ALT='IMG_7370.JPG'><BR>IMG_7370.JPG<br>68 KB</a><div class='inv'><br><a href='./images/20050819/IMG_7370.JPG' ALT='IMG_7370.JPG'>IMG_7370.JPG</a></div></td>
<td><A ID='IMG_7379.JPG' href='leapinglizards.php?fileId=IMG_7379.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050819/IMG_7379.JPG' ALT='IMG_7379.JPG'><BR>IMG_7379.JPG<br>82.26 KB</a><div class='inv'><br><a href='./images/20050819/IMG_7379.JPG' ALT='IMG_7379.JPG'>IMG_7379.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_7390.JPG' href='leapinglizards.php?fileId=IMG_7390.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050819/IMG_7390.JPG' ALT='IMG_7390.JPG'><BR>IMG_7390.JPG<br>136.87 KB</a><div class='inv'><br><a href='./images/20050819/IMG_7390.JPG' ALT='IMG_7390.JPG'>IMG_7390.JPG</a></div></td>
<td><A ID='IMG_7392.JPG' href='leapinglizards.php?fileId=IMG_7392.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050819/IMG_7392.JPG' ALT='IMG_7392.JPG'><BR>IMG_7392.JPG<br>75.86 KB</a><div class='inv'><br><a href='./images/20050819/IMG_7392.JPG' ALT='IMG_7392.JPG'>IMG_7392.JPG</a></div></td>
<td><A ID='IMG_7399.JPG' href='leapinglizards.php?fileId=IMG_7399.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050819/IMG_7399.JPG' ALT='IMG_7399.JPG'><BR>IMG_7399.JPG<br>136.32 KB</a><div class='inv'><br><a href='./images/20050819/IMG_7399.JPG' ALT='IMG_7399.JPG'>IMG_7399.JPG</a></div></td>
<td><A ID='IMG_7400.JPG' href='leapinglizards.php?fileId=IMG_7400.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050819/IMG_7400.JPG' ALT='IMG_7400.JPG'><BR>IMG_7400.JPG<br>92.57 KB</a><div class='inv'><br><a href='./images/20050819/IMG_7400.JPG' ALT='IMG_7400.JPG'>IMG_7400.JPG</a></div></td>
<td><A ID='IMG_7404.JPG' href='leapinglizards.php?fileId=IMG_7404.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050819/IMG_7404.JPG' ALT='IMG_7404.JPG'><BR>IMG_7404.JPG<br>131.88 KB</a><div class='inv'><br><a href='./images/20050819/IMG_7404.JPG' ALT='IMG_7404.JPG'>IMG_7404.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_7405.JPG' href='leapinglizards.php?fileId=IMG_7405.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050819/IMG_7405.JPG' ALT='IMG_7405.JPG'><BR>IMG_7405.JPG<br>102.78 KB</a><div class='inv'><br><a href='./images/20050819/IMG_7405.JPG' ALT='IMG_7405.JPG'>IMG_7405.JPG</a></div></td>
<td><A ID='IMG_7407_crop.JPG' href='leapinglizards.php?fileId=IMG_7407_crop.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050819/IMG_7407_crop.JPG' ALT='IMG_7407_crop.JPG'><BR>IMG_7407_crop.JPG<br>85.18 KB</a><div class='inv'><br><a href='./images/20050819/IMG_7407_crop.JPG' ALT='IMG_7407_crop.JPG'>IMG_7407_crop.JPG</a></div></td>
<td><A ID='IMG_7431.JPG' href='leapinglizards.php?fileId=IMG_7431.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050819/IMG_7431.JPG' ALT='IMG_7431.JPG'><BR>IMG_7431.JPG<br>89.1 KB</a><div class='inv'><br><a href='./images/20050819/IMG_7431.JPG' ALT='IMG_7431.JPG'>IMG_7431.JPG</a></div></td>
</tr>
</table>	</div>
</div>
</body>
</html>