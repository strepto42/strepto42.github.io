<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - 14/12/2000 - Back to bloody reality</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="Back to bloody reality">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="Greetings from the Other Side" href='greetingsfromtheotherside.php'>16/10/2000</a></li>
<li><a title="Another quick update from the land of rupees..." href='anotherquickupdate.php'>19/10/2000</a></li>
<li><a title="More Miscellaneous Ramblings from the Teeming Subcontinent" href='subcontinentramblings.php'>25/10/2000</a></li>
<li><a title="Indian Update" href='indianupdate.php'>4/11/2000</a></li>
<li><a title="From the Ganges to the Taj... and beyond" href='gangestotaj.php'>18/11/2000</a></li>
<li><a title="Camels, Tigers, Elephants and Octopussies" href='camelstigersoctopussies.php'>9/12/2000</a></li>
<li><div class='activemenu'>14/12/2000</div></li>
<li> </li><br><li>Or go back to:</li><li><a title='Travelouges from my trip through India in 2000' href="india2000.php">India 2000</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>14/12/2000</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Travel stories and pictures' href="travel.php">Travelogues</a> > <a title='Travelouges from my trip through India in 2000' href="india2000.php">India 2000</a> > <a title='Back to bloody reality' href="backtobloodyreality.php">14/12/2000</a>
<br><br>		


<h1>Back to bloody reality!</h1>

<p>Well folks, this is it! Last email before home-time. :) I must say it has 
been a blast. Definitely worth any hassles we've had.</p>

<p>So - to our final adventures. After I last wrote we hopped on a train to 
Aurangabad, about 7 or 8 hours northwest of Bombay. This is quite a touristy 
place, but worth visiting as there are various places nearby of interest. 
Specifically, the caves at Ajanta and Elora, and the meteorite crater at 
Lonar.</p>

<p>In the end we didn't get to Ajanta, due to lack of time, which was a pity, 
because it was supposed to be very nice.</p>

<p>Our first excursion was out to Lonar. It's a bit off the beaten track, and 
in the end we decided to get a taxi out there and back (a round trip of 
about 400kms!). Cost quite a bit by Indian standards, but we figured it was 
worth it, and in reality it worked out at about A$70. Pretty damn good when 
you think about how far that gets you in Oz!</p>

<p>It was also well worth it. The crater at Lonar is a really lovely place. It 
is thought to be about 40,000 years old, is about two kilometres in diameter 
and several hundred metres deep. A sign at the site proudly proclaims that 
it is 'the only natural hypervelocity impact crater in basaltic rock in the 
world'. Very impressive sounding, but doesn't do justice to the beauty of 
the place. We had heard there was a lake at the bottom, and had visions of a 
small mucky thing with a few trees perhaps.</p>

<p>In reality the lake was rather large, and was a gorgeous green colour. There 
were trees and greenery galore around it. We walked down into it and about a 
third of the way around, to a temple that was there. On the way we passed a 
couple of small disused temples/buildings. They were both full of bats. It 
was easy to imagine twilight falling and the ensuing horror movie scene with 
bats flying from the 'crypt'. :)</p>

<p>There were also all sorts of other creatures living down there; birds, big 
wildcats (a bit bigger than housecats), and of course our favourite - 
monkeys. It was what I would call a definite oasis in the barren area. Well 
worth the visit.</p>

<p>One other funny story from that day - we stopped on the way for tea in a 
small village. By now we're quite used to drawing a small crowd of people at 
times, especially when you're off the beaten track, but this time took the 
cake big time!</p>

<p>At first there were maybe 10 people, but by the time we had finished our tea 
there were easily 100 people. I'm not exaggerating either! All crowding 
around and staring at the strange tourists. It was quite funny. 
Unfortunately we didn't get a photo. I don't know where they all came from!</p>

<p>Our other excursion from Aurangabad was to the Elora caves nearby. These are 
basically a series of caves hand carved out of the (rather bloody solid) 
volcanic rock. They date from around 600AD to 1000AD. They're quite 
impressive when you think about the work involved - these aren't tiny little 
things at all. There is one really big one, which is more a temple than a 
cave, but it is carved out of solid rock. Apparently is is twice the area of 
the Greek Parthenon, and much higher. About 200,000 tonnes of rock have been 
removed to make it.</p>

<p>The whole place was quite lovely, and the serenity of some of the caves is 
quite wonderful (there are bats in quite a few as well). The serenity though 
was strained a little by the groups of Indians, who don't seem to know about 
silence, or at least talking softly. Ho well. Another amusing anecdote on 
Indian noise levels follows below.</p>

<p>So that was the last of our 'tourist' stops. From there it was back on a 
train to bombay. The train journey was pretty good this time - on the way 
out there it was packed. Not just people who had seats/beds reserved, but 
many other people packed the carriage (or 'bogey' as they call them here); 
there was no floor space at all, people were everywhere.</p>

<p>Some considerate gents decided to have a heated argument at about 3am. One 
fellow was outside the train (we were stopped), so the shouting went on 
through the window as well. But as I was saying the trip back was pretty 
good. We had a good mix of people in our little booth - a French guy and an 
American lady. We all fell into conversation and were having a fine old time 
- it's not often over here you can talk quickly and about complex things as 
a lot of Indians speak english, but not too well - when we got told off by 
an INDIAN guy for being too noisy. I think perhaps he didn't understand why 
we found this so amusing. Eventually we went to sleep, to the usual sounds 
of snoring and farting through the night. Too much noise indeed! :)</p>

<p>So now we're back in Bombay, or Mumbai, or whatever it is called now.</p>

<p>Bombay itself is actually a lot better than I thought it would be. The air 
is in fact remarkably clean given the number of people here. And as for the 
'smell that hits you as soon as you get off the plane' that various people 
had mentioned to me, I haven't noticed it particularly.  The slum area tends 
to pong a bit, but then again so does a public toilet. But the smell is 
hardly all-pervasive. Delhi's air was far worse.</p>

<p>The city is indeed much more cosmopolitan than anywhere else in India. There 
are even high-rise buildings here - rather an odd sight for me after two 
months.</p>

<p>There are certainly some things I'll miss when I'm back home.</p>

<p>For starters, the chaos. It can be a bit much at times, but it's fun to be 
swept up in it. I know Sydney can be chaotic too, but it isn't the same. 
Everything is so damn *safe* back home. It is so nice to be in a country 
where everyone isn't afraid of getting bloody sued all the time. Fireworks 
are legal. Roads are chaotic, but seem to work pretty well. You can smoke 
just about anywhere. The attitude is best summed up by a sign on the trains 
- "please do not smoke if other passengers object". Simple solution. 
Everyone happy.</p>

<p>I'll also miss the friendliness of the people. It can grate a bit at times 
(like at 5am when you've just gotten off a long train or bus ride) to be 
surrounded on all sides by eager people. And sure, lots of the time people 
just want something (well, money) from you. But there is a genuine 
friendliness here that we don't quite have at home, especially in Sydney. I 
suppose, thinking about it, that country areas are much better in Australia, 
and a fair bit more similar in that respect.</p>

<p>I'll miss the fact that, for 50 cents or a dollar, I can get a shave here. 
And I mean a proper shave - brush, lather, trim followed by various potions 
and powders rubbed and splattered liberally over my face.</p>

<p>I'll miss the animals everywhere. I remember coming round a corner in a taxi 
when we were in Varanasi and nearly running into a herd of braying donkeys. 
Over here, especially in the more rural areas, there are always cattle, 
goats, dogs, pigs, donkeys and camels roaming around, generally happy as 
larry. Lots of baby animals tagging along behind their Mums too. Baby goats 
(I won't say kids for the sake of clarity) are bloody cute.</p>

<p>I'll miss being able to get a good feed for about 5 bucks.</p>

<p>I'll miss the excitement of finding out if there is hot water every morning. 
Ooops... lapsed into sarcasm there. But it's not so bad; it's a warm 
country. I'll wager it's about the same temperature here in Bombay as it is 
in Sydney - and this is winter. Summer might be less pleasant I guess. :)</p>

<p>And I'll miss the weird and wonderful english written everywhere. And menu 
items like "Brain Egg Fry" (not to be confused with "Brain Plain Fry" - try 
and say that quickly five times).</p>

<p>So it's back to reality, or our version of it. I'll definitely come back 
here some day though. I can see how it gets into the blood, and once you've 
gotten used to the way things work it's pretty easy to get along (and you 
get to impress people who have just arrived with your extensive knowledge). 
;)</p>

<p>India is definitely recommended. You should all come here (if you haven't 
already. If you have, you should come back).</p>

<p>Anyway time to sign off. Thanks for the encouragement and stories of home. 
Poo to those of you who NEVER wrote, even in two months! ;)</p>
<br><br>
All images in this gallery:<br>
<table width='800'>
<tr>
</tr>
<tr><td><A ID='F1060018.JPG' href='backtobloodyreality.php?fileId=F1060018.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001214/F1060018.JPG' ALT='F1060018.JPG'><BR>F1060018.JPG<br>52.54 KB</a><div class='inv'><br><a href='./images/20001214/F1060018.JPG' ALT='F1060018.JPG'>F1060018.JPG</a></div></td>
<td><A ID='F1060019.JPG' href='backtobloodyreality.php?fileId=F1060019.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001214/F1060019.JPG' ALT='F1060019.JPG'><BR>F1060019.JPG<br>73.75 KB</a><div class='inv'><br><a href='./images/20001214/F1060019.JPG' ALT='F1060019.JPG'>F1060019.JPG</a></div></td>
<td><A ID='F1060024.JPG' href='backtobloodyreality.php?fileId=F1060024.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001214/F1060024.JPG' ALT='F1060024.JPG'><BR>F1060024.JPG<br>115.3 KB</a><div class='inv'><br><a href='./images/20001214/F1060024.JPG' ALT='F1060024.JPG'>F1060024.JPG</a></div></td>
<td><A ID='F1060026.JPG' href='backtobloodyreality.php?fileId=F1060026.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001214/F1060026.JPG' ALT='F1060026.JPG'><BR>F1060026.JPG<br>49.71 KB</a><div class='inv'><br><a href='./images/20001214/F1060026.JPG' ALT='F1060026.JPG'>F1060026.JPG</a></div></td>
<td><A ID='F1060027.JPG' href='backtobloodyreality.php?fileId=F1060027.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001214/F1060027.JPG' ALT='F1060027.JPG'><BR>F1060027.JPG<br>55.12 KB</a><div class='inv'><br><a href='./images/20001214/F1060027.JPG' ALT='F1060027.JPG'>F1060027.JPG</a></div></td>
</tr>
<tr><td><A ID='F1060028.JPG' href='backtobloodyreality.php?fileId=F1060028.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001214/F1060028.JPG' ALT='F1060028.JPG'><BR>F1060028.JPG<br>83.32 KB</a><div class='inv'><br><a href='./images/20001214/F1060028.JPG' ALT='F1060028.JPG'>F1060028.JPG</a></div></td>
<td><A ID='F1060029.JPG' href='backtobloodyreality.php?fileId=F1060029.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001214/F1060029.JPG' ALT='F1060029.JPG'><BR>F1060029.JPG<br>83.56 KB</a><div class='inv'><br><a href='./images/20001214/F1060029.JPG' ALT='F1060029.JPG'>F1060029.JPG</a></div></td>
<td><A ID='F1060031.JPG' href='backtobloodyreality.php?fileId=F1060031.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001214/F1060031.JPG' ALT='F1060031.JPG'><BR>F1060031.JPG<br>93.47 KB</a><div class='inv'><br><a href='./images/20001214/F1060031.JPG' ALT='F1060031.JPG'>F1060031.JPG</a></div></td>
<td><A ID='F1060032.JPG' href='backtobloodyreality.php?fileId=F1060032.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001214/F1060032.JPG' ALT='F1060032.JPG'><BR>F1060032.JPG<br>84.06 KB</a><div class='inv'><br><a href='./images/20001214/F1060032.JPG' ALT='F1060032.JPG'>F1060032.JPG</a></div></td>
<td><A ID='F1060033.JPG' href='backtobloodyreality.php?fileId=F1060033.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001214/F1060033.JPG' ALT='F1060033.JPG'><BR>F1060033.JPG<br>82.31 KB</a><div class='inv'><br><a href='./images/20001214/F1060033.JPG' ALT='F1060033.JPG'>F1060033.JPG</a></div></td>
</tr>
<tr><td><A ID='F1060035.JPG' href='backtobloodyreality.php?fileId=F1060035.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001214/F1060035.JPG' ALT='F1060035.JPG'><BR>F1060035.JPG<br>91.24 KB</a><div class='inv'><br><a href='./images/20001214/F1060035.JPG' ALT='F1060035.JPG'>F1060035.JPG</a></div></td>
<td><A ID='F1060037.JPG' href='backtobloodyreality.php?fileId=F1060037.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001214/F1060037.JPG' ALT='F1060037.JPG'><BR>F1060037.JPG<br>112.34 KB</a><div class='inv'><br><a href='./images/20001214/F1060037.JPG' ALT='F1060037.JPG'>F1060037.JPG</a></div></td>
<td><A ID='F1070001.JPG' href='backtobloodyreality.php?fileId=F1070001.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001214/F1070001.JPG' ALT='F1070001.JPG'><BR>F1070001.JPG<br>107.82 KB</a><div class='inv'><br><a href='./images/20001214/F1070001.JPG' ALT='F1070001.JPG'>F1070001.JPG</a></div></td>
<td><A ID='F1070004.JPG' href='backtobloodyreality.php?fileId=F1070004.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001214/F1070004.JPG' ALT='F1070004.JPG'><BR>F1070004.JPG<br>114.31 KB</a><div class='inv'><br><a href='./images/20001214/F1070004.JPG' ALT='F1070004.JPG'>F1070004.JPG</a></div></td>
<td><A ID='F1070005.JPG' href='backtobloodyreality.php?fileId=F1070005.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001214/F1070005.JPG' ALT='F1070005.JPG'><BR>F1070005.JPG<br>153.86 KB</a><div class='inv'><br><a href='./images/20001214/F1070005.JPG' ALT='F1070005.JPG'>F1070005.JPG</a></div></td>
</tr>
<tr><td><A ID='F1070006.JPG' href='backtobloodyreality.php?fileId=F1070006.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001214/F1070006.JPG' ALT='F1070006.JPG'><BR>F1070006.JPG<br>137.87 KB</a><div class='inv'><br><a href='./images/20001214/F1070006.JPG' ALT='F1070006.JPG'>F1070006.JPG</a></div></td>
<td><A ID='F1070007.JPG' href='backtobloodyreality.php?fileId=F1070007.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001214/F1070007.JPG' ALT='F1070007.JPG'><BR>F1070007.JPG<br>130.09 KB</a><div class='inv'><br><a href='./images/20001214/F1070007.JPG' ALT='F1070007.JPG'>F1070007.JPG</a></div></td>
<td><A ID='F1070008.JPG' href='backtobloodyreality.php?fileId=F1070008.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001214/F1070008.JPG' ALT='F1070008.JPG'><BR>F1070008.JPG<br>150.31 KB</a><div class='inv'><br><a href='./images/20001214/F1070008.JPG' ALT='F1070008.JPG'>F1070008.JPG</a></div></td>
<td><A ID='F1070010.JPG' href='backtobloodyreality.php?fileId=F1070010.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001214/F1070010.JPG' ALT='F1070010.JPG'><BR>F1070010.JPG<br>97.91 KB</a><div class='inv'><br><a href='./images/20001214/F1070010.JPG' ALT='F1070010.JPG'>F1070010.JPG</a></div></td>
<td><A ID='F1070011.JPG' href='backtobloodyreality.php?fileId=F1070011.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001214/F1070011.JPG' ALT='F1070011.JPG'><BR>F1070011.JPG<br>116.17 KB</a><div class='inv'><br><a href='./images/20001214/F1070011.JPG' ALT='F1070011.JPG'>F1070011.JPG</a></div></td>
</tr>
<tr><td><A ID='F1070013.JPG' href='backtobloodyreality.php?fileId=F1070013.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001214/F1070013.JPG' ALT='F1070013.JPG'><BR>F1070013.JPG<br>135.48 KB</a><div class='inv'><br><a href='./images/20001214/F1070013.JPG' ALT='F1070013.JPG'>F1070013.JPG</a></div></td>
<td><A ID='F1070014.JPG' href='backtobloodyreality.php?fileId=F1070014.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001214/F1070014.JPG' ALT='F1070014.JPG'><BR>F1070014.JPG<br>122.17 KB</a><div class='inv'><br><a href='./images/20001214/F1070014.JPG' ALT='F1070014.JPG'>F1070014.JPG</a></div></td>
<td><A ID='F1070015.JPG' href='backtobloodyreality.php?fileId=F1070015.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001214/F1070015.JPG' ALT='F1070015.JPG'><BR>F1070015.JPG<br>149.27 KB</a><div class='inv'><br><a href='./images/20001214/F1070015.JPG' ALT='F1070015.JPG'>F1070015.JPG</a></div></td>
<td><A ID='F1070016.JPG' href='backtobloodyreality.php?fileId=F1070016.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20001214/F1070016.JPG' ALT='F1070016.JPG'><BR>F1070016.JPG<br>79.42 KB</a><div class='inv'><br><a href='./images/20001214/F1070016.JPG' ALT='F1070016.JPG'>F1070016.JPG</a></div></td>
</tr>
</table>	</div>
</div>
</body>
</html>