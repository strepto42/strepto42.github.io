<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - September 2006 - Q&A letters</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="Q&A letters">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="Q&A letters" href='masterit200601.php'>January 2006</a></li>
<li><a title="Q&A letters" href='masterit200602.php'>February 2006</a></li>
<li><a title="Q&A letters" href='masterit200603.php'>March 2006</a></li>
<li><a title="Q&A letters" href='masterit200604.php'>April 2006</a></li>
<li><a title="Q&A letters" href='masterit200605.php'>May 2006</a></li>
<li><a title="Q&A letters" href='masterit200606.php'>June 2006</a></li>
<li><a title="Q&A letters" href='masterit200607.php'>July 2006</a></li>
<li><a title="Q&A letters" href='masterit200608.php'>August 2006</a></li>
<li><div class='activemenu'>September 2006</div></li>
<li><a title="Q&A letters" href='masterit200610.php'>October 2006</a></li>
<li><a title="Q&A letters" href='masterit200611.php'>November 2006</a></li>
<li><a title="Q&A letters" href='masterit200612.php'>December 2006</a></li>
<li> </li><br><li>Or go back to:</li><li><a title='Q&A/MasterIT letters from 2006' href="masterit2006.php">2006 archive</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>September 2006</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Mark's writing' href="written.php">Professional Writing</a> > <a title='My weekly Q&A column in The Australian' href="masterIT.php">MasterIT</a> > <a title='Q&A/MasterIT letters from 2006' href="masterit2006.php">2006 archive</a> > <a title='Q&A letters' href="masterit200609.php">September 2006</a>
<br><br>		<br>
<h2>5/9/06</h2><br>
<b>I've recently added an external USB hard drive to my system to use as a quick backup area. When connected, Windows finds it immediately and it shows as another hard drive alongside C. However, when I plug in my 1GB flash drive, Windows will recognise it but it does not appear in Windows Explorer. More strangely, if I plug in the flash drive first, it works, but the external hard drive fails to show. Basically, I can use one - but not both - at the same time. I have 4 USB 2.0 ports on a PCI card, and 4 on the motherboard, and have tried just about every combination I can think of, but no joy.</b><br>
<br>
I'll cheat with this one, because I already know the answer. In fact, the reader figured it out before I did, but it's worth looking at the topic anyway.<br>
<br>
Mostly, situations like this are software related, however sometimes hardware can be to blame. Some manufacturers have slightly different interpretations of the USB specifications (*cough* *DELL* *cough*) and occasionally hardware incompatibilities with external drive boxes and USB flash drives can result.<br>
<br>
In this case though, the fact that the reader was experiencing trouble using both the onboard ports as well as the PCI card ports suggested that this wasn't the problem. For the same reason, it was unlikely to be an issue of insufficient power being available to the devices.<br>
<br>
The next thing to look at was the possibility that the two devices themselves wouldn't play together (as occasionally happens), either for hardware or software reasons. I suggested to the reader that he try both devices on another PC, and they worked simultaneously, quite happily. This narrowed the problem down to one PC, and to software.<br>
<br>
Mostly, USB storage devices use the inbuilt Windows drivers, but sometimes manufacturers provide their own. I suggested that any custom drivers be removed and reinstalled, as well as any obsolete USB drivers that might have been present on the system (from, say, a card reader that was no longer used).<br>
<br>
This is because sometimes simply removing and reinstalling the devices in Device Manager helps Windows "get over it" and fix the problem.<br>
<br>
In the end, it turned out to be a more sublime issue. Using a program called TweakUI (available from Microsoft at tinyurl.com/2meyw), it is possible to prevent individual drive letters from appearing in Windows Explorer (by way of tweaking the registry). Somehow, this had happened, and on the reader's machine the G drive was hidden. Re-enabling it let the drive letters for both devices appear - problem solved.<br>
<br>
<br>
<h2>12/9/06</h2><br>
<b>My son just purchased a "Dell Inspiron 6400" and he would like to connect wireless broadband, but the laptop does not take a PCMCIA card modem. Dell informs me that his unit takes the following: Intel Pro/Wireless 3945 802.11a/b/g Minicard wireless. Any idea where he could find one? Both Telstra and 3 have said that they will have them sometime early next year.</b><br>
<br>
The best place to try would be Dell themselves. Often, internal laptop cards like this are a fairly custom item, and you can't really buy them off the shelf, so to speak.<br>
<br>
However, the card you're talking about is a wireless LAN card. It will let you use WLAN "hotspots", but it is different to the use-anywhere wireless access offered by the likes of Telstra and 3.<br>
<br>
For that, you need a specific modem from the provider, and unfortunately no-one is yet offering ExpressCard versions.<br>
<br>
(Expresscard, which is what the Inspiron 6400 supports, is the latest type of PCMCIA-esque laptop connector. It's being helpfully included by manufacturers on many new laptops these days, despite the fact that devices for it aren't commonly available yet).<br>
<br>
All is not lost though. Most of the wireless providers offer a USB modem, which should work just fine with any laptop; for example, Telstra have the EV-DO MiniMax. "Three" currently don't have a standalone USB option, unless you count using a 3 mobile, which is possible. Unwired (another wireless provider) also have a USB option.<br>
<br>
<br>
<b>I am trying to burn an AVI movie file with Sonic MyDVD LE. When I import the AVI into Sonic, insert a "Verbatim -R" dual layer DVD and hit burn, it does everything, then cancels, ejects the disc and says "incompatible medium, cannot format medium". Any ideas?</b><br>
<br>
It sounds a bit odd, assuming, of course, that your DVD writer is Dual-layer, "minus R" compatible; remember that +R media is also available, and not all drives support both formats, so check the drive manufacturer's website to make sure.<br>
<br>
Assuming it is compatible, it could be a few different things. It's possible that Sonic isn't playing well with your drive and/or the media in it. <br>
<br>
If so, you could try one of the other writing packages out there like Nero (a free trial of which can be downloaded) or DVD Decrypter (also free although in legal limbo).<br>
<br>
Sometimes, a particular drive may simply not like media of a particular brand. I've generally found Verbatim to be very good (it's my DVD medium of choice), but try a different brand if all else fails.<br>
<br>
Finally, if things still aren't working as they're supposed to, you may have a faulty writer.<br>
<br>
<br>
<h2>19/9/06</h2><br>
<b>I was wondering if there is an easy way to determine the total "uptime" of a system running Windows. It may seem frivolous to know, but I'm engaging in a pointless debate about server availability with a client (who hopefully doesn't read The Australian!). Bitterness aside, it would be handy to know in general.</b><br>
<br>
There are a few different ways you can gather the information you need to gently stick it to your valued client.<br>
<br>
The quick and nasty way to get an idea of a server's uptime is to look at it's network connection stats (just click the icon in the system tray). It shows how long the connection has been active, which will generally coincide with the time since the last reboot. Bear in mind that an interrupted network connection may skew this figure.<br>
<br>
Next cab off the rank is the "systeminfo" command. Open a command window (press Windows-R, type "cmd" and hit Enter is the easiest way) and type "systeminfo". You may now see a line showing the system uptime (the time elapsed since the last reboot).<br>
<br>
I say "may", because some editions of Windows (like XP home) don't support this command at all. Others, helpfully, display "n/a" in the System Up Time field.<br>
<br>
Another way is to use a little piece of vbscript like the one at tinyurl.com/ryxjo, which will read the data from Windows' brain directly and pop it up on screen.<br>
<br>
Perhaps the best option, given that you're trying to analyse server availability in general, is to download Microsoft's "uptime.exe" tool (available from tinyurl.com/8sge). It basically peruses the system logs for reboot and crash events, and can give you some extended information about the server and how long it's been up for, provided the appropriate log entries exist.<br>
<br>
<br>
<h2>26/9/06</h2><br>
<b>I am trying to burn an AVI movie file with Sonic MyDVD LE. When I import the AVI into Sonic, insert a "Verbatim -R" dual layer DVD and hit burn, it does everything, then cancels, ejects the disc and says "incompatible medium, cannot format medium". Any ideas?</b><br>
<br>
It sounds a bit odd, assuming, of course, that your DVD writer is Dual-layer, "minus R" compatible; remember that +R media is also available, and not all drives support both formats, so check the drive manufacturer's website to make sure.<br>
<br>
Assuming that it is compatible, it's possible that the burning software (Sonic) isn't playing well with your drive and/or the media in it. <br>
<br>
If so, you could try one of the other writing packages out there like Nero (a free trial of which can be downloaded) or DVD Decrypter (also free, albeit in legal limbo).<br>
<br>
Sometimes, a particular drive may simply not like media of a particular brand. I've generally found Verbatim to be very good (it's my DVD medium of choice), but try a different brand if all else fails.<br>
<br>
Of course, if things still aren't working as they're supposed to, you may have a faulty writer, and an excuse to upgrade.<br>
<br>
<br>
<b>I have a question about the Windows paging file. How big should it be? I've read conflicting opinions online; some say that it should be 1.5 times the size of your RAM whereas others think this is excessive.</b><br>
<br>
Microsoft's official recommendation is indeed to have 1.5 times as much virtual memory as you do physical RAM. Left to it's own devices, XP will auto-allocate this much as a matter of course, and more in some cases. So, if you have 2 gigabytes of RAM, Windows will eat at least 3 gigs of space from your drive.<br>
<br>
At first glance, this would appear to be insane overkill. I've done some reading up on this over the years, and the reasons behind it are fairly involved. They have to do with the way Windows manages it's memory.<br>
<br>
Basically, on paper, if you run without enough swap space you're risking all sorts of unspeakable horror and instability.<br>
<br>
In reality, you can run without any swapfile at all, provided you have enough RAM (two gigabytes is plenty). Your machine will not explode and your data will be safe. Windows will also become much more responsive, especially when swapping between programs.<br>
<br>
The only caveat is that if you ever DO run out of RAM, strange things will happen. Running programs may simply disappear from the taskbar, along with their unsaved data.<br>
<br>
If you lack sufficient RAM to disable the swapfile with confidence, but have more than one hard drive installed, you can still improve performance by moving the swapfile to a non-system drive.<br>
<br>
<i><p>Did the information on this page help you? Entertain you? Bore you? <a href="contact.php?subject=MasterIT">Drop me a line</a>.</p>

<p>If you're feeling particularly generous, you can even <a href="buypics.php">click here to send me some dot-com riches</a>. Think of it as online busking.</i></p>
	</div>
</div>
</body>
</html>