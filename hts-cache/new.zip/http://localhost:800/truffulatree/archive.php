<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - Archive - Old stuff from my site</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="Old stuff from my site">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="truffulatree.com.au homepage" href="home.php">Home</a></li>
<li> </li><br>
<li><a title="About me" href='about.php'>About</a></li>
<li><a title="Picture galleries" href='pictures.php'>Photography</a></li>
<li><a title="Travel stories and pictures" href='travel.php'>Travelogues</a></li>
<li><a title="Mark's writing" href='written.php'>Professional Writing</a></li>
<li><a title="Programming work I've done" href='programming.php'>Programming</a></li>
<li><a title="Sounds and music" href='music.php'>Music</a></li>
<li><a title="Silly things for your amusement" href='silliness.php'>Silliness</a></li>
<li><div class='activemenu'>Archive</div></li>
<ul>
<li><a title="Random mp3s" href='mp3s.php'>MP3s</a></li>
<li><a title="Mark Cocquio's webcam" href='webcam.php'>Webcam</a></li>
<li><a title="James Ruse Agricultural High School Class of 1992 10 year reunion" href='reunion.php'>Reunion</a></li>
</ul>
<li><a title="Contact me" href='contact.php'>Contact</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>Archive</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Old stuff from my site' href="archive.php">Archive</a>
<br>Select a link on the left to continue navigating.<br><br>		<br>
This is the archive of old stuff from the site. It's not quite ready for deletion yet, but it also no longer quite fits in the structure.<br>
<br>
Browse away.<br>


	</div>
</div>
</body>
</html>