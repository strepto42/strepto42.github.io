<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - April 2007 - Q&A letters</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="Q&A letters">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="Q&A letters" href='masterit200701.php'>January 2007</a></li>
<li><a title="Q&A letters" href='masterit200702.php'>February 2007</a></li>
<li><a title="Q&A letters" href='masterit200703.php'>March 2007</a></li>
<li><div class='activemenu'>April 2007</div></li>
<li><a title="Q&A letters" href='masterit200705.php'>May 2007</a></li>
<li><a title="Q&A letters" href='masterit200706.php'>June 2007</a></li>
<li><a title="Q&A letters" href='masterit200707.php'>July 2007</a></li>
<li> </li><br><li>Or go back to:</li><li><a title='Q&A letters from 2007' href="masterit2007.php">2007 archive</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>April 2007</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Mark's writing' href="written.php">Professional Writing</a> > <a title='My weekly Q&A column in The Australian' href="masterIT.php">MasterIT</a> > <a title='Q&A letters from 2007' href="masterit2007.php">2007 archive</a> > <a title='Q&A letters' href="masterit200704.php">April 2007</a>
<br><br>		<br>
<h2>3/4/07</h2><br>
<b>When I go to defrag my C drive, I am told that I do not have enough free space to do it. A quick check of "my computer" shows that the drive is 97% full, but I cannot find any files that would take up that much room. I have done a disc cleanup and all the other maintenance but to no avail. Where would a file/files that large be hiding?</b><br>
<br>
Unfortunately, they can be hiding anywhere. If you've already done a disk cleanup, then that eliminates the Temp folder (a likely candidate for taking up space) and a few other common locations.<br>
<br>
Your best bet is to go to the Start menu and run a search (Find->Files and Folders). <br>
<br>
Set up the search to include all files, but limit the results to files larger than a certain amount (10mb should be plenty). Also make sure that the search options are set up to include hidden files and folders.<br>
<br>
The results can then be sorted by size or location, and the culprit(s) easily moved or removed.<br>
<br>
<br>
<b>We have real problems with spam, and we have tried block sender but that takes time. Our provider says it can do no more, but some weekends we can have up to 50 unsolicited emails about Viagra, stock markets, etc. We use Mailwasher and have AVG for antivirus. What can you suggest?</b><br>
<br>
If your ISP is already filtering as much as they say they can, then your only other resort is to filter it at your end.<br>
<br>
Unfortunately, blocking senders is not only time consuming, but it's also pretty much useless, as spammers pretty much always use bogus addresses, which change all the time. Often, the low-lifes even use other addresses from their spam list as random "from" accounts.<br>
<br>
You already have the excellent Mailwasher (www.mailwasher.net). Apart from that there are enormous numbers of plug in spam filters for all the various mail reading programs (Thunderbird has it's own built in too).<br>
<br>
Alas, there's no 100% reliable way of getting rid of the stuff; you just have to strike a balance between not-enough-filtering (which will let some spam though) and over-filtering (which may mark some non-spam messages as spam).<br>
<br>
Not that it helps now, but the best idea with spam is prevention. Simply be very careful where you put your email address.<br>
<br>
It's quite useful to create a spam-catcher account in Hotmail or Gmail, and then use it when you fill out web forms. And, of course, never post to newsgroups using your actual address (add something to it that humans can remove before replying).<br>
<br>
<br>
<h2>10/4/07</h2><br>
<b>I've just bought a sizable USB flash drive to keep my programming work on from job to job (I'm a contractor). I'd like to use file compression and encryption on it, but to do that I need to format it with NTFS (it is FAT32 at the moment), and Windows doesn't let me do that. Is there a way to put NTFS on a USB key, and is it a good idea?</b><br>
<br>
Yes it's quite possible, and there aren't any big reasons why it's a bad idea to format NTFS.<br>
<br>
Be careful with NTFS encryption though - make sure you test it out before assuming its portability between different machines and user accounts.<br>
<br>
The first thing to know about formatting removable media with NTFS is that there is an option in Windows to configure write caching on removable drives.<br>
<br>
You can either set the drive to be optimised for speed (with write caching enabled), or for quick removal (with no caching).<br>
<br>
The latter option lets you yank the drive without first having to click on the "safely remove devices" icon.<br>
<br>
Windows, in it's infinite wisdom, will not let you format a drive to NTFS if it's set for quick removal.<br>
<br>
So, plug in your key, and open up the device manager (right click on My Computer, select Manage, then select Device Manager).<br>
<br>
Now open up the tree at "disk drives", right click on your USB key, select Properties, and then click on the Policies tab.<br>
<br>
Select "Optimise for Performance", click ok, possibly reboot (don't you love that?), and when you're all done you should now be able to format the drive to NTFS.<br>
<br>
<br>
<b>I'm on satellite broadband and have a fairly low monthly allowance. Sometimes, when I'm doing a big download with IE, it drops out half way through and I have to start all over again, using up my precious megabytes! Is there some way to resume a download from where it left off?</b><br>
<br>
Yes, resumable downloads have been around for years; IE just never jumped on the bandwagon properly (IE 7 has some primitive auto-resuming capabilities, other editions just didn't bother at all).<br>
<br>
Firefox also has a fairly primitive (although less so than IE's) function to do this out of the box, or you can download the excellent DTA! plugin for it.<br>
<br>
There are also third party programs galore that let you manage your downloads. Getright (www.getright.com) is the granddaddy of them all, but isn't free.<br>
<br>
<br>
<h2>17/4/07</h2><br>
<b>I'm encountering a little inconvenience with my USB Drive (which appears to Windows as a removable disk). Whenever I insert it, it opens through Windows Explorer in a maximised window, however, I do not want it to open in a maximised window, but in a 'normal' window (I would like to have it in the same window size as I had it the last time I used the drive). I have created a shortcut to it on the desktop. The problem is that, even if I set it to open in a normal window (in the shortcut properties), it keeps doing so in a maximised window: Whenever I insert the device, or double click its shortcut, it opens in a maximised window. How can I correct this?</b><br>
<br>
I know your problem well - it's one of the many little gripes I have with Windows. <br>
<br>
Unfortunately, there isn't an easy way around it. Then it comes to opening new Explorer windows, Windows tenaciously sticks to it's last known settings, and doesn't remember unique ones for different drives or folders.<br>
<br>
If your last open Explorer window was maximised to full screen when you closed it, that is how Windows will open the next one.<br>
<br>
Likewise, if the window wasn't set to take up the full screen, the size will be the same (although the location will be slightly different as Windows "tiles" the new Explorers). This happens regardless of the shortcut you use to open the window, hence the problem.<br>
<br>
Because of this, your only option is to try a third party tool. A quick search turned up one for me at this URL: tinyurl.com/2v4yxe.<br>
<br>
I had a quick play with it, and it seemed to fit the bill for your problem nicely, as well as pack in a myriad of other features.<br>
<br>
<br>
<b>I have a problem with Internet Explorer. Whenever I click on the little x in the top right corner, IE closes down with the message that IE has encountered a problem. This occurs even when I close something like a map that is accessed from an Internet site. I have uninstalled IE7 but that did not stop the problem.</b><br>
<br>
A problem like this could be caused by a number of things.<br>
<br>
If you have any third party toolbars installed in IE (like, for example, the Yahoo toolbar), try disabling them.<br>
<br>
I'd probably also run a scan with Adaware (a spyware finder - you can download a free version from www.lavasoft.de/products/ad-aware_se_personal.php), or Prevx (www.prevx.com).<br>
<br>
<br>
<h2>24/4/07</h2><br>
<b>In your piece about cleaning up to beat bluescreens (10/4), you mentioned everything except cleaning the Registry. I've installed Registry Mechanic and find that it keeps the registry nice and clean of errors. Is this a worthwhile exercise or not really necessary?</b><br>
<br>
It's true, I did forget to mention the registry, which was a bit naughty of me.<br>
<br>
Over the years, I've never found much value in registry cleaners.<br>
<br>
Certainly, they can do some good, but unless they're very well written they can also do inadvertent damage.<br>
<br>
Microsoft's own policy is not to bother - they used to have a program called Regclean available, but they no longer support its use.<br>
<br>
The thing with the registry is that it is a pretty complex beast. There are a lot of things that tie together, so it's a bit hairy to let some program (that may or may not know what it's doing) go poking around in there.<br>
<br>
At best it might not do much of anything; at worst it could cause some system instability.<br>
<br>
I've not used a registry cleaner for a long time. As a result, my XP installation has a registry that resembles Jabba the Hutt, but at the end of the day it's not really affecting anything. <br>
<br>
So, because of the above, my advice is that it's not really worth the trouble.<br>
<br>
If you really want to use a cleaner, it's worth getting familiar with exactly what it does, and keep an eye on it when it runs. Also, make sure it backs up any keys that get removed, just in case they need to get restored at some stage.<br>
<br>
<br>
<b>Since installing a low rent Nvidia video card to replace one gone, I keep getting a message ("SLI multi-GPU rendering has been disabled...") pop up every time I boot. It points to Nvidia webpage for more info.  I have tried everything to get rid of the  bloody thing. Any ideas, please?</b><br>
<br>
I was troubled by that annoying message for a while too. There was some speculation that it was a deliberate piece of marketing by Nvidia, but I suspect that at the end of the day it was just a bug in the video driver.<br>
<br>
Installing the latest Nvidia drivers available at www.nvidia.com ought to clear it up for you.<br>
<br>
<i><p>Did the information on this page help you? Entertain you? Bore you? <a href="contact.php?subject=MasterIT">Drop me a line</a>.</p>

<p>If you're feeling particularly generous, you can even <a href="buypics.php">click here to send me some dot-com riches</a>. Think of it as online busking.</i></p>
	</div>
</div>
</body>
</html>