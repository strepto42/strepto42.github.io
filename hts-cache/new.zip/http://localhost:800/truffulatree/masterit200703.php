<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - March 2007 - Q&A letters</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="Q&A letters">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="Q&A letters" href='masterit200701.php'>January 2007</a></li>
<li><a title="Q&A letters" href='masterit200702.php'>February 2007</a></li>
<li><div class='activemenu'>March 2007</div></li>
<li><a title="Q&A letters" href='masterit200704.php'>April 2007</a></li>
<li><a title="Q&A letters" href='masterit200705.php'>May 2007</a></li>
<li><a title="Q&A letters" href='masterit200706.php'>June 2007</a></li>
<li><a title="Q&A letters" href='masterit200707.php'>July 2007</a></li>
<li> </li><br><li>Or go back to:</li><li><a title='Q&A letters from 2007' href="masterit2007.php">2007 archive</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>March 2007</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Mark's writing' href="written.php">Professional Writing</a> > <a title='My weekly Q&A column in The Australian' href="masterIT.php">MasterIT</a> > <a title='Q&A letters from 2007' href="masterit2007.php">2007 archive</a> > <a title='Q&A letters' href="masterit200703.php">March 2007</a>
<br><br>		<br>
<h2>6/3/07</h2><br>
<b>We have real problems with spam, and we have tried block sender but that takes time. Our provider says it can do no more, but some weekends we can have up to 50 unsolicited emails about Viagra, stock markets, etc. We use Mailwasher and have AVG for antivirus. What can you suggest?</b><br>
<br>
If your ISP is already filtering as much as they say they can, then your only other resort is to filter it at your end.<br>
<br>
Unfortunately, blocking senders is not only time consuming, but it's also pretty much useless, as spammers pretty much always use bogus addresses, which change all the time. Often, the low-lifes even use other addresses from their spam list as random "from" accounts.<br>
<br>
You already have the excellent Mailwasher (www.mailwasher.net)... apart from that there are millions of plug in spam filters for all the various mail reading programs (Thunderbird has it's own built in too).<br>
<br>
Alas, there's no 100% reliable way of getting rid of the stuff; you just have to strike a balance between not-enough-filtering (which will let spam though) and over-filtering (which may mark some non-spam messages as spam).<br>
<br>
Not that it helps now, but the best idea with spam is prevention. Simply be very careful where you put your email address.<br>
<br>
It's quite useful to create a spam-catcher account in Hotmail or Gmail, and then use it when you fill out web forms. And, of course, never post to newsgroups using your actual address (add something to it that humans can remove before replying).<br>
<br>
<br>
<h2>13/3/07</h2><br>
The other day my computer was downloading and installing Windows XP's automatic updates when it shut itself down. Now when I try to power it up, it powers up for 2 seconds then shuts down again with a red light flashing once every so often. I searched the Internet and found that this means I have a "power supply crowbar". Unfortunately I can't find out what this means or how to overcome this problem. Would you be able to help?<br>
<br>
The concept of the power supply crowbar is that, if something goes wrong with your electrical equipment, a special circuit effectively shuts down the supply of electricity by short circuiting the output of the power supply (ie, throwing a virtual crowbar over the terminals). The idea is to prevent damage to anything plugged into it.<br>
<br>
Computer power supplies also tend to shut down like this when they're overloaded, but what's more likely in your situation is that there is an electrical fault within your computer, which is causing the power supply to shut down in this manner.<br>
<br>
The fault is probably in the computer's power supply itself, but it could also be in any of the devices that are connected to it (eg, the computer's motherboard, hard drives, CD-ROM, etc).<br>
<br>
If you have a spare PC power supply sitting around (doesn't everyone?), you could try swapping it for the existing one, to see if the problem goes away.<br>
<br>
This isn't terribly hard, but you have to know what you're doing, so if you're not confident then I'd recommend visiting the local PC repair shop.<br>
<br>
<br>
<h2>20/3/07</h2><br>
<b>I have set up a dual-boot system so that I can try out Vista, while still being able to use XP as a fallback. I've installed Firefox and Thunderbird under Vista, but I'd like to share my mail folders and Firefox settings with XP. Is it possible to do this?</b><br>
<br>
It certainly is, but with a small amount of fiddling.<br>
<br>
To set up Thunderbird to use your XP mail folders, boot into Vista, then go to the Start Menu -> All Programs -> Mozilla Thunderbird -> Profile Manager.<br>
<br>
Now click Create Profile, and when prompted to choose the folder for the new profile, navigate to your XP partition, and find the appropriate mail folders.<br>
<br>
They'll be named differently for everyone, but you can find them under -XP drive letter-Documents and Settings-your XP username-Application DataThunderbirdProfiles-something-.default.<br>
<br>
Lastly, configure Thunderbird to use this profile every time when it starts without asking, and you should be in business.<br>
<br>
With Firefox you can go one of two ways. The first way is to share the entire profile, including all extensions and passwords. This will give you maximum convenience, but you may have to change your download folder every time you switch operating system because of the different drive letters (both XP and Vista will probably want to be C: when you are running them).<br>
<br>
Sharing the profile is quite simple though. Boot Vista, then browse to Users-your Vista username-AppDataRoamingMozillaFirefox. Next, right click on profiles.ini, click edit, and change the following lines:<br>
<br>
IsRelative=0<br>
Path=-your XP profile for Mozilla-<br>
<br>
As with Thunderbird, the path will vary, but it'll be something like -XP drive letter-Documents and Settings-your XP username-Application DataMozillaFirefoxProfiles-something-.default.<br>
<br>
The alternative to sharing every single Firefox setting is to just share the bookmarks. To do this, open Firefox in Vista, and type About:config into the address bar. This will bring up the Firefox internal configuration page.<br>
<br>
Right click anywhere, then select new->string. For the name, enter browser.bookmarks.file, and for the value, the full path to bookmarks.html on your XP partition. This will be in the same place above as the profile.<br>
<br>
Restart Firefox, and you should be in the land of shared bookmarks (an exciting place to be in anyone's language!).<br>
<br>
<br>
<h2>27/3/07</h2><br>
<b>I have a problem with my Windows 2000 startup. I get a popup that says "thanks for using the 5 day free trial, but you must now log onto our website to activate". The website does not exist, and I have explored every single nook and cranny of both hard drives and all files including control panel, but I cannot find any where that would allow me to get rid of this annoying pop up. It has been there now for over two years. Any ideas?</b><br>
<br>
Two years! That's staying power.<br>
<br>
In addition to the start menu "startup" folder, Windows has an area of the registry which also stores the names of programs to run when your computer starts. I suspect there is an ancient entry in there.<br>
<br>
You can edit these values by hand, which is a pain, or use a third party utility to help.<br>
<br>
Normally this is where I point users to Microsoft's own utility, msconfig, but it's not included with Windows 2000.<br>
<br>
Instead, you can find something to do the job at www.mlin.net/StartupCPL.shtml.<br>
<br>
Once installed, it's simply a case of going through the lists and un-ticking boxes until the message goes away.<br>
<br>
<br>
<b>I recently bought Trend anti virus, but when I try to install it, it tells me that I must first get rid of Norton (which came with the computer). When I go to add/remove programs and try to delete Norton, I get a message that there is a newer version and that must be removed first. For the life of me I cannot find that version to remove it. This is very frustrating as Trend cost me $90 and I cannot use it. It has turned me off both Norton and Microsoft for life.</b><br>
<br>
This is exactly the sort of thing that put me off Norton/Symantec years ago, but, to be fair, Windows and its fragile uninstallation system share a large portion of the blame (and sadly, there's not much that can be done there).<br>
<br>
All is not lost though. Symantec are good enough to have a removal tool available on their website at tinyurl.com/y3ude7, which should do the trick.<br>
<br>
<i><p>Did the information on this page help you? Entertain you? Bore you? <a href="contact.php?subject=MasterIT">Drop me a line</a>.</p>

<p>If you're feeling particularly generous, you can even <a href="buypics.php">click here to send me some dot-com riches</a>. Think of it as online busking.</i></p>
	</div>
</div>
</body>
</html>