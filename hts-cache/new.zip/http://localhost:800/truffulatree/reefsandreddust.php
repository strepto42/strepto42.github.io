<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - 30/9/2005 - Reefs and Red Dust</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="Reefs and Red Dust">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="Greetings from a Bum" href='greetingsfromabum.php'>29/4/2005</a></li>
<li><a title="Onward" href='onward.php'>2/5/2005</a></li>
<li><a title="It's a tough life (pt 1: Bundaberg, Agnes Water and 1770)" href='itsatoughlife1.php'>17/5/2005</a></li>
<li><a title="It's a tough life (pt 2: Rockhampton, Emu Park and Great Keppel Island)" href='itsatoughlife2.php'>23/5/2005</a></li>
<li><a title="There and Back Again - a Yo-yo's Tale" href='thereandbackagain.php'>18/6/2005</a></li>
<li><a title="Platypi and Grey Nomads" href='platypiandgreynomads.php'>24/6/2005</a></li>
<li><a title="Blowing Bubbles in a Watery Tomb" href='blowingbubbles.php'>1/7/2005</a></li>
<li><a title="Pieces of History" href='piecesofhistory.php'>8/7/2005</a></li>
<li><a title="Walks and Waterfalls" href='walksandwaterfalls.php'>15/7/2005</a></li>
<li><a title="Mission to Tribulation" href='missiontotribulation.php'>22/7/2005</a></li>
<li><a title="Levity, Limestone and Lava" href='levitylimestoneandlava.php'>29/7/2005</a></li>
<li><a title="Into the Never Never" href='intothenevernever.php'>5/8/2005</a></li>
<li><a title="Slowing the pace in Darwin" href='slowingthepaceindarwin.php'>12/8/2005</a></li>
<li><a title="Blistering Barnacles and Leaping Lizards" href='leapinglizards.php'>19/8/2005</a></li>
<li><a title="Kakadu and Litchfield" href='kakadu.php'>26/8/2005</a></li>
<li><a title="Legacies of War" href='legaciesofwar.php'>2/9/2005</a></li>
<li><a title="Go West" href='gowest.php'>10/9/2005</a></li>
<li><a title="Things from Above" href='thingsfromabove.php'>16/9/2005</a></li>
<li><a title="The West Coast" href='thewestcoast.php'>23/9/2005</a></li>
<li><div class='activemenu'>30/9/2005</div></li>
<li><a title="The Pilbara" href='pilbara.php'>7/10/2005</a></li>
<li><a title="Paradise with a Headwind" href='paradisewithaheadwind.php'>14/10/2005</a></li>
<li><a title="Down the Coral Coast" href='downthecoralcoast.php'>21/10/2005</a></li>
<li><a title="Pinnacles and Pinnipeds" href='pinnaclesandpinnipeds.php'>28/10/2005</a></li>
<li><a title="A week in Perth" href='perth.php'>4/11/2005</a></li>
<li><a title="The Southwest (from Above and Below)" href='thesouthwest.php'>11/11/2005</a></li>
<li><a title="More Heights and Depths" href='moreheightsanddepths.php'>18/11/2005</a></li>
<li><a title="Across the Nullarbor (and a bit beyond)" href='nullarbor.php'>25/11/2005</a></li>
<li><a title="Double Whammy" href='doublewhammy.php'>9/12/2005</a></li>
<li><a title="Two Cities" href='twocities.php'>19/12/2005</a></li>
<li><a title="Tassie - Part 1" href='tassie1.php'>1/1/2006</a></li>
<li><a title="Tassie - Part 2" href='tassie2.php'>7/1/2006</a></li>
<li><a title="Full Circle" href='fullcircle.php'>26/1/2006</a></li>
<li><a title="The Wrap Up" href='thewrapup.php'>23/3/2006</a></li>
<li> </li><br><li>Or go back to:</li><li><a title='Travelouges and blogs from my trip around Australia' href="nerdseyeview.php">Nerd's Eye View</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>30/9/2005</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Travel stories and pictures' href="travel.php">Travelogues</a> > <a title='Travelouges and blogs from my trip around Australia' href="nerdseyeview.php">Nerd's Eye View</a> > <a title='Reefs and Red Dust' href="reefsandreddust.php">30/9/2005</a>
<br><br>		


<h1>Reefs and Red Dust</h1>

<a href="images/maps/Map050930.gif"><img src="images/maps/Map050930_sm.gif" align="right"></a>

<p>Hi All,</p>

<p>Here we are again, at the end of another adventurous week. As was the plan, we headed out of Derby and back up into the Kimberley, via the ancient prison boab tree (which is just out of Derby itself).</p>

<p>The southern part of the Gibb River Road is a pretty cruisey drive - no sharp rocks, or bad corrugations for that matter. The sand got a little deep in places but it was nothing the Subie couldn't handle. :)</p>

<p>Our first destination was Windjana Gorge, where we camped for two nights. This lovely spot is another river channel eroded through the same ancient Devonian reef (now limestone range) that Geikie Gorge runs through.</p>

<p>Unlike Geikie, it's almost dry at this time of year, but there are still a few billabongs along its 3.5km length, and the first one of those is positively infested with a concentration of cute freshwater crocodiles.</p>

<p>We got up early after the first cosy night together in the back of my car, and spent the day walking to the other end of the gorge and back at an extremely leisurely pace. Jana ticked off several new birds and we had a lunch and lie down at the other end of the gorge in amongst some nice shady rocks that hadn't yet been superheated by the sun.</p>

<p>The campsite at Windjana is pretty nice, with plenty of wildlife around, including some cute mini-goanna type monitor lizards, heaps of very sweet finches, bowerbirds and friarbirds, and one particularly friendly peewee that seemed to visit us regularly that we named "Warren".</p>

<p>A rather large willy-willy also tore across the campground at one point, and defied tradition by not actually entering my car (which had all it's windows open at the time), despite passing within a few metres of it.</p>

<p>I had the zoom lens on my camera at the time, so I didn't get a nice wide angle shot, but I did get a few pics of the mass of dirt that formed the middle of the little tornado. I'm quite glad it left my car alone. :) Regardless, it was really rather cool.</p>

<p>The following morning we headed off fairly early, down the road to Tunnel Creek, still on the same limestone range, and yet another spot where a watercourse has eroded a path through it.</p>

<p>In this case through, it's happened underground, and there is a 750m long cave running through the rock. It's a torch-and-wade-through-water experience, and there are various bats living in the cave. The other end of the tunnel ends in a lovely billabong, where we sat and relaxed for a while.</p>

<p>From there we pushed on, back to the sealed highway, after a quick stop to pick up some boab tree seed pods. We are yet to crack them open and sample the spongy mesocarp within.</p>

<p>There was a fair bit of daylight left, so we managed to get to a spot called Port Smith, a fair bit south of Broome, where we spent the night, and went for a swim the next morning in an idyllic tropical lagoon.</p>

<p>The rest of that day we spent driving down the coast, basically through the edge of the Great Sandy Desert, with 80 mile beach off to our right (read: boring scenery). The day was uneventful, apart from my spare tyre (which had been on the car since my blowout in Queensland) finally giving up the ghost rather suddenly.</p>

<p>Given that the tyre let go on a main highway, with a breeze blowing and mere high-20s temperatures, I wasn't that annoyed, especially as two days prior we would have been on a remote rocky dirt road in 35+ degree heat.</p>

<p>Anyway, I sat on my deckchair with a beer while I forced Jana to change the tyre.</p>

<p>Actually, I just dreamed that.</p>

<p>That night, we stayed in a caravan park next to the "pristine" 80 mile beach. There were 4WDs everywhere, on and off the beach. Still, we managed a pleasant bike ride on the beach for sunset, and then got thoroughly eaten by mosquitos later that night (I reckon between us we have easily more than 100 bites).</p>

<p>Our next destination was Port Hedland, the largest iron ore export port in the country. It's a lovely spot, especially the centre of town, where everything but everything is covered in iron ore dust, giving the town a lovely decaying, rusted appearance.</p>

<p>Thankfully the backpackers we stayed at (Frogs) was actually quite nice, and had a winning policy of no checkout time, as the guy who runs it works during the day.</p>

<p>We spent two nights there all up, and managed to do some exciting chores like shopping, getting a new tyre and so on. I also went for a ride and took some happy snaps of the cheerful landscape, which obliged me by puncturing a bike tyre yet again.</p>

<p>We also watched a few of the enormous freighters being towed in to the port, which was kinda cool, but something one would no doubt tire of pretty quickly.</p>

<p>From there we've driven to a lovely little old ghost town called Cossack, near Karratha. You can actually stay here in the old police barracks, which is a lovely 125ish year old building with nice high ceilings and a very quiet atmosphere.</p>

<p>We'll head on to Millstream and Karijini National Parks from here, and some of the oldest rocks on the planet. So strap yourselves in for exciting pictures of stones. :)</p>

<p>Until then, take care. Hope you're all well.</p>

<p>Pics from this week are:</p>
<!-- 
<ul>
<li><a href="?fileId=0_IMG_9761.JPG">Windjana Gorge at sunset</a></li>
<li><a href="?fileId=0_IMG_9983.JPG">The Flying Fox colony, Tunnel Creek</a></li>
<li><a href="?fileId=1_IMG_0070.JPG">"What's this? A shell? HERE?!"</a></li>
<li><a href="?fileId=1_IMG_0174.JPG">BHP paints the town red in Port Hedland</a></li>
<li><a href="?fileId=1_IMG_0263.JPG">A nicer shade of red - Sturt's Desert Pea</a></li>
</ul>
 -->
<table width="800">
	<tr>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=0_IMG_9761.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20050930/0_IMG_9761.JPG' ALT='Windjana Gorge at sunset'><BR>Windjana Gorge at sunset</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=0_IMG_9983.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20050930/0_IMG_9983.JPG' ALT='The Flying Fox colony, Tunnel Creek'><BR>The Flying Fox colony, Tunnel Creek</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=1_IMG_0070.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20050930/1_IMG_0070.JPG' ALT="What's this? A shell? HERE?!"><BR>"What's this? A shell? HERE?!"</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=1_IMG_0174.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20050930/1_IMG_0174.JPG' ALT='BHP paints the town red in Port Hedland'><BR>BHP paints the town red in Port Hedland</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=1_IMG_0263.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20050930/1_IMG_0263.JPG' ALT="A nicer shade of red - Sturt's Desert Pea"><BR>A nicer shade of red - Sturt's Desert Pea</a>
	</td>
	</tr>
</table>

<br><br>
All images in this gallery:<br>
<table width='800'>
<tr>
</tr>
<tr><td><A ID='0_IMG_9729.JPG' href='reefsandreddust.php?fileId=0_IMG_9729.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/0_IMG_9729.JPG' ALT='0_IMG_9729.JPG'><BR>0_IMG_9729.JPG<br>86.45 KB</a><div class='inv'><br><a href='./images/20050930/0_IMG_9729.JPG' ALT='0_IMG_9729.JPG'>0_IMG_9729.JPG</a></div></td>
<td><A ID='0_IMG_9730.JPG' href='reefsandreddust.php?fileId=0_IMG_9730.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/0_IMG_9730.JPG' ALT='0_IMG_9730.JPG'><BR>0_IMG_9730.JPG<br>109.79 KB</a><div class='inv'><br><a href='./images/20050930/0_IMG_9730.JPG' ALT='0_IMG_9730.JPG'>0_IMG_9730.JPG</a></div></td>
<td><A ID='0_IMG_9735.JPG' href='reefsandreddust.php?fileId=0_IMG_9735.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/0_IMG_9735.JPG' ALT='0_IMG_9735.JPG'><BR>0_IMG_9735.JPG<br>64.89 KB</a><div class='inv'><br><a href='./images/20050930/0_IMG_9735.JPG' ALT='0_IMG_9735.JPG'>0_IMG_9735.JPG</a></div></td>
<td><A ID='0_IMG_9739.JPG' href='reefsandreddust.php?fileId=0_IMG_9739.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/0_IMG_9739.JPG' ALT='0_IMG_9739.JPG'><BR>0_IMG_9739.JPG<br>69.87 KB</a><div class='inv'><br><a href='./images/20050930/0_IMG_9739.JPG' ALT='0_IMG_9739.JPG'>0_IMG_9739.JPG</a></div></td>
<td><A ID='0_IMG_9743.JPG' href='reefsandreddust.php?fileId=0_IMG_9743.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/0_IMG_9743.JPG' ALT='0_IMG_9743.JPG'><BR>0_IMG_9743.JPG<br>101.93 KB</a><div class='inv'><br><a href='./images/20050930/0_IMG_9743.JPG' ALT='0_IMG_9743.JPG'>0_IMG_9743.JPG</a></div></td>
</tr>
<tr><td><A ID='0_IMG_9747.JPG' href='reefsandreddust.php?fileId=0_IMG_9747.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/0_IMG_9747.JPG' ALT='0_IMG_9747.JPG'><BR>0_IMG_9747.JPG<br>36.55 KB</a><div class='inv'><br><a href='./images/20050930/0_IMG_9747.JPG' ALT='0_IMG_9747.JPG'>0_IMG_9747.JPG</a></div></td>
<td><A ID='0_IMG_9750.JPG' href='reefsandreddust.php?fileId=0_IMG_9750.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/0_IMG_9750.JPG' ALT='0_IMG_9750.JPG'><BR>0_IMG_9750.JPG<br>54.91 KB</a><div class='inv'><br><a href='./images/20050930/0_IMG_9750.JPG' ALT='0_IMG_9750.JPG'>0_IMG_9750.JPG</a></div></td>
<td><A ID='0_IMG_9754.JPG' href='reefsandreddust.php?fileId=0_IMG_9754.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/0_IMG_9754.JPG' ALT='0_IMG_9754.JPG'><BR>0_IMG_9754.JPG<br>100.51 KB</a><div class='inv'><br><a href='./images/20050930/0_IMG_9754.JPG' ALT='0_IMG_9754.JPG'>0_IMG_9754.JPG</a></div></td>
<td><A ID='0_IMG_9757.JPG' href='reefsandreddust.php?fileId=0_IMG_9757.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/0_IMG_9757.JPG' ALT='0_IMG_9757.JPG'><BR>0_IMG_9757.JPG<br>55.39 KB</a><div class='inv'><br><a href='./images/20050930/0_IMG_9757.JPG' ALT='0_IMG_9757.JPG'>0_IMG_9757.JPG</a></div></td>
<td><A ID='0_IMG_9758.JPG' href='reefsandreddust.php?fileId=0_IMG_9758.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/0_IMG_9758.JPG' ALT='0_IMG_9758.JPG'><BR>0_IMG_9758.JPG<br>96.07 KB</a><div class='inv'><br><a href='./images/20050930/0_IMG_9758.JPG' ALT='0_IMG_9758.JPG'>0_IMG_9758.JPG</a></div></td>
</tr>
<tr><td><A ID='0_IMG_9761.JPG' href='reefsandreddust.php?fileId=0_IMG_9761.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/0_IMG_9761.JPG' ALT='0_IMG_9761.JPG'><BR>0_IMG_9761.JPG<br>60.86 KB</a><div class='inv'><br><a href='./images/20050930/0_IMG_9761.JPG' ALT='0_IMG_9761.JPG'>0_IMG_9761.JPG</a></div></td>
<td><A ID='0_IMG_9763.JPG' href='reefsandreddust.php?fileId=0_IMG_9763.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/0_IMG_9763.JPG' ALT='0_IMG_9763.JPG'><BR>0_IMG_9763.JPG<br>46.73 KB</a><div class='inv'><br><a href='./images/20050930/0_IMG_9763.JPG' ALT='0_IMG_9763.JPG'>0_IMG_9763.JPG</a></div></td>
<td><A ID='0_IMG_9764.JPG' href='reefsandreddust.php?fileId=0_IMG_9764.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/0_IMG_9764.JPG' ALT='0_IMG_9764.JPG'><BR>0_IMG_9764.JPG<br>71.4 KB</a><div class='inv'><br><a href='./images/20050930/0_IMG_9764.JPG' ALT='0_IMG_9764.JPG'>0_IMG_9764.JPG</a></div></td>
<td><A ID='0_IMG_9772.JPG' href='reefsandreddust.php?fileId=0_IMG_9772.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/0_IMG_9772.JPG' ALT='0_IMG_9772.JPG'><BR>0_IMG_9772.JPG<br>85.55 KB</a><div class='inv'><br><a href='./images/20050930/0_IMG_9772.JPG' ALT='0_IMG_9772.JPG'>0_IMG_9772.JPG</a></div></td>
<td><A ID='0_IMG_9774.JPG' href='reefsandreddust.php?fileId=0_IMG_9774.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/0_IMG_9774.JPG' ALT='0_IMG_9774.JPG'><BR>0_IMG_9774.JPG<br>80.69 KB</a><div class='inv'><br><a href='./images/20050930/0_IMG_9774.JPG' ALT='0_IMG_9774.JPG'>0_IMG_9774.JPG</a></div></td>
</tr>
<tr><td><A ID='0_IMG_9798.JPG' href='reefsandreddust.php?fileId=0_IMG_9798.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/0_IMG_9798.JPG' ALT='0_IMG_9798.JPG'><BR>0_IMG_9798.JPG<br>90.11 KB</a><div class='inv'><br><a href='./images/20050930/0_IMG_9798.JPG' ALT='0_IMG_9798.JPG'>0_IMG_9798.JPG</a></div></td>
<td><A ID='0_IMG_9801.JPG' href='reefsandreddust.php?fileId=0_IMG_9801.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/0_IMG_9801.JPG' ALT='0_IMG_9801.JPG'><BR>0_IMG_9801.JPG<br>92.15 KB</a><div class='inv'><br><a href='./images/20050930/0_IMG_9801.JPG' ALT='0_IMG_9801.JPG'>0_IMG_9801.JPG</a></div></td>
<td><A ID='0_IMG_9802.JPG' href='reefsandreddust.php?fileId=0_IMG_9802.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/0_IMG_9802.JPG' ALT='0_IMG_9802.JPG'><BR>0_IMG_9802.JPG<br>117.42 KB</a><div class='inv'><br><a href='./images/20050930/0_IMG_9802.JPG' ALT='0_IMG_9802.JPG'>0_IMG_9802.JPG</a></div></td>
<td><A ID='0_IMG_9809.JPG' href='reefsandreddust.php?fileId=0_IMG_9809.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/0_IMG_9809.JPG' ALT='0_IMG_9809.JPG'><BR>0_IMG_9809.JPG<br>102.49 KB</a><div class='inv'><br><a href='./images/20050930/0_IMG_9809.JPG' ALT='0_IMG_9809.JPG'>0_IMG_9809.JPG</a></div></td>
<td><A ID='0_IMG_9817.JPG' href='reefsandreddust.php?fileId=0_IMG_9817.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/0_IMG_9817.JPG' ALT='0_IMG_9817.JPG'><BR>0_IMG_9817.JPG<br>77.9 KB</a><div class='inv'><br><a href='./images/20050930/0_IMG_9817.JPG' ALT='0_IMG_9817.JPG'>0_IMG_9817.JPG</a></div></td>
</tr>
<tr><td><A ID='0_IMG_9820.JPG' href='reefsandreddust.php?fileId=0_IMG_9820.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/0_IMG_9820.JPG' ALT='0_IMG_9820.JPG'><BR>0_IMG_9820.JPG<br>76.85 KB</a><div class='inv'><br><a href='./images/20050930/0_IMG_9820.JPG' ALT='0_IMG_9820.JPG'>0_IMG_9820.JPG</a></div></td>
<td><A ID='0_IMG_9821.JPG' href='reefsandreddust.php?fileId=0_IMG_9821.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/0_IMG_9821.JPG' ALT='0_IMG_9821.JPG'><BR>0_IMG_9821.JPG<br>87.32 KB</a><div class='inv'><br><a href='./images/20050930/0_IMG_9821.JPG' ALT='0_IMG_9821.JPG'>0_IMG_9821.JPG</a></div></td>
<td><A ID='0_IMG_9824.JPG' href='reefsandreddust.php?fileId=0_IMG_9824.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/0_IMG_9824.JPG' ALT='0_IMG_9824.JPG'><BR>0_IMG_9824.JPG<br>91.42 KB</a><div class='inv'><br><a href='./images/20050930/0_IMG_9824.JPG' ALT='0_IMG_9824.JPG'>0_IMG_9824.JPG</a></div></td>
<td><A ID='0_IMG_9833.JPG' href='reefsandreddust.php?fileId=0_IMG_9833.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/0_IMG_9833.JPG' ALT='0_IMG_9833.JPG'><BR>0_IMG_9833.JPG<br>111.8 KB</a><div class='inv'><br><a href='./images/20050930/0_IMG_9833.JPG' ALT='0_IMG_9833.JPG'>0_IMG_9833.JPG</a></div></td>
<td><A ID='0_IMG_9841.JPG' href='reefsandreddust.php?fileId=0_IMG_9841.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/0_IMG_9841.JPG' ALT='0_IMG_9841.JPG'><BR>0_IMG_9841.JPG<br>112.02 KB</a><div class='inv'><br><a href='./images/20050930/0_IMG_9841.JPG' ALT='0_IMG_9841.JPG'>0_IMG_9841.JPG</a></div></td>
</tr>
<tr><td><A ID='0_IMG_9843.JPG' href='reefsandreddust.php?fileId=0_IMG_9843.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/0_IMG_9843.JPG' ALT='0_IMG_9843.JPG'><BR>0_IMG_9843.JPG<br>119.3 KB</a><div class='inv'><br><a href='./images/20050930/0_IMG_9843.JPG' ALT='0_IMG_9843.JPG'>0_IMG_9843.JPG</a></div></td>
<td><A ID='0_IMG_9847.JPG' href='reefsandreddust.php?fileId=0_IMG_9847.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/0_IMG_9847.JPG' ALT='0_IMG_9847.JPG'><BR>0_IMG_9847.JPG<br>69.66 KB</a><div class='inv'><br><a href='./images/20050930/0_IMG_9847.JPG' ALT='0_IMG_9847.JPG'>0_IMG_9847.JPG</a></div></td>
<td><A ID='0_IMG_9853.JPG' href='reefsandreddust.php?fileId=0_IMG_9853.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/0_IMG_9853.JPG' ALT='0_IMG_9853.JPG'><BR>0_IMG_9853.JPG<br>92.96 KB</a><div class='inv'><br><a href='./images/20050930/0_IMG_9853.JPG' ALT='0_IMG_9853.JPG'>0_IMG_9853.JPG</a></div></td>
<td><A ID='0_IMG_9858.JPG' href='reefsandreddust.php?fileId=0_IMG_9858.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/0_IMG_9858.JPG' ALT='0_IMG_9858.JPG'><BR>0_IMG_9858.JPG<br>83.3 KB</a><div class='inv'><br><a href='./images/20050930/0_IMG_9858.JPG' ALT='0_IMG_9858.JPG'>0_IMG_9858.JPG</a></div></td>
<td><A ID='0_IMG_9865.JPG' href='reefsandreddust.php?fileId=0_IMG_9865.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/0_IMG_9865.JPG' ALT='0_IMG_9865.JPG'><BR>0_IMG_9865.JPG<br>83.37 KB</a><div class='inv'><br><a href='./images/20050930/0_IMG_9865.JPG' ALT='0_IMG_9865.JPG'>0_IMG_9865.JPG</a></div></td>
</tr>
<tr><td><A ID='0_IMG_9866.JPG' href='reefsandreddust.php?fileId=0_IMG_9866.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/0_IMG_9866.JPG' ALT='0_IMG_9866.JPG'><BR>0_IMG_9866.JPG<br>75.12 KB</a><div class='inv'><br><a href='./images/20050930/0_IMG_9866.JPG' ALT='0_IMG_9866.JPG'>0_IMG_9866.JPG</a></div></td>
<td><A ID='0_IMG_9869.JPG' href='reefsandreddust.php?fileId=0_IMG_9869.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/0_IMG_9869.JPG' ALT='0_IMG_9869.JPG'><BR>0_IMG_9869.JPG<br>162.89 KB</a><div class='inv'><br><a href='./images/20050930/0_IMG_9869.JPG' ALT='0_IMG_9869.JPG'>0_IMG_9869.JPG</a></div></td>
<td><A ID='0_IMG_9875.JPG' href='reefsandreddust.php?fileId=0_IMG_9875.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/0_IMG_9875.JPG' ALT='0_IMG_9875.JPG'><BR>0_IMG_9875.JPG<br>73.87 KB</a><div class='inv'><br><a href='./images/20050930/0_IMG_9875.JPG' ALT='0_IMG_9875.JPG'>0_IMG_9875.JPG</a></div></td>
<td><A ID='0_IMG_9876.JPG' href='reefsandreddust.php?fileId=0_IMG_9876.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/0_IMG_9876.JPG' ALT='0_IMG_9876.JPG'><BR>0_IMG_9876.JPG<br>107.38 KB</a><div class='inv'><br><a href='./images/20050930/0_IMG_9876.JPG' ALT='0_IMG_9876.JPG'>0_IMG_9876.JPG</a></div></td>
<td><A ID='0_IMG_9878.JPG' href='reefsandreddust.php?fileId=0_IMG_9878.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/0_IMG_9878.JPG' ALT='0_IMG_9878.JPG'><BR>0_IMG_9878.JPG<br>82.93 KB</a><div class='inv'><br><a href='./images/20050930/0_IMG_9878.JPG' ALT='0_IMG_9878.JPG'>0_IMG_9878.JPG</a></div></td>
</tr>
<tr><td><A ID='0_IMG_9881.JPG' href='reefsandreddust.php?fileId=0_IMG_9881.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/0_IMG_9881.JPG' ALT='0_IMG_9881.JPG'><BR>0_IMG_9881.JPG<br>75.78 KB</a><div class='inv'><br><a href='./images/20050930/0_IMG_9881.JPG' ALT='0_IMG_9881.JPG'>0_IMG_9881.JPG</a></div></td>
<td><A ID='0_IMG_9889.JPG' href='reefsandreddust.php?fileId=0_IMG_9889.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/0_IMG_9889.JPG' ALT='0_IMG_9889.JPG'><BR>0_IMG_9889.JPG<br>74.19 KB</a><div class='inv'><br><a href='./images/20050930/0_IMG_9889.JPG' ALT='0_IMG_9889.JPG'>0_IMG_9889.JPG</a></div></td>
<td><A ID='0_IMG_9891.JPG' href='reefsandreddust.php?fileId=0_IMG_9891.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/0_IMG_9891.JPG' ALT='0_IMG_9891.JPG'><BR>0_IMG_9891.JPG<br>92.59 KB</a><div class='inv'><br><a href='./images/20050930/0_IMG_9891.JPG' ALT='0_IMG_9891.JPG'>0_IMG_9891.JPG</a></div></td>
<td><A ID='0_IMG_9896.JPG' href='reefsandreddust.php?fileId=0_IMG_9896.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/0_IMG_9896.JPG' ALT='0_IMG_9896.JPG'><BR>0_IMG_9896.JPG<br>51.5 KB</a><div class='inv'><br><a href='./images/20050930/0_IMG_9896.JPG' ALT='0_IMG_9896.JPG'>0_IMG_9896.JPG</a></div></td>
<td><A ID='0_IMG_9897.JPG' href='reefsandreddust.php?fileId=0_IMG_9897.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/0_IMG_9897.JPG' ALT='0_IMG_9897.JPG'><BR>0_IMG_9897.JPG<br>65.05 KB</a><div class='inv'><br><a href='./images/20050930/0_IMG_9897.JPG' ALT='0_IMG_9897.JPG'>0_IMG_9897.JPG</a></div></td>
</tr>
<tr><td><A ID='0_IMG_9898.JPG' href='reefsandreddust.php?fileId=0_IMG_9898.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/0_IMG_9898.JPG' ALT='0_IMG_9898.JPG'><BR>0_IMG_9898.JPG<br>76.28 KB</a><div class='inv'><br><a href='./images/20050930/0_IMG_9898.JPG' ALT='0_IMG_9898.JPG'>0_IMG_9898.JPG</a></div></td>
<td><A ID='0_IMG_9899.JPG' href='reefsandreddust.php?fileId=0_IMG_9899.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/0_IMG_9899.JPG' ALT='0_IMG_9899.JPG'><BR>0_IMG_9899.JPG<br>69.72 KB</a><div class='inv'><br><a href='./images/20050930/0_IMG_9899.JPG' ALT='0_IMG_9899.JPG'>0_IMG_9899.JPG</a></div></td>
<td><A ID='0_IMG_9917.JPG' href='reefsandreddust.php?fileId=0_IMG_9917.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/0_IMG_9917.JPG' ALT='0_IMG_9917.JPG'><BR>0_IMG_9917.JPG<br>38.95 KB</a><div class='inv'><br><a href='./images/20050930/0_IMG_9917.JPG' ALT='0_IMG_9917.JPG'>0_IMG_9917.JPG</a></div></td>
<td><A ID='0_IMG_9923.JPG' href='reefsandreddust.php?fileId=0_IMG_9923.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/0_IMG_9923.JPG' ALT='0_IMG_9923.JPG'><BR>0_IMG_9923.JPG<br>55.1 KB</a><div class='inv'><br><a href='./images/20050930/0_IMG_9923.JPG' ALT='0_IMG_9923.JPG'>0_IMG_9923.JPG</a></div></td>
<td><A ID='0_IMG_9933.JPG' href='reefsandreddust.php?fileId=0_IMG_9933.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/0_IMG_9933.JPG' ALT='0_IMG_9933.JPG'><BR>0_IMG_9933.JPG<br>67.64 KB</a><div class='inv'><br><a href='./images/20050930/0_IMG_9933.JPG' ALT='0_IMG_9933.JPG'>0_IMG_9933.JPG</a></div></td>
</tr>
<tr><td><A ID='0_IMG_9956.JPG' href='reefsandreddust.php?fileId=0_IMG_9956.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/0_IMG_9956.JPG' ALT='0_IMG_9956.JPG'><BR>0_IMG_9956.JPG<br>94.08 KB</a><div class='inv'><br><a href='./images/20050930/0_IMG_9956.JPG' ALT='0_IMG_9956.JPG'>0_IMG_9956.JPG</a></div></td>
<td><A ID='0_IMG_9971.JPG' href='reefsandreddust.php?fileId=0_IMG_9971.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/0_IMG_9971.JPG' ALT='0_IMG_9971.JPG'><BR>0_IMG_9971.JPG<br>73.64 KB</a><div class='inv'><br><a href='./images/20050930/0_IMG_9971.JPG' ALT='0_IMG_9971.JPG'>0_IMG_9971.JPG</a></div></td>
<td><A ID='0_IMG_9977.JPG' href='reefsandreddust.php?fileId=0_IMG_9977.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/0_IMG_9977.JPG' ALT='0_IMG_9977.JPG'><BR>0_IMG_9977.JPG<br>97.73 KB</a><div class='inv'><br><a href='./images/20050930/0_IMG_9977.JPG' ALT='0_IMG_9977.JPG'>0_IMG_9977.JPG</a></div></td>
<td><A ID='0_IMG_9979.JPG' href='reefsandreddust.php?fileId=0_IMG_9979.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/0_IMG_9979.JPG' ALT='0_IMG_9979.JPG'><BR>0_IMG_9979.JPG<br>57.72 KB</a><div class='inv'><br><a href='./images/20050930/0_IMG_9979.JPG' ALT='0_IMG_9979.JPG'>0_IMG_9979.JPG</a></div></td>
<td><A ID='0_IMG_9983.JPG' href='reefsandreddust.php?fileId=0_IMG_9983.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/0_IMG_9983.JPG' ALT='0_IMG_9983.JPG'><BR>0_IMG_9983.JPG<br>100.36 KB</a><div class='inv'><br><a href='./images/20050930/0_IMG_9983.JPG' ALT='0_IMG_9983.JPG'>0_IMG_9983.JPG</a></div></td>
</tr>
<tr><td><A ID='0_IMG_9986.JPG' href='reefsandreddust.php?fileId=0_IMG_9986.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/0_IMG_9986.JPG' ALT='0_IMG_9986.JPG'><BR>0_IMG_9986.JPG<br>49.47 KB</a><div class='inv'><br><a href='./images/20050930/0_IMG_9986.JPG' ALT='0_IMG_9986.JPG'>0_IMG_9986.JPG</a></div></td>
<td><A ID='0_IMG_9989.JPG' href='reefsandreddust.php?fileId=0_IMG_9989.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/0_IMG_9989.JPG' ALT='0_IMG_9989.JPG'><BR>0_IMG_9989.JPG<br>95.26 KB</a><div class='inv'><br><a href='./images/20050930/0_IMG_9989.JPG' ALT='0_IMG_9989.JPG'>0_IMG_9989.JPG</a></div></td>
<td><A ID='0_IMG_9991.JPG' href='reefsandreddust.php?fileId=0_IMG_9991.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/0_IMG_9991.JPG' ALT='0_IMG_9991.JPG'><BR>0_IMG_9991.JPG<br>117.51 KB</a><div class='inv'><br><a href='./images/20050930/0_IMG_9991.JPG' ALT='0_IMG_9991.JPG'>0_IMG_9991.JPG</a></div></td>
<td><A ID='0_IMG_9993.JPG' href='reefsandreddust.php?fileId=0_IMG_9993.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/0_IMG_9993.JPG' ALT='0_IMG_9993.JPG'><BR>0_IMG_9993.JPG<br>136.25 KB</a><div class='inv'><br><a href='./images/20050930/0_IMG_9993.JPG' ALT='0_IMG_9993.JPG'>0_IMG_9993.JPG</a></div></td>
<td><A ID='0_IMG_9995.JPG' href='reefsandreddust.php?fileId=0_IMG_9995.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/0_IMG_9995.JPG' ALT='0_IMG_9995.JPG'><BR>0_IMG_9995.JPG<br>119.31 KB</a><div class='inv'><br><a href='./images/20050930/0_IMG_9995.JPG' ALT='0_IMG_9995.JPG'>0_IMG_9995.JPG</a></div></td>
</tr>
<tr><td><A ID='0_IMG_9997.JPG' href='reefsandreddust.php?fileId=0_IMG_9997.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/0_IMG_9997.JPG' ALT='0_IMG_9997.JPG'><BR>0_IMG_9997.JPG<br>126.95 KB</a><div class='inv'><br><a href='./images/20050930/0_IMG_9997.JPG' ALT='0_IMG_9997.JPG'>0_IMG_9997.JPG</a></div></td>
<td><A ID='0_IMG_9999.JPG' href='reefsandreddust.php?fileId=0_IMG_9999.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/0_IMG_9999.JPG' ALT='0_IMG_9999.JPG'><BR>0_IMG_9999.JPG<br>139.12 KB</a><div class='inv'><br><a href='./images/20050930/0_IMG_9999.JPG' ALT='0_IMG_9999.JPG'>0_IMG_9999.JPG</a></div></td>
<td><A ID='1_IMG_0001.JPG' href='reefsandreddust.php?fileId=1_IMG_0001.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/1_IMG_0001.JPG' ALT='1_IMG_0001.JPG'><BR>1_IMG_0001.JPG<br>114.16 KB</a><div class='inv'><br><a href='./images/20050930/1_IMG_0001.JPG' ALT='1_IMG_0001.JPG'>1_IMG_0001.JPG</a></div></td>
<td><A ID='1_IMG_0008.JPG' href='reefsandreddust.php?fileId=1_IMG_0008.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/1_IMG_0008.JPG' ALT='1_IMG_0008.JPG'><BR>1_IMG_0008.JPG<br>104.08 KB</a><div class='inv'><br><a href='./images/20050930/1_IMG_0008.JPG' ALT='1_IMG_0008.JPG'>1_IMG_0008.JPG</a></div></td>
<td><A ID='1_IMG_0009.JPG' href='reefsandreddust.php?fileId=1_IMG_0009.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/1_IMG_0009.JPG' ALT='1_IMG_0009.JPG'><BR>1_IMG_0009.JPG<br>90.94 KB</a><div class='inv'><br><a href='./images/20050930/1_IMG_0009.JPG' ALT='1_IMG_0009.JPG'>1_IMG_0009.JPG</a></div></td>
</tr>
<tr><td><A ID='1_IMG_0010.JPG' href='reefsandreddust.php?fileId=1_IMG_0010.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/1_IMG_0010.JPG' ALT='1_IMG_0010.JPG'><BR>1_IMG_0010.JPG<br>81.2 KB</a><div class='inv'><br><a href='./images/20050930/1_IMG_0010.JPG' ALT='1_IMG_0010.JPG'>1_IMG_0010.JPG</a></div></td>
<td><A ID='1_IMG_0017.JPG' href='reefsandreddust.php?fileId=1_IMG_0017.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/1_IMG_0017.JPG' ALT='1_IMG_0017.JPG'><BR>1_IMG_0017.JPG<br>105.09 KB</a><div class='inv'><br><a href='./images/20050930/1_IMG_0017.JPG' ALT='1_IMG_0017.JPG'>1_IMG_0017.JPG</a></div></td>
<td><A ID='1_IMG_0026.JPG' href='reefsandreddust.php?fileId=1_IMG_0026.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/1_IMG_0026.JPG' ALT='1_IMG_0026.JPG'><BR>1_IMG_0026.JPG<br>89.38 KB</a><div class='inv'><br><a href='./images/20050930/1_IMG_0026.JPG' ALT='1_IMG_0026.JPG'>1_IMG_0026.JPG</a></div></td>
<td><A ID='1_IMG_0027.JPG' href='reefsandreddust.php?fileId=1_IMG_0027.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/1_IMG_0027.JPG' ALT='1_IMG_0027.JPG'><BR>1_IMG_0027.JPG<br>109.9 KB</a><div class='inv'><br><a href='./images/20050930/1_IMG_0027.JPG' ALT='1_IMG_0027.JPG'>1_IMG_0027.JPG</a></div></td>
<td><A ID='1_IMG_0030.JPG' href='reefsandreddust.php?fileId=1_IMG_0030.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/1_IMG_0030.JPG' ALT='1_IMG_0030.JPG'><BR>1_IMG_0030.JPG<br>94.93 KB</a><div class='inv'><br><a href='./images/20050930/1_IMG_0030.JPG' ALT='1_IMG_0030.JPG'>1_IMG_0030.JPG</a></div></td>
</tr>
<tr><td><A ID='1_IMG_0032.JPG' href='reefsandreddust.php?fileId=1_IMG_0032.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/1_IMG_0032.JPG' ALT='1_IMG_0032.JPG'><BR>1_IMG_0032.JPG<br>73.78 KB</a><div class='inv'><br><a href='./images/20050930/1_IMG_0032.JPG' ALT='1_IMG_0032.JPG'>1_IMG_0032.JPG</a></div></td>
<td><A ID='1_IMG_0033.JPG' href='reefsandreddust.php?fileId=1_IMG_0033.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/1_IMG_0033.JPG' ALT='1_IMG_0033.JPG'><BR>1_IMG_0033.JPG<br>88.81 KB</a><div class='inv'><br><a href='./images/20050930/1_IMG_0033.JPG' ALT='1_IMG_0033.JPG'>1_IMG_0033.JPG</a></div></td>
<td><A ID='1_IMG_0034.JPG' href='reefsandreddust.php?fileId=1_IMG_0034.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/1_IMG_0034.JPG' ALT='1_IMG_0034.JPG'><BR>1_IMG_0034.JPG<br>71.93 KB</a><div class='inv'><br><a href='./images/20050930/1_IMG_0034.JPG' ALT='1_IMG_0034.JPG'>1_IMG_0034.JPG</a></div></td>
<td><A ID='1_IMG_0035.JPG' href='reefsandreddust.php?fileId=1_IMG_0035.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/1_IMG_0035.JPG' ALT='1_IMG_0035.JPG'><BR>1_IMG_0035.JPG<br>70.06 KB</a><div class='inv'><br><a href='./images/20050930/1_IMG_0035.JPG' ALT='1_IMG_0035.JPG'>1_IMG_0035.JPG</a></div></td>
<td><A ID='1_IMG_0039.JPG' href='reefsandreddust.php?fileId=1_IMG_0039.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/1_IMG_0039.JPG' ALT='1_IMG_0039.JPG'><BR>1_IMG_0039.JPG<br>102.28 KB</a><div class='inv'><br><a href='./images/20050930/1_IMG_0039.JPG' ALT='1_IMG_0039.JPG'>1_IMG_0039.JPG</a></div></td>
</tr>
<tr><td><A ID='1_IMG_0042.JPG' href='reefsandreddust.php?fileId=1_IMG_0042.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/1_IMG_0042.JPG' ALT='1_IMG_0042.JPG'><BR>1_IMG_0042.JPG<br>89.26 KB</a><div class='inv'><br><a href='./images/20050930/1_IMG_0042.JPG' ALT='1_IMG_0042.JPG'>1_IMG_0042.JPG</a></div></td>
<td><A ID='1_IMG_0043.JPG' href='reefsandreddust.php?fileId=1_IMG_0043.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/1_IMG_0043.JPG' ALT='1_IMG_0043.JPG'><BR>1_IMG_0043.JPG<br>65.91 KB</a><div class='inv'><br><a href='./images/20050930/1_IMG_0043.JPG' ALT='1_IMG_0043.JPG'>1_IMG_0043.JPG</a></div></td>
<td><A ID='1_IMG_0044.JPG' href='reefsandreddust.php?fileId=1_IMG_0044.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/1_IMG_0044.JPG' ALT='1_IMG_0044.JPG'><BR>1_IMG_0044.JPG<br>49.75 KB</a><div class='inv'><br><a href='./images/20050930/1_IMG_0044.JPG' ALT='1_IMG_0044.JPG'>1_IMG_0044.JPG</a></div></td>
<td><A ID='1_IMG_0052.JPG' href='reefsandreddust.php?fileId=1_IMG_0052.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/1_IMG_0052.JPG' ALT='1_IMG_0052.JPG'><BR>1_IMG_0052.JPG<br>51.77 KB</a><div class='inv'><br><a href='./images/20050930/1_IMG_0052.JPG' ALT='1_IMG_0052.JPG'>1_IMG_0052.JPG</a></div></td>
<td><A ID='1_IMG_0053.JPG' href='reefsandreddust.php?fileId=1_IMG_0053.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/1_IMG_0053.JPG' ALT='1_IMG_0053.JPG'><BR>1_IMG_0053.JPG<br>37.45 KB</a><div class='inv'><br><a href='./images/20050930/1_IMG_0053.JPG' ALT='1_IMG_0053.JPG'>1_IMG_0053.JPG</a></div></td>
</tr>
<tr><td><A ID='1_IMG_0055.JPG' href='reefsandreddust.php?fileId=1_IMG_0055.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/1_IMG_0055.JPG' ALT='1_IMG_0055.JPG'><BR>1_IMG_0055.JPG<br>34.39 KB</a><div class='inv'><br><a href='./images/20050930/1_IMG_0055.JPG' ALT='1_IMG_0055.JPG'>1_IMG_0055.JPG</a></div></td>
<td><A ID='1_IMG_0058.JPG' href='reefsandreddust.php?fileId=1_IMG_0058.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/1_IMG_0058.JPG' ALT='1_IMG_0058.JPG'><BR>1_IMG_0058.JPG<br>96.94 KB</a><div class='inv'><br><a href='./images/20050930/1_IMG_0058.JPG' ALT='1_IMG_0058.JPG'>1_IMG_0058.JPG</a></div></td>
<td><A ID='1_IMG_0061.JPG' href='reefsandreddust.php?fileId=1_IMG_0061.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/1_IMG_0061.JPG' ALT='1_IMG_0061.JPG'><BR>1_IMG_0061.JPG<br>114.96 KB</a><div class='inv'><br><a href='./images/20050930/1_IMG_0061.JPG' ALT='1_IMG_0061.JPG'>1_IMG_0061.JPG</a></div></td>
<td><A ID='1_IMG_0064.JPG' href='reefsandreddust.php?fileId=1_IMG_0064.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/1_IMG_0064.JPG' ALT='1_IMG_0064.JPG'><BR>1_IMG_0064.JPG<br>56.6 KB</a><div class='inv'><br><a href='./images/20050930/1_IMG_0064.JPG' ALT='1_IMG_0064.JPG'>1_IMG_0064.JPG</a></div></td>
<td><A ID='1_IMG_0066.JPG' href='reefsandreddust.php?fileId=1_IMG_0066.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/1_IMG_0066.JPG' ALT='1_IMG_0066.JPG'><BR>1_IMG_0066.JPG<br>40.67 KB</a><div class='inv'><br><a href='./images/20050930/1_IMG_0066.JPG' ALT='1_IMG_0066.JPG'>1_IMG_0066.JPG</a></div></td>
</tr>
<tr><td><A ID='1_IMG_0069.JPG' href='reefsandreddust.php?fileId=1_IMG_0069.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/1_IMG_0069.JPG' ALT='1_IMG_0069.JPG'><BR>1_IMG_0069.JPG<br>68.63 KB</a><div class='inv'><br><a href='./images/20050930/1_IMG_0069.JPG' ALT='1_IMG_0069.JPG'>1_IMG_0069.JPG</a></div></td>
<td><A ID='1_IMG_0070.JPG' href='reefsandreddust.php?fileId=1_IMG_0070.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/1_IMG_0070.JPG' ALT='1_IMG_0070.JPG'><BR>1_IMG_0070.JPG<br>59.92 KB</a><div class='inv'><br><a href='./images/20050930/1_IMG_0070.JPG' ALT='1_IMG_0070.JPG'>1_IMG_0070.JPG</a></div></td>
<td><A ID='1_IMG_0074.JPG' href='reefsandreddust.php?fileId=1_IMG_0074.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/1_IMG_0074.JPG' ALT='1_IMG_0074.JPG'><BR>1_IMG_0074.JPG<br>56.6 KB</a><div class='inv'><br><a href='./images/20050930/1_IMG_0074.JPG' ALT='1_IMG_0074.JPG'>1_IMG_0074.JPG</a></div></td>
<td><A ID='1_IMG_0076.JPG' href='reefsandreddust.php?fileId=1_IMG_0076.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/1_IMG_0076.JPG' ALT='1_IMG_0076.JPG'><BR>1_IMG_0076.JPG<br>60.69 KB</a><div class='inv'><br><a href='./images/20050930/1_IMG_0076.JPG' ALT='1_IMG_0076.JPG'>1_IMG_0076.JPG</a></div></td>
<td><A ID='1_IMG_0092.JPG' href='reefsandreddust.php?fileId=1_IMG_0092.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/1_IMG_0092.JPG' ALT='1_IMG_0092.JPG'><BR>1_IMG_0092.JPG<br>87.58 KB</a><div class='inv'><br><a href='./images/20050930/1_IMG_0092.JPG' ALT='1_IMG_0092.JPG'>1_IMG_0092.JPG</a></div></td>
</tr>
<tr><td><A ID='1_IMG_0094.JPG' href='reefsandreddust.php?fileId=1_IMG_0094.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/1_IMG_0094.JPG' ALT='1_IMG_0094.JPG'><BR>1_IMG_0094.JPG<br>57.95 KB</a><div class='inv'><br><a href='./images/20050930/1_IMG_0094.JPG' ALT='1_IMG_0094.JPG'>1_IMG_0094.JPG</a></div></td>
<td><A ID='1_IMG_0101.JPG' href='reefsandreddust.php?fileId=1_IMG_0101.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/1_IMG_0101.JPG' ALT='1_IMG_0101.JPG'><BR>1_IMG_0101.JPG<br>63.48 KB</a><div class='inv'><br><a href='./images/20050930/1_IMG_0101.JPG' ALT='1_IMG_0101.JPG'>1_IMG_0101.JPG</a></div></td>
<td><A ID='1_IMG_0106.JPG' href='reefsandreddust.php?fileId=1_IMG_0106.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/1_IMG_0106.JPG' ALT='1_IMG_0106.JPG'><BR>1_IMG_0106.JPG<br>41.54 KB</a><div class='inv'><br><a href='./images/20050930/1_IMG_0106.JPG' ALT='1_IMG_0106.JPG'>1_IMG_0106.JPG</a></div></td>
<td><A ID='1_IMG_0110.JPG' href='reefsandreddust.php?fileId=1_IMG_0110.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/1_IMG_0110.JPG' ALT='1_IMG_0110.JPG'><BR>1_IMG_0110.JPG<br>39.58 KB</a><div class='inv'><br><a href='./images/20050930/1_IMG_0110.JPG' ALT='1_IMG_0110.JPG'>1_IMG_0110.JPG</a></div></td>
<td><A ID='1_IMG_0113.JPG' href='reefsandreddust.php?fileId=1_IMG_0113.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/1_IMG_0113.JPG' ALT='1_IMG_0113.JPG'><BR>1_IMG_0113.JPG<br>44.8 KB</a><div class='inv'><br><a href='./images/20050930/1_IMG_0113.JPG' ALT='1_IMG_0113.JPG'>1_IMG_0113.JPG</a></div></td>
</tr>
<tr><td><A ID='1_IMG_0115.JPG' href='reefsandreddust.php?fileId=1_IMG_0115.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/1_IMG_0115.JPG' ALT='1_IMG_0115.JPG'><BR>1_IMG_0115.JPG<br>46.48 KB</a><div class='inv'><br><a href='./images/20050930/1_IMG_0115.JPG' ALT='1_IMG_0115.JPG'>1_IMG_0115.JPG</a></div></td>
<td><A ID='1_IMG_0119.JPG' href='reefsandreddust.php?fileId=1_IMG_0119.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/1_IMG_0119.JPG' ALT='1_IMG_0119.JPG'><BR>1_IMG_0119.JPG<br>54.99 KB</a><div class='inv'><br><a href='./images/20050930/1_IMG_0119.JPG' ALT='1_IMG_0119.JPG'>1_IMG_0119.JPG</a></div></td>
<td><A ID='1_IMG_0120.JPG' href='reefsandreddust.php?fileId=1_IMG_0120.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/1_IMG_0120.JPG' ALT='1_IMG_0120.JPG'><BR>1_IMG_0120.JPG<br>63.61 KB</a><div class='inv'><br><a href='./images/20050930/1_IMG_0120.JPG' ALT='1_IMG_0120.JPG'>1_IMG_0120.JPG</a></div></td>
<td><A ID='1_IMG_0121.JPG' href='reefsandreddust.php?fileId=1_IMG_0121.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/1_IMG_0121.JPG' ALT='1_IMG_0121.JPG'><BR>1_IMG_0121.JPG<br>64.86 KB</a><div class='inv'><br><a href='./images/20050930/1_IMG_0121.JPG' ALT='1_IMG_0121.JPG'>1_IMG_0121.JPG</a></div></td>
<td><A ID='1_IMG_0123.JPG' href='reefsandreddust.php?fileId=1_IMG_0123.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/1_IMG_0123.JPG' ALT='1_IMG_0123.JPG'><BR>1_IMG_0123.JPG<br>70.44 KB</a><div class='inv'><br><a href='./images/20050930/1_IMG_0123.JPG' ALT='1_IMG_0123.JPG'>1_IMG_0123.JPG</a></div></td>
</tr>
<tr><td><A ID='1_IMG_0126.JPG' href='reefsandreddust.php?fileId=1_IMG_0126.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/1_IMG_0126.JPG' ALT='1_IMG_0126.JPG'><BR>1_IMG_0126.JPG<br>27.43 KB</a><div class='inv'><br><a href='./images/20050930/1_IMG_0126.JPG' ALT='1_IMG_0126.JPG'>1_IMG_0126.JPG</a></div></td>
<td><A ID='1_IMG_0127.JPG' href='reefsandreddust.php?fileId=1_IMG_0127.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/1_IMG_0127.JPG' ALT='1_IMG_0127.JPG'><BR>1_IMG_0127.JPG<br>50.98 KB</a><div class='inv'><br><a href='./images/20050930/1_IMG_0127.JPG' ALT='1_IMG_0127.JPG'>1_IMG_0127.JPG</a></div></td>
<td><A ID='1_IMG_0130.JPG' href='reefsandreddust.php?fileId=1_IMG_0130.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/1_IMG_0130.JPG' ALT='1_IMG_0130.JPG'><BR>1_IMG_0130.JPG<br>50.38 KB</a><div class='inv'><br><a href='./images/20050930/1_IMG_0130.JPG' ALT='1_IMG_0130.JPG'>1_IMG_0130.JPG</a></div></td>
<td><A ID='1_IMG_0134.JPG' href='reefsandreddust.php?fileId=1_IMG_0134.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/1_IMG_0134.JPG' ALT='1_IMG_0134.JPG'><BR>1_IMG_0134.JPG<br>48.07 KB</a><div class='inv'><br><a href='./images/20050930/1_IMG_0134.JPG' ALT='1_IMG_0134.JPG'>1_IMG_0134.JPG</a></div></td>
<td><A ID='1_IMG_0141.JPG' href='reefsandreddust.php?fileId=1_IMG_0141.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/1_IMG_0141.JPG' ALT='1_IMG_0141.JPG'><BR>1_IMG_0141.JPG<br>105.62 KB</a><div class='inv'><br><a href='./images/20050930/1_IMG_0141.JPG' ALT='1_IMG_0141.JPG'>1_IMG_0141.JPG</a></div></td>
</tr>
<tr><td><A ID='1_IMG_0151.JPG' href='reefsandreddust.php?fileId=1_IMG_0151.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/1_IMG_0151.JPG' ALT='1_IMG_0151.JPG'><BR>1_IMG_0151.JPG<br>57.57 KB</a><div class='inv'><br><a href='./images/20050930/1_IMG_0151.JPG' ALT='1_IMG_0151.JPG'>1_IMG_0151.JPG</a></div></td>
<td><A ID='1_IMG_0158.JPG' href='reefsandreddust.php?fileId=1_IMG_0158.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/1_IMG_0158.JPG' ALT='1_IMG_0158.JPG'><BR>1_IMG_0158.JPG<br>40.07 KB</a><div class='inv'><br><a href='./images/20050930/1_IMG_0158.JPG' ALT='1_IMG_0158.JPG'>1_IMG_0158.JPG</a></div></td>
<td><A ID='1_IMG_0159.JPG' href='reefsandreddust.php?fileId=1_IMG_0159.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/1_IMG_0159.JPG' ALT='1_IMG_0159.JPG'><BR>1_IMG_0159.JPG<br>50.84 KB</a><div class='inv'><br><a href='./images/20050930/1_IMG_0159.JPG' ALT='1_IMG_0159.JPG'>1_IMG_0159.JPG</a></div></td>
<td><A ID='1_IMG_0161.JPG' href='reefsandreddust.php?fileId=1_IMG_0161.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/1_IMG_0161.JPG' ALT='1_IMG_0161.JPG'><BR>1_IMG_0161.JPG<br>60.4 KB</a><div class='inv'><br><a href='./images/20050930/1_IMG_0161.JPG' ALT='1_IMG_0161.JPG'>1_IMG_0161.JPG</a></div></td>
<td><A ID='1_IMG_0162.JPG' href='reefsandreddust.php?fileId=1_IMG_0162.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/1_IMG_0162.JPG' ALT='1_IMG_0162.JPG'><BR>1_IMG_0162.JPG<br>71.65 KB</a><div class='inv'><br><a href='./images/20050930/1_IMG_0162.JPG' ALT='1_IMG_0162.JPG'>1_IMG_0162.JPG</a></div></td>
</tr>
<tr><td><A ID='1_IMG_0164.JPG' href='reefsandreddust.php?fileId=1_IMG_0164.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/1_IMG_0164.JPG' ALT='1_IMG_0164.JPG'><BR>1_IMG_0164.JPG<br>51.98 KB</a><div class='inv'><br><a href='./images/20050930/1_IMG_0164.JPG' ALT='1_IMG_0164.JPG'>1_IMG_0164.JPG</a></div></td>
<td><A ID='1_IMG_0174.JPG' href='reefsandreddust.php?fileId=1_IMG_0174.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/1_IMG_0174.JPG' ALT='1_IMG_0174.JPG'><BR>1_IMG_0174.JPG<br>68.19 KB</a><div class='inv'><br><a href='./images/20050930/1_IMG_0174.JPG' ALT='1_IMG_0174.JPG'>1_IMG_0174.JPG</a></div></td>
<td><A ID='1_IMG_0182.JPG' href='reefsandreddust.php?fileId=1_IMG_0182.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/1_IMG_0182.JPG' ALT='1_IMG_0182.JPG'><BR>1_IMG_0182.JPG<br>50.37 KB</a><div class='inv'><br><a href='./images/20050930/1_IMG_0182.JPG' ALT='1_IMG_0182.JPG'>1_IMG_0182.JPG</a></div></td>
<td><A ID='1_IMG_0189.JPG' href='reefsandreddust.php?fileId=1_IMG_0189.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/1_IMG_0189.JPG' ALT='1_IMG_0189.JPG'><BR>1_IMG_0189.JPG<br>46.66 KB</a><div class='inv'><br><a href='./images/20050930/1_IMG_0189.JPG' ALT='1_IMG_0189.JPG'>1_IMG_0189.JPG</a></div></td>
<td><A ID='1_IMG_0201.JPG' href='reefsandreddust.php?fileId=1_IMG_0201.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/1_IMG_0201.JPG' ALT='1_IMG_0201.JPG'><BR>1_IMG_0201.JPG<br>65.82 KB</a><div class='inv'><br><a href='./images/20050930/1_IMG_0201.JPG' ALT='1_IMG_0201.JPG'>1_IMG_0201.JPG</a></div></td>
</tr>
<tr><td><A ID='1_IMG_0204.JPG' href='reefsandreddust.php?fileId=1_IMG_0204.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/1_IMG_0204.JPG' ALT='1_IMG_0204.JPG'><BR>1_IMG_0204.JPG<br>47.33 KB</a><div class='inv'><br><a href='./images/20050930/1_IMG_0204.JPG' ALT='1_IMG_0204.JPG'>1_IMG_0204.JPG</a></div></td>
<td><A ID='1_IMG_0221.JPG' href='reefsandreddust.php?fileId=1_IMG_0221.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/1_IMG_0221.JPG' ALT='1_IMG_0221.JPG'><BR>1_IMG_0221.JPG<br>39.71 KB</a><div class='inv'><br><a href='./images/20050930/1_IMG_0221.JPG' ALT='1_IMG_0221.JPG'>1_IMG_0221.JPG</a></div></td>
<td><A ID='1_IMG_0222.JPG' href='reefsandreddust.php?fileId=1_IMG_0222.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/1_IMG_0222.JPG' ALT='1_IMG_0222.JPG'><BR>1_IMG_0222.JPG<br>53.49 KB</a><div class='inv'><br><a href='./images/20050930/1_IMG_0222.JPG' ALT='1_IMG_0222.JPG'>1_IMG_0222.JPG</a></div></td>
<td><A ID='1_IMG_0223.JPG' href='reefsandreddust.php?fileId=1_IMG_0223.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/1_IMG_0223.JPG' ALT='1_IMG_0223.JPG'><BR>1_IMG_0223.JPG<br>76.86 KB</a><div class='inv'><br><a href='./images/20050930/1_IMG_0223.JPG' ALT='1_IMG_0223.JPG'>1_IMG_0223.JPG</a></div></td>
<td><A ID='1_IMG_0225.JPG' href='reefsandreddust.php?fileId=1_IMG_0225.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/1_IMG_0225.JPG' ALT='1_IMG_0225.JPG'><BR>1_IMG_0225.JPG<br>77.07 KB</a><div class='inv'><br><a href='./images/20050930/1_IMG_0225.JPG' ALT='1_IMG_0225.JPG'>1_IMG_0225.JPG</a></div></td>
</tr>
<tr><td><A ID='1_IMG_0227.JPG' href='reefsandreddust.php?fileId=1_IMG_0227.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/1_IMG_0227.JPG' ALT='1_IMG_0227.JPG'><BR>1_IMG_0227.JPG<br>54.82 KB</a><div class='inv'><br><a href='./images/20050930/1_IMG_0227.JPG' ALT='1_IMG_0227.JPG'>1_IMG_0227.JPG</a></div></td>
<td><A ID='1_IMG_0230.JPG' href='reefsandreddust.php?fileId=1_IMG_0230.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/1_IMG_0230.JPG' ALT='1_IMG_0230.JPG'><BR>1_IMG_0230.JPG<br>55.77 KB</a><div class='inv'><br><a href='./images/20050930/1_IMG_0230.JPG' ALT='1_IMG_0230.JPG'>1_IMG_0230.JPG</a></div></td>
<td><A ID='1_IMG_0232.JPG' href='reefsandreddust.php?fileId=1_IMG_0232.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/1_IMG_0232.JPG' ALT='1_IMG_0232.JPG'><BR>1_IMG_0232.JPG<br>88.43 KB</a><div class='inv'><br><a href='./images/20050930/1_IMG_0232.JPG' ALT='1_IMG_0232.JPG'>1_IMG_0232.JPG</a></div></td>
<td><A ID='1_IMG_0235.JPG' href='reefsandreddust.php?fileId=1_IMG_0235.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/1_IMG_0235.JPG' ALT='1_IMG_0235.JPG'><BR>1_IMG_0235.JPG<br>31.57 KB</a><div class='inv'><br><a href='./images/20050930/1_IMG_0235.JPG' ALT='1_IMG_0235.JPG'>1_IMG_0235.JPG</a></div></td>
<td><A ID='1_IMG_0241.JPG' href='reefsandreddust.php?fileId=1_IMG_0241.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/1_IMG_0241.JPG' ALT='1_IMG_0241.JPG'><BR>1_IMG_0241.JPG<br>59.81 KB</a><div class='inv'><br><a href='./images/20050930/1_IMG_0241.JPG' ALT='1_IMG_0241.JPG'>1_IMG_0241.JPG</a></div></td>
</tr>
<tr><td><A ID='1_IMG_0246.JPG' href='reefsandreddust.php?fileId=1_IMG_0246.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/1_IMG_0246.JPG' ALT='1_IMG_0246.JPG'><BR>1_IMG_0246.JPG<br>62.36 KB</a><div class='inv'><br><a href='./images/20050930/1_IMG_0246.JPG' ALT='1_IMG_0246.JPG'>1_IMG_0246.JPG</a></div></td>
<td><A ID='1_IMG_0250.JPG' href='reefsandreddust.php?fileId=1_IMG_0250.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/1_IMG_0250.JPG' ALT='1_IMG_0250.JPG'><BR>1_IMG_0250.JPG<br>97.85 KB</a><div class='inv'><br><a href='./images/20050930/1_IMG_0250.JPG' ALT='1_IMG_0250.JPG'>1_IMG_0250.JPG</a></div></td>
<td><A ID='1_IMG_0251.JPG' href='reefsandreddust.php?fileId=1_IMG_0251.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/1_IMG_0251.JPG' ALT='1_IMG_0251.JPG'><BR>1_IMG_0251.JPG<br>93.33 KB</a><div class='inv'><br><a href='./images/20050930/1_IMG_0251.JPG' ALT='1_IMG_0251.JPG'>1_IMG_0251.JPG</a></div></td>
<td><A ID='1_IMG_0260.JPG' href='reefsandreddust.php?fileId=1_IMG_0260.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/1_IMG_0260.JPG' ALT='1_IMG_0260.JPG'><BR>1_IMG_0260.JPG<br>94.21 KB</a><div class='inv'><br><a href='./images/20050930/1_IMG_0260.JPG' ALT='1_IMG_0260.JPG'>1_IMG_0260.JPG</a></div></td>
<td><A ID='1_IMG_0263.JPG' href='reefsandreddust.php?fileId=1_IMG_0263.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/1_IMG_0263.JPG' ALT='1_IMG_0263.JPG'><BR>1_IMG_0263.JPG<br>76.95 KB</a><div class='inv'><br><a href='./images/20050930/1_IMG_0263.JPG' ALT='1_IMG_0263.JPG'>1_IMG_0263.JPG</a></div></td>
</tr>
<tr><td><A ID='1_IMG_0268.JPG' href='reefsandreddust.php?fileId=1_IMG_0268.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/1_IMG_0268.JPG' ALT='1_IMG_0268.JPG'><BR>1_IMG_0268.JPG<br>69.66 KB</a><div class='inv'><br><a href='./images/20050930/1_IMG_0268.JPG' ALT='1_IMG_0268.JPG'>1_IMG_0268.JPG</a></div></td>
<td><A ID='1_IMG_0271.JPG' href='reefsandreddust.php?fileId=1_IMG_0271.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/1_IMG_0271.JPG' ALT='1_IMG_0271.JPG'><BR>1_IMG_0271.JPG<br>113.77 KB</a><div class='inv'><br><a href='./images/20050930/1_IMG_0271.JPG' ALT='1_IMG_0271.JPG'>1_IMG_0271.JPG</a></div></td>
<td><A ID='1_IMG_0273.JPG' href='reefsandreddust.php?fileId=1_IMG_0273.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/1_IMG_0273.JPG' ALT='1_IMG_0273.JPG'><BR>1_IMG_0273.JPG<br>76.12 KB</a><div class='inv'><br><a href='./images/20050930/1_IMG_0273.JPG' ALT='1_IMG_0273.JPG'>1_IMG_0273.JPG</a></div></td>
<td><A ID='1_IMG_0274.JPG' href='reefsandreddust.php?fileId=1_IMG_0274.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/1_IMG_0274.JPG' ALT='1_IMG_0274.JPG'><BR>1_IMG_0274.JPG<br>59.88 KB</a><div class='inv'><br><a href='./images/20050930/1_IMG_0274.JPG' ALT='1_IMG_0274.JPG'>1_IMG_0274.JPG</a></div></td>
<td><A ID='1_IMG_0278.JPG' href='reefsandreddust.php?fileId=1_IMG_0278.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/1_IMG_0278.JPG' ALT='1_IMG_0278.JPG'><BR>1_IMG_0278.JPG<br>74.1 KB</a><div class='inv'><br><a href='./images/20050930/1_IMG_0278.JPG' ALT='1_IMG_0278.JPG'>1_IMG_0278.JPG</a></div></td>
</tr>
<tr><td><A ID='1_IMG_0282.JPG' href='reefsandreddust.php?fileId=1_IMG_0282.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/1_IMG_0282.JPG' ALT='1_IMG_0282.JPG'><BR>1_IMG_0282.JPG<br>53.91 KB</a><div class='inv'><br><a href='./images/20050930/1_IMG_0282.JPG' ALT='1_IMG_0282.JPG'>1_IMG_0282.JPG</a></div></td>
<td><A ID='1_IMG_0283.JPG' href='reefsandreddust.php?fileId=1_IMG_0283.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/1_IMG_0283.JPG' ALT='1_IMG_0283.JPG'><BR>1_IMG_0283.JPG<br>67.75 KB</a><div class='inv'><br><a href='./images/20050930/1_IMG_0283.JPG' ALT='1_IMG_0283.JPG'>1_IMG_0283.JPG</a></div></td>
<td><A ID='1_IMG_0284.JPG' href='reefsandreddust.php?fileId=1_IMG_0284.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/1_IMG_0284.JPG' ALT='1_IMG_0284.JPG'><BR>1_IMG_0284.JPG<br>82.34 KB</a><div class='inv'><br><a href='./images/20050930/1_IMG_0284.JPG' ALT='1_IMG_0284.JPG'>1_IMG_0284.JPG</a></div></td>
<td><A ID='1_IMG_0285.JPG' href='reefsandreddust.php?fileId=1_IMG_0285.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/1_IMG_0285.JPG' ALT='1_IMG_0285.JPG'><BR>1_IMG_0285.JPG<br>73.83 KB</a><div class='inv'><br><a href='./images/20050930/1_IMG_0285.JPG' ALT='1_IMG_0285.JPG'>1_IMG_0285.JPG</a></div></td>
<td><A ID='1_IMG_0286.JPG' href='reefsandreddust.php?fileId=1_IMG_0286.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050930/1_IMG_0286.JPG' ALT='1_IMG_0286.JPG'><BR>1_IMG_0286.JPG<br>123.26 KB</a><div class='inv'><br><a href='./images/20050930/1_IMG_0286.JPG' ALT='1_IMG_0286.JPG'>1_IMG_0286.JPG</a></div></td>
</tr>
</table>	</div>
</div>
</body>
</html>