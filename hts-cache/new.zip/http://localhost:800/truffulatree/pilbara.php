<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - 7/10/2005 - The Pilbara</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="The Pilbara">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="Greetings from a Bum" href='greetingsfromabum.php'>29/4/2005</a></li>
<li><a title="Onward" href='onward.php'>2/5/2005</a></li>
<li><a title="It's a tough life (pt 1: Bundaberg, Agnes Water and 1770)" href='itsatoughlife1.php'>17/5/2005</a></li>
<li><a title="It's a tough life (pt 2: Rockhampton, Emu Park and Great Keppel Island)" href='itsatoughlife2.php'>23/5/2005</a></li>
<li><a title="There and Back Again - a Yo-yo's Tale" href='thereandbackagain.php'>18/6/2005</a></li>
<li><a title="Platypi and Grey Nomads" href='platypiandgreynomads.php'>24/6/2005</a></li>
<li><a title="Blowing Bubbles in a Watery Tomb" href='blowingbubbles.php'>1/7/2005</a></li>
<li><a title="Pieces of History" href='piecesofhistory.php'>8/7/2005</a></li>
<li><a title="Walks and Waterfalls" href='walksandwaterfalls.php'>15/7/2005</a></li>
<li><a title="Mission to Tribulation" href='missiontotribulation.php'>22/7/2005</a></li>
<li><a title="Levity, Limestone and Lava" href='levitylimestoneandlava.php'>29/7/2005</a></li>
<li><a title="Into the Never Never" href='intothenevernever.php'>5/8/2005</a></li>
<li><a title="Slowing the pace in Darwin" href='slowingthepaceindarwin.php'>12/8/2005</a></li>
<li><a title="Blistering Barnacles and Leaping Lizards" href='leapinglizards.php'>19/8/2005</a></li>
<li><a title="Kakadu and Litchfield" href='kakadu.php'>26/8/2005</a></li>
<li><a title="Legacies of War" href='legaciesofwar.php'>2/9/2005</a></li>
<li><a title="Go West" href='gowest.php'>10/9/2005</a></li>
<li><a title="Things from Above" href='thingsfromabove.php'>16/9/2005</a></li>
<li><a title="The West Coast" href='thewestcoast.php'>23/9/2005</a></li>
<li><a title="Reefs and Red Dust" href='reefsandreddust.php'>30/9/2005</a></li>
<li><div class='activemenu'>7/10/2005</div></li>
<li><a title="Paradise with a Headwind" href='paradisewithaheadwind.php'>14/10/2005</a></li>
<li><a title="Down the Coral Coast" href='downthecoralcoast.php'>21/10/2005</a></li>
<li><a title="Pinnacles and Pinnipeds" href='pinnaclesandpinnipeds.php'>28/10/2005</a></li>
<li><a title="A week in Perth" href='perth.php'>4/11/2005</a></li>
<li><a title="The Southwest (from Above and Below)" href='thesouthwest.php'>11/11/2005</a></li>
<li><a title="More Heights and Depths" href='moreheightsanddepths.php'>18/11/2005</a></li>
<li><a title="Across the Nullarbor (and a bit beyond)" href='nullarbor.php'>25/11/2005</a></li>
<li><a title="Double Whammy" href='doublewhammy.php'>9/12/2005</a></li>
<li><a title="Two Cities" href='twocities.php'>19/12/2005</a></li>
<li><a title="Tassie - Part 1" href='tassie1.php'>1/1/2006</a></li>
<li><a title="Tassie - Part 2" href='tassie2.php'>7/1/2006</a></li>
<li><a title="Full Circle" href='fullcircle.php'>26/1/2006</a></li>
<li><a title="The Wrap Up" href='thewrapup.php'>23/3/2006</a></li>
<li> </li><br><li>Or go back to:</li><li><a title='Travelouges and blogs from my trip around Australia' href="nerdseyeview.php">Nerd's Eye View</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>7/10/2005</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Travel stories and pictures' href="travel.php">Travelogues</a> > <a title='Travelouges and blogs from my trip around Australia' href="nerdseyeview.php">Nerd's Eye View</a> > <a title='The Pilbara' href="pilbara.php">7/10/2005</a>
<br><br>		


<h1>The Pilbara</h1>

<a href="images/maps/Map051007.gif"><img src="images/maps/Map051007_sm.gif" align="right"></a>

<p>Yay, it's email time again. We've spent most of the week exploring the Pilbara region, a fantastic landscape of ancient geology (very ancient - 2.5 billion years!), much of which is iron ore country (ie, pretty damn red; we've both been somewhat stained by the dust, in fact).</p>

<p>Taking up after last week, we explored the ghost town of Cossack again briefly in the morning, including taking a bike ride out to the old cemetery, which was full of cheerfully inscribed headstones, recording for posterity things like entire families being "drowned in the foam passage" (which I would imagine is not nearly as fun as it sounds).</p>

<p>Then we hit the road again, and began our journey through the ancient landscape of the Pilbara. Much of the trip was on dirt roads, which I had some reservations about the good sense of travelling on, after having had a conversation with a random guy we met at the backpackers in Cossack.</p>

<p>He was quite shocked that we were even considering the trip, in my car, with only one spare tyre. However, this completely contradicted all the other information I had on the area, and as it turned out he was quite wrong about how terrible the roads were (they were fairly rocky and corrugated in places, but we took our time and had no blowouts at all), so go figure.</p>

<p>The first day's travel took us to Millstream-Chichester National Park, where we camped by a nice billabong (but not under the shade of Coolabah trees, they were Snappy Gums). It was our second choice of campsite, the first being full, due to the unfortunate timing of school holidays.</p>

<p>Despite this, it was a nice spot, and we went for a walk in the morning, followed by a very pleasant, crocodile-free swim.</p>

<p>The simple plan was then to drive to Karijini (formerly Hamersley) National Park, which we did, although it took us all day, due to the road being pretty bad in places, and just plain long. Along the way, we passed through Wittenoom, the old asbestos mining town, now pretty much a ghost town of 25 hardcore locals.</p>

<p>Over the two days the scenery had been getting steadily nicer too, but the Wittenoom area, on the edge of Karijini was where things started to get really nice, with weathered outcrops of cracked iron ore rising up out of the plain we were on.</p>

<p>In the end we made it to the first campsite in Karijini, near Dales Gorge, just as the day was winding up.</p>

<p>We got up fairly early the next morning, and spent that day exploring the first system of gorges nearby. The geology of the area is quite interesting, and quite different to anything I've encountered yet on my trip, with a highly layered structure. This often gives the gorges in the area a stepped appearance, all very red of course due to the iron. There are also veins of blue asbestos running through the rock in some places, which I'm sure would be handy in the case of fire.</p>

<p>All up the gorges we walked through had three lovely swimming spots, two of which we sampled (the third being overrun by school holidaying munchkins and their entourages, bless 'em).</p>

<p>We ended the day by shifting to the other campsite in the park, near the convergence of several other gorges, basically the park's premier attraction.</p>

<p>Despite an early rise, we seemed to be the last to leave the next morning to explore the area, but in the end it made no difference to the stunning landscape.</p>

<p>Contrasting the previous day's gorges, which had been fairly deep and quite wide, these ones were often quite narrow, and in places they shrink down to only a metre or two wide, and become the territory of serious canyoners if you want to go very far.</p>

<p>We didn't pack the abseiling equipment, so we had to settle for the mere class 5 tracks, which nonetheless involve swimming and wading through pretty cold water, and the odd scramble over slippery rocks. Needless to say, photos of such places were not taken, as I wasn't game to swim and wade through water with my rather expensive camera held high above my head.</p>

<p>I didn't miss all the photo opportunities though, and there are a couple of shots (one of which is attached) that show the coolness of these places. Swimming along through them with my glasses and hat on was quite a unique experience.</p>

<p>Actually, I should mention my hat. You see, I've traded in my old straw model for a leather hat, which I found at the hostel in Port Hedland. It was just like one I wanted to buy at the markets in Darwin, but never got around to, so really it was quite a serendipitous find. It's nicely worn in too, for added Wallaby Jack credibility.</p>

<p>This is the Nerd's Eye View of course, so I have to justify my hat exchange by presenting appropriate stats.</p>

<p>Old hat (straw):
<ul>
	<li>Armour: 0.5/50</li>
	<li>Sun shielding: 6/10 (Mexican sombrero 10, skull cap 1)</li>
	<li>Comfort (fit): 3/10</li>
	<li>Comfort (head temperature): 8/10</li>
	<li>-10 charisma</li>
	<li>+15 apparent age</li>
	<li>+2 nerd cred</li>
	<li>-5 tourist cred</li>
	<li>-5 intelligence (should have known better as it looks goofy)</li>
</ul>
</p>

<p>New hat (leather):
<ul>
	<li>Armour: 2/50</li>
	<li>Sun shielding: 4/10</li>
	<li>Comfort (fit): 7/10</li>
	<li>Comfort (head temperature): 4/10</li>
	<li>+4 charisma (in outback towns)</li>
	<li>+15 ability to kill crocodiles with bare hands</li>
	<li>+5 apparent age</li>
	<li>-3 intelligence (redneck factor)</li>
	<li>+7 fear of snakes</li>
	<li>+10 ability to use whip</li>
</ul>
</p>

<p>Anyway, it's plain to see it was a great improvement in my overall armour class.</p>

<p>Hats aside, the day was great. We had many lovely swims, including in a great spot called Kermit's pool (Kermit was not present, obviously off seeking the rainbow connection).</p>

<p>We finished the day by visiting several lookouts and admiring the striking landscape in general, then headed back to the campsite for the usual dinner ritual.</p>

<p>The next morning we rose bright and early, and managed to get on the road by 7:30. Nonetheless, it still took us all day to reach Exmouth, a distance of about 600kms. Admittedly though, I did stop and write my column beside a random park in the town of Tom Price, and we also stopped a few times to observe interesting birds, including a pair of Wedge-tailed Eagles and a couple of encounters with wild Emus, one of which I managed to photograph just before it bolted across the road.</p>

<p>We've since spent a day in Exmouth, which is pretty boring really, but is near all sorts of lovely coastline including Ningaloo Reef, which we'll explore over the next week. The Whale Sharks aren't here any more unfortunately, but there are apparently still all sorts of cool things to see, including Manta Rays, which I've been wanting to see for ages.</p>

<p>Anyway, hope you're all well as usual, and as usual good to hear from those of you who've written.</p>

<p>Happy snaps for this week are:</p>
<!-- 
<ul>
<li><a href="?fileId=IMG_0328.JPG">Spinifex Pigeon</a></li>
<li><a href="?fileId=IMG_0490.JPG">Swimming at Fortescue Falls</a></li>
<li><a href="?fileId=IMG_0498.JPG">Gorge, one, wide</a></li>
<li><a href="?fileId=IMG_0518.JPG">Gorge, one, narrow</a></li>
<li><a href="?fileId=IMG_0597_crop.JPG">Old man Emu</a></li>
</ul>
 -->
<table width="800">
	<tr>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=IMG_0328.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20051007/IMG_0328.JPG' ALT='Spinifex Pigeon'><BR>Spinifex Pigeon</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=IMG_0490.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20051007/IMG_0490.JPG' ALT='Swimming at Fortescue Falls'><BR>Swimming at Fortescue Falls</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=IMG_0498.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20051007/IMG_0498.JPG' ALT='Gorge, one, wide'><BR>Gorge, one, wide</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=IMG_0518.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20051007/IMG_0518.JPG' ALT='Gorge, one, narrow'><BR>Gorge, one, narrow</a>
	</td>
	<td ALIGN=CENTER VALIGN=top>
		<A href='?fileId=IMG_0597_crop.JPG'>
		<img src='modules/cms/showthumb.php?image=../.././images/20051007/IMG_0597_crop.JPG' ALT='Old man Emu'><BR>Old man Emu</a>
	</td>
	</tr>
</table>

<br><br>
All images in this gallery:<br>
<table width='800'>
<tr>
</tr>
<tr><td><A ID='IMG_0290.JPG' href='pilbara.php?fileId=IMG_0290.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051007/IMG_0290.JPG' ALT='IMG_0290.JPG'><BR>IMG_0290.JPG<br>93.46 KB</a><div class='inv'><br><a href='./images/20051007/IMG_0290.JPG' ALT='IMG_0290.JPG'>IMG_0290.JPG</a></div></td>
<td><A ID='IMG_0292.JPG' href='pilbara.php?fileId=IMG_0292.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051007/IMG_0292.JPG' ALT='IMG_0292.JPG'><BR>IMG_0292.JPG<br>89.66 KB</a><div class='inv'><br><a href='./images/20051007/IMG_0292.JPG' ALT='IMG_0292.JPG'>IMG_0292.JPG</a></div></td>
<td><A ID='IMG_0293.JPG' href='pilbara.php?fileId=IMG_0293.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051007/IMG_0293.JPG' ALT='IMG_0293.JPG'><BR>IMG_0293.JPG<br>91.57 KB</a><div class='inv'><br><a href='./images/20051007/IMG_0293.JPG' ALT='IMG_0293.JPG'>IMG_0293.JPG</a></div></td>
<td><A ID='IMG_0298.JPG' href='pilbara.php?fileId=IMG_0298.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051007/IMG_0298.JPG' ALT='IMG_0298.JPG'><BR>IMG_0298.JPG<br>54.19 KB</a><div class='inv'><br><a href='./images/20051007/IMG_0298.JPG' ALT='IMG_0298.JPG'>IMG_0298.JPG</a></div></td>
<td><A ID='IMG_0300.JPG' href='pilbara.php?fileId=IMG_0300.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051007/IMG_0300.JPG' ALT='IMG_0300.JPG'><BR>IMG_0300.JPG<br>73.17 KB</a><div class='inv'><br><a href='./images/20051007/IMG_0300.JPG' ALT='IMG_0300.JPG'>IMG_0300.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_0301.JPG' href='pilbara.php?fileId=IMG_0301.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051007/IMG_0301.JPG' ALT='IMG_0301.JPG'><BR>IMG_0301.JPG<br>64.14 KB</a><div class='inv'><br><a href='./images/20051007/IMG_0301.JPG' ALT='IMG_0301.JPG'>IMG_0301.JPG</a></div></td>
<td><A ID='IMG_0312.JPG' href='pilbara.php?fileId=IMG_0312.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051007/IMG_0312.JPG' ALT='IMG_0312.JPG'><BR>IMG_0312.JPG<br>91.16 KB</a><div class='inv'><br><a href='./images/20051007/IMG_0312.JPG' ALT='IMG_0312.JPG'>IMG_0312.JPG</a></div></td>
<td><A ID='IMG_0320.JPG' href='pilbara.php?fileId=IMG_0320.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051007/IMG_0320.JPG' ALT='IMG_0320.JPG'><BR>IMG_0320.JPG<br>56.22 KB</a><div class='inv'><br><a href='./images/20051007/IMG_0320.JPG' ALT='IMG_0320.JPG'>IMG_0320.JPG</a></div></td>
<td><A ID='IMG_0321.JPG' href='pilbara.php?fileId=IMG_0321.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051007/IMG_0321.JPG' ALT='IMG_0321.JPG'><BR>IMG_0321.JPG<br>100.14 KB</a><div class='inv'><br><a href='./images/20051007/IMG_0321.JPG' ALT='IMG_0321.JPG'>IMG_0321.JPG</a></div></td>
<td><A ID='IMG_0324.JPG' href='pilbara.php?fileId=IMG_0324.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051007/IMG_0324.JPG' ALT='IMG_0324.JPG'><BR>IMG_0324.JPG<br>93 KB</a><div class='inv'><br><a href='./images/20051007/IMG_0324.JPG' ALT='IMG_0324.JPG'>IMG_0324.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_0328.JPG' href='pilbara.php?fileId=IMG_0328.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051007/IMG_0328.JPG' ALT='IMG_0328.JPG'><BR>IMG_0328.JPG<br>54.09 KB</a><div class='inv'><br><a href='./images/20051007/IMG_0328.JPG' ALT='IMG_0328.JPG'>IMG_0328.JPG</a></div></td>
<td><A ID='IMG_0337.JPG' href='pilbara.php?fileId=IMG_0337.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051007/IMG_0337.JPG' ALT='IMG_0337.JPG'><BR>IMG_0337.JPG<br>49.29 KB</a><div class='inv'><br><a href='./images/20051007/IMG_0337.JPG' ALT='IMG_0337.JPG'>IMG_0337.JPG</a></div></td>
<td><A ID='IMG_0339.JPG' href='pilbara.php?fileId=IMG_0339.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051007/IMG_0339.JPG' ALT='IMG_0339.JPG'><BR>IMG_0339.JPG<br>69.63 KB</a><div class='inv'><br><a href='./images/20051007/IMG_0339.JPG' ALT='IMG_0339.JPG'>IMG_0339.JPG</a></div></td>
<td><A ID='IMG_0341.JPG' href='pilbara.php?fileId=IMG_0341.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051007/IMG_0341.JPG' ALT='IMG_0341.JPG'><BR>IMG_0341.JPG<br>100.16 KB</a><div class='inv'><br><a href='./images/20051007/IMG_0341.JPG' ALT='IMG_0341.JPG'>IMG_0341.JPG</a></div></td>
<td><A ID='IMG_0344.JPG' href='pilbara.php?fileId=IMG_0344.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051007/IMG_0344.JPG' ALT='IMG_0344.JPG'><BR>IMG_0344.JPG<br>58.87 KB</a><div class='inv'><br><a href='./images/20051007/IMG_0344.JPG' ALT='IMG_0344.JPG'>IMG_0344.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_0347.JPG' href='pilbara.php?fileId=IMG_0347.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051007/IMG_0347.JPG' ALT='IMG_0347.JPG'><BR>IMG_0347.JPG<br>86.72 KB</a><div class='inv'><br><a href='./images/20051007/IMG_0347.JPG' ALT='IMG_0347.JPG'>IMG_0347.JPG</a></div></td>
<td><A ID='IMG_0348.JPG' href='pilbara.php?fileId=IMG_0348.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051007/IMG_0348.JPG' ALT='IMG_0348.JPG'><BR>IMG_0348.JPG<br>106.57 KB</a><div class='inv'><br><a href='./images/20051007/IMG_0348.JPG' ALT='IMG_0348.JPG'>IMG_0348.JPG</a></div></td>
<td><A ID='IMG_0353.JPG' href='pilbara.php?fileId=IMG_0353.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051007/IMG_0353.JPG' ALT='IMG_0353.JPG'><BR>IMG_0353.JPG<br>127.11 KB</a><div class='inv'><br><a href='./images/20051007/IMG_0353.JPG' ALT='IMG_0353.JPG'>IMG_0353.JPG</a></div></td>
<td><A ID='IMG_0357.JPG' href='pilbara.php?fileId=IMG_0357.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051007/IMG_0357.JPG' ALT='IMG_0357.JPG'><BR>IMG_0357.JPG<br>120.34 KB</a><div class='inv'><br><a href='./images/20051007/IMG_0357.JPG' ALT='IMG_0357.JPG'>IMG_0357.JPG</a></div></td>
<td><A ID='IMG_0359.JPG' href='pilbara.php?fileId=IMG_0359.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051007/IMG_0359.JPG' ALT='IMG_0359.JPG'><BR>IMG_0359.JPG<br>63.29 KB</a><div class='inv'><br><a href='./images/20051007/IMG_0359.JPG' ALT='IMG_0359.JPG'>IMG_0359.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_0360.JPG' href='pilbara.php?fileId=IMG_0360.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051007/IMG_0360.JPG' ALT='IMG_0360.JPG'><BR>IMG_0360.JPG<br>65.84 KB</a><div class='inv'><br><a href='./images/20051007/IMG_0360.JPG' ALT='IMG_0360.JPG'>IMG_0360.JPG</a></div></td>
<td><A ID='IMG_0364.JPG' href='pilbara.php?fileId=IMG_0364.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051007/IMG_0364.JPG' ALT='IMG_0364.JPG'><BR>IMG_0364.JPG<br>111.88 KB</a><div class='inv'><br><a href='./images/20051007/IMG_0364.JPG' ALT='IMG_0364.JPG'>IMG_0364.JPG</a></div></td>
<td><A ID='IMG_0366.JPG' href='pilbara.php?fileId=IMG_0366.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051007/IMG_0366.JPG' ALT='IMG_0366.JPG'><BR>IMG_0366.JPG<br>133.71 KB</a><div class='inv'><br><a href='./images/20051007/IMG_0366.JPG' ALT='IMG_0366.JPG'>IMG_0366.JPG</a></div></td>
<td><A ID='IMG_0376.JPG' href='pilbara.php?fileId=IMG_0376.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051007/IMG_0376.JPG' ALT='IMG_0376.JPG'><BR>IMG_0376.JPG<br>86.75 KB</a><div class='inv'><br><a href='./images/20051007/IMG_0376.JPG' ALT='IMG_0376.JPG'>IMG_0376.JPG</a></div></td>
<td><A ID='IMG_0382.JPG' href='pilbara.php?fileId=IMG_0382.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051007/IMG_0382.JPG' ALT='IMG_0382.JPG'><BR>IMG_0382.JPG<br>72.65 KB</a><div class='inv'><br><a href='./images/20051007/IMG_0382.JPG' ALT='IMG_0382.JPG'>IMG_0382.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_0393.JPG' href='pilbara.php?fileId=IMG_0393.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051007/IMG_0393.JPG' ALT='IMG_0393.JPG'><BR>IMG_0393.JPG<br>92.24 KB</a><div class='inv'><br><a href='./images/20051007/IMG_0393.JPG' ALT='IMG_0393.JPG'>IMG_0393.JPG</a></div></td>
<td><A ID='IMG_0398.JPG' href='pilbara.php?fileId=IMG_0398.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051007/IMG_0398.JPG' ALT='IMG_0398.JPG'><BR>IMG_0398.JPG<br>52.54 KB</a><div class='inv'><br><a href='./images/20051007/IMG_0398.JPG' ALT='IMG_0398.JPG'>IMG_0398.JPG</a></div></td>
<td><A ID='IMG_0404.JPG' href='pilbara.php?fileId=IMG_0404.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051007/IMG_0404.JPG' ALT='IMG_0404.JPG'><BR>IMG_0404.JPG<br>68.51 KB</a><div class='inv'><br><a href='./images/20051007/IMG_0404.JPG' ALT='IMG_0404.JPG'>IMG_0404.JPG</a></div></td>
<td><A ID='IMG_0407.JPG' href='pilbara.php?fileId=IMG_0407.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051007/IMG_0407.JPG' ALT='IMG_0407.JPG'><BR>IMG_0407.JPG<br>71.9 KB</a><div class='inv'><br><a href='./images/20051007/IMG_0407.JPG' ALT='IMG_0407.JPG'>IMG_0407.JPG</a></div></td>
<td><A ID='IMG_0408.JPG' href='pilbara.php?fileId=IMG_0408.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051007/IMG_0408.JPG' ALT='IMG_0408.JPG'><BR>IMG_0408.JPG<br>75.92 KB</a><div class='inv'><br><a href='./images/20051007/IMG_0408.JPG' ALT='IMG_0408.JPG'>IMG_0408.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_0409.JPG' href='pilbara.php?fileId=IMG_0409.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051007/IMG_0409.JPG' ALT='IMG_0409.JPG'><BR>IMG_0409.JPG<br>61.76 KB</a><div class='inv'><br><a href='./images/20051007/IMG_0409.JPG' ALT='IMG_0409.JPG'>IMG_0409.JPG</a></div></td>
<td><A ID='IMG_0414.JPG' href='pilbara.php?fileId=IMG_0414.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051007/IMG_0414.JPG' ALT='IMG_0414.JPG'><BR>IMG_0414.JPG<br>69.79 KB</a><div class='inv'><br><a href='./images/20051007/IMG_0414.JPG' ALT='IMG_0414.JPG'>IMG_0414.JPG</a></div></td>
<td><A ID='IMG_0417.JPG' href='pilbara.php?fileId=IMG_0417.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051007/IMG_0417.JPG' ALT='IMG_0417.JPG'><BR>IMG_0417.JPG<br>53.85 KB</a><div class='inv'><br><a href='./images/20051007/IMG_0417.JPG' ALT='IMG_0417.JPG'>IMG_0417.JPG</a></div></td>
<td><A ID='IMG_0422.JPG' href='pilbara.php?fileId=IMG_0422.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051007/IMG_0422.JPG' ALT='IMG_0422.JPG'><BR>IMG_0422.JPG<br>120 KB</a><div class='inv'><br><a href='./images/20051007/IMG_0422.JPG' ALT='IMG_0422.JPG'>IMG_0422.JPG</a></div></td>
<td><A ID='IMG_0426.JPG' href='pilbara.php?fileId=IMG_0426.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051007/IMG_0426.JPG' ALT='IMG_0426.JPG'><BR>IMG_0426.JPG<br>97.54 KB</a><div class='inv'><br><a href='./images/20051007/IMG_0426.JPG' ALT='IMG_0426.JPG'>IMG_0426.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_0427.JPG' href='pilbara.php?fileId=IMG_0427.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051007/IMG_0427.JPG' ALT='IMG_0427.JPG'><BR>IMG_0427.JPG<br>114.98 KB</a><div class='inv'><br><a href='./images/20051007/IMG_0427.JPG' ALT='IMG_0427.JPG'>IMG_0427.JPG</a></div></td>
<td><A ID='IMG_0432.JPG' href='pilbara.php?fileId=IMG_0432.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051007/IMG_0432.JPG' ALT='IMG_0432.JPG'><BR>IMG_0432.JPG<br>100.81 KB</a><div class='inv'><br><a href='./images/20051007/IMG_0432.JPG' ALT='IMG_0432.JPG'>IMG_0432.JPG</a></div></td>
<td><A ID='IMG_0435.JPG' href='pilbara.php?fileId=IMG_0435.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051007/IMG_0435.JPG' ALT='IMG_0435.JPG'><BR>IMG_0435.JPG<br>68.6 KB</a><div class='inv'><br><a href='./images/20051007/IMG_0435.JPG' ALT='IMG_0435.JPG'>IMG_0435.JPG</a></div></td>
<td><A ID='IMG_0436.JPG' href='pilbara.php?fileId=IMG_0436.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051007/IMG_0436.JPG' ALT='IMG_0436.JPG'><BR>IMG_0436.JPG<br>133.43 KB</a><div class='inv'><br><a href='./images/20051007/IMG_0436.JPG' ALT='IMG_0436.JPG'>IMG_0436.JPG</a></div></td>
<td><A ID='IMG_0441.JPG' href='pilbara.php?fileId=IMG_0441.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051007/IMG_0441.JPG' ALT='IMG_0441.JPG'><BR>IMG_0441.JPG<br>136.74 KB</a><div class='inv'><br><a href='./images/20051007/IMG_0441.JPG' ALT='IMG_0441.JPG'>IMG_0441.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_0442.JPG' href='pilbara.php?fileId=IMG_0442.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051007/IMG_0442.JPG' ALT='IMG_0442.JPG'><BR>IMG_0442.JPG<br>127.82 KB</a><div class='inv'><br><a href='./images/20051007/IMG_0442.JPG' ALT='IMG_0442.JPG'>IMG_0442.JPG</a></div></td>
<td><A ID='IMG_0444.JPG' href='pilbara.php?fileId=IMG_0444.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051007/IMG_0444.JPG' ALT='IMG_0444.JPG'><BR>IMG_0444.JPG<br>132.55 KB</a><div class='inv'><br><a href='./images/20051007/IMG_0444.JPG' ALT='IMG_0444.JPG'>IMG_0444.JPG</a></div></td>
<td><A ID='IMG_0447.JPG' href='pilbara.php?fileId=IMG_0447.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051007/IMG_0447.JPG' ALT='IMG_0447.JPG'><BR>IMG_0447.JPG<br>114.68 KB</a><div class='inv'><br><a href='./images/20051007/IMG_0447.JPG' ALT='IMG_0447.JPG'>IMG_0447.JPG</a></div></td>
<td><A ID='IMG_0448.JPG' href='pilbara.php?fileId=IMG_0448.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051007/IMG_0448.JPG' ALT='IMG_0448.JPG'><BR>IMG_0448.JPG<br>85.95 KB</a><div class='inv'><br><a href='./images/20051007/IMG_0448.JPG' ALT='IMG_0448.JPG'>IMG_0448.JPG</a></div></td>
<td><A ID='IMG_0449.JPG' href='pilbara.php?fileId=IMG_0449.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051007/IMG_0449.JPG' ALT='IMG_0449.JPG'><BR>IMG_0449.JPG<br>76.82 KB</a><div class='inv'><br><a href='./images/20051007/IMG_0449.JPG' ALT='IMG_0449.JPG'>IMG_0449.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_0455.JPG' href='pilbara.php?fileId=IMG_0455.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051007/IMG_0455.JPG' ALT='IMG_0455.JPG'><BR>IMG_0455.JPG<br>121.81 KB</a><div class='inv'><br><a href='./images/20051007/IMG_0455.JPG' ALT='IMG_0455.JPG'>IMG_0455.JPG</a></div></td>
<td><A ID='IMG_0456.JPG' href='pilbara.php?fileId=IMG_0456.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051007/IMG_0456.JPG' ALT='IMG_0456.JPG'><BR>IMG_0456.JPG<br>103.89 KB</a><div class='inv'><br><a href='./images/20051007/IMG_0456.JPG' ALT='IMG_0456.JPG'>IMG_0456.JPG</a></div></td>
<td><A ID='IMG_0464.JPG' href='pilbara.php?fileId=IMG_0464.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051007/IMG_0464.JPG' ALT='IMG_0464.JPG'><BR>IMG_0464.JPG<br>102.81 KB</a><div class='inv'><br><a href='./images/20051007/IMG_0464.JPG' ALT='IMG_0464.JPG'>IMG_0464.JPG</a></div></td>
<td><A ID='IMG_0465.JPG' href='pilbara.php?fileId=IMG_0465.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051007/IMG_0465.JPG' ALT='IMG_0465.JPG'><BR>IMG_0465.JPG<br>102.97 KB</a><div class='inv'><br><a href='./images/20051007/IMG_0465.JPG' ALT='IMG_0465.JPG'>IMG_0465.JPG</a></div></td>
<td><A ID='IMG_0467.JPG' href='pilbara.php?fileId=IMG_0467.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051007/IMG_0467.JPG' ALT='IMG_0467.JPG'><BR>IMG_0467.JPG<br>44.59 KB</a><div class='inv'><br><a href='./images/20051007/IMG_0467.JPG' ALT='IMG_0467.JPG'>IMG_0467.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_0473.JPG' href='pilbara.php?fileId=IMG_0473.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051007/IMG_0473.JPG' ALT='IMG_0473.JPG'><BR>IMG_0473.JPG<br>108.68 KB</a><div class='inv'><br><a href='./images/20051007/IMG_0473.JPG' ALT='IMG_0473.JPG'>IMG_0473.JPG</a></div></td>
<td><A ID='IMG_0475.JPG' href='pilbara.php?fileId=IMG_0475.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051007/IMG_0475.JPG' ALT='IMG_0475.JPG'><BR>IMG_0475.JPG<br>146.21 KB</a><div class='inv'><br><a href='./images/20051007/IMG_0475.JPG' ALT='IMG_0475.JPG'>IMG_0475.JPG</a></div></td>
<td><A ID='IMG_0476.JPG' href='pilbara.php?fileId=IMG_0476.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051007/IMG_0476.JPG' ALT='IMG_0476.JPG'><BR>IMG_0476.JPG<br>86.36 KB</a><div class='inv'><br><a href='./images/20051007/IMG_0476.JPG' ALT='IMG_0476.JPG'>IMG_0476.JPG</a></div></td>
<td><A ID='IMG_0478.JPG' href='pilbara.php?fileId=IMG_0478.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051007/IMG_0478.JPG' ALT='IMG_0478.JPG'><BR>IMG_0478.JPG<br>114.68 KB</a><div class='inv'><br><a href='./images/20051007/IMG_0478.JPG' ALT='IMG_0478.JPG'>IMG_0478.JPG</a></div></td>
<td><A ID='IMG_0481.JPG' href='pilbara.php?fileId=IMG_0481.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051007/IMG_0481.JPG' ALT='IMG_0481.JPG'><BR>IMG_0481.JPG<br>72.77 KB</a><div class='inv'><br><a href='./images/20051007/IMG_0481.JPG' ALT='IMG_0481.JPG'>IMG_0481.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_0483.JPG' href='pilbara.php?fileId=IMG_0483.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051007/IMG_0483.JPG' ALT='IMG_0483.JPG'><BR>IMG_0483.JPG<br>72.36 KB</a><div class='inv'><br><a href='./images/20051007/IMG_0483.JPG' ALT='IMG_0483.JPG'>IMG_0483.JPG</a></div></td>
<td><A ID='IMG_0486.JPG' href='pilbara.php?fileId=IMG_0486.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051007/IMG_0486.JPG' ALT='IMG_0486.JPG'><BR>IMG_0486.JPG<br>116.38 KB</a><div class='inv'><br><a href='./images/20051007/IMG_0486.JPG' ALT='IMG_0486.JPG'>IMG_0486.JPG</a></div></td>
<td><A ID='IMG_0487.JPG' href='pilbara.php?fileId=IMG_0487.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051007/IMG_0487.JPG' ALT='IMG_0487.JPG'><BR>IMG_0487.JPG<br>114.37 KB</a><div class='inv'><br><a href='./images/20051007/IMG_0487.JPG' ALT='IMG_0487.JPG'>IMG_0487.JPG</a></div></td>
<td><A ID='IMG_0490.JPG' href='pilbara.php?fileId=IMG_0490.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051007/IMG_0490.JPG' ALT='IMG_0490.JPG'><BR>IMG_0490.JPG<br>106.77 KB</a><div class='inv'><br><a href='./images/20051007/IMG_0490.JPG' ALT='IMG_0490.JPG'>IMG_0490.JPG</a></div></td>
<td><A ID='IMG_0494.JPG' href='pilbara.php?fileId=IMG_0494.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051007/IMG_0494.JPG' ALT='IMG_0494.JPG'><BR>IMG_0494.JPG<br>96.69 KB</a><div class='inv'><br><a href='./images/20051007/IMG_0494.JPG' ALT='IMG_0494.JPG'>IMG_0494.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_0496.JPG' href='pilbara.php?fileId=IMG_0496.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051007/IMG_0496.JPG' ALT='IMG_0496.JPG'><BR>IMG_0496.JPG<br>130.54 KB</a><div class='inv'><br><a href='./images/20051007/IMG_0496.JPG' ALT='IMG_0496.JPG'>IMG_0496.JPG</a></div></td>
<td><A ID='IMG_0498.JPG' href='pilbara.php?fileId=IMG_0498.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051007/IMG_0498.JPG' ALT='IMG_0498.JPG'><BR>IMG_0498.JPG<br>95.06 KB</a><div class='inv'><br><a href='./images/20051007/IMG_0498.JPG' ALT='IMG_0498.JPG'>IMG_0498.JPG</a></div></td>
<td><A ID='IMG_0499.JPG' href='pilbara.php?fileId=IMG_0499.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051007/IMG_0499.JPG' ALT='IMG_0499.JPG'><BR>IMG_0499.JPG<br>112.04 KB</a><div class='inv'><br><a href='./images/20051007/IMG_0499.JPG' ALT='IMG_0499.JPG'>IMG_0499.JPG</a></div></td>
<td><A ID='IMG_0505.JPG' href='pilbara.php?fileId=IMG_0505.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051007/IMG_0505.JPG' ALT='IMG_0505.JPG'><BR>IMG_0505.JPG<br>83.7 KB</a><div class='inv'><br><a href='./images/20051007/IMG_0505.JPG' ALT='IMG_0505.JPG'>IMG_0505.JPG</a></div></td>
<td><A ID='IMG_0510.JPG' href='pilbara.php?fileId=IMG_0510.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051007/IMG_0510.JPG' ALT='IMG_0510.JPG'><BR>IMG_0510.JPG<br>81.67 KB</a><div class='inv'><br><a href='./images/20051007/IMG_0510.JPG' ALT='IMG_0510.JPG'>IMG_0510.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_0514.JPG' href='pilbara.php?fileId=IMG_0514.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051007/IMG_0514.JPG' ALT='IMG_0514.JPG'><BR>IMG_0514.JPG<br>115.31 KB</a><div class='inv'><br><a href='./images/20051007/IMG_0514.JPG' ALT='IMG_0514.JPG'>IMG_0514.JPG</a></div></td>
<td><A ID='IMG_0518.JPG' href='pilbara.php?fileId=IMG_0518.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051007/IMG_0518.JPG' ALT='IMG_0518.JPG'><BR>IMG_0518.JPG<br>113.61 KB</a><div class='inv'><br><a href='./images/20051007/IMG_0518.JPG' ALT='IMG_0518.JPG'>IMG_0518.JPG</a></div></td>
<td><A ID='IMG_0520.JPG' href='pilbara.php?fileId=IMG_0520.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051007/IMG_0520.JPG' ALT='IMG_0520.JPG'><BR>IMG_0520.JPG<br>116.53 KB</a><div class='inv'><br><a href='./images/20051007/IMG_0520.JPG' ALT='IMG_0520.JPG'>IMG_0520.JPG</a></div></td>
<td><A ID='IMG_0523.JPG' href='pilbara.php?fileId=IMG_0523.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051007/IMG_0523.JPG' ALT='IMG_0523.JPG'><BR>IMG_0523.JPG<br>97.14 KB</a><div class='inv'><br><a href='./images/20051007/IMG_0523.JPG' ALT='IMG_0523.JPG'>IMG_0523.JPG</a></div></td>
<td><A ID='IMG_0527.JPG' href='pilbara.php?fileId=IMG_0527.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051007/IMG_0527.JPG' ALT='IMG_0527.JPG'><BR>IMG_0527.JPG<br>96.01 KB</a><div class='inv'><br><a href='./images/20051007/IMG_0527.JPG' ALT='IMG_0527.JPG'>IMG_0527.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_0532.JPG' href='pilbara.php?fileId=IMG_0532.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051007/IMG_0532.JPG' ALT='IMG_0532.JPG'><BR>IMG_0532.JPG<br>72.51 KB</a><div class='inv'><br><a href='./images/20051007/IMG_0532.JPG' ALT='IMG_0532.JPG'>IMG_0532.JPG</a></div></td>
<td><A ID='IMG_0536.JPG' href='pilbara.php?fileId=IMG_0536.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051007/IMG_0536.JPG' ALT='IMG_0536.JPG'><BR>IMG_0536.JPG<br>80.5 KB</a><div class='inv'><br><a href='./images/20051007/IMG_0536.JPG' ALT='IMG_0536.JPG'>IMG_0536.JPG</a></div></td>
<td><A ID='IMG_0537.JPG' href='pilbara.php?fileId=IMG_0537.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051007/IMG_0537.JPG' ALT='IMG_0537.JPG'><BR>IMG_0537.JPG<br>115.84 KB</a><div class='inv'><br><a href='./images/20051007/IMG_0537.JPG' ALT='IMG_0537.JPG'>IMG_0537.JPG</a></div></td>
<td><A ID='IMG_0540.JPG' href='pilbara.php?fileId=IMG_0540.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051007/IMG_0540.JPG' ALT='IMG_0540.JPG'><BR>IMG_0540.JPG<br>112 KB</a><div class='inv'><br><a href='./images/20051007/IMG_0540.JPG' ALT='IMG_0540.JPG'>IMG_0540.JPG</a></div></td>
<td><A ID='IMG_0541.JPG' href='pilbara.php?fileId=IMG_0541.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051007/IMG_0541.JPG' ALT='IMG_0541.JPG'><BR>IMG_0541.JPG<br>118.44 KB</a><div class='inv'><br><a href='./images/20051007/IMG_0541.JPG' ALT='IMG_0541.JPG'>IMG_0541.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_0548.JPG' href='pilbara.php?fileId=IMG_0548.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051007/IMG_0548.JPG' ALT='IMG_0548.JPG'><BR>IMG_0548.JPG<br>101.87 KB</a><div class='inv'><br><a href='./images/20051007/IMG_0548.JPG' ALT='IMG_0548.JPG'>IMG_0548.JPG</a></div></td>
<td><A ID='IMG_0557.JPG' href='pilbara.php?fileId=IMG_0557.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051007/IMG_0557.JPG' ALT='IMG_0557.JPG'><BR>IMG_0557.JPG<br>109.17 KB</a><div class='inv'><br><a href='./images/20051007/IMG_0557.JPG' ALT='IMG_0557.JPG'>IMG_0557.JPG</a></div></td>
<td><A ID='IMG_0562.JPG' href='pilbara.php?fileId=IMG_0562.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051007/IMG_0562.JPG' ALT='IMG_0562.JPG'><BR>IMG_0562.JPG<br>75.51 KB</a><div class='inv'><br><a href='./images/20051007/IMG_0562.JPG' ALT='IMG_0562.JPG'>IMG_0562.JPG</a></div></td>
<td><A ID='IMG_0563.JPG' href='pilbara.php?fileId=IMG_0563.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051007/IMG_0563.JPG' ALT='IMG_0563.JPG'><BR>IMG_0563.JPG<br>122.05 KB</a><div class='inv'><br><a href='./images/20051007/IMG_0563.JPG' ALT='IMG_0563.JPG'>IMG_0563.JPG</a></div></td>
<td><A ID='IMG_0564.JPG' href='pilbara.php?fileId=IMG_0564.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051007/IMG_0564.JPG' ALT='IMG_0564.JPG'><BR>IMG_0564.JPG<br>96.39 KB</a><div class='inv'><br><a href='./images/20051007/IMG_0564.JPG' ALT='IMG_0564.JPG'>IMG_0564.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_0567.JPG' href='pilbara.php?fileId=IMG_0567.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051007/IMG_0567.JPG' ALT='IMG_0567.JPG'><BR>IMG_0567.JPG<br>88.65 KB</a><div class='inv'><br><a href='./images/20051007/IMG_0567.JPG' ALT='IMG_0567.JPG'>IMG_0567.JPG</a></div></td>
<td><A ID='IMG_0568.JPG' href='pilbara.php?fileId=IMG_0568.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051007/IMG_0568.JPG' ALT='IMG_0568.JPG'><BR>IMG_0568.JPG<br>61.83 KB</a><div class='inv'><br><a href='./images/20051007/IMG_0568.JPG' ALT='IMG_0568.JPG'>IMG_0568.JPG</a></div></td>
<td><A ID='IMG_0571.JPG' href='pilbara.php?fileId=IMG_0571.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051007/IMG_0571.JPG' ALT='IMG_0571.JPG'><BR>IMG_0571.JPG<br>95.48 KB</a><div class='inv'><br><a href='./images/20051007/IMG_0571.JPG' ALT='IMG_0571.JPG'>IMG_0571.JPG</a></div></td>
<td><A ID='IMG_0573.JPG' href='pilbara.php?fileId=IMG_0573.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051007/IMG_0573.JPG' ALT='IMG_0573.JPG'><BR>IMG_0573.JPG<br>87.69 KB</a><div class='inv'><br><a href='./images/20051007/IMG_0573.JPG' ALT='IMG_0573.JPG'>IMG_0573.JPG</a></div></td>
<td><A ID='IMG_0579.JPG' href='pilbara.php?fileId=IMG_0579.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051007/IMG_0579.JPG' ALT='IMG_0579.JPG'><BR>IMG_0579.JPG<br>83.06 KB</a><div class='inv'><br><a href='./images/20051007/IMG_0579.JPG' ALT='IMG_0579.JPG'>IMG_0579.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_0581.JPG' href='pilbara.php?fileId=IMG_0581.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051007/IMG_0581.JPG' ALT='IMG_0581.JPG'><BR>IMG_0581.JPG<br>53.27 KB</a><div class='inv'><br><a href='./images/20051007/IMG_0581.JPG' ALT='IMG_0581.JPG'>IMG_0581.JPG</a></div></td>
<td><A ID='IMG_0584.JPG' href='pilbara.php?fileId=IMG_0584.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051007/IMG_0584.JPG' ALT='IMG_0584.JPG'><BR>IMG_0584.JPG<br>87.91 KB</a><div class='inv'><br><a href='./images/20051007/IMG_0584.JPG' ALT='IMG_0584.JPG'>IMG_0584.JPG</a></div></td>
<td><A ID='IMG_0586.JPG' href='pilbara.php?fileId=IMG_0586.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051007/IMG_0586.JPG' ALT='IMG_0586.JPG'><BR>IMG_0586.JPG<br>108.1 KB</a><div class='inv'><br><a href='./images/20051007/IMG_0586.JPG' ALT='IMG_0586.JPG'>IMG_0586.JPG</a></div></td>
<td><A ID='IMG_0587.JPG' href='pilbara.php?fileId=IMG_0587.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051007/IMG_0587.JPG' ALT='IMG_0587.JPG'><BR>IMG_0587.JPG<br>86.37 KB</a><div class='inv'><br><a href='./images/20051007/IMG_0587.JPG' ALT='IMG_0587.JPG'>IMG_0587.JPG</a></div></td>
<td><A ID='IMG_0590.JPG' href='pilbara.php?fileId=IMG_0590.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051007/IMG_0590.JPG' ALT='IMG_0590.JPG'><BR>IMG_0590.JPG<br>53.43 KB</a><div class='inv'><br><a href='./images/20051007/IMG_0590.JPG' ALT='IMG_0590.JPG'>IMG_0590.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_0593.JPG' href='pilbara.php?fileId=IMG_0593.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051007/IMG_0593.JPG' ALT='IMG_0593.JPG'><BR>IMG_0593.JPG<br>101.23 KB</a><div class='inv'><br><a href='./images/20051007/IMG_0593.JPG' ALT='IMG_0593.JPG'>IMG_0593.JPG</a></div></td>
<td><A ID='IMG_0596.JPG' href='pilbara.php?fileId=IMG_0596.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051007/IMG_0596.JPG' ALT='IMG_0596.JPG'><BR>IMG_0596.JPG<br>87.78 KB</a><div class='inv'><br><a href='./images/20051007/IMG_0596.JPG' ALT='IMG_0596.JPG'>IMG_0596.JPG</a></div></td>
<td><A ID='IMG_0597.JPG' href='pilbara.php?fileId=IMG_0597.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051007/IMG_0597.JPG' ALT='IMG_0597.JPG'><BR>IMG_0597.JPG<br>76.99 KB</a><div class='inv'><br><a href='./images/20051007/IMG_0597.JPG' ALT='IMG_0597.JPG'>IMG_0597.JPG</a></div></td>
<td><A ID='IMG_0597_crop.JPG' href='pilbara.php?fileId=IMG_0597_crop.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20051007/IMG_0597_crop.JPG' ALT='IMG_0597_crop.JPG'><BR>IMG_0597_crop.JPG<br>94.15 KB</a><div class='inv'><br><a href='./images/20051007/IMG_0597_crop.JPG' ALT='IMG_0597_crop.JPG'>IMG_0597_crop.JPG</a></div></td>
</tr>
</table>	</div>
</div>
</body>
</html>