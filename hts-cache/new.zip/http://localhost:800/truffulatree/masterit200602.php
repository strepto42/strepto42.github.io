<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - February 2006 - Q&A letters</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="Q&A letters">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="Q&A letters" href='masterit200601.php'>January 2006</a></li>
<li><div class='activemenu'>February 2006</div></li>
<li><a title="Q&A letters" href='masterit200603.php'>March 2006</a></li>
<li><a title="Q&A letters" href='masterit200604.php'>April 2006</a></li>
<li><a title="Q&A letters" href='masterit200605.php'>May 2006</a></li>
<li><a title="Q&A letters" href='masterit200606.php'>June 2006</a></li>
<li><a title="Q&A letters" href='masterit200607.php'>July 2006</a></li>
<li><a title="Q&A letters" href='masterit200608.php'>August 2006</a></li>
<li><a title="Q&A letters" href='masterit200609.php'>September 2006</a></li>
<li><a title="Q&A letters" href='masterit200610.php'>October 2006</a></li>
<li><a title="Q&A letters" href='masterit200611.php'>November 2006</a></li>
<li><a title="Q&A letters" href='masterit200612.php'>December 2006</a></li>
<li> </li><br><li>Or go back to:</li><li><a title='Q&A/MasterIT letters from 2006' href="masterit2006.php">2006 archive</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>February 2006</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Mark's writing' href="written.php">Professional Writing</a> > <a title='My weekly Q&A column in The Australian' href="masterIT.php">MasterIT</a> > <a title='Q&A/MasterIT letters from 2006' href="masterit2006.php">2006 archive</a> > <a title='Q&A letters' href="masterit200602.php">February 2006</a>
<br><br>		<br>
<h2>7/2/06</h2><br>
<b>I spoiled myself with a shiny new laptop for Christmas. It's fantastic, and the display is glossy and very clear. Unfortunately it's also now covered in fingerprints, after a photo-viewing session with some relative's darling children. I'm quite paranoid about damaging the screen, and was wondering what the best way is to clean it?</b><br>
<br>
I'll avoid starting the new year with a rave about screen touchers (but this link sums up my attitude - tinyurl.com/8owpz). Thankfully though, it's not terribly hard to clean modern LCD screens, especially the glossy type.<br>
<br>
All you need is the right sort of cloth, some cleaning solution, and a little patience. <br>
<br>
The cloth needs to be very soft, completely non-abrasive and lint free; most people use a so-called microfibre cloth. You can buy them online, and from many computer outlets. If you wear glasses, you may already even have one, as those little cleaning cloths you get with your specs are the same stuff, and most optometrists will sell you one very cheaply.<br>
<br>
As far as cleaning fluid goes, there are all sorts of recipes and concoctions online. The simplest, and best option is a solution of half water and half isopropyl alcohol (or even methylated spirits at a pinch), however, for dust and small stains (like cough marks) simply using a damp cloth first, and then a gentle hand will work just fine.<br>
<br>
Fingerprints are different though; they're oily, and therefore a little harder to shift. A tiny amount of detergent in the water may help, and the alcohol will assist with evaporation and prevent streaks.<br>
<br>
Just work slowly, gently and methodically and you'll have the screen back to showroom condition in no time.<br>
<br>
Once you're done, remember to clean and dry your cloth with soap and water to remove any grit that has accumulated. If you don't, your screen cleaning experiences will eventually become screen scratching experiences, which are altogether less pleasurable.<br>
<br>
Finally, a hard learned footnote from personal experience - never, never sit downwind of a great Aussie barbeque with your precious laptop. Tiny grease particles will coat your screen, and it will take a lot of work (and cursing) to get it clean again. <br>
<br>
<br>
<h2>14/2/06</h2><br>
<b>I would like to know if it would it be possible to set up/Windows Explorer in such a manner that, when executed, it displays not only the directory structure but also, in the same pane, everything that is under a given directory (including regular files). If it is not possible to have such a view by altering the standard behaviour of Windows Explorer, are you aware of any replacement?</b><br>
<br>
As far as I know, it's not possible to do this with Windows Explorer. The only files which it will display in this fashion are ZIP files (if you have XP), which it treats as folders.<br>
<br>
You may be able to find some third party software to do it, however, I don't know of any programs that work in the way you describe. Many use a system where the files and folders are displayed in the same pane, but not in a tree; it's essentially like the right hand pane of explorer anyway, and that kind of defeats the purpose.<br>
<br>
Two programs that fall into this category are Diropus (www.gpsoft.com.au) and Total Commander (www.ghisler.com). Both offer all sorts of interesting bells and whistles, but are also not free.<br>
<br>
The thing about showing ALL files in the tree is that sometimes it's a pretty cumbersome way to do things. If you have a folder with hundreds of files, the tree becomes enormous, and I'd say this is pretty much why no program seems to support this view.<br>
<br>
<br>
<b>Can you explain why GoogleTalk using computer to computer is so much better to use than other VOIP sites such as Yahoo and MSN Messenger? No special tuning of the microphone or speakers is required and there is no feedback despite using the built in microphone in my older laptop and stand alone speakers. I can walk around the room talking without the listener having any difficulty hearing even though he can tell that I am some distance from my computer.</b><br>
<br>
In short, it's just a better piece of programming. More modern VOIP programs (like Skype and Googletalk) use all sorts of clever tricks to boost the level of audio, cancel echoes and feedback, and generally improve the quality of the sound.<br>
<br>
More advanced compression techniques also let the program send higher quality sound over your internet connection. It's basically just a lot of tricky maths.<br>
<br>
By contrast, MSN messenger is a fairly primitive program, and Microsoft are a bit behind the game.<br>
<br>
<br>
<h2>21/2/06</h2><br>
<b>We've had a small family website for a while, hosted by my ISP. Some of my more distant rellies recently set up their own web site, but they have their own domain name (their family name as it happens). I'd love to do the same thing, but have no idea where to start. How does one acquire a "dot com", and is it expensive?</b><br>
<br>
Registering your own domain is really easy; often the hardest part is agreeing on the name itself, and finding one that hasn't already been taken.<br>
<br>
Domain ownership is not permanent - you buy the name for so many years, after which you have the option of renewing. There are different rules (and prices) for different "top level" domains (meaning the suffix grouping - like .com and .org). Plain "dot coms" are available to anyone; a .com.au is more expensive and harder to acquire, as it needs to be associated with a business.<br>
<br>
Once you've picked out your potential name, you need to find a registrar (a company through which you register your domain). There are scores of these around, and prices vary, so shop around. I've used netregistry.com.au in recent years - a .com there currently costs about $AU20 per year.<br>
<br>
All you have to do now is fill out a few forms online, feed in your credit card number, and presto - you have your domain. Bear in mind that that the information you put into these forms will be potentially visible to anyone - so be honest, but also be mindful of which addresses you use (both physical and email).<br>
<br>
Now comes the tricky part - you need tie the domain to your website, and there are two approaches. You can set purchase your own hosting and move your web pages there, or you make the domain "point" to your existing free ISP website.<br>
<br>
There are advantages and disadvantages to both strategies. If you go with your own hosting, it will cost you money (whereas your ISP gives you hosting for free), but visitors to your site will always see your domain name in the URL. You'll also be able to set up multiple mailboxes.<br>
<br>
If you set up a pointer service, a visitor to your domain gets redirected to your ISP's hosted site. This is easier, and free, but once redirected a visitor won't see your domain in the URL any more. A good free redirection service is zoneedit.com.<br>
<br>
Finally, for a more extensive overview of this whole tangled mess, check out http://tinyurl.com/bsskx.<br>
<br>
<br>
<h2>28/2/06</h2><br>
<b>Is it possible to network a Mac running OSX 10.4 with a PC running Windows XP to share files using a broadband router and standard Ethernet cables?</b><br>
<br>
Absolutely. All you need to do is hook up the appropriate cables, make sure the computers can talk to each other on the network, and then set up the file sharing on each computer (sounds easy, hey!)<br>
<br>
So, to avoid later hair-tearing, our first step is to check that the computers can indeed talk to each other.<br>
<br>
On the Mac, open the Network Utility program and check the Info tab. Make a note of the IP address (four numbers with dots in between).<br>
<br>
Next, on the PC, open a command prompt, type "ipconfig" and hit Enter. This will reveal the PC's IP address. While we're here, type in "ping" followed by the Mac's address (that we wrote down above).<br>
<br>
Now, hop back onto the Mac, open your Applications folder, then the Utilities folder, then the Network Utility program. Now go to the Ping tab, enter the IP address you wrote down for the PC, and click Ping.<br>
<br>
If the pinging fails, you may need to disable any firewalls you are using, or at least allow an exception for file sharing. This is fine, as in most cases as the Internet router acts as a firewall of it's own, but if you're unsure of how well protected you are and would like a little peace of mind, visit the excellent "ShieldsUP!" page at www.grc.com.<br>
<br>
Assuming all is well, now you need to specifically share a folder on your Windows machine, in order for the Mac to be able to see it. Once that's done you should be able to connect to the shared folder from the Mac, using "Connect to server" in the finder's "Go" menu.<br>
<br>
There is a good step-by-step tutorial at joelshoemaker.com/computer/mac/wxpfs.html.<br>
<br>
<br>
<b>More on displaying all files in Windows Explorer</b><br>
<br>
A couple of weeks ago, we discussed the possibility of showing not only folders, but files as well in the tree view of Windows Explorer. Whilst not possible in Explorer, a kind reader has whipped up a program to do it, which can be found at tinyurl.com/n9l92.<br>
<br>
Further research has also revealed that Directory Opus, one of the programs mentioned in the column, is indeed capable of providing the extended display (at the time I couldn't find the option).<br>
<br>
To enable the extended view, open a new explorer-style lister, then select "Flat view->Grouped" from the View menu.<br>
<br>
<i><p>Did the information on this page help you? Entertain you? Bore you? <a href="contact.php?subject=MasterIT">Drop me a line</a>.</p>

<p>If you're feeling particularly generous, you can even <a href="buypics.php">click here to send me some dot-com riches</a>. Think of it as online busking.</i></p>
	</div>
</div>
</body>
</html>