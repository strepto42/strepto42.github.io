<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - 29/4/2005 - Greetings from a Bum</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="Greetings from a Bum">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><div class='activemenu'>29/4/2005</div></li>
<li><a title="Onward" href='onward.php'>2/5/2005</a></li>
<li><a title="It's a tough life (pt 1: Bundaberg, Agnes Water and 1770)" href='itsatoughlife1.php'>17/5/2005</a></li>
<li><a title="It's a tough life (pt 2: Rockhampton, Emu Park and Great Keppel Island)" href='itsatoughlife2.php'>23/5/2005</a></li>
<li><a title="There and Back Again - a Yo-yo's Tale" href='thereandbackagain.php'>18/6/2005</a></li>
<li><a title="Platypi and Grey Nomads" href='platypiandgreynomads.php'>24/6/2005</a></li>
<li><a title="Blowing Bubbles in a Watery Tomb" href='blowingbubbles.php'>1/7/2005</a></li>
<li><a title="Pieces of History" href='piecesofhistory.php'>8/7/2005</a></li>
<li><a title="Walks and Waterfalls" href='walksandwaterfalls.php'>15/7/2005</a></li>
<li><a title="Mission to Tribulation" href='missiontotribulation.php'>22/7/2005</a></li>
<li><a title="Levity, Limestone and Lava" href='levitylimestoneandlava.php'>29/7/2005</a></li>
<li><a title="Into the Never Never" href='intothenevernever.php'>5/8/2005</a></li>
<li><a title="Slowing the pace in Darwin" href='slowingthepaceindarwin.php'>12/8/2005</a></li>
<li><a title="Blistering Barnacles and Leaping Lizards" href='leapinglizards.php'>19/8/2005</a></li>
<li><a title="Kakadu and Litchfield" href='kakadu.php'>26/8/2005</a></li>
<li><a title="Legacies of War" href='legaciesofwar.php'>2/9/2005</a></li>
<li><a title="Go West" href='gowest.php'>10/9/2005</a></li>
<li><a title="Things from Above" href='thingsfromabove.php'>16/9/2005</a></li>
<li><a title="The West Coast" href='thewestcoast.php'>23/9/2005</a></li>
<li><a title="Reefs and Red Dust" href='reefsandreddust.php'>30/9/2005</a></li>
<li><a title="The Pilbara" href='pilbara.php'>7/10/2005</a></li>
<li><a title="Paradise with a Headwind" href='paradisewithaheadwind.php'>14/10/2005</a></li>
<li><a title="Down the Coral Coast" href='downthecoralcoast.php'>21/10/2005</a></li>
<li><a title="Pinnacles and Pinnipeds" href='pinnaclesandpinnipeds.php'>28/10/2005</a></li>
<li><a title="A week in Perth" href='perth.php'>4/11/2005</a></li>
<li><a title="The Southwest (from Above and Below)" href='thesouthwest.php'>11/11/2005</a></li>
<li><a title="More Heights and Depths" href='moreheightsanddepths.php'>18/11/2005</a></li>
<li><a title="Across the Nullarbor (and a bit beyond)" href='nullarbor.php'>25/11/2005</a></li>
<li><a title="Double Whammy" href='doublewhammy.php'>9/12/2005</a></li>
<li><a title="Two Cities" href='twocities.php'>19/12/2005</a></li>
<li><a title="Tassie - Part 1" href='tassie1.php'>1/1/2006</a></li>
<li><a title="Tassie - Part 2" href='tassie2.php'>7/1/2006</a></li>
<li><a title="Full Circle" href='fullcircle.php'>26/1/2006</a></li>
<li><a title="The Wrap Up" href='thewrapup.php'>23/3/2006</a></li>
<li> </li><br><li>Or go back to:</li><li><a title='Travelouges and blogs from my trip around Australia' href="nerdseyeview.php">Nerd's Eye View</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>29/4/2005</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Travel stories and pictures' href="travel.php">Travelogues</a> > <a title='Travelouges and blogs from my trip around Australia' href="nerdseyeview.php">Nerd's Eye View</a> > <a title='Greetings from a Bum' href="greetingsfromabum.php">29/4/2005</a>
<br><br>		


<h1>Greetings from a Bum</h1>

<a href="images/maps/Map050429.gif"><img src="images/maps/Map050429_sm.gif" align="right"></a>
<p>VINCENT<br>
So if you're quitting the life, what'll you do?</p>

<p>JULES<br>
That's what I've been sitting here contemplating. First, I'm gonna
deliver this case to Marcellus. Then, basically, I'm gonna walk the earth.</p>

<p>VINCENT<br>
What do you mean, walk the earth?</p>

<p>JULES<br>
You know, like Caine in "KUNG FU." Just walk from town to town, meet
people, get in adventures.</p>

<p>VINCENT<br>
So you decided to be a bum?</p>

<p>JULES<br>
I'll just be Jules, Vincent - no more, no less.</p>

<p>(Pulp Fiction)</p>

<p>Well, at long last, I've finally made it out the door. It's only early
days so I haven't really met any people or had any adventures yet; I've
basically been trying to settle into the life of the bum, and come to
grips with what I'm actually doing.</p>

<p>I started off on Monday arvo, and drove up to Noosa, which upon first
glance is a town composed entirely of expensive resorts, upmarket
seafood restaurants, old people, poms, kids and ice cream parlours. It's
nice, but is also expensive.</p>

<p>The first night I just checked in to a random place, rather than doing
the sensible thing and checking my maps and Lonely Planet guide, but it
was dark and I was pretty tired, so I ended up staying at the
illustrious Noosa Pde Holiday Inn. I guess I figured that the words
"Holiday Inn" would mean it was slightly dodgy and therefore cheap, but
in Noosa it's all relative.</p>

<p>The aim was primarily to have a decent place to stay on the first night,
and have access to a phone line so I could dial up to the net and write
my column and catch up on email. Unfortunately the magic Telstra
dial-anywhere-in-oz-for-a-local-call number didn't work, and whilst my
laptop picked up two wireless networks they were both just out of range
(and probably secured), so no hot nerd action occurred.</p>

<p>The next morning I relocated to the caravan park, and inflated my air
mattress, which, incidentally, takes about 700 strokes of my inadequate
(for the purpose) bicycle pump to do. One can do it sitting down
thankfully, but it's still a pretty good workout for the triceps. I
think I'll be leaving it largely inflated for the duration; I can get
exercise more productively.</p>

<p>After that I felt a swim was in order, so I biked down to the local
touristy beach and floated around for a while. It's not quite open ocean
so there was no surf to speak of at all, but the bottom dropped off
really quickly and so there weren't too many people far out from the
shore (the kiddies and pasty poms preferring to brave the deep).</p>

<p>Back at the caravan park I explored a bit and had a photo shoot with
some obliging pelicans (see attached), and then I slept in the car for
the first time; all up it's fairly comfy, if a little cramped.</p>

<p>I was also pleased to note that, despite the fact that it pissed down
with rain for half the night, I have no leaks, and nothing got wet (even
with the back hatch of the car open slightly).</p>

<p>I've relocated now to a nearby spot, Peregian Beach, which has a
slightly cheaper caravan park and actual surf, although it lacks just
about anything else. That's fine though, I'm still planning where to go
and a bit of quiet time is in order.</p>

<p>Last night sampled the fine cuisine at the local bowls club. And of
course I had to have a cheap beer.</p>

<p>Today I went for a longish walk in Noosa National Park. Explored for a
while, took a few pictures, didn't see much wildlife though, except for
a few other tourists. But still a nice day.</p>

<p>I think I'll stay here another day and work out where to head next, then
head there. Such is life.</p>

<p>Hope all is well back in the world. Email is going to be sporadic, but
there's always the phone if anyone wants me in a hurry. So far, so good!</p>

<br><br>
All images in this gallery:<br>
<table width='800'>
<tr>
</tr>
<tr><td><A ID='IMG_2021.JPG' href='greetingsfromabum.php?fileId=IMG_2021.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050429/IMG_2021.JPG' ALT='Fishing at sunset in Noosa'><BR>Fishing at sunset in Noosa<br>71.99 KB</a><div class='inv'><br><a href='./images/20050429/IMG_2021.JPG' ALT='Fishing at sunset in Noosa'>Fishing at sunset in Noosa</a></div></td>
<td><A ID='IMG_2026.JPG' href='greetingsfromabum.php?fileId=IMG_2026.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050429/IMG_2026.JPG' ALT='Two Pelicans and a Little Cormorant on the beach at Noosa'><BR>Two Pelicans and a Little Cormorant on the beach at Noosa<br>90.17 KB</a><div class='inv'><br><a href='./images/20050429/IMG_2026.JPG' ALT='Two Pelicans and a Little Cormorant on the beach at Noosa'>Two Pelicans and a Little Cormorant on the beach at Noosa</a></div></td>
<td><A ID='IMG_2029.JPG' href='greetingsfromabum.php?fileId=IMG_2029.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050429/IMG_2029.JPG' ALT='Pelican at sunset in Noosa'><BR>Pelican at sunset in Noosa<br>79.01 KB</a><div class='inv'><br><a href='./images/20050429/IMG_2029.JPG' ALT='Pelican at sunset in Noosa'>Pelican at sunset in Noosa</a></div></td>
<td><A ID='IMG_2032.JPG' href='greetingsfromabum.php?fileId=IMG_2032.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050429/IMG_2032.JPG' ALT='Pelican at sunset in Noosa'><BR>Pelican at sunset in Noosa<br>64.63 KB</a><div class='inv'><br><a href='./images/20050429/IMG_2032.JPG' ALT='Pelican at sunset in Noosa'>Pelican at sunset in Noosa</a></div></td>
<td><A ID='IMG_2042.JPG' href='greetingsfromabum.php?fileId=IMG_2042.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050429/IMG_2042.JPG' ALT='Two Pelicans'><BR>Two Pelicans<br>101.52 KB</a><div class='inv'><br><a href='./images/20050429/IMG_2042.JPG' ALT='Two Pelicans'>Two Pelicans</a></div></td>
</tr>
<tr><td><A ID='IMG_2045.JPG' href='greetingsfromabum.php?fileId=IMG_2045.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050429/IMG_2045.JPG' ALT='Noosa at sunset from the caravan park'><BR>Noosa at sunset from the caravan park<br>66.04 KB</a><div class='inv'><br><a href='./images/20050429/IMG_2045.JPG' ALT='Noosa at sunset from the caravan park'>Noosa at sunset from the caravan park</a></div></td>
<td><A ID='IMG_2047.JPG' href='greetingsfromabum.php?fileId=IMG_2047.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050429/IMG_2047.JPG' ALT='Cormorants on the radio mast'><BR>Cormorants on the radio mast<br>56.28 KB</a><div class='inv'><br><a href='./images/20050429/IMG_2047.JPG' ALT='Cormorants on the radio mast'>Cormorants on the radio mast</a></div></td>
<td><A ID='IMG_2052.JPG' href='greetingsfromabum.php?fileId=IMG_2052.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050429/IMG_2052.JPG' ALT='Noosa beach'><BR>Noosa beach<br>88.92 KB</a><div class='inv'><br><a href='./images/20050429/IMG_2052.JPG' ALT='Noosa beach'>Noosa beach</a></div></td>
<td><A ID='IMG_2053.JPG' href='greetingsfromabum.php?fileId=IMG_2053.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050429/IMG_2053.JPG' ALT='Noosa'><BR>Noosa<br>114.83 KB</a><div class='inv'><br><a href='./images/20050429/IMG_2053.JPG' ALT='Noosa'>Noosa</a></div></td>
<td><A ID='IMG_2059.JPG' href='greetingsfromabum.php?fileId=IMG_2059.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050429/IMG_2059.JPG' ALT='A biplane'><BR>A biplane<br>27.94 KB</a><div class='inv'><br><a href='./images/20050429/IMG_2059.JPG' ALT='A biplane'>A biplane</a></div></td>
</tr>
<tr><td><A ID='IMG_2060.JPG' href='greetingsfromabum.php?fileId=IMG_2060.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050429/IMG_2060.JPG' ALT='Hell's Gate, Noosa National Park'><BR>Hell's Gate, Noosa National Park<br>89.06 KB</a><div class='inv'><br><a href='./images/20050429/IMG_2060.JPG' ALT='Hell's Gate, Noosa National Park'>Hell's Gate, Noosa National Park</a></div></td>
<td><A ID='IMG_2061.JPG' href='greetingsfromabum.php?fileId=IMG_2061.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050429/IMG_2061.JPG' ALT='Hell's Gate, Noosa National Park'><BR>Hell's Gate, Noosa National Park<br>89.41 KB</a><div class='inv'><br><a href='./images/20050429/IMG_2061.JPG' ALT='Hell's Gate, Noosa National Park'>Hell's Gate, Noosa National Park</a></div></td>
<td><A ID='IMG_2063.JPG' href='greetingsfromabum.php?fileId=IMG_2063.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050429/IMG_2063.JPG' ALT='Alexandria Bay from Hell's Gate, Noosa National Park'><BR>Alexandria Bay from Hell's Gate, Noosa National Park<br>85.31 KB</a><div class='inv'><br><a href='./images/20050429/IMG_2063.JPG' ALT='Alexandria Bay from Hell's Gate, Noosa National Park'>Alexandria Bay from Hell's Gate, Noosa National Park</a></div></td>
<td><A ID='IMG_2064.JPG' href='greetingsfromabum.php?fileId=IMG_2064.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050429/IMG_2064.JPG' ALT='Hell's Gate, Noosa National Park'><BR>Hell's Gate, Noosa National Park<br>116.44 KB</a><div class='inv'><br><a href='./images/20050429/IMG_2064.JPG' ALT='Hell's Gate, Noosa National Park'>Hell's Gate, Noosa National Park</a></div></td>
<td><A ID='IMG_2068.JPG' href='greetingsfromabum.php?fileId=IMG_2068.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050429/IMG_2068.JPG' ALT='Looking back to Alexandria bay from Hell's Gate, Noosa National Park'><BR>Looking back to Alexandria bay from Hell's Gate, Noosa National Park<br>68.92 KB</a><div class='inv'><br><a href='./images/20050429/IMG_2068.JPG' ALT='Looking back to Alexandria bay from Hell's Gate, Noosa National Park'>Looking back to Alexandria bay from Hell's Gate, Noosa National Park</a></div></td>
</tr>
<tr><td><A ID='IMG_2071.JPG' href='greetingsfromabum.php?fileId=IMG_2071.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050429/IMG_2071.JPG' ALT='White Breasted Sea Eagle, Hell's Gate, Noosa National Park'><BR>White Breasted Sea Eagle, Hell's Gate, Noosa National Park<br>37.04 KB</a><div class='inv'><br><a href='./images/20050429/IMG_2071.JPG' ALT='White Breasted Sea Eagle, Hell's Gate, Noosa National Park'>White Breasted Sea Eagle, Hell's Gate, Noosa National Park</a></div></td>
<td><A ID='IMG_2073.JPG' href='greetingsfromabum.php?fileId=IMG_2073.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050429/IMG_2073.JPG' ALT='Coastline, Noosa National Park'><BR>Coastline, Noosa National Park<br>66.19 KB</a><div class='inv'><br><a href='./images/20050429/IMG_2073.JPG' ALT='Coastline, Noosa National Park'>Coastline, Noosa National Park</a></div></td>
<td><A ID='IMG_2076.JPG' href='greetingsfromabum.php?fileId=IMG_2076.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050429/IMG_2076.JPG' ALT='White Breasted Sea Eagle, Hell's Gate, Noosa National Park'><BR>White Breasted Sea Eagle, Hell's Gate, Noosa National Park<br>29.06 KB</a><div class='inv'><br><a href='./images/20050429/IMG_2076.JPG' ALT='White Breasted Sea Eagle, Hell's Gate, Noosa National Park'>White Breasted Sea Eagle, Hell's Gate, Noosa National Park</a></div></td>
<td><A ID='IMG_2080.JPG' href='greetingsfromabum.php?fileId=IMG_2080.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050429/IMG_2080.JPG' ALT='Noosa National Park'><BR>Noosa National Park<br>118.59 KB</a><div class='inv'><br><a href='./images/20050429/IMG_2080.JPG' ALT='Noosa National Park'>Noosa National Park</a></div></td>
<td><A ID='IMG_2087.JPG' href='greetingsfromabum.php?fileId=IMG_2087.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050429/IMG_2087.JPG' ALT='Stars from the car, Perigian Beach'><BR>Stars from the car, Perigian Beach<br>47.02 KB</a><div class='inv'><br><a href='./images/20050429/IMG_2087.JPG' ALT='Stars from the car, Perigian Beach'>Stars from the car, Perigian Beach</a></div></td>
</tr>
</table>	</div>
</div>
</body>
</html>