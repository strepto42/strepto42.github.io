<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - 24/6/2005 - Platypi and Grey Nomads</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="Platypi and Grey Nomads">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="Greetings from a Bum" href='greetingsfromabum.php'>29/4/2005</a></li>
<li><a title="Onward" href='onward.php'>2/5/2005</a></li>
<li><a title="It's a tough life (pt 1: Bundaberg, Agnes Water and 1770)" href='itsatoughlife1.php'>17/5/2005</a></li>
<li><a title="It's a tough life (pt 2: Rockhampton, Emu Park and Great Keppel Island)" href='itsatoughlife2.php'>23/5/2005</a></li>
<li><a title="There and Back Again - a Yo-yo's Tale" href='thereandbackagain.php'>18/6/2005</a></li>
<li><div class='activemenu'>24/6/2005</div></li>
<li><a title="Blowing Bubbles in a Watery Tomb" href='blowingbubbles.php'>1/7/2005</a></li>
<li><a title="Pieces of History" href='piecesofhistory.php'>8/7/2005</a></li>
<li><a title="Walks and Waterfalls" href='walksandwaterfalls.php'>15/7/2005</a></li>
<li><a title="Mission to Tribulation" href='missiontotribulation.php'>22/7/2005</a></li>
<li><a title="Levity, Limestone and Lava" href='levitylimestoneandlava.php'>29/7/2005</a></li>
<li><a title="Into the Never Never" href='intothenevernever.php'>5/8/2005</a></li>
<li><a title="Slowing the pace in Darwin" href='slowingthepaceindarwin.php'>12/8/2005</a></li>
<li><a title="Blistering Barnacles and Leaping Lizards" href='leapinglizards.php'>19/8/2005</a></li>
<li><a title="Kakadu and Litchfield" href='kakadu.php'>26/8/2005</a></li>
<li><a title="Legacies of War" href='legaciesofwar.php'>2/9/2005</a></li>
<li><a title="Go West" href='gowest.php'>10/9/2005</a></li>
<li><a title="Things from Above" href='thingsfromabove.php'>16/9/2005</a></li>
<li><a title="The West Coast" href='thewestcoast.php'>23/9/2005</a></li>
<li><a title="Reefs and Red Dust" href='reefsandreddust.php'>30/9/2005</a></li>
<li><a title="The Pilbara" href='pilbara.php'>7/10/2005</a></li>
<li><a title="Paradise with a Headwind" href='paradisewithaheadwind.php'>14/10/2005</a></li>
<li><a title="Down the Coral Coast" href='downthecoralcoast.php'>21/10/2005</a></li>
<li><a title="Pinnacles and Pinnipeds" href='pinnaclesandpinnipeds.php'>28/10/2005</a></li>
<li><a title="A week in Perth" href='perth.php'>4/11/2005</a></li>
<li><a title="The Southwest (from Above and Below)" href='thesouthwest.php'>11/11/2005</a></li>
<li><a title="More Heights and Depths" href='moreheightsanddepths.php'>18/11/2005</a></li>
<li><a title="Across the Nullarbor (and a bit beyond)" href='nullarbor.php'>25/11/2005</a></li>
<li><a title="Double Whammy" href='doublewhammy.php'>9/12/2005</a></li>
<li><a title="Two Cities" href='twocities.php'>19/12/2005</a></li>
<li><a title="Tassie - Part 1" href='tassie1.php'>1/1/2006</a></li>
<li><a title="Tassie - Part 2" href='tassie2.php'>7/1/2006</a></li>
<li><a title="Full Circle" href='fullcircle.php'>26/1/2006</a></li>
<li><a title="The Wrap Up" href='thewrapup.php'>23/3/2006</a></li>
<li> </li><br><li>Or go back to:</li><li><a title='Travelouges and blogs from my trip around Australia' href="nerdseyeview.php">Nerd's Eye View</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>24/6/2005</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Travel stories and pictures' href="travel.php">Travelogues</a> > <a title='Travelouges and blogs from my trip around Australia' href="nerdseyeview.php">Nerd's Eye View</a> > <a title='Platypi and Grey Nomads' href="platypiandgreynomads.php">24/6/2005</a>
<br><br>		


<h1>Platypi and Grey Nomads</h1>

<a href="images/maps/Map050624.gif"><img src="images/maps/Map050624_sm.gif" align="right"></a>
<p>Greetings once again. I thought I should write another, shorter update for you all, before things got out of hand again.</p>

<p>I didn't really hang round in Mackay, the hostel was full and the caravan park was distinctly lacklustre. So after getting a new tyre the next day, and doing a spot of clothes shopping (to replace my missing pants!), I headed off to Eungella (yun-galla, or something like that) National Park and Finch Hatton Gorge. These spots had been on my to-do list for a while, doubly so after having been recommended by a few people.</p>

<p>They're the place to go to see Platypi in the wild, as these normally shy creatures have become somewhat accustomed to people there.</p>

<p>The drive up there is quite spectacular, it's a really steep and windy climb, the sort of things that breaks cheap backpacker cars on a regular basis I would imagine. I heard a story of one girl who drove up there without any oil in her engine, which proceeded to die spectactularly a few days later.</p>

<p>I got there fairly late in the day, so I didn't do much except meet the neighbours, including a really friendly old chap called Geoff, who turned out to be quite an interesting fellow, having done a lot of climbing in his younger years (in the 1960s and so on).</p>

<p>Next morning I got up at the crack of dawn (well, ok, 7am) and managed to see my first Platypus. They're very odd creatures, as I'm sure you all know. It was quite cool to see one in the wild though, as I'd only ever seen them in the zoo before.</p>

<p>I spent the rest of the day walking around in the national park there. There are some really lovely walks through the forest, with some spectacular views. There are a lot of dairy farms up there too (in the non-national park bits), it's all a bit English-countryside in a way, but of course with Aussie flora and fauna of course (including squillions of raucous Sulphur-crested Cockies).</p>

<p>Ok, so it wasn't very English at all. Perhaps it was just that it was a grey overcast day that did it. ;)</p>

<p>After another evening spent gasbagging with Geoff I had another early morning, which let me get a much better platypus photo. Then I moved on to nearby Finch Hatton Gorge, via a strange little cafe. The guidebook listed it as having an "eccentric but utterly enchanting" garden attached, so I was intrigued.</p>

<p>When I got there the garden was closed, and the lady who ran the place seemed almost annoyed by my presence, but after my tea and scones (with jam and cream, thank you very much), I asked her about the garden and she cheered up and let me have a wander through. I'll let the picture speak for itself; I found it pretty much as the guide described it. Apparently it's taken her four years to build, all by hand.</p>

<p>After that I got to Finch Hatton Gorge and stayed at a place called Platypus Bush Camp, run by an old fellow with a big beard called Wazza. I gather he's built it pretty much himself over the years, and it's really quite a lovely spot, although Wazza can be a bit much at times (he's friendly, but rough around the edges shall we say, and talks incessantly. And tries to flog you Whitsunday cruises).</p>

<p>A quick wander up the road from there is a really nice walk to some falls. A pic is also attached � the water was amazingly clear and clean (and COLD). Various people were going in for dips and coming out blue. I would have joined them, but I didn't have a towel and I figured the walk back wouldn't be too pleasant damp. Instead I had a dip in the creek at Wazza's, which was just as nice really. It reminded me very strongly of swimming in Brogers Creek down near Berry (in NSW), which some of you will no doubt be familiar with.</p>

<p>I also found a random termite-eaten tree on the way to the falls. It reminded me rather a lot the Black Tower in Mordor from Lord of the Rings. There's a pic attached to illustrate the point.</p>

<p>I also wired the UPS cum inverter into my car properly (ie, directly to the battery, rather than going through the ciggie lighter). It works well now, no shutting down due to under voltage when running the laptop, and no overloading the wiring of my car either.</p>

<p>Using my monster laptop will still flatten my car battery in a few hours though, so I'll have to be careful, but now I should at least be able to watch a movie on the laptop if I so desire it, as well as use the inverter without taking up the ciggie lighter whilst in motion (this way I can have the GPS plugged in too). All very fascinating, yes? Hey I'm excited at my achievement, splicing and wiring in a national park campsite, so there (and yes I did pick up all the little bits of plastic insulation from stripped wires).</p>

<p>Anyway from there I pushed on to yet another national park, on the coast this time, Cape Hillsborough. I camped again amongst a bunch of grey nomads (over 50s travelling with caravans), and had some nice chats. Met one couple who spend 6 months in Mooloolaba and 6 months travelling and gold prospecting (for fun basically, they admitted that their equipment still hadn't been paid for by the gold it's found, but the thrill is in the chase after all).</p>

<p>The park itself was really nice. I walked out to a spot called Wedge Island at low tide, and took some pictures (of course). There were some amazing rocks there, with fantastic shapes formed from erosion and so on.</p>

<p>(ok, so maybe you had to be there ;))</p>

<p>And now I'm in Airlie Beach. It's a backpacker town, and jumping off point for the Whitsunday Islands cruises. I'm not going to bother with a cruise, as the company you get on the boat is random, as is the weather. Plus of course, it's expensive. I've had a few nights of going out, but drinking and single serving friends get rapidly tiresome, so I reckon I'll push on shortly, to Ayr or Townsville, where you can do the famous Yongala wreck dive, supposedly one of the best around. Can't wait!</p>

<p>Oh well, so much for a brief email, but hey, what can you do. Not read it, I guess. &lt;grin&gt;</p>

<p>As usual tons of pics are here on my site, as are those fantastically lucrative (and often strangely irrelevant) banner ads - I'm up to $13. Money for nothing, that's what dot-coms are all about.</p>

<p>Take care all, thanks for those who are writing, it's nice to hear the news from around the traps while I'm on the road in random places.</p>

<br><br>
All images in this gallery:<br>
<table width='800'>
<tr>
</tr>
<tr><td><A ID='IMG_3491.JPG' href='platypiandgreynomads.php?fileId=IMG_3491.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050624/IMG_3491.JPG' ALT='IMG_3491.JPG'><BR>IMG_3491.JPG<br>84.97 KB</a><div class='inv'><br><a href='./images/20050624/IMG_3491.JPG' ALT='IMG_3491.JPG'>IMG_3491.JPG</a></div></td>
<td><A ID='IMG_3493.JPG' href='platypiandgreynomads.php?fileId=IMG_3493.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050624/IMG_3493.JPG' ALT='IMG_3493.JPG'><BR>IMG_3493.JPG<br>86.73 KB</a><div class='inv'><br><a href='./images/20050624/IMG_3493.JPG' ALT='IMG_3493.JPG'>IMG_3493.JPG</a></div></td>
<td><A ID='IMG_3497.JPG' href='platypiandgreynomads.php?fileId=IMG_3497.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050624/IMG_3497.JPG' ALT='IMG_3497.JPG'><BR>IMG_3497.JPG<br>53.86 KB</a><div class='inv'><br><a href='./images/20050624/IMG_3497.JPG' ALT='IMG_3497.JPG'>IMG_3497.JPG</a></div></td>
<td><A ID='IMG_3499.JPG' href='platypiandgreynomads.php?fileId=IMG_3499.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050624/IMG_3499.JPG' ALT='IMG_3499.JPG'><BR>IMG_3499.JPG<br>87.53 KB</a><div class='inv'><br><a href='./images/20050624/IMG_3499.JPG' ALT='IMG_3499.JPG'>IMG_3499.JPG</a></div></td>
<td><A ID='IMG_3506.JPG' href='platypiandgreynomads.php?fileId=IMG_3506.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050624/IMG_3506.JPG' ALT='IMG_3506.JPG'><BR>IMG_3506.JPG<br>66.08 KB</a><div class='inv'><br><a href='./images/20050624/IMG_3506.JPG' ALT='IMG_3506.JPG'>IMG_3506.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_3507.JPG' href='platypiandgreynomads.php?fileId=IMG_3507.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050624/IMG_3507.JPG' ALT='IMG_3507.JPG'><BR>IMG_3507.JPG<br>83.36 KB</a><div class='inv'><br><a href='./images/20050624/IMG_3507.JPG' ALT='IMG_3507.JPG'>IMG_3507.JPG</a></div></td>
<td><A ID='IMG_3512.JPG' href='platypiandgreynomads.php?fileId=IMG_3512.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050624/IMG_3512.JPG' ALT='IMG_3512.JPG'><BR>IMG_3512.JPG<br>34.01 KB</a><div class='inv'><br><a href='./images/20050624/IMG_3512.JPG' ALT='IMG_3512.JPG'>IMG_3512.JPG</a></div></td>
<td><A ID='IMG_3514.JPG' href='platypiandgreynomads.php?fileId=IMG_3514.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050624/IMG_3514.JPG' ALT='IMG_3514.JPG'><BR>IMG_3514.JPG<br>30.52 KB</a><div class='inv'><br><a href='./images/20050624/IMG_3514.JPG' ALT='IMG_3514.JPG'>IMG_3514.JPG</a></div></td>
<td><A ID='IMG_3519.JPG' href='platypiandgreynomads.php?fileId=IMG_3519.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050624/IMG_3519.JPG' ALT='IMG_3519.JPG'><BR>IMG_3519.JPG<br>28.71 KB</a><div class='inv'><br><a href='./images/20050624/IMG_3519.JPG' ALT='IMG_3519.JPG'>IMG_3519.JPG</a></div></td>
<td><A ID='IMG_3525.JPG' href='platypiandgreynomads.php?fileId=IMG_3525.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050624/IMG_3525.JPG' ALT='IMG_3525.JPG'><BR>IMG_3525.JPG<br>78.74 KB</a><div class='inv'><br><a href='./images/20050624/IMG_3525.JPG' ALT='IMG_3525.JPG'>IMG_3525.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_3531.JPG' href='platypiandgreynomads.php?fileId=IMG_3531.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050624/IMG_3531.JPG' ALT='IMG_3531.JPG'><BR>IMG_3531.JPG<br>137.62 KB</a><div class='inv'><br><a href='./images/20050624/IMG_3531.JPG' ALT='IMG_3531.JPG'>IMG_3531.JPG</a></div></td>
<td><A ID='IMG_3532.JPG' href='platypiandgreynomads.php?fileId=IMG_3532.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050624/IMG_3532.JPG' ALT='IMG_3532.JPG'><BR>IMG_3532.JPG<br>115.11 KB</a><div class='inv'><br><a href='./images/20050624/IMG_3532.JPG' ALT='IMG_3532.JPG'>IMG_3532.JPG</a></div></td>
<td><A ID='IMG_3534.JPG' href='platypiandgreynomads.php?fileId=IMG_3534.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050624/IMG_3534.JPG' ALT='IMG_3534.JPG'><BR>IMG_3534.JPG<br>68.68 KB</a><div class='inv'><br><a href='./images/20050624/IMG_3534.JPG' ALT='IMG_3534.JPG'>IMG_3534.JPG</a></div></td>
<td><A ID='IMG_3538.JPG' href='platypiandgreynomads.php?fileId=IMG_3538.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050624/IMG_3538.JPG' ALT='IMG_3538.JPG'><BR>IMG_3538.JPG<br>100.61 KB</a><div class='inv'><br><a href='./images/20050624/IMG_3538.JPG' ALT='IMG_3538.JPG'>IMG_3538.JPG</a></div></td>
<td><A ID='IMG_3546.JPG' href='platypiandgreynomads.php?fileId=IMG_3546.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050624/IMG_3546.JPG' ALT='IMG_3546.JPG'><BR>IMG_3546.JPG<br>36.59 KB</a><div class='inv'><br><a href='./images/20050624/IMG_3546.JPG' ALT='IMG_3546.JPG'>IMG_3546.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_3547.JPG' href='platypiandgreynomads.php?fileId=IMG_3547.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050624/IMG_3547.JPG' ALT='IMG_3547.JPG'><BR>IMG_3547.JPG<br>40.86 KB</a><div class='inv'><br><a href='./images/20050624/IMG_3547.JPG' ALT='IMG_3547.JPG'>IMG_3547.JPG</a></div></td>
<td><A ID='IMG_3548.JPG' href='platypiandgreynomads.php?fileId=IMG_3548.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050624/IMG_3548.JPG' ALT='IMG_3548.JPG'><BR>IMG_3548.JPG<br>39.92 KB</a><div class='inv'><br><a href='./images/20050624/IMG_3548.JPG' ALT='IMG_3548.JPG'>IMG_3548.JPG</a></div></td>
<td><A ID='IMG_3549.JPG' href='platypiandgreynomads.php?fileId=IMG_3549.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050624/IMG_3549.JPG' ALT='IMG_3549.JPG'><BR>IMG_3549.JPG<br>39.01 KB</a><div class='inv'><br><a href='./images/20050624/IMG_3549.JPG' ALT='IMG_3549.JPG'>IMG_3549.JPG</a></div></td>
<td><A ID='IMG_3550.JPG' href='platypiandgreynomads.php?fileId=IMG_3550.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050624/IMG_3550.JPG' ALT='IMG_3550.JPG'><BR>IMG_3550.JPG<br>63.92 KB</a><div class='inv'><br><a href='./images/20050624/IMG_3550.JPG' ALT='IMG_3550.JPG'>IMG_3550.JPG</a></div></td>
<td><A ID='IMG_3551.JPG' href='platypiandgreynomads.php?fileId=IMG_3551.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050624/IMG_3551.JPG' ALT='IMG_3551.JPG'><BR>IMG_3551.JPG<br>69.48 KB</a><div class='inv'><br><a href='./images/20050624/IMG_3551.JPG' ALT='IMG_3551.JPG'>IMG_3551.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_3552.JPG' href='platypiandgreynomads.php?fileId=IMG_3552.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050624/IMG_3552.JPG' ALT='IMG_3552.JPG'><BR>IMG_3552.JPG<br>57.27 KB</a><div class='inv'><br><a href='./images/20050624/IMG_3552.JPG' ALT='IMG_3552.JPG'>IMG_3552.JPG</a></div></td>
<td><A ID='IMG_3554.JPG' href='platypiandgreynomads.php?fileId=IMG_3554.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050624/IMG_3554.JPG' ALT='IMG_3554.JPG'><BR>IMG_3554.JPG<br>29.92 KB</a><div class='inv'><br><a href='./images/20050624/IMG_3554.JPG' ALT='IMG_3554.JPG'>IMG_3554.JPG</a></div></td>
<td><A ID='IMG_3559.JPG' href='platypiandgreynomads.php?fileId=IMG_3559.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050624/IMG_3559.JPG' ALT='IMG_3559.JPG'><BR>IMG_3559.JPG<br>49.54 KB</a><div class='inv'><br><a href='./images/20050624/IMG_3559.JPG' ALT='IMG_3559.JPG'>IMG_3559.JPG</a></div></td>
<td><A ID='IMG_3560.JPG' href='platypiandgreynomads.php?fileId=IMG_3560.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050624/IMG_3560.JPG' ALT='IMG_3560.JPG'><BR>IMG_3560.JPG<br>47.85 KB</a><div class='inv'><br><a href='./images/20050624/IMG_3560.JPG' ALT='IMG_3560.JPG'>IMG_3560.JPG</a></div></td>
<td><A ID='IMG_3564.JPG' href='platypiandgreynomads.php?fileId=IMG_3564.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050624/IMG_3564.JPG' ALT='IMG_3564.JPG'><BR>IMG_3564.JPG<br>157.47 KB</a><div class='inv'><br><a href='./images/20050624/IMG_3564.JPG' ALT='IMG_3564.JPG'>IMG_3564.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_3568.JPG' href='platypiandgreynomads.php?fileId=IMG_3568.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050624/IMG_3568.JPG' ALT='IMG_3568.JPG'><BR>IMG_3568.JPG<br>79.53 KB</a><div class='inv'><br><a href='./images/20050624/IMG_3568.JPG' ALT='IMG_3568.JPG'>IMG_3568.JPG</a></div></td>
<td><A ID='IMG_3569.JPG' href='platypiandgreynomads.php?fileId=IMG_3569.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050624/IMG_3569.JPG' ALT='IMG_3569.JPG'><BR>IMG_3569.JPG<br>55.79 KB</a><div class='inv'><br><a href='./images/20050624/IMG_3569.JPG' ALT='IMG_3569.JPG'>IMG_3569.JPG</a></div></td>
<td><A ID='IMG_3572.JPG' href='platypiandgreynomads.php?fileId=IMG_3572.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050624/IMG_3572.JPG' ALT='IMG_3572.JPG'><BR>IMG_3572.JPG<br>84.37 KB</a><div class='inv'><br><a href='./images/20050624/IMG_3572.JPG' ALT='IMG_3572.JPG'>IMG_3572.JPG</a></div></td>
<td><A ID='IMG_3573.JPG' href='platypiandgreynomads.php?fileId=IMG_3573.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050624/IMG_3573.JPG' ALT='IMG_3573.JPG'><BR>IMG_3573.JPG<br>87.15 KB</a><div class='inv'><br><a href='./images/20050624/IMG_3573.JPG' ALT='IMG_3573.JPG'>IMG_3573.JPG</a></div></td>
<td><A ID='IMG_3575.JPG' href='platypiandgreynomads.php?fileId=IMG_3575.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050624/IMG_3575.JPG' ALT='IMG_3575.JPG'><BR>IMG_3575.JPG<br>103.01 KB</a><div class='inv'><br><a href='./images/20050624/IMG_3575.JPG' ALT='IMG_3575.JPG'>IMG_3575.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_3577.JPG' href='platypiandgreynomads.php?fileId=IMG_3577.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050624/IMG_3577.JPG' ALT='IMG_3577.JPG'><BR>IMG_3577.JPG<br>77.93 KB</a><div class='inv'><br><a href='./images/20050624/IMG_3577.JPG' ALT='IMG_3577.JPG'>IMG_3577.JPG</a></div></td>
<td><A ID='IMG_3591.JPG' href='platypiandgreynomads.php?fileId=IMG_3591.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050624/IMG_3591.JPG' ALT='IMG_3591.JPG'><BR>IMG_3591.JPG<br>144.75 KB</a><div class='inv'><br><a href='./images/20050624/IMG_3591.JPG' ALT='IMG_3591.JPG'>IMG_3591.JPG</a></div></td>
<td><A ID='IMG_3594.JPG' href='platypiandgreynomads.php?fileId=IMG_3594.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050624/IMG_3594.JPG' ALT='IMG_3594.JPG'><BR>IMG_3594.JPG<br>144.42 KB</a><div class='inv'><br><a href='./images/20050624/IMG_3594.JPG' ALT='IMG_3594.JPG'>IMG_3594.JPG</a></div></td>
<td><A ID='IMG_3597.JPG' href='platypiandgreynomads.php?fileId=IMG_3597.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050624/IMG_3597.JPG' ALT='IMG_3597.JPG'><BR>IMG_3597.JPG<br>115.77 KB</a><div class='inv'><br><a href='./images/20050624/IMG_3597.JPG' ALT='IMG_3597.JPG'>IMG_3597.JPG</a></div></td>
<td><A ID='IMG_3599.JPG' href='platypiandgreynomads.php?fileId=IMG_3599.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050624/IMG_3599.JPG' ALT='IMG_3599.JPG'><BR>IMG_3599.JPG<br>96.19 KB</a><div class='inv'><br><a href='./images/20050624/IMG_3599.JPG' ALT='IMG_3599.JPG'>IMG_3599.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_3600.JPG' href='platypiandgreynomads.php?fileId=IMG_3600.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050624/IMG_3600.JPG' ALT='IMG_3600.JPG'><BR>IMG_3600.JPG<br>146.47 KB</a><div class='inv'><br><a href='./images/20050624/IMG_3600.JPG' ALT='IMG_3600.JPG'>IMG_3600.JPG</a></div></td>
<td><A ID='IMG_3601.JPG' href='platypiandgreynomads.php?fileId=IMG_3601.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050624/IMG_3601.JPG' ALT='IMG_3601.JPG'><BR>IMG_3601.JPG<br>150.31 KB</a><div class='inv'><br><a href='./images/20050624/IMG_3601.JPG' ALT='IMG_3601.JPG'>IMG_3601.JPG</a></div></td>
<td><A ID='IMG_3602.JPG' href='platypiandgreynomads.php?fileId=IMG_3602.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050624/IMG_3602.JPG' ALT='IMG_3602.JPG'><BR>IMG_3602.JPG<br>139.15 KB</a><div class='inv'><br><a href='./images/20050624/IMG_3602.JPG' ALT='IMG_3602.JPG'>IMG_3602.JPG</a></div></td>
<td><A ID='IMG_3615.JPG' href='platypiandgreynomads.php?fileId=IMG_3615.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050624/IMG_3615.JPG' ALT='IMG_3615.JPG'><BR>IMG_3615.JPG<br>94.71 KB</a><div class='inv'><br><a href='./images/20050624/IMG_3615.JPG' ALT='IMG_3615.JPG'>IMG_3615.JPG</a></div></td>
<td><A ID='IMG_3616.JPG' href='platypiandgreynomads.php?fileId=IMG_3616.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050624/IMG_3616.JPG' ALT='IMG_3616.JPG'><BR>IMG_3616.JPG<br>106.24 KB</a><div class='inv'><br><a href='./images/20050624/IMG_3616.JPG' ALT='IMG_3616.JPG'>IMG_3616.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_3620.JPG' href='platypiandgreynomads.php?fileId=IMG_3620.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050624/IMG_3620.JPG' ALT='IMG_3620.JPG'><BR>IMG_3620.JPG<br>99.24 KB</a><div class='inv'><br><a href='./images/20050624/IMG_3620.JPG' ALT='IMG_3620.JPG'>IMG_3620.JPG</a></div></td>
<td><A ID='IMG_3623.JPG' href='platypiandgreynomads.php?fileId=IMG_3623.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050624/IMG_3623.JPG' ALT='IMG_3623.JPG'><BR>IMG_3623.JPG<br>118.29 KB</a><div class='inv'><br><a href='./images/20050624/IMG_3623.JPG' ALT='IMG_3623.JPG'>IMG_3623.JPG</a></div></td>
<td><A ID='IMG_3626.JPG' href='platypiandgreynomads.php?fileId=IMG_3626.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050624/IMG_3626.JPG' ALT='IMG_3626.JPG'><BR>IMG_3626.JPG<br>94.72 KB</a><div class='inv'><br><a href='./images/20050624/IMG_3626.JPG' ALT='IMG_3626.JPG'>IMG_3626.JPG</a></div></td>
<td><A ID='IMG_3629.JPG' href='platypiandgreynomads.php?fileId=IMG_3629.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050624/IMG_3629.JPG' ALT='IMG_3629.JPG'><BR>IMG_3629.JPG<br>101.76 KB</a><div class='inv'><br><a href='./images/20050624/IMG_3629.JPG' ALT='IMG_3629.JPG'>IMG_3629.JPG</a></div></td>
<td><A ID='IMG_3636.JPG' href='platypiandgreynomads.php?fileId=IMG_3636.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050624/IMG_3636.JPG' ALT='IMG_3636.JPG'><BR>IMG_3636.JPG<br>108.05 KB</a><div class='inv'><br><a href='./images/20050624/IMG_3636.JPG' ALT='IMG_3636.JPG'>IMG_3636.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_3647.JPG' href='platypiandgreynomads.php?fileId=IMG_3647.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050624/IMG_3647.JPG' ALT='IMG_3647.JPG'><BR>IMG_3647.JPG<br>53.11 KB</a><div class='inv'><br><a href='./images/20050624/IMG_3647.JPG' ALT='IMG_3647.JPG'>IMG_3647.JPG</a></div></td>
<td><A ID='IMG_3650.JPG' href='platypiandgreynomads.php?fileId=IMG_3650.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050624/IMG_3650.JPG' ALT='IMG_3650.JPG'><BR>IMG_3650.JPG<br>43.87 KB</a><div class='inv'><br><a href='./images/20050624/IMG_3650.JPG' ALT='IMG_3650.JPG'>IMG_3650.JPG</a></div></td>
<td><A ID='IMG_3653.JPG' href='platypiandgreynomads.php?fileId=IMG_3653.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050624/IMG_3653.JPG' ALT='IMG_3653.JPG'><BR>IMG_3653.JPG<br>103.64 KB</a><div class='inv'><br><a href='./images/20050624/IMG_3653.JPG' ALT='IMG_3653.JPG'>IMG_3653.JPG</a></div></td>
<td><A ID='IMG_3657.JPG' href='platypiandgreynomads.php?fileId=IMG_3657.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050624/IMG_3657.JPG' ALT='IMG_3657.JPG'><BR>IMG_3657.JPG<br>55.98 KB</a><div class='inv'><br><a href='./images/20050624/IMG_3657.JPG' ALT='IMG_3657.JPG'>IMG_3657.JPG</a></div></td>
<td><A ID='IMG_3659.JPG' href='platypiandgreynomads.php?fileId=IMG_3659.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050624/IMG_3659.JPG' ALT='IMG_3659.JPG'><BR>IMG_3659.JPG<br>59.57 KB</a><div class='inv'><br><a href='./images/20050624/IMG_3659.JPG' ALT='IMG_3659.JPG'>IMG_3659.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_3676.JPG' href='platypiandgreynomads.php?fileId=IMG_3676.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050624/IMG_3676.JPG' ALT='IMG_3676.JPG'><BR>IMG_3676.JPG<br>107.89 KB</a><div class='inv'><br><a href='./images/20050624/IMG_3676.JPG' ALT='IMG_3676.JPG'>IMG_3676.JPG</a></div></td>
<td><A ID='IMG_3678.JPG' href='platypiandgreynomads.php?fileId=IMG_3678.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050624/IMG_3678.JPG' ALT='IMG_3678.JPG'><BR>IMG_3678.JPG<br>31.93 KB</a><div class='inv'><br><a href='./images/20050624/IMG_3678.JPG' ALT='IMG_3678.JPG'>IMG_3678.JPG</a></div></td>
<td><A ID='IMG_3681.JPG' href='platypiandgreynomads.php?fileId=IMG_3681.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050624/IMG_3681.JPG' ALT='IMG_3681.JPG'><BR>IMG_3681.JPG<br>81.95 KB</a><div class='inv'><br><a href='./images/20050624/IMG_3681.JPG' ALT='IMG_3681.JPG'>IMG_3681.JPG</a></div></td>
<td><A ID='IMG_3682.JPG' href='platypiandgreynomads.php?fileId=IMG_3682.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050624/IMG_3682.JPG' ALT='IMG_3682.JPG'><BR>IMG_3682.JPG<br>104.98 KB</a><div class='inv'><br><a href='./images/20050624/IMG_3682.JPG' ALT='IMG_3682.JPG'>IMG_3682.JPG</a></div></td>
<td><A ID='IMG_3683.JPG' href='platypiandgreynomads.php?fileId=IMG_3683.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050624/IMG_3683.JPG' ALT='IMG_3683.JPG'><BR>IMG_3683.JPG<br>112.28 KB</a><div class='inv'><br><a href='./images/20050624/IMG_3683.JPG' ALT='IMG_3683.JPG'>IMG_3683.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_3685.JPG' href='platypiandgreynomads.php?fileId=IMG_3685.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050624/IMG_3685.JPG' ALT='IMG_3685.JPG'><BR>IMG_3685.JPG<br>40.25 KB</a><div class='inv'><br><a href='./images/20050624/IMG_3685.JPG' ALT='IMG_3685.JPG'>IMG_3685.JPG</a></div></td>
<td><A ID='IMG_3686.JPG' href='platypiandgreynomads.php?fileId=IMG_3686.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050624/IMG_3686.JPG' ALT='IMG_3686.JPG'><BR>IMG_3686.JPG<br>59.24 KB</a><div class='inv'><br><a href='./images/20050624/IMG_3686.JPG' ALT='IMG_3686.JPG'>IMG_3686.JPG</a></div></td>
<td><A ID='IMG_3687.JPG' href='platypiandgreynomads.php?fileId=IMG_3687.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050624/IMG_3687.JPG' ALT='IMG_3687.JPG'><BR>IMG_3687.JPG<br>57.88 KB</a><div class='inv'><br><a href='./images/20050624/IMG_3687.JPG' ALT='IMG_3687.JPG'>IMG_3687.JPG</a></div></td>
<td><A ID='IMG_3691.JPG' href='platypiandgreynomads.php?fileId=IMG_3691.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050624/IMG_3691.JPG' ALT='IMG_3691.JPG'><BR>IMG_3691.JPG<br>52.49 KB</a><div class='inv'><br><a href='./images/20050624/IMG_3691.JPG' ALT='IMG_3691.JPG'>IMG_3691.JPG</a></div></td>
<td><A ID='IMG_3697.JPG' href='platypiandgreynomads.php?fileId=IMG_3697.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050624/IMG_3697.JPG' ALT='IMG_3697.JPG'><BR>IMG_3697.JPG<br>59.65 KB</a><div class='inv'><br><a href='./images/20050624/IMG_3697.JPG' ALT='IMG_3697.JPG'>IMG_3697.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_3700.JPG' href='platypiandgreynomads.php?fileId=IMG_3700.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050624/IMG_3700.JPG' ALT='IMG_3700.JPG'><BR>IMG_3700.JPG<br>70.93 KB</a><div class='inv'><br><a href='./images/20050624/IMG_3700.JPG' ALT='IMG_3700.JPG'>IMG_3700.JPG</a></div></td>
<td><A ID='IMG_3703.JPG' href='platypiandgreynomads.php?fileId=IMG_3703.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050624/IMG_3703.JPG' ALT='IMG_3703.JPG'><BR>IMG_3703.JPG<br>92.99 KB</a><div class='inv'><br><a href='./images/20050624/IMG_3703.JPG' ALT='IMG_3703.JPG'>IMG_3703.JPG</a></div></td>
<td><A ID='IMG_3708.JPG' href='platypiandgreynomads.php?fileId=IMG_3708.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050624/IMG_3708.JPG' ALT='IMG_3708.JPG'><BR>IMG_3708.JPG<br>91.1 KB</a><div class='inv'><br><a href='./images/20050624/IMG_3708.JPG' ALT='IMG_3708.JPG'>IMG_3708.JPG</a></div></td>
<td><A ID='IMG_3715.JPG' href='platypiandgreynomads.php?fileId=IMG_3715.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050624/IMG_3715.JPG' ALT='IMG_3715.JPG'><BR>IMG_3715.JPG<br>59.07 KB</a><div class='inv'><br><a href='./images/20050624/IMG_3715.JPG' ALT='IMG_3715.JPG'>IMG_3715.JPG</a></div></td>
<td><A ID='IMG_3725.JPG' href='platypiandgreynomads.php?fileId=IMG_3725.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050624/IMG_3725.JPG' ALT='IMG_3725.JPG'><BR>IMG_3725.JPG<br>36.44 KB</a><div class='inv'><br><a href='./images/20050624/IMG_3725.JPG' ALT='IMG_3725.JPG'>IMG_3725.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_3729.JPG' href='platypiandgreynomads.php?fileId=IMG_3729.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20050624/IMG_3729.JPG' ALT='IMG_3729.JPG'><BR>IMG_3729.JPG<br>118.2 KB</a><div class='inv'><br><a href='./images/20050624/IMG_3729.JPG' ALT='IMG_3729.JPG'>IMG_3729.JPG</a></div></td>
</tr>
</table>	</div>
</div>
</body>
</html>