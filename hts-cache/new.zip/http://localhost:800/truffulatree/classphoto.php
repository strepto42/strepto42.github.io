<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - Class Photo - James Ruse Agricultural High School Class of 1992 - Class photo</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="James Ruse Agricultural High School Class of 1992 - Class photo">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="James Ruse Agricultural High School Class of 1992 10 year reunion pictures" href='10yearpics.php'>Reunion Photos</a></li>
<li><div class='activemenu'>Class Photo</div></li>
<li><a title="James Ruse Agricultural High School Class of 1992 10 year reunion - personal profiles" href='profiles.php'>People's Profiles</a></li>
<li> </li><br><li>Or go back to:</li><li><a title='James Ruse Agricultural High School Class of 1992 10 year reunion' href="reunion.php">Reunion</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>Class Photo</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Old stuff from my site' href="archive.php">Archive</a> > <a title='James Ruse Agricultural High School Class of 1992 10 year reunion' href="reunion.php">Reunion</a> > <a title='James Ruse Agricultural High School Class of 1992 - Class photo' href="classphoto.php">Class Photo</a>
<br><br>		
<h2>JRAHS Year 12 photo - class of '92</h2>
I scanned this a few years back for some odd reason, it may as well get passed around. :) Any spelling mistakes are the scanner's fault, not mine! (but let me know)<br>
<br>
Click on it for the original enormous version.<br>
<br>
<a href="images/reunion/classphoto/YR12.jpg"><img src="images/reunion/classphoto/YR12_small.jpg" alt="James Ruse Year 12 Class of 1992" border="0"></a><br>
<br>

<p>FRONT ROW: Herrick Ho, Lisa Thompson, Chee-Ho Tham, Elizabeth Scott, Helen
Troup, Christie Hunt, Mark Edler, Robert Aroney, Adam Keppie, Paul Irish,
Rowena Besley, Rebecca Lovell, James Taylor, Lee On Tan, Zane Turner, Andrew
Schmidt, Kelly Hutchinson, Sarah Cheong, Yin-Yin Chung</p>

<p>SECOND ROW: Sharitah Shanmuganathan, Mila Kasby, Liza Cubeddu, Jenni Cooper,
Natalie Gamble, Winnie Chui, Hoangsa Tran, Sharrie Hosford, Sandra Pedram,
Jae Lee, Anna To, Karen Tsai, Karina Sendt, Leanne Uren, Hazel Law, Yvonne
Ching, Helen Lau, Micaela Fernandez, Kavita Panjratan. Angela Poon.</p>

<p>THIRD ROW: Daniella Ferrara, Elizabeth Hammond, Chrissie Penn, Lucy Curlewis,
Kirsty Harvison, Kylie Lance, Katherine White, Katrina Groot-Obbink, Jodie
Layton</p>

<p>FOURTH ROW: Jean Li, Kawal Johal, Helen Moon, Suzan Meguid, Sarah Roberts,
Karen Cambrell, Sharon Medlow, Bronwyn Walker, Jenny Eden, Lyndall Durkin,
Brooke Davidson, Jenny McGlynn, Lucy Johnson, Emma Baggs, Anna Kempisty,
Jenny Chang, Amanda Lane, Annalisa Berra, Michelle Imrie, Vinoli
Thampapillai, Karen Payne</p>

<p>FIFTH ROW: Lisa Le Van, Justine Drew, Aivee Chua, Jenny Harvey, Melinda
Goudkamp, Aubrey Jonker, Deborah Johns, Narelle Mathews, Samantha Ridler,
Sarah Benson, Kelly Randall, Ann Ho, Felicia Wallace, Shaylee Iles, Laura
Olds, Kathleen Collins, Hong Foo, Vivienne Khouri, Naomi Peles</p>

<p>SIXTH ROW: Lisa Clark, Fiona Straton, Claire Allen, Susan Kim, Namson Lau,
Michael Wong, Edmond Yan, Matthew Kwong, Damian Teoh, Stephen Liu, Sumugan
Sivanesan, Stephen Park, Bun Leng Chhoeu, Simon Lau, Kenneth Lai, Jenny
Darnell, Neisha Asimus, Elizabeth Tran, Ashley Lewis</p>

<p>SEVENTH ROW: Dimitri Diamantes, Drew MacRae, Daniel Teoh, Tim Bannister,
Michael Shamgar, Brendan Phelan, Jonathon Parkinson, Aaron Nankivell, Peter
Hoy, Adrian Cory, Warren Macnab, Tony Wong, Lachlan Tidmarsh, Paul Hahn,
Douglas Fletcher, Usman Malik, Damien MacRae, Vivek Prabhu, Richard Chia</p>

<p>EIGHTH ROW: Patrick Choi, George Jeffreys, Davor Saravanja, Jacob Philips,
Jason Sinclair, David Chinner, Justin Avery, Martin Laslett, Nathan Ward,
Mathew Dolenac, Mark Cocquio, Mr X :), Andrew Norris, Lindsay Halamek,
Mathew Webster, Aravind Adiga, Le Tran, Michael Tidman, Guy Bunn, Adrian
Urquhart</p>

<p>92-059 Year 12 Principal: Mr Michael Quinlan Teacher: Mrs Kowalski</p>

<p><a href="http://www.jamesruse.nsw.edu.au/" target="_blank">James Ruse Agricultural High School</a></p>
	</div>
</div>
</body>
</html>