<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - July 2003 - Q&A letters</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="Q&A letters">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="Q&A letters" href='masterit200301.php'>January 2003</a></li>
<li><a title="Q&A letters" href='masterit200302.php'>February 2003</a></li>
<li><a title="Q&A letters" href='masterit200303.php'>March 2003</a></li>
<li><a title="Q&A letters" href='masterit200304.php'>April 2003</a></li>
<li><a title="Q&A letters" href='masterit200305.php'>May 2003</a></li>
<li><a title="Q&A letters" href='masterit200306.php'>June 2003</a></li>
<li><div class='activemenu'>July 2003</div></li>
<li><a title="Q&A letters" href='masterit200308.php'>August 2003</a></li>
<li><a title="Q&A letters" href='masterit200309.php'>September 2003</a></li>
<li><a title="Q&A letters" href='masterit200310.php'>October 2003</a></li>
<li><a title="Q&A letters" href='masterit200311.php'>November 2003</a></li>
<li><a title="Q&A letters" href='masterit200312.php'>December 2003</a></li>
<li> </li><br><li>Or go back to:</li><li><a title='Q&A/MasterIT letters from 2003' href="masterit2003.php">2003 archive</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>July 2003</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Mark's writing' href="written.php">Professional Writing</a> > <a title='My weekly Q&A column in The Australian' href="masterIT.php">MasterIT</a> > <a title='Q&A/MasterIT letters from 2003' href="masterit2003.php">2003 archive</a> > <a title='Q&A letters' href="masterit200307.php">July 2003</a>
<br><br>		<br>
<h2>1/7/03</h2><br>
<b>I've just upgraded to Windows XP. Most of it's new features are great, however one thing has been driving me up the wall. When I double click on image files, Windows used to open them with a whatever program I had configured as the image. XP defaults to a built-in previewer, and I can't seem to change it. Any ideas?</b><br>
<br>
This is easy to fix, although you'll need to hack your registry to do it. If that sounded scary, don't worry, it's actually pretty easy.<br>
<br>
Just follow the instructions below, but don't deviate from the path or you'll damage your registry, sink below the surface, join the dead ones and light little candles of your own.<br>
<br>
First of all open the registry editor by pressing Windows-R (for run) and then typing "regedit".<br>
<br>
Next, open up the branches on the left to the following:<br>
<br>
HKEY_CLASSES_ROOTSystemFileAssociationsimageShellExContextMenuHandlersShellImagePreview<br>
<br>
Now, clear the value of "(Default)" (on the right) to disable the image previewer.<br>
<br>
An easier alternative is to download a registry patch file that accomplishes the same thing.<br>
<br>
<br>
<b>I am going to buy a new PC, which will have a 60 GB disk; much "bigger" than my current one's 7GB.<br>
<br>
I will be faced with the prospect of partitioning it. I have unsatisfactory knowledge on partitioning; especially on its quantitative aspects - not on HOW to partition, which is easy, but rather why to partition; how many partitions are the optimum; which size(s) to give to each partition; what to put in each partition and why, etc. Could you be so kind as to point me to an article (Internet, or book) where partitioning is dealt with extensively and in a quantitative manner?</b><br>
<br>
Partitioning is one of those things that you get a different answer from depending on who you ask. The Master's personal preference is not to partition at all (in the name of simplicity and performance, but at the expense of some security and flexibility).<br>
<br>
Rather than point at a specific site, your best jumping off point might be groups.google.com - your gateway to opinions and discussions galore.<br>
<br>
<br>
<h2>8/7/03</h2><br>
<b>I have a Celeron 533 Computer and recently I clean installed Windows 2000 Professional (it was running 98). But now I have a new problem. The computer doesn't turn off automatically after I shut down (it would before). Now I have to push the power button on the unit and hold it for four seconds to turn off the computer. Could you please tell me how to solve the problem? Can I do it in Control panel?</b><br>
<br>
First of all, check that you have APM (advanced power management) enabled, if it's available. You'll find this option in Control panel -> Power Options. Select the APM tab (if it exists) and make sure "enable APM" is ticked.<br>
<br>
Failing that, make sure you're running the latest service pack for Windows 2000 (service pack 4 has just been released). You can grab it from Microsoft's website, but be prepared for some download sticker shock - the full version weighs in at around 130mb.<br>
<br>
If that doesn't help, you'll have to play the Update Everything And Reboot 1000 Times Game. Start with your motherboard's BIOS, and then work through any manufacturer's drivers for any expansion cards you might have.<br>
<br>
<br>
<b>Creating Toolbars and establishing Macros seems to result in some other functions in MS Word (2001, Mac Edition, OS 9.2) vanishing; for example the ability to perform left/ right text alignment by using the Apple-l/r.<br>
<br>
Is this a fault in MS Word, is it only on Apple Mac computers, and what can I now do to rectify the problems I have?</b><br>
<br>
Believe it or not, we've been unable to turn up any information on this one - yes, you've stumped the Master!<br>
<br>
The problem would appear to be limited to Macs though - and it also seems quite likely that it is tied to your version of Word and/or OS. Upgrading either may cure the problem, but this is just a shameless guess (the cornerstone of any nutritious helpdesk).<br>
<br>
So we'll throw the question open to the public - if anyone has a solution, let us know. Fame, glory and an insufferable sense of cleverness will be yours for the taking if you do!<br>
<br>
<br>
<h2>15/7/03</h2><br>
<b>Is there a simple program on the market that can be loaded on to a PC to restrict incoming mail to "invitation only" i.e. mail only from those on one's outgoing address list held on the PC. Would this also work for address lists held on external (eg Hotmail) servers?</b><br>
<br>
There are a few programs out there which will let you do something like this. A personal favourite of the Master is Mailwasher (<a href="http://www.mailwasher.net" target="_blank">www.mailwasher.net</a>).<br>
<br>
Mailwasher doesn't link directly in to your address books, but it works on so called black and whitelists - the first time you receive an email from a given person, you have to tell the program if they're a friend or a bottom-feeding, scum-sucking, algae-eating spammer.<br>
<br>
Thereafter you can configure it to automatically delete (and even send a fake bounce message for - sort of a 'return to sender' email) any mail from people on the blacklist.<br>
<br>
Mailwasher used to be completely free, now it's been split up into a free and "pro" version. You'll need the pro version to check Hotmail - you can download a 30 day trial first though to see if you like it.<br>
<br>
There's a more in-depth article on Mailwasher at <a href="http://www.dansdata.com/mailwasher.htm" target="_blank">www.dansdata.com/mailwasher.htm</a>.<br>
<br>
<br>
<b>I am not getting notification of Windows 2000 patches and updates any more, they used to come up regularly; did I turn off something by mistake or did they stop? Can I get the auto-notifications back?</b><br>
<br>
Well, the updates haven't stopped. The day Microsoft gets it right is also likely to involve various trumpets sounding and people eating snow cones in Hell.<br>
<br>
However, Microsoft did change the way the Win2000 notification system worked a while back. You may need to install service pack 3 (or the newly released 4) to switch over to the new system.<br>
<br>
Once installed, notification options can be set  by going to Control Panel and double-clicking Automatic Updates.<br>
<br>
Windows XP also supports this feature by default - you can get at it in Control Panel, System options. It's under the "automatic updates" tag.<br>
<br>
Bear in mind also that it's a good idea to check <a href="http://www.windowsupdate.com" target="_blank">www.windowsupdate.com</a> for non-critical updates every now and then.<br>
<br>
<br>
<h2>22/7/03</h2><br>
<b>Some time ago, a friend showed me how to bring up a page that showed all the "repeater stations" that linked my computer with the destination. There were about twenty stations, and even while we watched, some stations disappeared and some were added. This information was shown as a list of numbers, like telephone numbers, so there was no information as to which countries were involved. Would it be possible for you to give me the key combination to (a) bring up the list of repeater stations as numbers (b) have the numbers translated into towns or countries?</b><br>
<br>
It's most likely that your friend showed you how to do what's a called a "tracert" (geek speak, pronounced "trace route").<br>
<br>
Most operating systems will have this command for this built in - in Windows you need to open a command prompt and then type "tracert", followed by the internet address of the computer you wish to trace a path to (your computer's address is the source).<br>
<br>
The list that's displayed shows you which other machines your data packets will pass through on the way to their destination, and how long it took each machine to respond. If you're finding a particular website slow, doing a tracert can sometimes show you where the bottleneck is.<br>
<br>
It is possible, in a lot of cases, to find out where these machines are located, but the information isn't trivial to retrieve. Also, bear in mind that this information is not always accurate - it shouldn't be taken as gospel by a long shot.<br>
<br>
We had a quick dig around and discovered a couple of neat toys that find as much geographical information as they can, and give it to you in a pretty map-of-the-world view.<br>
<br>
<a href="http://visualroute.brd.net.au" target="_blank">visualroute.brd.net.au</a> is one example - you can play online (in a limited fashion).<br>
<br>
We also dug up a neat little program called NeoTrace Pro - it's since been taken over by McAfee, but you can still download the trial version from <a href="http://www.download.com" target="_blank">www.download.com</a>; just do a search for "NeoTrace Pro". It comes complete with bells and whistles (literally), and is really easy use.<br>
<br>
<br>
<h2>29/7/03</h2><br>
<b>We produce a monthly newsletter in MS Publisher 2002 on Win XP Pro. We also produce a PDF version from the Publisher file using the Adobe Universal PostScript Driver. We take the PostScript files to Acrobat Distiller (5.05) on a Mac using the ebook job option. When we view the resulting PDF, all scanned images and most clipart graphics are monochrome. How do we'd get a full colour PDF?</b><br>
<br>
The first thing to do here is to work out where the problem is being introduced.<br>
<br>
Try looking at the postscript file using a postscript viewer (Postscript is actually a language designed for printers). One common one is Ghostscript, available at <a href="http://www.cs.wisc.edu/~ghost" target="_blank">www.cs.wisc.edu/~ghost</a>.<br>
<br>
If the images are not in colour at this stage, your problem lies somewhere with Publisher or the Postscript print driver. There may be a setting that reduces the coloured images to monochrome to make them print better.<br>
<br>
On the other hand, if the images are still in colour at this point the problem is being introduced by Distiller. There may also be a setting somewhere to make Distiller convert images to monochrome.<br>
<br>
It may even be a bug with Distiller, in which the case the simplest answer would be to use a different PDF conversion process. For example you could use "pdfFactory Pro" (available at <a href="http://www.fineprint.com" target="_blank">www.fineprint.com</a>) to print directly from Publisher to PDF under XP.<br>
<br>
<b>Also, the size of our PDFs are generally 1.4-1.6 MB and I've recently started splitting them into two parts for the purpose of emailing. This works well but we occasionally still have problems - could you recommend a file size that we should not exceed for emailing?</b><br>
<br>
There's no hard and fast rule for this; it depends on how big the recipient's inbox is and how full it is when you send them your message.<br>
<br>
A good rule of thumb (and etiquette) is to ask people before you send then anything in excess of 500k, unless you know for sure they can receive it.<br>
<br>
Remember too that even if someone successfully receives your particular e-elephant, it might fill their mailbox to the extent where other people's emails to this person start to bounce.<br>
<br>
<i><p>Did the information on this page help you? Entertain you? Bore you? <a href="contact.php?subject=MasterIT">Drop me a line</a>.</p>

<p>If you're feeling particularly generous, you can even <a href="buypics.php">click here to send me some dot-com riches</a>. Think of it as online busking.</i></p>
	</div>
</div>
</body>
</html>