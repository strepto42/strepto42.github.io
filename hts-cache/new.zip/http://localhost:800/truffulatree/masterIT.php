<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - MasterIT - My weekly Q&A column in The Australian</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="My weekly Q&A column in The Australian">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><div class='activemenu'>MasterIT</div></li>
<ul>
<li><a title="Q&A/MasterIT letters from 2003" href='masterit2003.php'>2003 archive</a></li>
<li><a title="Q&A/MasterIT letters from 2004" href='masterit2004.php'>2004 archive</a></li>
<li><a title="Q&A/MasterIT letters from 2005" href='masterit2005.php'>2005 archive</a></li>
<li><a title="Q&A/MasterIT letters from 2006" href='masterit2006.php'>2006 archive</a></li>
<li><a title="Q&A letters from 2007" href='masterit2007.php'>2007 archive</a></li>
</ul>
<li> </li><br><li>Or go back to:</li><li><a title='Mark's writing' href="written.php">Professional Writing</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>MasterIT</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Mark's writing' href="written.php">Professional Writing</a> > <a title='My weekly Q&A column in The Australian' href="masterIT.php">MasterIT</a>
<br>Select a link on the left to continue navigating.<br><br>		<br>
From January 2003 to July 2007, I wrote the IT letters column for The Australian newspaper. First it was called "MasterIT" (which was nice, because people would write to me starting with "Dear Master...") and it appeared in the IT Alive section. Then in late 2005 it got renamed to the rather dull "Q&amp;A" column, when they changed the name of the section to <a href="http://www.australianit.news.com.au/exectech/" target="_blank">Exec Tech</a>.<br>
<br>
Anyway, people would send me their problems, and I would <s>have a good laugh</s> help them sort them out <a href="http://www.digi-comic.com/?comicId=2" target="_blank">(My mate Nathan's parody notwithstanding)</a>.<br>
<br>
Eventually, The Australian finally started putting up the Q&amp;A columns onto the <a href="http://www.australianit.news.com.au/" target="_blank">Australian IT</a> website. Unfortunately, about 6 weeks later, they axed it completely, without warning - so I didn't get to say thank you to my readers. <b>Well, thank you!</b> I wouldn't have had a column without your questions.<br>
<br>
So, at long last, I've finally put up all of the old columns here. You can select by clicking the year above, and then the month.<br>
<br>
If you'd like help with a particular problem, feel free to <a href="contact.php?subject=MasterIT">contact me though the website</a>. <a href="buypics.php">Placing a coin into my hat</a> will of course make me feel much warmer and fuzzier about replying to you, but please note that it is far from necessary. I don't want to be too mercenary about things, after all!<br>
<br>
I'd also like to point out that there's absolutely nothing I can do to prevent you from <a href="http://www.australianit.news.com.au/contactus" target="_blank">hassling the editors at The Australian</a> to bring back my column. ;)<br>
<br>
The links to files below are things I've referred to in one column or another, that I've subsequently made available on my site for download. Eventually I'll reorganise them more properly.<br>
<br><br>
Files available for download:<br>
<ul class="dirlist"><li><a href="files/masterit/cdtools.zip">cdtools.zip</a></li><li><a href="files/masterit/diskexplorer.zip">diskexplorer.zip</a></li><li><a href="files/masterit/notmad_cpu_affinity_fix.reg">notmad_cpu_affinity_fix.reg</a></li><li><a href="files/masterit/pvpatch.zip">pvpatch.zip</a></li><li><a href="files/masterit/termservices_multi_patch.zip">termservices_multi_patch.zip</a></li></ul><!-- old method
getTheFiles($file);

function getTheFiles($folder) {
	if ($handle = opendir($folder)) {
		while (false !== ($file = readdir($handle))) {
			If ($file!= "." && $file!= ".." and !is_dir($folder."/".$file)) {
				$filesize = round(filesize ($folder."/".$file)/1024,2);
				echo "<tr><td><div align='left'><A href='$corelise$folder/$file'>$file</a></div></td><td><div align='left'>$filesize KB</div></td><tr>\n";
			} else {
			If ($file!= "." && $file!= ".." and is_dir($folder."/".$file)) {
				getTheFiles($file);
			}
		}
		closedir($handle);
	}
} -->
	</div>
</div>
</body>
</html>