<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - Sydney, April 06 - Sydney trip - April '06</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="Sydney trip - April '06">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="Pictures of my 28th Birthday party complete with Sparkler Bomb" href='28th.php'>28th Birthday</a></li>
<li><a title="Pictures of my 30th Birthday party" href='30th.php'>30th Birthday</a></li>
<li><a title="Michael Shamgar and Lindsay Halamek's 30th birthday bash photos" href='sl30th.php'>Shams & Linds' 30th</a></li>
<li><a title="Pictures of Andy Marinos's new flat, cat Toby, and Mum Pam Swain" href='andycatandflat.php'>Andy's Cat & Flat</a></li>
<li><a title="Pictures of a visit to Stephen Jackson's Farm" href='jackovisit.php'>Jacko's Farm</a></li>
<li><a title="Pictures taken at the Peace Convergence action in Rockhampton and Yeppoon in June 2005 to protest the joint US Australia military exercises (Operation Talisman Sabre)" href='peaceconvergence.php'>Peace Convergence</a></li>
<li><div class='activemenu'>Sydney, April 06</div></li>
<li><a title="Pics of Naima's 28th birthday dinner" href='mim28th.php'>Naima's 28th</a></li>
<li><a title="Brisbane CBD and the Story Bridge" href='brisbanepics1.php'>Brissie by Night 1</a></li>
<li><a title="Lamington National Park" href='lamington.php'>Lamington NP</a></li>
<li><a title="Various creatures and views from our Brisbane back yard" href='backyard.php'>Backyard Creatures</a></li>
<li><a title="Opening day of the Eleanor Schonell (Green) Bridge" href='greenbridge.php'>Green Bridge</a></li>
<li><a title="Pictutres from the 2006 Woodford Folk Festival" href='woodford0607.php'>Woodford 2006-2007</a></li>
<li><a title="One Cute Puppy" href='jezebel.php'>Jezebel</a></li>
<li><a title="Climbing at Kangaroo Point Cliffs" href='kangaroopt1.php'>Heather's Visit</a></li>
<li><a title="0x0021st (33rd) birthday celebrations" href='0x0021st.php'>0x0021st Birthday</a></li>
<li><a title="Nuptial photography" href='guyandalison.php'>Guy and Alison's Wedding</a></li>
<li><a title="Pictures from the 2007 Woodford Folk Festival" href='woodford0708.php'>Woodford 2007-2008</a></li>
<li><a title="Image gallery" href='sydneytrip0802.php'>Sydney & Yacaaba Head</a></li>
<li><a title="An impressive show by nature" href='lightning.php'>Thunderstorm Moonrise</a></li>
<li><a title="Frightening pictures of a shrinking beard" href='debearding.php'>De-bearding</a></li>
<li><a title="More Nuptial Photography" href='michaelandkaren.php'>Michael and Karen's Wedding</a></li>
<li><a title="A night of celebration" href='andrews21st.php'>Andrew's 21st</a></li>
<li><a title="Image Gallery" href='bloodyknee.php'>Bloody Knee</a></li>
<li><a title="Image Gallery" href='tyesbirthday.php'>Tye's Birthday</a></li>
<li><a title="Image Gallery" href='lasersocialising.php'>Laser Socialising</a></li>
<li><a title="Image Gallery" href='heatherandevan.php'>Heather and Evan's Wedding</a></li>
<li><a title="Image Gallery" href='woodford0809.php'>Woodford 2008-2009</a></li>
<li><a title="Image Gallery" href='allyandben.php'>Ally and Ben's Wedding</a></li>
<li><a title="Image Gallery" href='annes30th.php'>Anne's 30th</a></li>
<li><a title="Image Gallery" href='possumcreek.php'>Possum Creek</a></li>
<li><a title="Image Gallery" href='jamnight.php'>Jam Night</a></li>
<li><a title="Image Gallery" href='cunninghamsgap.php'>Cunningham's Gap</a></li>
<li><a title="Image Gallery" href='bigcat.php'>Diving on Big Cat</a></li>
<li><a title="Images from my birthday jam" href='birthdayjam.php'>Music, mayhem and merriment</a></li>
<li><a title="Image Gallery" href='fuzzypolaroidpics.php'>Fuzzy Polaroid</a></li>
<li><a title="Image Gallery" href='zombiewalk2009.php'>2009 Zombie Walk</a></li>
<li> </li><br><li>Or go back to:</li><li><a title='Picture galleries' href="pictures.php">Photography</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>Sydney, April 06</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Picture galleries' href="pictures.php">Photography</a> > <a title='Sydney trip - April '06' href="bridges.php">Sydney, April 06</a>
<br><br>		


<h1>Sydney trip - April '06</h1>

<p>Here are the photos from my recent trip down to Sydney. Somehow, it's ended up being a study in bridges, with the Harbour Bridge, Gladesville Bridge, Anzac Bridge, Iron Cove Bridge and Meadowbank Bridge all featuring.</p>

<p>There are also photos of Daniel and Anne's Good Friday party, and various others taken with family and friends along the way.</p>

<br><br>
All images in this gallery:<br>
<table width='800'>
<tr>
</tr>
<tr><td><A ID='IMG_8645.JPG' href='bridges.php?fileId=IMG_8645.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060421/IMG_8645.JPG' ALT='IMG_8645.JPG'><BR>IMG_8645.JPG<br>56.85 KB</a><div class='inv'><br><a href='./images/20060421/IMG_8645.JPG' ALT='IMG_8645.JPG'>IMG_8645.JPG</a></div></td>
<td><A ID='IMG_8649.JPG' href='bridges.php?fileId=IMG_8649.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060421/IMG_8649.JPG' ALT='IMG_8649.JPG'><BR>IMG_8649.JPG<br>83.03 KB</a><div class='inv'><br><a href='./images/20060421/IMG_8649.JPG' ALT='IMG_8649.JPG'>IMG_8649.JPG</a></div></td>
<td><A ID='IMG_8651.JPG' href='bridges.php?fileId=IMG_8651.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060421/IMG_8651.JPG' ALT='IMG_8651.JPG'><BR>IMG_8651.JPG<br>58.7 KB</a><div class='inv'><br><a href='./images/20060421/IMG_8651.JPG' ALT='IMG_8651.JPG'>IMG_8651.JPG</a></div></td>
<td><A ID='IMG_8656.JPG' href='bridges.php?fileId=IMG_8656.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060421/IMG_8656.JPG' ALT='IMG_8656.JPG'><BR>IMG_8656.JPG<br>61.91 KB</a><div class='inv'><br><a href='./images/20060421/IMG_8656.JPG' ALT='IMG_8656.JPG'>IMG_8656.JPG</a></div></td>
<td><A ID='IMG_8657.JPG' href='bridges.php?fileId=IMG_8657.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060421/IMG_8657.JPG' ALT='IMG_8657.JPG'><BR>IMG_8657.JPG<br>51.25 KB</a><div class='inv'><br><a href='./images/20060421/IMG_8657.JPG' ALT='IMG_8657.JPG'>IMG_8657.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_8663.JPG' href='bridges.php?fileId=IMG_8663.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060421/IMG_8663.JPG' ALT='IMG_8663.JPG'><BR>IMG_8663.JPG<br>53.72 KB</a><div class='inv'><br><a href='./images/20060421/IMG_8663.JPG' ALT='IMG_8663.JPG'>IMG_8663.JPG</a></div></td>
<td><A ID='IMG_8666.JPG' href='bridges.php?fileId=IMG_8666.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060421/IMG_8666.JPG' ALT='IMG_8666.JPG'><BR>IMG_8666.JPG<br>63.02 KB</a><div class='inv'><br><a href='./images/20060421/IMG_8666.JPG' ALT='IMG_8666.JPG'>IMG_8666.JPG</a></div></td>
<td><A ID='IMG_8669.JPG' href='bridges.php?fileId=IMG_8669.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060421/IMG_8669.JPG' ALT='IMG_8669.JPG'><BR>IMG_8669.JPG<br>77.96 KB</a><div class='inv'><br><a href='./images/20060421/IMG_8669.JPG' ALT='IMG_8669.JPG'>IMG_8669.JPG</a></div></td>
<td><A ID='IMG_8675.JPG' href='bridges.php?fileId=IMG_8675.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060421/IMG_8675.JPG' ALT='IMG_8675.JPG'><BR>IMG_8675.JPG<br>55.13 KB</a><div class='inv'><br><a href='./images/20060421/IMG_8675.JPG' ALT='IMG_8675.JPG'>IMG_8675.JPG</a></div></td>
<td><A ID='IMG_8695.JPG' href='bridges.php?fileId=IMG_8695.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060421/IMG_8695.JPG' ALT='IMG_8695.JPG'><BR>IMG_8695.JPG<br>83.77 KB</a><div class='inv'><br><a href='./images/20060421/IMG_8695.JPG' ALT='IMG_8695.JPG'>IMG_8695.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_8703.JPG' href='bridges.php?fileId=IMG_8703.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060421/IMG_8703.JPG' ALT='IMG_8703.JPG'><BR>IMG_8703.JPG<br>72.78 KB</a><div class='inv'><br><a href='./images/20060421/IMG_8703.JPG' ALT='IMG_8703.JPG'>IMG_8703.JPG</a></div></td>
<td><A ID='IMG_8716.JPG' href='bridges.php?fileId=IMG_8716.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060421/IMG_8716.JPG' ALT='IMG_8716.JPG'><BR>IMG_8716.JPG<br>59.97 KB</a><div class='inv'><br><a href='./images/20060421/IMG_8716.JPG' ALT='IMG_8716.JPG'>IMG_8716.JPG</a></div></td>
<td><A ID='IMG_8721.JPG' href='bridges.php?fileId=IMG_8721.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060421/IMG_8721.JPG' ALT='IMG_8721.JPG'><BR>IMG_8721.JPG<br>76.9 KB</a><div class='inv'><br><a href='./images/20060421/IMG_8721.JPG' ALT='IMG_8721.JPG'>IMG_8721.JPG</a></div></td>
<td><A ID='IMG_8729.JPG' href='bridges.php?fileId=IMG_8729.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060421/IMG_8729.JPG' ALT='IMG_8729.JPG'><BR>IMG_8729.JPG<br>75.98 KB</a><div class='inv'><br><a href='./images/20060421/IMG_8729.JPG' ALT='IMG_8729.JPG'>IMG_8729.JPG</a></div></td>
<td><A ID='IMG_8734.JPG' href='bridges.php?fileId=IMG_8734.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060421/IMG_8734.JPG' ALT='IMG_8734.JPG'><BR>IMG_8734.JPG<br>63.12 KB</a><div class='inv'><br><a href='./images/20060421/IMG_8734.JPG' ALT='IMG_8734.JPG'>IMG_8734.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_8739.JPG' href='bridges.php?fileId=IMG_8739.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060421/IMG_8739.JPG' ALT='IMG_8739.JPG'><BR>IMG_8739.JPG<br>73.2 KB</a><div class='inv'><br><a href='./images/20060421/IMG_8739.JPG' ALT='IMG_8739.JPG'>IMG_8739.JPG</a></div></td>
<td><A ID='IMG_8740.JPG' href='bridges.php?fileId=IMG_8740.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060421/IMG_8740.JPG' ALT='IMG_8740.JPG'><BR>IMG_8740.JPG<br>53.46 KB</a><div class='inv'><br><a href='./images/20060421/IMG_8740.JPG' ALT='IMG_8740.JPG'>IMG_8740.JPG</a></div></td>
<td><A ID='IMG_8744.JPG' href='bridges.php?fileId=IMG_8744.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060421/IMG_8744.JPG' ALT='IMG_8744.JPG'><BR>IMG_8744.JPG<br>58.97 KB</a><div class='inv'><br><a href='./images/20060421/IMG_8744.JPG' ALT='IMG_8744.JPG'>IMG_8744.JPG</a></div></td>
<td><A ID='IMG_8748.JPG' href='bridges.php?fileId=IMG_8748.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060421/IMG_8748.JPG' ALT='IMG_8748.JPG'><BR>IMG_8748.JPG<br>57.23 KB</a><div class='inv'><br><a href='./images/20060421/IMG_8748.JPG' ALT='IMG_8748.JPG'>IMG_8748.JPG</a></div></td>
<td><A ID='IMG_8749.JPG' href='bridges.php?fileId=IMG_8749.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060421/IMG_8749.JPG' ALT='IMG_8749.JPG'><BR>IMG_8749.JPG<br>85.1 KB</a><div class='inv'><br><a href='./images/20060421/IMG_8749.JPG' ALT='IMG_8749.JPG'>IMG_8749.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_8751.JPG' href='bridges.php?fileId=IMG_8751.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060421/IMG_8751.JPG' ALT='IMG_8751.JPG'><BR>IMG_8751.JPG<br>59.45 KB</a><div class='inv'><br><a href='./images/20060421/IMG_8751.JPG' ALT='IMG_8751.JPG'>IMG_8751.JPG</a></div></td>
<td><A ID='IMG_8761.JPG' href='bridges.php?fileId=IMG_8761.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060421/IMG_8761.JPG' ALT='IMG_8761.JPG'><BR>IMG_8761.JPG<br>73.2 KB</a><div class='inv'><br><a href='./images/20060421/IMG_8761.JPG' ALT='IMG_8761.JPG'>IMG_8761.JPG</a></div></td>
<td><A ID='IMG_8777.JPG' href='bridges.php?fileId=IMG_8777.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060421/IMG_8777.JPG' ALT='IMG_8777.JPG'><BR>IMG_8777.JPG<br>59.62 KB</a><div class='inv'><br><a href='./images/20060421/IMG_8777.JPG' ALT='IMG_8777.JPG'>IMG_8777.JPG</a></div></td>
<td><A ID='IMG_8786.JPG' href='bridges.php?fileId=IMG_8786.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060421/IMG_8786.JPG' ALT='IMG_8786.JPG'><BR>IMG_8786.JPG<br>72.37 KB</a><div class='inv'><br><a href='./images/20060421/IMG_8786.JPG' ALT='IMG_8786.JPG'>IMG_8786.JPG</a></div></td>
<td><A ID='IMG_8788.JPG' href='bridges.php?fileId=IMG_8788.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060421/IMG_8788.JPG' ALT='IMG_8788.JPG'><BR>IMG_8788.JPG<br>79.18 KB</a><div class='inv'><br><a href='./images/20060421/IMG_8788.JPG' ALT='IMG_8788.JPG'>IMG_8788.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_8793.JPG' href='bridges.php?fileId=IMG_8793.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060421/IMG_8793.JPG' ALT='IMG_8793.JPG'><BR>IMG_8793.JPG<br>88.82 KB</a><div class='inv'><br><a href='./images/20060421/IMG_8793.JPG' ALT='IMG_8793.JPG'>IMG_8793.JPG</a></div></td>
<td><A ID='IMG_8798.JPG' href='bridges.php?fileId=IMG_8798.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060421/IMG_8798.JPG' ALT='IMG_8798.JPG'><BR>IMG_8798.JPG<br>81.34 KB</a><div class='inv'><br><a href='./images/20060421/IMG_8798.JPG' ALT='IMG_8798.JPG'>IMG_8798.JPG</a></div></td>
<td><A ID='IMG_8804.JPG' href='bridges.php?fileId=IMG_8804.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060421/IMG_8804.JPG' ALT='IMG_8804.JPG'><BR>IMG_8804.JPG<br>44.62 KB</a><div class='inv'><br><a href='./images/20060421/IMG_8804.JPG' ALT='IMG_8804.JPG'>IMG_8804.JPG</a></div></td>
<td><A ID='IMG_8817.JPG' href='bridges.php?fileId=IMG_8817.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060421/IMG_8817.JPG' ALT='IMG_8817.JPG'><BR>IMG_8817.JPG<br>50.2 KB</a><div class='inv'><br><a href='./images/20060421/IMG_8817.JPG' ALT='IMG_8817.JPG'>IMG_8817.JPG</a></div></td>
<td><A ID='IMG_8819.JPG' href='bridges.php?fileId=IMG_8819.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060421/IMG_8819.JPG' ALT='IMG_8819.JPG'><BR>IMG_8819.JPG<br>56.21 KB</a><div class='inv'><br><a href='./images/20060421/IMG_8819.JPG' ALT='IMG_8819.JPG'>IMG_8819.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_8832.JPG' href='bridges.php?fileId=IMG_8832.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060421/IMG_8832.JPG' ALT='IMG_8832.JPG'><BR>IMG_8832.JPG<br>43.29 KB</a><div class='inv'><br><a href='./images/20060421/IMG_8832.JPG' ALT='IMG_8832.JPG'>IMG_8832.JPG</a></div></td>
<td><A ID='IMG_8855.JPG' href='bridges.php?fileId=IMG_8855.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060421/IMG_8855.JPG' ALT='IMG_8855.JPG'><BR>IMG_8855.JPG<br>62.81 KB</a><div class='inv'><br><a href='./images/20060421/IMG_8855.JPG' ALT='IMG_8855.JPG'>IMG_8855.JPG</a></div></td>
<td><A ID='IMG_8856.JPG' href='bridges.php?fileId=IMG_8856.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060421/IMG_8856.JPG' ALT='IMG_8856.JPG'><BR>IMG_8856.JPG<br>71.21 KB</a><div class='inv'><br><a href='./images/20060421/IMG_8856.JPG' ALT='IMG_8856.JPG'>IMG_8856.JPG</a></div></td>
<td><A ID='IMG_8859.JPG' href='bridges.php?fileId=IMG_8859.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060421/IMG_8859.JPG' ALT='IMG_8859.JPG'><BR>IMG_8859.JPG<br>64.08 KB</a><div class='inv'><br><a href='./images/20060421/IMG_8859.JPG' ALT='IMG_8859.JPG'>IMG_8859.JPG</a></div></td>
<td><A ID='IMG_8862.JPG' href='bridges.php?fileId=IMG_8862.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060421/IMG_8862.JPG' ALT='IMG_8862.JPG'><BR>IMG_8862.JPG<br>65.89 KB</a><div class='inv'><br><a href='./images/20060421/IMG_8862.JPG' ALT='IMG_8862.JPG'>IMG_8862.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_8863.JPG' href='bridges.php?fileId=IMG_8863.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060421/IMG_8863.JPG' ALT='IMG_8863.JPG'><BR>IMG_8863.JPG<br>64.05 KB</a><div class='inv'><br><a href='./images/20060421/IMG_8863.JPG' ALT='IMG_8863.JPG'>IMG_8863.JPG</a></div></td>
<td><A ID='IMG_8864.JPG' href='bridges.php?fileId=IMG_8864.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060421/IMG_8864.JPG' ALT='IMG_8864.JPG'><BR>IMG_8864.JPG<br>66.72 KB</a><div class='inv'><br><a href='./images/20060421/IMG_8864.JPG' ALT='IMG_8864.JPG'>IMG_8864.JPG</a></div></td>
<td><A ID='IMG_8871.JPG' href='bridges.php?fileId=IMG_8871.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060421/IMG_8871.JPG' ALT='IMG_8871.JPG'><BR>IMG_8871.JPG<br>68.36 KB</a><div class='inv'><br><a href='./images/20060421/IMG_8871.JPG' ALT='IMG_8871.JPG'>IMG_8871.JPG</a></div></td>
<td><A ID='IMG_8873.JPG' href='bridges.php?fileId=IMG_8873.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060421/IMG_8873.JPG' ALT='IMG_8873.JPG'><BR>IMG_8873.JPG<br>73.7 KB</a><div class='inv'><br><a href='./images/20060421/IMG_8873.JPG' ALT='IMG_8873.JPG'>IMG_8873.JPG</a></div></td>
<td><A ID='IMG_8881.JPG' href='bridges.php?fileId=IMG_8881.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060421/IMG_8881.JPG' ALT='IMG_8881.JPG'><BR>IMG_8881.JPG<br>72.33 KB</a><div class='inv'><br><a href='./images/20060421/IMG_8881.JPG' ALT='IMG_8881.JPG'>IMG_8881.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_8882.JPG' href='bridges.php?fileId=IMG_8882.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060421/IMG_8882.JPG' ALT='IMG_8882.JPG'><BR>IMG_8882.JPG<br>81.49 KB</a><div class='inv'><br><a href='./images/20060421/IMG_8882.JPG' ALT='IMG_8882.JPG'>IMG_8882.JPG</a></div></td>
<td><A ID='IMG_8884.JPG' href='bridges.php?fileId=IMG_8884.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060421/IMG_8884.JPG' ALT='IMG_8884.JPG'><BR>IMG_8884.JPG<br>50.86 KB</a><div class='inv'><br><a href='./images/20060421/IMG_8884.JPG' ALT='IMG_8884.JPG'>IMG_8884.JPG</a></div></td>
<td><A ID='IMG_8888.JPG' href='bridges.php?fileId=IMG_8888.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060421/IMG_8888.JPG' ALT='IMG_8888.JPG'><BR>IMG_8888.JPG<br>68.24 KB</a><div class='inv'><br><a href='./images/20060421/IMG_8888.JPG' ALT='IMG_8888.JPG'>IMG_8888.JPG</a></div></td>
<td><A ID='IMG_8890.JPG' href='bridges.php?fileId=IMG_8890.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060421/IMG_8890.JPG' ALT='IMG_8890.JPG'><BR>IMG_8890.JPG<br>49.3 KB</a><div class='inv'><br><a href='./images/20060421/IMG_8890.JPG' ALT='IMG_8890.JPG'>IMG_8890.JPG</a></div></td>
<td><A ID='IMG_8892.JPG' href='bridges.php?fileId=IMG_8892.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060421/IMG_8892.JPG' ALT='IMG_8892.JPG'><BR>IMG_8892.JPG<br>62.21 KB</a><div class='inv'><br><a href='./images/20060421/IMG_8892.JPG' ALT='IMG_8892.JPG'>IMG_8892.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_8894.JPG' href='bridges.php?fileId=IMG_8894.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060421/IMG_8894.JPG' ALT='IMG_8894.JPG'><BR>IMG_8894.JPG<br>77.91 KB</a><div class='inv'><br><a href='./images/20060421/IMG_8894.JPG' ALT='IMG_8894.JPG'>IMG_8894.JPG</a></div></td>
<td><A ID='IMG_8896.JPG' href='bridges.php?fileId=IMG_8896.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060421/IMG_8896.JPG' ALT='IMG_8896.JPG'><BR>IMG_8896.JPG<br>71.17 KB</a><div class='inv'><br><a href='./images/20060421/IMG_8896.JPG' ALT='IMG_8896.JPG'>IMG_8896.JPG</a></div></td>
<td><A ID='IMG_8898.JPG' href='bridges.php?fileId=IMG_8898.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060421/IMG_8898.JPG' ALT='IMG_8898.JPG'><BR>IMG_8898.JPG<br>58.25 KB</a><div class='inv'><br><a href='./images/20060421/IMG_8898.JPG' ALT='IMG_8898.JPG'>IMG_8898.JPG</a></div></td>
<td><A ID='IMG_8905.JPG' href='bridges.php?fileId=IMG_8905.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060421/IMG_8905.JPG' ALT='IMG_8905.JPG'><BR>IMG_8905.JPG<br>141.24 KB</a><div class='inv'><br><a href='./images/20060421/IMG_8905.JPG' ALT='IMG_8905.JPG'>IMG_8905.JPG</a></div></td>
<td><A ID='IMG_8908.JPG' href='bridges.php?fileId=IMG_8908.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060421/IMG_8908.JPG' ALT='IMG_8908.JPG'><BR>IMG_8908.JPG<br>77.58 KB</a><div class='inv'><br><a href='./images/20060421/IMG_8908.JPG' ALT='IMG_8908.JPG'>IMG_8908.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_8909.JPG' href='bridges.php?fileId=IMG_8909.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060421/IMG_8909.JPG' ALT='IMG_8909.JPG'><BR>IMG_8909.JPG<br>69.25 KB</a><div class='inv'><br><a href='./images/20060421/IMG_8909.JPG' ALT='IMG_8909.JPG'>IMG_8909.JPG</a></div></td>
<td><A ID='IMG_8913.JPG' href='bridges.php?fileId=IMG_8913.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060421/IMG_8913.JPG' ALT='IMG_8913.JPG'><BR>IMG_8913.JPG<br>108.92 KB</a><div class='inv'><br><a href='./images/20060421/IMG_8913.JPG' ALT='IMG_8913.JPG'>IMG_8913.JPG</a></div></td>
<td><A ID='IMG_8915.JPG' href='bridges.php?fileId=IMG_8915.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060421/IMG_8915.JPG' ALT='IMG_8915.JPG'><BR>IMG_8915.JPG<br>61.42 KB</a><div class='inv'><br><a href='./images/20060421/IMG_8915.JPG' ALT='IMG_8915.JPG'>IMG_8915.JPG</a></div></td>
<td><A ID='IMG_8918.JPG' href='bridges.php?fileId=IMG_8918.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060421/IMG_8918.JPG' ALT='IMG_8918.JPG'><BR>IMG_8918.JPG<br>54.21 KB</a><div class='inv'><br><a href='./images/20060421/IMG_8918.JPG' ALT='IMG_8918.JPG'>IMG_8918.JPG</a></div></td>
<td><A ID='IMG_8920.JPG' href='bridges.php?fileId=IMG_8920.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060421/IMG_8920.JPG' ALT='IMG_8920.JPG'><BR>IMG_8920.JPG<br>52.88 KB</a><div class='inv'><br><a href='./images/20060421/IMG_8920.JPG' ALT='IMG_8920.JPG'>IMG_8920.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_8924.JPG' href='bridges.php?fileId=IMG_8924.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060421/IMG_8924.JPG' ALT='IMG_8924.JPG'><BR>IMG_8924.JPG<br>91.98 KB</a><div class='inv'><br><a href='./images/20060421/IMG_8924.JPG' ALT='IMG_8924.JPG'>IMG_8924.JPG</a></div></td>
<td><A ID='IMG_8925.JPG' href='bridges.php?fileId=IMG_8925.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060421/IMG_8925.JPG' ALT='IMG_8925.JPG'><BR>IMG_8925.JPG<br>77.34 KB</a><div class='inv'><br><a href='./images/20060421/IMG_8925.JPG' ALT='IMG_8925.JPG'>IMG_8925.JPG</a></div></td>
<td><A ID='IMG_8927.JPG' href='bridges.php?fileId=IMG_8927.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060421/IMG_8927.JPG' ALT='IMG_8927.JPG'><BR>IMG_8927.JPG<br>90.34 KB</a><div class='inv'><br><a href='./images/20060421/IMG_8927.JPG' ALT='IMG_8927.JPG'>IMG_8927.JPG</a></div></td>
<td><A ID='IMG_8929.JPG' href='bridges.php?fileId=IMG_8929.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060421/IMG_8929.JPG' ALT='IMG_8929.JPG'><BR>IMG_8929.JPG<br>72.94 KB</a><div class='inv'><br><a href='./images/20060421/IMG_8929.JPG' ALT='IMG_8929.JPG'>IMG_8929.JPG</a></div></td>
<td><A ID='IMG_8939.JPG' href='bridges.php?fileId=IMG_8939.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060421/IMG_8939.JPG' ALT='IMG_8939.JPG'><BR>IMG_8939.JPG<br>55.14 KB</a><div class='inv'><br><a href='./images/20060421/IMG_8939.JPG' ALT='IMG_8939.JPG'>IMG_8939.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_8944.JPG' href='bridges.php?fileId=IMG_8944.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060421/IMG_8944.JPG' ALT='IMG_8944.JPG'><BR>IMG_8944.JPG<br>64.25 KB</a><div class='inv'><br><a href='./images/20060421/IMG_8944.JPG' ALT='IMG_8944.JPG'>IMG_8944.JPG</a></div></td>
<td><A ID='IMG_8959.JPG' href='bridges.php?fileId=IMG_8959.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060421/IMG_8959.JPG' ALT='IMG_8959.JPG'><BR>IMG_8959.JPG<br>84.31 KB</a><div class='inv'><br><a href='./images/20060421/IMG_8959.JPG' ALT='IMG_8959.JPG'>IMG_8959.JPG</a></div></td>
<td><A ID='IMG_8962.JPG' href='bridges.php?fileId=IMG_8962.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060421/IMG_8962.JPG' ALT='IMG_8962.JPG'><BR>IMG_8962.JPG<br>59.69 KB</a><div class='inv'><br><a href='./images/20060421/IMG_8962.JPG' ALT='IMG_8962.JPG'>IMG_8962.JPG</a></div></td>
<td><A ID='IMG_8964.JPG' href='bridges.php?fileId=IMG_8964.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060421/IMG_8964.JPG' ALT='IMG_8964.JPG'><BR>IMG_8964.JPG<br>54.94 KB</a><div class='inv'><br><a href='./images/20060421/IMG_8964.JPG' ALT='IMG_8964.JPG'>IMG_8964.JPG</a></div></td>
<td><A ID='IMG_8969.JPG' href='bridges.php?fileId=IMG_8969.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060421/IMG_8969.JPG' ALT='IMG_8969.JPG'><BR>IMG_8969.JPG<br>55.56 KB</a><div class='inv'><br><a href='./images/20060421/IMG_8969.JPG' ALT='IMG_8969.JPG'>IMG_8969.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_8976.JPG' href='bridges.php?fileId=IMG_8976.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060421/IMG_8976.JPG' ALT='IMG_8976.JPG'><BR>IMG_8976.JPG<br>55.97 KB</a><div class='inv'><br><a href='./images/20060421/IMG_8976.JPG' ALT='IMG_8976.JPG'>IMG_8976.JPG</a></div></td>
<td><A ID='IMG_8977.JPG' href='bridges.php?fileId=IMG_8977.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060421/IMG_8977.JPG' ALT='IMG_8977.JPG'><BR>IMG_8977.JPG<br>59.68 KB</a><div class='inv'><br><a href='./images/20060421/IMG_8977.JPG' ALT='IMG_8977.JPG'>IMG_8977.JPG</a></div></td>
<td><A ID='IMG_8980.JPG' href='bridges.php?fileId=IMG_8980.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060421/IMG_8980.JPG' ALT='IMG_8980.JPG'><BR>IMG_8980.JPG<br>56.88 KB</a><div class='inv'><br><a href='./images/20060421/IMG_8980.JPG' ALT='IMG_8980.JPG'>IMG_8980.JPG</a></div></td>
<td><A ID='IMG_8981.JPG' href='bridges.php?fileId=IMG_8981.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060421/IMG_8981.JPG' ALT='IMG_8981.JPG'><BR>IMG_8981.JPG<br>61.83 KB</a><div class='inv'><br><a href='./images/20060421/IMG_8981.JPG' ALT='IMG_8981.JPG'>IMG_8981.JPG</a></div></td>
<td><A ID='IMG_8991.JPG' href='bridges.php?fileId=IMG_8991.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060421/IMG_8991.JPG' ALT='IMG_8991.JPG'><BR>IMG_8991.JPG<br>37.88 KB</a><div class='inv'><br><a href='./images/20060421/IMG_8991.JPG' ALT='IMG_8991.JPG'>IMG_8991.JPG</a></div></td>
</tr>
<tr><td><A ID='IMG_8993.JPG' href='bridges.php?fileId=IMG_8993.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060421/IMG_8993.JPG' ALT='IMG_8993.JPG'><BR>IMG_8993.JPG<br>42.08 KB</a><div class='inv'><br><a href='./images/20060421/IMG_8993.JPG' ALT='IMG_8993.JPG'>IMG_8993.JPG</a></div></td>
<td><A ID='IMG_8996.JPG' href='bridges.php?fileId=IMG_8996.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060421/IMG_8996.JPG' ALT='IMG_8996.JPG'><BR>IMG_8996.JPG<br>70.5 KB</a><div class='inv'><br><a href='./images/20060421/IMG_8996.JPG' ALT='IMG_8996.JPG'>IMG_8996.JPG</a></div></td>
<td><A ID='IMG_9003.JPG' href='bridges.php?fileId=IMG_9003.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060421/IMG_9003.JPG' ALT='IMG_9003.JPG'><BR>IMG_9003.JPG<br>86.11 KB</a><div class='inv'><br><a href='./images/20060421/IMG_9003.JPG' ALT='IMG_9003.JPG'>IMG_9003.JPG</a></div></td>
<td><A ID='IMG_9013.JPG' href='bridges.php?fileId=IMG_9013.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060421/IMG_9013.JPG' ALT='IMG_9013.JPG'><BR>IMG_9013.JPG<br>56.59 KB</a><div class='inv'><br><a href='./images/20060421/IMG_9013.JPG' ALT='IMG_9013.JPG'>IMG_9013.JPG</a></div></td>
<td><A ID='IMG_9018.JPG' href='bridges.php?fileId=IMG_9018.JPG'><img src='modules/cms/showthumb.php?image=../.././images/20060421/IMG_9018.JPG' ALT='IMG_9018.JPG'><BR>IMG_9018.JPG<br>37.63 KB</a><div class='inv'><br><a href='./images/20060421/IMG_9018.JPG' ALT='IMG_9018.JPG'>IMG_9018.JPG</a></div></td>
</tr>
</table>	</div>
</div>
</body>
</html>