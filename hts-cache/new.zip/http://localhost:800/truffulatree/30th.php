<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Mark's Homepage - 30th Birthday - Pictures of my 30th Birthday party</title>
	<LINK rel=STYLESHEET href="templates/truffulatree.css" type="text/css">
	<META content="Mark" name="Author">
	<META content="nerd's eye view,australia,photos,travel" name="KeyWords">
	<META name="description" content="Pictures of my 30th Birthday party">
	<META content="TravelWin CMS" name="Generator">
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
		_uacct = "UA-1273091-1";
		urchinTracker();
	</script>
</head>
<body>
<div id="page">
	<div id="navigation">
		<img src="images/mark_upside.jpg" alt="Peekaboo!" title="Peekaboo!" width="153" height="244">
		<ul>
	<li>Navigate to:</li>
<li><a title="Pictures of my 28th Birthday party complete with Sparkler Bomb" href='28th.php'>28th Birthday</a></li>
<li><div class='activemenu'>30th Birthday</div></li>
<li><a title="Michael Shamgar and Lindsay Halamek's 30th birthday bash photos" href='sl30th.php'>Shams & Linds' 30th</a></li>
<li><a title="Pictures of Andy Marinos's new flat, cat Toby, and Mum Pam Swain" href='andycatandflat.php'>Andy's Cat & Flat</a></li>
<li><a title="Pictures of a visit to Stephen Jackson's Farm" href='jackovisit.php'>Jacko's Farm</a></li>
<li><a title="Pictures taken at the Peace Convergence action in Rockhampton and Yeppoon in June 2005 to protest the joint US Australia military exercises (Operation Talisman Sabre)" href='peaceconvergence.php'>Peace Convergence</a></li>
<li><a title="Sydney trip - April '06" href='bridges.php'>Sydney, April 06</a></li>
<li><a title="Pics of Naima's 28th birthday dinner" href='mim28th.php'>Naima's 28th</a></li>
<li><a title="Brisbane CBD and the Story Bridge" href='brisbanepics1.php'>Brissie by Night 1</a></li>
<li><a title="Lamington National Park" href='lamington.php'>Lamington NP</a></li>
<li><a title="Various creatures and views from our Brisbane back yard" href='backyard.php'>Backyard Creatures</a></li>
<li><a title="Opening day of the Eleanor Schonell (Green) Bridge" href='greenbridge.php'>Green Bridge</a></li>
<li><a title="Pictutres from the 2006 Woodford Folk Festival" href='woodford0607.php'>Woodford 2006-2007</a></li>
<li><a title="One Cute Puppy" href='jezebel.php'>Jezebel</a></li>
<li><a title="Climbing at Kangaroo Point Cliffs" href='kangaroopt1.php'>Heather's Visit</a></li>
<li><a title="0x0021st (33rd) birthday celebrations" href='0x0021st.php'>0x0021st Birthday</a></li>
<li><a title="Nuptial photography" href='guyandalison.php'>Guy and Alison's Wedding</a></li>
<li><a title="Pictures from the 2007 Woodford Folk Festival" href='woodford0708.php'>Woodford 2007-2008</a></li>
<li><a title="Image gallery" href='sydneytrip0802.php'>Sydney & Yacaaba Head</a></li>
<li><a title="An impressive show by nature" href='lightning.php'>Thunderstorm Moonrise</a></li>
<li><a title="Frightening pictures of a shrinking beard" href='debearding.php'>De-bearding</a></li>
<li><a title="More Nuptial Photography" href='michaelandkaren.php'>Michael and Karen's Wedding</a></li>
<li><a title="A night of celebration" href='andrews21st.php'>Andrew's 21st</a></li>
<li><a title="Image Gallery" href='bloodyknee.php'>Bloody Knee</a></li>
<li><a title="Image Gallery" href='tyesbirthday.php'>Tye's Birthday</a></li>
<li><a title="Image Gallery" href='lasersocialising.php'>Laser Socialising</a></li>
<li><a title="Image Gallery" href='heatherandevan.php'>Heather and Evan's Wedding</a></li>
<li><a title="Image Gallery" href='woodford0809.php'>Woodford 2008-2009</a></li>
<li><a title="Image Gallery" href='allyandben.php'>Ally and Ben's Wedding</a></li>
<li><a title="Image Gallery" href='annes30th.php'>Anne's 30th</a></li>
<li><a title="Image Gallery" href='possumcreek.php'>Possum Creek</a></li>
<li><a title="Image Gallery" href='jamnight.php'>Jam Night</a></li>
<li><a title="Image Gallery" href='cunninghamsgap.php'>Cunningham's Gap</a></li>
<li><a title="Image Gallery" href='bigcat.php'>Diving on Big Cat</a></li>
<li><a title="Images from my birthday jam" href='birthdayjam.php'>Music, mayhem and merriment</a></li>
<li><a title="Image Gallery" href='fuzzypolaroidpics.php'>Fuzzy Polaroid</a></li>
<li><a title="Image Gallery" href='zombiewalk2009.php'>2009 Zombie Walk</a></li>
<li> </li><br><li>Or go back to:</li><li><a title='Picture galleries' href="pictures.php">Photography</a></li>
</ul>
<BR>
		<p>
		<IMG src="images/loraxlg.gif" alt="I speak for the trees!" title="I speak for the trees!">
		<BR><BR>
		<script type="text/javascript"><!--
		google_ad_client = "pub-6581529309076769";
		google_ad_width = 120;
		google_ad_height = 600;
		google_ad_format = "120x600_as";
		google_ad_type = "text";
		google_ad_channel ="";
		google_color_border = "E0FFE3";
		google_color_bg = "E0FFE3";
		google_color_link = "0000CC";
		google_color_url = "008000";
		google_color_text = "000000";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</p>
	</div>
	<div id="content">
		<!-- display content -->
		<h1>30th Birthday</h1>
		You are here: <a title='truffulatree.com.au homepage' href="home.php">Home</a> > <a title='Picture galleries' href="pictures.php">Photography</a> > <a title='Pictures of my 30th Birthday party' href="30th.php">30th Birthday</a>
<br><br>		

<p>Yep, I'm now officially an Old Bastard.</p>

<br><br>
All images in this gallery:<br>
<table width='800'>
<tr>
</tr>
<tr><td><A ID='Brisbane176949.jpg' href='30th.php?fileId=Brisbane176949.jpg'><img src='modules/cms/showthumb.php?image=../.././images/30th/Brisbane176949.jpg' ALT='Brisbane176949.jpg'><BR>Brisbane176949.jpg<br>84.78 KB</a><div class='inv'><br><a href='./images/30th/Brisbane176949.jpg' ALT='Brisbane176949.jpg'>Brisbane176949.jpg</a></div></td>
<td><A ID='Brisbane176950.jpg' href='30th.php?fileId=Brisbane176950.jpg'><img src='modules/cms/showthumb.php?image=../.././images/30th/Brisbane176950.jpg' ALT='Brisbane176950.jpg'><BR>Brisbane176950.jpg<br>87.24 KB</a><div class='inv'><br><a href='./images/30th/Brisbane176950.jpg' ALT='Brisbane176950.jpg'>Brisbane176950.jpg</a></div></td>
<td><A ID='Brisbane176951.jpg' href='30th.php?fileId=Brisbane176951.jpg'><img src='modules/cms/showthumb.php?image=../.././images/30th/Brisbane176951.jpg' ALT='Brisbane176951.jpg'><BR>Brisbane176951.jpg<br>84.67 KB</a><div class='inv'><br><a href='./images/30th/Brisbane176951.jpg' ALT='Brisbane176951.jpg'>Brisbane176951.jpg</a></div></td>
<td><A ID='IMG_0235.jpg' href='30th.php?fileId=IMG_0235.jpg'><img src='modules/cms/showthumb.php?image=../.././images/30th/IMG_0235.jpg' ALT='IMG_0235.jpg'><BR>IMG_0235.jpg<br>65.88 KB</a><div class='inv'><br><a href='./images/30th/IMG_0235.jpg' ALT='IMG_0235.jpg'>IMG_0235.jpg</a></div></td>
<td><A ID='IMG_0236.jpg' href='30th.php?fileId=IMG_0236.jpg'><img src='modules/cms/showthumb.php?image=../.././images/30th/IMG_0236.jpg' ALT='IMG_0236.jpg'><BR>IMG_0236.jpg<br>43.57 KB</a><div class='inv'><br><a href='./images/30th/IMG_0236.jpg' ALT='IMG_0236.jpg'>IMG_0236.jpg</a></div></td>
</tr>
<tr><td><A ID='IMG_0237.jpg' href='30th.php?fileId=IMG_0237.jpg'><img src='modules/cms/showthumb.php?image=../.././images/30th/IMG_0237.jpg' ALT='IMG_0237.jpg'><BR>IMG_0237.jpg<br>65.7 KB</a><div class='inv'><br><a href='./images/30th/IMG_0237.jpg' ALT='IMG_0237.jpg'>IMG_0237.jpg</a></div></td>
<td><A ID='IMG_0238.jpg' href='30th.php?fileId=IMG_0238.jpg'><img src='modules/cms/showthumb.php?image=../.././images/30th/IMG_0238.jpg' ALT='IMG_0238.jpg'><BR>IMG_0238.jpg<br>59.81 KB</a><div class='inv'><br><a href='./images/30th/IMG_0238.jpg' ALT='IMG_0238.jpg'>IMG_0238.jpg</a></div></td>
<td><A ID='IMG_0239.jpg' href='30th.php?fileId=IMG_0239.jpg'><img src='modules/cms/showthumb.php?image=../.././images/30th/IMG_0239.jpg' ALT='IMG_0239.jpg'><BR>IMG_0239.jpg<br>59.87 KB</a><div class='inv'><br><a href='./images/30th/IMG_0239.jpg' ALT='IMG_0239.jpg'>IMG_0239.jpg</a></div></td>
<td><A ID='IMG_0240.jpg' href='30th.php?fileId=IMG_0240.jpg'><img src='modules/cms/showthumb.php?image=../.././images/30th/IMG_0240.jpg' ALT='IMG_0240.jpg'><BR>IMG_0240.jpg<br>117.69 KB</a><div class='inv'><br><a href='./images/30th/IMG_0240.jpg' ALT='IMG_0240.jpg'>IMG_0240.jpg</a></div></td>
<td><A ID='IMG_0241.jpg' href='30th.php?fileId=IMG_0241.jpg'><img src='modules/cms/showthumb.php?image=../.././images/30th/IMG_0241.jpg' ALT='IMG_0241.jpg'><BR>IMG_0241.jpg<br>46 KB</a><div class='inv'><br><a href='./images/30th/IMG_0241.jpg' ALT='IMG_0241.jpg'>IMG_0241.jpg</a></div></td>
</tr>
<tr><td><A ID='IMG_0242.jpg' href='30th.php?fileId=IMG_0242.jpg'><img src='modules/cms/showthumb.php?image=../.././images/30th/IMG_0242.jpg' ALT='IMG_0242.jpg'><BR>IMG_0242.jpg<br>60.69 KB</a><div class='inv'><br><a href='./images/30th/IMG_0242.jpg' ALT='IMG_0242.jpg'>IMG_0242.jpg</a></div></td>
<td><A ID='IMG_0243.jpg' href='30th.php?fileId=IMG_0243.jpg'><img src='modules/cms/showthumb.php?image=../.././images/30th/IMG_0243.jpg' ALT='IMG_0243.jpg'><BR>IMG_0243.jpg<br>79.02 KB</a><div class='inv'><br><a href='./images/30th/IMG_0243.jpg' ALT='IMG_0243.jpg'>IMG_0243.jpg</a></div></td>
<td><A ID='IMG_0244.jpg' href='30th.php?fileId=IMG_0244.jpg'><img src='modules/cms/showthumb.php?image=../.././images/30th/IMG_0244.jpg' ALT='IMG_0244.jpg'><BR>IMG_0244.jpg<br>79.55 KB</a><div class='inv'><br><a href='./images/30th/IMG_0244.jpg' ALT='IMG_0244.jpg'>IMG_0244.jpg</a></div></td>
<td><A ID='IMG_0245.jpg' href='30th.php?fileId=IMG_0245.jpg'><img src='modules/cms/showthumb.php?image=../.././images/30th/IMG_0245.jpg' ALT='IMG_0245.jpg'><BR>IMG_0245.jpg<br>57.12 KB</a><div class='inv'><br><a href='./images/30th/IMG_0245.jpg' ALT='IMG_0245.jpg'>IMG_0245.jpg</a></div></td>
<td><A ID='IMG_0246.jpg' href='30th.php?fileId=IMG_0246.jpg'><img src='modules/cms/showthumb.php?image=../.././images/30th/IMG_0246.jpg' ALT='IMG_0246.jpg'><BR>IMG_0246.jpg<br>42.61 KB</a><div class='inv'><br><a href='./images/30th/IMG_0246.jpg' ALT='IMG_0246.jpg'>IMG_0246.jpg</a></div></td>
</tr>
<tr><td><A ID='IMG_0247.jpg' href='30th.php?fileId=IMG_0247.jpg'><img src='modules/cms/showthumb.php?image=../.././images/30th/IMG_0247.jpg' ALT='IMG_0247.jpg'><BR>IMG_0247.jpg<br>60.74 KB</a><div class='inv'><br><a href='./images/30th/IMG_0247.jpg' ALT='IMG_0247.jpg'>IMG_0247.jpg</a></div></td>
<td><A ID='IMG_0248.jpg' href='30th.php?fileId=IMG_0248.jpg'><img src='modules/cms/showthumb.php?image=../.././images/30th/IMG_0248.jpg' ALT='IMG_0248.jpg'><BR>IMG_0248.jpg<br>82.14 KB</a><div class='inv'><br><a href='./images/30th/IMG_0248.jpg' ALT='IMG_0248.jpg'>IMG_0248.jpg</a></div></td>
<td><A ID='IMG_0249.jpg' href='30th.php?fileId=IMG_0249.jpg'><img src='modules/cms/showthumb.php?image=../.././images/30th/IMG_0249.jpg' ALT='IMG_0249.jpg'><BR>IMG_0249.jpg<br>84.22 KB</a><div class='inv'><br><a href='./images/30th/IMG_0249.jpg' ALT='IMG_0249.jpg'>IMG_0249.jpg</a></div></td>
<td><A ID='IMG_0250.jpg' href='30th.php?fileId=IMG_0250.jpg'><img src='modules/cms/showthumb.php?image=../.././images/30th/IMG_0250.jpg' ALT='IMG_0250.jpg'><BR>IMG_0250.jpg<br>73.62 KB</a><div class='inv'><br><a href='./images/30th/IMG_0250.jpg' ALT='IMG_0250.jpg'>IMG_0250.jpg</a></div></td>
<td><A ID='IMG_0251.jpg' href='30th.php?fileId=IMG_0251.jpg'><img src='modules/cms/showthumb.php?image=../.././images/30th/IMG_0251.jpg' ALT='IMG_0251.jpg'><BR>IMG_0251.jpg<br>77.31 KB</a><div class='inv'><br><a href='./images/30th/IMG_0251.jpg' ALT='IMG_0251.jpg'>IMG_0251.jpg</a></div></td>
</tr>
<tr><td><A ID='IMG_0252.jpg' href='30th.php?fileId=IMG_0252.jpg'><img src='modules/cms/showthumb.php?image=../.././images/30th/IMG_0252.jpg' ALT='IMG_0252.jpg'><BR>IMG_0252.jpg<br>29.27 KB</a><div class='inv'><br><a href='./images/30th/IMG_0252.jpg' ALT='IMG_0252.jpg'>IMG_0252.jpg</a></div></td>
<td><A ID='IMG_0253.jpg' href='30th.php?fileId=IMG_0253.jpg'><img src='modules/cms/showthumb.php?image=../.././images/30th/IMG_0253.jpg' ALT='IMG_0253.jpg'><BR>IMG_0253.jpg<br>68.88 KB</a><div class='inv'><br><a href='./images/30th/IMG_0253.jpg' ALT='IMG_0253.jpg'>IMG_0253.jpg</a></div></td>
<td><A ID='IMG_0254.jpg' href='30th.php?fileId=IMG_0254.jpg'><img src='modules/cms/showthumb.php?image=../.././images/30th/IMG_0254.jpg' ALT='IMG_0254.jpg'><BR>IMG_0254.jpg<br>26.1 KB</a><div class='inv'><br><a href='./images/30th/IMG_0254.jpg' ALT='IMG_0254.jpg'>IMG_0254.jpg</a></div></td>
<td><A ID='IMG_0255.jpg' href='30th.php?fileId=IMG_0255.jpg'><img src='modules/cms/showthumb.php?image=../.././images/30th/IMG_0255.jpg' ALT='IMG_0255.jpg'><BR>IMG_0255.jpg<br>17.08 KB</a><div class='inv'><br><a href='./images/30th/IMG_0255.jpg' ALT='IMG_0255.jpg'>IMG_0255.jpg</a></div></td>
<td><A ID='IMG_0256.jpg' href='30th.php?fileId=IMG_0256.jpg'><img src='modules/cms/showthumb.php?image=../.././images/30th/IMG_0256.jpg' ALT='IMG_0256.jpg'><BR>IMG_0256.jpg<br>17.37 KB</a><div class='inv'><br><a href='./images/30th/IMG_0256.jpg' ALT='IMG_0256.jpg'>IMG_0256.jpg</a></div></td>
</tr>
<tr><td><A ID='IMG_0257.jpg' href='30th.php?fileId=IMG_0257.jpg'><img src='modules/cms/showthumb.php?image=../.././images/30th/IMG_0257.jpg' ALT='IMG_0257.jpg'><BR>IMG_0257.jpg<br>16.09 KB</a><div class='inv'><br><a href='./images/30th/IMG_0257.jpg' ALT='IMG_0257.jpg'>IMG_0257.jpg</a></div></td>
<td><A ID='IMG_0258.jpg' href='30th.php?fileId=IMG_0258.jpg'><img src='modules/cms/showthumb.php?image=../.././images/30th/IMG_0258.jpg' ALT='IMG_0258.jpg'><BR>IMG_0258.jpg<br>17.97 KB</a><div class='inv'><br><a href='./images/30th/IMG_0258.jpg' ALT='IMG_0258.jpg'>IMG_0258.jpg</a></div></td>
<td><A ID='IMG_0259.jpg' href='30th.php?fileId=IMG_0259.jpg'><img src='modules/cms/showthumb.php?image=../.././images/30th/IMG_0259.jpg' ALT='IMG_0259.jpg'><BR>IMG_0259.jpg<br>67.24 KB</a><div class='inv'><br><a href='./images/30th/IMG_0259.jpg' ALT='IMG_0259.jpg'>IMG_0259.jpg</a></div></td>
<td><A ID='IMG_0260.jpg' href='30th.php?fileId=IMG_0260.jpg'><img src='modules/cms/showthumb.php?image=../.././images/30th/IMG_0260.jpg' ALT='IMG_0260.jpg'><BR>IMG_0260.jpg<br>17.07 KB</a><div class='inv'><br><a href='./images/30th/IMG_0260.jpg' ALT='IMG_0260.jpg'>IMG_0260.jpg</a></div></td>
<td><A ID='IMG_0261.jpg' href='30th.php?fileId=IMG_0261.jpg'><img src='modules/cms/showthumb.php?image=../.././images/30th/IMG_0261.jpg' ALT='IMG_0261.jpg'><BR>IMG_0261.jpg<br>44.28 KB</a><div class='inv'><br><a href='./images/30th/IMG_0261.jpg' ALT='IMG_0261.jpg'>IMG_0261.jpg</a></div></td>
</tr>
<tr><td><A ID='IMG_0262.jpg' href='30th.php?fileId=IMG_0262.jpg'><img src='modules/cms/showthumb.php?image=../.././images/30th/IMG_0262.jpg' ALT='IMG_0262.jpg'><BR>IMG_0262.jpg<br>66.23 KB</a><div class='inv'><br><a href='./images/30th/IMG_0262.jpg' ALT='IMG_0262.jpg'>IMG_0262.jpg</a></div></td>
<td><A ID='IMG_0263.jpg' href='30th.php?fileId=IMG_0263.jpg'><img src='modules/cms/showthumb.php?image=../.././images/30th/IMG_0263.jpg' ALT='IMG_0263.jpg'><BR>IMG_0263.jpg<br>19.57 KB</a><div class='inv'><br><a href='./images/30th/IMG_0263.jpg' ALT='IMG_0263.jpg'>IMG_0263.jpg</a></div></td>
<td><A ID='IMG_0264.jpg' href='30th.php?fileId=IMG_0264.jpg'><img src='modules/cms/showthumb.php?image=../.././images/30th/IMG_0264.jpg' ALT='IMG_0264.jpg'><BR>IMG_0264.jpg<br>36.54 KB</a><div class='inv'><br><a href='./images/30th/IMG_0264.jpg' ALT='IMG_0264.jpg'>IMG_0264.jpg</a></div></td>
</tr>
</table>	</div>
</div>
</body>
</html>